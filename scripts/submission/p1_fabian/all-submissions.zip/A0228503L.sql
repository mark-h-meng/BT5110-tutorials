/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228503L                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.03 ms
-- Average Execution 1.35 ms
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid , per.lname;

-- Average Planning 0.03 ms
-- Average Execution 1.25 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.salary, pay.empid FROM payroll pay) AS temp
WHERE temp.salary = 189170 AND temp.empid = per.empid
ORDER BY per.empid, per.lname;
-- Average Planning 0.03 ms
-- Average Execution 1.27 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per
WHERE per.empid NOT IN ( SELECT pay.empid FROM payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid , per.lname;
-- Average Planning 0.02 ms
-- Average Execution 2.55 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT DISTINCT per.empid , per.lname
FROM employee per, (SELECT temp1.empid, temp1.salary FROM 
	  (SELECT temp2.empid, temp2.salary FROM 
	   (SELECT temp3.salary, temp3.empid FROM 
		(SELECT temp4.salary, temp4.empid FROM 
		 (SELECT temp5.salary, temp5.empid FROM 
		  (SELECT pay.salary, pay.empid FROM payroll pay WHERE pay.salary%10 =0) AS temp5 
		  WHERE temp5.salary%100 = 70) AS temp4 
		 WHERE temp4.salary%1000=170) AS temp3
		WHERE temp3.salary%10000 =9170 ) AS temp2
	   WHERE temp2.salary%100000 =89170) AS temp1
	  WHERE temp1.salary%1000000 = 189170) AS temp
WHERE per.empid NOT IN ( SELECT per.empid FROM employee per, 
						(SELECT pay.salary, pay.empid FROM payroll pay WHERE pay.salary = 189170
						UNION
						SELECT pay.salary, pay.empid FROM payroll pay WHERE pay.salary < 189170
						UNION
						SELECT pay.salary, pay.empid FROM payroll pay WHERE pay.salary > 189170) AS pay
					WHERE lower(per.empid) LIKE lower(pay.empid) AND pay.salary <> 189170) AND temp.salary = 189170
ORDER BY per.empid , per.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.17 ms
-- Average Execution 50562 ms
