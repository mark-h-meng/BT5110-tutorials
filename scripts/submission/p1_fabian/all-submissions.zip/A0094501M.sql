/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0094501M                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL
ORDER BY per.empid, per.lname;

-- Average Planning 0.11 ms
-- Average Execution 3.67 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll pay where pay.salary = 189170) AS temp
WHERE temp.empid = per.empid
ORDER BY per.empid, per.lname;

-- Average Planning 0.09 ms
-- Average Execution 3.33 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.05 ms
-- Average Execution 5.63 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
 SELECT per.empid, per.lname
FROM employee per
GROUP BY 1, 2
HAVING (
	SELECT a.empid FROM (
	SELECT p.empid, pay.empid as payempid
	FROM payroll pay FULL OUTER JOIN employee p
	ON per.empid = pay.empid
	WHERE pay.salary = 189170) a
	WHERE a.empid IS NOT NULL AND payempid IS NOT NULL
	LIMIT 1
) IS NOT NULL
ORDER BY per.empid, per.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.18 ms
-- Average Execution 13271.88 ms
