/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0248349R                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning <0.05> ms
-- Average Execution <1.40> ms
-- SELECT test('SELECT per.empid, per.lname
-- FROM employee per FULL OUTER JOIN payroll pay 
--     ON per.empid = pay.empid AND pay.salary = 189170
-- WHERE pay.salary = 189170
-- ORDER BY per.empid, per.lname;', 1000);

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, 
	(
		SELECT *
		FROM payroll pay
		where pay.salary = 189170
	) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Average Planning <0.05> ms
-- Average Execution <1.43> ms
-- SELECT test('SELECT per.empid, per.lname
-- FROM employee per, 
-- 	(
-- 		SELECT *
-- 		FROM payroll pay
-- 		where pay.salary = 189170
-- 	) AS temp
-- WHERE per.empid = temp.empid
-- ORDER BY per.empid, per.lname;', 1000);

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN 
	(
		SELECT pay.empid
		FROM payroll pay
		WHERE pay.salary <> 189170
	)
ORDER BY per.empid, per.lname;

-- Average Planning <0.04> ms
-- Average Execution <3.34> ms
-- SELECT test('SELECT per.empid, per.lname
-- FROM employee per
-- WHERE per.empid NOT IN 
-- 	(
-- 		SELECT pay.empid
-- 		FROM payroll pay
-- 		WHERE pay.salary <> 189170
-- 	)
-- ORDER BY per.empid, per.lname;', 1000)

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per0.empid, per0.lname
FROM employee per0 FULL OUTER JOIN payroll pay0
ON per0.empid = pay0.empid
WHERE per0.empid NOT IN (
	SELECT pay1.empid
	FROM employee per1 CROSS JOIN payroll pay1
	WHERE (pay1.salary <> 189170)
)
ORDER BY per0.empid, per0.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.12> ms
-- Average Execution <92254.08> ms

-- SELECT test('SELECT per0.empid, per0.lname
-- FROM employee per0 FULL OUTER JOIN payroll pay0
-- ON per0.empid = pay0.empid
-- WHERE per0.empid NOT IN (
-- 	SELECT pay1.empid
-- 	FROM employee per1 CROSS JOIN payroll pay1
-- 	WHERE (pay1.salary <> 189170)
-- )
-- ORDER BY per0.empid, per0.lname;', 20);
