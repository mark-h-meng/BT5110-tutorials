/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232482J                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.04 ms
-- Average Execution 2.75 ms
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.05 ms
-- Average Execution 2.75 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary FROM payroll pay) AS temp
WHERE temp.salary = 189170 AND per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Average Planning 0.04 ms
-- Average Execution 2.75 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll pay, employee per1
						WHERE per1.empid = pay.empid AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.10 ms
-- Average Execution 14.16 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN (SELECT pay.empid, pay.salary 
								   FROM payroll pay) AS temp
    ON per.empid = temp.empid
WHERE per.empid NOT IN (SELECT empid FROM payroll pay 
						WHERE per.empid = pay.empid AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.11 ms
-- Average Execution 6721.84 ms

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
