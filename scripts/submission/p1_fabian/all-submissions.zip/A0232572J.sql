/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232572J                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

select test('SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;' ,1000); 

-- Average Planning <0.02> ms
-- Average Execution <0.95> ms

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

select test('SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;' ,1000); 

-- Average Planning <0.02> ms
-- Average Execution <0.96> ms


/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary from payroll) AS temp
WHERE per.empid = temp.empid and temp.salary = 189170
ORDER BY per.empid, per.lname;

select test('SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary from payroll) AS temp
WHERE per.empid = temp.empid and temp.salary = 189170
ORDER BY per.empid, per.lname;' ,1000); 

-- Average Planning <0.02> ms
-- Average Execution <0.95> ms


/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid from payroll where salary <> 189170)
ORDER BY per.empid, per.lname;

select test('SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid from payroll where salary <> 189170)
ORDER BY per.empid, per.lname;' ,1000); 

-- Average Planning <0.01> ms
-- Average Execution <2.22> ms


/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per full outer join payroll pay on per.empid = pay.empid
WHERE pay.salary NOT IN (SELECT salary FROM payroll WHERE salary <> 189170 and per.empid = pay.empid)
ORDER BY per.empid, per.lname;

select test('SELECT per.empid, per.lname
FROM employee per full outer join payroll pay on per.empid = pay.empid
WHERE pay.salary NOT IN (SELECT salary FROM payroll WHERE salary <> 189170 and per.empid = pay.empid)
ORDER BY per.empid, per.lname;',20)


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.06> ms
-- Average Execution <924.10> ms
