/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: E0524769                 */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
-- Average Planning 0.16 ms
-- Average Execution 4.16 ms
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary IS NOT NULL AND per.empid IS NOT NULL
ORDER BY per.empid, per.lname;
-- Average Planning 0.17 ms
-- Average Execution 4.74 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid
				    FROM payroll pay
				    WHERE pay.salary = 189170 ) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
-- Average Planning 0.15 ms
-- Average Execution 4.06 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid
				        FROM payroll pay
				        WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;
-- Average Planning 0.13 ms
-- Average Execution 10.62 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

----------------13 mins 37 secs ---
SELECT per.empid, per.lname
FROM employee per
WHERE 0 < (SELECT COUNT(*)
	       FROM payroll pay
	       WHERE (pay.empid NOT IN (SELECT pay.empid
								    FROM payroll pay
								    WHERE pay.empid <> per.empid
									AND pay.empid IS NOT NULL
								    ORDER BY pay.empid DESC)
				 )
	       AND (pay.salary NOT IN ((SELECT pay.salary
									FROM payroll pay
									WHERE pay.salary  NOT IN (SELECT pay.salary
															  FROM payroll pay
															  WHERE pay.salary NOT IN (SELECT pay.salary
																					   FROM payroll pay
																					   WHERE pay.salary < 189170
																					   AND pay.salary IS NOT NULL 
																					   ORDER BY pay.salary DESC)
															  AND pay.salary IS NOT NULL 
															  ORDER BY pay.salary ASC
															 )
									AND pay.salary IS NOT NULL 
									ORDER BY pay.salary DESC)
								   UNION
								   (SELECT pay.salary
									FROM payroll pay
									WHERE pay.salary  NOT IN (SELECT pay.salary
															  FROM payroll pay
															  WHERE pay.salary NOT IN (SELECT pay.salary
																					   FROM payroll pay
																					   WHERE pay.salary > 189170
																					   AND pay.salary IS NOT NULL 
																					   ORDER BY pay.salary DESC
																					  )
															  AND pay.salary IS NOT NULL 
															  ORDER BY pay.salary ASC
															 )
									AND pay.salary IS NOT NULL 
									ORDER BY pay.salary DESC)
								  )
			   )
		  )
ORDER BY per.empid, per.lname;
-- Average Planning  1.82 ms
-- Average Execution 807549 ms

SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE 0 < (SELECT COUNT(*)
	       FROM payroll pay
	       WHERE (pay.empid NOT IN (SELECT pay.empid
								    FROM payroll pay
								    WHERE pay.empid <> per.empid
									AND pay.empid IS NOT NULL
								    ORDER BY pay.empid DESC)
				 )
	       AND (pay.salary NOT IN ((SELECT pay.salary
									FROM payroll pay
									WHERE pay.salary  NOT IN (SELECT pay.salary
															  FROM payroll pay
															  WHERE pay.salary NOT IN (SELECT pay.salary
																					   FROM payroll pay
																					   WHERE pay.salary < 189170
																					   AND pay.salary IS NOT NULL 
																					   ORDER BY pay.salary DESC)
															  AND pay.salary IS NOT NULL 
															  ORDER BY pay.salary ASC
															 )
									AND pay.salary IS NOT NULL 
									ORDER BY pay.salary DESC)
								   UNION
								   (SELECT pay.salary
									FROM payroll pay
									WHERE pay.salary  NOT IN (SELECT pay.salary
															  FROM payroll pay
															  WHERE pay.salary NOT IN (SELECT pay.salary
																					   FROM payroll pay
																					   WHERE pay.salary > 189170
																					   AND pay.salary IS NOT NULL 
																					   ORDER BY pay.salary DESC
																					  )
															  AND pay.salary IS NOT NULL 
															  ORDER BY pay.salary ASC
															 )
									AND pay.salary IS NOT NULL 
									ORDER BY pay.salary DESC)
								  )
			   )
		  )
ORDER BY per.empid, per.lname;
' , 20)

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning  ms
-- Average Execution  ms
