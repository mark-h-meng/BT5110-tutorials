/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0212201J                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
	AND pay.empid IS NOT NULL
ORDER BY per.empid, per.lname;
-- Average Planning 0.06 ms
-- Average Execution 2.98 ms
/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (
		SELECT DISTINCT pay.empid
		FROM payroll pay
		WHERE pay.salary = 189170
	) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
-- Average Planning 0.06 ms
-- Average Execution 2.76 ms
/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (
	SELECT DISTINCT pay.empid
	FROM payroll pay
	WHERE pay.salary != 189170
)
ORDER BY per.empid, per.lname;
-- Average Planning 0.06 ms
-- Average Execution 8.49 ms
/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT tmp.empid, tmp.lname
FROM (
	SELECT per.empid, per.lname, row_number() OVER(
		PARTITION BY per.empid, per.lname
		ORDER BY per.empid, per.lname
		) AS row_num
	FROM employee per, payroll pay
	WHERE per.empid != ALL (
			SELECT pay1.empid
			FROM payroll pay1
			WHERE pay1.salary != 189170
	) 
		AND pay.salary != ALL (
			SELECT pay2.salary
			FROM payroll pay2
			WHERE pay2.salary != 189170
	)
) AS tmp
WHERE tmp.row_num = 1
ORDER BY tmp.empid, tmp.lname;
-- Average Planning 0.12 ms
-- Average Execution 11049.55 ms
