/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228550H                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
-- Average Planning 0.06 ms; Average Execution 3.17 ms
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL
ORDER BY per.empid, per.lname;
-- Average Planning 0.07 ms; Average Execution 3.49 ms
/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid from payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
-- Average Planning 0.07 ms; Average Execution 3.18 ms
/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid from payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;
-- Average Planning 0.05 ms; Average Execution 8.34 ms
/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
 SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN(
    SELECT unioned.empid FROM (
            (SELECT tmp1.pid AS empid, tmp1.salary FROM (
                SELECT pay.empid AS pid, e.empid AS eid, salary
                FROM payroll pay CROSS JOIN employee e
                ) AS tmp1
                WHERE tmp1.pid = tmp1.eid AND tmp1.salary < 189170 AND per.empid IS NOT NULL
            )  UNION
            (SELECT tmp2.empid,tmp2.salary FROM (
                SELECT pay.empid, salary
                FROM payroll pay FULL OUTER JOIN employee e
                ON pay.empid = e.empid AND per.empid IS NOT NULL
                ) AS tmp2
                WHERE tmp2.salary > 189170
                )

        ) AS unioned)
GROUP BY per.empid, per.lname
ORDER BY per.empid, per.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 4.55 ms
-- Average Execution 131000.49 ms
