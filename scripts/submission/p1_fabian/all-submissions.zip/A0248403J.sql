/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0248403J
   test
   0.04 : 1.41
*/
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below
   test : 1000 executions
   average planning times : average execution times
   0.05 : 1.62
*/
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid  is not null and  pay.empid  is not null
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below
   test : 1000 executions
   average planning times : average execution times
   0.05 : 1.44
*/
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid,salary FROM payroll) AS temp
WHERE per.empid=temp.empid and temp.salary=189170
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below
   test : 1000 executions
   average planning times : average execution times
   0.03 : 3.05
*/
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary<>189170)
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below
   test : 100 executions
   average planning times : average execution times
   11.31 : 185.74
*/
/******************************************************************************/
select per.empid,per.lname  from (
    select * from (select empid,lname from (select empid, lname, fname from (select empid, lname, fname, address from (select empid, lname, fname, address, city from (select empid, lname, fname, address, city, state from (select empid, lname, fname, address, city, state, zip from employee) t06) t05) t04) t03) t02) t01 ) per
                                     FULL OUTER JOIN (select empid, lname from employee) t1
                                                     on per.empid = t1.empid
                                     FULL OUTER JOIN (select * from (select empid, salary from (select empid, salary, bonus from payroll) t12) t11) pay
                                                     on per.empid = pay.empid
                                     FULL OUTER join (select empid, salary from payroll) t2
                                                     on pay.empid = t2.empid
                                     FULL OUTER join (select empid, salary from payroll) t3
                                                     on t3.empid = t2.empid
                                     FULL OUTER join (select empid, salary from payroll) t4
                                                     on t3.empid = t4.empid
                                     FULL OUTER join (select empid, salary from payroll) t5
                                                     on t4.empid = t5.empid
                                     FULL OUTER join (select empid, salary from payroll) t6
                                                     on t5.empid = t6.empid
                                     FULL OUTER join (select empid, salary from payroll) t7
                                                     on t6.empid = t7.empid
                                     FULL OUTER join (select empid, salary from payroll) t8
                                                     on t7.empid = t8.empid
                                     FULL OUTER join (select empid, salary from payroll) t9
                                                     on t8.empid = t9.empid
                                     FULL OUTER join (select empid, salary from payroll) t10
                                                     on t9.empid = t10.empid
                                     FULL OUTER join (select empid, salary from payroll) t11
                                                     on t10.empid = t11.empid
where per.empid  is not null  and pay.empid  is not null and t1.empid is not null and t2.empid is not null and t3.empid is not null and t4.empid is not null and t5.empid is not null
  and t6.empid is not null and t7.empid is not null and t8.empid is not null and t9.empid is not null and t10.empid is not null and t11.empid is not null
  and per.empid NOT IN (SELECT empid FROM payroll  WHERE  salary<>189170)
  and t1.empid NOT IN (SELECT empid FROM payroll  WHERE  salary<>189170)
  and t2.empid NOT IN (SELECT empid FROM payroll  WHERE  salary<>189170)
  and t3.empid NOT IN (SELECT empid FROM payroll  WHERE  salary<>189170)
  and t4.empid NOT IN (SELECT empid FROM payroll  WHERE  salary<>189170)
  and t5.empid NOT IN (SELECT empid FROM payroll  WHERE  salary<>189170)
  and t6.empid NOT IN (SELECT empid FROM payroll  WHERE  salary<>189170)
  and t7.empid NOT IN (SELECT empid FROM payroll  WHERE  salary<>189170)
  and t8.empid NOT IN (SELECT empid FROM payroll  WHERE  salary<>189170)
  and t9.empid NOT IN (SELECT empid FROM payroll  WHERE  salary<>189170)
  and t10.empid NOT IN (SELECT empid FROM payroll  WHERE  salary<>189170)
  and t11.empid NOT IN (SELECT empid FROM payroll  WHERE  salary<>189170)

  and pay.salary NOT IN (SELECT salary FROM payroll  WHERE  salary<>189170)
  and t2.salary NOT IN (SELECT salary FROM payroll  WHERE  salary<>189170)
  and t3.salary NOT IN (SELECT salary FROM payroll  WHERE  salary<>189170)
  and t4.salary NOT IN (SELECT salary FROM payroll  WHERE  salary<>189170)
  and t5.salary NOT IN (SELECT salary FROM payroll  WHERE  salary<>189170)
  and t6.salary NOT IN (SELECT salary FROM payroll  WHERE  salary<>189170)
  and t7.salary NOT IN (SELECT salary FROM payroll  WHERE  salary<>189170)
  and t8.salary NOT IN (SELECT salary FROM payroll  WHERE  salary<>189170)
  and t9.salary NOT IN (SELECT salary FROM payroll  WHERE  salary<>189170)
  and t10.salary NOT IN (SELECT salary FROM payroll  WHERE  salary<>189170)
  and t11.salary NOT IN (SELECT salary FROM payroll  WHERE  salary<>189170)
ORDER BY per.empid, per.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
