/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0236586R                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below 
Average planning time: 0.05 ms
Average execution time: 2.73 ms    */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below    
Average planning time: 0.09ms  
Average execution time: 2.88ms */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT TRUE) AS temp
WHERE per.empid in (SELECT empid from payroll where salary = 189170)
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below   
Average planning time: 0.04ms 
Average execution time: 4.76 ms */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid from payroll where salary <> 189170)
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT DISTINCT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid NOT IN (
	SELECT e.empid
	FROM employee e, payroll pr
	WHERE (e.empid = pr.empid)
	AND NOT(
		pr.salary::text LIKE '1%' 
		AND pr.salary::text LIKE '_8%' 
		AND pr.salary::text LIKE '__9%'
		AND pr.salary::text LIKE '___1%'
		AND pr.salary::text LIKE '____7%'
		AND pr.salary::text LIKE '%0')
)
GROUP BY per.empid, per.lname
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- The string part after LIKE cluase should be changed from single quote into double single quotes 
-- when using test() function to test the query
-- e.g. from '1%' into ''1%''
-- Average Planning 0.15 ms
-- Average Execution 51.61 ms
