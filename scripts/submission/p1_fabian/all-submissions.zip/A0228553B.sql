/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228553B                              */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.14 ms
-- Average Execution 4.88 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid from payroll where salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Average Planning 0.13 ms
-- Average Execution 4.77 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid from payroll where salary != 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.09 ms
-- Average Execution 11.10 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT *
FROM employee e
WHERE  e.empid IN(
SELECT p.empid
FROM payroll p
WHERE p.salary = 189170
AND p.empid = e.empid);

-- Average Planning 0.10 ms
-- Average Execution 13716.96 ms
