/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228512L                             */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
-- average measured time for 100 executions for the query.
-- Average Planning 0.08 ms
-- Average Execution 2.63 ms

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.empid IS NOT NULL and per.empid IS NOT NULL
ORDER BY per.empid, per.lname;

-- average measured time for 100 executions for the query.
-- Average Planning 0.08 ms
-- Average Execution 2.74 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid FROM payroll where salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- average measured time for 100 executions for the query.
-- Average Planning 0.09 ms
-- Average Execution 2.55 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT per.empid FROM employee per , payroll pay WHERE per.empid = pay.empid
AND pay.salary != 189170)
ORDER BY per.empid, per.lname;

-- average measured time for 100 executions for the query.
-- Average Planning 0.12 ms
-- Average Execution 11.33 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM (SELECT * from employee) as per, (SELECT * from payroll) as pay
WHERE per.empid = pay.empid 
AND per.empid IN (SELECT e.empid from employee e,payroll p )
AND pay.salary = (power(2,17) + (((power(2,6) - power(2,2))* power(10,3)) + (power(10,2)-power(2,1))) - power(10,3) * power(2,1))
ORDER BY per.empid, per.lname


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.61 ms
-- Average Execution 192675.77 ms
