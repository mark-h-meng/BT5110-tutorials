/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0248328X                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below*/
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;
/* Average Planning time:0.09 */
/* Average Execution time:2.37 */

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
/* Average Planning time:0.09 */
/* Average Execution time:2.43 */

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN 
	(SELECT per.empid
	 FROM employee per FULL OUTER JOIN payroll pay ON per.empid = pay.empid
	 WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;
/* Average Planning time:0.13 */
/* Average Execution time:11.67 */

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

/*select test('*/

SELECT DISTINCT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay ON per.empid = pay.empid
WHERE (per.empid, per.lname) NOT IN 
	(SELECT DISTINCT per1.empid, per1.lname
	 FROM employee per1 FULL OUTER JOIN payroll pay1 ON per1.empid = pay1.empid
	 WHERE pay1.salary > 189170
	 ORDER BY per1.empid, per1.lname)
AND 
	 (per.empid, per.lname) NOT IN 
	(SELECT DISTINCT per2.empid, per2.lname
	 FROM employee per2 FULL OUTER JOIN payroll pay2 ON per2.empid = pay2.empid
	 WHERE pay2.salary < 189170
	 ORDER BY per2.empid, per2.lname)
AND 
	 (per.empid, per.lname) NOT IN 
	(SELECT DISTINCT per3.empid, per3.lname
	 FROM employee per3 FULL OUTER JOIN payroll pay3 ON per3.empid = pay3.empid
	 WHERE pay3.salary IS NULL
	 ORDER BY per3.empid, per3.lname)
ORDER BY per.empid, per.lname;

/*',20);*/

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.36> ms
-- Average Execution <38.23> ms
