/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0237338Y                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid = pay.empid
ORDER BY per.empid, per.lname;

-- Average Planning <0.05> ms
-- Average Execution <2.28> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid FROM payroll 
	  WHERE salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Average Planning <0.05> ms
-- Average Execution <2.13> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid 
					   FROM payroll pay
					   WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Average Planning <0.03> ms
-- Average Execution <3.61> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   FROM payroll pay
				   WHERE pay.empid IN (SELECT pay1.empid
										FROM payroll pay1
										WHERE pay1.salary NOT IN (SELECT pay1.salary
															  FROM payroll pay2
															  WHERE pay2.salary <> 189170 AND pay1.salary = pay2.salary
															  GROUP BY pay2.salary
															  ORDER BY pay2.salary					
																) 
					GROUP BY pay1.empid
					ORDER BY pay1.empid) AND pay.empid = per.empid
)
GROUP BY per.empid, per.lname
ORDER BY per.empid, per.lname;

-- Average Planning <0.09> ms
-- Average Execution <9073.31> ms

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
