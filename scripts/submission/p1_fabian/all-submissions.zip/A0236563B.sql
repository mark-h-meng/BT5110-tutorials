/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0236563B                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid , per. lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

-- "Average Planning Time : 0.10ms , Average Execution Time : 3.99ms "

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary from payroll pay) AS temp
WHERE per.empid = temp.empid and temp.salary = 189170
ORDER BY per.empid, per.lname;

-- "Average Planning Time : 0.10ms , Average Execution Time : 4.04ms "

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT emp.empid from employee emp, payroll pay where emp.empid = pay.empid and pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- "Average Planning Time : 0.17ms , Average Execution Time : 17.88ms "

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per FULL OUTER JOIN payroll pay 
ON per.empid = pay.empid 
WHERE (SELECT count(*)
FROM payroll pay WHERE pay.empid = per.empid AND pay.salary = 189170) > 0
ORDER BY per.empid, per.lname;

-- "Average Planning Time : 0.18ms , Average Execution Time : 11299.89ms "


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
