/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0247459N                            */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
 /*   Average planning and execution times over 100 executions   */
 /*              Planning time      |    Execution time     */
 /* 100 times         0.17ms        |        5.45ms         */
 /* 1000 times        0.17ms        |        5.59ms         */
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

 /*   Average planning and execution times over 100 executions   */
 /*               Planning time     |    Execution time     */
 /* 100 times         0.18ms        |        5.23ms         */
 /* 1000 times        0.19ms        |        5.39ms         */
/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

 /*   Average planning and execution times over 100 and 1000 executions   */
 /*               Planning time     |    Execution time     */
 /* 100 times         0.18ms        |        5.57ms         */
 /* 1000 times        0.17ms        |        5.46ms         */
/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;

 /*   Average planning and execution times over 100 executions   */
 /*        Planning time            |    Execution time      */
 /* 100 times         0.11ms        |        11.40ms         */
 /* 1000 times        0.12ms        |        11.83ms          */
 
/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
/* The following 2 queries both find the other 9993 records and then filter 
from the employee instance to find the correct 7 records. It adds one time 
scan on the table according to Explain. And I think nesting more queries 
are not interesting although it can improve the time.
   To keep as much as records possible, I use != instead of = first.
   The execution time fluctuates obviously in ±5ms, I try to choose an average
   one to report.
*/
 
SELECT per2.empid, per2.lname
FROM employee per2
WHERE per2.empid NOT IN
(SELECT per1.empid
FROM employee per1 
WHERE per1.empid IN (SELECT pay.empid FROM payroll pay WHERE pay.salary != 189170))
ORDER BY per2.empid, per2.lname;

-- Indicate the average measured time for 20 executions for the query.
-- Average Planning 0.21 ms
-- Average Execution 21.05 ms

SELECT per2.empid, per2.lname
FROM employee per2
WHERE per2.empid NOT IN
(SELECT temp.empid
FROM (SELECT pay.empid,pay.salary FROM payroll pay WHERE pay.salary != 189170) as temp
LEFT JOIN employee per1    
ON per1.empid = temp.empid)
ORDER BY per2.empid, per2.lname;

-- Indicate the average measured time for 20 executions for the query.
-- Average Planning 0.23 ms
-- Average Execution 20.81 ms
