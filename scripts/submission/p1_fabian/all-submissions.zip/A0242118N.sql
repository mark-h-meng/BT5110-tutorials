/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0242118N                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.09 ms
-- Average Execution 2.26 ms
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid = pay.empid AND pay.salary = 189170
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * from payroll) AS temp
WHERE per.empid = temp.empid and temp.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.10 ms
-- Average Execution 2.63 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT per.empid 
	 FROM employee per, payroll pay
	 WHERE per.empid = pay.empid
	 AND pay.salary != 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.13 ms
-- Average Execution 11.20 ms

/******************************************************************************/
/*            Average Planning (ms)    Average Execution (ms)                 */
/* 2.a               0.09                      2.26                           */
/* 2.b               0.10                      2.63                           */
/* 2.c               0.13                     11.20                           */
/******************************************************************************/


/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
(SELECT temp.empid, temp.lname
FROM (SELECT per.empid AS empid, per.lname,
	        pay.empid AS payid, pay.salary
	  FROM employee per, 
	      (SELECT * FROM payroll pay) AS pay
	  WHERE per.empid=pay.empid) as temp
WHERE temp.salary NOT IN (SELECT pay.salary 
	 FROM employee per, payroll pay
	 WHERE per.empid = pay.empid
	 AND pay.salary != 189170) 
LIMIT 1)
UNION
(SELECT temp.empid, temp.lname
FROM (SELECT per.empid AS empid, per.lname,
	        pay.empid AS payid, pay.salary
	  FROM employee per, 
	      (SELECT * FROM payroll pay) AS pay
	  WHERE per.empid=pay.empid) as temp
WHERE temp.salary NOT IN (SELECT pay.salary 
	 FROM employee per, payroll pay
	 WHERE per.empid = pay.empid
	 AND pay.salary != 189170) 
LIMIT 2)
UNION
SELECT temp.empid, temp.lname
FROM (SELECT per.empid AS empid, per.lname,
	        pay.empid AS payid, pay.salary
	  FROM employee per, 
	      (SELECT * FROM payroll pay) AS pay
	  WHERE per.empid=pay.empid) as temp
WHERE temp.salary NOT IN (SELECT pay.salary 
	 FROM employee per, payroll pay
	 WHERE per.empid = pay.empid
	 AND pay.salary != 189170) 
ORDER BY empid, lname; 

-- Average Planning 0.42 ms
-- Average Execution 28.97 ms


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
