/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0248150L                            */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IN (SELECT per.empid FROM payroll pay LEFT JOIN employee per ON per.empid = pay.empid)
ORDER BY per.empid, per.lname;
-- Average Planning 0.21 ms
-- Average Execution 16.81 ms


/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT AVG(salary) FROM payroll as temp1) AS temp
WHERE (per.empid IN (SELECT per.empid FROM payroll pay RIGHT JOIN employee per ON per.empid = pay.empid))
OR (per.empid NOT IN (SELECT per.empid FROM payroll pay RIGHT JOIN employee per ON per.empid = pay.empid))
ORDER BY per.empid, per.lname;
-- Average Planning 0.19 ms
-- Average Execution 14.75 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM employee WHERE empid NOT IN (SELECT empid FROM employee))
ORDER BY per.empid, per.lname;
-- Average Planning 0.07 ms
-- Average Execution 10.31 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, 
(
  SELECT SUM(temp1.salary) AS sum_salary FROM (
    SELECT per.empid, pay.salary FROM payroll pay FULL OUTER JOIN employee per ON per.empid = pay.empid
  ) AS temp1
) AS temp2
WHERE temp2.sum_salary NOT IN(SELECT p.salary FROM payroll p, employee e where 1=1)
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.15 ms
-- Average Execution 33066.60 ms
