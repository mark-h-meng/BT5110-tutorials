/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232487Y                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/* Average Planning 0.09 ms                                                   */
/* Average Execution 2.60 ms                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary IS NOT NULL and per.empid IS NOT NULL
ORDER BY per.empid, per.lname;


/******************************************************************************/
/* Answer Question 2.b below                                                  */
/* Average Planning 0.08 ms                                                   */
/* Average Execution 2.47 ms                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * from payroll) AS temp
WHERE per.empid = temp.empid and temp.salary = 189170
ORDER BY per.empid, per.lname;


/******************************************************************************/
/* Answer Question 2.c below                                                  */
/* Average Planning 0.07 ms                                                   */
/* Average Execution 5.38 ms                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT DISTINCT emp.empid, emp.lname
FROM employee emp
WHERE emp.empid NOT IN(
	SELECT DISTINCT pay.empid
	FROM employee per, payroll pay
	WHERE per.empid <> pay.empid AND pay.salary <> 189170)
ORDER BY emp.empid, emp.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.13 ms
-- Average Execution 60173.35 ms
