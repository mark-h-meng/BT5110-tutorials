/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228582X                              */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT null AND pay.salary IS NOT null 
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT null AND pay.salary IS NOT null 
ORDER BY per.empid, per.lname;', 1000);


-- Average Planning 0.14 ms
-- Average Execution 5.03 ms
/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Average Planning 0.13 ms
-- Average Execution 4.61 ms
/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll AS pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.08 ms
-- Average Execution 10.40 ms
/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/





 SELECT per.empid, per.lname
FROM employee per
WHERE per.lname IN (Select emp.lname from employee emp where emp.empid in(
select pay.empid from payroll as pay where per.empid = pay.empid and pay.empid not in (
select p2.empid from payroll as p2 where p2.salary <189170) and pay.empid not in (select p3.empid 
																				 from payroll as p3 where p3.salary >189170))  )
order by per.empid, per.lname;

 
-- Average Planning 0.17 ms
-- Average Execution 54174.42 ms

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
