/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0248352A                               */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, payroll pay
WHERE per.empid = pay.empid
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
-- Average Planning 0.12 ms
-- Average Execution 4.55 ms

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL
ORDER BY per.empid, per.lname;
-- Average Planning 0.12 ms
-- Average Execution 4.69 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary FROM payroll pay) AS temp
WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;
-- Average Planning 0.12 ms
-- Average Execution 4.43 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;
-- Average Planning 0.06 ms
-- Average Execution 9.27 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT joined.empid, joined.lname
FROM
(
    SELECT per1.empid, per1.lname, pay1.salary FROM employee per1, payroll pay1
    ORDER BY per1.empid, per1.lname
) AS joined
WHERE joined.empid NOT IN
(
    SELECT pay.empid FROM payroll pay WHERE pay.salary IN (SELECT salary FROM payroll WHERE pay.salary != 189170)
);
-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.14 ms
-- Average Execution 760182.61 ms

-- Thought Process:
-- The result in Question 2 shows that 2.c has the longest execution time.
-- After analyzing it, the most time consuming step is scanning the employee table which caused by NOT IN filter.
-- Therefore, the rough idea is to introduce more IN with larger set to filter.
-- Also, currently the ORDER BY only sort 5 rows, it is possible that we sort at an earlier stage to slow the query down.

-- Step 1: Add one more IN
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN
(
    SELECT pay.empid FROM payroll pay WHERE pay.salary IN (SELECT salary FROM payroll WHERE pay.salary != 189170)
) ORDER BY per.empid, per.lname;
-- "Sort  (cost=945812.69..945825.19 rows=5000 width=26) (actual time=3386.820..3386.822 rows=5 loops=1)"
-- "  Sort Key: per.empid, per.lname"
-- "  Sort Method: quicksort  Memory: 25kB"
-- "  ->  Seq Scan on employee per  (cost=945226.50..945505.50 rows=5000 width=26) (actual time=3382.359..3386.803 rows=5 loops=1)"
-- "        Filter: (NOT (hashed SubPlan 2))"
-- "        Rows Removed by Filter: 9995"
-- "        SubPlan 2"
-- "          ->  Seq Scan on payroll pay  (cost=0.00..945214.00 rows=5000 width=10) (actual time=0.013..3373.245 rows=9995 loops=1)"
-- "                Filter: (SubPlan 1)"
-- "                Rows Removed by Filter: 5"
-- "                SubPlan 1"
-- "                  ->  Result  (cost=0.00..164.00 rows=10000 width=4) (actual time=0.002..0.251 rows=897 loops=10000)"
-- "                        One-Time Filter: (pay.salary <> 189170)"
-- "                        ->  Seq Scan on payroll  (cost=0.00..164.00 rows=10000 width=4) (actual time=0.002..0.095 rows=898 loops=9995)"
-- "Planning Time: 0.105 ms"
-- "Execution Time: 3386.865 ms"

-- Step 2: Apply ORDER BY on a larger CROSS JOINED table
SELECT joined.empid, joined.lname
FROM
(
    SELECT per1.empid, per1.lname, pay1.salary FROM employee per1, payroll pay1
    ORDER BY per1.empid, per1.lname
) AS joined
WHERE joined.empid NOT IN
(
    SELECT pay.empid FROM payroll pay WHERE pay.salary IN (SELECT salary FROM payroll WHERE pay.salary != 189170)
);
-- "Unique  (cost=22661118.88..24411118.88 rows=50000000 width=26) (actual time=564423.736..745375.635 rows=5 loops=1)"
-- "  ->  Subquery Scan on joined  (cost=22661118.88..24161118.88 rows=50000000 width=26) (actual time=564423.732..745365.164 rows=50000 loops=1)"
-- "        Filter: (NOT (hashed SubPlan 2))"
-- "        Rows Removed by Filter: 99950000"
-- "        ->  Sort  (cost=21715892.38..21965892.38 rows=100000000 width=30) (actual time=550767.040..695933.087 rows=100000000 loops=1)"
-- "              Sort Key: per1.empid, per1.lname"
-- "              Sort Method: external merge  Disk: 3522576kB"
-- "              ->  Nested Loop  (cost=0.00..1250443.00 rows=100000000 width=30) (actual time=0.017..22051.290 rows=100000000 loops=1)"
-- "                    ->  Seq Scan on employee per1  (cost=0.00..254.00 rows=10000 width=26) (actual time=0.007..7.408 rows=10000 loops=1)"
-- "                    ->  Materialize  (cost=0.00..214.00 rows=10000 width=0) (actual time=0.000..0.795 rows=10000 loops=10000)"
-- "                          ->  Seq Scan on payroll pay1  (cost=0.00..164.00 rows=10000 width=0) (actual time=0.005..1.542 rows=10000 loops=1)"
-- "        SubPlan 2"
-- "          ->  Seq Scan on payroll pay  (cost=0.00..945214.00 rows=5000 width=10) (actual time=0.022..3387.474 rows=9995 loops=1)"
-- "                Filter: (SubPlan 1)"
-- "                Rows Removed by Filter: 5"
-- "                SubPlan 1"
-- "                  ->  Result  (cost=0.00..164.00 rows=10000 width=4) (actual time=0.002..0.251 rows=897 loops=10000)"
-- "                        One-Time Filter: (pay.salary <> 189170)"
-- "                        ->  Seq Scan on payroll  (cost=0.00..164.00 rows=10000 width=4) (actual time=0.002..0.095 rows=898 loops=9995)"
-- "Planning Time: 0.151 ms"
-- "Execution Time: 745631.375 ms"
