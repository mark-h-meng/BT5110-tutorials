/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0248357U                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;
-- Average planning time 0.15ms, average execution time 3.88ms               

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per, (SELECT empid FROM payroll pay WHERE pay.salary = 189170) AS temp WHERE temp.empid = per.empid
ORDER BY per.empid , per.lname;
-- Average planning time 0.13ms, average execution time 3.24ms               

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary != 189170)
ORDER BY per.empid , per.lname;
-- Average planning time 0.06ms, average execution time 6.99ms   


/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
 SELECT per.empid, per.lname
 FROM employee per 
 WHERE per.empid NOT IN 
 	(SELECT empid FROM payroll WHERE (||/ salary ^ 3.0) != @(|/ 35785288900)
  	 OR bonus > 0
 	 OR bonus < 0
     OR per.address !~* '^[0-9]{3}'
 	 OR LEFT(per.city, position(' ' in per.city) - 1) ~* 'RED%'
  	 OR RIGHT(per.city, position(' ' in per.city) - 1) ~* '%s%'
  	 OR RIGHT(per.zip, position('4' in per.city) - 1) > '66'
	)
ORDER BY per.empid , per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.13 ms
-- Average Execution 58722.94 ms

