/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232299X                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Tabulate the average planning and execution times over 100 executions:
-- Planning Time: 0.042 ms
-- Execution Time: 1149.183 ms
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.salary IS NOT NULL
ORDER BY per.empid, per.lname;

-- Tabulate the average planning and execution times over 100 executions:
-- Planning Time: 0.023 ms
-- Execution Time: 1159.783 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (
    SELECT pay.empid
    FROM payroll pay
    WHERE pay.salary = 189170
) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Tabulate the average planning and execution times over 100 executions:
-- Planning Time: 0.025 ms
-- Execution Time: 1159.297 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (
    SELECT pay.empid 
    FROM payroll pay
    WHERE pay.salary <> 189170
)
ORDER BY per.empid, per.lname;

-- Tabulate the average planning and execution times over 100 executions:
-- Planning Time: 0.034 ms
-- Execution Time: 2642.567 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
select empid, lname from (
SELECT *
FROM employee per FULL OUTER JOIN(
    SELECT pay1.empid as pid1
    FROM payroll pay1
    WHERE pay1.empid NOT IN(
        select empid
        from 
        (
        SELECT *
        FROM employee per1
        WHERE per1.empid IN(
        SELECT pay2.empid 
        FROM payroll pay2
        WHERE pay2.empid = per1.empid AND pay2.salary > 189170
        )
        UNION 
        SELECT *
        FROM employee per2
        WHERE per2.empid IN(
        SELECT pay3.empid 
        FROM payroll pay3
        WHERE pay3.empid = per2.empid AND pay3.salary < 189170
        )
        ) as temp1
    )
) temp 
ON per.empid = temp.pid1
ORDER BY per.empid, per.lname
) temp2
where temp2.pid1 is not null

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Planning Time: 0.036 ms
-- Execution Time: 128686.153 ms
