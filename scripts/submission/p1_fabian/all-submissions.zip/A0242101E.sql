/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0242101E                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/

/* AP: 0.04ms  AE: 11.20ms */
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE TRUE
ORDER BY per.empid, per.lname;

/* AP: 0.04ms	AE: 11.11ms */
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
		ON pay.salary = 189170 AND per.empid = pay.empid
WHERE TRUE
ORDER BY per.empid, per.lname;

/* AP: 0.04ms	AE: 11.08ms */
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
		ON pay.salary = 189170 AND per.empid = pay.empid
ORDER BY per.empid, per.lname;

/* AP: 0.04ms	AE: 11.16ms */
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
/* AP: 0.02ms	AE: 3.65ms */
SELECT per.empid, per.lname
FROM employee per, (SELECT TRUE) AS temp
WHERE TRUE
ORDER BY per.empid, per.lname;

/* AP: 0.01ms	AE: 3.62ms */
SELECT per.empid, per.lname
FROM employee per
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
/* AP: 0.03ms	AE: 5.43ms */
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT 'TRUE')
ORDER BY per.empid, per.lname;

/* AP: 0.01ms	AE: 3.62ms */
SELECT per.empid, per.lname
FROM employee per
WHERE TRUE
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

/* AP: 0.07ms	AE: 2.86ms */
SELECT per.empid, per.lname
FROM employee per , payroll pay
WHERE per.empid = pay.empid
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

/* AP: 0.14ms	AE: 39.50ms */
SELECT empid, lname FROM (
SELECT per.empid, per.lname, per.fname, per.address, per.city, per.state, per.zip,
pay.salary, pay.bonus
FROM (SELECT * FROM employee ORDER BY fname, lname) per, (SELECT * FROM payroll ORDER BY salary) pay 
WHERE per.empid = pay.empid
AND pay.bonus != -1
AND pay.salary = 189170
AND per.lname NOT IN (SELECT 'TRUE')
AND per.fname NOT IN (SELECT 'TRUE')
AND per.city NOT IN (SELECT 'TRUE')
AND per.state NOT IN (SELECT 'TRUE')
AND per.zip NOT IN (SELECT 'TRUE')
AND pay.salary NOT IN (SELECT -1)
AND pay.bonus NOT IN (SELECT -1)
ORDER BY per.empid, per.lname) tempTable;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
