/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232478Y                              */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary is NOT NULL and per.empid is NOT NULL
ORDER BY per.empid , per.lname;

-- Average Planning Time : 0.07ms
-- Average Running Time : 4.47 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per, (SELECT * from payroll where salary = 189170) AS temp 
WHERE per.empid = temp.empid
ORDER BY per.empid , per.lname;

-- Average Planning Time : 0.07 ms
-- Average Running Time : 4.09 ms


/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per
WHERE per.empid NOT IN 
(SELECT emp1.empid from employee emp1, payroll p1
where emp1.empid = p1.empid and p1.salary <> 189170)
ORDER BY per.empid , per.lname;

-- Average Planning Time : 0.10 ms
-- Average Execution Time : 16.35 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, payroll pl
WHERE per.empid =
(SELECT per1.empid from employee per1, payroll pl1
WHERE per1.empid = pl1.empid and per.empid = per1.empid and pl1.salary =
( SELECT pl2.salary from employee per2, payroll pl2
 WHERE per2.empid = pl2.empid and per1.empid = per2.empid and pl2.salary = 189170 
)
) GROUP BY per.empid , per.lname


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.19 ms
-- Average Execution 72590.52 ms
