/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0174092E                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;
/*** planning time: 0.11; exe time: 2.99 ***/

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
/*** planning time: 0.09; exe time: 2.60 ***/

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;
/*** planning time: 0.09; exe time: 6.76 ***/

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
 SELECT temp.per_empid AS empid, temp.per_lname AS lname FROM
(
(SELECT per.empid AS per_empid, per.lname AS per_lname, pay.empid AS pay_empid 
FROM employee AS per, payroll AS pay)
EXCEPT
(SELECT per.empid AS per_empid, per.lname AS per_lname, pay.empid AS pay_empid 
FROM employee AS per, payroll AS pay 
 WHERE per.empid != pay.empid OR pay.salary != 189170)
) AS temp

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 1.46 ms
-- Average Execution 834334.52 ms
