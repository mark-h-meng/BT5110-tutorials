/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0199476x                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid = pay.empid 
ORDER BY per.empid, per.lname;
-- 0.09:1.99

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary FROM payroll pay) AS temp
WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;
-- 0.08:2.00

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary != 189170)
ORDER BY per.empid, per.lname;
-- 0.06:4.86

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT DISTINCT per.empid, per.lname
FROM payroll pay, employee per
WHERE per.empid NOT IN (SELECT DISTINCT empid 
	FROM payroll 
	WHERE salary - 1!= 189169
	GROUP BY empid 
	ORDER BY empid) 
GROUP BY per.empid, per.lname
ORDER BY per.empid, per.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- 0.17 ms
-- 48.55 ms
