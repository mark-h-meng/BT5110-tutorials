/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0237343H                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per . empid is not null and pay.salary is not null 
ORDER BY per.empid, per.lname;

-- average planning and execution times "0.07 : 2.18"

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per . empid , per . lname
FROM employee per , ( SELECT pay.empid from payroll pay where pay.salary = 189170 ) AS temp
WHERE per.empid = temp.empid
ORDER BY per . empid , per . lname ;

-- average planning and execution times "0.09 : 2.13"

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid from payroll pay where pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- average planning and execution times "0.06 : 4.36"

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
select per2.empid, per2.lname
from employee per2
where per2.empid not in 
(select per.empid
from employee per, payroll pay
group by per.empid,pay.empid,pay.salary
having per.empid = pay.empid and pay.salary in (select pay2.salary from payroll pay2 where pay2.salary <> 189170)) 
order by per2.empid,per2.lname

-- average planning and execution times "0.20 : 16.58"
-- if we set the join method as nested loop the time will be dramatically longger but not sure if it is allowed to change this setting



-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
