/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0114402B                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid FROM payroll WHERE salary = 189170) AS temp
WHERE per.empid = temp.empid 
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary <> 189170)
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT DISTINCT empid, lname
FROM (
    SELECT DISTINCT per.empid AS empid, lname, fname, address, city, state, zip, bonus, salary
    FROM (SELECT DISTINCT * FROM employee ORDER BY empid, lname, fname, address, city, state, zip) per
    FULL OUTER JOIN (SELECT DISTINCT * FROM payroll ORDER BY empid, bonus, salary) pay 
    ON per.empid = pay.empid 
    WHERE 
        per.empid IN (SELECT DISTINCT empid FROM employee ORDER BY empid DESC)
        AND per.lname IN (SELECT DISTINCT lname FROM employee ORDER BY lname DESC)
        AND per.fname IN (SELECT DISTINCT fname FROM employee ORDER BY fname DESC)
        AND per.address IN (SELECT DISTINCT address FROM employee ORDER BY address DESC)
        AND per.city IN (SELECT DISTINCT city FROM employee ORDER BY city DESC)
        AND per.state IN (SELECT DISTINCT state FROM employee ORDER BY state DESC)
        AND per.zip IN (SELECT DISTINCT zip FROM employee ORDER BY zip DESC)
        AND pay.empid IN (SELECT DISTINCT empid FROM payroll ORDER BY empid DESC)
        AND pay.bonus IN (SELECT DISTINCT bonus FROM payroll ORDER BY bonus DESC)
        AND pay.salary IN (SELECT DISTINCT salary FROM payroll ORDER BY salary DESC)
) combined
WHERE
    (empid, salary) NOT IN (
        (SELECT DISTINCT empid, AVG(salary) AS salary FROM 
            (
            SELECT DISTINCT empid, salary 
            FROM (SELECT * FROM payroll ORDER BY salary, bonus, empid) pay
            WHERE 
                empid IN (SELECT DISTINCT empid FROM payroll ORDER BY empid DESC)
                AND bonus IN (SELECT DISTINCT bonus FROM payroll ORDER BY bonus DESC)
                AND salary IN (SELECT DISTINCT salary FROM payroll ORDER BY salary DESC)
            ORDER BY empid, salary
            ) tmp
        GROUP BY empid
        HAVING AVG(salary) < 189170
        ORDER BY empid DESC)        
        UNION 
        (SELECT DISTINCT empid, AVG(salary) AS salary FROM 
            (
            SELECT DISTINCT empid, salary 
            FROM payroll 
            WHERE 
                empid IN (SELECT DISTINCT empid FROM payroll ORDER BY empid DESC)
                AND bonus IN (SELECT DISTINCT bonus FROM payroll ORDER BY bonus DESC)
                AND salary IN (SELECT DISTINCT salary FROM payroll ORDER BY salary DESC)
            ORDER BY empid, salary
            ) tmp
        GROUP BY empid
        HAVING AVG(salary) > 189170
        ORDER BY empid DESC) 
        )
ORDER BY empid, lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning Time: 2.57ms
-- Average Execution Time: 910.70ms
