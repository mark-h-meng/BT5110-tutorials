/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0248359N                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;
-- Average Planning 0.02 ms
-- Average Execution 1.03 ms


/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll) AS temp
WHERE temp.empid = per.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;
-- Average Planning 0.02 ms
-- Average Execution 1.03 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary!=189170)
ORDER BY per.empid, per.lname;
-- Average Planning 0.01 ms
-- Average Execution 2.48 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
 SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll po on per.empid = po.empid
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary!=189170) AND po.empid
NOT IN (SELECT empid FROM payroll WHERE salary!=189170)
UNION
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll po on per.empid = po.empid
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary!=189170) AND po.empid
NOT IN (SELECT empid FROM payroll WHERE salary!=189170)
ORDER BY empid;
 

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.09 ms
-- Average Execution 15.02 ms
