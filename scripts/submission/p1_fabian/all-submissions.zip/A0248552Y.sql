/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0xxxxxxx                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below
   Average Planing 0.12 ms : Average Execution 2.83 ms                        */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below 
   Average Planing 0.12 ms : Average Execution 2.61 ms                        */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT salary,empid from payroll) AS temp
WHERE temp.salary = 189170 and temp.empid=per.empid
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below 
   Average Planing 0.11 ms : Average Execution 7.05 ms                        */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid from payroll pay where pay.salary <> 189170)
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below 
   Average Planing 0.04ms : Average Execution 34001.02 ms                       */
/******************************************************************************/
CREATE OR REPLACE FUNCTION get_name() RETURNS TABLE (
    empid character
  , lname character
  ) AS
$BODY$
DECLARE
	pay RECORD;
BEGIN
    FOR pay IN
        SELECT * FROM payroll
    LOOP
        RETURN QUERY 
		SELECT per.empid, per.lname 
		FROM employee per 
		WHERE per.empid NOT IN(
			SELECT tmp.empid FROM employee tmp 
			WHERE tmp.empid <> pay.empid ) 
		AND pay.empid NOT IN (
			SELECT tmp.empid FROM payroll tmp WHERE salary <> 189170
		);
    END LOOP;
    RETURN;
END
$BODY$
LANGUAGE plpgsql;

SELECT * FROM get_name() ORDER BY empid, lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.04 ms
-- Average Execution 34001.02 ms
