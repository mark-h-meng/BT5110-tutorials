/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0236154J                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll) AS temp
WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM (SELECT * FROM employee 
	WHERE empid like '%_____%' AND lname like '_______________'
	AND fname like '____________' AND address like '%500 ORACLE PARKWAY%'
	AND city like '%REDWOOD SHORES%' AND state like '%CA%' AND zip like '%94065%' 
	GROUP BY empid, lname, fname, address, city, state, zip
	HAVING COUNT(empid) >= 1 AND COUNT(lname) >= 1 AND COUNT(fname) >= 1 
	AND COUNT(address) >= 1 AND COUNT(city) >= 1 AND COUNT(state) >= 1 AND COUNT(zip) >= 1
	ORDER BY empid, lname, fname, address, city, state, zip) as per
WHERE per.empid NOT IN 
	(SELECT pay.empid 
	FROM payroll pay 
	WHERE CAST(pay.salary as varchar(10)) not like CAST(189170 as varchar(10))
	GROUP BY pay.empid, pay.bonus, pay.salary
	HAVING COUNT(pay.empid) >= 1 AND COUNT(pay.bonus) >= 1 AND COUNT(pay.salary) >= 1
	ORDER BY pay.empid, pay.bonus, pay.salary)
	GROUP BY per.empid, per.lname
	HAVING COUNT(per.empid) >= 1 AND COUNT(per.lname) >= 1
ORDER BY per.empid, per.lname


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.30 ms
-- Average Execution 145.77 ms
