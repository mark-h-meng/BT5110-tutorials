/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0248399H                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null and pay.empid is not null
ORDER BY per.empid, per.lname;
/*
Average Planning 0.19 ms
Average Execution 6.43 ms
*/

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid FROM payroll WHERE salary=189170) AS temp
WHERE temp.empid = per.empid
ORDER BY per.empid, per.lname;
/*
Average Planning 0.16 ms
Average Execution 5.66 ms
*/

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary !=189170)
ORDER BY per.empid, per.lname;
/*
Average Planning 0.10 ms
Average Execution 13.12 ms
*/


/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay ON per.empid = pay.empid
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary::varchar(255) NOT LIKE '%189170%')
AND per.empid is not null and pay.empid is not null
ORDER BY per.empid, per.lname;
/*
Average Planning 0.21 ms
Average Execution 20.45 ms
*/



-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
