/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0248398J                          */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below
average planning time: 0.11ms
average execution time: 2.24ms                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid = pay.empid
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below
average planning time: 0.11ms
average execution time: 2.42ms                                                       */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid,salary from payroll) AS temp
WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below
average planning time: 0.11ms
average execution time: 8.33ms                                                   */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll where payroll.salary != 189170)
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per,payroll pay
WHERE per.empid NOT IN (SELECT empid FROM payroll where empid != per.empid OR payroll.salary != 189170) AND pay.empid NOT IN (SELECT empid FROM payroll where empid != per.empid OR payroll.salary != 189170)
ORDER BY per.empid, per.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.16> ms
-- Average Execution <169223.98> ms
