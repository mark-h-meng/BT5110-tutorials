/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0237333J                               */
/******************************************************************************/

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.empid IS NOT NULL AND per.empid IS NOT NULL 
ORDER BY per.empid, per.lname;

-- Average Planning 0.07 ms
-- Average Execution 2.23 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll) AS temp
WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.07 ms
-- Average Execution 1.93 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid from payroll pay WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.05 ms
-- Average Execution 4.55 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per full outer join payroll pay 
ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid NOT IN (SELECT pay.empid from payroll pay WHERE pay.empid NOT IN 
			(SELECT pay.empid FROM payroll pay WHERE pay.salary =189170))
ORDER BY per.empid, per.lname

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.10 ms
-- Average Execution 10.96 ms