/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228554Y                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
ON per.empid = pay.empid AND pay.salary = 189170
WHERE TRUE
ORDER BY per.empid, per.lname;

SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT TRUE) AS temp
WHERE TRUE
ORDER BY per.empid, per.lname;

SELECT per.empid , per.lname
FROM employee per, (SELECT pay.empid FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid , per.lname;

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT 'TRUE')
ORDER BY per.empid, per.lname;

SELECT per.empid , per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary != 189170)
ORDER BY per.empid , per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
((SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary != 189170
ORDER BY per.empid , per.lname))
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130000
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130001
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130002
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130003
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130004
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130005
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130006
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130007
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130008
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130009
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130010
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130011
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130012
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130013
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130014
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130015
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130016
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130017
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130018
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130019
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130020
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130021
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130022
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130023
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130024
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130025
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130026
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130027
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130028
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130029
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130030
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130031
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130032
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130033
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130034
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130035
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130036
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130037
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130038
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130039
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130040
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130041
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130042
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130043
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130044
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130045
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130046
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130047
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130048
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130049
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130050
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130051
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130052
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130053
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130054
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130055
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130056
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130057
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130058
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130059
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130060
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130061
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130062
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130063
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130064
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130065
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130066
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130067
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130068
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130069
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130070
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130071
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130072
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130073
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130074
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130075
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130076
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130077
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130078
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130079
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130080
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130081
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130082
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130083
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130084
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130085
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130086
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130087
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130088
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130089
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130090
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130091
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130092
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130093
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130094
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130095
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130096
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130097
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130098
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130099
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130100
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130101
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130102
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130103
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130104
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130105
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130106
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130107
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130108
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130109
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130110
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130111
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130112
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130113
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130114
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130115
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130116
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130117
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130118
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130119
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130120
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130121
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130122
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130123
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130124
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130125
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130126
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130127
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130128
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130129
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130130
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130131
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130132
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130133
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130134
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130135
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130136
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130137
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130138
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130139
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130140
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130141
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130142
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130143
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130144
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130145
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130146
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130147
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130148
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130149
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130150
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130151
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130152
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130153
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130154
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130155
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130156
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130157
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130158
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130159
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130160
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130161
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130162
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130163
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130164
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130165
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130166
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130167
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130168
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130169
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130170
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130171
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130172
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130173
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130174
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130175
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130176
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130177
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130178
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130179
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130180
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130181
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130182
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130183
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130184
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130185
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130186
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130187
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130188
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130189
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130190
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130191
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130192
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130193
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130194
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130195
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130196
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130197
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130198
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130199
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130200
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130201
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130202
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130203
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130204
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130205
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130206
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130207
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130208
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130209
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130210
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130211
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130212
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130213
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130214
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130215
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130216
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130217
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130218
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130219
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130220
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130221
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130222
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130223
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130224
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130225
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130226
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130227
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130228
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130229
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130230
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130231
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130232
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130233
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130234
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130235
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130236
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130237
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130238
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130239
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130240
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130241
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130242
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130243
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130244
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130245
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130246
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130247
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130248
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130249
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130250
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130251
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130252
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130253
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130254
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130255
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130256
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130257
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130258
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130259
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130260
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130261
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130262
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130263
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130264
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130265
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130266
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130267
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130268
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130269
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130270
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130271
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130272
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130273
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130274
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130275
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130276
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130277
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130278
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130279
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130280
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130281
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130282
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130283
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130284
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130285
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130286
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130287
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130288
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130289
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130290
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130291
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130292
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130293
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130294
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130295
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130296
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130297
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130298
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130299
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130300
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130301
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130302
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130303
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130304
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130305
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130306
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130307
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130308
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130309
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130310
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130311
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130312
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130313
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130314
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130315
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130316
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130317
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130318
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130319
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130320
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130321
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130322
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130323
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130324
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130325
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130326
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130327
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130328
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130329
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130330
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130331
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130332
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130333
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130334
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130335
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130336
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130337
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130338
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130339
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130340
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130341
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130342
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130343
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130344
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130345
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130346
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130347
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130348
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130349
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130350
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130351
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130352
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130353
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130354
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130355
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130356
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130357
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130358
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130359
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130360
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130361
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130362
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130363
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130364
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130365
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130366
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130367
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130368
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130369
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130370
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130371
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130372
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130373
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130374
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130375
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130376
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130377
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130378
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130379
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130380
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130381
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130382
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130383
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130384
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130385
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130386
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130387
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130388
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130389
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130390
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130391
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130392
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130393
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130394
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130395
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130396
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130397
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130398
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130399
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130400
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130401
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130402
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130403
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130404
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130405
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130406
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130407
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130408
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130409
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130410
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130411
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130412
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130413
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130414
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130415
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130416
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130417
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130418
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130419
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130420
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130421
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130422
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130423
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130424
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130425
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130426
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130427
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130428
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130429
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130430
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130431
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130432
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130433
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130434
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130435
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130436
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130437
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130438
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130439
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130440
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130441
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130442
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130443
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130444
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130445
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130446
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130447
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130448
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130449
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130450
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130451
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130452
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130453
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130454
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130455
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130456
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130457
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130458
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130459
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130460
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130461
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130462
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130463
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130464
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130465
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130466
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130467
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130468
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130469
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130470
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130471
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130472
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130473
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130474
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130475
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130476
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130477
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130478
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130479
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130480
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130481
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130482
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130483
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130484
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130485
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130486
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130487
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130488
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130489
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130490
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130491
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130492
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130493
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130494
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130495
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130496
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130497
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130498
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130499
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130500
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130501
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130502
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130503
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130504
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130505
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130506
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130507
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130508
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130509
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130510
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130511
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130512
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130513
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130514
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130515
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130516
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130517
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130518
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130519
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130520
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130521
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130522
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130523
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130524
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130525
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130526
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130527
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130528
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130529
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130530
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130531
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130532
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130533
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130534
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130535
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130536
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130537
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130538
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130539
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130540
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130541
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130542
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130543
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130544
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130545
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130546
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130547
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130548
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130549
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130550
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130551
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130552
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130553
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130554
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130555
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130556
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130557
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130558
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130559
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130560
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130561
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130562
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130563
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130564
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130565
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130566
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130567
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130568
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130569
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130570
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130571
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130572
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130573
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130574
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130575
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130576
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130577
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130578
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130579
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130580
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130581
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130582
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130583
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130584
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130585
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130586
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130587
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130588
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130589
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130590
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130591
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130592
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130593
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130594
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130595
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130596
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130597
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130598
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130599
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130600
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130601
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130602
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130603
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130604
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130605
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130606
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130607
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130608
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130609
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130610
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130611
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130612
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130613
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130614
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130615
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130616
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130617
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130618
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130619
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130620
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130621
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130622
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130623
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130624
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130625
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130626
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130627
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130628
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130629
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130630
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130631
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130632
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130633
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130634
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130635
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130636
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130637
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130638
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130639
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130640
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130641
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130642
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130643
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130644
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130645
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130646
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130647
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130648
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130649
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130650
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130651
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130652
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130653
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130654
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130655
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130656
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130657
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130658
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130659
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130660
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130661
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130662
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130663
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130664
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130665
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130666
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130667
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130668
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130669
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130670
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130671
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130672
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130673
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130674
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130675
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130676
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130677
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130678
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130679
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130680
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130681
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130682
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130683
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130684
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130685
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130686
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130687
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130688
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130689
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130690
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130691
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130692
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130693
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130694
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130695
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130696
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130697
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130698
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130699
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130700
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130701
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130702
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130703
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130704
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130705
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130706
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130707
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130708
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130709
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130710
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130711
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130712
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130713
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130714
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130715
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130716
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130717
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130718
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130719
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130720
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130721
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130722
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130723
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130724
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130725
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130726
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130727
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130728
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130729
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130730
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130731
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130732
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130733
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130734
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130735
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130736
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130737
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130738
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130739
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130740
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130741
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130742
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130743
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130744
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130745
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130746
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130747
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130748
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130749
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130750
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130751
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130752
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130753
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130754
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130755
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130756
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130757
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130758
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130759
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130760
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130761
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130762
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130763
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130764
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130765
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130766
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130767
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130768
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130769
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130770
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130771
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130772
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130773
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130774
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130775
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130776
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130777
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130778
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130779
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130780
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130781
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130782
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130783
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130784
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130785
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130786
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130787
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130788
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130789
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130790
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130791
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130792
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130793
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130794
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130795
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130796
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130797
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130798
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130799
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130800
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130801
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130802
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130803
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130804
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130805
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130806
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130807
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130808
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130809
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130810
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130811
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130812
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130813
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130814
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130815
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130816
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130817
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130818
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130819
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130820
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130821
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130822
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130823
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130824
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130825
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130826
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130827
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130828
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130829
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130830
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130831
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130832
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130833
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130834
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130835
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130836
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130837
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130838
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130839
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130840
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130841
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130842
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130843
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130844
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130845
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130846
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130847
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130848
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130849
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130850
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130851
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130852
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130853
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130854
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130855
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130856
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130857
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130858
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130859
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130860
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130861
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130862
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130863
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130864
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130865
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130866
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130867
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130868
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130869
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130870
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130871
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130872
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130873
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130874
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130875
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130876
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130877
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130878
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130879
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130880
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130881
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130882
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130883
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130884
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130885
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130886
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130887
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130888
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130889
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130890
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130891
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130892
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130893
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130894
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130895
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130896
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130897
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130898
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130899
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130900
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130901
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130902
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130903
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130904
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130905
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130906
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130907
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130908
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130909
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130910
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130911
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130912
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130913
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130914
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130915
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130916
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130917
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130918
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130919
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130920
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130921
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130922
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130923
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130924
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130925
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130926
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130927
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130928
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130929
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130930
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130931
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130932
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130933
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130934
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130935
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130936
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130937
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130938
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130939
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130940
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130941
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130942
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130943
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130944
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130945
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130946
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130947
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130948
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130949
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130950
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130951
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130952
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130953
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130954
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130955
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130956
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130957
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130958
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130959
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130960
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130961
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130962
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130963
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130964
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130965
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130966
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130967
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130968
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130969
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130970
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130971
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130972
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130973
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130974
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130975
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130976
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130977
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130978
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130979
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130980
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130981
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130982
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130983
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130984
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130985
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130986
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130987
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130988
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130989
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130990
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130991
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130992
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130993
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130994
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130995
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130996
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130997
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130998
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 130999
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131000
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131001
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131002
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131003
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131004
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131005
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131006
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131007
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131008
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131009
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131010
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131011
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131012
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131013
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131014
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131015
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131016
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131017
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131018
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131019
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131020
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131021
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131022
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131023
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131024
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131025
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131026
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131027
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131028
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131029
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131030
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131031
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131032
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131033
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131034
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131035
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131036
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131037
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131038
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131039
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131040
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131041
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131042
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131043
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131044
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131045
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131046
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131047
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131048
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131049
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131050
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131051
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131052
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131053
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131054
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131055
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131056
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131057
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131058
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131059
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131060
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131061
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131062
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131063
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131064
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131065
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131066
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131067
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131068
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131069
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131070
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131071
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131072
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131073
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131074
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131075
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131076
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131077
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131078
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131079
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131080
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131081
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131082
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131083
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131084
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131085
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131086
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131087
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131088
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131089
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131090
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131091
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131092
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131093
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131094
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131095
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131096
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131097
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131098
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131099
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131100
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131101
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131102
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131103
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131104
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131105
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131106
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131107
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131108
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131109
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131110
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131111
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131112
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131113
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131114
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131115
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131116
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131117
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131118
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131119
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131120
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131121
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131122
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131123
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131124
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131125
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131126
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131127
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131128
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131129
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131130
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131131
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131132
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131133
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131134
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131135
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131136
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131137
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131138
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131139
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131140
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131141
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131142
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131143
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131144
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131145
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131146
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131147
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131148
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131149
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131150
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131151
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131152
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131153
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131154
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131155
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131156
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131157
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131158
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131159
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131160
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131161
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131162
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131163
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131164
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131165
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131166
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131167
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131168
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131169
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131170
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131171
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131172
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131173
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131174
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131175
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131176
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131177
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131178
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131179
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131180
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131181
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131182
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131183
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131184
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131185
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131186
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131187
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131188
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131189
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131190
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131191
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131192
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131193
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131194
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131195
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131196
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131197
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131198
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131199
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131200
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131201
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131202
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131203
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131204
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131205
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131206
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131207
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131208
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131209
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131210
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131211
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131212
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131213
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131214
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131215
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131216
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131217
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131218
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131219
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131220
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131221
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131222
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131223
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131224
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131225
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131226
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131227
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131228
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131229
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131230
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131231
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131232
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131233
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131234
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131235
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131236
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131237
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131238
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131239
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131240
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131241
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131242
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131243
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131244
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131245
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131246
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131247
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131248
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131249
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131250
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131251
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131252
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131253
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131254
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131255
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131256
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131257
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131258
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131259
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131260
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131261
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131262
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131263
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131264
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131265
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131266
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131267
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131268
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131269
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131270
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131271
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131272
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131273
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131274
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131275
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131276
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131277
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131278
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131279
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131280
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131281
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131282
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131283
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131284
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131285
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131286
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131287
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131288
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131289
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131290
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131291
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131292
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131293
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131294
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131295
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131296
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131297
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131298
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131299
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131300
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131301
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131302
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131303
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131304
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131305
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131306
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131307
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131308
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131309
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131310
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131311
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131312
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131313
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131314
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131315
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131316
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131317
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131318
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131319
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131320
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131321
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131322
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131323
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131324
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131325
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131326
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131327
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131328
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131329
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131330
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131331
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131332
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131333
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131334
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131335
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131336
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131337
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131338
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131339
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131340
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131341
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131342
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131343
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131344
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131345
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131346
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131347
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131348
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131349
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131350
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131351
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131352
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131353
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131354
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131355
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131356
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131357
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131358
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131359
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131360
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131361
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131362
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131363
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131364
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131365
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131366
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131367
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131368
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131369
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131370
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131371
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131372
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131373
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131374
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131375
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131376
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131377
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131378
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131379
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131380
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131381
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131382
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131383
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131384
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131385
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131386
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131387
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131388
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131389
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131390
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131391
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131392
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131393
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131394
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131395
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131396
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131397
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131398
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131399
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131400
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131401
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131402
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131403
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131404
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131405
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131406
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131407
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131408
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131409
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131410
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131411
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131412
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131413
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131414
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131415
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131416
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131417
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131418
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131419
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131420
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131421
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131422
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131423
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131424
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131425
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131426
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131427
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131428
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131429
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131430
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131431
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131432
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131433
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131434
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131435
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131436
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131437
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131438
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131439
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131440
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131441
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131442
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131443
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131444
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131445
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131446
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131447
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131448
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131449
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131450
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131451
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131452
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131453
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131454
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131455
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131456
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131457
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131458
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131459
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131460
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131461
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131462
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131463
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131464
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131465
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131466
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131467
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131468
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131469
ORDER BY per.empid , per.lname)
EXCEPT
(SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid WHERE pay.salary = 131470
ORDER BY per.empid , per.lname);

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 141.53 ms
-- Average Execution 2259.30 ms
