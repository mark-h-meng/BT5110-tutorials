/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0097088M                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/* Average Planning Time is 0.07ms and Average Execution Time is 3.32ms*/

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

/* Average Planning Time is 0.08ms and Average Execution Time is 3.28ms*/

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

/* Average Planning Time is 0.07ms and Average Execution Time is 3.32ms*/

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT per2.empid 
						FROM employee per2, payroll pay
					    WHERE per2.empid = pay.empid AND pay.salary != 189170)
ORDER BY per.empid, per.lname;

/* Average Planning Time is 0.14ms and Average Execution Time is 18.95ms*/

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per, payroll pay
WHERE per.empid = pay.empid AND per.empid NOT IN (SELECT per2.empid
												 FROM employee per2
												 WHERE pay.empid = per2.empid AND per2.empid NOT IN (SELECT nested.empid 
												  													FROM (SELECT pay2.empid,
																										CASE WHEN pay2.salary < 189170 THEN 0
																										WHEN pay2.salary > 189170 THEN 1
																										ELSE 2
																										END AS boolnum
																										FROM payroll pay2) nested
												  													WHERE nested.boolnum = 2))
ORDER BY per.empid, per.lname;

/* Average Planning Time is 0.22ms and Average Execution Time is 9365.3ms*/

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning is 0.22 ms
-- Average Execution 9365.3 ms
