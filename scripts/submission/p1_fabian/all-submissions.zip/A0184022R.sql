/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0184022R                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- planning: 0.05, execution: 2.76 
SELECT test('SELECT per.empid , per.lname
FROM employee per , payroll pay WHERE per.empid = pay.empid
AND pay.salary = 189170
ORDER BY per.empid , per.lname;', 10000);

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

-- planning: 0.05, execution: 2.76
SELECT test('
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;
', 20);

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- planning: 0.05, execution: 2.79
SELECT test('
SELECT per.empid, per.lname
FROM employee per, (SELECT empid FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
', 20);

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll pay WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;

-- planning: 0.03, execution: 7.10
SELECT test('
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll pay WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;
', 20);

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (
	SELECT empid FROM payroll pay 
	WHERE CAST(pay.salary AS TEXT) NOT LIKE '%189170%' 
	OR CAST(pay.salary AS TEXT) NOT LIKE '%0'
) 
ORDER BY per.empid, per.lname;

SELECT test('
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (
	SELECT empid FROM payroll pay 
	WHERE CAST(pay.salary AS TEXT) NOT LIKE ''%189170%''
	OR CAST(pay.salary AS TEXT) NOT LIKE ''%0''
) 
ORDER BY per.empid, per.lname;
', 20);

-- Not too sure if this is a well known trick, but we can force a full table scan with the LIKE opertator
-- Since the db can only determine matches at runtime by checking ALL salaries! :-)
-- Satistics might not help here!
-- Wildcards at the start and the end for maximum time! (exploit the distribution of salary values)

-- Tested on M1 Macbook Pro

-- Indicate the average measured time for 20 executions for the query.
-- Average Planning 0.04 ms
-- Average Execution 10.18 ms
