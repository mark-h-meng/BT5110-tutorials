/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232294H                             */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, payroll pay
WHERE per.empid = pay.empid
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL;
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per, (
	SELECT empid
	FROM payroll p
	WHERE p.salary = 189170
	) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (
    SELECT pay.empid
    FROM payroll pay
    WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay ON per.empid = pay.empid
WHERE NOT EXISTS(
    SELECT *
    FROM payroll pay
    WHERE NOT EXISTS(
        SELECT *
        FROM payroll pay
        WHERE per.empid = pay.empid
		AND pay.salary = 189170
    )
) AND per.empid IS NOT NULL AND pay.empid IS NOT NULL
ORDER BY per.empid, per.lname;


-- Indicate the average measured time for 20 executions for the query.
-- query1   Average Planning <0.09> ms Average Execution <5.21> ms
-- query2a  Average Planning <0.10> ms Average Execution <4.72> ms
-- query2b  Average Planning <0.10> ms Average Execution <5.10> ms
-- query2c  Average Planning <0.06> ms Average Execution <11.20> ms
-- querySlowest  Average Planning <0.24> ms Average Execution <81.02> ms
