******************************************************************************/
/* Fabian Pascal                                                              */
/* A0248409X    	                           */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/


SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.empid = ANY (SELECT p.empid FROM payroll p WHERE p.salary = 189170)
ORDER BY per, empid, per, lname;

/* Average Planning Time : 0.25ms , Average Execution Time : 10.30 ms */

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/


SELECT per.empid, per.lname
FROM employee per, (SELECT p.empid,p.salary FROM payroll p) AS temp
WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;

/* Average Planning Time : 0.16ms , Average Execution Time : 3.66 ms */

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/


SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

/* Average Planning Time : 0.10ms , Average Execution Time : 8.93 ms */

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per1.empid, per1.lname
FROM employee per1 FULL OUTER JOIN payroll pay1 ON per1.empid = pay1.empid
WHERE pay1.empid = ANY
(	SELECT pay2.empid
	FROM payroll pay2
	WHERE EXISTS (
		SELECT *
	    	FROM payroll pay3
		WHERE pay3.empid = pay2.empid AND NOT EXISTS (
				SELECT * 
				FROM employee per2
		       		 WHERE per2.empid = pay3.empid AND per2.empid = ANY(
					SELECT pay4.empid
					FROM payroll pay4
					WHERE pay4.salary < 189170
				    UNION
				    	SELECT per3.empid
				    	FROM employee per3
				   	WHERE per3.empid = ANY (
						SELECT pay5.empid
						FROM payroll pay5
						WHERE pay5.salary > 189170
					)
				
				) ))
)
ORDER BY per1.empid, per1.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.48> ms
-- Average Execution <37596.65> ms



 
