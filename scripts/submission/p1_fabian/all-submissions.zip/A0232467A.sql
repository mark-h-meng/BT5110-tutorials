/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232467A                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning <0.16> ms
-- Average Execution <4.18> ms

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning <0.17> ms
-- Average Execution <4.09> ms
/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.salary, pay.empid FROM payroll pay) AS temp
WHERE temp.salary = 189170 AND temp.empid = per.empid
ORDER BY per.empid, per.lname;

-- Average Planning <0.15> ms
-- Average Execution <4.16> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN 
(SELECT per2.empid FROM employee per2, payroll pay WHERE per2.empid=pay.empid 
AND pay.salary != 189170)
ORDER BY per.empid, per.lname;

-- Average Planning <0.19> ms
-- Average Execution <21.46> ms


/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid=pay.empid and pay.empid NOT in (
SELECT per2.empid  
FROM employee per2, payroll pay2 
	WHERE per2.empid = pay2.empid AND pay2.empid IN (
	SELECT pay3.empid 
	FROM payroll pay3
	WHERE pay3.salary > 189170 or pay3.salary < 189170
)
GROUP BY per2.empid
ORDER BY per2.empid)
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.46> ms
-- Average Execution <49.68> ms


