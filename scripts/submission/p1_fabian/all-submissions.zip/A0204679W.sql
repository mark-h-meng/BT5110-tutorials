/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0204679W                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/

/*
Unfortunately I am unable to trick the optimizer into creating a different plan.
The planner will almost always try to push the filter condition of salary = 189170 down to
the selection of records from payroll table to reduce the number of records used in the join.
*/
SELECT per.empid, per.lname 
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid = pay.empid 
ORDER BY per.empid, per.lname;

-- 100 runs
-- SELECT test('SELECT per.empid, per.lname 
-- FROM employee per FULL OUTER JOIN payroll pay 
--     ON per.empid = pay.empid AND pay.salary = 189170
-- WHERE per.empid = pay.empid
-- ORDER BY per.empid, per.lname;', 100);
-- Average Planning 0.10 ms
-- Average Execution 2.01 ms

-- 1000 runs
-- SELECT test('SELECT per.empid, per.lname 
-- FROM employee per FULL OUTER JOIN payroll pay 
--     ON per.empid = pay.empid AND pay.salary = 189170
-- WHERE per.empid = pay.empid
-- ORDER BY per.empid, per.lname;', 1000);
-- Average Planning 0.09 ms
-- Average Execution 2.01 ms

/* ------------------------------------------------- Another variant, different WHERE ----------------------------------------------- */
SELECT per.empid, per.lname 
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

-- 100 runs
-- SELECT test('SELECT per.empid, per.lname 
-- FROM employee per FULL OUTER JOIN payroll pay 
--     ON per.empid = pay.empid AND pay.salary = 189170
-- WHERE pay.salary = 189170
-- ORDER BY per.empid, per.lname;', 100);
-- Average Planning 0.10 ms
-- Average Execution 2.01 ms

-- 1000 runs
-- SELECT test('SELECT per.empid, per.lname 
-- FROM employee per FULL OUTER JOIN payroll pay 
--     ON per.empid = pay.empid AND pay.salary = 189170
-- WHERE pay.salary = 189170
-- ORDER BY per.empid, per.lname;', 1000);
-- Average Planning 0.10 ms
-- Average Execution 2.03 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
/* The plan is the same as one from 2.a. The optimizer knows what's up. */
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid
				    FROM payroll pay
				    WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- 100 runs
-- SELECT test('SELECT per.empid, per.lname
-- FROM employee per, (SELECT pay.empid
-- 				    FROM payroll pay
-- 				    WHERE pay.salary = 189170) AS temp
-- WHERE per.empid = temp.empid
-- ORDER BY per.empid, per.lname;', 100);
-- Average Planning 0.11 ms
-- Average Execution 2.07 ms

-- !000 runs
-- SELECT test('SELECT per.empid, per.lname
-- FROM employee per, (SELECT pay.empid
-- 				    FROM payroll pay
-- 				    WHERE pay.salary = 189170) AS temp
-- WHERE per.empid = temp.empid
-- ORDER BY per.empid, per.lname;', 1000);
-- Average Planning 0.11 ms
-- Average Execution 2.14 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
/* 
The correlated subquery causes a significant slowdown. Rather than having a hashed subplan for the nested query, 
it now executes the subquery for every row instead of a lookup on the hashed subplan.
*/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid 
						FROM payroll 
					    WHERE payroll.salary <> 189170 AND payroll.empid = per.empid)
ORDER BY per.empid, per.lname;

-- 100 runs
-- SELECT test('SELECT per.empid, per.lname
-- FROM employee per
-- WHERE per.empid NOT IN (SELECT empid 
-- 						FROM payroll 
-- 					    WHERE payroll.salary <> 189170 AND payroll.empid = per.empid)
-- ORDER BY per.empid, per.lname;', 100);
-- Average Planning 0.08 ms
-- Average Execution 4963.27 ms

-- 1000 runs
-- SELECT test('SELECT per.empid, per.lname
-- FROM employee per
-- WHERE per.empid NOT IN (SELECT empid 
-- 						FROM payroll 
-- 					    WHERE payroll.salary <> 189170 AND payroll.empid = per.empid)
-- ORDER BY per.empid, per.lname;', 1000);
-- Didnt bother waiting for it to finish.


-- OTHER QUERIES TRIED
/* 
Introducing DISTINCT caused the subplan to include an additional aggregate node, presumably to remove duplicate values. This 
seems to cause a bit fo slowdown.
*/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT DISTINCT empid 
						FROM payroll 
					    WHERE payroll.salary <> 189170)
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT DISTINCT empid 
						FROM payroll 
					    WHERE payroll.salary <> 189170)
ORDER BY per.empid, per.lname;', 100);
-- Average Planning 0.09 ms
-- Average Execution 7.40 ms

SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT DISTINCT empid 
						FROM payroll 
					    WHERE payroll.salary <> 189170)
ORDER BY per.empid, per.lname;', 1000);
-- Average Planning 0.10 ms
-- Average Execution 8.23 ms

SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid 
						FROM payroll 
					    WHERE payroll.salary <> 189170)
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid 
						FROM payroll 
					    WHERE payroll.salary <> 189170)
ORDER BY per.empid, per.lname;', 100);
-- Average Planning 0.08 ms
-- Average Execution 4.65 ms

SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid 
						FROM payroll 
					    WHERE payroll.salary <> 189170)
ORDER BY per.empid, per.lname;', 1000);
-- Average Planning 0.08 ms
-- Average Execution 4.59 ms

/******************************************************************************/
/* Answer Question 3 below                                                    */
/******************************************************************************/

-- Have two correlated subqueries to prevent the usage of a hashed subplan for the nested query.
SELECT per.empid, per.lname
FROM employee AS per, payroll AS pay
WHERE per.empid = pay.empid AND per.empid NOT IN (SELECT DISTINCT empid
												  FROM payroll AS p
												  WHERE per.empid = p.empid AND p.empid IN (SELECT e2.empid 
																							FROM payroll AS p2, employee AS e2
																						    WHERE e2.empid = p2.empid 
																							AND p2.salary <> 189170
																						    AND p2.empid = pay.empid))
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee AS per, payroll AS pay
WHERE per.empid = pay.empid AND per.empid NOT IN (SELECT DISTINCT empid
												  FROM payroll AS p
												  WHERE per.empid = p.empid AND p.empid IN (SELECT e2.empid 
																							FROM payroll AS p2, employee AS e2
																						    WHERE e2.empid = p2.empid 
																							AND p2.salary <> 189170
																						    AND p2.empid = pay.empid))
ORDER BY per.empid, per.lname;', 20);
-- Avg\erage Planning 0.19 ms
-- Average Execution 15307.92 ms

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
