/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0236598L                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.salary IS NOT NULL
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 1000 executions for the query.
-- Average Planning 0.05 ms
-- Average Execution 1.48 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary FROM employee NATURAL INNER JOIN payroll WHERE salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 1000 executions for the query.
-- Average Planning 0.11 ms
-- Average Execution 2.25 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM employee NATURAL INNER JOIN payroll WHERE salary <> 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 1000 executions for the query.
-- Average Planning 0.08 ms
-- Average Execution 5.79 ms

/******************************************************************************/
/* Answer Question 3 below                                                    */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (
    SELECT empid FROM (
        (SELECT empid, lname
        FROM employee per NATURAL INNER JOIN (SELECT empid, salary FROM employee NATURAL INNER JOIN payroll ORDER BY empid DESC, lname DESC, fname DESC, address DESC, city DESC, state DESC, zip DESC, bonus DESC, salary DESC) AS temp
        ORDER BY empid DESC, lname DESC, fname DESC, address DESC, city DESC, state DESC, zip DESC, salary DESC)
        EXCEPT
        (SELECT empid, lname
        FROM employee 
        WHERE empid IN (
            SELECT empid 
            FROM employee NATURAL INNER JOIN payroll 
            WHERE salary = 189170
            ORDER BY empid DESC, lname DESC, fname DESC, address DESC, city DESC, state DESC, zip DESC, salary DESC)
        )) AS temp_empid
        ORDER BY empid DESC
    )
ORDER BY PER.empid, per.lname

-- Indicate the average measured time for 20 executions for the query.
-- Average Planning 0.25 ms
-- Average Execution 110.15 ms
