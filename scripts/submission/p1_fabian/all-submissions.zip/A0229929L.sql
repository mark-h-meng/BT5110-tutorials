/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0xxxxxxx                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;
/*
Planning time:0.16 Execution time:8.19 (100 Executions)
*/

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid from payroll pay where pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
/*
Planning time:0.18 Execution time:6.13 (100 Executions)
*/

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid from payroll pay where pay.salary != 189170)
ORDER BY per.empid, per.lname;
/*
Planning time:0.10 Execution time:10.55 (100 Executions)
*/

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid != ALL(SELECT pay.empid from payroll pay where pay.salary not in (SELECT pay.salary from payroll pay where pay.salary = 189170))
ORDER BY per.empid, per.lname;
/*
Planning time:0.10 Execution time:14814.99 (20 Executions)
*/

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
