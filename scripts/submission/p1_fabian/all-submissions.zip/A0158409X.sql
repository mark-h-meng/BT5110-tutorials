/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0158409X                               */
/******************************************************************************/
SELECT per.empid, per.lname  
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning : 0.11 ms 
-- Average Execution: 6.21 ms 
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning : 0.15 ms 
-- Average Execution: 5.04 ms 

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary 
					FROM payroll pay
					WHERE pay.salary = 189170) AS temp 
WHERE per.empid = temp.empid 
ORDER BY per.empid, per.lname;

-- Average Planning : 0.14 ms 
-- Average Execution: 4.69 ms 

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid
						FROM payroll pay
						WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Average Planning:  0.08 ms 
-- Average Execution: 9.28 ms 

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT DISTINCT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay ON per.empid = pay.empid
WHERE 189170 = (SELECT CAST(SUM(pay.salary) / COUNT(*) AS INT)
				FROM payroll pay
				WHERE pay.empid NOT IN (SELECT pay1.empid
										FROM payroll pay1
										WHERE pay1.empid != per.empid
									    ORDER BY pay.empid DESC)
				AND pay.salary NOT IN (SELECT pay.salary
									   FROM payroll pay
									   WHERE pay.salary NOT IN (SELECT pay1.salary
															   FROM payroll pay1
															   WHERE pay.salary NOT IN (SELECT pay2.salary
																						FROM payroll pay2
																						WHERE pay.salary != 189170)
																AND pay.salary IS NOT NULL
																ORDER BY pay.salary ASC)))
ORDER BY per.empid, per.lname;

-- Average Planning: 1.09 ms
-- Average Execution: 89218.05 ms
