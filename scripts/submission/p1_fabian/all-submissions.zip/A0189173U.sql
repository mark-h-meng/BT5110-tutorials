/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0189173U                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
-- 0.05 : 2.75
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
-- 0.09 : 2.96
SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll) AS temp
WHERE per.empid = temp.empid 
AND temp.salary = 189170
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
-- 0.05 : 5.39
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay 
					   WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
-- Average Planning <0.29> ms
-- Average Execution <225449.65> ms

SELECT e1.empid, e1.lname
FROM employee e1, payroll p1
WHERE e1.empid = p1.empid 

EXCEPT

SELECT e1.empid, e1.lname
FROM employee e1, payroll p1
WHERE (p1.empid, e1.lname) IN 
(SELECT empid, lname FROM 
 (SELECT empid, lname, 
  CASE WHEN indexed = -1 THEN 0
  ELSE
  RANK() OVER (ORDER BY indexed) 
  END
  AS ranking
  FROM
  (SELECT  e.empid, e.lname, 
   CASE WHEN pp.salary <> 189170 THEN
   ROW_NUMBER() OVER(PARTITION BY pp.salary)
   ELSE -1
   END as indexed
   FROM employee e, payroll pp
   WHERE e.empid = pp.empid ) AS indexing
 ) AS ranked_table
 WHERE ranking <> 0 AND e1.empid = ranked_table.empid AND
 ranked_table.lname = e1.lname
) AND p1.empid = e1.empid
ORDER BY empid, lname;



-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
