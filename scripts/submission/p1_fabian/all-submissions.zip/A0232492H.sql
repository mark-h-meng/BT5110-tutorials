/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232492H                               */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.02 ms
-- Average Execution 1.06 ms
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
-- /******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL
ORDER BY per.empid, per.lname;

-- Average Planning 0.02 ms
-- Average Execution 1.13 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary FROM payroll pay) AS temp
WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.02 ms
-- Average Execution 1.00 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay 
						WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.02 ms
-- Average Execution 2.53 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT DISTINCT per.empid, per.lname
FROM employee per, payroll pay
WHERE per.empid NOT IN (SELECT per.empid 
						FROM employee per FULL OUTER JOIN payroll pay 
						ON per.empid = pay.empid AND pay.salary::text NOT LIKE '189170'
						WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL 
						GROUP BY per.empid, per.lname 
						ORDER BY per.empid, per.lname)
GROUP BY per.empid, per.lname
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.09 ms
-- Average Execution 31.25 ms
-- Note: When use test() to compute the planning time and executing time, need to change '189170' into ''189170''
