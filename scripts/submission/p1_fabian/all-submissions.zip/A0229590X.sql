/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0229590X                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
-- SELECT per.empid, per.lname
-- FROM employee per FULL OUTER JOIN payroll pay 
--     ON per.empid = pay.empid AND pay.salary = 189170
-- WHERE TRUE
-- ORDER BY per.empid, per.lname;

SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average planning: 0.09
-- Average execution: 3.85
/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
-- SELECT per.empid, per.lname
-- FROM employee per, (SELECT TRUE) AS temp
-- WHERE TRUE
-- ORDER BY per.empid, per.lname;

SELECT per.empid, per.lname
FROM employee per, (SELECT empid,salary FROM payroll) AS temp
WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;

-- Average planning: 0.08
-- Average Execution: 3.82
/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
-- SELECT per.empid, per.lname
-- FROM employee per
-- WHERE per.empid NOT IN (SELECT 'TRUE')
-- ORDER BY per.empid, per.lname;

SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll where salary!=189170)
ORDER BY per.empid, per.lname;

-- Average Planning: 0.06 ms 
-- Average Execution 7.00 ms
/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT test('SELECT DISTINCT per.empId, per.lname FROM employee per,payroll pay 
WHERE per.empId IN (SELECT t1.empId FROM (SELECT employee.*,payroll.empId as payEmpId FROM employee, payroll) AS T1)
AND pay.salary NOT IN (SELECT t2.salary FROM (SELECT employee.*,payroll.empId as payEmpId,payroll.salary FROM employee,payroll) AS T2
					  WHERE t2.salary != 189170)
AND per.empId = pay.empId
ORDER BY per.empId,per.lname;',20)

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 2.05 ms
-- Average Execution 425818.64 ms