/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0237536Y                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL
ORDER BY per.empid , per.lname;

-- Average Planning Time : 0.07ms
-- Average Execution Time : 2.29ms 

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid FROM payroll WHERE salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Average Planning Time : 0.07ms
-- Average Execution Time : 2.11ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary <> 189170)
ORDER BY per.empid, per.lname;

-- Average Planning Time : 0.06ms 
-- Average Execution Time : 6.15ms

/******************************************************************************/
/* Answer Question 3 below                                                    */
/******************************************************************************/
SELECT DISTINCT per.empid, per.lname
FROM employee per
WHERE per.empid <> ALL (
    SELECT DISTINCT empid
    FROM (
        SELECT DISTINCT *
        FROM (
			SELECT DISTINCT * FROM employee ORDER BY empid DESC) e 
				FULL OUTER JOIN (
			(SELECT DISTINCT * FROM payroll
                WHERE salary <> ALL (
            SELECT salary FROM payroll WHERE salary >= 189170 ORDER BY empid DESC))
            UNION ALL
            (SELECT DISTINCT * FROM payroll
                WHERE salary <> ALL (
            SELECT salary FROM payroll WHERE salary <= 189170 ORDER BY empid DESC))
                ORDER BY empid
		) temp1
        USING (empid)
        ORDER BY empid DESC
    ) temp2
    WHERE salary IS NOT NULL
    ORDER BY empid DESC)
ORDER BY per.empid , per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning Time : 0.31ms
-- Average Execution Time : 420763.97ms
