/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0210988W                               */
/******************************************************************************/

/******************************************************************************/
/* Environment:                                                             */
/* MacBook Pro (16-inch, 2021)				                                */
/* Apple M1 Max								                                */
/* Memory 64GB								                                */
/******************************************************************************/

SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

/* 100 iterations                        */
/* average planning : average execution  */
/* 0.02             : 1.28               */

/* 1000 iterations                       */
/* average planning : average execution  */
/* 0.02             : 1.04               */
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170 
ORDER BY per.empid, per.lname;
/* 100 iterations                        */
/* average planning : average execution  */
/* 0.02             : 1.32               */

/* 1000 iterations                       */
/* average planning : average execution  */
/* 0.02             : 1.02               */

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary FROM payroll pay) AS temp
WHERE temp.salary = 189170 AND per.empid = temp.empid
ORDER BY per.empid, per.lname;
/* 100 iterations                         */
/* average planning : average execution   */
/* 0.03             : 1.26                */

/* 1000 iterations                        */
/* average planning : average execution   */
/* 0.02             : 1.02                */

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;
/* 100 iterations                       */
/* average planning : average execution */
/* 0.02             : 2.90              */

/* 1000 iterations                        */
/* average planning : average execution   */
/* 0.01             : 2.52                */

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
select per.empid, per.lname
from employee per, (select emp.empid from employee emp
except
 select pay.empid
 from payroll pay
 where pay.salary <> 189170
) AS X
where per.empid IN (
	select pay.empid
	from payroll pay
	where pay.empid = X.empid and X.empid in (
		select Y.empid
		from payroll Y
		where Y.salary <= pay.salary and Y.empid in (
			select H.empid
			from payroll H
			where H.salary is not NULL
			order by H.salary, H.bonus, H.empid asc
		)
		intersect
		select Z.empid
		from payroll Z
		where Z.salary >= pay.salary and Z.empid in (
			select H.empid
			from payroll H
			where H.salary is not NULL
			order by H.salary, H.bonus, H.empid desc
		)
		order by empid desc
	)
	order by pay.salary, pay.bonus, pay.empid asc
) 
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.24 ms
-- Average Execution 345482.73 ms

/******************************************************************************/
/* OTHER WORKINGS */
/******************************************************************************/

-- select per.empid, per.lname
-- from employee per, (select emp.empid from employee emp
-- except
--  select pay.empid
--  from payroll pay
--  where pay.salary <> 189170
-- ) AS X
-- where per.empid IN (
-- 	select pay.empid
-- 	from payroll pay
-- 	where pay.empid = X.empid
-- )
-- ORDER BY per.empid, per.lname;
/* 20 iterations                          */
/* average planning : average execution   */
/* 0.08             : 38556.30             */

-- SELECT per.empid, per.lname
-- FROM employee per
-- WHERE per.empid IN (
--     select pay.empid
--     from payroll pay
--     where salary = 189170
--     and pay.empid = per.empid
-- )
-- ORDER BY per.empid, per.lname;
/* 20 iterations                          */
/* average planning : average execution   */
/* 0.05             : 3506.20             */

-- SELECT per.empid, per.lname
-- FROM employee per
-- WHERE per.empid NOT IN (
--     select pay.empid
--     from payroll pay
--     where salary <> 189170
--     and pay.empid = per.empid
-- );
/* 20 iterations                          */
/* average planning : average execution   */
/* 0.04             : 2554.94             */

-- WITH X AS 
-- (select emp.empid from employee emp
-- except
--  select pay.empid
--  from payroll pay
--  where pay.salary <> 189170
-- )
-- select per.empid, per.lname
-- from employee per, X
-- where per.empid IN (
-- 	select pay.empid
-- 	from payroll pay
-- 	where pay.empid = X.empid
-- )
-- ORDER BY per.empid, per.lname;
/* 20 iterations                          */
/* average planning : average execution   */
/* 0.09             : 38671.54             */
