/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0242116U                               */
/******************************************************************************/
SELECT test('SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;', 1000);
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT test('SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid = pay.empid
ORDER BY per.empid, per.lname;', 1000);

-- Indicate the average measured time for 1000 executions for the query.
-- Average Planning 0.10 ms
-- Average Execution 3.12 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT test('SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary FROM payroll WHERE salary = 189170) AS temp
WHERE temp.empid = per.empid
ORDER BY per.empid, per.lname;', 1000);

-- Indicate the average measured time for 1000 executions for the query.
-- Average Planning 0.12 ms
-- Average Execution 3.35 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary != 189170)
ORDER BY per.empid, per.lname;', 1000);

-- Indicate the average measured time for 1000 executions for the query.
-- Average Planning 0.07 ms
-- Average Execution 6.27 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
select test('select per1.empid, per1.lname 
FROM employee per1
WHERE per1.empid NOT IN (
			SELECT per2.empid FROM employee per2 
			EXCEPT 
			SELECT pay.empid FROM payroll pay WHERE salary = 189170 AND per1.empid = pay.empid
		   )
ORDER BY per1.empid, per1.lname;', 20)

-- Indicate the average measured time for 20 executions for the query.
-- Average Planning 0.13 ms
-- Average Execution 69783.57 ms


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
