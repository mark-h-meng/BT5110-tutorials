/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0133934E                               */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, payroll pay
WHERE per.empid = pay.empid
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.03 ms
-- Average Execution 1.21 ms
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL AND pay.salary IS NOT NULL
ORDER BY per.empid, per.lname;

-- Average Planning 0.02 ms
-- Average Execution 1.34 ms
/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT p.empid
					FROM payroll p
					WHERE p.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Average Planning 0.03 ms
-- Average Execution 1.24 ms
/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT p.empid
					   FROM payroll p
					   WHERE p.salary <> 189170)
ORDER BY per.empid, per.lname;


-- Average Planning 0.02 ms
-- Average Execution 2.56 ms
/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT DISTINCT per.empid, per.lname
FROM employee per CROSS JOIN payroll pay
WHERE NOT EXISTS (
SELECT *
FROM payroll p
WHERE per.empid = p.empid
AND p.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.07 ms
-- Average Execution 20.04 ms
