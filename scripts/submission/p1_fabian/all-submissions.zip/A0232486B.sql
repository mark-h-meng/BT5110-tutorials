/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232486B                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.04 ms
-- Average Execution 1.59 ms
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.empid IS NOT NULL AND per.empid IS NOT NULL
ORDER BY per.empid, per.lname;

-- Average Planning 0.05 ms
-- Average Execution 1.80 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid FROM payroll AS pay WHERE pay.salary = 189170) AS temp
WHERE per.empid IN (temp.empid)
ORDER BY per.empid, per.lname;

-- Average Planning 0.05 ms
-- Average Execution 1.60 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll AS pay WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.03 ms
-- Average Execution 3.80 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE 
	(per.empid IS NOT NULL) AND
	(per.lname IS NOT NULL) AND
	(per.fname IS NOT NULL) AND
	(per.address IS NOT NULL) AND
	(per.city IS NOT NULL) AND
	(per.state IS NOT NULL) AND
	(per.zip IS NOT NULL) AND
	per.empid IN (
    SELECT pay.empid
    FROM payroll pay
    WHERE pay.empid NOT IN (
        SELECT pay1.empid
        FROM payroll pay1
        WHERE pay.salary != 189170 AND pay1.empid = per.empid))
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.07 ms
-- Average Execution 56209208.74 ms (15 hr 36 min)
