/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0229394U                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;
--  Average Planning time: 0.15ms                                              
--  Average Execution time: 4.21ms                                             

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary FROM payroll WHERE salary= 189170 ) AS temp
WHERE per.empid = temp.empid 
ORDER BY per.empid, per.lname;
--  Average Planning time: 0.18ms                                              
--  Average Execution time: 4.42ms                                             

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary != 189170 )
ORDER BY per.empid, per.lname;
--  Average Planning time: 0.10ms                                              
--  Average Execution time: 10.01ms                                            

/******************************************************************************/
/* Answer Question 3 below                                                    */
/******************************************************************************/

SELECT per.empid, per.lname FROM employee per
WHERE empid NOT IN
(SELECT empid FROM payroll WHERE MOD(salary,10) <> 0 OR
	per.empid IN 
	(SELECT empid FROM payroll WHERE MOD(salary,100)/10 <> 7 OR
		per.empid IN 
		(SELECT empid FROM payroll WHERE MOD(salary,1000)/100 <> 1 OR
 			per.empid IN
			(SELECT empid FROM payroll WHERE MOD(salary,10000)/1000 <> 9 OR
				per.empid IN
				(SELECT empid FROM payroll WHERE MOD(salary,100000)/10000 <> 8 OR 
					per.empid IN
					(SELECT empid FROM payroll WHERE MOD(salary,1000000)/100000 <> 1)
	   			) 
   			) 
  		) 
 	) 
)ORDER BY per.empid, per.lname;
-- Indicate the average measured time for 20 executions for the query.
-- Average Planning 1.20ms
-- Average Execution 334124.32ms = 5.57mins

SELECT per.empid, per.lname FROM employee per
WHERE empid NOT IN
(SELECT per.empid FROM employee per, payroll pay WHERE per.empid = pay.empid AND MOD(pay.salary,10) <> 0 OR
	per.empid IN 
	(SELECT per.empid FROM employee per, payroll pay WHERE per.empid = pay.empid AND MOD(pay.salary,100)/10 <> 7 OR
		per.empid IN 
		(SELECT per.empid FROM employee per, payroll pay WHERE per.empid = pay.empid AND MOD(pay.salary,1000)/100 <> 1 OR
 			per.empid IN
			(SELECT per.empid FROM employee per, payroll pay WHERE per.empid = pay.empid AND MOD(pay.salary,10000)/1000 <> 9 OR
				per.empid IN
				(SELECT per.empid FROM employee per, payroll pay WHERE per.empid = pay.empid AND MOD(pay.salary,100000)/10000 <> 8 OR 
					per.empid IN
					(SELECT per.empid FROM employee per, payroll pay WHERE per.empid = pay.empid AND MOD(pay.salary,1000000)/100000 <> 1)
	   			) ORDER BY per.empid, per.lname
   			) ORDER BY per.empid, per.lname
  		) ORDER BY per.empid, per.lname
 	) ORDER BY per.empid, per.lname
)ORDER BY per.empid, per.lname;
-- Average Planning not sure.
-- Average Execution not sure, as I left it run overnight, but the query could not finish.
-- If this query (joining table multiple times) is now allowed, please take the first answer.
