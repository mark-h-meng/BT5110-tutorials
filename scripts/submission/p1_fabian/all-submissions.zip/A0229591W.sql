/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0229591W                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
/* 100 Executions:                                                            */
/* Average Planning Time : 0.05ms , Average Execution Time : 1.25 ms          */
/* 1000 Executions:                                                           */
/* Average Planning Time : 0.04ms , Average Execution Time : 1.22 ms          */
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/

/* Condition `pay.salary = 189170` replaced TRUE in WHERE clause              */
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;
/* 100 Executions:                                                            */
/* Average Planning Time : 0.04ms , Average Execution Time : 1.23 ms          */
/* 1000 Executions:                                                           */
/* Average Planning Time : 0.06ms , Average Execution Time : 1.24 ms          */

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/

/* temp subquery filters for only payroll records with salary 189170          */
/* and used to cross join with employee in outer query with WHERE clause      */
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
/* 100 Executions:                                                            */
/* Average Planning Time : 0.06ms , Average Execution Time : 1.26 ms          */
/* 1000 Executions:                                                           */
/* Average Planning Time : 0.04ms , Average Execution Time : 1.23 ms          */


/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/

/* Subquery projects all empid values for payrolls where salary is NOT 189170 */
/* so that these employee records can be excluded in the outer query          */
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE salary <> 189170)
ORDER BY per.empid, per.lname;
/* 100 Executions:                                                            */
/* Average Planning Time : 0.04ms , Average Execution Time : 2.97 ms          */
/* 1000 Executions:                                                           */
/* Average Planning Time : 0.04ms , Average Execution Time : 3.01 ms          */


/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
/*                                                                            */
/* The strategy for slowing down the query involves two main ideas:           */ 
/* 1. Forcing the optimizer to execute a cross join of employee and payroll   */
/* 2. Resolving matching joined rows on empid and salary via derived values   */
/*                                                                            */
/* cross_join_concat_employee_payroll:                                        */
/* Cross join query returns relevant result columns as concatenated strings   */
/*                                                                            */
/* cross_join_concat_extract_empid:                                           */
/* Full list of empid values extracted using regular expression               */
/*                                                                            */
/* cross_join_matches:                                                        */
/* Cross join matches which are resolved by extracting the two regex captured */
/* instances of empid in the concatenated result as a text array, unnesting   */
/* it into two rows for each result, and then using a GROUP BY to collect     */
/* all empid values with at least two results.                                */
/* Note: Cross joined rows with non-matching empid values will not pass.      */
/*       regex validation for the expression `([0-9]+)-[A-Z]+- (\1)-[0-9]+`.  */
/*       which requires that the two capture groups are equal, and hence      */
/*       will not be unnested and be part of the final GROUP BY result.       */
/*                                                                            */
/* cross_join_matches_empids_with_target_salary:                              */
/* Filters the list of empid values in cross_join_concat_extract_empid        */
/* against the results in cross_join_matches with the target salary of 189170 */
/*                                                                            */
/* Finally, the outer query projects empid and lname from the base employee   */
/* table for rows where empid can be found in the cross joined result         */
/* cross_join_matches_empids_with_target_salary                               */
/*                                                                            */
WITH
    cross_join_concat_employee_payroll AS 
    (
        SELECT per.empid || '-' || per.lname || '-' || pay.empid || '-' || pay.salary AS identifier
        FROM 
            (SELECT * FROM employee ORDER BY empid ASC) per, 
            (SELECT * FROM payroll ORDER BY empid ASC) pay
    ),
    cross_join_concat_extract_empid AS 
    (
        SELECT (REGEXP_MATCHES(cross_join_concat_employee_payroll.identifier, '^ ([0-9]+).*$'))[1] AS empid
        FROM cross_join_concat_employee_payroll
    ),
    cross_join_matches AS 
    (
        SELECT 
            UNNEST(REGEXP_MATCHES(
                cross_join_concat_employee_payroll.identifier,
                '([0-9]+)-[A-Z]+- (\1)-[0-9]+',
                'g'
            )) AS matching_empid,
            CAST((REGEXP_MATCHES(cross_join_concat_employee_payroll.identifier, '^.*-.*-.*-([0-9]+)$'))[1] AS INTEGER) 
                AS matching_salary
        FROM cross_join_concat_employee_payroll
        GROUP BY matching_empid, matching_salary
        HAVING COUNT(*) = 2
    ),
    cross_join_matches_empids_with_target_salary AS 
    (
        SELECT DISTINCT cross_join_concat_extract_empid.empid
        FROM cross_join_concat_extract_empid
        WHERE 
            cross_join_concat_extract_empid.empid IN 
                (SELECT cross_join_matches.matching_empid 
                 FROM cross_join_matches
                 WHERE cross_join_matches.matching_salary = 189170)
    )
SELECT emp.empid, emp.lname
FROM employee emp
WHERE TRIM(emp.empid) IN (SELECT * FROM cross_join_matches_empids_with_target_salary)
ORDER BY emp.empid, emp.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.33 ms
-- Average Execution 2691526.33 ms
