/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228617Y                               */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, payroll pay
WHERE per.empid = pay.empid
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL and pay.salary IS NOT NULL
ORDER BY per.empid, per.lname;


-- Average Planning 0.17 ms
-- Average Execution 6.42 (run 1000 by using the test function)


/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per, (SELECT empid FROM payroll WHERE salary=189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid , per.lname;

-- Average Planning 0.17 ms
-- Average Execution 5.42 (run 1000 by using the test function)by using the test function)

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary != 189170)
ORDER BY per.empid , per.lname;

-- Average Planning 0.29 ms
-- Average Execution 10.93 (run 1000 by using the test function)

/******************************************************************************/
/* Answer Question 3 below                                                  */
/* NOT BEST YET, JUST AN ATTEMPT */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per
WHERE 189170 >= (SELECT p.salary
    FROM payroll p
    WHERE p.empid = per.empid AND empid IN (SELECT per.empid
        FROM employee per
        WHERE 189170 <= (
            SELECT pay.salary
            FROM payroll pay
            WHERE pay.empid = per.empid)));


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.16 ms
-- Average Execution 67680.42 (run 20 by using the test function)
