/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228603J                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- test script and time estimates
SELECT test('SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;', 100);

-- Average planning and execution times over 100 executions:
-- Average Planning 0.17 ms
-- Average Execution 3.88 ms
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.salary IS NOT NULL
ORDER BY per.empid, per.lname;

-- test script and time estimates
SELECT test('SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.salary IS NOT NULL
ORDER BY per.empid, per.lname;', 100);

-- Average planning and execution times over 100 executions:
-- Average Planning 0.16 ms
-- Average Execution 4.12 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid
				   FROM payroll pay
				   WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- test script and time estimates
SELECT test('SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid
				   FROM payroll pay
				   WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;', 100);

-- Average planning and execution times over 100 executions:
-- Average Planning 0.16 ms
-- Average Execution 3.89 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid
				   FROM payroll pay
				   WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- test script and time estimates
SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid
				   FROM payroll pay
				   WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;', 100);

-- Average planning and execution times over 100 executions:
-- Average Planning 0.14 ms
-- Average Execution 8.23 ms

/******************************************************************************/
/* Answer Question 3 below                                                    */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE (SELECT pay.empid 
	   FROM payroll pay 
	   WHERE pay.empid = per.empid     -- try to scan through "payroll" from the start for each employee
	   AND pay.salary = 189170) IS NOT NULL;

-- test script and time estimates
SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE (SELECT pay.empid 
	   FROM payroll pay 
	   WHERE pay.empid = per.empid 
	   AND pay.salary = 189170) IS NOT NULL;', 20);

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.08 ms
-- Average Execution 11841.81 ms
