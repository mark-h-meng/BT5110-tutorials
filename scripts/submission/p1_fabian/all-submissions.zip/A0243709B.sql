/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0243709B                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
-- Average Planning 0.12 ms
-- Average Execution 5.21 ms

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid <> '' AND pay.empid <> ''
ORDER BY per.empid, per.lname;

-- Average Planning 0.14 ms
-- Average Execution 18.48 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Average Planning 0.13 ms
-- Average Execution 5.19 ms


/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.08 ms
-- Average Execution 11.21 ms


/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid as empid, per.lname as lname
FROM employee per
EXCEPT
SELECT salary_not_equal.empid as empid, two_join.lname as lname
FROM
(SELECT per2.empid, per2.lname 
 FROM employee per2 FULL OUTER JOIN payroll pay 
 ON per2.empid = pay.empid) AS two_join
CROSS JOIN 
 (SELECT pay2.empid 
  FROM payroll pay2 
  WHERE pay2.salary <> 189170) AS salary_not_equal
WHERE two_join.empid <> '' AND salary_not_equal.empid <> ''
ORDER BY empid, lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.30 ms
-- Average Execution 88412.21 ms
