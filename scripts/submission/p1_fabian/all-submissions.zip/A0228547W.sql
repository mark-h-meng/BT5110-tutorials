/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228547W                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Measured Time for 100 Executions
-- Average Planning 0.15 ms
-- Average Execution 4.19 ms

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/

-- [Version1] Modify the ON and WHERE Clauses
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Measured Time for 100 Executions
-- Average Planning 0.15 ms
-- Average Execution 4.17 ms

-- [Version2] Only Modify the WHERE Clauses
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND per.lname IS NOT NULL AND pay.salary IS NOT NULL
ORDER BY per.empid, per.lname;

-- Average Measured Time for 100 Executions
-- Average Planning 0.18 ms
-- Average Execution 5.48 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Average Measured Time for 100 Executions
-- Average Planning 0.16 ms
-- Average Execution 4.15 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;

-- Average Measured Time for 100 Executions
-- Average Planning 0.12 ms
-- Average Execution 9.53 ms

/******************************************************************************/
/* Answer Question 3 below                                                    */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary != 189170 AND pay.empid = per.empid)
ORDER BY per.empid, per.lname;

-- Average Measured Time for 20 Executions
-- Average Planning 0.14 ms
-- Average Execution 9637.42 ms

/******************************************************************************/
/* Another Possible Equivalent Query (Query 4) below                          */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (SELECT pay.empid FROM payroll pay WHERE pay.salary != 189170 AND pay.empid = per.empid)
ORDER BY per.empid, per.lname;

-- Average Measured Time for 100 Executions
-- Average Planning 0.17 ms
-- Average Execution 9.22 ms

/******************************************************************************
Observation and Demonstration

The Average execution time of Query 2.c is longer than that of Query 2.a and Query 2.b.
Query 2.c uses NOT IN rather than JOIN, so I tried Query 3.

For query 2.c, per.empid is irrelevant to sub-SELECT. Maybe sub-SELECT is executed only once, 
and then main-SELECT compares whether each per.empid is in the return of sub-SELECT.

For query 3, per.empid is irrelevant to sub-SELECT. For each per.empid record, sub-SELECT is 
repeatedly executed to re-traverse the payroll table, and then main-SELECT compares
whether each per.empid is in the return of sub-SELECT.

For query4, per.empid is irrelevant to sub-SELECT. But when I check explain / analysis,
I find can find this query actually uses hash anti join.
******************************************************************************/