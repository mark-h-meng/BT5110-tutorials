/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0236359W                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per . empid , per . lname
FROM employee per FULL OUTER JOIN payroll pay
ON per . empid = pay . empid AND pay . salary = 189170
WHERE pay.salary = 189170
ORDER BY per . empid , per . lname ;

/*******************************/
/** Planning : Execution Time **/
/*       "0.10 : 4.69"         */
/*******************************/

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/

SELECT per . empid , per . lname
FROM employee per , ( SELECT * FROM payroll pay WHERE pay.salary = 189170 ) AS temp
WHERE per.empid = temp.empid
ORDER BY per . empid , per . lname ;

/*******************************/
/** Planning : Execution Time **/
/*       "0.09 : 4.68"         */
/*******************************/

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/

SELECT per . empid , per . lname
FROM employee per
WHERE per . empid NOT IN ( SELECT pay.empid FROM payroll pay WHERE pay.salary <> 189170)
ORDER BY per . empid , per . lname ;

/*******************************/
/** Planning : Execution Time **/
/*       "0.06 : 11.67"         */
/*******************************/

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT DISTINCT *
FROM (SELECT per.empid, per.lname
		FROM employee per
		WHERE per.empid IN (SELECT per.empid FROM employee per, payroll pay WHERE per.empid = pay.empid) 
					  AND per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary <> 189170 AND per.empid = pay.empid 
					  AND NOT EXISTS (SELECT * FROM employee per, payroll pay WHERE pay.salary < 0))
ORDER BY per.empid, per.lname)AS x;	

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.31 ms
-- Average Execution 11365.73 ms

