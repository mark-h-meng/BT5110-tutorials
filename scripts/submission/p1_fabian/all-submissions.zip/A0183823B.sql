/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0183823B                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/*
                              test
----------------------------------------------------------------
 Average Planning Time: 0.07ms, Average Execution Time: 2.02 ms
*/

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL 
ORDER BY per.empid, per.lname;
/*
                              test
----------------------------------------------------------------
 Average Planning Time: 0.10ms, Average Execution Time: 2.73 ms
*/

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
/*
                                test
----------------------------------------------------------------
 Average Planning Time: 0.07ms, Average Execution Time: 2.17 ms
*/

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;
/*
                              test
----------------------------------------------------------------
 Average Planning Time: 0.07ms, Average Execution Time: 5.11 ms
*/

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT emp_temp.empid, emp_temp.lname
FROM (
SELECT *
FROM employee per
EXCEPT
SELECT *
FROM employee per2 
WHERE per2.empid IN (
  SELECT emp_salary_ranks.empid 
  FROM (
    SELECT per3.empid, CASE 
      WHEN ABS(pay2.salary - 189170) = 0 THEN 0
      ELSE RANK() OVER ( ORDER BY ABS(pay2.salary - 189170) ASC) 
      END rank_num 
      FROM employee per3, payroll pay2 
      WHERE per3.empid = pay2.empid
  ) AS emp_salary_ranks 
  WHERE per2.empid = emp_salary_ranks.empid 
    AND emp_salary_ranks.rank_num <> 0
)) AS emp_temp 
ORDER BY emp_temp.empid, emp_temp.lname;
/*
                                test
--------------------------------------------------------------------
 Average Planning Time: 0.26ms, Average Execution Time: 95268.92 ms
*/

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.26ms
-- Average Execution 95268.92 ms