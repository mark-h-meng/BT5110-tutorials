/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228490B                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid = pay.empid
ORDER BY per.empid, per.lname;

-- Average Planning Time:0.48ms, Average Execution Time : 9.40 ms"
/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT  empid from payroll where salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- "Average Planning Time:0.33ms, Average Execution Time : 8.76 ms"

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid from payroll where salary <> 189170)
ORDER BY per.empid, per.lname;

-- "Average Planning Time:0.33ms, Average Execution Time : 32.30 ms"

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM payroll sal, employee per
WHERE per.empid IN (SELECT empid from payroll pay where per.empid = pay.empid and salary = 189170)
and sal.empid IN (SELECT empid from payroll pay where per.empid = pay.empid and salary = 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.30ms ms
-- Average Execution 169802.02 ms
