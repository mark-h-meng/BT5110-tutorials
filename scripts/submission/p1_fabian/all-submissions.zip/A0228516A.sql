/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228516A                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 -- Average planning and execution times over 100 executions: 0.06 : 1.93;
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;
 -- Average planning and execution times over 100 executions: 0.07 : 1.94;
/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
 -- Average planning and execution times over 100 executions: 0.06 : 1.89;
/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;
 -- Average planning and execution times over 100 executions: 0.05 : 4.57;
/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT *
FROM(
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 199170)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 99170)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 198170)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 109170)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 197170)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 119170)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 196170)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 129170)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 195170)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 139170)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 194170)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 149170)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 193170)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 159170)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 192170)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 169170)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 191170)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 179170)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 189179)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 189161)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 189178)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 189162)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 189177)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 189163)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 189176)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 189164)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 189175)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 189165)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 189174)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 189166)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 189173)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 189167)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 189172)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 189168)
INTERSECT 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary < 189171)
INTERSECT
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid
				   From payroll pay
				   WHERE pay.salary > 189169)
) tmp
ORDER BY tmp.empid, tmp.lname;
-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 2.09 ms
-- Average Execution 240.89 ms
