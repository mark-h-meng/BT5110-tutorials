/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0242091N                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning   0.08 ms 
-- Average Execution  6.29 ms
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning   0.08 ms 
-- Average Execution  5.57 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Average Planning   0.09 ms 
-- Average Execution  5.70 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Average Planning   0.10 ms 
-- Average Execution  6.50 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT pay1.empid, per1.lname
FROM employee per1 FULL OUTER JOIN
(
	SELECT pay2.empid
	FROM payroll pay2
	WHERE pay2.empid NOT IN 
	(
		SELECT per2.empid
		FROM employee per2
		WHERE per2.empid IN 
		(
			SELECT pay2.empid WHERE pay2.empid = per2.empid AND pay2.salary > 189170
		)
		UNION
		SELECT per3.empid
		FROM employee per3
		WHERE per3.empid IN 
		(
			SELECT pay2.empid WHERE pay2.empid = per3.empid AND pay2.salary < 189170
		)
	)
) as pay1
ON pay1.empid = per1.empid
WHERE pay1.empid IS NOT NULL
ORDER BY pay1.empid, per1.lname;

-- Average Planning   0.14 ms
-- Average Execution  112982.66 ms
