/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0083629W                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- SELECT test ('SELECT per.empid, per.lname 
-- FROM employee per, payroll pay
-- WHERE per.empid = pay.empid 
-- AND pay.salary = 189170
-- ORDER BY per.empid, per.lname;',1000)


-- Average Planning 0.10 ms
-- Average Execution 2.85 ms
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid = pay.empid AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- SELECT test('SELECT per.empid, per.lname
-- FROM employee per FULL OUTER JOIN payroll pay 
--     ON per.empid = pay.empid AND pay.salary = 189170
-- WHERE per.empid = pay.empid AND pay.salary = 189170
-- ORDER BY per.empid, per.lname;',1000)


-- Average Planning 0.11 ms
-- Average Execution 2.80 ms
/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary FROM payroll pay) AS temp
WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;

-- SELECT test('SELECT per.empid, per.lname
-- FROM employee per, (SELECT pay.empid, pay.salary FROM payroll pay) AS temp
-- WHERE per.empid = temp.empid AND temp.salary = 189170
-- ORDER BY per.empid, per.lname;',1000)


-- Average Planning 0.12 ms
-- Average Execution 2.77 ms
/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;

-- SELECT test('SELECT per.empid, per.lname
-- FROM employee per
-- WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary != 189170)
-- ORDER BY per.empid, per.lname;',1000)


-- Average Planning 0.08 ms
-- Average Execution 7.07 ms
/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT DISTINCT per.empid,per.lname
FROM employee per
WHERE (per.empid,per.lname) NOT IN (
			 (SELECT per.empid, per.lname 
			 FROM payroll pay 
			 WHERE per.empid = pay.empid AND pay.salary < 189170)
	
			 UNION

			 (SELECT per.empid, per.lname 
			 FROM payroll pay 
			 WHERE per.empid = pay.empid AND pay.salary > 189170)
			)
GROUP BY per.empid,per.lname			 
ORDER BY per.empid,per.lname;

-- SELECT test('SELECT DISTINCT per.empid,per.lname
-- FROM employee per
-- WHERE (per.empid,per.lname) NOT IN (
-- 			 (SELECT per.empid, per.lname 
-- 			 FROM payroll pay 
-- 			 WHERE per.empid = pay.empid AND pay.salary < 189170)
	
-- 			 UNION

-- 			 (SELECT per.empid, per.lname 
-- 			 FROM payroll pay 
-- 			 WHERE per.empid = pay.empid AND pay.salary > 189170)
-- 			)
-- GROUP BY per.empid,per.lname			 
-- ORDER BY per.empid,per.lname;',20)


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.17 ms
-- Average Execution 22738.64 ms
