/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228596M                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
-- Average Planning: 0.20 ms
-- Average Execution: 1.22 ms 
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning: 0.18 ms
-- Average Execution: 1.06 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary from payroll) AS temp
WHERE per.empid=temp.empid and temp.salary=189170
ORDER BY per.empid, per.lname;

-- Average Planning: 0.20 ms
-- Average Execution: 1.19 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid from payroll where salary<>189170)
ORDER BY per.empid, per.lname;

-- Average Planning: 0.12 ms
-- Average Execution: 7.82 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT em.empid, em.lname from employee em, payroll pr
where em.empid=pr.empid and (em.empid,pr.salary, em.lname) not in			
((Select e.empid,py.salary,e.lname 
from employee e full outer join payroll py
on e.empid=py.empid
where e.empid=em.empid
group by e.empid, py.salary,e.lname
having py.salary<189170
order by e.lname, e.empid, py.salary)
union
(Select e.empid,py.salary,e.lname 
from employee e full outer join payroll py
on e.empid=py.empid
where e.empid=em.empid
group by e.empid, py.salary,e.lname
having py.salary>189170
order by e.lname, e.empid, py.salary)
union
(Select e.empid,py.salary,e.lname 
from employee e full outer join payroll py
on e.empid=py.empid
where e.empid=em.empid
group by e.empid, py.salary,e.lname
having py.salary!=189170
order by e.lname, e.empid, py.salary)
union
(Select e.empid,py.salary,e.lname 
from employee e full outer join payroll py
on e.empid=py.empid
where e.empid=em.empid
group by e.empid, py.salary,e.lname
having floor(log(abs(py.salary))+1) < 1
order by e.lname, e.empid, py.salary)
union
(Select e.empid,py.salary,e.lname
from employee e full outer join payroll py
on e.empid=py.empid
full outer join payroll pr on e.empid=pr.empid
group by e.empid, py.salary,e.lname, pr.salary
having floor(log(abs(py.salary))+1) <= 2 and floor(log(abs(pr.salary))+1) > 1
order by e.lname, e.empid, py.salary)
union
(Select e.empid,py.salary,e.lname
from employee e full outer join payroll py
on e.empid=py.empid
full outer join payroll pr on e.empid=pr.empid
group by e.empid, py.salary,e.lname, pr.salary
having floor(log(abs(py.salary))+1) <= 3 and floor(log(abs(pr.salary))+1) > 2
order by e.lname, e.empid, py.salary)
union
(Select e.empid,py.salary,e.lname
from employee e full outer join payroll py
on e.empid=py.empid
full outer join payroll pr on e.empid=pr.empid
group by e.empid, py.salary,e.lname, pr.salary
having floor(log(abs(py.salary))+1) <= 4 and floor(log(abs(pr.salary))+1) > 3
order by e.lname, e.empid, py.salary)
union
(Select e.empid,py.salary,e.lname
from employee e full outer join payroll py
on e.empid=py.empid
full outer join payroll pr on e.empid=pr.empid
group by e.empid, py.salary,e.lname, pr.salary
having floor(log(abs(py.salary))+1) <= 5 and floor(log(abs(pr.salary))+1) > 4
order by e.lname, e.empid, py.salary)
union
(Select e.empid,py.salary,e.lname
from employee e full outer join payroll py
on e.empid=py.empid
full outer join payroll pr on e.empid=pr.empid
group by e.empid, py.salary,e.lname, pr.salary
having floor(log(abs(py.salary))+1) <= 7 and floor(log(abs(pr.salary))+1) > 6
order by e.lname, e.empid, py.salary)
union
(Select e.empid,py.salary,e.lname 
from employee e full outer join payroll py
on e.empid=py.empid
where e.empid=em.empid
group by e.empid, py.salary,e.lname
having floor(log(abs(py.salary))+1) != 6
order by e.lname, e.empid, py.salary)
union
(Select e.empid,py.salary,e.lname 
from employee e full outer join payroll py
on e.empid=py.empid
where e.empid=em.empid
group by e.empid, py.salary,e.lname
having py.salary/100000 !=1
order by e.lname, e.empid, py.salary)
union
(Select e.empid,py.salary,e.lname 
from employee e full outer join payroll py
on e.empid=py.empid
where e.empid=em.empid
group by e.empid, py.salary,e.lname
having mod(py.salary,3) = 0
order by e.lname, e.empid, py.salary)
) order by em.empid, em.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning: 3.31 ms
-- Average Execution: 108874.78 ms
