/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0214477B                              */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
-- Average Planning Time: 0.14ms, Average Execution Time: 5.15ms

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.salary IS NOT NULL
ORDER BY per.empid, per.lname;
-- Average Planning Time: 0.19ms, Average Execution Time: 6.16ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid
					FROM payroll pay 
					WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
-- Average Planning Time: 0.17ms, Average Execution Time: 5.29ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid 
						FROM payroll pay 
						WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;
-- Average Planning Time: 0.13ms, Average Execution Time: 12.54ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT emp.empid
						FROM employee emp CROSS JOIN payroll pay
						WHERE per.empid = pay.empid AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.20 ms
-- Average Execution 33280.18 ms
-- Note: Results might vary. Please run in a standardised testing environment.
