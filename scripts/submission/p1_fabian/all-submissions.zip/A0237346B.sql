/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0237346B                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;


/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;


/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid FROM payroll WHERE salary = 189170) AS temp
WHERE temp.empid = per.empid
ORDER BY per.empid, per.lname;


/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (SELECT pay.empid FROM payroll pay WHERE pay.salary = 189170)
ORDER BY per.empid, per.lname;


/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT t1.empid, t2.lname FROM
(SELECT e1.empid, e1.lname FROM employee e1 FULL OUTER JOIN payroll p1 ON p1.empid = e1.empid 
WHERE p1.salary - '1' <= 189170 - 1
AND p1.salary + 1 >= 189170 + 1 ORDER BY e1.empid, e1.lname) AS t1
FULL OUTER JOIN
(SELECT e2.lname FROM employee e2 FULL OUTER JOIN payroll p2 ON p2.empid = e2.empid 
WHERE p2.salary - '1' <= 189170 - 1
AND p2.salary + 1 >= 189170 + 1 ORDER BY e2.empid, e2.lname) AS t2
ON t1.lname = t2.lname
ORDER BY t1.empid, t2.lname


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms