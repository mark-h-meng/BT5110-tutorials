/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0190403R                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary IS NOT NULL AND per.empid IS NOT NULL
ORDER BY per.empid, per.lname;

-- Average Planning : 0.07 ms
-- Average Execution : 3.30 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid FROM payroll WHERE salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Average Planning :  0.07 ms
-- Average Execution :  3.03 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary != 189170)
ORDER BY per.empid, per.lname;

-- Average Planning :  0.05 ms
-- Average Execution :  5.84 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT E1.empid, E1.lname 
FROM employee E1
WHERE NOT EXISTS (
		SELECT empid
		FROM (
			SELECT *
			FROM payroll
			WHERE
				CASE 
					WHEN EXISTS (
						SELECT * 
							FROM payroll 
							WHERE empid = E1.empid 
								AND salary < ALL (
									SELECT salary
										FROM payroll
										WHERE salary > 189170)
								AND salary > ALL (
									SELECT salary
										FROM payroll
										WHERE salary < 189170)) THEN empid = E1.empid
					ELSE TRUE
				END	
			) AS S
		WHERE NOT EXISTS (
				SELECT 1
					FROM employee AS E2
					WHERE E2.empid = S.empid
						AND E2.lname = E1.lname))
ORDER BY E1.empid, E1.lname;

-- Average Planning 0.21 ms
-- Average Execution 24499.61 ms