/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0248373X                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL
ORDER BY per.empid, per.lname;
-- Average Planning 0.08 ms
-- Average Execution 3.54 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid
					FROM payroll pay
					WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
-- Average Planning 0.08 ms
-- Average Execution 3.29 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid
						FROM payroll pay
						WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;
-- Average Planning 0.07 ms
-- Average Execution 6.04 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (
	SELECT temp.empid 
	FROM (
		SELECT * 
		FROM payroll pay1 
		WHERE pay1.salary > 189170
		UNION
		SELECT * 
		FROM payroll pay2 
		WHERE pay2.salary < 189170 
	) AS temp, employee per1
	WHERE temp.empid = per1.empid AND per1.empid = per.empid
)
ORDER BY per.empid, per.lname;	


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.16 ms
-- Average Execution 23809.78 ms
