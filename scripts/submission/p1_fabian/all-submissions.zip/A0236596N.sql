/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0236596N                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Total Planning 0.02 ms
-- Total Execution 0.96 ms


/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170 -- True
ORDER BY per.empid, per.lname;


-- Total Planning 0.02 ms
-- Total Execution 0.96 ms


/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid from payroll pay WHERE pay.salary = 189170 ) AS temp
WHERE per.empid = temp.empid 
ORDER BY per.empid, per.lname;


-- Total Planning 0.02 ms
-- Total Execution 0.96 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid from payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Total Planning 0.02 ms
-- Total Execution 2.18 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

select empid, max(lname) as lname from employee 
where empid not in (select empid from payroll where salary > 189171 or salary < 189169 order by empid)
group by empid
order by empid, lname;

SELECT test('select empid, max(lname) as lname from employee 
where empid not in (select empid from payroll where salary > 189171 or salary < 189169 order by empid)
group by empid
order by empid, lname;', 20);
-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.05 ms
-- Average Execution 4.91 ms