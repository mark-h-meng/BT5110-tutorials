/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0237317E                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/* Average Planning Time: 0.07ms, Average Execution Time: 3.18ms              */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/* Average Planning Time: 0.07ms, Average Execution Time: 3.32ms              */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid From payroll pay WhERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/* Average Planning Time: 0.05ms, Average Execution Time: 5.95ms              */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid From payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                    */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay
	ON per.empid = pay.empid
WHERE pay.salary = ALL(
SELECT pay1.salary
FROM payroll pay1, employee per1
WHERE pay1.salary = 189170 AND per1.empid = per.empid
)
ORDER BY per.empid, per.lname;


-- Average Planning 0.12 ms
-- Average Execution 6219.50 ms
-- Idea: correlated subquery