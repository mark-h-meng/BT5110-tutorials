/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228567R                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
/* plainging time 0.05  execution time 2.59 */
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null and pay.salary is not null
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
/* plainging time 0.04  execution time 2.32 */
SELECT per.empid , per.lname
FROM employee per, (SELECT pay.empid,pay.salary from payroll pay) AS temp 
WHERE per.empid = temp.empid and temp.salary = 189170
ORDER BY per.empid , per.lname;

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
/* plainging time 0.04  execution time 4.46 */
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid from payroll where salary != 189170)
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/


select empid, lname
from employee per
where not exists (select * from payroll pay where per.empid = pay.empid and pay.salary > 189170)

intersect

select empid, lname
from employee per
where not exists (select * from payroll pay where per.empid = pay.empid and pay.salary < 189170)

order by empid, lname;


/* adding extra 'distinct' or 'order by' may even slow the process, though it's not interesting 
from my point of view. */

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.13 ms
-- Average Execution 12.51 ms
