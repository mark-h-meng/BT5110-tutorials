/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0236570E                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.empid IS NOT NULL AND per.empid IS NOT NULL
ORDER BY per.empid, per.lname;

/*
SELECT test('SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.empid IS NOT NULL AND per.empid IS NOT NULL
ORDER BY per.empid, per.lname;',100);
*/

-- Average Planning Time: 0.11ms, Average Execution Time: 5.80ms


/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

/*
SELECT test('SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;',100);
*/

-- Average Planning Time: 0.25ms, Average Execution Time: 5.42ms


/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid from payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

/*
SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid from payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;', 100);
*/

-- Average Planning Time: 0.07ms, Average Execution Time: 10.68ms


/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT emp.empid, emp.lname FROM employee emp 
WHERE emp.empid NOT IN
	(SELECT DISTINCT empid FROM
		(SELECT INTERNAL.empid, INTERNAL.salary FROM
			(SELECT * FROM payroll) AS INTERNAL
		GROUP BY INTERNAL.empid, INTERNAL.salary
		HAVING INTERNAL.salary < 189170 
		 AND INTERNAL.salary IN (SELECT DISTINCT salary FROM payroll ORDER BY salary)
		 AND INTERNAL.empid IN (SELECT DISTINCT empid FROM payroll ORDER BY empid DESC)
		ORDER BY INTERNAL.empid DESC) 
 	AS EXCLUDED_LEFT ORDER by empid DESC)
AND emp.empid NOT IN
	(SELECT DISTINCT empid FROM
		(SELECT INTERNAL.empid, INTERNAL.salary FROM
			(SELECT * FROM payroll) AS INTERNAL
		GROUP BY INTERNAL.empid, INTERNAL.salary
		HAVING INTERNAL.salary > 189170 
		 AND INTERNAL.salary IN (SELECT DISTINCT salary FROM payroll ORDER BY salary)
		 AND INTERNAL.empid IN (SELECT DISTINCT empid FROM payroll ORDER BY empid DESC)
		ORDER BY INTERNAL.empid DESC) 
 	AS EXCLUDED_RIGHT ORDER by empid DESC)
AND emp.empid IN
	(SELECT DISTINCT empid FROM
		(SELECT INTERNAL.empid, INTERNAL.salary FROM
			(SELECT * FROM payroll) AS INTERNAL
		GROUP BY INTERNAL.empid, INTERNAL.salary
		HAVING INTERNAL.salary = 189170 
		 AND INTERNAL.salary IN (SELECT DISTINCT salary FROM payroll ORDER BY salary)
		 AND INTERNAL.empid IN (SELECT DISTINCT empid FROM payroll ORDER BY empid DESC)
		ORDER BY INTERNAL.empid DESC) 
 	AS INCLUDED ORDER by empid DESC)
AND emp.empid IN (SELECT DISTINCT empid FROM employee ORDER BY empid DESC)
AND emp.lname IN (SELECT DISTINCT lname FROM employee ORDER BY lname DESC)
AND emp.fname IN (SELECT DISTINCT fname FROM employee ORDER BY fname DESC)
AND emp.address IN (SELECT DISTINCT address FROM employee ORDER BY address DESC)
AND emp.city IN (SELECT DISTINCT city FROM employee ORDER BY city DESC)
AND emp.state IN (SELECT DISTINCT "state" FROM employee ORDER BY "state" DESC)
AND emp.zip IN (SELECT DISTINCT zip FROM employee ORDER BY zip DESC)
GROUP BY emp.empid, emp.lname
ORDER BY emp.empid, emp.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 4.23 ms
-- Average Execution 1916.41 ms



