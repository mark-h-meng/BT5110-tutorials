/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0242080U                              */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null and pay.empid is not null
ORDER BY per.empid, per.lname;

-- Average Planning 0.08 ms
-- Average Execution 2.49 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid from payroll pay where pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Average Planning 0.08 ms
-- Average Execution 2.25 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid from payroll pay where pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.06 ms
-- Average Execution 5.07 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (
    SELECT pay.empid
    FROM payroll pay
    WHERE pay.empid NOT IN
          (
              SELECT pay1.empid
              FROM payroll pay1
              WHERE pay1.empid = per.empid
                AND pay.empid IN
                    (
                        SELECT pay2.empid
                        FROM payroll pay2
                        WHERE pay2.salary NOT IN (189170)
                    )))
ORDER BY per.empid, per.lname;

-- Average Planning 0.15 ms
-- Average Execution 91460895 ms (1 d 1 h 24 m 20 s 895 ms)

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
