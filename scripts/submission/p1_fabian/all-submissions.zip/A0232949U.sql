/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232949U                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 0.06ms; 4.00ms
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid = pay.empid AND pay.salary = 189170
ORDER BY per.empid, per.lname;
0.07ms; 3.94ms
/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * from payroll) AS temp
WHERE per.empid = temp.empid and temp.salary = 189170
ORDER BY per.empid, per.lname;
0.07ms; 3.91ms
/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid from payroll where salary <> 189170)
ORDER BY per.empid, per.lname;
0.04ms; 9.73ms
/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT tmp.empid, tmp.lname
FROM (
	SELECT per.empid, per.lname, per.fname, per.address, per.city, per.state, per.zip, pay.salary 
	FROM employee per, payroll pay
	WHERE per.empid = pay.empid AND pay.salary IN (
		SELECT pay.salary
		FROM employee per1 FULL OUTER JOIN payroll pay1 
		ON per1.empid = pay1.empid AND pay1.salary <> 189171 ORDER BY Random()
		) AND pay.salary <> 189173 ORDER BY Random(), per.fname
) tmp WHERE tmp.salary IN (
		SELECT tmp.salary
		FROM employee per1 FULL OUTER JOIN payroll pay1 
		ON per1.empid = pay1.empid AND pay1.salary <> 189172 ORDER BY Random(), per1.fname
	) AND tmp.empid NOT IN (
		SELECT per.empid
		FROM employee per, payroll pay
		WHERE per.empid = pay.empid AND pay.salary IN (
			SELECT pay.salary
			FROM employee per1 FULL OUTER JOIN payroll pay1 
			ON per1.empid = pay1.empid AND pay1.salary <> 189171 ORDER BY Random()
			) AND pay.salary <> 189170 ORDER BY Random(), per.fname
)
ORDER BY tmp.empid, tmp.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.93 ms
-- Average Execution 206898.33 ms
