/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0126486X                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.04 ms
-- Average Execution 1.30 ms
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not NULL AND pay.empid is not NULL
ORDER BY per.empid, per.lname;

-- Average Planning 0.05 ms
-- Average Execution 1.41 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary FROM payroll pay) AS temp
WHERE per.empid = temp.empid 
AND temp.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.04 ms
-- Average Execution 1.18 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.03 ms
-- Average Execution 2.99 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per CROSS JOIN (SELECT * FROM payroll pay WHERE pay.empid is not NULL) pay
WHERE per.empid is not NULL  AND per.empid = pay.empid  AND pay.empid NOT IN (SELECT pays.empid FROM payroll pays WHERE NOT EXISTS (SELECT * FROM payroll payx WHERE pays.salary = 189170))
ORDER BY per.empid, per.lname;

-- Average Planning 0.13 ms
-- Average Execution 5234.92 ms

/******************************************************************************/
/* In case the answer above is deemed to have unnecessary steps, please use below
    
SELECT per.empid, per.lname
FROM employee per 
WHERE per.empid is not NULL AND per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE NOT EXISTS (SELECT * FROM payroll pays WHERE pay.salary = 189170))
ORDER BY per.empid, per.lname;  
          
-- Indicate the average measured time for 20 executions for the query.
-- Average Planning 0.11 ms
-- Average Execution 5250.29 ms
                             */
/******************************************************************************/
