/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228984L                              */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, payroll pay
WHERE per.empid = pay.empid
AND pay.salary = 189170
ORDER BY per.empid, per.lname

-- Average Planning 0.32 ms for 100 runs
-- Average Execution 8.30 ms for 100 runs

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname

-- Average Planning 0.23 ms for 100 runs
-- Average Execution 10.95 ms for 100 runs

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.* FROM payroll pay) AS temp
WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname

-- Average Planning 0.24 ms for 100 runs
-- Average Execution 8.91 ms for 100 runs

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname

-- Average Planning 0.15 ms for 100 runs
-- Average Execution 22.05 ms for 100 runs

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT pay.empid,per.lname 
FROM payroll pay FULL OUTER JOIN employee per ON UPPER(pay.empid) = UPPER(per.empid)
WHERE pay.salary 
NOT IN(SELECT pay.salary FROM payroll pay WHERE pay.salary - 189170 + 2 <> 4 - 2) 
AND per.lname IN (SELECT a1.lname from employee a1,employee b1 where a1.empid <> b1.empid)
UNION 
SELECT pay.empid,per.lname 
FROM payroll pay RIGHT JOIN employee per ON UPPER(pay.empid) LIKE UPPER(per.empid)
WHERE pay.salary 
NOT IN(SELECT pay.salary FROM payroll pay WHERE pay.salary - 189170 <> 
       (SELECT COUNT(*) * 0 FROM 
            (SELECT pay.empid,per.lname 
            FROM employee per LEFT JOIN payroll pay on UPPER(pay.empid) LIKE UPPER(per.empid)
            WHERE pay.salary NOT IN(SELECT pay.salary FROM payroll pay WHERE pay.salary -189170 + 6 <> 6)
            ) as abc)) 
AND per.lname IN (SELECT a1.lname from employee a1,employee b1 where a1.empid <> b1.empid)

-- Average Planning 1.77 ms for 20 runs
-- Average Execution  567570.19 ms for 20 runs

/******************************************************************************/
