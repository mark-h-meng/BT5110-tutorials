/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0243772B                               */
/******************************************************************************/
SELECT test('SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname', 1000);
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170 AND per.lname IS NOT NULL
ORDER BY per.empid, per.lname;

-- Average Planning 0.10 ms
-- Average Execution 2.77 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid 
					FROM payroll pay
				    WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Average Planning 0.09 ms
-- Average Execution 2.52 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid
					    FROM payroll pay
					    WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.07 ms
-- Average Execution 6.00 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (SELECT pay.empid
					    FROM payroll pay
					    WHERE pay.salary <> 189170
		  				AND pay.empid = per.empid)
ORDER BY per.empid, per.lname;

-- Average Planning 0.08 ms
-- Average Execution 5152.22 ms
