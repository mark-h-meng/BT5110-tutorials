/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232481L                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary is null or pay.salary >= 0
ORDER BY per.empid, per.lname;

-- Average Planning 0.08 ms
-- Average Execution 10.68 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT *
FROM employee per, (select payroll.empid is not null from payroll limit 1 ) AS temp
WHERE per.empid is not null
ORDER BY per.empid, per.lname;

-- Average Planning 0.06 ms
-- Average Execution 5.72 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT state from employee per2)
ORDER BY per.empid, per.lname;

-- Average Planning 0.04 ms
-- Average Execution 6.64 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

select empid, lname
from ( 
		(	
			(SELECT per.empid, per.lname, pay.empid empid2, pay.salary 
			from  employee per join payroll pay on true)
			except
			(SELECT per.empid, per.lname, pay.empid empid2, pay.salary
			from  employee per join payroll pay on per.empid <> pay.empid)
		)
		except
		(SELECT per.empid, per.lname, pay.empid empid2, pay.salary
		from  employee per join payroll pay on pay.salary <> 189170
		)
) results
order by empid, lname

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.35 ms
-- Average Execution 1634638.38 ms
