/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0144362L                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;',1000);

/* Over 100 iterations: Average planning time 0.08ms, Average execution time 3.77ms
Over 1000 iterations: Average planning time 0.07ms, Average execution time 3.70ms*/

 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary=189170
WHERE pay.salary=189170
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary=189170
WHERE pay.salary=189170
ORDER BY per.empid, per.lname;',1000);

/*Over 100 iterations: Average planning time is 0.09ms, Average execution time is 3.85ms
Over 1000 iterations: Average planning time is 0.08ms, Average execution time is 3.69ms*/

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary FROM payroll pay ) AS temp
WHERE temp.salary=189170 AND per.empid=temp.empid
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary FROM payroll pay ) AS temp
WHERE temp.salary=189170 AND per.empid=temp.empid
ORDER BY per.empid, per.lname;', 1000);

/*Over 100 iterations: Average planning time 0.09ms, Average execution time 3.86ms
Over 1000 iterations: Average planning time 0.07ms, Average execution time 3.71ms*/


/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT per.empid
					   FROM employee per, payroll pay
					   WHERE per.empid=pay.empid AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT per.empid
					   FROM employee per, payroll pay
					   WHERE per.empid=pay.empid AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;', 1000);

/*Over 100 iterations: Average planning time 0.12ms, Average execution time 16.64ms
Over 1000 iterations: Average planning time 0.11ms, Average execution time 16.48ms*/

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT fcc.empid, fcc.lname
FROM (SELECT per.empid, per.lname
      FROM employee per
      UNION
     (SELECT per.empid,per.lname
      FROM employee per
      WHERE per.empid NOT IN ( SELECT per.empid
                               FROM employee per
                               INNER JOIN
                               ((SELECT per.empid,
                                 CASE WHEN per.empid>pay.empid THEN 1 END AS wanted
                                 FROM employee per, payroll pay
                                 WHERE (CASE WHEN per.empid > pay.empid THEN 1 END)=1)
                                 UNION
                                (SELECT per.empid,
                                 CASE WHEN per.empid<pay.empid THEN 1 END AS wanted
                                 FROM employee per, payroll pay
                                 WHERE CASE WHEN per.empid<pay.empid THEN 1 END =1))fee
                                 ON fee.empid=per.empid)))fcc
                                 INNER JOIN
                                (SELECT pay.empid
                                 FROM payroll pay
                                 WHERE pay.empid NOT IN (SELECT pay.empid
                                                         FROM payroll pay
                                                         INNER JOIN
                                                         ((SELECT pay.empid,
                                                           COUNT(CASE WHEN pay.salary>189170 THEN 1 END) AS wanted
                                                           FROM payroll pay
                                                           GROUP BY pay.empid
                                                           HAVING COUNT(CASE WHEN pay.salary>189170 THEN 1 END)= (SELECT MAX(wanted)
                                                                                                                  FROM(SELECT pay.empid,
                                                                                                                       CASE WHEN pay.salary>189170 THEN 1 END AS wanted
                                                                                                                       FROM payroll pay
                                                                                                                       GROUP BY pay.empid, pay.salary
                                                                                                                       ORDER BY pay.empid,pay.salary)temp, payroll pay)
                                                                                                                       UNION
                                                                                                                       SELECT pay.empid,
                                                                                                                       COUNT(CASE WHEN pay.salary<189170 THEN 1 END) AS wanted
                                                                                                                       FROM payroll pay
														                                                               GROUP BY pay.empid
                                                                                                                       HAVING COUNT(CASE WHEN pay.salary<189170 THEN 1 END)=(SELECT MAX(wanted)
																													                                                         FROM(SELECT pay.empid,
                                                                                                                                                                                  CASE WHEN pay.salary<189170 THEN 1 END AS wanted
                                                                                                                                                                                  FROM payroll pay
                                                                                                                                                                                  GROUP BY pay.empid, pay.salary
                                                                                                                                                                                  ORDER BY pay.empid,pay.salary)temp, payroll pay)))faa
	                                                                                                                                                                              ON faa.empid=pay.empid))fdd
																																												  ON fcc.empid=fdd.empid
                                                                                                                                                                                  ORDER BY fcc.empid, fcc.lname;
																																												  
																																												  
SELECT test ('SELECT fcc.empid, fcc.lname
FROM (SELECT per.empid, per.lname
      FROM employee per
      UNION
     (SELECT per.empid,per.lname
      FROM employee per
      WHERE per.empid NOT IN ( SELECT per.empid
                               FROM employee per
                               INNER JOIN
                               ((SELECT per.empid,
                                 CASE WHEN per.empid>pay.empid THEN 1 END AS wanted
                                 FROM employee per, payroll pay
                                 WHERE (CASE WHEN per.empid > pay.empid THEN 1 END)=1)
                                 UNION
                                (SELECT per.empid,
                                 CASE WHEN per.empid<pay.empid THEN 1 END AS wanted
                                 FROM employee per, payroll pay
                                 WHERE CASE WHEN per.empid<pay.empid THEN 1 END =1))fee
                                 ON fee.empid=per.empid)))fcc
                                 INNER JOIN
                                (SELECT pay.empid
                                 FROM payroll pay
                                 WHERE pay.empid NOT IN (SELECT pay.empid
                                                         FROM payroll pay
                                                         INNER JOIN
                                                         ((SELECT pay.empid,
                                                           COUNT(CASE WHEN pay.salary>189170 THEN 1 END) AS wanted
                                                           FROM payroll pay
                                                           GROUP BY pay.empid
                                                           HAVING COUNT(CASE WHEN pay.salary>189170 THEN 1 END)= (SELECT MAX(wanted)
                                                                                                                  FROM(SELECT pay.empid,
                                                                                                                       CASE WHEN pay.salary>189170 THEN 1 END AS wanted
                                                                                                                       FROM payroll pay
                                                                                                                       GROUP BY pay.empid, pay.salary
                                                                                                                       ORDER BY pay.empid,pay.salary)temp, payroll pay)
                                                                                                                       UNION
                                                                                                                       SELECT pay.empid,
                                                                                                                       COUNT(CASE WHEN pay.salary<189170 THEN 1 END) AS wanted
                                                                                                                       FROM payroll pay
														                                                               GROUP BY pay.empid
                                                                                                                       HAVING COUNT(CASE WHEN pay.salary<189170 THEN 1 END)=(SELECT MAX(wanted)
																													                                                         FROM(SELECT pay.empid,
                                                                                                                                                                                  CASE WHEN pay.salary<189170 THEN 1 END AS wanted
                                                                                                                                                                                  FROM payroll pay
                                                                                                                                                                                  GROUP BY pay.empid, pay.salary
                                                                                                                                                                                  ORDER BY pay.empid,pay.salary)temp, payroll pay)))faa
	                                                                                                                                                                              ON faa.empid=pay.empid))fdd
																																												  ON fcc.empid=fdd.empid
                                                                                                                                                                                  ORDER BY fcc.empid, fcc.lname;',20)																																												  
																																												  

 

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 2.21 ms
-- Average Execution 652573.95 ms
						


