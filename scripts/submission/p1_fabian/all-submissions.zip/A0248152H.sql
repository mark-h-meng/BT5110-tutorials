/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0248152H                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below     
SELECT test('SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.salary IS NOT NULL
ORDER BY per.empid, per.lname;', 1000); , output: "0.02 : 1.18"                                      
*//******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.salary IS NOT NULL
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below     
SELECT test('SELECT per.empid, per.lname
FROM employee per, (SELECT salary, empid FROM payroll) AS temp
WHERE temp.empid = per.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;', 1000); , output : "0.02 : 1.03"                                             
*//******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT salary, empid FROM payroll) AS temp
WHERE temp.empid = per.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below
SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary <> 189170) 
ORDER BY per.empid, per.lname;', 1000); , output: "0.01 : 2.48”                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid 
FROM payroll pay WHERE pay.salary <> 189170) 
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid != ALL (
	SELECT pay.empid 
	FROM payroll pay 
	WHERE pay.salary <> 189170) 
ORDER BY per.empid, per.lname DESC;
-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.05 ms
-- Average Execution 3005.73 ms
