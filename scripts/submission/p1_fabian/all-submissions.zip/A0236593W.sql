/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0236593W                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.empid  IS NOT NULL AND per . empid IS NOT NULL
ORDER BY per.empid, per.lname;
--Execution Time: 26.133 ms
--Planning Time: 0.015 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll pay) AS temp 
WHERE temp . salary = 189170 AND temp.empid = per.empid
ORDER BY per.empid, per.lname;
--Execution Time: 26.187 ms
--planning time: 0.015 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per . empid NOT IN ( SELECT pay.empid FROM payroll pay WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;
--Execution Time: 27.364 ms
--Planning Time: 0.015 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname  
FROM employee per 
WHERE  per . empid != ALL(  	
			SELECT pay.empid  	
			FROM payroll pay  	
			WHERE pay.salary != 189170 	
			AND pay.empid = per.empid)  
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.030> ms
-- Average Execution <2773.3> ms
