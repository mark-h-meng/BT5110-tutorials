/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232973Y                             */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.empid <> '' AND per.empid <> '' AND pay.salary <> 0 
ORDER BY per.empid, per.lname;

"0.11 : 12.46"
/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname;

"0.12 : 3.28"
/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary <>189170)
ORDER BY per.empid, per.lname;

"0.09 : 6.29"
/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT DISTINCT per.empid, per.lname 
FROM employee per, payroll pay
WHERE EXISTS(
	(SELECT * FROM payroll pay WHERE
	per.empid = pay.empid ORDER BY random())
	INTERSECT
	(SELECT * FROM payroll pay WHERE
	pay.salary = 189170 ORDER BY random())
)  
ORDER BY per.empid, per.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.15 ms
-- Average Execution 16607.11 ms



-----------------------------------------------------------------------------------------------
-- 2nd solution if the previous solution is categorized as multiple joining:
SELECT DISTINCT per.empid, per.lname 
FROM employee per, payroll pay
WHERE EXISTS(
	SELECT * FROM payroll pay WHERE
	per.empid = pay.empid AND pay.salary = 189170
)  
ORDER BY per.empid, per.lname;
-- Average Planning 0.14 ms
-- Average Execution 29.95 ms
