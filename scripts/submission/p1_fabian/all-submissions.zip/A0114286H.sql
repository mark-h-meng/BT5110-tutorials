/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0114286H                              */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
--"0.05 : 2.57"
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.empid IS NOT NULL and per.empid is not null
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
--"0.06 : 3.30"
SELECT per.empid, per.lname
FROM employee per, (SELECT empid from payroll where salary=189170) AS temp
WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
--"0.05 : 6.43"
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid from payroll where salary<>189170)
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT distinct per.empid, (select distinct lname from employee c where empid NOT IN (SELECT empid from (select * from payroll where salary<>189170)d where salary<>189170)and c.empid=per.empid) as lname
FROM employee per,payroll pay
WHERE per.empid NOT IN (SELECT empid from (select * from payroll where salary<>189170)a where salary<>189170)
  and per.empid in (SELECT empid from (select * from payroll where salary=189170)b where salary=189170)
group by per.empid, (select distinct lname from employee c where empid NOT IN (SELECT empid from (select * from payroll where salary<>189170)d where salary<>189170)and c.empid=per.empid)
ORDER BY per.empid, (select distinct lname from employee c where empid NOT IN (SELECT empid from (select * from payroll where salary<>189170)d where salary<>189170)and c.empid=per.empid)
--"0.23 : 247279.94"

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> 0.23
-- Average Execution <time> 247279.94
