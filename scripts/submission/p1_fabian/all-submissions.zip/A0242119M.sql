/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0242119M                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL
ORDER BY per.empid, per.lname;
-- Average Planning Time: 0.09ms
-- Average Execution Time: 5.35ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
-- Average Planning Time: 0.08ms
-- Average Execution Time: 4.64ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid FROM payroll pay WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;
--Average Planning Time: 0.08ms
--Average Execution Time: 8.64ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT comb.per_empid AS empid, comb.per_lname AS lname
FROM
	(
		(
			SELECT per.empid AS per_empid, per.lname AS per_lname, pay.empid AS pay_empid, pay.salary AS pay_salary
			FROM employee per FULL OUTER JOIN payroll pay 
			ON per.empid = pay.empid
		)
		INTERSECT
		(
			SELECT per.empid AS per_empid, per.lname AS per_lname, pay.empid AS pay_empid, pay.salary AS pay_salary
			FROM employee per LEFT OUTER JOIN payroll pay 
			ON per.empid = pay.empid
		)
		INTERSECT
		(
			SELECT per.empid AS per_empid, per.lname AS per_lname, pay.empid AS pay_empid, pay.salary AS pay_salary
			FROM employee per RIGHT OUTER JOIN payroll pay 
			ON per.empid = pay.empid
		)
	) AS comb
WHERE comb.per_empid IS NOT NULL AND comb.pay_empid IS NOT NULL
AND (comb.per_empid, comb.pay_salary) NOT IN (
	SELECT DISTINCT pay1.empid, pay1.salary
	FROM payroll pay1 
	WHERE (pay1.empid = comb.per_empid OR pay1.empid > comb.per_empid OR pay1.empid < comb.per_empid)
	AND NOT EXISTS (
			(
				SELECT DISTINCT pay2.empid, pay2.salary
				FROM payroll pay2 
				WHERE pay2.empid = pay1.empid AND pay2.empid = comb.per_empid
				GROUP BY pay2.empid, pay2.salary
				HAVING COUNT(*) >= 1
			)
			EXCEPT 
			(
				SELECT DISTINCT pay3.empid, pay3.salary
				FROM payroll pay3 
				WHERE pay3.salary > 189170 
				AND pay3.empid = pay1.empid AND pay3.empid = comb.per_empid
				GROUP BY pay3.empid, pay3.salary
				HAVING COUNT(*) >= 1
			)
			EXCEPT
			(
				SELECT DISTINCT pay4.empid, pay4.salary
				FROM payroll pay4 
				WHERE pay4.salary < 189170 
				AND pay4.empid = pay1.empid AND pay4.empid = comb.per_empid
				GROUP BY pay4.empid, pay4.salary
				HAVING COUNT(*) >= 1
			)
	)
	GROUP BY pay1.empid, pay1.salary
	HAVING COUNT(*) >= 1
)
ORDER BY comb.per_empid, comb.per_lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.90 ms
-- Average Execution 1385986.65 ms
