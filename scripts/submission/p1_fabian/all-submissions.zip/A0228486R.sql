/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0228486R                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT salary,empid from payroll) AS temp
WHERE temp.salary = 189170 and per.empid = temp.empid
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid from payroll pay where pay.salary != 189170)
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT a.empid, a.lname FROM ( SELECT per.empid, per.lname, per.fname, per.address, per.city, per.zip, per.state
FROM employee per FULL OUTER JOIN payroll pay on per.empid = pay.empid
WHERE not exists (SELECT pay.empid
                     FROM payroll pay
				  	 left join employee emp
				     on pay.empid = emp.empid
                     WHERE per.empid not in(
						 select p.empid from 
						 (select p1.empid, p1.bonus, p1.salary
						  	 from payroll p1
							 where p1.salary = 189170
							 ORDER BY per.empid , per.lname) p
						 )
				  	 ORDER BY pay.bonus
				 ) ORDER BY per.empid , per.lname
) a;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.22 ms
-- Average Execution 62192.21 ms
