/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0190367Y                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

/*
average over 100 iterations: 
planning: 0.08
execution: 2.19
*/

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid 
		    FROM payroll pay
		    WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

/*
average over 100 iterations: 
planning: 0.09
execution: 2.55
*/

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid
			FROM payroll pay
			WHERE pay.salary != 189170)
ORDER BY per.empid, per.lname;

/*
average over 10 iterations: 
planning: 0.19
execution: 17.06
*/

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT per1.empid
			FROM employee per1, payroll pay
			WHERE pay.salary < 189170
			AND per.empid = pay.empid) AND
			per.empid 
		NOT IN (SELECT per2.empid
		   	FROM employee per2, payroll pay1
		   	WHERE pay1.salary > 189170
		   	AND per2.empid = pay1.empid)
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.43 ms
-- Average Execution 40376.15 ms

/*
Not sure if my answer for Question 3 could be deemed as "unnecessary" 
by the marking team, so I prepared an alternative: 
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT per1.empid
			FROM employee per1, payroll pay
			WHERE pay.salary != 189170
			AND per.empid = pay.empid)
ORDER BY per.empid, per.lname;

-- Average Planning 0.23
-- Average Execution 43545.71
(ran the test twice with 20 iterations each and got very different results)
-- Average Planning 0.11
-- Average Execution 17081.77 
*/