/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0243773Y                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.40 ms
-- Average Execution 10.61 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary from payroll) AS temp
WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning 0.38 ms
-- Average Execution 10.62 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid from payroll where salary <> 189170)
ORDER BY per.empid, per.lname;

-- Average Planning 0.24 ms
-- Average Execution 22.35 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT Distinct per.empid, per.lname 
	FROM employee per, payroll pay
	WHERE 
	Exists(
		SELECT * from (
			SELECT Count(Distinct payroll.empid) as records from payroll 
			where per.empid=payroll.empid and 
			pay.empid=per.empid and pay.salary=payroll.salary 
			and payroll.salary=189170
		) As temp where temp.records>0
	)	
ORDER BY per.empid, per.lname;

-- Average Planning 0.16 ms
-- Average Execution 144911.99 ms



