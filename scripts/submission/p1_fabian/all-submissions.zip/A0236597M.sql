/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0236597M                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null and per.lname is not null and pay.salary is not null
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * from payroll where payroll.salary=189170) AS temp
WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid from payroll pay where pay.salary!=189170)
ORDER BY per.empid, per.lname;


/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname, pay.salary
from employee per, payroll pay
where per.empid not in (
	select empid
	from payroll
	where salary <= (select max(salary) from payroll)
	and salary >= (select min(salary) from payroll)
	)
or pay.salary*10 = 1891700
and per.empid = pay.empid
order by per.empid, per.lname

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.13> ms
-- Average Execution <23653.59> ms
