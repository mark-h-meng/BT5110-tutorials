/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0248551                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay 
WHERE per.empid = pay.empid 
AND pay.salary = 189170 
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170 
WHERE pay.salary = 189170 
ORDER BY per.empid, per.lname;
    test
-------------
 0.14 : 1.05
/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname FROM employee per, 
(SELECT * from payroll pay) AS temp 
WHERE per.empid=temp.empid AND temp.salary=189170 
ORDER BY per.empid, per.lname;
    test
-------------
 0.15 : 1.09
(1 row)
/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname FROM employee per 
WHERE per.empid NOT IN 
(SELECT e.empid from employee e,  
payroll p where e.empid=p.empid 
AND NOT p.salary=189170) 
ORDER BY per.empid, per.lname;
     test
--------------
 0.22 : 11.41
(1 row)


/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname FROM employee per 
WHERE per.empid NOT IN 
(SELECT e.empid from employee e FULL JOIN  
payroll p ON e.empid=p.empid  where NOT p.salary=189170) 
AND per.lname NOT IN 
(SELECT e.lname from employee e FULL JOIN  
payroll p ON e.empid=p.empid  where NOT p.salary=189170)
ORDER BY per.empid, per.lname;

     test
--------------
 0.38 : 20.37

-- Average Planning 0.38 ms
-- Average Execution 20.37 ms
