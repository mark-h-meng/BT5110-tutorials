/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0236578N                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.empid IS NOT NULL 
ORDER BY per.empid, per.lname;

-- Average Planning time/Average Execution time Over 100 executions:
-- ap/ae: 0.16ms/4.81ms
-- ap/ae: 0.16ms/4.57ms
-- ap/ae: 0.15ms/4.66ms
-- ap/ae: 0.16ms/4.40ms
-- ap/ae: 0.15ms/4.17ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Average Planning time/Average Execution time Over 100 executions:
-- ap/ae: 0.14ms/4.06ms
-- ap/ae: 0.15ms/3.86ms
-- ap/ae: 0.16ms/3.90ms
-- ap/ae: 0.14ms/3.79ms
-- ap/ae: 0.16ms/3.91ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll pay WHERE pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Average Planning time/Average Execution time Over 100 executions:
-- ap/ae: 0.11ms/9.21ms
-- ap/ae: 0.10ms/9.17ms
-- ap/ae: 0.12ms/10.36ms
-- ap/ae: 0.12ms/11.81ms
-- ap/ae: 0.11ms/9.68ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE 1 > (SELECT COUNT(*) FROM payroll pay WHERE per.empid = pay.empid AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.11 ms
-- Average Execution 18606.84 ms
