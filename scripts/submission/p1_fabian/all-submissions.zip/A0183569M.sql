/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0183569M                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND pay.salary IS NOT NULL
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid empid
					FROM payroll pay
					WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT per2.empid
						FROM employee per2, payroll pay
						WHERE per2.empid = pay.empid AND pay.salary <> 189170
						UNION
						SELECT per3.empid
						FROM employee per3
						WHERE per3.empid NOT IN (SELECT pay2.empid
												 FROM payroll pay2))
ORDER BY per.empid, per.lname;

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
 SELECT per.empid, per.lname
 FROM employee per
 WHERE per.empid NOT IN (SELECT per2.empid
						 FROM employee per2, payroll pay
						 WHERE per2.empid = pay.empid
						 AND pay.salary IN (SELECT pay2.salary
											FROM payroll pay2
											WHERE pay2.empid = pay.empid AND pay2.salary < 189170
											UNION
											SELECT pay3.salary
											FROM payroll pay3
											WHERE pay3.empid = pay.empid
											AND pay3.empid NOT IN (SELECT pay4.empid
																   FROM payroll pay4
																   WHERE pay4.salary <= 189170))
						 UNION
						 SELECT per3.empid
						 FROM employee per3
						 WHERE per3.empid NOT IN (SELECT pay5.empid
												  FROM payroll pay5))
 ORDER BY per.empid, per.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.86 ms
-- Average Execution 78146.51 ms
