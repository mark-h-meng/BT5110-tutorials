/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0248360E                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;

-- Average Planning Time: 0.11ms
-- Average Execution Time: 3.00ms
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
-- SELECT per.empid, per.lname
-- FROM employee per FULL OUTER JOIN payroll pay 
    -- ON per.empid = pay.empid AND pay.salary = 189170
-- WHERE TRUE
-- ORDER BY per.empid, per.lname;

-- -- -- Ans
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay
ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL AND  pay.empid IS NOT NULL
ORDER BY per.empid, per.lname;

-- -- -- Test
-- SELECT test('SELECT per.empid, per.lname
-- FROM employee per FULL OUTER JOIN payroll pay
-- ON per.empid = pay.empid AND pay.salary = 189170
-- WHERE per.empid IS NOT NULL AND  pay.empid IS NOT NULL
-- ORDER BY per.empid, per.lname;', 100);

-- 100 runs
-- Average Planning Time: 0.12ms
-- Average Execution Time: 3.44ms

-- 1000 run
-- Average Planning Time: 0.13ms 
-- Average Execution Time: 3.83ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
-- SELECT per.empid, per.lname
-- FROM employee per, (SELECT TRUE) AS temp
-- WHERE TRUE
-- ORDER BY per.empid, per.lname;

-- -- -- Ans
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid
					FROM payroll pay
					WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- -- -- Test
-- SELECT test('SELECT per.empid, per.lname
-- FROM employee per, (SELECT pay.empid
-- 					FROM payroll pay
-- 					WHERE pay.salary = 189170) AS temp
-- WHERE per.empid = temp.empid
-- ORDER BY per.empid, per.lname;', 100);

-- 100 runs
-- Average Planning Time: 0.09ms
-- Average Execution Time: 2.54ms

-- 1000 runs
-- Average Planning Time: 0.13ms 
-- Average Execution Time: 3.28ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
-- SELECT per.empid, per.lname
-- FROM employee per
-- WHERE per.empid NOT IN (SELECT 'TRUE')
-- ORDER BY per.empid, per.lname;

-- -- -- Ans
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT pay.empid 
						FROM payroll pay 
						WHERE pay.salary < 189170 
						OR pay.salary > 189170)
ORDER BY per.empid, per.lname;

-- -- -- Test
-- SELECT test('SELECT per.empid, per.lname
-- FROM employee per
-- WHERE per.empid NOT IN (SELECT pay.empid 
-- 						FROM payroll pay 
-- 						WHERE pay.salary < 189170 
-- 						OR pay.salary > 189170)
-- ORDER BY per.empid, per.lname;', 100);

-- 100 runs
-- Average Planning Time: 0.10ms
-- Average Execution Time: 7.28ms

-- 1000 runs
-- Average Planning Time: 0.12ms
-- Average Execution Time: 9.60ms

/******************************************************************************/
/* Answer Question 3 below                                                    */
/******************************************************************************/
-- Inspiration from Boolean Algebra
-- AB = (AB)'' = (A' + B')'
-- A - same empid
-- B - salary = 189170

-- -- -- Ans
SELECT empid, lname
FROM employee 
WHERE empid NOT IN (SELECT e.empid 
					FROM employee e CROSS JOIN payroll p
					WHERE e.empid NOT IN (SELECT empid FROM payroll)
					UNION
				   	SELECT pay.empid 
					FROM payroll pay 
					WHERE pay.salary < 189170 
					OR pay.salary > 189170
				   )
ORDER BY empid, lname;

-- -- -- Test
-- SELECT test('SELECT empid, lname
-- FROM employee 
-- WHERE empid NOT IN (SELECT E.empid 
-- 					FROM employee E CROSS JOIN payroll P
-- 					WHERE E.empid NOT IN (SELECT empid FROM payroll)
-- 					UNION
-- 				   	SELECT empid 
-- 					FROM payroll
-- 					WHERE salary < 189170 
-- 					OR salary > 189170
-- 				   )
-- ORDER BY empid, lname;', 20);

-- 20 runs
-- Average Planning Time: 0.16 ms
-- Average Execution Time: 6156.56 ms

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> ms
-- Average Execution <time> ms
