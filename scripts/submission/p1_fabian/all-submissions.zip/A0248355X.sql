/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0248355X                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170
ORDER BY per.empid, per.lname;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per FULL OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE TRUE
ORDER BY per.empid, per.lname;

Ans:
 SELECT per . empid , per . lname
 FROM employee per FULL OUTER JOIN payroll pay
 ON per . empid = pay . empid AND pay . salary = 189170
 WHERE pay . salary = 189170
 ORDER BY per . empid , per . lname

Comment: Execution of 100 query: 
Average Planning <0.05> ms
Average Execution <1.37> ms


/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT TRUE) AS temp
WHERE TRUE
ORDER BY per.empid, per.lname;

Ans:
 SELECT per.empid, per.lname
 FROM employee per, (SELECT * from payroll) AS temp
 WHERE per . empid = temp . empid and  temp . salary = 189170
 ORDER BY per.empid, per.lname;

Comment - Execution of 100 query:
Average Planning <0.05> ms
Average Execution <1.40> ms



/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT 'TRUE')
ORDER BY per.empid, per.lname;

Ans:
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (SELECT empid from payroll p where p.salary <> 189170 )
ORDER BY per.empid, per.lname;

Comment - Execution of 100 query:
Average Planning <0.04> ms
Average Execution <3.24> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
 
 SELECT 
 p.empid , per . lname 
 FROM employee per , payroll p 
 INTERSECT
 SELECT 
 p.empid , per . lname 
 FROM employee per , payroll p 
 WHERE p.salary = 189170
 INTERSECT
 SELECT 
 p.empid , per . lname 
 FROM employee per , payroll p 
 WHERE p.empid = per.empid
 order by empid, lname


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.18> ms
-- Average Execution <1094350.09> ms
