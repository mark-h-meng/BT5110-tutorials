/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218923B        */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name, continent_code FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT ap.name AS app, C.name AS country
FROM app AS ap, available AS ava, country AS C, store AS s1, store as s2, appfunctionality as apf
WHERE ap.name = ava.name
AND ava.country = C.code3
AND C.continent_name = 'Europe' 
AND ap.name = s1.name
AND s1.os = 'Android' 
AND s1.name = s2.name
AND s2.os = 'iOS'
AND ava.name = apf.name 
AND apf.functionality='contact tracing';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT name FROM country 
GROUP BY name 
HAVING count(*)>1 
ORDER BY name ASC;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c1.name AS name 
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_name!=c2.continent_name
ORDER BY name ASC;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT ap.name AS app
FROM app AS ap, available AS ava, country AS C, store AS s, appfunctionality as apf, store AS s2
WHERE ap.name = ava.name
AND ava.country = C.code3
AND C.continent_name = 'Oceania' 
AND ap.name = s.name
AND s.name = s2.name
AND s.os <> s2.os;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT C.name, count (ap.name)
FROM app AS ap
RIGHT JOIN available AS ava ON ap.name = ava.name
JOIN country AS C ON ava.country = C.code3
GROUP BY C.name 
ORDER BY count (ap.name) DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS E1 (
	A VARCHAR(50) NOT NULL,
	B VARCHAR(50) NOT NULL,
	C VARCHAR(50) NOT NULL,
	D VARCHAR(50) NOT NULL,
    PRIMARY KEY(C,D,A)
);

CREATE TABLE IF NOT EXISTS E2(
    G VARCHAR(50)  PRIMARY KEY,
    H VARCHAR(50) NOT NULL,
    J VARCHAR(50) NOT NULL,
    K VARCHAR(50) UNIQUE NOT NULL
    );


CREATE TABLE IF NOT EXISTS t_bookmark (
    F VARCHAR(50) NOT NULL,
    G VARCHAR(50) NOT NULL,
    A VARCHAR(50) NOT NULL,
	C VARCHAR(50) NOT NULL,
	D VARCHAR(50) NOT NULL,
    PRIMARY KEY (G,C,D,A),
    FOREIGN KEY (C,D,A) REFERENCES E1(C,D,A) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE,
    FOREIGN KEY (G) REFERENCES E2(G) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE
    
);


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*


Real word example: It can be 1 employee only can have 1-1 relationship to 1 company but 
the 1 employee can do multiple projects. 


G is the primary key of E2,
E2 and S have zero or more relationship while E1 and S only have 1 to 1 relationship.
E1 has A, C, D as composited primary key.
S is the relationship between E1 and E2 table.

E2 can be project 
E1 can be Company 
and S can be employee.



reference: https://www.google.com/search?q=(o,n)+ER+diagram+means&rlz=1C5CHFA_enSG922SG922&sxsrf=AOaemvKuNvde5fn4RwZqY5RWYz3xlLgXJA:1632918322920&tbm=isch&source=iu&ictx=1&fir=wDbVgXtvuKnXcM%252CYKJRzGQ7GYRN0M%252C_&vet=1&usg=AI4_-kRHf2fkmjOaj16YJmaquPtO4VfBYA&sa=X&ved=2ahUKEwiXldbklqTzAhWDvJ4KHS8oAA8Q9QF6BAgXEAE&biw=1440&bih=631&dpr=2#imgrc=wDbVgXtvuKnXcM


*/

