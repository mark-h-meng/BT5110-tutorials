/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number :A023945A                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.continent_name,c.continent_code
from country c
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name as app, c.name as country
from available a,store s,country c,appfunctionality ff
where a.name=s.name
and a.country=c.code3
and ff.name=a.name
and c.continent_name='Europe'
and s.os='iOS'
and ff.functionality='contact tracing'
intersect 
select a.name as app, c.name as country
from available a,store s,country c,appfunctionality ff
where a.name=s.name
and a.country=c.code3
and ff.name=a.name
and c.continent_name='Europe'
and s.os='Android'
and ff.functionality='contact tracing'

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c 
group by c.name
having count(c.continent_name)>=2

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.name
from country c
except
select c.name
from country c
where not exists(
	select *
	from country cc
	where c.name=cc.name
	and c.continent_name<>cc.continent_name
)
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name
from available a,country c
where c.continent_name='Oceania'
and a.country=c.code3
and not exists
(
	select *
	from store ss
	where not exists(
		select *
		from store s
		where s.name=a.name
		and s.os=ss.os
	)
)

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name,temp.count
from(
select a.country,count(a.name) as count
from available a
group by a.country
order by count(a.name) desc
limit 6)as temp, country c
where temp.country=c.code3
order by temp.count desc


/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table if not exists E2(
	J varchar(64) not null,
	K varchar(64) not null,
	G varchar(64) primary key,
	H varchar(64) not null
)
 
create table if not exists E1_S(
	A varchar(64) not null,
	B varchar(64) not null,
	C varchar(64) not null,
	D varchar(64) not null,
	F varchar(64) not null,
	primary key(A,C,D),
	G varchar(64) not null references E2(G)
)


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
The E1 represents the set of wines. Each of wines is identified 
by its name(Parade D'Amour), appellation(Bordeaux) and vintage(1980).
Thus, (A, B D) is (name,appellation, vintage). C represents the degree of alcohol.
The primary key for E1 is (A,C,D)

E2 represents the brand of wine（like Martell). attribute G is the name of 
the brand, because we can indentity the brand by its name. While J, K H represnts
the start time of the brand, the name of Legal Representative, the birthplace of the brand.
Because these three attributes are important as well.

R represents a kind of affiliation. Each wine should belong to one specific brand.
While each brand may contain multiple wines and some brands do not have any wines
because the brand do not produce wines, it produces xo，whiskey etc.
and the attribut of R, F represents whether this wine is the main product of this brand.
If this wine is the brand main product, then F is 'is main product', otherwise, F is 'is not main product'.



*/

