/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231894X						                    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT av.name AS app, c.name AS country
FROM available av, store s1, country c, store s2, appfunctionality af
WHERE s1.name = av.name
AND s1.name = s2.name
AND c.code3 = av.country
AND s1.os = 'iOS'
AND s2.os = 'Android'
AND c.continent_code = 'EU'
AND af.name = s1.name
AND af.functionality = 'contact tracing';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(DISTINCT c.continent_name) > 1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_name <> c2.continent_name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT av.name
FROM available av
WHERE NOT EXISTS(
	SELECT *
	FROM store s	
	WHERE av.name = s.name
	AND NOT EXISTS(
		SELECT *
		FROM country c, store s1, available av1
		WHERE c.continent_name = 'Oceania'
		AND av.country = c.code3
	)
);
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(DISTINCT av.name)
FROM country c, available av
WHERE av.country = c.code3
GROUP BY c.name
ORDER BY COUNT(DISTINCT av.name) DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1(
	A TEXT NOT NULL,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	PRIMARY KEY (A, C, D)
);
CREATE TABLE E2(
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL,
	J TEXT NOT NULL,
	K TEXT NOT NULL
);
CREATE TABLE S(
	F TEXT NOT NULL,
	A TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	PRIMARY KEY (A, C, D),
	FOREIGN KEY (A, C, D) REFERENCES E1(A, C, D),
	G TEXT REFERENCES E2(G)
);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Set E1 is a student set and A is the e-mail of students, B is gender of students, 
C is family name of students, D is first name of students. Set E2 is a university 
set and G is school name, H is the QS rank for the school this year, J and K is 
country and city the school locates in respectively. The set S records the school 
each student is studying in at present and F represents the faculty students are in. 
In the entity-relationship diagram, each record in E1 should have the only record in E2 
to correspond in S, so the set S records which college the student is in now. But the 
college in E2 may have no student in E1 to correspond, and also may have a lot of students 
to correspond. There is no limitation. The candidate key for E1 are (A, C, D) and the 
candidate key for E2 is (G). The candidate key for S is also (A, C, D). 


*/