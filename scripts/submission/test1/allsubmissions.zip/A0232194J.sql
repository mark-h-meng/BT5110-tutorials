/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0232194J>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name, continent_code FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name, c.name
FROM app a, available av, country c, store s1, store s2, appfunctionality af
WHERE a.name=av.name
AND av.country=c.code3
AND c.continent_code='EU'
AND a.name=af.name
AND a.name=s1.name
AND a.name=s2.name
AND s1.os='Android'
AND s2.os='iOS'
AND af.functionality='contact tracing';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT name FROM country
GROUP BY name
HAVING count(*)>1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.continent_name<>c2.continent_name
AND c1.name=c2.name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name FROM
app a, available av, store s1, store s2, country c
WHERE a.name=av.name
AND a.name=s1.name
AND a.name=s2.name
AND s1.os='Android'
AND s2.os='iOS'
AND av.country=c.code3
AND c.continent_code='OC';

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, count(*)
FROM app a, available av, country c
WHERE a.name=av.name AND av.country=c.code3
GROUP BY c.name
ORDER BY count(*) DESC
LIMIT 16;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1 (
	A TEXT NOT NULL ,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	PRIMARY KEY (A,C,D));

CREATE TABLE IF NOT EXISTS E2 (
	J TEXT NOT NULL,
	K TEXT NOT NULL,
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS S(
	F TEXT NOT NULL);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
For instance, the entity E1 could be applicants of a job. A is the name of applicants, B is age, C is email address,
and D is phone number. Name, email address, and phone number together is the primary key.
The entity E2 is the company, J is type of company, K is formed year of the company, H is the existing department of 
the company, and G is the registration number, which is a primary key to determine the company.
The relation is offer. Applicants can only accept one offer from a company, and company could decide to give zero or many 
offers to applicants.

*/

