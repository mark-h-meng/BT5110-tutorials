/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231869U>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT continent_name, continent_code
FROM country
GROUP BY continent_name, continent_code;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT a.name AS app, c.name AS country
FROM available a, store s, country c, appfunctionality af
WHERE a.name = s.name
AND a.name = af.name
AND af.functionality = 'contact tracing'
AND a.name in (SELECT s1.name
FROM store s1
GROUP BY s1.name
HAVING COUNT(s1.os) >1)
AND a.country in (SELECT c1.code3 as Ecountry
FROM country c1
WHERE c.continent_code = 'EU')
AND a.country = c.code3


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING count(c.name)>1
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c2.name
FROM country c1 LEFT JOIN country c2 ON c1.code2 = c2.code2 AND c1.continent_code <> c2.continent_code
WHERE c2.name IS NOT NULL
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT a.name
FROM available a, store s, country c
WHERE a.name = s.name
AND a.name in (
SELECT s1.name
FROM store s1, store s2
WHERE s1.name = s2.name
AND s1.os = 'iOS'
AND s2.os = 'Android')
AND a.country in (SELECT c1.code3 as Ecountry
FROM country c1
WHERE c.continent_code = 'OC')
AND a.country = c.code3
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, p.count
FROM country c
RIGHT JOIN
(SELECT a.country AS country, count(a.name) AS count
FROM available a
GROUP BY a.country
ORDER BY count DESC
LIMIT 6) p
ON p.country = c.code3
ORDER BY p.count DESC;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS E2 (
G TEXT,
J TEXT NOT NULL,
K TEXT NOT NULL,
H TEXT NOT NULL,
PRIMARY KEY (G));


CREATE TABLE IF NOT EXISTS E1 (
A TEXT NOT NULL UNIQUE ,
B TEXT NOT NULL,
C TEXT,
D TEXT,
F TEXT NOT NULL,
G TEXT,
PRIMARY KEY (C,D),
FOREIGN KEY (G) REFERENCES E2(G));


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 can be an entity table of cars registered, S is the relation "registered", and E2 is an entity table of person. So, a person can register 0-n cars while a
registered car can be registered only by one person.
In this case, for E1, A can be the car's unique attribute of 'registration number', B can be color. C can be state, and D can be licence, so combined C and D we can identify a car.
For relation S, we can make F be the attribute of registration expiry date.
For E2, we can make G, the primary key, id number for the person. J can be date of birth. K can be gender. H can be income.

*/
