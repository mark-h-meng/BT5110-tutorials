/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231875Y 							                */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
SELECT DISTINCT ct.continent_name, ct.continent_code
FROM country AS ct;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
SELECT avail.name, ct.name 
FROM available AS avail, country AS ct 
LEFT JOIN 
	SELECT a.name
	FROM app AS a, store AS s1, store AS s2
	WHERE a.name = s1.name
	AND a.name = s2.name 
	AND s1.os = 'iOS'
	AND s2.os = 'Android'
ON avail.name  = a.name
WHERE avail.country = ct.code3
AND ct.continent_name = 'Europe';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
SELECT DISTINCT ct.name, 
	(CASE WHEN ct2.frequency < 2 THEN 0 
	WHEN ct2.frequency >=2 THEN frequency END) AS frequency
FROM country AS ct, 
	(SELECT ct.name, count(ct.name) AS frequency
	FROM country AS ct 
	GROUP BY ct.name) AS ct2
WHERE ct.name = ct2.name 
AND frequency >=2;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
SELECT DISTINCT ct.name, 
	(CASE WHEN ct2.frequency < 2 THEN 0 
	WHEN ct2.frequency >=2 THEN frequency END) AS frequency
FROM country AS ct, 
	(SELECT ct.name, count(ct.name) AS frequency
	FROM country AS ct 
	GROUP BY ct.name) AS ct2
WHERE ct.name = ct2.name 
AND frequency >=2;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
SELECT ct.name
FROM country AS ct, available AS avail, app AS a 
WHERE ct.continent_code = 'Oceania'
AND ct3 = avail.country
AND avail.name = app.name 
AND avail.name IN (
	(SELECT a.name
	FROM app AS a, store AS s
	WHERE a.name = s.name
	AND s.os = 'iOS'
	INTERSECT
	SELECT a.name
	FROM app AS a, store AS s
	WHERE a.name = s.name
	AND s.os = 'Android')  
	
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
SELECT ct.name, sub.frequency
FROM country AS ct, 
	(SELECT count(avail.name) AS frequency
	FROM available AS avail, country AS ct 
	GROUP BY ct.name) AS sub 
ORDER BY sub.frequency DESC; 

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
-- E1 is parliment member, E2 is political party and S is belong_to. 
-- The name of the parliment memeber may not be unique, hence it requires the age(A), name  and gender as primary key. 
-- 


*/

