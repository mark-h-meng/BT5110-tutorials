/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218949L						                    */
/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name, continent_code
FROM country
ORDER BY continent_name, continent_code;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT europe_apps.app, europe_apps.country
FROM (
	SELECT name
	FROM store
	WHERE os = 'iOS' ) s1 INNER JOIN (
		SELECT name
		FROM store
		WHERE os = 'Android') s2
		ON s1.name=s2.name
		INNER JOIN (
			SELECT a.name AS app, c.name AS country
			FROM available a INNER JOIN country c
			ON a.country=c.code3
			WHERE c.continent_code = 'EU') europe_apps
		ON s1.name=europe_apps.app;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT name
FROM country
GROUP BY name
HAVING COUNT(DISTINCT continent_name) > 1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name as name
FROM country c1 LEFT OUTER JOIN country c2 ON c1.name=c2.name
WHERE c1.continent_name != c2.continent_name
ORDER BY name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name AS name
FROM available a LEFT OUTER JOIN country c ON a.country=c.code3
WHERE c.continent_name='Oceania'
AND a.name IN (
	SELECT s.name
	FROM store s
	GROUP BY s.name
	HAVING COUNT(DISTINCT s.os) >= ALL(
		SELECT COUNT(*)
		FROM store s1
		GROUP BY s1.name)
	)
ORDER BY a.name;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name AS name, COUNT(*) AS count
FROM available a LEFT OUTER JOIN country c ON a.country=c.code3
GROUP BY c.name
ORDER BY count DESC, c.name ASC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1 (
	A TEXT NOT NULL,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	PRIMARY KEY (C, D),
    UNIQUE (A, C, D)
);

CREATE TABLE IF NOT EXISTS E2 (
	G TEXT NOT NULL PRIMARY KEY,
	H TEXT NOT NULL,
	J TEXT NOT NULL,
	K TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS S (
	F TEXT NOT NULL,
	E1_A TEXT NOT NULL,
	E1_C TEXT NOT NULL,
	E1_D TEXT NOT NULL,
	E2_G TEXT NOT NULL,
	PRIMARY KEY (E1_A, E1_C, E1_D, E2_G),
	FOREIGN KEY (E1_A, E1_C, E1_D) REFERENCES E1(A, C, D),
	FOREIGN KEY (E2_G) REFERENCES E2(G)
);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
In the real world example of COVID-19, E1 represents the COIVD-19 patients and
E2 can represent hospitals in a country, and S represents admission to hospital.
So,
E1: patient
E2: hospital
S: admitted_to

And,
A - IC/FIN number of the patient (unique, therefore primary key)
B - Symptoms observed
C - Full Name,
D - Contact Number

F - Contracted Date

G - Hospital Name (Unique)
H - Maximum Bed Capacity
J - Address
K - Type of Hospital (Public/Private)

The relationship admitted_to is a one-to-many relationship from hospital to
patient. It is mandatory for the patient entities but optional for the hospital
entities. The participation constraints for the entity set hospital is (0, n)
and the participation constraints for the entity set patient is (1,1).

This cannot be otherwise because both patient and hospital are dominant entities.
We also note that IC/FIN is a unique identifier in Singapore and can serve as
he primary key for the patient list. A composite key can be the combination of a
patient's full name and contact number. Symptoms observed, contracted date, and
hospital capacity, address and type of hospital do not serve as keys in this case.
Each hospital has a unique name and can serve as the primary key of the hospital
entity.

Finally, we see that the relationship observes that each patient can only be
admitted to one hospital at any time after contracting COVID-19.
*/
