/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231884Y>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Print the names and ISO two letter codes of the different continents. The
result should be similar to that in the table below in any order */

select distinct continent_name, continent_code
from country;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/*Find the contact tracing apps that are available in Europe and work for both
iOS and Android operating systems. For each app, print the name of the app (rename the
column as “app”) and the name of the country (rename the column as “country”) in which the
app is available. The result should be similar to that in the table below in any order.*/

select distinct ap.name as app, cou.name as country
from app ap, available ava, country cou, appfunctionality apf, store st1, store st2
where ap.name = ava.name
and ava.country = cou.code3
and cou.continent_name = 'Europe'
and ap.name = apf.name
and apf.functionality = 'contact tracing'
and ap.name = st1.name
and ap.name = st2.name
and st1.os = 'Android'
and st2.os = 'iOS';


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/*Find the names of the countries that are spanning over several continents.
Use aggregate functions. The result should be similar to that in the table below in any order*/

select c.name
from country c
group by c.name
having count(c.continent_code) > 1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/*Find the names of the countries that are spanning over several continents.
This is the same query as (1.c) only do not use an aggregate query. The result should be similar
to that in the table above in any order*/

select distinct c1.name
from country c1, country c2
where c1.name = c2.name
and c1.continent_code != c2.continent_code;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Find the names of the apps available in countries in Oceania that work for
all recorded operating systems. 

The result should be similar to that in the table below in any
order. Make sure that your query produces the correct result in all possible database instances
including when new apps with new operating systems are added (you may neither hardcode
the operating systems as in Question 1.b nor the number of operating systems.) Do not use an
aggregate query. */

-- no such app 
-- not available in countries in Oceania

select ap.name
from app ap
where not exists (
	select *
	from store st
	where ap.name = st.name
	and not exists (
	 	select *
		from available ava, country cou
		where st.name = ava.name
		and ava.country = cou.code3
		and cou.continent_name = 'Oceania'));



/************************************************************************/
/*                                                                      */
/* Question 1.f                                                        */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/*
Find the countries with the top 6 largest number of apps available (this is
a dense ranking of the countries according to the number of apps). Print the names of the
countries and the numbers of apps in descending order of the numbers of apps. The result
should be similar to that in the table below. For full mark, make sure that your query produces
the correct result for the top 7, 8 to 16 as well. Do not use “RANK()”, “DENSE_RANK()”,
“ROW_NUMBER()”, window functions and partitions (although they could be better choices in
this case.) Use “GROUP BY”, “ORDER BY”, and “LIMIT”.
*/

select cou.name, count(ap.name) as count
from country cou, available ava, app ap
where ava.name = ap.name
and ava.country = cou.code3
group by cou.name
order by count desc
limit 6;


/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/*
Translate the entity-relationship diagram into SQL following the translation rules
given in the lecture. Use “TEXT” as the domain of the columns. Make sure that the design does
not allow null values. The code should run for PostgreSQL version 13 and above (try it).
*/

create table if not exists E2 (
	G text primary key,
	H text not null,
	J text not null,
	K text not null);

create table if not exists E1_S (
	A text not null,
	B text not null,
	C text not null,
	D text not null,
	F text not null,
	e2G text not null,
	foreign key (e2G) references E2(G),
	primary key (A, C, D));



/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/* Describe in English an original real world example to which the entity-relationship
diagram in Figure 1 could correspond. Give the real world meaning of entity sets E1 and E2,
of relationship set S, and of attributes A, B, C, D, F, G, H, J, and K. Justify the candidate
keys and participation constraints in the entity-relationship diagram. */


/*
E1: each car available at the store house
E2: car type
S: contain

A:car color under each car type
B:car price
C:car individual number given under each car type
D:car production batch number under each car type
F:the number of cars of each type stored at the house
G:car number that identifies the unique car type
H:production year
J:mileage
K:brand

*/

