/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231872E*/

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.continent_name,c.continent_code
from country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct a.name as app,c.name
from app a, available av,store s,country c
where a.name=av.name
and c.code3=av.country
and a.name=s.name
and c.continent_name='Europe'
and s.os='Android'
intersect
select distinct a.name as app,c.name
from app a, available av,store s,country c
where a.name=av.name
and c.code3=av.country
and c.continent_name='Europe'
and a.name=s.name
and s.os='iOS';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c1.name
from country c1
where exists (select c.name,count(*)
from country c
where c1.name=c.name
group by c.name
having count(*)>=2);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.name
from country c
where exists (select c1.name
			 from country c1
			 where c1.name=c.name
			 and c1.continent_name<>c.continent_name);
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct av.name
from available av,store s,country c
where s.name=av.name
and c.code3=av.country
and c.continent_name='Oceania'
and not exists (select distinct s2.os
				from store s2
				where s2.name = s.name
				except
				select distinct s1.os
			    from store s1
			    );
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name,count(*)
from country c,available av
where av.country=c.code3
group by c.name
order by count(*)desc
limit 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table if not exists E2(
G varchar(32) primary key,
H varchar(32) not null,
J varchar(32) not null,
K varchar(32) not null);
create table if not exists E1_S(
A varchar(32) unique not null,
B varchar(32) not null,
C varchar(32),
D varchar(32),
primary key(C,D),
F varchar(32) not null,
G varchar(32) references E2(G)	
)
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 represents students in a class of kindergarten. E2 represents a class. S represents the relationship between the student and the class.A child can only be in one class, and a class can have many students.
In E1, A represents the student ID, B represents the student’s gender, C represents the student’s date of birth, and D represents the student’s name. The student ID of each student is different. At the same time, the date of birth and the name of the student are enough to find a student.
In S, F represents the time when the student started school.
In E2, G represents the name of the class, H represents the class size, J represents the floor where the class is located, and K represents the ratio of male to female students in the class. In a kindergarten, the name of the class is enough to find a class.In a kindergarten, each class has a different name.
*/

