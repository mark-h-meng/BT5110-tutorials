/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0165086Y>                  */
/* */
/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT country.continent_name,country.continent_code
FROM country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT app.name AS app,country FROM app,available,country
WHERE app.name = available.name AND country.code3 = available.country AND country.continent_code = 'EU';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c1.name
FROM country c1 
INNER JOIN country c2 ON c1.code3 = c2.code3
GROUP BY c1.name
HAVING COUNT(*) > 1
ORDER BY c1.name;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c1.name
FROM country c1 
INNER JOIN country c2 ON c1.code3 = c2.code3 WHERE c1.continent_code = 'AS'

INTERSECT 

SELECT c1.name
FROM country c1 
INNER JOIN country c2 ON c1.code3 = c2.code3 WHERE c1.continent_code = 'EU' 
OR c1.continent_code = 'AF' OR c1.continent_code = 'OC'
OR c1.continent_code = 'NA' OR c1.continent_code = 'SA'
OR c1.continent_code = 'AN' 

UNION 

SELECT c1.name
FROM country c1 
INNER JOIN country c2 ON c1.code3 = c2.code3 WHERE c1.continent_code = 'OC'

INTERSECT 

SELECT c1.name
FROM country c1 
INNER JOIN country c2 ON c1.code3 = c2.code3 WHERE c1.continent_code = 'NA'; 


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/* EDIT NOT FULLY CORRECT                                                           */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT app.name FROM app,available,country,store
WHERE app.name = available.name AND country.code3 = available.country AND country.continent_code = 'OC'
AND app.name = store.name

EXCEPT

SELECT app.name FROM app,available,country,store
WHERE app.name = available.name AND country.code3 = available.country AND country.continent_code = 'OC'
AND app.name = store.name AND store.os ISNULL;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT country.name, COUNT(available.country) FROM app,available,country
WHERE app.name = available.name AND country.code3 = available.country
GROUP BY country.name
ORDER BY COUNT(available.country) DESC LIMIT 6; 
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1 (
A TEXT NOT NULL,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
PRIMARY KEY (A,C,D)
);

CREATE TABLE IF NOT EXISTS E2 (
G TEXT NOT NULL,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL,
PRIMARY KEY G
);

CREATE TABLE IF NOT EXISTS S (
F TEXT NOT NULL,
A TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
G TEXT NOT NULL,
PRIMARY KEY (A,C,D,G),
FOREIGN KEY (A,C,D) REFERENCES E1(A,C,D),
FOREIGN KEY G REFERENCES E2(G),
);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 as government.
E2 as parliament member.
S as head.
There is only one government heading all the parliament members at any one point of time.

A - Name of government
B - Number of members in government
C - Majority party leading government
D - Leader of government

F - Years headed 

G - Parliament member name
H - Parliament member age
J - Parliament member height
K - Parliament member date of birth

A,C,D are keys so as to distinguish between the various parties that have formed the majority in the government.
A (Name of government) indicates the country name (eg. Singapore)
The number of members in government is not a very important attribute so B is not a key.
C (Majority party leading governments) refers to the party that won the most seats to form a majority government (eg. PAP)
D (Leader of government) refers to the country's leader (eg. Lee Hsien Loong in Singapore )

F (Years headed) refers to the number of years which the current government has been heading since the last election.

G (name of parliament member) is a key since it is used to distinguish between the various parliament members.
H,J,K are just descriptive attributes of the parliament member and not very important so are not keys.

*/

