/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231863E                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT app.name AS app, c.name AS country
FROM app app, available av, appfunctionality appf, country c, store s
WHERE app.name = av.name
AND app.name = appf.name
AND av.country = c.code3
AND appf.functionality = 'contact tracing'
AND c.continent_name = 'Europe'
AND s.name = app.name
AND s.os = 'iOS'
INTERSECT
SELECT app.name AS app, c.name AS country
FROM app app, available av, appfunctionality appf, country c, store s
WHERE app.name = av.name
AND app.name = appf.name
AND av.country = c.code3
AND appf.functionality = 'contact tracing'
AND c.continent_name = 'Europe'
AND s.name = app.name
AND s.os = 'Android'
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(c.continent_name)>1
ORDER BY c.name
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.name
FROM country c
WHERE EXISTS(
	SELECT *
	FROM country c1
	WHERE c1.name = c.name
	AND c1.continent_name <> c.continent_name
)
ORDER BY c.name
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT app.name
FROM app app, available av, country c, store s
WHERE c.continent_name = 'Oceania'
AND app.name = av.name
AND av.country = c.code3
AND s.name = av.name
AND s.os = 'iOS'
INTERSECT
SELECT app.name
FROM app app, available av, country c, store s
WHERE c.continent_name = 'Oceania'
AND app.name = av.name
AND av.country = c.code3
AND s.name = av.name
AND s.os = 'Android'

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(*)
FROM available av, country c
WHERE av.country = c.code3
GROUP BY c.name
ORDER BY COUNT(*) DESC
LIMIT(6)
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1(
	A TEXT,
	B TEXT NOT NULL,
	C TEXT,
	D TEXT,
	PRIMARY KEY(A, C, D)
);

CREATE TABLE E2(
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL,
	J TEXT NOT NULL,
	K TEXT NOT NULL
);

CREATE TABLE S(
	A TEXT,
	C TEXT,
	D TEXT,
	F TEXT NOT NULL,
	G TEXT,
	PRIMARY KEY(A, C, D, G),
	FOREIGN KEY(A, C, C) REFERENCES E1(A, C, D),
	FOREIGN KEY(G) REFERENCES E2(G)
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 as student_club
E2 as student
S as head

E1 (student_club):
A is Club Name
C is Faculty of the club
D is Department of the club
B is Number of members

E2 (student):
G is Student email
H is Age
J is Gender
K is Enrolled course

S (head):
F is Years in position

In this school, every student can at most head only one student club (0,1), and every club
in the school must have a president(1,1).





*/

