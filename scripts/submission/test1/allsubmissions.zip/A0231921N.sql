/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231921N>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name, continent_code
FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
WITH ios AS (SELECT DISTINCT a.name as app, c.name as country
FROM store s, available a, country c
WHERE a.country = c.code3
	AND s.name = a.name
	AND c.continent_code = 'EU'
	AND s.os = 'iOS'),

android AS (SELECT DISTINCT a.name as app, c.name as country
FROM store s, available a, country c
WHERE a.country = c.code3
	AND s.name = a.name
	AND c.continent_code = 'EU'
	AND s.os = 'Android')
	
SELECT DISTINCT i.app, i.country
FROM ios i INNER JOIN android a ON (i.app, i.country) = (a.app, a.country)

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT name
FROM country
GROUP BY name
HAVING count(DISTINCT continent_code) > 1

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
	AND c1.continent_name <> c2.continent_name

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */



/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

WITH winner AS (SELECT c.name as name, COUNT(DISTINCT a.name) as count1
FROM available a, country c
WHERE a.country = c.code3
GROUP BY c.name),

loser AS (SELECT c.name as name, COUNT(DISTINCT a.name) as count1
FROM available a, country c
WHERE a.country = c.code3
GROUP BY c.name)

SELECT loser.name, loser.count1
FROM loser LEFT OUTER JOIN winner
					ON winner.name<>loser.name 
					AND winner.count1 > loser.count1
GROUP BY loser.name, loser.count1
HAVING COUNT(loser.name) < 6
ORDER BY count1 DESC;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE S (
A TEXT NOT NULL,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
F TEXT NOT NULL,
G TEXT NOT NULL,
PRIMARY KEY (A, G),
FOREIGN KEY (G) REFERENCES E2(G));

CREATE TABLE E2(
G TEXT PRIMARY KEY,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/* The entity set E1 can represent Key Appointment Holders in a company 
(e.g. CEO, CFO, COO) and the table E2 can represent employees of the company. 
The relationship S represents 'Held By' i.e. each position in E1 is held by 
someone in E2. 

Participation constraints: Each key position (A) can be held by only 1 person,
 hence E1 and S are combined in the table set up. However, one person can
 hold multiple positions e.g. in some companies, CEO and COO may be the 
 same person.

Attributes could stand for:
A: Title (e.g. Global CEO, CFO North America, COO Asia-Pacific, hence this is the Primary Key of S)
B: Duties
C: Rank (e.g. Director, VP)
D: Region (e.g. USA, Global, Asia)
F: Appointment Date (e.g. Date the person became CEO)
G: Employee ID
H: Name 
J: Join Date
K: Reporting Manager (if any)
Hence, C,D may be a composite primary key as they are unique when combined.

Although C,D,G is a candidate key for S, this is not as simple as A,G hence A,G 
is chosen for the table set up. 
*/

