/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231974Y>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select distinct c.continent_name, c.continent_code
From country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select distinct a.name AS app, c.name AS country
From app a, country c, store s, available av
WHERE s.os IN ('iOS', 'Android')
AND av.name = a.name
AND s.name = a.name
AND av.country = c.code3
AND c.continent_code = 'EU';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select distinct c.name
From country c
Group by c.name
HAVING count(c.number) > 1
Order by c.name ASC;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select distinct a.name
From app a, country c, available av, store s
WHERE a.name = av.name
AND av.country = c.code3
AND s.name = a.name
AND s.os IN ('iOS', 'Android')
AND c.continent_code = 'OC';

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select c.name, count(*) AS count
From country c, app a, available av
WHERE c.code3 = av. country
AND av.name = a.name
Group by c.name
Order by count(*) DESC
Limit 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS E1(
	A VARCHAR(64) NOT NULL,
	B VARCHAR(64) NOT NULL,
	C VARCHAR(64) NOT NULL,
	D VARCHAR(64) NOT NULL,
	F VARCHAR(64) NOT NULL,
	PRIMARY KEY (A,C,D)
);

CREATE TABLE IF NOT EXISTS S(
	A VARCHAR(64) NOT NULL REFERENCES E1(A),
	C VARCHAR(64) NOT NULL REFERENCES E1(C),
	D VARCHAR(64) NOT NULL REFERENCES E1(D),
	G VARCHAR(64) NOT NULL REFERENCES E2(G),
	F VARCHAR(64) NOT NULL
);

CREATE TABLE IF NOT EXISTS E2(
	G VARCHAR(64) NOT NULL PRIMARY KEY,
	H VARCHAR(64) NOT NULL,
	J VARCHAR(64) NOT NULL,
	K VARCHAR(64) NOT NULL
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */

'It could be a student-mentorship problem. E1 will be students sets. One student are required to find a mentor. S represent the mentoring. E2 would be the mentors sets. Each mentor/academic faculty could have no student to mentor, or have multiple students. 

The attrubutes of E1
A: student email
B: student faculty
C: student last_name
D: student first_name

The attrubutes of S
F: the proposed mentoring duration

The attrubutes of E2
G: faculty number
H: school address
J: office hour
K: rating from previou student
/*


*/

