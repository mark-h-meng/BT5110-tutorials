/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232000L                */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name,continent_code
FROM country
ORDER BY continent_name;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT app.name AS app, c.name as country
FROM app, country c, available ava, store s1, store s2
WHERE app.name = ava.name
AND c.code3=ava.country
AND c.continent_name = 'Europe'
AND app.name = s1.name
AND s1.os = 'iOS' 
AND app.name = s2.name
AND s2.os = 'Android'
ORDER BY app.name, c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT name
FROM country 
GROUP BY name
HAVING count(*)>1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.name
FROM country c, country c1 
WHERE c.name = c1.name
AND c.continent_name <> c1.continent_name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT s.name
FROM store s, available ava, country c
WHERE s.name = ava.name
AND c.code3 = ava.country
AND c.continent_name = 'Oceania'
AND s.os = ANY(
	SELECT DISTINCT os
	FROM store);
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, count(*)
FROM country c, available ava
WHERE c.code3 = ava.country
GROUP BY c.name
ORDER BY count(*) DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E2(
	J TEXT NOT NULL,
	K TEXT NOT NULL,
	H TEXT NOT NULL,
	G TEXT PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS E1(
	B TEXT NOT NULL,
	A TEXT NOT NULL,
	C TEXT,
	D TEXT,
	F TEXT NOT NULL,
	G TEXT REFERENCES E2(G),
	PRIMARY KEY (C, D)
	);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
This could represent an employment relationship for employed univerisity graduates. E2 is the company, G would be the registered brand name,
which is the candidate key as it is uniquely identified. H,K,J could be address, industry and revenue respectively. E1 is the worker, A could 
be national ID, which can be used as a candidate key. C and D could be university and university id, which together can serve as candidate key. 
B would beother information, such as salary.

Participation constraint for E1 is (1,1) as each worker needs need to be employed by a company and cannot be employed by more than 1 company,
for E2 is (0,n) as each company can hire 0 to as many they want the number of recent graduates.

*/

