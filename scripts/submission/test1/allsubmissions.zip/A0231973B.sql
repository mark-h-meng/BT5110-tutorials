/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231973B */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name AS app, c.name AS country
FROM app a, available av JOIN country c ON av.country = c.code3
WHERE a.name = av.name
AND c.continent_name = 'Europe'
AND EXISTS(
	SELECT a1.name
	FROM app a1, store s1, store s2
	WHERE a1.name = a.name
	AND a1.name = s1.name
	AND a1.name = s2.name
	AND s1.store = 'GooglePlay'
	AND s2.store = 'AppStore')
ORDER BY c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(c.name)>1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_name <> c2.continent_name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name
FROM app a, available av JOIN country c ON av.country = c.code3
WHERE a.name = av.name
AND c.continent_name = 'Oceania'
AND NOT EXISTS (
	SELECT s.os
	FROM store s
	WHERE NOT EXISTS (
		SELECT a1.name
		FROM app a1, store s1
		WHERE a1.name = s1.name
		AND s1.name = s.name)); 

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name, COUNT(DISTINCT a.name)
FROM app a, available av JOIN country c ON av.country = c.code3
WHERE a.name = av.name
GROUP BY c.name
ORDER BY COUNT(DISTINCT a.name) DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS E2 (
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL,
	J TEXT NOT NULL,
	K TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS E1_S (
	A TEXT,
	B TEXT NOT NULL,
	C TEXT,
	D TEXT,
	F TEXT NOT NULL,
	G TEXT NOT NULL,
	PRIMARY KEY(A, C, D),
	FOREIGN KEY(G) REFERENCES E2(G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

We can think of a database which would list the buildings in Singapore and the architect
who built these buildings. Please note that in my understanding, one and only one architect is 
responsible for a construction site. If this is not the case in real life, I assume 
the architects in the table to be the 'chief architects' or 'chief project developer' for each building (so that 1 and exactly 1 architect is affected to a building - conversely, an architect can conceive a large number of buildings throughout his life).

We would then have the following entities, relationship and attributes:
- E1: 'architect'
- E2: 'building'
- S: 'conceived'

The attributes of 'architect' would be:
- A: 'license_id_number', the architect's license identification number 
as the job of being an architect is a regulated profession
- B: 'birth_date'
- C: 'first_name'
- D: 'last_name'
(A, B, C) is a correct primary key because we can perfectly identify (without ambiguity) an architect
(in Singapore, since the license numbers must not be shared globally) given these three attributes.

The attribute of 'conceived' would be:
- F: 'conception_date'

The attributes of 'building' would be:
- G: 'building permit number', which is a unique number used legally 
and would perfectly identify the building referred to. G is then an adequate primary key
- H: 'geographic_coordinates', which precisely identifies the location of the building. 
I saw on Google maps (https://support.google.com/maps/answer/18539?hl=fr&co=GENIE.Platform%3DAndroid)
that this is useful to precisely identify an address 
- J: 'address' including the street number and street name
- K: 'height' with the height of the building

*/

