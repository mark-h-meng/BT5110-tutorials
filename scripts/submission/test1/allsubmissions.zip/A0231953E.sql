/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231953E                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name, continent_code
from country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
 select distinct ap.name as app, c.name as country 
 from app ap, available av, country c, store s1, store s2
 where ap.name = av.name
 and c.code3 = av.country
 and c.continent_name = 'Europe'
 and c.code3 = av.country
 and s1.name = ap.name
 and s2.name = ap.name
 and s1.os = 'iOS'
 and s2.os = 'Android';
 
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c
group by c.name
having count(distinct c.continent_name)>1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c1.name
from country c1, country c2
where c1.name = c2.name
and c1.continent_name <> c2.continent_name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select ap.name
from app ap, available av, country c
where ap.name = av.name
and av.country = c.code3
and c.continent_name = 'Oceania'
and not exists(
	select s1.os
	from store s1
	where s1.name <> ap.name);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name, count(distinct ap.name)
from country c, available av, app ap
where c.code3 = av.country
and av.name = ap.name
group by c.name
order by count(distinct ap.name) desc
limit 16;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table E2(
G TEXT primary key,
H TEXT not null, 
J TEXT not null,
K TEXT not null);

create table E1(
A TEXT not null,
B TEXT not null,
C TEXT not null,
D TEXT not null,
F TEXT not null,
G TExT not null,
primary key(A,C,D),
foreign key (G) references E2(G));



/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Table E1 could be the entity set for dancing clubs in China. 
Attibutes A, B, C, D respectively represent the name of each club, the slogan
of each club, the type of dance they are teaching and the founder of each club. 
With the club name, the type of dance and the founder, we could distinguish 
different dancing clubs.

Table E2 could be the entity set for provinces in China.
Attributes G, H, J, K respectively represent the name of each province, the region
it belongs to, the governor of each province and the vice-governor of each province. 

The relationship set shows which province each dancing club locates in.
Attribute F represents the exact location of the each dancing club in each province. 

*/

