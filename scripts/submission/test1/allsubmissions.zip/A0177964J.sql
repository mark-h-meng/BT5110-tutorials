/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0177964J                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name, continent_code
FROM country;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT av.name AS app, c.name AS country
FROM country c, available av, store s
WHERE av.country = c.code3
AND EXISTS (SELECT s1.name, COUNT(s1.os)
		   FROM store s1
		   WHERE s1.name = s.name
		   GROUP BY s1.name
		   HAVING COUNT(s1.os) > 1);

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.name
FROM country c
WHERE EXISTS ( 
	SELECT c1.name, COUNT(continent_name)
	FROM country c1
	WHERE c1.name = c.name
	GROUP BY c1.name
	HAVING COUNT(continent_name) > 1)
ORDER BY c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.name
FROM country c
WHERE EXISTS (
	SELECT *
	FROM country c1 
	WHERE c.name = c1.name 
	AND c.continent_name <> c1.continent_name)
ORDER BY c.name;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT av.name
FROM available av, country c, store s
WHERE av.country = c.code3
AND c.continent_name = 'Oceania'
AND av.name = s.name
AND EXISTS (SELECT s1.name, COUNT(s1.os)
		   FROM store s1
		   WHERE s1.name = s.name
		   GROUP BY s1.name
		   HAVING COUNT(s1.os) > 1)
ORDER BY av.name;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(av.name)
FROM country c, available av
WHERE c.code3 = av.country
GROUP BY c.name
ORDER BY COUNT(av.name) DESC
LIMIT 6;


/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1 (
	A VARCHAR(64),
	B VARCHAR(64) NOT NULL,
	C VARCHAR(64),
	D VARCHAR(64),
	F VARCHAR(64) NOT NULL,
	PRIMARY KEY (A, C, D)
);

CREATE TABLE IF NOT EXISTS E2(
	J VARCHAR(64) NOT NULL,
	G VARCHAR(64) PRIMARY KEY,
	K VARCHAR(64) NOT NULL,
	H VARCHAR(64) NOT NULL
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1: car
	A - category of vehicle
	C - city code
	D - licence plate number
	B - vehicle brand
S: bought
	F - shop
E2: person
	G(primary key) - IC number
	H - first_name
	J - last_name
	K - age_group

The E-R diagram can be a person buy a new car. 

The E1 can be the car entity with its new licence plate number, the A is the category of car like petrol or electrical car 
(the color of plate is different in China for this 2 kind of vehicle). 
The C will be city code and D is licence plate number, only the combination of A,C,D can identify one unique car. 
And B can be the brand of car. 

The relation is bought and F is the shop where the person buy the car. 
The E2 is person entity and G is the IC number of person to identify the person and H,J,K can be first_name, 
last_name and age_group of person respectively.

Participation constraints:
Each car can only be bought by 1 person. 
Each person can buy 0 or many cars. 

Candidate key for E1 is {A,C,D}
Candidate key for E2 is {G}


*/

