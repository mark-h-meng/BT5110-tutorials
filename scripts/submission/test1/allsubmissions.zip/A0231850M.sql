/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231850M                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT continent_name, continent_code
FROM country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name AS app, c.name AS country
FROM country c, available a, store s
WHERE a.country = c.code3
AND c.continent_code = 'EU'
AND a.name = s.name
GROUP BY a.name, c.name
HAVING COUNT(a.name) = 2;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(c.name) >1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_name <> c2.continent_name
GROUP BY c1.name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name
FROM available a, country c, store s
WHERE c.continent_code = 'OC'
AND a.country = c.code3
AND a.name = s.name
GROUP BY a.name;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(*)
FROM country c, available a
WHERE a.country = c.code3
GROUP BY c.name
ORDER BY count DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1(
A VARCHAR(32) NOT NULL UNIQUE,
B VARCHAR(32) NOT NULL,
C VARCHAR(32) NOT NULL,
D VARCHAR(32) NOT NULL,
PRIMARY KEY(C, D)); 

CREATE TABLE E2(
J VARCHAR(32) NOT NULL,
K VARCHAR(32) NOT NULL,
G VARCHAR(32) PRIMARY KEY,
H VARCHAR(32) NOT NULL);

CREATE TABLE S(
F VARCHAR(32) NOT NULL,
SA VARCHAR(32) NOT NULL UNIQUE,
SB VARCHAR(32) NOT NULL,
SC VARCHAR(32) NOT NULL,
SD VARCHAR(32) NOT NULL,
SG VARCHAR(32) NOT NULL,
PRIMARY KEY(SC, SD),
FOREIGN KEY (SG) REFERENCES E2(G));
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 may be government, E2 may be parliament_member, S maybe head, A maybe office code,
B maybe department, C maybe office name, D maybe office head, F may be time of appointment,
G may be parliament member id, J may be member name, K may be sex, H may be party name.
*/

