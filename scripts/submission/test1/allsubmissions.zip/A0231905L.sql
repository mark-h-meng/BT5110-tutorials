/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231905L                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT
  continent_name, 
  continent_code 
FROM 
  country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  av.name AS app, 
  c.name AS country 
FROM 
  available av, 
  country c, 
  store s1, 
  store s2 
WHERE 
  av.country = c.code3 
  AND av.name = s1.name 
  AND av.name = s2.name 
  AND s1.os = 'iOS' 
  AND s2.os = 'Android' 
  AND c.continent_name = 'Europe';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  name 
FROM 
  country 
GROUP BY 
  name 
HAVING 
  COUNT(continent_name) > 1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  DISTINCT c1.name 
FROM 
  country c1, 
  country c2 
WHERE 
  c1.code2 = c2.code2 
  AND c1.continent_name <> c2.continent_name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT ava.name
FROM available ava, country c
WHERE ava.country = c.code3
AND c.continent_name = 'Oceania'
AND NOT EXISTS (SELECT DISTINCT s1.os
			   FROM store s1
			   WHERE NOT EXISTS (SELECT *
								 FROM store s, available ava, country c
								WHERE ava.country = c.code3
								AND ava.name = s.name));

/* We can use two not exists for universality. The query above is not complete
but we can use the logic where we find apps from oceania where there is no os
that are not available for. */

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  c.name, 
  COUNT (ava.name) as count 
FROM 
  country c, 
  available ava 
WHERE 
  c.code3 = ava.country 
GROUP BY 
  c.name 
ORDER BY 
  count desc 
LIMIT 
  6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


CREATE TABLE E1 (
A text UNIQUE NOT NULL,
B text NOT NULL,
C text NOT NULL,
D text NOT NULL,
UNIQUE (C,D));

CREATE TABLE S (
F text NOT NULL);

CREATE TABLE E2(
J text NOT NULL,
K text NOT NULL,
H text NOT NULL,
G text UNIQUE NOT NULL);

/*The query above would need to add primary keys and references once that is decided based on application*/

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
This could be a list of form teacher and their students. E1 could be the table of students.
B could be the name of the student, A could be their NRIC number so it is unique. C could be
the class number and D could be the roll number, so the combination of class number and roll
number would be unique. S determines list of classes at the school and F is the class number.
E2 is for the teachers. J is the class number, K is the name, G is the unique NRIC number and 
H could be the subject the teacher specialises in. 

Each student has only one form teacher but each form teacher has multiple students in their class.

*/

