/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231906J>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.continent_name, c.continent_code
from country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct a.name as app, c.name as country
from app a, country c, store s, available av
where s.name = a.name
and c.code3 = av.country
and (s.os = 'iOS' or s.os = 'Android')
and c.continent_name = 'Europe'
order by a.name, c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct c.name
from country c
group by c.name
having count(c.continent_code)>1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct c.name
from country c
where c.continent_code >= all(
select c.continent_code
from country c);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct a.name
from app a, available av, country c
where av.country = c.code3
and a.name = av.name
and c.continent_name = 'Oceania'
and exists(
select *
from store s
where s.os is not null);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.name, count(av.name)
from country c, app a, available av
where c.code3 = av.country
and a.name = av.name
group by c.name
order by count(av.name)desc
limit 6;



/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E1(
A text not null,
B text not null,
C text not null,
D text not null,
primary key(A,C,D));

create table E2(
J text not null,
K text not null,
G text primary key,
H text not null);

create table S(
F text not null,
G text not null,
C text not null,
D text not null,
A text not null,
primary key(A,C,D,G),
foreign key(A,C,D) references E1(A,C,D),
foreign key(G) references E2(G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
real-life scenario:

E1 is manager
A could be the manager position name
C could be the salary of that manager position
and D could be the department in which the position is. 

E2 is employees
G could be the employee id

R is the relationship of which employee is in what manager position.

Each manager position must have only one employee's id.
Some employees are not managers while some talented employee can be the manager of two departments.

*/

