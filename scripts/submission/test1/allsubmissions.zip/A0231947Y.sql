/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231947Y                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT av.name as app, c.name as country
FROM available av, store s1, store s2, country c
WHERE av.name = s1.name
AND av.name = s2.name
AND s1.os = 'Android' 
AND s2.os = 'iOS'
AND av.country = c.code3
AND c.continent_name = 'Europe';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING count(*) >= 2
ORDER BY c.name;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c1.name FROM country c1
WHERE c1.name >= ALL (SELECT c2.name FROM country c2);
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT av.name
FROM available av, country c, store s1, store s2
where c.continent_code = 'OC'
AND av.country = c.code3
AND av.name = s1.name
AND av.name = s2.name
AND s1.os = 'Android' 
AND s2.os = 'iOS';
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, count(av.name)
FROM country c, available av
WHERE av.country = c.code3
GROUP BY c.name
ORDER BY count(*) DESC LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1(
A VARCHAR(32) UNIQUE,
B VARCHAR(32) NOT NULL,
C VARCHAR(32),
D VARCHAR(32),
PRIMARY KEY(C, D));

CREATE TABLE E2(
J VARCHAR(32) NOT NULL,
K VARCHAR(32) NOT NULL,
G VARCHAR(32) PRIMARY KEY,
H VARCHAR(32) NOT NULL);

CREATE TABLE S(
E1A VARCHAR(32),
E1B VARCHAR(32) NOT NULL,
E1C VARCHAR(32),
E1D VARCHAR(32),
FOREIGN KEY(E1C, E1D) REFERENCES E1(C, D)
E2G VARCHAR(32) PRIMARY KEY,
FOREIGN KEY(E2G) REFERENCES E2(G))
FOREIGN KEY (E2J, E2K, E2G, E2H) REFERENCE E2(J, K, H);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/* A, B, C, and D are attributes to Entity E1.
J, K, G, H are attributes to Entity E2. G is primary key to E2, which means only one unique to E2. 
Only one-to-one relationship between E1 and S, and there are many-to-many 
relationship between E2 and S. We can know the keys of the participating entities 
from S, which is our relationship sets.



*/

