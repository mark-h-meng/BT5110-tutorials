/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number :                         A0231917E                   */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c
ORDER BY c.continent_name

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT a.name AS app, c.name AS country
FROM app a, available av, country c, store s, appfunctionality af
WHERE a.name = av.name
AND a.name = s.name
AND a.name = af.name
AND av.country = c.code3
AND c.continent_code = 'EU'
AND af.functionality = 'contact tracing'
AND s.os = 'iOS'
INTERSECT
SELECT DISTINCT a.name AS app, c.name AS country
FROM app a, available av, country c, store s, appfunctionality af
WHERE a.name = av.name
AND a.name = s.name
AND a.name = af.name
AND av.country = c.code3
AND c.continent_code = 'EU'
AND af.functionality = 'contact tracing'
AND s.os = 'Android'
ORDER BY country

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(c.continent_code) > 1
ORDER BY c.name

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_name <> c2.continent_name
ORDER BY c1.name

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
	
SELECT DISTINCT a.name
FROM app a, country c, available av, store s1
WHERE a.name = av.name
AND a.name = s1.name
AND av.country = c.code3
AND c.continent_name = 'Oceania'
AND s1.os =ANY (SELECT DISTINCT s2.os FROM store s2)

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.name, COUNT(*) AS count
FROM app a, available av, country c
WHERE a.name = av.name
AND av.country = c.code3
GROUP BY c.name
ORDER BY count DESC
LIMIT 6

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1 (
A VARCHAR(64) ,
B VARCHAR(64) NOT NULL,
C VARCHAR(64) ,
D VARCHAR(64) ,
PRIMARY KEY(A,C,D)
)

CREATE TABLE IF NOT EXISTS E2 (
G VARCHAR(64) PRIMARY KEY,
H VARCHAR(64) NOT NULL,
J VARCHAR(64) NOT NULL,
K VARCHAR(64) NOT NULL)

CREATE TABLE IF NOT EXISTS S(
A VARCHAR(64), 
C VARCHAR(64), 
D VARCHAR(64), 
G VARCHAR(64),
F VARCHAR(64) NOT NULL,
FOREIGN KEY(A,C,D) REFERENCES E1(A,C,D),
FOREIGN KEY(G) REFERENCES E2(G)
)

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 as hobby club in a university, E2 as club_member, S as head

E1 as hobby club in a university
A is the club's code, which is unique.
B is where the club will have activities, which is not that important for 
identification.
C is the name of the club, and D is the year of establishment, the
combination of which will help identify the club. 
A, C and D are candidate keys.
For example, if I say the code as AA1234, or I say 'The Musical club 
established in 2012', everyone can find the exact club. 

E2 as club member.
G is the student number (A0231917E for example)
H can be the person's name.
J can be the person's gender.
K can be the person's mobile number.
Since H,J,K are not candidate keys, they can also be the members' address, 
age, and so on. There will be no constriants on H,J and K excepr to be 
not null.

S as the relationship of a certain person in E2 heading E1.
(0,n) means a many-to-many relationship. Everyone can join many clubs as 
each will have many hobbies. One club could have no members except the 
head if few people feel interested.
(1,1) means a one-to-one relationship. One club must have one person to lead,
or it will not be established. If one want to be the he head of the club,
he or she can't be the head of another.

*/




















