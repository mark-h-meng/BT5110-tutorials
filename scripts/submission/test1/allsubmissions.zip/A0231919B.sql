/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231919B>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.continent_name, c.continent_code 
from country c

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
ALTER TABLE public.country 
    ADD CONSTRAINT countryid
        PRIMARY KEY (continent_code, code2);

CREATE TABLE country_code3 (
code3 CHAR(3),
continent_code CHAR(2) NOT NULL,
code2 CHAR(2) NOT NULL,
PRIMARY KEY (continent_code, code2)
Foreign key (continent_code,code2) REFERENCES country(continent_code,code2));

INSERT INTO country_code3
SELECT distinct(code3) FROM country where code3 is not null;


(select a.name as app, v.name as country
from app a, available v, country_code3 cc, coutry c, store s
where a.name = v.name
and cc.code3 = v.country
and s.name = a.name
and (cc.continent_code = c.continent_code and cc.code2=c.code2)
and c.continent_name = 'Europe'
and (s.os = 'iOS')
intersect
(select a.name as app, v.name as country
from app a, available v, country_code3 cc, coutry c, store s
where a.name = v.name
and cc.code3 = v.country
and s.name = a.name
and (cc.continent_code = c.continent_code and cc.code2=c.code2)
and c.continent_name = 'Europe'
and (s.os = 'Andriod'))

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select name from country
group by name having count(name)>1;
 
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct(c1.name) from country c1
right join (select name from country c2) as country2
where country.name isnull;
 
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name
from 

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1(
A TEXT NOT NULL,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
PRIMARY KEY (A, C, D));

CREATE TABLE E2(
G TEXT NOT NULL PRIMARY KEY,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL);

CREATE TABLE S(
A TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
G TEXT NOT NULL REFERENCES E2(G),	
Foreign key (A,C,D) REFERENCES E1(A,C,D));
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 is students, S is library borrowing account, E2 is books avaible for borrowing;
one student can have one and only one account, one account can have 0 to n books borrowed
ACD is a student's email,name, age;F is the account number; 
G is the unique book identication number, JKH is other features 
*/

