/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218968J                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT distinct c.continent_name, c.continent_code
FROM country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name as app, c.name as country
FROM available a, store s, country c, store s2
WHERE c.continent_name = 'Europe'
AND a.country = c.code3
AND c.code3 is not null
AND s.os = 'Android' 
AND s2.os = 'iOS'
AND s.name = s2.name
AND a.name = s.name
ORDER BY app;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(c.name)>1
ORDER BY c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name 
FROM country c1, country c2
WHERE c2.continent_name <> c1.continent_name 
AND c1.name = c2.name
ORDER BY c1.name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT distinct a.name
FROM country c1, store s, available a
WHERE c1.continent_name='Oceania'
AND a.country = c1.code3
AND c1.code3 is not null
and a.name = s.name
AND NOT EXISTS (
	SELECT *   
	FROM store s2  
	WHERE s.name = s2.name
	and a.name = s2.name
	and s.os = s2.os
	AND s.os NOT IN (      
		SELECT DISTINCT s3.os 
		FROM store s3));

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c1.name, count(distinct a.name)
FROM country c1, available a
WHERE c1.code3 is not null
and c1.code3 = a.country
group by c1.name
order by count(distinct a.name) DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS E2 (
J TEXT NOT NULL,
K TEXT NOT NULL,
G TEXT PRIMARY KEY,
H TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS E1 (
A TEXT UNIQUE NOT NULL,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
G TEXT NOT NULL,
F TEXT NOT NULL,
PRIMARY KEY(C,D),
FOREIGN KEY (G) REFERENCES E2(G) );


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Entity E1 can be wine with primary key G as name.
Other attributes for wine as J, H, K can be appellation, vintage and degree.
Entity E2 can be bottle with combination of attributes as primary keys. 
C attribute can be number(on the bottle) and D attribute can be country.
Relations S can be contains where F denotes whether the bottle is empty or contains a wine.



*/

