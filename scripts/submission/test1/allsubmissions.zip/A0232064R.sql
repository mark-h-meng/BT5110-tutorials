/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number :A0232064R                */



/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name, continent_code from country;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct available.name as app,country.name as cuontry
from public.available, public.store,public.country
where available.name=store.name
and available.country=country.code3
and country.name in
(select country.name from public.country
where country.continent_name='Europe'
)
and store.name in(
select store.name from public.store
group by store.name
having count(*)>1)
)
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select name from country
group by name
having count(*)>1
order by name;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select name from country
group by name
having count(*)>1
order by name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct available.name from available,country
where available.country=country.code3
and country.continent_name= 'Oceania'
and available.name in (
select store.name from store);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


select c.name, count(available.name) as count 
from country c,available
where available.country=c.code3
group by c.name
order by count desc
limit 6;


/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1
(
	A  varchar(62)not null
	B  varchar(62)not null
    C  varchar(62)not null
    D varchar(62)not null
    primary key(C,D)
)
--because s and e2 is 1-1 relationship, and S is the weak entity,  the table can be written using one to represant both of them.

CREATE TABLE IF NOT EXISTS E2
(
	F varchar(62)not null
	G  varchar(62)not null primary key
	H  varchar(62)not null
    J  varchar(62)not null
    K varchar(62)not null
)
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
we can suppose the E1 is main party in one country, for example, People's Action in Singapore and Reform in USA.
Then the E2 is the country. Obviously, E1 is the weak entity and R can be described to 'belongs to'.
E1 has four attributes: A is the country name (E2.name) and B is the scale of the party, for example it owns 500 people who belong to the party.
At the same time , C and D are the party's name and its learder's name which can positioned the specific party using the two attributes.

E2 depicts the country: G is the country's name(in the world, country's name is unique) and works as the primary key.
H,J,K are the contient, climate and language the country use, all of which cannot be used to represant the country.

Additionally, F can be derived.


*/

