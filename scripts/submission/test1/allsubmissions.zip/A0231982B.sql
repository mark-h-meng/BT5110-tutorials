/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231982B>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/* */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.continent_name, c.continent_code
from country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select av.name as app, c.name as country
from available av, country c, store s
where av.country=c.code3
and s.name=av.name
and c.continent_code='EU'
and s.os='iOS'
intersect
select av.name as app, c.name as country
from available av, country c, store s
where av.country=c.code3
and s.name=av.name
and c.continent_code='EU'
and s.os='Android'
order by app;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c
group by c.name
having count(*)>=2
order by c.name;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct c1.name
from country c1, country c2
where c1.code3=c2.code3
and c1.continent_code <>c2.continent_code
order by c1.name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct av.name
from available av, country c, store s1, store s2
where av.country=c.code3
and s1.name=av.name
and s2.name=av.name
and s1.name=s2.name
and c.continent_code='OC'
and s1.os <> s2.os
order by av.name;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name, count(*)
from available av, country c
where c.code3=av.country
group by c.name
order by count(*) desc limit 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table if not exists E1(
A VARCHAR(255) unique,
B VARCHAR(255) not null,
C VARCHAR(255) not null,
D VARCHAR(255) not null,
primary key (C,D));

create table if not exists E2(
G VARCHAR(255) primary key,
H VARCHAR(255) not null,
J VARCHAR(255) not null,
K VARCHAR(255) not null);

create table if not exists S(
F VARCHAR(255) not null,
C VARCHAR(255) not null,
D VARCHAR(255) not null, 
G VARCHAR(255) references E2(G),
primary key (C,D,G),
foreign key (C,D) references E1(C,D)
);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 is airplane, s is departure to, E2 is airport.

An airplane has its airline code(C), number(D), airplane production series number(A),
and producer(B). Each airplane has its unique production series number(just like production
series number on car), and by combining airline code and number (eg.UA886), the 
airplane is unique. Different airplanes may have the same producer like Boeing.

The relation is departure to (can be arrival as well). An airplane/flight can only
departure to one destination, but there can be multiple flights flying to the
same destination.

An airport has its unique code(eg.CGQ)(G), name(H), city (J), country(K). Different
airports may share the same name, same city or same country.

*/

