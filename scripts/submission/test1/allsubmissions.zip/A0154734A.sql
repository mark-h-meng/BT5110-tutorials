/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0154734A                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  distinct c.continent_name, 
  c.continent_code 
from 
  country c 
order by 
  c.continent_name;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  distinct d1.name as app, 
  d1.country 
from 
  (
    select 
      distinct a.name, 
      s.os, 
      c.continent_name, 
      c.name as country 
    from 
      store s, 
      app a, 
      available av, 
      country c, 
      appfunctionality ap 
    where 
      a.name = s.name 
      and a.name = ap.name 
      and a.name = av.name 
      and c.code3 = av.country 
      and c.continent_name = 'Europe' 
      and ap.functionality = 'contact tracing' 
      and s.os = 'iOS' 
    order by 
      a.name
  ) as d1, 
  (
    select 
      distinct a.name, 
      s.os, 
      c.continent_name, 
      c.name as country 
    from 
      store s, 
      app a, 
      available av, 
      country c, 
      appfunctionality ap 
    where 
      a.name = s.name 
      and a.name = ap.name 
      and a.name = av.name 
      and c.code3 = av.country 
      and c.continent_name = 'Europe' 
      and ap.functionality = 'contact tracing' 
      and s.os = 'Android' 
    order by 
      a.name
  ) as d2 
where 
  d1.name = d2.name 
order by 
  d1.name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  c.name 
from 
  country c 
group by 
  c.name 
having 
  count(*) > 1 
order by 
  c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  c.name , c.continent_code
from 
  country c;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  d1.name 
from 
  (
    select 
      distinct a.name, 
      s.os, 
      c.continent_name 
    from 
      store s, 
      app a, 
      available av, 
      country c 
    where 
      a.name = s.name 
      and a.name = av.name 
      and c.code3 = av.country 
      and c.continent_name = 'Oceania' 
      and s.os = 'Android' 
    order by 
      a.name
  ) as d1, 
  (
    select 
      distinct a.name, 
      s.os, 
      c.continent_name 
    from 
      store s, 
      app a, 
      available av, 
      country c 
    where 
      a.name = s.name 
      and a.name = av.name 
      and c.code3 = av.country 
      and c.continent_name = 'Oceania' 
      and s.os = 'iOS' 
    order by 
      a.name
  ) as d2 
where 
  d1.name = d2.name 
order by 
  d1.name;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  d1.name, 
  count(*) 
from 
  (
    select 
      a.name as app, 
      c.name as name 
    from 
      app a, 
      available av, 
      country c 
    where 
      a.name = av.name 
      and av.country = c.code3
  ) as d1 
group by 
  d1.name 
order by 
  count(*) desc 
limit 
  6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table if not exists E2 (
	J VARCHAR(64) NOT NULL,
	K VARCHAR(64) NOT NULL,
	G VARCHAR(64) NOT NULL PRIMARY KEY,
	H VARCHAR(64) NOT NULL
);

create table if not exists E1_S (
	A VARCHAR(64) NOT NULL,
	B VARCHAR(64) NOT NULL,
	C VARCHAR(64) NOT NULL,
	D VARCHAR(64) NOT NULL,
	PRIMARY KEY (A, C, D),
	F VARCHAR(64) NOT NULL,
	G VARCHAR(64) NOT NULL,
	FOREIGN KEY (G) REFERENCES E2(G)
);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/* The entity relationship diagram can correspond to a hiring process of a company
E1 = employee applying for job in the company
S = application submitted
E2 = Hiring manager for the company

E1 can only submit 1 application to the company hence, there is a one to one relationship between E1 (employee) and S (application submitted)
E2 are hiring managers of the company where they can review multiple applications, hence, there is a 0 to many relationship between E2 and S

For attributes of E1:
A = university
B = GPA
C = internship experience with the company
D = internship experience within the industry

Primary key = A, C, D = when applying to the job, hiring managers want to know whether they have internship experience and are from which university as some universities have partnerships with the company

For attributes of S:
F = application submission number and date

For attributes of E2:
J = department
K = seniority 
G = Company's Employee ID
H = previous university of hiring manager


*/

