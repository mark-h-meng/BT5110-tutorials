/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231989M                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name, continent_code
from country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name as app, cou.name as country
from app a, available as ava, store as st, country as cou
where st.name = a.name and ava.name = a.name and ava.country = cou.code3
and cou.continent_name = 'Europe' and st.os = 'iOS'
intersect
select a.name as app, cou.name as country
from app a, available as ava, store as st, country as cou
where st.name = a.name and ava.name = a.name and ava.country = cou.code3
and cou.continent_name = 'Europe' and st.os = 'Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cou.name
from country as cou
group by cou.name
having count(cou.continent_name) > 1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cou.name
from country as cou
where coun

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select ava.name
from available as ava, country as coun, store as st, app as a
where ava.country = coun.code3 and st.name = a.name and ava.name = a.name and coun.continent_name = 'Oceania'
and st.name = ava.name and st.os = all(
select st.os
from store as st
group by st.os);
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select coun.name, count(ava.name)
from available ava, country coun
where coun.code3 = ava.country
group by coun.name
order by count(ava.name) desc
limit 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1 (
A TEXT NOT NULL,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
F TEXT NOT NULL,
PRIMARY KEY (C,D),
FOREIGN KEY (A) REFERENCES E2(G));

CREATE TABLE E2(
J TEXT NOT NULL,
K TEXT NOT NULL,
H TEXT NOT NULL,
G TEXT PRIMARY KEY
);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
This entity-relationship diagram could correspond to E1 being a football player and E2 being a football club.
This database is strictly for players who are playing for clubs and represents the data of players who are currently playing.
S is the relationship that signifies "plays for". 

A, in this case, is the name of the football club – Arsenal FC,
FC Barcelona, Liverpool FC etc. 

B is an attribute, so we can let it be the skill of the player which could be from "Mediocre" to "World-Class".

C and D are the composite primary keys which uniquely identifies a football player.
This could be the full name of the player as C and the D as their birth place. Cristiano Ronaldo's full name
is Cristiano Ronaldo dos Santos Aveiro and his birth place is Funchal, Madeira, Portugal. Both this
information would uniquely identify a player.

F is the attribute in the relationship S, "plays for". This can be the contract information of the player and the football club.

G is the primary key of the football club or E2. This is the name of the football club as it generally uniquely identifies
a football team. For ex: Real Madrid has two teams Real Madrid CF, A team, and Real Madrid Castilla Club de Fútbol, B team.

H, J, K are attributes for the football club. So, H can be the football club stadium capacity, J could be the
number of years active, and K could be the fanbase of the football club.

To justify the participation contraints, in this database, a football player can only play for a minimum of one
team and a maximum of one team at one point in time. Note that this database is only for football players and clubs, no country football data.
Also, there is a 1-to-1 pairing of football player to club as this data is only concerned with the current situation.
For instance, Lionel Messi is only playing for PSG at this moment, so he has a 1-to-1 pairing with PSG.

Clubs has a 0 to many constraint as a club could be without any players (inactive) or a club would typically
have multiple players playing for the team. This is trivial as clubs contain numerous players from their first team to
youth squads.

*/

