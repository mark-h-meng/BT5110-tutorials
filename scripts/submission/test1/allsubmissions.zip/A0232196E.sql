/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0232196E>  Shaobin Qiao                */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name, continent_code from country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct av.name as app, c.name as country
from available av join country c on av.country = c.code3
where (av.name, c.name) in (select av.name, c.name
from store s join available av on s.name = av.name 
join country c on c.code3 = av.country where s.os='iOS')
and (av.name, c.name) in (select av.name, c.name
from store s join available av on s.name = av.name 
join country c on c.code3 = av.country where s.os='Android')
;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name from country c group by c.name 
having count(c.continent_name) > 1; 

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.name from country c, country cc
where c.name = cc.name and c.continent_name <> cc.continent_name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct s.name, s.os from store s natural join available av 
join country c on av.country = c.code3 
where c.continent_name = 'Oceania' order by s.name;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name, count(*) from available av 
join country c on c.code3 = av.country
group by c.name
order by count desc limit 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E1 (
C VARCHAR(10) NOT NULL unique,
D VARCHAR(10) NOT NULL unique,
A VARCHAR(10) NOT NULL unique,
B VARCHAR(10) NOT NULL, 
PRIMARY KEY (C, D));

CREATE TABLE E2 (
J VARCHAR(10) NOT NULL,
K VARCHAR(10) NOT NULL,
G VARCHAR(10) PRIMARY KEY,
H VARCHAR(10) NOT NULL
);

CREATE TABLE S (
F VARCHAR(10) NOT NULL PRIMARY KEY unique,
C VARCHAR(10) NOT NULL REFERENCES E1 (C),
D VARCHAR(10) NOT NULL REFERENCES E1 (D),
G VARCHAR(10) NOT NULL REFERENCES E2 (G));
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

E1 could be book, C D are the book's name and its author name, as 
they can be combined to identify the book (assume the name and author name
are unique in this case). A could be a unique numeric identifier of the book
and B could be its genre or book type. 
E2 could be students or people who
borrow books. G could be their identification number, J, K, H could be their
attributes like age, gender and nationality.
S is the relationship of borrowing book. A book can only be borrowed by one 
at a time, so its a 1-to-1 relationship, whereas a student can borrow several
books or no books, so it's a (0, n) relationship.
C, D column in S table can be used to identify the book, and G can be used to 
identify the borrower. F its a unique number that stands for this borrow action.



*/

