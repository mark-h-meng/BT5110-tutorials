/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0057228A>                  			    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name, continent_code 
FROM country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c1.name 
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_name <> c2.continent_name
GROUP BY c1.name
ORDER BY c1.name;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name 
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_name <> c2.continent_name
ORDER by c1.name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1(
	A TEXT NOT NULL, PRIMARY KEY,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL
	PRIMARY KEY (C, D)
	);

CREATE TABLE IF NOT EXISTS E2(
	G TEXT NOT NULL, PRIMARY KEY, 
	H TEXT NOT NULL, 
	J TEXT NOT NULL,
	K TEXT NOT NULL
	);

CREATE TABLE IF NOT EXISTS S(
	F TEXT NOT NULL,
	E1 TEXT NOT NULL,
	E2 TEXT NOT NULL,
	PRIMARY KEY (E2, A, C, D),
	FOREIGN KEY (E2) REFERENCES E2(G),
	FOREIGN KEY (A, C, D) REFERENCES E1(A, C, D)
	);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*								    */

