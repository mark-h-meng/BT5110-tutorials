/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231857Y                						  	*/

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT continent_name, continent_code FROM country GROUP BY continent_name, continent_code;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name, c.name FROM available a, country c WHERE a.country = c.code3 AND c.continent_name = 'Europe' AND a.name IN
(SELECT s1.name FROM store s1, store s2 WHERE s1.name = s2.name AND s1.os = 'iOS' AND s2.os = 'Android') AND a.name IN (
SELECT name FROM appfunctionality WHERE functionality = 'contact tracing');

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name FROM country c GROUP BY c.code3, c.name HAVING COUNT(*) > 1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c1.name FROM country c1 WHERE EXISTS
(SELECT * FROM country c2 WHERE c1.continent_name <> c2.continent_name
AND c1.code3 = c2.code3);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name FROM available a WHERE a.country IN (
SELECT c.code3 FROM country c WHERE c.continent_name = 'Oceania')
INTERSECT
SELECT DISTINCT a.name FROM app a CROSS JOIN 
(SELECT DISTINCT s.os FROM store s) AS all_os
WHERE NOT EXISTS (
SELECT * FROM store s1 WHERE s1.name = a.name AND s1.os = all_os.os);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name, COUNT(*) AS count FROM available a, country c 
WHERE a.country = c.code3 GROUP BY c.name ORDER BY count desc LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E2(
G TEXT NOT NULL,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL,
PRIMARY KEY (G));

CREATE TABLE S_MERGED_E1(
F TEXT NOT NULL,
G TEXT NOT NULL,
A TEXT NOT NULL PRIMARY KEY,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
FOREIGN KEY (G) REFERENCES E2(G));


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
The entity-relationship diagram can represent a scenario where a door producing factory is producing
and tracing its products. In this case, E1 would represent the doors produced, S would represent a 
production ledger that tracks what has been produced and E2 would represent door producing factories.

E1 (Door) attributes could represent the following:
A = Unique Warranty Product Number
B = Door Type
C = Manufacturing Batch
D = Item Batch Number

The candidate keys here are A or C & D because A is unique for each product, meanwhile C & D will 
be able to identify product when used in composite since manufacturing batch points to the group 
and item batch number will identify the exact item produced. The (1, 1) constraint exists because 
a particular door can only be produced once by the factory but when it has been produced, it must 
be tracked (so mandatory participation).

S (Production Ledger) attributes could represent the following:
F = Date of Production

E2 (Factory) attributes could represent the following:
G = Factory Number
H = Factory Specialty
J = Factory Year Open
K = Factory Size

The candidate key is G because G is unique per factory. Other attributes in this table cannot be 
used to identify a factory as it might not be unique among different factories. The (0, n)
constraint exists because a factory can produce between 0 to many doors.

*/

