/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231856B>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT distinct continent_name, continent_code
from country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT app.name as app, c.name as country
from app, available as a, country as c, store as s1, store as s2
where app.name=a.name
and a.country=c.code3
and app.name=s1.name
and app.name=s2.name
and c.continent_name='Europe'
and s1.os='iOS'
and s2.os='Android';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT name from country
group by name
having count(*)>1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT distinct c1.name
from country as c1, country as c2
where c1.name=c2.name
and c1.continent_name<>c2.continent_name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name
from available as a
where not exists(
  select distinct s.os from store as s
  except
  select s.os from store as s, country as c
  where c.continent_name='Oceania'
  and a.name=s.name
  and a.country=c.code3
);
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, count(a.name) as count
from country as c, available as a
where c.code3=a.country
group by c.name
order by count desc
limit 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1 (
  A TEXT UNIQUE NOT NULL,
  B TEXT NOT NULL,
  C TEXT NOT NULL,
  D TEXT NOT NULL,
  PRIMARY KEY(C,D)
);

CREATE TABLE IF NOT EXISTS E2 (
  G TEXT PRIMARY KEY,
  J TEXT NOT NULL,
  K TEXT NOT NULL,
  H TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS S (
  C TEXT NOT NULL,
  D TEXT NOT NULL,
  G TEXT NOT NULL REFERENCES E2(G) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
  F TEXT NOT NULL,
  PRIMARY KEY(C,D),
  FOREIGN KEY (C,D) REFERENCES E1(C,D) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 could be the new employee table, E2 is the manager table, and the S describe the
relationship of management. For the E1 new employee table, A is their ID number, B
is age, C is name and D is address. For the E2 manager table, G is the ID number,
H is job level, J is the position, and K is the years of management. For S, it includes
the primary keys of both table, as well as a new attribute F, which is the time when
a manager choose to manage the new employee.
So {A}--->{A,B,C,D,F,G,J,K,H}, {C,D}--->{A,B,C,D,F,G,J,K,H}
Since the partition constraint is (1,1) for E1, so the candidate key is the primary
key of E1, could be A, or the combination of C,D. One entity in the E1 must have
only one corresponding record in E2.
*/
