/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232016X               */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT continent_name, continent_code
FROM country
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
ALTER TABLE available 
RENAME COLUMN name to app;

ALTER TABLE country
RENAME COLUMN name to country;

SELECT av.app, c.country
FROM available av, store s1, store s2, country c
WHERE av.app = s1.name
AND av.app = s2.name
AND s1.os = 'iOS'
AND s2.os = 'Android'
AND av.country = c.code3
AND av.country IN (
	SELECT code3
	FROM country
	WHERE continent_code = 'EU')
GROUP BY av.app, c.country

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
ALTER TABLE available 
RENAME COLUMN app to name;

ALTER TABLE country
RENAME COLUMN country to name;

SELECT name
FROM country
GROUP BY name
HAVING count(DISTINCT continent_name)>1
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_code <> c2.continent_code

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT av.name
FROM available av, country c, store s
WHERE av.country = c.code3
AND s.name = av.name
AND c.continent_name = 'Oceania'
AND NOT EXISTS (
	SELECT os
	FROM store
	WHERE os NOT in (
	SELECT DISTINCT os
	FROM store))
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, count(av.name) 
FROM country c LEFT OUTER JOIN available av ON c.code3 = av.country
GROUP BY c.name
ORDER BY count(av.name) DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1 (
A VARCHAR(32) NOT NULL,
B VARCHAR(32) NOT NULL,
C VARCHAR(32) NOT NULL,
D VARCHAR(32) NOT NULL,
PRIMARY KEY (A));

CREATE TABLE E2 (
G VARCHAR(32) NOT NULL,
H VARCHAR(32) NOT NULL,
J VARCHAR(32) NOT NULL,
K VARCHAR(32) NOT NULL,
PRIMARY KEY (G) );

CREATE TABLE S (
F VARCHAR(32) NOT NULL,
E1 VARCHAR(32) REFERENCES E1(A),
E2 VARCHAR(32) REFERENCES E2(G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
One example in the real world is the emplyment physical examination records
E1 is the list of employees and E2 is the list of all addtional examinations other than basic ones. 
S is the costumers' service purchasing record.

In E1, A is the ID which can alone distinguish every employee.
B is employee's department.
C and D are employee's real name and cell phone number, which 
can only distinguish every employee together because there can be
peopele with same name and different people in history using the same number.

In E2, G is the name of all addtional examinations.
H is the category of each examination.
J is the name of clinics where the examination is conducted.
K is the date when this service is added to the list.

As for S, because every new employee is required to hand in a physical examination
report, the relationship between E1 and S is 1 to 1. And people can choose whether or not to take 
addtional examinations and which ones to take. The relationship between E2 and S is 0 to n.


*/

