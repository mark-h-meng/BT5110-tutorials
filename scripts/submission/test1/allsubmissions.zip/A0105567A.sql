/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0105567A                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name, continent_code 
FROM country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name as app, c.name as country
FROM available a, country c, store s, appfunctionality af
WHERE a.name = s.name
AND a.name = af.name
AND a.country = c.code3
AND c.continent_code = 'EU'
AND af.functionality = 'contact tracing'
AND s.OS = 'iOS'
AND a.name in (SELECT a2.name
			  FROM available a2, store s2
			  WHERE a2. name = s2.name
			  AND s2.OS = 'Android');
			  
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT name
FROM country
GROUP by name
HAVING count (continent_code)>1
Order by name ASC;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.name 
FROM country c, country c2
WHERE c.name = c2.name
AND c.continent_code <> c2.continent_code
Order by c.name ASC;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT s.name
FROM available a, country c, store s
WHERE a.name = s.name
AND a.country = c.code3
AND c.continent_code = 'OC'
AND NOT EXISTS (SELECT DISTINCT OS FROM store as oss
			   WHERE NOT EXISTS (
			   SELECT *
			   FROM store s2
			   WHERE oss.OS = s2.OS
			   AND s.name = s2.name));
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, count(*)
FROM available a, country c
WHERE a.country = c.code3
GROUP by c.name
ORDER by count(*) DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E2(
J TEXT NOT NULL,
K TEXT NOT NULL,
G TEXT Primary Key,
H TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS E1(
A TEXT NOT NULL UNIQUE,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
PRIMARY KEY (C, D)
);

CREATE TABLE IF NOT EXISTS S(
C TEXT NOT NULL,
D TEXT NOT NULL,
G TEXT NOT NULL,
F TEXT NOT NULL,
FOREIGN KEY (C,D) REFERENCES E1 (C,D),
FOREIGN KEY (G) REFERENCES E2 (G)
);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 contains game infomation, 
where A is the registeration ID of the game, 
B is the price of the game, 
C is the name of the game, 
D is the version of the game.

E2 contains gaming company information, 
where J is the location of the company, 
K is the number of employees of the company, 
G is the name of the company (Unique), 
H is the established year of the company.

S is the relationship between games and gaming company (published by)
where it contains: 
the name of the game C, 
the version of the game D, 
the publishing company G,
and the publishing year F
*/

