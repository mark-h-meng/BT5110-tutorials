/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0218875N>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT s1.name AS app, c.name AS country
FROM store s1, store s2, app a, available av, country c
WHERE s1.name = a.name
AND S2.name = a.name
AND S1.os ='iOS'
AND S2.os = 'Android'
AND av.name = a.name
AND av.country = 'Europe'
AND av.country = c.code3;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT (c.continent_name)> 1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.name
FROM country c
WHERE 'c.continent_name' > 1;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT a.name
FROM store s, app a, available av, country c
WHERE c.continent_name = 'Oceania'
AND c.code3 = av.country
AND av.name = a.name
AND s.name = a.name
;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT (a.name) 
FROM country c, available av, app a
WHERE av.country = c.code3
AND av.name = a.name
GROUP BY c.name
ORDER BY COUNT DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1 (
	A TEXT UNIQUE NOT NULL,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	PRIMARY KEY (C,D)
);

CREATE TABLE IF NOT EXISTS E2 (
	J TEXT NOT NULL,
	K TEXT NOT NULL,
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS S (
	F TEXT NOT NULL,
	G TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	PRIMARY KEY (C,D,G),
	FOREIGN KEY (G) REFERENCES E2 (G),
	FOREIGN KEY (D,C) REFERENCES E1 (D,C)
);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 = Employee
E2 = Company
S = Contract
A = NRIC
B = Age
C = Name
D = Employee ID
F = Date of employment start
G = Company Registered ID
H = Country
J = Name
K = Number of offices

The example is of an entity set E2 (companies) of which entity set E1 (employees) are employed to work for under the relationship (contract). 
As there can be multiple employees with the same name (C) and employee ID (D) across companies, we use a composite of (C) + (D) as candidate keys to identify.
E2 (0,n): Companies can choose to employ multiple employees or none at all.
E1 (1,1): Employees have to work and can only choose to work at 1 company at any given time.

*/

