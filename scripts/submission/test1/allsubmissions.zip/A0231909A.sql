/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231909A>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select continent_name, continent_code from country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name, c.name
from available a, country c
where a.country = c.code3
and c.continent_name = 'Europe'
and a.name in (select s.name from store s
group by s.name
having count (*) = 2);
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select name from country
group by name
having count (*)>1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name, c.name from available a, country c where a.country = c.code3
and c.continent_name = 'Oceania'
and a.name in (
select s.nmae from store s where exists(
select r.os from stroe r));
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name as name, count(*) as count from available
left join country c on a.country = c.code3 
group by c.name order by count desc limit 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1(
A TEXT NOT NULL,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
PRIMARY KEY (A,C,D));

CREATE TABLE E2(
G TEXT NOT NULL,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL,
PRIMARY KEY (G));

CREATE TABLE S(
F TEXT NOT NULL
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1: Student
A: Student ID
B: Age
C: Department
D: Major
S: Register for
F: Grade
E2:Course
G: Course ID
H: Course Name
J: Course Level
K: Pre-requesite Courses

*/

