/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231952H>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.continent_name, c.continent_code
from country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct a.name as app, c.name as country
from country c, available a, store s1, store s2 
where a.country=c.code3 and c.continent_name='Europe' 
and s1.name=a.name and s2.name=s1.name and s2.name=a.name
and s1.os='iOS' and s2.os='Android'
order by app;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c
group by c.name
having count(c.continent_name)>1
order by c.name;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c1.name
from country c1,country c2
where c1.name=c2.name and c1.continent_name <> c2.continent_name
order by c1.name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name
from country c, store s, available a
where a.country=c.code3 
and c.continent_name='Oceania'  
and s.name=a.name
group by a.name
having count(s.os) = (select count(distinct s.os)
						 from store s);
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT loser.count, loser.name 
FROM (select count(a.name) as count, c.name 
from available a, country c
where a.country=c.code3  
group by c.name) as loser
LEFT OUTER JOIN (select count(a.name) as count, c.name 
from available a, country c
where a.country=c.code3  
group by c.name) as winner
ON winner.name<>loser.name
AND winner.count>loser.count
GROUP BY loser.name, loser.count 
HAVING COUNT(loser.name) < 6
ORDER BY loser.count desc;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1 ( 
A VARCHAR(64) UNIQUE NOT NULl,
B VARCHAR(64) NOT NULL,
C VARCHAR(64) NOT NULL,
D VARCHAR(64) NOT NULL,
PRIMARY KEY(C,D)
) ;

CREATE TABLE IF NOT EXISTS E2( 
J VARCHAR(64) NOT NULL,
K VARCHAR(64) NOT NULL,
G VARCHAR(64) PRIMARY KEY,
H VARCHAR(64) NOT NULL
);

CREATE TABLE IF NOT EXISTS S (
C VARCHAR(64),
D VARCHAR(64),
F VARCHAR(64) NOT NULL,
G VARCHAR(64),
FOREIGN KEY (C,D) REFERENCES E1(C,D),
FOREIGN KEY (G) REFERENCES E2(G),
PRIMARY KEY(C,D,G)
);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
A company want to send advertisement of its product to its consumer, in order to attract consumer to buy its products.
E1 is conusmer of a company. A is consumer's email adress, which must be unique, a candidate key. B is consumers's name. C is consumers' contact number and a id number for company to lable each consumer. C and D are used to identify a consumer.
E2 is products of the company. G is the id number of a product, which is set by the company to identify each product. J is the name of the products. K is the function of the products. H is the profit of the products.
S is the relationship between consumers and products. F is the result of whether the consumer response to the advertisemen of the product. Each consumer will only have one result. Therefore, the relationship is a one-to-one relationship from E1 to S.
However, a product may correspond to many results from different consumers. The relationship is a many-to-many relationship from E2 to S.
*/

