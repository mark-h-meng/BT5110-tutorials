/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231908E               */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select continent_name,continent_code
from country;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct a.name app, c.name country
from available a, store s1, store s2, country c
where a.name=s1.name
and a.name=s2.name
and s1.os!=s2.os
and c.code3=a.country
and c.continent_name='Europe';



/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name 
from country c
group by c.name
having count(distinct continent_name)>1;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c1.name
from country c1,country c2
where c1.name=c2.name
and c1.continent_name!=c2.continent_name;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name
from available a
where not exists(
select s.os
from store s
where a.name=s.name 
and not exists(
select c.code3
from country c
where a.country=c.code3
and c.continent_name='Oceania'
));

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name,count(a.name) count
from available a,country c
where a.country=c.code3
group by c.name
order by count desc
limit 6;


/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table E2(
j text not null,
k text not null,
g text primary key,
h text not null
);

create table E1_S(
a text unique not null,
b text not null,
c text,
d text,
f text not null,
g text not null,
primary key(c,d),
foreign key(g) references E2(g)
);



/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
This can correspond to the relationship of children and female. 
E1 represents the children while children only have one natural mother.
E2 represents the female while one female can have none or many children.
S can represnets the blood relationship.
Under this case, A can represent the birth certification number, 
B represents gender, C represents name and D represents ID number.
J represents gender, K represents country, G represents ID number,
H represents address.
F can denote the birth date.

*/

