/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231971E>                                         */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT av.name AS app, c.name AS country
FROM available av, country c, store s1, store s2
WHERE av.country = c.code3
AND c.continent_name = 'Europe'
AND av.name = s1.name
AND av.name = s2.name
AND s1.os = 'iOS' 
AND s2.os = 'Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name 
FROM country c
GROUP BY c.name
HAVING COUNT(*)>1
ORDER BY c.name;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name 
FROM country c
GROUP BY c.name
HAVING COUNT(*)>1
ORDER BY c.name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT av.name 
FROM available av
WHERE NOT EXISTS(
	SELECT * 
	FROM country c
	WHERE c.continent_name = 'Oceania' AND NOT EXISTS(
		SELECT *
		FROM store s
		WHERE s.name = av.name AND av.country = c.code3));

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, count(*) AS count
FROM available av, country c
WHERE av.country = c.code3
GROUP BY av.country, c.name
ORDER BY count DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1_S(
A VARCHAR(64) NOT NULL,
B VARCHAR(64) NOT NULL,
C VARCHAR(64) NOT NULL,
D VARCHAR(64) NOT NULL,
F VARCHAR(64) NOT NULL,
PRIMARY KEY(A,C,D)
FOREIGN KEY(E2G) REFERENCES E2(G));

CREATE TABLE IF NOT EXISTS E2(
J VARCHAR(64) NOT NULL,
K VARCHAR(64) NOT NULL,
G VARCHAR(64) NOT NULL,
H VARCHAR(64) NOT NULL,
PRIMARY KEY(G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
This ER diagram can be used to describe the relationship between government head 
and parliament members. E1 is composed of several government department. E2 is the 
set of parliament member. R is the head of each government department. 
A,B,C,D are department name, department function, department code and candidancy. 
F is the job description of the parliament head. G is the name of the person. 
J, K, H are the marriage status, education and sex of parliament members. 
Each governmetn department must have a head and the head can be in parliament, 
but parliament can have members not from any department.
*/

