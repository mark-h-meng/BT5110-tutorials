/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231993X                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct c.continent_name, c.continent_code
from country as c; 

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


select a.name as app, c.name as country
from app as a, store as s, appfunctionality as af, available as av, country as c, store as s2
where a.name = s.name and s.name=af.name and af.name = av.name and av.country = c.code3
and c.continent_name = 'Europe'
and s.os = 'Android'
and a.name = s2.name and s2.name=af.name and af.name = av.name and av.country = c.code3
and c.continent_name = 'Europe'
and s2.os = 'iOS'
and s2.name = s.name
group by a.name, c.name, c.continent_name;


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c1.name from country as c1
group by c1.name
having count(c1.continent_name)>=2
order by c1.name;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct c1.name 
from country as c1, country as c2
where c1.name = c2.name and c1.continent_name <> c2.continent_name
order by c1.name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct a.name
from app as a, store as s, appfunctionality as af, available as av, country as c
where a.name = s.name and s.name=af.name and af.name = av.name and av.country = c.code3
and c.continent_name = 'Oceania'
and s.os in (select distinct s2.os from store as s2)
order by a.name;




/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.name, count(distinct a.name)
from app as a, store as s, appfunctionality as af, available as av, country as c
where a.name = s.name and s.name = af.name and af.name = av.name and av.country = c.code3
group by c.name
order by count(distinct a.name) desc
limit 16;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

--take the comments below as my attempt at answer

/*
CREATE TABLE IF NOT EXISTS E1(
	A text(14) PRIMARY KEY,
	B text(14),
	C text(14),
	D text(14)
	primary key( C,D ) );
	
CREATE TABLE IF NOT EXISTS E2(
	G text(14) PRIMARY KEY,
	J text(14),
	K text(14),
	H text(14) );
	
create table if not exists S(
F)
references E1(A,B,C) 
references E2(G) );

*/

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

There is 1 to 1 relationship from E1 to S.
There is optional to many relationship from E2 to S.

E1 and E2 are linked by relationship S.

A real life example of a one to one and one to many relationship could be for example:
Entity E1 phd student can only have one supervisor, and minimum need one supervisor.
Entity E2 academic staff, some can supervisor many students. Some academic staff do not supervise
any students.
The relationship S is Supervise.




*/

