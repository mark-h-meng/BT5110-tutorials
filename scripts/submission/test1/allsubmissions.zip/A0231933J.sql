/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231933J>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name,continent_code
from country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct a1.name as app,c.name as country
from appfunctionality a1, available a2, country c
where a1.name=a2.name
and a2.country=c.code3
and a1.functionality='contact tracing'
and c.continent_name='Europe'
and a1.name in(
select distinct s1.name
from store s1, store s2
where s1.name=s2.name
and s1.os<>s2.os);
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c
group by c.name
having count(*)>1
order by c.name asc;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c1.name
from country c1, country c2
where c1.name=c2.name
and c1.continent_code<>c2.continent_code
order by c1.name asc;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name
from available a, country c
where a.country=c.code3
and c.continent_name='Oceania'
and a.name in (
select distinct s1.name
from store s1, store s2
where s1.name=s2.name
and s1.os<>s2.os)
order by a.name;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name,count(*)
from available a,country c
where a.country=c.code3
group by c.name
order by count(*) desc
limit 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E2 (
G VARCHAR(64) not null PRIMARY KEY,
H VARCHAR(64) not null,
J VARCHAR(64) not null,
K VARCHAR(64) not null);

CREATE TABLE IF NOT EXISTS E1_S (
A VARCHAR(64) not null,
B VARCHAR(64) not null,
C VARCHAR(64) not null,
D VARCHAR(64) not null,
F VARCHAR(64) not null,
I VARCHAR(64) not null,
PRIMARY KEY (A,B,C),
FOREIGN KEY (I) REFERENCES E2(G));
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

In a neighbourhood, every dog has its sole owner. People living in the neibourhood may have 
one or more dogs or they don't want to have dogs. We assume that in this neighbourhood, there is no same
dogs who have same name, dog breed and origin. The pets have their name, dog breed, origin and hair color. 
They are raised by people in the neighborhood. People have their identity card number, hobby, gender and job. 
In this case, the entity set E1 is dogs and entity E2 is people. Relationship set S is that the dogs are raised
by people. For the attributes A,B,C and D of E1 dogs, they are name, dog breed,origin and hair color, respectively. 
Among these, name, dog breed and origin are the candidate keys because these three attributes can determine the dog.
For the attributes G,H,J and K of entity E2 people, they are identity card number, hobby, gender and job, respectively
and identity card number is the candidate key as every people have their unique identity number. For the attribute F
for the relationship S, it is time for how long people have had the dog. Because every dog must have its sole owner, 
therefore, the participation constraint for E1 dogs is (1,1). For people, they may not have dogs or they may have one 
or more dogs, therefore, the participation constraint for people is (0,n).
*/

