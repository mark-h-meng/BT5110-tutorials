/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0080400B>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT av.name AS app, c.name AS country
FROM available av, country c, appfunctionality af, store s1, store s2
WHERE av.country = c.code3 AND
	af.name = av.name AND
	s1.name = av.name AND
	s2.name = s1.name AND
	c.continent_name = 'Europe' AND
	af.functionality = 'contact tracing' AND
	s1.os='iOS' AND
	s2.os='Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(*) >1
;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name AND
	c1.continent_name <> c2.continent_name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT av1.name
	FROM available av1, country c1
	WHERE av1.country = c1.code3 AND
		c1.continent_name='Oceania'
EXCEPT
SELECT Oc_app.name
FROM
	(SELECT av.name, s.os
	FROM available av, country c, store s
	WHERE av.country = c.code3 AND
		c.continent_name='Oceania'
	GROUP BY av.name, s.os) AS Oc_app
LEFT JOIN store s ON Oc_app.name = s.name AND Oc_app.os=s.os
WHERE s.name ISNULL;



/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(*)
FROM available av, country c
WHERE av.country = c.code3
GROUP BY c.name
ORDER BY COUNT(*) DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E2 (
G text PRIMARY KEY,
H text NOT NULL,
J text NOT NULL,
K text NOT NULL
);

CREATE TABLE E1S (
A text PRIMARY KEY,
B text NOT NULL,
C text NOT NULL,
D text NOT NULL,
F text NOT NULL,
G text NOT NULL REFERENCES E2(G),
UNIQUE (C,D)
);


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Primary Key:
A is able to identify the entities in E1 with the smallest number of attributes
hence it is a suitable primary key for E1. Similarly for G in E2.
Foreign Key:
The G columns in E1 references G in E2 as G is the primary key of E2 (hence a unique entity).

To celebrate the end of BT5101 test, the professor decide to treat each student in the class to
a Starbucks drink, each student can only get 1 Grande drink.
E1 is the list of BT5101 students class of 2021 obtained from teh school. E2 listed the drinks available at Starbucks.
Entity E1:
A: NUS student number unique to each NUS student
B: Name of student, some students may have the same name.
C: passport number
D: country of origin. Together with C, they uniquely identify the student (in case some countries use similar numbering system)

Relationship S (favorite drink)  - matches every single student to their favorite Starbucks drink.
F: any remarks regarding the drink (use soymilk etc)

Entity E2:
G: name of Starbucks drink (unique, eg. Java Chips Frappucino)
H: price of the drink (Grande)
J: calories
K: whether it is a cold or hot drink

*/

