/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0124216U                */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code 
FROM country c

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct av.name as "app", c.name as "country"
from available av, country c, store s1, store s2
where av.country=c.code3
and s1.name=av.name
and s2.name=av.name
and c.continent_name ='Europe'
and (s1.os='iOS' and s2.os='Android');

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c
group by c.name
having count(distinct c.continent_name)>1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c1.name
from country c1, country c2
where c1.name=c2.name
and c1.continent_name<>c2.continent_name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct av.name
from available av, country c
where av.country=c.code3
and c.continent_name ='Oceania'
and av.name in (
select distinct s1.name
from store s1, store s2
where s1.name=s2.name
and s1.os<>s2.os);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name, count(distinct av.name) as "count"
from available av, country c
where av.country=c.code3
group by c."name"
order by "count" desc
limit 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table if not exists E1 (
	A text not null,
	B text not null,
	C text not null,
	D text not null,
	primary key (A, C, D)
	);

create table if not exists E2 (
	G text primary key not null,
	H text not null,
	J text not null,
	K text not null
	);

create table if not exists S (
	A text not null,
	C text not null,
	D text not null,
	G text not null,
	F text not null,
	primary key (A, C, D, G),
	foreign key (A, C, D) references E1(A, C, D),
	foreign key (G) references E2(G)
	);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 could be the course schedule of different university in Singapore across different years. 
Meaning A would be "university name", C would be "year" 
and D would be "Module Code". Since Module code can be similar for  different
univerities and in different years, hence the primary keys, or candidate keys are A, C, D that can uniquely 
identify a row. 
The column B, can then by day and timing of the module, like Monday, 1.30pm.

The table E2 can contain a list of academics currently employed in Singapore,
such that whether it is a Singaporean, PR, or EP holder, they would have a unique
identification number given. The column G would therefore be "IC", and the rest of the 
columns can be particulars of the said person, such as J can be first name, K can be last name,
and H shows whether the person is a Singaporean, PR or EP holder.

The table S will therefore be the professor in charge of the module at the said university,
hence it will contain A (university name), C (year), D (Module Code), and
G (IC). The column F could be the overall average difficulty of the module, with a
range from 1-5 in that particular university for that particular year. 

As such, since the cardinality constraints of E1 is (1,1), which means that every row must
be connected to one row in E2, which is indeed true since every module code has to have one
professor in charge of teaching and creating the materials for that particular. 
For table E2, the cardinality constraint is (0,n), which means a professor, 
or academic currently employed in a univerity in singapore,
can be in charge of more than 1 module, or even not teach any modules in the home university.
Hence this example fulfills the cardinality constraints of a academic person, found in table E2, 
working in a university can be in-charge of 0 to n modules, while each module, found in table E1,
can only have one professor as the main in-charge. The relationship table S can therefore be found
with the average difficulty rating of each module, based on people who have audited or taken the class,
and that each module will show the overall difficulty for that year, taught by the particular professor.

*/

