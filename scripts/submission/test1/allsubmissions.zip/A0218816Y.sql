/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218816Y						                    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT continent_name, continent_code
FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT av.name AS app, c.name AS country
FROM available av, country c, store s
WHERE av.country = c.code3
AND c.continent_name = 'Europe'
AND av.name = s.name
AND s.os = 'iOS'

INTERSECT(

SELECT av.name AS app, c.name AS country
FROM available av, country c, store s
WHERE av.country = c.code3
AND c.continent_name = 'Europe'
AND av.name = s.name
AND s.os = 'Android'
);

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT name
FROM country
GROUP BY name
HAVING count(*) > 1
ORDER BY name ASC;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name
FROM app a, available av, country c, store s
WHERE a.name = av.name
AND av.country = c.code3
AND continent_name = 'Oceania'
AND a.name = s.name
AND s.os = 'iOS'

INTERSECT(
SELECT a.name
FROM app a, available av, country c, store s
WHERE a.name = av.name
AND av.country = c.code3
AND continent_name = 'Oceania'
AND a.name = s.name
AND s.os = 'Android'
)

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name, n.count
FROM country c, (
	SELECT av.country, count(DISTINCT av.name) AS count
	FROM available av
	GROUP BY av.country
	ORDER BY count DESC) AS n
WHERE n.country = c.code3
ORDER BY n.count DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS E1 (
	A VARCHAR(256),
	B VARCHAR(256) NOT NULL,
	C VARCHAR(256),
	D VARCHAR(256),
	PRIMARY KEY (A, C, D));

CREATE TABLE S (
	F VARCHAR(256) NOT NULL);

CREATE TABLE IF NOT EXISTS E2 (
	G VARCHAR(256) PRIMARY KEY,
	H VARCHAR(256) NOT NULL,
	J VARCHAR(256) NOT NULL,
	K VARCHAR(256) NOT NULL);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

The ERD could represent a relationship between an amateur football player who is registered at a amateur football club.
Table E1 represents the football player, S represents the footballer player "is registered" at a football club, and E2 represents the amateur club.
Each player must be registered at one club but cannot be registered at multiple clubs.
Each amateur club can have 0 or n registered players.

A = Registration number
B = First name
C = Last name
D = Birthday

F = Active or non-active player

G = Club registration nymber
H = City
J = Sports
K = Club name


*/

