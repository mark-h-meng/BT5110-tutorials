/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231849X>                  */
/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.continent_name,c.continent_code from country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name as app,c.name as country
from app a, store s,country c,available ava
where a.name=s.name
and a.name=ava.name
and s.os='iOS'
and ava.country=c.code3
and c.continent_code='EU'
intersect
select a.name as app,c.name as country
from app a, store s,country c,available ava
where a.name=s.name
and a.name=ava.name
and s.os='Android'
and ava.country=c.code3
and c.continent_code='EU';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name from country c
group by c.name
having count(distinct c.continent_code)>=2;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c1.name
from country c1,country c2
where c1.name=c2.name
and c1.continent_name<>c2.continent_name
order by c1.name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name 
from app a,store s,country c,available ava
where a.name=s.name
and a.name=ava.name
and ava.country=c.code3
and c.continent_code='OC'
and not exists (select s2.os from store s2
where a.name=s2.name
and s.os<>s2.os);


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name, count(a.name) from country c,app a,available ava
where a.name=ava.name
and ava.country=c.code3
group by c.name
order by count(a.name) desc;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table if not exists E2(
J text not null,
G text not null,
K text not null,
H text not null,
primary key (G))

create table if not exists E1_S(
A text not null unique,
B text not null,
C text not null,
D text not null,
F text not null,	
primary key(C,D),
G text references E2(G))
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 is the people who already got employed by a company and signed a contract.
E2 is the company set.
S can be the contracts that link the employees to the companies.

For E1 people, A can be his or her DNA sequence.
B can be the gender.
C and D can be the Country Code and the ID number of his or her country,
which together can determine who this guy is.

For E2 company,G can be the company registration number that is unique all around the world,
which can determine what company it is.
J,K,H can be something like how many charis the company have, how many countries the company located,
and the revenue of last year.

For S contracts, F can be the contract sign date.

So, for the E1 and S (1,1), because I set E1 to be people who already got employed by a company and signed a contract,
every one in the E1 have to sign one(minimum) and only sign one(maximum) contract to a company. 

For each contract, it has a sign date F.

For E2 and S(0,n), some company might be a start-up company that have not yet sign up contract to hire any people, 
which refers to the 0(minimum) participation in S. Some company might hire many different people with contracts, 
which refers to the n(maximum) particitation in S.

In total, one people one contract refering to one company.
But one company can either sign no contract with any people or sign up contracts with many different people.

To emphasize entity E1 again, people here are those who already got employed by some company
and signed a contract with this company.
*/ 

