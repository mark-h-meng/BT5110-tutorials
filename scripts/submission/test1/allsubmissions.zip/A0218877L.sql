/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218877L						                    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
SELECT DISTINCT CONTINENT_NAME, CONTINENT_CODE FROM COUNTRY;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/

SELECT DISTINCT AF1.NAME AS APP, C1.NAME AS COUNTRY
FROM APPFUNCTIONALITY AF1 
INNER JOIN AVAILABLE AV1 ON AF1.NAME=AV1.NAME
INNER JOIN COUNTRY C1 ON AV1.COUNTRY=C1.CODE3
INNER JOIN STORE STORE1 ON AF1.NAME=STORE1.NAME 
INNER JOIN (
SELECT DISTINCT AF.NAME AS APP, C.NAME AS COUNTRY
FROM APPFUNCTIONALITY AF 
INNER JOIN AVAILABLE AV ON AF.NAME=AV.NAME
INNER JOIN COUNTRY C ON AV.COUNTRY=C.CODE3
INNER JOIN STORE STORE ON AF.NAME=STORE.NAME 
WHERE 
AF.FUNCTIONALITY = 'contact tracing' 
AND STORE.OS IN ('iOS')
AND C.CONTINENT_NAME = 'Europe') IOS
ON AF1.NAME = IOS.APP
WHERE 
AF1.FUNCTIONALITY = 'contact tracing' 
AND STORE1.OS IN ('Android')
AND C1.CONTINENT_NAME = 'Europe'

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/

SELECT DISTINCT NAME FROM (
SELECT NAME, COUNT(*) AS COUNT FROM COUNTRY
GROUP BY NAME
HAVING COUNT(*)>1) CNT
ORDER BY NAME;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/

SELECT DISTINCT NAME FROM (
SELECT C1.NAME, C1.CONTINENT_CODE AS CC1, C2.CC2 FROM COUNTRY C1
INNER JOIN 
(SELECT NAME, CONTINENT_CODE AS CC2 FROM COUNTRY) C2
ON C1.NAME=C2.NAME) JOINCTRY
WHERE CC1 <> CC2
ORDER BY NAME;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/

SELECT COUNT(DISTINCT OS) AS OS1 FROM STORE;

SELECT DISTINCT AVAIL.NAME FROM AVAILABLE AVAIL 
INNER JOIN COUNTRY COUNTRY ON AVAIL.COUNTRY=COUNTRY.CODE3
INNER JOIN (
	SELECT NAME, COUNT(*) AS COUNT FROM STORE
	GROUP BY NAME ) STORE_OS
	ON AVAIL.NAME=STORE_OS.NAME 
INNER JOIN (
	SELECT COUNT(DISTINCT OS) AS OS1 FROM STORE ) COUNT_OS  
	ON STORE_OS.COUNT = COUNT_OS.OS1
WHERE COUNTRY.CONTINENT_NAME = 'Oceania'
ORDER BY AVAIL.NAME;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/

SELECT C.NAME, AV.COUNT FROM COUNTRY C
INNER JOIN
(SELECT COUNTRY, COUNT(*) AS COUNT FROM AVAILABLE
GROUP BY COUNTRY
ORDER BY COUNT DESC LIMIT 6) AV
ON C.CODE3=AV.COUNTRY
ORDER BY COUNT DESC;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/

DROP TABLE IF EXISTS E2; CREATE TABLE E2(
G TEXT PRIMARY KEY,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL);

DROP TABLE IF EXISTS S; CREATE TABLE S(
F TEXT NOT NULL,
G TEXT REFERENCES E2(G),
UNIQUE (F,G));

DROP TABLE IF EXISTS E1; CREATE TABLE E1(
A TEXT PRIMARY KEY,
B TEXT NOT NULL,
C TEXT,
D TEXT,
FOREIGN KEY (C, D) REFERENCES S(F,G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

E2 can be universities in SG with name G as the primary key
H, J, K can be other attributes such as acronym of name, address, ranking in the world

E1 can be courses provided by universities in SG 
A can be the primary key on course provided in student study year 1, 2, ...
B can be the name of the courses
Because courses code might have have duplicates among universities and even faculties in the same univerisies, 
C,D can be a combination of university name and created date to be the foreign key.

S can be the relation created by with F as the created date

*/

