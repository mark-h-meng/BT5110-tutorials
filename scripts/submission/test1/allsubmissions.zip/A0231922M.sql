/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231922M           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name,continent_code
from country;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct a.name as app, c.name as country
FROM available a, country c, store s1, store s2
where s1.name = a.name
and s2.name = a.name
and a.country = c.code3
and c.continent_name ='Europe'
and s1.os = 'Android' 
and s2.os = 'iOS'
and s1.name = s2.name
;
-- select distinct av.name as app, c.name as country
-- FROM available av, country c, store s
-- where s.name = av.name
-- and av.country = c.code3
-- and c.continent_name ='Europe'
-- and s.os = 'iOS'
-- intersect
-- select distinct av.name as app, c.name as country
-- FROM available av, country c, store s
-- where s.name = av.name
-- and av.country = c.code3
-- and c.continent_name ='Europe'
-- and s.os = 'Android' 
-- ;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
from country c
group by c.name
having count(c.continent_name) > 1
order by c.name asc;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT distinct c.name
from country c, country C2
where c.name = c2.name 
and c.continent_name <> c2.continent_name
order by c.name asc;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name
from available a, country c
where c.code3 = a.country
and c.continent_name ='Oceania'
and not exists
(select *
from store s1
where s1.os = all (select distinct s2.os from store s2)
order by s1.name);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name, count(*)
from country c, available a
where a.country = c.code3
group by c.name 
order by count(*) desc limit 6;



/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E2 (
J text not null,
K text not null,
G text primary key,
H text not null
);


CREATE TABLE IF NOT EXISTS E1 (
A text ,
B text not null,
C text ,
D text ,
F text not null,
primary key (A,C,D),
G text references E2(G) deferrable
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/* the real world example

E2: parliament_member 
E1: Government_divisions
R: Head
The entity set Government_divisions has attributes division_code, division_name, floor_number,
and member_size, the Primary key of government is the composite 
primary key (division_code, division_name, floor_number), which can be used to unique identify one instance.

the entity set parliament_member has attributs member_first_name, member_last_name,
member_age, and member_id. The primary key is member_id.

The relationship set Head has one attribute since, which describes the time when the parliament member is nominated a role in the government

Each government division can have one and only one parliament member searving as the head,
therefore there is both a minimum and a maximum of one relationship.

However, each parliament member can head many government divisions if she/he is very potent, 
or head zero government division if she/he got unlucky.

Since Government_divisions can have one and only one parliament member to head it, the member_id of this heading member 
need to be the foreign key of Government_divisions. In this way the relationships between these 2 entities are preserved.
More over, the attribute 'since' from the relation set Head can be included in the entity set Government_divisions. 


*/

