/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0119430N                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT ap.name AS app, c.name AS country
FROM app ap, available av, country c, store s1, store s2, appfunctionality af
WHERE ap.name = av.name
AND av.country = c.code3
AND ap.name = af.name
AND ap.name = s1.name
AND ap.name = s2.name
AND c.continent_code = 'EU'
AND s1.os = 'Android'
AND s2.os = 'iOS'
AND af.functionality = 'contact tracing';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(c.continent_name)>1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1
WHERE EXISTS(
	SELECT *
	FROM country c2
	WHERE c1.name = c2.name
	AND c1.continent_name <> c2.continent_name

);
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE VIEW appcount AS
SELECT c.name, COUNT(*) as count
FROM app ap, available av, country c
WHERE ap.name = av.name
AND av.country = c.code3
GROUP BY c.name;

SELECT loser.name, loser.count
FROM appcount loser LEFT JOIN appcount winner
ON loser.name <> winner.name
AND loser.count < winner.count
GROUP BY loser.name, loser.count
HAVING COUNT(loser.name) < 6
ORDER BY loser.count DESC;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E2 (
	J TEXT NOT NULL,
	K TEXT NOT NULL,
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL

);



CREATE TABLE E1_S (
	A TEXT PRIMARY KEY,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	F TEXT NOT NULL,
	G TEXT REFERENCES E2(G)
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
This can be the emergency contact of a student.
E1 is the student set.
A: ID
B: name
C: student number
D: university

E2 is the emergency contact person.
J is the address.
K is the name of the contact person.
G is the ID of the contact person.
H is the phone number.

S is the relationship "has emergency contact of"
F can be the date the contact is updated.

*/

