/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218871X

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name,continent_code
FROM country;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT s1.name
FROM store s1,store s2, available av,country c
WHERE s1.name = s2.name AND c.code3 = av.country AND av.name = s1.name
AND s1.os = 'iOS' AND s2.os = 'Android' AND c.continent_code = 'EU';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT name
FROM country
GROUP BY name
HAVING count(*) = 2;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_code <> c2.continent_code;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT name
FROM available av
WHERE NOT EXISTS
	(SELECT *
	 FROM  country c
	 WHERE av.country = c.code3 AND c.continent_code = 'OC'
	 AND NOT EXISTS (
	 	SELECT *
		FROM store st
		WHERE av.name = st.name)
	 );


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(*) AS count
FROM available av,country c
WHERE av.country = c.code3
GROUP BY c.name
ORDER BY count DESC LIMIT 6
;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E2(
G TEXT PRIMARY KEY,
J TEXT NOT NULL,
K TEXT NOT NULL,
H TEXT NOT NULL
);


-- (1,1) participation, so merge E1 and S using the primary key of E1
CREATE TABLE IF NOT EXISTS S(
A TEXT,
B TEXT NOT NULL	,
C TEXT,
D TEXT,
E TEXT NOT NULL,
F TEXT NOT NULL,
G TEXT REFERENCES E2(G),
PRIMARY KEY(A,C,D));



/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
At the beginning of this semester, each student is required to choose only one Co-curricular activities (CCA).
They have to choose one, so it is (1,1) participation constraint.
Student can be identified by the combination of class, name, year of study and CCA can be identified by their name.

E1 - student
S - choice
E2 CCA

A name
B gender
C year of study
D class
F registration date and time
J Fee
K type
H venue
G name of CCA


*/
