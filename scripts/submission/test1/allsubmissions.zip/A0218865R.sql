/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218865R                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name, continent_code 
from country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select app, name as country from (
select app.name as app, store, os, available.country, c.name
from app, store, available, country c
where app.name = store.name
and app.name = available.name
and available.country = c.code3
and c.code3 in (select code3 from country
where continent_name = 'Europe')
) temp
group by app, name
having count(*)=2;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select name from country
group by name
having count(distinct continent_name)>1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct name from country
where name not in (select name from country
			  group by name
				  having count(distinct continent_name)=1);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select app as name from (
select app.name as app, store, os, available.country, c.name
from app, store, available, country c
where app.name = store.name
and app.name = available.name
and available.country = c.code3
and c.code3 in (select code3 from country
where continent_name = 'Oceania')
) temp
group by app, name
having count(*)>=ALL(select count(distinct os) from store);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
(
select name, count(distinct app) as count from (
select distinct app.name as app, available.country, c.name
from app, available, country c
where app.name = available.name
and available.country = c.code3
) temp 
group by name) order by count desc
limit 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E1 (
A TEXT PRIMARY KEY,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL);

-- note that E1 can be combined with S as it is a 1-1 relationship
-- the code below will be the combined DDL
-- CREATE TABLE E1 (
-- A TEXT PRIMARY KEY,
-- B TEXT NOT NULL,
-- C TEXT NOT NULL,
-- D TEXT NOT NULL,
-- F TEXT NOT NULL);

CREATE TABLE E2 (
A TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL,
G TEXT PRIMARY KEY,
H TEXT NOT NULL);


CREATE TABLE S(
A TEXT NOT NULL,
F TEXT NOT NULL,
G TEXT NOT NULL,
PRIMARY KEY (A, G),
FOREIGN KEY (A) REFERENCES E1(A),
FOREIGN KEY (G) REFERENCES E2(G)
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 can be a list of companies in Singapore, with some company related attributes.
Attribute A can be the ACRA registered company UEN.
Attribute B can be the year of registration.
Attribute C can be the country of the company.
Attribute D can be the company name.
C and D can be candidate key because the combination of company name + country uniquely identifies the company in Singapore.


S can be the relationship between the Singapore registered company UEN and the company CEO. 
The relationship is 1-1 because a registered company must have a CEO.
Attribute F can be the number of years of being the CEO.


E2 can be a list of names of CEOs of companies in the world.
Attribute G can be the name of the company CEO.
Attribute J can be the country of the company
Attribute K can be the industry of the company.
Attribute H can be the sector of the company.
The participation constraint is (0,n) because:
1. the names in E2 may not be a CEO of a company in Singapore, but in other countries -> hence the minimum value is 0
2. the names in E2 may be a CEO of multiple companies in Singapore -> hence the maximum value is n

*/

