/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0142279B>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT a.name AS app, c.name AS country
FROM available a, country c, store s1, store s2
WHERE a.country = c.code3
AND a.name = s1.name
AND a.name = s2.name
AND s1.OS = 'iOS' 
AND s2.OS = 'Android'
AND s1.name = s2.name
AND c.continent_name = 'Europe'

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING c.count > 1
ORDER BY c.name

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_name <> c2.continent_name
ORDER BY c1.name

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT s0.name
FROM store s0,
(SELECT DISTINCT a.name, s.os
FROM available a, country c, store s
WHERE a.country = c.code3
AND c.continent_name = 'Oceania'
AND a.name = s.name) AS oc1,
(SELECT DISTINCT a.name, s.os
FROM available a, country c, store s
WHERE a.country = c.code3
AND c.continent_name = 'Oceania'
AND a.name = s.name) AS oc2
WHERE s0.name = oc1.name
AND oc1.os='Andriod'
AND oc2.os='iOS'
AND oc1.name = oc2.name

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E2(
J TEXT NOT NULL,
K TEXT NOT NULL,
G TEXT PRIMARY KEY,
H TEXT NOT NULL);

CREATE TABLE E1_S(
A TEXT UNIQUE NOT NULL,
B TEXT NOT NULL,
C TEXT,
D TEXT,
F TEXT NOT NULL,
G TEXT NOT NULL,
PRIMARY KEY(C,D),
FOREIGN KEY (G) REFERENCES E2(G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 is membership account information
A = membership account ID
B = membership level (bronze, silver, gold)
C = account manager employee ID
D = customer name

E2 is the customer information
G = passport number of the customer
J = name of the customer
K = sex of the customer
H = age of the customer

S = become member record
F = membership account creation date (when become member)

participation constraints:
(1,1) = one membership account can only have one customer
(0,n) = there can be many customers having membership
there also can be customer has not become member (i.e. no membership)

candidate keys:
For E1, there are 2 candidate keys, A or CD
A = membership account ID can be used to locate member information
CD = membership information can also be identified via the corresponding account manager employee ID and the custommer name he/she serves
(assume that usually one account manager will not serve 2 customers with the same name)


*/

