/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231929Y         */

/************************************************************************/
/*                                                                      */
/* Question 1.a  Print the names and ISO two letter codes of the different continents. The
result should be similar to that in the table below in any order.                                                    */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*  Find the contact tracing apps that are available in Europe and work for both
iOS and Android operating systems. For each app, print the name of the app (rename the
column as “app”) and the name of the                                                           */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT a.name AS app, c.name AS country
FROM app a, available ava, country c, store s1, store s2, functionality f
WHERE a.name = ava.name
AND ava.country = c.code3
AND (s1.name = a.name AND s1.os = 'iOS')
AND (s2.name = a.name AND s2.os = 'Android')
AND c.continent_name= 'Europe'
AND f.type = 'contact tracing'
GROUP BY a.name,c.name,c.continent_name,c.continent_code,c.code2;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/* Find the names of the countries that are spanning over several continents.
Use aggregate functions. 
The result should be similar to that in the table below in any order.                                                                     */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c1.name
FROM country c1, country c2
WHERE c1.code3 = c2.code3
AND c1.continent_code <> c2.continent_code
GROUP BY c1.name;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.code3 = c2.code3
AND c1.continent_code <> c2.continent_code;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*   Find the names of the apps available in countries in Oceania 
that work for all recorded operating systems.                                                          */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT a.name
FROM app a, available ava, country c, store s
WHERE a.name = ava.name
AND ava.country = c.code3
AND c.continent_code = 'OC'
AND c.continent_name = 'Oceania'
AND s.name = a.name
GROUP BY a.name, s.name, s.store, s.os;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*    Find the countries with the top 6 largest number of apps 
available (this is
a dense ranking of the countries according to the number of apps).                                                   */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(a.name) AS count
FROM country c, app a, available ava
WHERE a.name = ava.name
AND ava.country = c.code3
GROUP BY c.name
ORDER BY count DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1 (
	A VARCHAR(20),
	B VARCHAR(20) NOT NULL,
	C VARCHAR(20),
	D VARCHAR(20),
	PRIMARY KEY (A,C,D));
	
CREATE TABLE IF NOT EXISTS E2 (
	J VARCHAR(20) NOT NULL,
	G VARCHAR(20) PRIMARY KEY ,
	H VARCHAR(20) NOT NULL,
	K VARCHAR(20) NOT NULL);
	
CREATE TABLE IF NOT EXISTS S (
	F VARCHAR(20) NOT NULL,
	G VARCHAR(20) NOT NULL,
	A VARCHAR(20) NOT NULL,
	C VARCHAR(20) NOT NULL,
	D VARCHAR(20) NOT NULL,
	PRIMARY KEY (A,C,D,G),
	FOREIGN KEY (A,C,D) REFERENCES E1(A,C,D),
	FOREIGN KEY (G) REFERENCES E2(G)
);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 is a government. 
In E1, A is the country of the government, B is the number of parliament in the government
C is the name of the government, and D is the head of the government.

E2 is the member of parliament.
G is the name of each of head of the parliament,
J is the number of member in the parliament,
H is the abbreviation of the Abbreviation,
K is the address of the headquarter for the parliament.

S is the head of each parliament in the government.
F is the Time in office of the head of each parliament.

*/

