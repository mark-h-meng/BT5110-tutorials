/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231886W                                           */
/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT
    continent_name
    , continent_code
from
    country
group by
    continent_name
    , continent_code;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT
    a.name as app
    , d.name as country
FROM
    app a
    left JOIN
        appfunctionality b
    ON
        a.name = b.name
    AND
        b.functionality = 'contact tracing'
    left JOIN
        available c
    on
        a.name = c.name
    left JOIN
        country d
    on
        c.country = d.code3
where
    d.continent_name = 'Europe';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select
    a.name
from
    country a
group by
    a.name
having
    count(distinct a.continent_name) > 1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select
    distinct a.name
from
    country a
    left join
        country b
    on
        a.name = b.name
where
    a.continent_name <> b.continent_name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select
    a.name
from
    app a
    left join
        available b
    on
        a.name = b.name
    left join
        country c
    on
        b.country = c.code3
    and
        c.continent_name = 'Oceania'
where
    a.name not in (
        select
            d.name
        from
            store d
            left join
                app e
            on
                d.name = e.name
        where
            d.os is null);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select
    a.name
    , count(distinct c.name) as count
from
    country a
    left join
        available b
    ON
        a.code3 = b.country
    left join
        app c
    on
        b.name = c.name
group by
    a.name
order by
    count(distinct c.name) desc
limit 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1 (
A TEXT,
C TEXT,
D TEXT,
B TEXT NOT NULL,
F TEXT NOT NULL,
PRIMARY KEY (A, C, D));

CREATE TABLE E2 (
G TEXT,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL,
PRIMARY KEY (G));

CREATE TABLE S (
A TEXT REFERENCES E1(A),
C TEXT REFERENCES E1(C),
D TEXT REFERENCES E1(D),
G TEXT REFERENCES E2(G),
F TEXT NOT NULL,
FOREIGN KEY(A, C, D) REFERENCES E1(A, C, D),
PRIMARY KEY ((A, C, D, G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1: zoo species information
attributes:
    A: zoo species family name;
    C: zoo species genus name;
    D: zoo species species name;
    B: zoo species common name;

S: zoo species sector information
attributes:
    A: zoo species family name;
    C: zoo species genus name;
    D: zoo species species name;
    F: species sector identification number;
    G: maintenance personnal identification number

E2: zoo maintenance personnal information
attributes:
    G: maintenance personnal identification number
    H: personnal position;
    J: personnal name;
    K: personnal gender;

explantion:
My real-world example is a zoo maintenance system. E1 is the information of 
species including plants and animals; E2 is the personnal information; S is 
the maintenance record of personnal to species sector.

participation constraints:
As family, genus and species identifies a species, and a species belongs to 
one species sector, the cardinality is (1,1) for species and sectors.

As a species sector is maintained by zero or more personnal(plants may need 
no regular maintenance), and every personnal may be in charge of zero or 
more sectors according to his/her position, the cardinality is (0,n) for 
sector and personnal.

candidate key:
    E1: {A,C,D}
        family, genus and species specifies an animal and its common name(which 
        could be duplicate among species);
    E2: {G}
        personnal ID identifies a person;
    S: {A,C,D,G};
        a personnal may take care of multiple sectors or none; a sector may 
        need multiple maintainer or none.
*/

