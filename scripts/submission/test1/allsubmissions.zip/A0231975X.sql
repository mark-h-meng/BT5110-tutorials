/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231975X>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select Distinct continent_name, continent_code
from country

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select ap.name as app, c.name as country
from app ap, available av, country c, store s, appfunctionality af
where ap.name = s.name
and ap.name = av.name
and ap.name = af.name
and c.code3 = av.country
and af.functionality = 'contact tracing'
and c.continent_code = 'EU'
and (s.os = 'iOS' or s.os ='Android');

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select c.name
from country c
group by c.name
having count(*) > 1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select distinct c1.name
from country c1 left outer join country c2 on c1.name =c2.name
where c1.continent_name <> c2.continent_name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select distinct ap.name
from app ap, available av, country c, store s
where ap.name = s.name
and ap.name = av.name
and c.code3 = av.country
and c.continent_code = 'OC'
and s.os = any(
Select distinct os
from store);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select c.name, count(distinct ap.name) as count
from app ap, available av, country c
where ap.name = av.name
and c.code3 = av.country
group by c.name 
order by count desc
limit 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1(
A VARCHAR(64) unique,
B VARCHAR(64) not null,
C VARCHAR(64) not null,
D VARCHAR(64) not null,
PRIMARY KEY (C,D));
			 
CREATE TABLE E1(
J VARCHAR(64) not null,
K VARCHAR(64) not null,
G VARCHAR(64) PRIMARY KEY,
H VARCHAR(64) not null);
			 
CREATE TABLE S(
F VARCHAR(64)
A REFERENCES E1(A)
F REFERENCES E2(G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):  
The E1 is employee database. E2 is manager. S is company.
A is employee's identity card number. B is his or her department. C is employee's first name. D is employee's last name.
F is company's name.
J is manager's age. K is manager's department. G is manager's ID. H is manager's gender.
Candidate keys of E1 is A.  Candidate keys of E2 is G.
Participation constraints are one manager can only enter one company, and one employee can enter 0 to infinite companies.*/
/*


*/

