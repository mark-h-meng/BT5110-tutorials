/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0090966R>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name, continent_code from country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct a.name as app, c.name as country
from available a,country c,store s1,store s2
where 
a.country = c.code3
and a.name = s1.name
and a.name = s2.name
and c.continent_name = 'Europe'
and s1.os = 'iOS'
and s2.os = 'Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name from country c
group by c.name
having count(*) >= all (
select count(*) from country c1
group by c1.name);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct name
 from country as a
 where exists (
   select 1
   from   country as a2
   where  a2.name = a.name
   and    a2.continent_name <> a.continent_name)
   order by 1;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct name from available a
where country in (select distinct code3 from country where continent_name = 'Oceania')
and not exists(select * from store s
			  where not exists (select * from store s1
							   where s1.name = a.name
							   and s1.os = s.os));

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name, case when b.cnt is null then 0 else b.cnt end as count
from
(select distinct code3, name from country) a 
left join
(select distinct country, count(name) as cnt from available
group by 1) b 
on a.code3 = b.country
order by 2 desc
limit 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table E1 (
A varchar(32) unique not null,
B varchar(32) not null,
C varchar(32) not null,
D varchar(32) not null,
primary key (C, D)
);

create table E2 (
G varchar(32) primary key,
H varchar(32) not null,
J varchar(32) not null,
K varchar(32) not null
);

create table S (
F varchar(32) not null,
E1C varchar(32) not null,
E1D varchar(32) not null,
E2G varchar(32) not null,
primary key (E1C, E1D, E2G),
foreign key (E1C, E1D) references E1 (C, D),
foreign key (E2G) references E2 (G)
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 is a table/entity with 4 attributes. It has a combination of attributes that identify the entity,
which mean combination of C and D is the primary key of the entity. Or we also can only use A as the primary key
to identity the entity. For example, E1 can be the employee table where C and D are the employee's first name
and last name (please note there is distinct first name + last name, there is no one in the company have the same
full name which is first name + last name here). A can be the employee ID of the employee. This employee ID is unique. 

E2 is a table with 4 attributes and it has G as its primary key. For example this table can be the manager table
and G represents the employee ID of the manager. This employee ID is unique as well.

S is the relationship which joins E1 and E2. For example this can be 'manage'. In this case, one manager can manage
a team which consists 1 or more employee or this manager can be an individual contributor (manage 0 people). 
However, one employee should and only should has one manager. 

*/
