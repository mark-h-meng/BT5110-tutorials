/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231904M                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country AS c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT ap.name AS app, c.name AS country
FROM app AS ap, available AS av, store AS s,
	appfunctionality AS af, country AS c
WHERE ap.name = av.name
AND ap.name = s.name
AND ap.name = af.name
AND af.functionality = 'contact tracing'
AND s.os = 'iOS'
AND av.country = c.code3
AND av.country IN(
	SELECT c.code3
	FROM country AS c
	WHERE c.continent_name = 'Europe')
INTERSECT
SELECT ap.name AS app, c.name AS country
FROM app AS ap, available AS av, store AS s, 
	appfunctionality AS af, country AS c
WHERE ap.name = av.name
AND ap.name = s.name
AND ap.name = af.name
AND af.functionality = 'contact tracing'
AND s.os = 'Android'
AND av.country = c.code3
AND av.country IN(
	SELECT c.code3
	FROM country AS c
	WHERE c.continent_name = 'Europe');
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country AS c
GROUP BY c.name
HAVING COUNT(*) > 1
ORDER BY name ASC;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select DISTINCT a.name from country a
where EXISTS (Select * from country b 
                where (a.name = b.name)
                     and a.continent_code != b.continent_code);
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT ap.name
FROM app AS ap, available AS av, store AS s
WHERE ap.name = av.name
AND ap.name = s.name
AND av.country IN (
	SELECT c.code3
	FROM country AS c
	WHERE c.continent_name = 'Oceania'
	AND NOT EXISTS(
		SELECT *
		FROM store AS s
		WHERE s.os NOT IN(
			SELECT DISTINCT s.os
			FROM store AS s)));
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(*) 
FROM country AS c, available AS av
WHERE c.code3 = av.country
GROUP BY c.name
ORDER BY count DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1(
	A TEXT UNIQUE NOT NULL,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	PRIMARY KEY (C, D));

CREATE TABLE IF NOT EXISTS E2(
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL,
	J TEXT NOT NULL,
	K TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS S(
	F TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	G TEXT NOT NULL REFERENCES E2(G),
	FOREIGN KEY (C, D) REFERENCES E1(C, D));
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 as government, E2 as parliament_member, S as head.
Each government must have one and only one head.
Each parliament member can be zero to several heads of government.
A can be the government name, for example: Ministry of Finance.
B can be the government building age.
C can be the government address.
D can be the government phone number.
F can be the date that the parliament member start to serve as a head of government.
G can be the name of parliament member.
H can be the date of starting serving.
J can be the office address of parliament member.
K can be the age of parliament member.
*/

