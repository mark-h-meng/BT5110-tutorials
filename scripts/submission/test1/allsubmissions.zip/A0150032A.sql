/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0150032A>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT continent_name, continent_code
FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name app, c.name country
FROM country c
JOIN available a
ON c.code3 = a.country;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT temp.name
FROM
(
SELECT c.name AS name, COUNT(continent_name)
FROM country c
GROUP BY c.name
HAVING COUNT(continent_name) > 1
) temp;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_code <> c2.continent_code;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name, s.os
FROM app a
JOIN available av
ON a.name = av.name
JOIN country c
ON av.country = c.code3
JOIN store s
ON a.name = s.name
WHERE c.continent_name = 'Oceania'
ORDER BY a.name;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE VIEW temp2 AS
SELECT c.name AS name, COUNT(ap.name) AS num
FROM country c
JOIN available av
ON c.code3 = av.country
JOIN app ap
ON ap.name = av.name
GROUP BY c.name
ORDER BY COUNT(ap.name) DESC;

SELECT temp3.name AS name, temp3.num AS count
FROM (
SELECT b.name, b.num,
(SELECT count(*)+1 FROM temp2 a
WHERE a.num > b.num) as rank
FROM temp2 b
ORDER BY num DESC
) temp3 WHERE rank <= 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E1 (
A TEXT NOT NULL,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
PRIMARY KEY (A));

CREATE TABLE E2 (
J TEXT NOT NULL,
K TEXT NOT NULL,
G TEXT NOT NULL,
H TEXT NOT NULL,
PRIMARY KEY (G));

CREATE TABLE S (
F TEXT NOT NULL,
A TEXT PRIMARY KEY,
G TEXT NOT NULL,
FOREIGN KEY (A) REFERENCES E1(A),
FOREIGN KEY (G) REFERENCES E2(G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1: Soldier
	A can be their Soldier_ID
	C and D can be their Rank and Full Name
	B can be their army_unit
E2: Vaccination Center
	G can be the government_identifier for the center
	J, K, H can be location, holding_capacity, operating hours
S: Student gets Vaccination. 
	F can be date of vaccine administration.
	
A soldier must get vaccinate at one and only one vaccination Center. 
It cannot be 0 due to the mandate.
However, there may be vaccination centers who may not get any soldiers 
(e.g. serving other public servants, public instead).

*/