/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231996R                */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
 select distinct continent_name, continent_code
 from country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select (af.name) as app , (c.name) as country
from appfunctionality af cross join store s1 cross join store s2 cross join available av 
left outer join country c on av.country = c.code3
where av.name=af.name
and af.name = s1.name
and af.name = s2.name
and av.name = s1.name
and av.name = s2.name
and af.functionality = 'contact tracing'
and s1.os = 'iOS'
and s2.os = 'Android'
and av.country in
(select code3 from country c
where c.continent_name = 'Europe');

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c
group by c.name
having count(c.continent_name) <>1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c1.name
from country c1, country c2
where c1.name = c2.name
and c1.continent_name <>c2.continent_name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select s1.name
from store s1 cross join store s2 cross join available av left outer join country c
on av.country = c.name
where s1.name = av.name
and s2.name = av.name
and av.country in (
select code3 from country c
where c.continent_name = 'Oceania')
and s1.os = 'iOS'
and s2.os = 'Android';

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name, count(av.name)
from country c, available av
where av.country = c.code3
group by c.name
order by count(av.name) desc
limit (6);

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E2 (
J TEXT not null,
H TEXT not null,
K TEXT not null,
G TEXT primary key
 );


CREATE TABLE IF NOT EXISTS E1 (
A TEXT unique not null,
B TEXT not null,
C TEXT not null,
D TEXT not null,
F TEXT not null,
G Text not null,
primary key (C,D),
foreign key (G) references E2(G));
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 = Employee
A = Emloyee ID
B = Join date
C = Address
D = Full name

S = Directly Managed by
F = Department

E2 = Manager
G = Manager ID
H = Age
J = Gender
K = Skillsets

In this scenario, each employee must be and must only be managed by one manager in the comapny.
Can identify the employee by a combanation of traits of Address and Full name.
Each employee's Employee ID should be unique within the company.

Entity 2 is the infomation regarding the managers.
Each manager can directly manage 0 or n numbers of employees.
Some attributes of managers are Manager ID, Age, Gender and Skillsets. 
Here, Manager ID should be used as the identifier for each manager wthin the company.

The relationship set S is directly managed by.
The attribute can be department.
However, since E1(Employee) has 1-to-1 relationship, the number of rows of S and E1 should be the same.
Hence, can merge the S and E1 into one table.


*/

