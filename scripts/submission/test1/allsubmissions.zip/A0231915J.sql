/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231915J>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name,continent_code
from country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                     */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name AS app, c.name AS country
from app a join store s1 on a.name=s1.name join store s2 on a.name=s2.name join appfunctionality af on a.name=af.name join available av on a.name=av.name join country c on av.country=c.code3
where af.functionality='contact tracing' and s1.os='iOS' and s2.os='Android' and c.continent_code='EU';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                    */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c
group by c.name
having count(c.continent_code)!=1 and count(c.continent_code)!=0;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                     */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct(c.name)
from country c
where c.continent_code in (select c1.continent_code from country c1,country c2 
						   where c1.continent_code!=c2.continent_code and c.name=c1.name and c1.name=c2.name);
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct(a.name)
from app a join available av on a.name=av.name join country c on av.country=c.code3 
where c.continent_code='OC'
and not exists(select distinct store,os from store AS OS
			   where not exists(select * from store s where s.name=a.name and s.os=OS.os));

/*information regarding double negation:https://blog.csdn.net/qq_43788640/article/details/89816237?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522163291620216780262510139%2522%252C%2522scm%2522%253A%252220140713.130102334.pc%255Fall.%2522%257D&request_id=163291620216780262510139&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~first_rank_ecpm_v1~rank_v31_ecpm-2-89816237.pc_search_result_hbase_insert&utm_term=sql+%E5%8F%8C%E9%87%8D%E5%90%A6%E5%AE%9A%E5%8F%96%E5%85%A8%E9%83%A8&spm=1018.2226.3001.4187*/
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                     */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name, count(a.name)
from app a join available av on a.name=av.name join country c on av.country=c.code3
group by c.name
order by count(a.name) DESC limit 6;

/*information regarding usage of limit function:https://blog.csdn.net/weixin_43307577/article/details/89001580*/
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table E1(
A TEXT, 
B TEXT NOT NULL,
C TEXT,
D TEXT, 
PRIMARY KEY(A,C,D));

create table E2(
G TEXT PRIMARY KEY, 
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL);

create table S(
G TEXT REFERENCES E2(G),
A TEXT,
C TEXT,
D TEXT,
F TEXT NOT NULL,
FOREIGN KEY(A,C,D)
REFERENCES E1(A,C,D),
PRIMARY KEY(A,C,D));
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):   */
/*
E2 is the information of world top_500_company, G is company_code which is also the candidate key,JKH is company_name, company_size,company_revenue respectively which must be recognized;
E1 is the information of employee, ACD is employee_name, employer_jobtitle, employer_workingnumber which are together the candidate key, and B is employer_gender which can't be null;
S is the work_for_top_500 relationship, each employee in S only and must work for one top_500_company while each company can have different
employees and f is the work_duration for each employee which can't be null, employer_name, employer_jobtitle, employer_workingnumber are together as the candidate key.Participation constraint
is those who work for small companies(not top 500) not in the table S.
*/

