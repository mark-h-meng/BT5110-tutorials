/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231956Y                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select continent_name, continent_code
from country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select af.name as app, c.name as country 
from appfunctionality af, available av, country c, store s1, store s2
where af.functionality ='contact tracing'
	and af.name=av.name
	and af.name=s1.name
	and af.name=s2.name
	and av.country=c.code3
	and c.continent_code='EU'
	and s1.os='Android' and s2.os='iOS';


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select name
from country
group by name
having count(*)>1
order by name;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct c1.name
from country c1, country c2
where c1.name=c2.name
and c1.continent_code<>c2.continent_code
order by name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select av.name,c.continent_code,s.os
from available av, country c, store s
where av.country=c.code3
and c.continent_code='OC'
and av.name=s.name
and not exists(

	select *
	from store s2
	where av.name=s2.name
	and not exists(
		select *
		from store s2
		where av.name=s2.name
		and s.os=s2.os
	)
)

order by name, os;



/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


select c.name,count(*)
from available av, country c
where av.country=c.code3
group by c.name
order by count desc
limit 16;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E2(
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL,
	J TEXT NOT NULL,
	K TEXT NOT NULL
);

CREATE TABLE E1(
	A TEXT UNIQUE NOT NULL,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	F TEXT NOT NULL,
	Z TEXT NOT NULL 
		REFERENCES E2(G),
	PRIMARY KEY (C,D)
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

Table E2 can be the project POC or lead table in an imaginary company with attributes:
- first name
- last name
- line of business
- email (would correspond to G and should be unique)

Table E1 can be the business analysts table with attributes

- first name (part of the primary composite key and can be C/D in the diagram)
- last name (part of primary composite key and can be C/D in the diagram)
- email (would correspond to A and should be unique)
- line of business
- manager (would correspond to F)

In table E1, it is assumed that the composite of first name, last name is unique. Likewise as per the table creation integrity
checks provided the attribute manager in table E1 cannot be left blank since a (1,1) participation constraint has been imposed.


*/

