/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0041688X                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name,continent_code
FROM country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name AS app, c.name AS country
FROM app a, country c, store s, store s1, available av, appfunctionality af
WHERE a.name = s.name
AND a.name = s1.name
AND a.name = av.name
AND av.country = c.code3
AND a.name = af.name
AND af.functionality='contact tracing'
AND s.os = 'iOS'
AND s1.os = 'Android'
AND c.continent_name = 'Europe'
GROUP BY a.name,c.name;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.name
FROM country c, country c1
WHERE c.name = c1.name
GROUP BY c.continent_name, c.name
HAVING count(c1.name)>1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name FROM country c
EXCEPT
SELECT DISTINCT c2.name from country c2;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT a.name FROM country c, app a
INNER JOIN store s1 on a.name = s1.name
AND s1.os IN (SELECT DISTINCT s2.os FROM store s2)
WHERE c.continent_name='Oceania';
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(a.name)
FROM country c, app a, available av
WHERE av.country = c.code3
AND av.name = a.name
GROUP BY c.name
ORDER BY count(a.name) DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1(
	A TEXT,
	B TEXT NOT NULL,
	C TEXT,
	D TEXT,
	PRIMARY KEY(A,C,D));

CREATE TABLE IF NOT EXISTS E2(
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL,
	J TEXT NOT NULL,
	K TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS S(
	A TEXT,
	C TEXT,
	D TEXT,
	G TEXT,
	F TEXT NOT NULL,
	PRIMARY KEY (A,C,D,G),
	FOREIGN KEY (G) REFERENCES E2(G),
	FOREIGN KEY (A,C,D) REFERENCES E1(A,C,D)
);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Supposed E1 refers to local parcels to be delivered. 
A,C,D which form the primary key could be sender address, receiver name and 
receiver address respectively. B could be the name of the sender.
S could refer to the relationship 'shipped by' where F could be shipping number.
E2 could refer to the logistic companies which receive and deliver the parcels.
G which is the primary key, can be the company's registration number as it uniquely
identify the company. 
H,J,K could be company name, company address and telephone number respectively.
A parcel can only be delivered by 1 logistic company while logistic companies can
receive/deliver none or many parcels.
*/

