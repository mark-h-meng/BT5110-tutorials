/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0232012E>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name, continent_code 
FROM country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT af.name AS app, c.name AS country 
FROM appfunctionality af, country c, store s, available a 
WHERE af.name = a.name 
AND a.country = c.code3 
AND s.name = af.name 
AND s.os = 'Android' 
AND c.continent_name = 'Europe' 
AND af.functionality = 'contact tracing' 
INTERSECT 
SELECT af.name AS app, c.name AS country 
FROM appfunctionality af, country c, store s, available a 
WHERE af.name = a.name 
AND a.country = c.code3 
AND s.name = af.name 
AND s.os = 'iOS' 
AND c.continent_name = 'Europe' 
AND af.functionality = 'contact tracing'; 

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name 
FROM country c 
GROUP BY c.name 
HAVING COUNT(*) >1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.name
FROM country c
EXCEPT 
SELECT c.name 
FROM country c 
GROUP BY c.name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name 
FROM available a, country c 
WHERE a.country = c.code3 
AND c.continent_name = 'Oceania' 
AND a.name IN( 
SELECT tmp.name 
FROM (SELECT DISTINCT s.name, s.os FROM store s) tmp 
GROUP BY tmp.name 
HAVING COUNT(*) >= ALL( 
SELECT count(DISTINCT s2.os) 
FROM store s2)); 

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(*) AS count 
FROM country c, available a 
WHERE c.code3 = a.country 
GROUP BY c.name 
ORDER BY count DESC 
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E2 (
J TEXT NOT NULL,
K TEXT NOT NULL,
G TEXT PRIMARY KEY,
H TEXT NOT NULL);

CREATE TABLE E1_S(
F TEXT NOT NULL,
A TEXT NOT NULL,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
G TEXT NOT NULL REFERENCES E2(G),
PRIMARY KEY(A, C, D));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
As we know, each computer has one and only one kind of operation system, however a kind of operation system can be installed in different kinds of computers. Using the symbols in the figure, that's to say, E1 represents computers, and E2 represents the operation systems. To decide which kind the computer is, use its brand, its type_code and its production batch as identifiers. To identify what the os is, use its name as the identifier.
E1: computers
E2: operation systems
S: the operation system used in the computer
A: brand (the brand of this computer) - one of the primary keys
B: color (the color of this computer)
C: type (the type code of this computer) - one of the primary keys
D: production_batch (production batch of this computer) - one of the primary keys
F: person (the person who install the os in the computer)
G: name (the name of the os) - one of the primary keys
H: designer (the designer of the os)
J: price (the price of the os)
K: date (the date that the os first published)
*/

