/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231885X                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.continent_name, c.continent_code
FROM country c
GROUP BY c.continent_name, c.continent_code;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name AS app, c.name AS country, s.os
FROM app a, country c, store s
WHERE s.os IN (SELECT s.os FROM store s 
			   WHERE (s.os = 'iOS' OR s.os='Android')
			   AND s.name=a.name)
AND c.continent_name = 'Europe'
AND s.name=a.name
GROUP BY a.name, c.name, s.os;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.name, c.continent_name 
FROM country c
GROUP BY c.name, c.continent_name
HAVING COUNT(*)>1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, c.continent_name 
FROM country c
GROUP BY c.name, c.continent_name
WHERE  c.continent_name > ANY (SELECT DISTINCT c.name, c.continent_name 
FROM country c
GROUP BY c.name, c.continent_name);
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E2 (
	J TEXT NOT NULL,
	K TEXT NOT NULL,
	H TEXT NOT NULL,
	G TEXT NOT NULL PRIMARY KEY);
	
CREATE TABLE IF NOT EXISTS E1 (
	A TEXT NOT NULL,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	PRIMARY KEY (A, C, D));
	
CREATE TABLE IF NOT EXISTS S (
	F TEXT NOT NULL,
	A TEXT NOT NULL,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	G TEXT NOT NULL,
	PRIMARY KEY (A, C, D, G),
	FOREIGN KEY (G) REFERENCES E2(G));


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
/*For example, we take E1 as students, S as accept_by, and E2 as Universities.
/*A can be the passport ID which is a candidate key, B can be the age of student,
/*C can be the full name of student which can be a candidate key, and D is the email address of the student
/*which can be a candidate key. F can be student ID. G can be the name of Univerisity which is a candidate key,
/*J can be the country of the university, K can be the number of faculties in university, and H can be the address
/*of Universities. University can accept many students but a student can only be enrolled in one university.
/*All candidate keys should not be null.
*/

