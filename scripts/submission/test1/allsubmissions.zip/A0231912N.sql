/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231912N>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name, continent_code
FROM country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT af.name as app, c.name as country
FROM appfunctionality af, country c
WHERE af.functionality LIKE  '%contact tracing%'
AND continent_name LIKE '%Europe%';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT name 
FROM country
GROUP BY name
HAVING COUNT(continent_name) > 1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT distinct c1.name
FROM country c1, country c2
where c1.name = c2.name
and c1.continent_name<> c2.continent_name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT af.name
FROM appfunctionality af, 
	SELECT a.name
			FROM available a, country c
			WHERE c.name = a.country
			AND c.continent_name LIKE '%Oceaniea%'
	);
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT country, COUNT (DISTINCT name)
FROM available
GROUP BY country
ORDER BY COUNT (DISTINCT name) DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1(
A VARCHAR PRIMARY KEY,
B VARCHAR NOT NULL,
C VARCHAR NOT NULL,
D VARCHAR NOT NULL
);

CREATE TABLE IF NOT EXISTS E2(
J VARCHAR NOT NULL,
K VARCHAR NOT NULL,
G VARCHAR PRIMARY KEY,
H VARCHAR NOT NULL
);

CREATE TABLE IF NOT EXISTS S(
F VARCHAR NOT NULL
);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/* For instance, entity 1 E1 could be diners, entity 2 E2 can be
restaurants, and relationship S can be the orders that diners placed
at the restaurants. A can be diner's email address which is a primary key,
or the diner can be identified using a combination of C and D (name and telephone
number, for instance). 


*/

