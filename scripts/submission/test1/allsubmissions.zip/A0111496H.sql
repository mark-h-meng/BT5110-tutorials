/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0111496H                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT d.name AS app, c.name AS country
FROM available d, country c, store s
WHERE d.country = c.code3
AND s.name = d.name
AND c.continent_code = 'EU'
AND s.os = 'iOS'
INTERSECT
SELECT d.name AS app, c.name AS country
FROM available d, country c, store s
WHERE d.country = c.code3
AND s.name = d.name
AND c.continent_code = 'EU'
AND s.os = 'Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(c.continent_code) > 1
ORDER BY c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_code != c2.continent_code
ORDER BY c1.name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a3.name
FROM available a3, country c
WHERE a3.country = c.code3
AND c.continent_name = 'Oceania'
EXCEPT(
	SELECT temp1.name
	FROM (SELECT DISTINCT a.name, s.os FROM available a, store s) AS temp1
			LEFT OUTER JOIN (SELECT DISTINCT a.name, s.os FROM available a, store s WHERE s.name = a.name) AS temp2 ON temp1.name = temp2.name and temp1.os = temp2.os
	WHERE temp2.name IS NULL);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(DISTINCT a.name)
FROM available a, country c
WHERE c.code3 = a.country
GROUP BY c.name
ORDER BY COUNT(DISTINCT a.name) DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E2 (
	J TEXT NOT NULL,
	K TEXT NOT NULL,
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS E1 (
	A TEXT PRIMARY KEY,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	G TEXT NOT NULL REFERENCES E2(G),
	F TEXT NOT NULL);
	
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E2 is the entity set of managers, E1 is the entity set of employee, and S relationship set of which employee is managed by which manager. 
Having the primary key of table E2 as a foreign key in table E1 would ensure that the (1,1) participation constraints for E1 is enforced
For table E1, since there are 1 possible candidate keys, we select the shortest one (i.e. A instead of combination of C and D).
For table E2, since there are only 1 possible candidate key, we chose that to be the primary key

A could be the employee's employee ID
B could be the department of the employee
C could be the first name of the employee
D could be the last name of the employee
F could be the nature of the management (i.e. manager, supervisor, etc)
J could be the department of the manager
K could be the title of the manager
G could be the manager's employee ID
H could be the manager's office location
*/

