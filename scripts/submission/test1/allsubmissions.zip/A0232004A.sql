/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232004A                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select continent_name, continent_code from country
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select av.name as app, co.name as country
from available av, country co, store st
where av.country = co.code3
and co.continent_name = 'Europe'
and av.name = st.name
and os = 'iOS'
intersect
select av.name as app, co.name as country
from available av, country co, store st
where av.country = co.code3
and co.continent_name = 'Europe'
and av.name = st.name
and os = 'Android'
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c
group by c.name
having count(*) >= 2
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c1.name
from country c1
where c1.continent_name <> ANY	(select c2.continent_name
								from country c2
								where c2.name = c1.name)
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select avf.name
from country co, 	(select av.name, av.country
					from available av
					where not exists 	(select *
				 						from store st1
				 						where av.name = st1.name
				 						and not exists	(select *
							   							from store st2
							   							where st1.os = st2.os))) as avf
where co.code3 = avf.country
and co.continent_name = 'Oceania'
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select co.name, count(*)
from app ap, available av, country co
where av.country = co.code3
and ap.name = av.name
group by co.continent_name, co.name
order by count desc
limit 6
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1(
A VARCHAR(64),
B VARCHAR(64),
C VARCHAR(64),
D VARCHAR(64),
F VARCHAR(64) REFERENCES E2(G)
PRIMARY KEY (C, D));

CREATE TABLE E2(
G VARCHAR(64) PRIMARY KEY,
H VARCHAR(64),
J VARCHAR(64),
K VARCHAR(64))
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 could be identified by its feature C and D together or by feature A. It also have some other features such as B. It is and could only be connected to the relation with E2 by feature F. E2 could be connected to multiple E1 or not connected to any of them.
Candidate key for E1 is A or (C + D); Candidate key for E2 is G.
*/

