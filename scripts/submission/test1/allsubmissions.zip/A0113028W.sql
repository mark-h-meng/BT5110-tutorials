/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0113028W                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name, continent_code
FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT av.name as app, c.name as country
FROM available av, country c, store s
WHERE av.country = c.code3
AND av.name = s.name
AND c.continent_name = 'Europe'
AND s.os = 'iOS'
INTERSECT
SELECT av.name as app, c.name as country
FROM available av, country c, store s
WHERE av.country = c.code3
AND av.name = s.name
AND c.continent_name = 'Europe'
AND s.os = 'Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(c.continent_name) > 1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_name <> c2.continent_name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT av.name
FROM available av, store s, country c
WHERE av.name = s.name
AND av.country = c.code3
AND c.continent_name = 'Oceania'
AND s.os = 'iOS'
INTERSECT
SELECT av.name
FROM available av, store s, country c
WHERE av.name = s.name
AND av.country = c.code3
AND c.continent_name = 'Oceania'
AND s.os = 'Android';
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(av.name)
FROM country c, available av
WHERE av.country = c.code3
GROUP BY c.name
ORDER BY COUNT DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E2 (
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL,
	J TEXT NOT NULL,
	K TEXT NOT NULL);
	
CREATE TABLE IF NOT EXISTS E1 (
	A TEXT NOT NULL,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	F TEXT NOT NULL,
	PRIMARY KEY (C,D),
	FOREIGN KEY (A) REFERENCES E2(G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Real world example: A university offering various study programs to students.
A study program can have no student signing up, or many students signed up.
A student can only enroll in 1 study program.
E2: program
E1: student
S: enroll
A: program name
B: first name
C: student matric number
D: last name
F: student code in the faculty
G: program name
H: department name
J: faculty name
K: head of program
*/