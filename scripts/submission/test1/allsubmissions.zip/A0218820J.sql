/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0218820J Yu Zhe>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT continent_name,continent_code 
FROM country; 
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT ava.name AS app,c.name AS country
FROM available ava,store s, country c
WHERE c.code3=ava.country
AND ava.name=s.name
AND c.continent_name='Europe'
AND s.os='iOS'
INTERSECT
SELECT ava.name AS app,c.name AS country
FROM available ava,store s, country c
WHERE c.code3=ava.country
AND ava.name=s.name
AND c.continent_name='Europe'
AND s.os='Android';



/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT name
FROM country
GROUP BY name
HAVING COUNT(continent_name)>1	
ORDER BY name;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name=c2.name
AND c1.continent_name<>	c2.continent_name
ORDER BY c1.name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT ava.name 
FROM available ava,store s, country c
WHERE c.code3=ava.country
AND ava.name=s.name
AND c.continent_name='Oceania'
AND s.os in (SELECT DISTINCT s.os
FROM store s);


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(ava.name)
FROM country c, available ava
WHERE c.code3 =ava.country
GROUP BY c.name
ORDER BY COUNT(ava.name) DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


CREATE TABLE IF NOT EXISTS E2(
G VARCHAR(30) PRIMARY KEY,
J VARCHAR(30) NOT NULL,
K VARCHAR(30) NOT NULL,
H VARCHAR(30) NOT NULL);

CREATE TABLE IF NOT EXISTS E1_S(
A VARCHAR(30) NOT NULL UNIQUE,
C VARCHAR(30) NOT NULL,
D VARCHAR(30) NOT NULL,
B VARCHAR(30) NOT NULL,
PRIMARY KEY (C,D),
F VARCHAR(30) NOT NULL,
G VARCHAR(30) REFERENCES E2(G));
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*


*/

