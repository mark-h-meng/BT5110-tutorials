/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231979N                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT continent_name, continent_code FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT  DISTINCT appli.name, c.name FROM appfunctionality appfunc JOIN app appli ON appfunc.name = appli.name JOIN available av ON av.name = appli.name  JOIN country  c ON av.country = c.code3 JOIN store str on str.name = appli.name																	 
WHERE continent_code = 'EU' AND functionality = 'contact tracing' AND os = 'iOS'
INTERSECT
SELECT  DISTINCT appli.name, c.name FROM appfunctionality appfunc JOIN app appli ON appfunc.name = appli.name JOIN available av ON av.name = appli.name  JOIN country  c ON av.country = c.code3 JOIN store str on str.name = appli.name																		 
WHERE continent_code = 'EU' AND functionality = 'contact tracing' AND os = 'Android'

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name FROM country c
GROUP BY c.name
HAVING COUNT(*)>1
ORDER BY c.name;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.name FROM country c
WHERE EXISTS (SELECT * FROM country c2 WHERE c2.continent_code != c.continent_code AND c2.name = c.name)
ORDER BY c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT  DISTINCT appli.name FROM appfunctionality appfunc JOIN app appli ON appfunc.name = appli.name JOIN available av ON av.name = appli.name  JOIN country  c ON av.country = c.code3 JOIN store str on str.name = appli.name																	 
WHERE c.continent_name = 'Oceania'  AND os = 'iOS'
INTERSECT
SELECT  DISTINCT appli.name FROM appfunctionality appfunc JOIN app appli ON appfunc.name = appli.name JOIN available av ON av.name = appli.name  JOIN country  c ON av.country = c.code3 JOIN store str on str.name = appli.name																		 
WHERE c.continent_name = 'Oceania'   AND os = 'Android'
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name, COUNT(DISTINCT av.name)  as cc FROM country c JOIN available av ON av.country = c.code3
GROUP BY c.name
ORDER BY cc DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E1 (
A TEXT NOT NULL ,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
F TEXT NOT NULL,
G TEXT REFERENCES E2(G)
PRIMARY KEY (A,D,C));

CREATE TABLE E2 (
J TEXT NOT NULL,
G TEXT PRIMARY KEY,
K TEXT NOT NULL,
H TEXT NOT NULL);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

One example could be private teachers and students
One student can have only one teacher, but teachers can have multiple students.
E1 would represent the students. A= name, C = last name, D = student id, B= age. (A,C,D) could be a candidate key (we can assume name, last name and id totally identifies a student). F= hours per week
E2 would represent the teachers. G = teacher_id, J = age, K = hourly_remuneration, H = sex


*/

