/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231930N>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT continent_name, continent_code
FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT av.name app, c.name country
FROM available av, country c, store st, appfunctionality af
WHERE c.code3 = av.country
AND st.name = av.name
AND af.name = av.name
AND af.name = st.name
AND c.continent_name = 'Europe'
AND af.functionality = 'contact tracing'
AND st.os = 'iOS' AND st.name  IN ( 
SELECT st.name 
FROM store st
WHERE st.os = 'Android');




/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT(name) FROM country
WHERE code3 IN (SELECT code3 
				AS cc FROM 
				country 
				GROUP BY code3 
				HAVING COUNT(*) > 1
			    )
ORDER BY name ASC;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT(name) FROM country
WHERE code2 IN (SELECT code2
				AS cc FROM 
				country 
				GROUP BY code2
				HAVING COUNT(*) > 1
			    )
ORDER BY name ASC;

/* wE CAN USE CTE OR RANK\????
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT av.name
FROM available av , country c, store st
WHERE c.code3 = av.country
AND st.name = av.name
AND c.continent_name = 'Oceania'
AND st.os = 'iOS' AND st.name  IN ( 
SELECT st.name 
FROM store st
WHERE st.os = 'Android')
ORDER BY st.name DESC;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name , COUNT(*)
FROM country c, available av
WHERE av.country = c.code3
GROUP BY c.name
ORDER BY COUNT(*) DESC
LIMIT 6 ;


/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE "E1" (
A VARCHAR(1) NOT NULL PRIMARY KEY, 
B VARCHAR(1) NOT NULL ,
C VARCHAR(1) NOT NULL,
D VARCHAR(1) NOT NULL
)

SELECT * FROM e1

CREATE TABLE "S" (
F VARCHAR(1) NOT NULL,
FOREIGN KEY("A")
REFERENCES E1 ("A"),
FOREIGN KEY ("C","D")
REFERENCES E1 ("C","D"),
FOREIGN KEY ("C","D")
REFERENCES E2 ("G")
)

CREATE TABLE "E2" (
"J" VARCHAR(1) NOT NULL ,
"K" VARCHAR(1)NOT NULL ,
"H" VARCHAR(1) NOT NULL,
"G" VARCHAR(1) NOT NULL PRIMARY KEY)

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
A an example fitting the ER diagram above would be an employee and manager, 
where the employee is being managed by the manager
Here we have the case where and employee can have only one manager, 
but the manager can manage many employees
A rough translation of the letters would be:
Employee (E1)
	The Primary Key A - Business Entity ID
	B - Department
	C - Department ID (Candidate Key)
	D - Sales Territory Region Code (Candidate Key)

The combination of Department ID and Sales Territory Region Code would make sense in this case since 
would uniquely identify the rows on the employee, and would always be non-null hence paramount for row identification
Removing any of them would lead to a high risk of duplicate values in the future *f.ex Candidates in the department would have 
the same id. 
	
Is_Managed (S)
	F - Starting Date
Manager (E2)
	The Primary Key G - email
	H - Full Name
	K - Specialization
	L - Years of Managing in Department
	
Referenced File: https://dataedo.com/download/AdventureWorks.pdf
Lecture Video On Entity
*/

