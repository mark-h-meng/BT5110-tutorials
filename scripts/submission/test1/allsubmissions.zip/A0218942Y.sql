/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218942Y                   */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name, continent_code
FROM country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
(SELECT available.name AS app, country.name AS country
FROM available
JOIN country ON country.code3 =available.country
WHERE country.continent_name = 'Europe' AND available.name IN (
	(SELECT store.name 
	FROM store WHERE store.os ='iOS')
	))

INTERSECT

(SELECT available.name AS app, country.name AS country
FROM available
JOIN country ON country.code3 =available.country
WHERE country.continent_name = 'Europe' AND available.name IN (
	(SELECT store.name 
	FROM store WHERE store.os ='Android')
	))
;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT name
FROM country
GROUP BY name
HAVING COUNT(continent_name)>1
ORDER BY name;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c1.name
FROM country c1
JOIN country c2 ON c2.continent_name = c1.name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT available.name
FROM available
JOIN country ON country.code3 = available.country
WHERE country.continent_name = 'Oceania';

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT country.name, count(*)
FROM available
JOIN country ON country.code3 = available.country
GROUP BY country.name
ORDER BY count DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1 (
A VARCHAR(20) NOT NULL,
B VARCHAR(20) NOT NULL,
C VARCHAR(20) NOT NULL,
D VARCHAR(20) NOT NULL,
F VARCHAR(20) NOT NULL,
PRIMARY KEY (A, C , D)
);

CREATE TABLE E1 (
J VARCHAR(20) NOT NULL,
G VARCHAR(20) NOT NULL,
K VARCHAR(20) NOT NULL,
H VARCHAR(20) NOT NULL,
PRIMARY KEY (H)
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Entity 1  represents the fan club
S represents the idol of the club
Entity 2 represents the member of the club
A represents the club registration number, B is the club website, C is the club name, D is the country
G represents the member ID, J represents the age, K presents the contact number, H represent email
In each fan club, there can only be one idol and one idol will have one official fan club. However,  each member can join many or zero fan club.

*/
