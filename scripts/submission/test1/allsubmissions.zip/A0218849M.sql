/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218849M               */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT av.name AS app, c.name AS country, s.store
FROM available av, country c, store s
WHERE av.country = c.code3
AND av.name = s.name
AND c.continent_code = 'EU'
ORDER BY av.name ASC;

SELECT s.name, count(*)
FROM store s
GROUP BY s.name
HAVING COUNT(*) >1
ORDER BY s.name ASC;


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(*) >1
ORDER BY c.name ASC;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT c.name
FROM c.country, d.country
WHERE (SELECT DISTINCT d.name
FROM country d) AS d.country



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT av.name
FROM available av, country c
WHERE av.country = c.code3
AND c.continent_code = 'OC'
ORDER BY av.name ASC

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT av.country, count(*)
FROM available av
GROUP BY av.country
HAVING COUNT(*) >=1
ORDER BY count DESC
LIMIT 5;



/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS E1(
A VARCHAR(8),
B VARCHAR(8) NOT NULL,
C VARCHAR(8),
D VARCHAR(8),
PRIMARY KEY (A, C, D)
);

CREATE TABLE IF NOT EXISTS E2(
G VARCHAR(8) PRIMARY KEY,
H VARCHAR(8) NOT NULL,
J VARCHAR(8) NOT NULL,
K VARCHAR(8) NOT NULL
);

CREATE TABLE IF NOT EXISTS S(
F VARCHAR(8) NOT NULL,
A VARCHAR(8),
B VARCHAR(8) NOT NULL,
C VARCHAR(8),
D VARCHAR(8),
G VARCHAR(8),
PRIMARY KEY (A, C, D, G),
FOREIGN KEY (A, C, D) REFERENCES E1 (A, C, D),
FOREIGN KEY (G) REFERENCES E2 (G)
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

E1 is a person's particulars
A = name
B = residential address
C = father's name
D = mother's name

E2 is the public hospitals
G = hospital name
H = hospital address
J = building name
K = block name

S is the relationship set where a person can be born.

The composite key of C and D is not sufficient as siblings have the same parents' names
Thus, the combination of A, C and D is unique enough to be a primary key.
There is a partication constraint of (1,1) between E1 and E2 because everyone is only born once
However, the partication constrain of (0,n) between E2 and E1 is because not all hospitals deliver the people in E1.


*/
