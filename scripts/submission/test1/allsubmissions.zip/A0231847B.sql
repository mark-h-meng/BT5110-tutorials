/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231847B      */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name, continent_code
FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT ava.name AS app, c.name AS country
FROM available ava, appfunctionality apf, store s, country c
WHERE ava.name = apf.name
AND ava.name = s.name
AND ava.country = c.code3
AND apf.functionality = 'contact tracing'
AND c.continent_name = 'Europe'
AND apf.name = s.name
AND s.os = 'iOS'
INTERSECT 
SELECT ava.name AS app, c.name AS country
FROM available ava, appfunctionality apf, store s, country c
WHERE ava.name = apf.name
AND ava.name = s.name
AND ava.country = c.code3
AND apf.functionality = 'contact tracing'
AND c.continent_name = 'Europe'
AND apf.name = s.name
AND s.os = 'Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT name
FROM country
GROUP BY name 
HAVING count (*) > 1
ORDER BY name ASC;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_name <> c2.continent_name
ORDER BY c1.name ASC;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT ava.name
FROM available ava, country c, store s
WHERE ava.name = s.name 
AND ava.country = c.code3
AND c.continent_name = 'Oceania'
AND s.os IN (
SELECT DISTINCT s1.os FROM store s1);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT (*) AS count
FROM available ava INNER JOIN country c ON ava.country = c.code3
GROUP BY c.code3,c.name
ORDER BY count DESC
LIMIT 16;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1 (
A VARCHAR(64) PRIMARY KEY,
B VARCHAR (64) NOT NULL,
C VARCHAR (64) NOT NULL,
D VARCHAR (64) NOT NULL,
UNIQUE (C,D));

CREATE TABLE IF NOT EXISTS E2(
G VARCHAR (64) PRIMARY KEY,
H VARCHAR (64) NOT NULL,
J VARCHAR (64) NOT NULL,
K VARCHAR (64) NOT NULL);

CREATE TABLE IF NOT EXISTS S(
F VARCHAR (64) NOT NULL,
SA VARCHAR (64) PRIMARY KEY,
SG VARCHAR (64) REFERENCES E2 (G),
FOREIGN KEY (SA) REFERENCES E1 (A));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 is the entity set representing ministries in Singapore such as Ministry of education, Finance, etc. 
E2 is the entity set representing the parliment members in Singapore.
S is the relationship repsenting leadership. Each ministry from E1 can only be lead only one parliment member, while for parliment members they can either not working
any ministries or in multiple ministries. 
*/

