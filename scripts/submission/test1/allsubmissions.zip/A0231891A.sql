/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231891A>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name,  continent_code
from country;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct ap.name AS app, c.name AS country
from available av, store s, app ap, country c
where ap.name = av.name
and ap.name = s.name
and c.code3 = av.country
and c.continent_name = 'Europe'
and s.os = 'iOS'
intersect 
select distinct ap.name AS app, c.name AS country
from available av, store s, app ap, country c
where ap.name = av.name
and ap.name = s.name
and c.code3 = av.country
and c.continent_name = 'Europe'
and s.os = 'Android'
order by app;


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c
group by c.name
having count(c.continent_name) > 1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.name
from country c
where c.continent_name <> ANY(select c1.continent_name
							 from country c1
							 where c.name = c1.name);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct av.name 
from available av, store s, app ap, country c
where ap.name = av.name
and ap.name = s.name
and c.code3 = av.country
and c.continent_name = 'Oceania'
and s.os in (select distinct s.os from store s);



/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name, count(*)
from country c, available av
where c.code3 = av.country
group by c.name
order by count(*) desc, c.name desc
limit 6;


/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table E1(
	A TEXT,
	B TEXT NOT NULL,
	C TEXT,
	D TEXT,
	F TEXT NOT NULL,
	PRIMARY KEY (A, C, D));

create table E2(
	J TEXT NOT NULL,
	K TEXT NOT NULL,
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
The entity set E1 and E2 could be the department leader and different departments. 
ACD represents the first name, last name and email address of the department head/leader. 
G represents the unique code for the department. 
One leader can lead several departments. But one department can only have one department leader.
*/

