/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0086956J						                    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name AS app, c.name AS country
FROM app a, available av, country c, store s1, store s2
WHERE a.name=av.name
	AND s1.name=a.name
	AND s2.name=a.name
	AND c.code3=av.country
	AND c.continent_name='Europe'
	AND s1.os='iOS' AND s2.os='Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(*) > 1

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name=c2.name
	AND c1.continent_name <> c2.continent_name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name
FROM app a
WHERE NOT EXISTS(
	SELECT *
	FROM available av, country c
	WHERE c.code3= av.country
		AND c.continent_name='Oceania'
		AND NOT EXISTS(
			SELECT *
			FROM store s
			WHERE s.name=a.name));

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE VIEW tmp AS
SELECT c.name, COUNT(*) AS count
FROM available av, country c
WHERE c.code3=av.country
GROUP BY c.name;

SELECT loser.name, loser.count
FROM tmp loser LEFT OUTER JOIN tmp winner
	ON winner.name<>loser.name
	AND winner.count>loser.count
GROUP BY loser.name, loser.count
HAVING COUNT(*)<6
ORDER by loser.count DESC;


/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1(
	A VARCHAR(64),
	B VARCHAR(64) NOT NULL,
	C VARCHAR(64),
	D VARCHAR(64),
	PRIMARY KEY(A,C,D));

CREATE TABLE E2(
	G VARCHAR(64) PRIMARY KEY,
	H VARCHAR(64) NOT NULL,
	J VARCHAR(64) NOT NULL,
	K VARCHAR(64) NOT NULL);
	
CREATE TABLE S(
	F VARCHAR(64) NOT NULL,
	A VARCHAR(64),
	C VARCHAR(64),
	D VARCHAR(64),
	G VARCHAR(64) REFERENCES E2(G)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(A,C,D) REFERENCES E1(A,C,D)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Example that correspond to the entity-relation diagram
E1 as shopping mall, with attributes A, C, D as the 
mall's name, country and the street it is located respectively. These 3 
attributes uniquely defines a mall. The attribute B is a mall 
feature, such as the owner of the mall. 

E2 as mall's major stakeowner, the attribute G is the corporate 
or individual ID that uniquely defines the major stakeowner of 
the mall, while J,K and H are attributes of the major stakeowner,
such as the major stakeowner's type (corporate or individual),
where is the stakeowner located/headquartered and name of the 
major stakeowner.

S relates the major stakeowner to the shopping mall. The 
attribute F is since when the mall is owned by the major stakeowner.

The pariticpation constraint between E1 and S is justified because 
each mall can only have one major stakeowner, hence the (1,1) 
participation constraint. And the participation constraint
between S and E2 is justified because each corporate/individual
stakeowner could either own no mall, or multiple malls, hence
the (0,n) participation constraints.

The candidate key for E1 is (A,C,D) that uniquely defines the rows
in the table. While that for E2 is G.

*/

