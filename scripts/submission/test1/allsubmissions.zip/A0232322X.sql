/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232322X                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name,  c.continent_code
FROM country c


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT s.name as app, c.name as country
FROM store s, country c, appfunctionality af, app a, available av
WHERE s.os = 'iOS' 
AND c.continent_name = 'Europe'
AND af.functionality = 'contact tracing'
AND s.name = a.name
AND af.name = a.name
AND av.name = a.name
AND c.code3 = av.country
GROUP BY s.name,c.name
INTERSECT
SELECT s.name, c.name
FROM store s, country c, appfunctionality af, app a,available av
WHERE s.os = 'Android' 
AND c.continent_name = 'Europe'
AND af.functionality = 'contact tracing'
AND s.name = a.name
AND af.name = a.name
AND av.name = a.name
AND c.code3 = av.country
GROUP BY s.name,c.name

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name
FROM country c, country c1
WHERE c.name = c1.name
GROUP BY c.name
HAVING COUNT(c.name) >1

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name
FROM country c
WHERE c.name = c.name
GROUP BY c.name
HAVING count(c.name) >1

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT  a.name
FROM country c, app a, available av
WHERE c.continent_name = 'Oceania'
AND av.name = a.name
AND av.country = c.code3


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT  c.name, COUNT(a.name)
FROM country c,  available av,  app a 
WHERE c.code3 = av.country
AND av.name = a.name
GROUP BY c.name
ORDER BY COUNT(a.name)DESC
LIMIT 6;


/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E2(
	G TEXT PRIMARY KEY,
	F TEXT NOT NULL);

CREATE TABLE E1_S(
	A TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL, 
	FOREIGN KEY (A) REFERENCES E2(G)
	PRIMARY KEY(A,C));
	

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Real world example as follows:
E2 - Parliament member
E1 - Government Ministries
S - Heads

A - Ministry ID
B - Ministry Office
C - Ministry State
D - Ministry Country

F - start date

J- member name
K- member state
G - member ID
H - member party

Candidate Keys - 
For E1 - (A,C,D) 
For E2 - G 

Participation constraints  as follows:
Relationship Set S: one to many relationship from E2 to E1
Entity Set E1: (1,1)
Entity Set E2: (0,n)


*/

