/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0232007X>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name,continent_code
from country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct ap1.name as app,c1.name as country
from app ap1
inner join available av1
on ap1.name=av1.name
inner join country c1
on av1.country=c1.code3
inner join store s1
on ap1.name=s1.name
inner join store s2
on ap1.name=s2.name
inner join appfunctionality appf
on ap1.name=appf.name
where c1.continent_name='Europe'
and s1.os='iOS'
and s2.os='Android'
and appf.functionality='contact tracing';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c
group by c.name
having count(c.continent_name)>1
order by c.name asc;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t.name
from (select *,
	 rank() over(partition by c.name
				order by c.continent_name desc) as ranking
	 from country c) t
where t.ranking=2;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct ap.name as name
from app ap
inner join available av
on ap.name=av.name
inner join store s
on s.name=av.name
inner join country c
on c.code3=av.country
where c.continent_name='Oceania'
and ap.name in (select s1.name
			   from store s1
			   group by s1.name
			   having count(s1.os)=(select count(distinct s2.os)
							   from store s2));
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name,count(av.name)
from available av
inner join country c
on av.country=c.code3
group by c.name
order by count(av.name) desc
limit 6;									
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table E1(
A TEXT NOT NULL,
B TEXT NOT NULL,
C TEXT,
D TEXT,
PRIMARY KEY(C,D));

create table E2(
J TEXT NOT NULL,
K TEXT NOT NULL,
H TEXT NOT NULL,
G TEXT PRIMARY KEY);

create table S(
F TEXT NOT NULL，
S_A TEXT NOT NULL,
s_B TEXT NOT NULL,
S_C TEXT,
S_D TEXT,
S_G TEXT,
PRIMARY KEY (S_C,S_D,S_G),
FOREIGN KEY (S_C,S_D)
REFERENCES E1(C,D),
FOREIGN KEY (S_G)
REFERENCES E2(G));
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 is table of students; S is table of their studentID; E2 is table of names of clubs on campus.
Each student has only one studentId, and they can join several clubs.

For E1, A is their email, as primary key; C is first name, D is last name; B is country they come from.
For S, F is students' studentID.
For E2, G is the code(unique) for the club, as primary key; J is the location of club; K is the max number of members
in this club; H is the leader of this club.
*/

