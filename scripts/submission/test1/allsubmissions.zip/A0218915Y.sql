/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0218915Y>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT a.name AS app, c.name AS country
FROM app a, country c,available av, store st1, store st2
WHERE c.continent_name ='Europe'
AND av.country = c.code3
AND st1.os='iOS'
AND st2.os='Android'
AND st1.name = st2.name
AND a.name =st1.name
AND a.name =av.name;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
-- the country must have a name, that is to say, cannot be null
SELECT DISTINCT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(*)>1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
-- But based on the geographical information, we could reduce down the number
-- of pairs to be checked.
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='NA'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='AF')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='NA'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='EU')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='NA'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='AN')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='NA'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='SA')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='NA'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='AS')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='NA'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='OC')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='AF'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='EU')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='AF'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='AN')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='AF'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='SA')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='AF'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='AS')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='AF'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='OC')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='EU'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='AN')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='EU'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='SA')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='EU'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='SA')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='EU'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='AS')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='EU'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='OC')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='AN'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='SA')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='AN'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='AS')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='AN'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='OC')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='SA'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='AS')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='SA'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='OC')
UNION
(SELECT DISTINCT c.name
FROM country c
WHERE c.continent_code ='AS'
INTERSECT
SELECT c.name
FROM country c
WHERE c.continent_code ='OC');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT av.name
FROM available av, country c,store st1,store st2
WHERE c.continent_name ='Oceania'
AND c.code3=av.country
AND st1.os='iOS'
AND st2.os='Android'
AND st1.name =st2.name
AND st1.name=av.name;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name AS name, COUNT(*) AS COUNT
FROM available av, country c
WHERE av.country = c.code3
GROUP BY c.name
ORDER BY COUNT(*) DESC LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
-- Create E2 at first.
CREATE TABLE IF NOT EXISTS E2(
J VARCHAR (32) NOT NULL,
K VARCHAR (32) NOT NULL,
H VARCHAR (32) NOT NULL,
G VARCHAR (32),
PRIMARY KEY (G));
-- Merge the table E1 and S and use the primary key of the E1.
CREATE TABLE IF NOT EXISTS E1_S(
F VARCHAR (32) NOT NULL,
B VARCHAR (32) NOT NULL,
C VARCHAR (32) NOT NULL,
D VARCHAR (32) NOT NULL,
UNIQUE (C,D),
A VARCHAR (32) PRIMARY KEY,
G VARCHAR (32) NOT NULL,
FOREIGN KEY (G) REFERENCES E2(G));
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Hired employees sign contract with the hiring companies.
E1 - Employee
E2 - Company
S - Contract 
A - Employee Number (unique ID used in the company)
B - Employee Home address
C - Employee first_name
D - Employee last_name
F - Contract Signing Channel (Like e-doc,paper)
G - Company Name
H - Company Address
J - Company Type
K - Company Industry

Here, A is regarded as the primary key (also candidate key), 
and the combination of C and D is as the other candidate key; 
E1->S as (1,1), it is the mandatory participation, and it is also a one-to-one
relationship
E2->S as (0,n), it is the optional participation, and it is also a many to many
relationship

*/

