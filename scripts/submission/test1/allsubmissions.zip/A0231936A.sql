/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231936A>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT s.name AS app, av.country AS country
FROM available av, store s
WHERE av.country IN (SELECT c.code3
					 FROM country c
					 WHERE c.continent_name = 'Europe')
AND (s.os = 'iOS' AND s.os = 'Android')
AND s.name = af.name
AND s.name IN (SELECT af.name
			   FROM appfunctionality af
			   WHERE functionality = 'contact tracing');

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(c.name) > 1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
RIGHT JOIN (SELECT DISTINCT c2.name 
			FROM country c2) as cc
ON c.name = cc.name
WHERE c.name IS NOT NULL;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT av.name
FROM available av, store s, country c
WHERE av.name = s.name
AND av.country IN (SELECT c.code3
 				   FROM country c
 				   WHERE c.continent_name = 'Oceania')
AND NOT EXISTS (SELECT S.name
			    FROM store s
			    WHERE av.name = s.name
				AND NOT EXISTS(SELECT av.name
							    FROM available av
							   WHERE av.name = s.name));
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT av.country, COUNT(*)
FROM available av
GROUP BY av.country
ORDER BY COUNT(*) DESC 
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1(
	A TEXT UNIQUE NOT NULL,
	B TEXT NOT NULL,
	C TEXT,
	D TEXT,
	PRIMARY KEY(C,D));
	
CREATE TABLE E2(
	J TEXT NOT NULL,
	K TEXT NOT NULL,
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL
	);
	
CREATE TABLE S(
	F TEXT NOT NULL,
	sC TEXT,
	sD TEXT,
	sG TEXT REFERENCES E2(G),
	PRIMARY KEY(sC, sD),
	FOREIGN KEY(sC, sD) REFERENCES E1(C,D)
	);

CREATE TABLE E1_S(
	F TEXT NUT NULL,
	eA TEXT UNIQUE NOT NULL
	eB TEXT NOT NULL
	eC TEXT,
	eD TEXT,
	PRIMARY KEY(eC,eD)
	FOREIGN KEY(eG) REFERENCES E2(G)
	);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/* Real world example could be game downloading. E1 could be the customers
   in app store, E2 could be games in app store, and S could be the
   downloading records.
   A could be the customer ID which is unique for each
   customer, B could be the age of the customers, C could be the name of 
   the customer, and D could be the email of the customer. Composite of
   name and email is unique for each customer.
   G could be the code of the games given by app store which is unique for
   each game listed; H could be game developer; J could be the name of the
   game, and K could be the age limit for a game.
   F could be download date.
   The participation countraint could be fullfilled as followed: each customer
   can download only one game in order to be a eligible user, while each
   game could exist without being downloaded and can be downloaded by
   multiple users.
*/

