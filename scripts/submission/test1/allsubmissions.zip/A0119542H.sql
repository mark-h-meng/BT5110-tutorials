/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0119542H                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.continent_name, c.continent_code 
FROM country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT ap.name AS app, c.name AS country
FROM app ap
INNER JOIN store s1 ON ap.name = s1.name 
INNER JOIN store s2 ON ap.name = s2.name 
INNER JOIN available av ON ap.name = av.name INNER JOIN country c ON av.country = c.code3
INNER JOIN appfunctionality af ON ap.name = af.name
WHERE af.functionality = 'contact tracing'
AND s1.os = 'Android' AND s2.os = 'iOS'
AND c.continent_name = 'Europe';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name 
FROM country c
GROUP BY c.name
HAVING COUNT(c.continent_code)>1
ORDER BY c.name; 
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name 
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_code <> c2.continent_code
ORDER BY c1.name; 
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT ap.name, c.continent_name, s.os
FROM app ap
INNER JOIN store s ON ap.name = s.name  
INNER JOIN available av ON ap.name = av.name INNER JOIN country c ON av.country = c.code3
WHERE c.continent_name = 'Oceania';
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(*) 
FROM app ap, country c, available av
WHERE ap.name = av.name 
AND av.country = c.code3
GROUP BY c.name
ORDER BY count DESC
LIMIT 6;

SELECT c.name, COUNT(*) 
FROM app ap, country c, available av
WHERE ap.name = av.name 
AND av.country = c.code3
GROUP BY c.name
ORDER BY count DESC
LIMIT 7;

SELECT c.name, COUNT(*) 
FROM app ap, country c, available av
WHERE ap.name = av.name 
AND av.country = c.code3
GROUP BY c.name
ORDER BY count DESC
LIMIT 8;

SELECT c.name, COUNT(*) 
FROM app ap, country c, available av
WHERE ap.name = av.name 
AND av.country = c.code3
GROUP BY c.name
ORDER BY count DESC
LIMIT 16;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1(
	A VARCHAR(20) PRIMARY KEY,
	B VARCHAR(20) NOT NULL,
	C VARCHAR(20) NOT NULL,
	D VARCHAR(20) NOT NULL,
	UNIQUE NOT NULL (C,D)
);

CREATE TABLE IF NOT EXISTS S(
	F VARCHAR(20) NOT NULL
);

CREATE TABLE IF NOT EXISTS E2(
	G VARCHAR(20) PRIMARY KEY,
	H VARCHAR(20) NOT NULL,
	J VARCHAR(20) NOT NULL,
	K VARCHAR(20) NOT NULL
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
-- E1 = government 
-- A = country if we assume one country has only one government, this is a primary key as identificaiton
-- B = amount of financial reserve
-- C = political party 
-- D = political governing year 
-- C and D combined form a unique identification for the government in place. 

-- S = head/ lead, referring to 1 government is led by 1 parliament member 
-- E2 = parliament member 
-- J = gender of parliament member
-- K = race of parliament member
-- G = IC number of parliament member, it is primary key as it identifies a parliament member
-- H = years of experience of parliament member

*/

