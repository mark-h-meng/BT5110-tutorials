/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0150639A                 						    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT continent_name,continent_code
FROM country
GROUP BY continent_name,continent_code;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name app, c.name country
FROM store s1, store s2, available a, country c
WHERE s1.name = a.name
	AND s2.name = a.name
 	AND a.country = c.code3 
	AND c.continent_name = 'Europe'
	AND s1.store = 'GooglePlay'
	AND s2.store = 'AppStore';


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT name
FROM country
GROUP BY name
HAVING COUNT(DISTINCT continent_code) > 1 ;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

-- No Aggreagate





/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name
FROM store s1, store s2, available a, country c
WHERE s1.name = a.name
	AND s2.name = a.name
 	AND a.country = c.code3 
	AND c.continent_name = 'Oceania'
	AND s1.os = 'Android'
	AND s2.os = 'iOS';

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name, COUNT(DISTINCT a.name) AS count
FROM available a, country c
WHERE a.country = c.code3
GROUP BY c.name 
ORDER BY count DESC
LIMIT 6;



/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS E1 (
	A VARCHAR NOT NULL,
	B VARCHAR NOT NULL,
	C VARCHAR NOT NULL,
	D VARCHAR NOT NULL,
	PRIMARY KEY(A,C,D));

CREATE TABLE IF NOT EXISTS E2 (
	G VARCHAR NOT NULL,
	H VARCHAR NOT NULL,
	J VARCHAR NOT NULL,
	K VARCHAR NOT NULL,
	PRIMARY KEY(G));

CREATE TABLE IF NOT EXISTS S (
	F VARCHAR NOT NULL,
	A VARCHAR NOT NULL,
	C VARCHAR NOT NULL,
	D VARCHAR NOT NULL,
	G VARCHAR NOT NULL,
	FOREIGN KEY(A,C,D) REFERENCES E1(A,C,D),
	FOREIGN KEY(G) REFERENCES E2(G));


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */

/*
One classic example can be describled by using students apply and enroll the primary schools.
Here we can use entity E1 to represent the Studetns with the corresponding attributes.
A - Student's Identification No.
B - Student's address
C - Student's First Name
D - Student's Last Name

Meanwhile we can use entity E2 to represent the different schools with the corresponding attributes below.

G - School Full Name
H - School Address
J - School Offical Contact
K - School Admission Requirement,etc

As we know, when each student applied to different schools and they can only be assinged to one school in maxium.
On the contrast, the primary schools can admit multiple students from E1, but also might not admit some of them.

Hence we can build the new relation entity S with the corresponding attributes.
A,C,D,G - which are referenced from other two entities.
F - Application No 

Thus we can build the new relational entity to link the 2 entities mentioned above successfully.


*/




