/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218840E                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name app, c.name
FROM available a, country c, store s, store s2
WHERE a.country = c.code3
AND c.continent_name = 'Europe'
AND s.name = a.name
AND s2.name = a.name
AND s.os = 'iOS'
AND s2.os = 'Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(c.name) > 1
ORDER BY c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.name
FROM country c, country c2
WHERE c.continent_code <> c2.continent_code
AND c.name = c2.name
ORDER BY c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name
FROM available a, country c, store s
WHERE a.name = s.name
AND a.country = c.code3
AND c.continent_name = 'Oceania'
AND s.os >= ALL(SELECT DISTINCT s.os
			  FROM store s);
			  
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name, COUNT(ap.name)
FROM country c, app ap, available av
WHERE ap.name = av.name
AND c.code3 = av.country
GROUP BY c.name
ORDER BY COUNT(ap.name) DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E1(
A TEXT,
B TEXT NOT NULL,
C TEXT,
D TEXT,
PRIMARY KEY(A,C,D));

CREATE TABLE E2(
G TEXT PRIMARY KEY ,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL);

CREATE TABLE S(
F TEXT NOT NULL,
A TEXT,
C TEXT,
D TEXT,
G TEXT,
FOREIGN KEY (G) REFERENCES E2(G),
PRIMARY KEY(A,C,D));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

E1 refers to an Employee,
A refers to their first name,
C refers to their age,
D refers to the function they work under.
In the event there are colleagues with the same first name working in the
same department, their age is likely to differ and set them apart.
B refers to their employment type e.g full time, part-time etc.

S refers to a income tax filing relationship, F refers to the year of filing. 
At a given point an employee can only have 1 income tax filing in a year. 
But if the part-time employee is not working that year then there will 
not be an income tax filing with the company for that year which explains 
the optional is to many relationship with company. The company has several
income tax filed on behalf of all its employees.

E2 refers to the company they work for,
G being the UEN which is the company registration number,
J, K and H can be the company's postal code, founding year, employee count.


*/

