/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0093740E>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select continent_name, continent_code from country

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct av.name as app, av.country
from appfunctionality af, available av, country c, store s
where av.country = c.code3
and af.name = av.name
and af.functionality = 'contact tracing'
and c.continent_name ='Europe'
and s.os = 'iOS'
except
(select distinct a.name, s.os
from app a, store s
where s.os = 'iOS'
and s.os <> 'Android')

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c
group by c.name
having count (distinct c.continent_code)>1

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c
group by c.name
having count (distinct c.continent_code)>1

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select *from
( select c.name, count (distinct av.name ) as count
	from country c, available av
	where av.country = c.code3
	group by
	c.name
    order by count desc
) a
limit 16

--I print out the top 16, please refer to row 1 to 6 as the top 6 countires

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E1 (
A TEXT PRIMARY KEY,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL);

CREATE TABLE E2 (
J TEXT NOT NULL,
K TEXT NOT NULL,
G TEXT PRIMARY KEY,
H TEXT NOT NULL);

CREATE TABLE S (
F TEXT NOT NULL);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 could be a store, A is its primary key A could be its postal code
C could be the store name, D could be owner IC of this store

S is the relationship own, and F can be the year when the owner start to own this tore

E2 could be owner, G is the primary key of owener, G could be the owner's IC
1 onwer can have multiple store, 1 store belong to 1 onwer only

*/

