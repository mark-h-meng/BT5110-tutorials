/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0218855U>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.continent_name, c.continent_code FROM country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT av.name as app, c.name as country

FROM available av LEFT JOIN country c ON av.country = c.code3, store s

WHERE c.continent_name = 'Europe'
AND s.os IN ('iOS','Android')

GROUP BY av.name, c.name

HAVING COUNT(DISTINCT s.os) = 2;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c1.name 

FROM 

(SELECT DISTINCT c.name, count (distinct c.continent_name)
FROM country c
GROUP BY c.name
ORDER BY count DESC) AS c1

WHERE c1.count >1;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT c1.name 

FROM 

(SELECT DISTINCT c.name, count (distinct c.continent_name)
FROM country c
GROUP BY c.name
ORDER BY count DESC) AS c1

WHERE c1.count >1;



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
#We do not limit the selection of the OS type and set no. of OS to be more than 1.
/************************************************************************/

SELECT av.name

FROM available av LEFT JOIN country c ON av.country = c.code3, store s

WHERE c.continent_name = 'Oceania'

GROUP BY av.name

HAVING COUNT(DISTINCT s.os) >= 2;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
#To update no. of fitch to achieve the no. of row selection
/************************************************************************/

SELECT c.name, count (c.name)

FROM country c LEFT JOIN available av ON c.code3 = av.country

GROUP BY c.name

ORDER BY count DESC

FETCH FIRST 6 ROWS ONLY;


/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
#Assume all the arritbute are charterers.
/************************************************************************/

CREATE TABLE IF NOT EXISTS E1 (
A VARCHAR(20) PRIMARY KEY,
B VARCHAR(20)  NOT NULL,
C VARCHAR(50) NOT NULL,
D VARCHAR(50) NOT NULL,
PRIMARY KEY (C,D)
);

CREATE TABLE IF NOT EXISTS E2 (
G VARCHAR(20) PRIMARY KEY,
J VARCHAR(20)  NOT NULL,
K VARCHAR(50) NOT NULL,
H VARCHAR(50) NOT NULL,
);

CREATE TABLE IF NOT EXISTS S (
F NUMERIC(20) NOT NULL,
A VARCHAR(20) NOT NULL,
B VARCHAR(20)  NOT NULL,
C VARCHAR(50) NOT NULL,
D VARCHAR(50) NOT NULL,
G VARCHAR(20) NOT NULL,
J VARCHAR(20)  NOT NULL,
K VARCHAR(50) NOT NULL,
H VARCHAR(50) NOT NULL,
PRIMARY KEY (A,C,D,G),
FOREIGN KEY (A) REFERENCES E1(A),
FOREIGN KEY (C,D) REFERENCES E1(C,D),
FOREIGN KEY (G) REFERENCES E2(G));


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

/************************************************************************/
#Sorry, dont have sufficient time for this question, but simplely, 
E1 can be 'employee', where C is first name and D is last name, A is ID no. and B is age;
S can be 'work for' with F as starting year; 
E2 can be employer information, where G is UEN code (comapny register code) which is primary key, and J,K,H can be other 
attributes of the company such as Address, Industry, HQ Country, etc.
/************************************************************************/

*/

