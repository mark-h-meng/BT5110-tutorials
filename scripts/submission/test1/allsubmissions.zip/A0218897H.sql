/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218897H                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name, continent_code from country;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select av.name as app, c.name as country from available av
left join country c on av.country = c.code3
left join store s on av.name = s.name
where c.continent_code = 'EU'
group by av.name, c.name
having count(distinct s.os) = 2;


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select name from country
group by name
having count(continent_code) > 1
order by name;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct name from country c1
where exists (
	select * from country c2
	where c1.name = c2.name
	and c1.continent_code <> c2.continent_code)
order by c1.name;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct s1.name from store s1
left join available a on s1.name = a.name
left join country c on a.country = c.code3
where c.continent_name = 'Oceania'
and exists (
	select * from store s2
where s1.name = s2.name
and s1.os <> s2.os);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name, count(ap.name) from app ap
left join available av on ap.name = av.name
left join country c on av.country = c.code3
group by c.name
order by count desc
limit 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table E1 (
A VARCHAR(255) NOT NULL,
B VARCHAR(255) NOT NULL,
C VARCHAR(255) NOT NULL,
D VARCHAR(255) NOT NULL,
PRIMARY KEY(A, C, D));

create table E2 (
J VARCHAR(255) NOT NULL,
G VARCHAR(255) NOT NULL PRIMARY KEY,
K VARCHAR(255) NOT NULL,
H VARCHAR(255) NOT NULL);

create table S (
A VARCHAR(255) NOT NULL,
C VARCHAR(255) NOT NULL,
D VARCHAR(255) NOT NULL,
G VARCHAR(255) NOT NULL REFERENCES E2(G),
FOREIGN KEY (A, C, D) REFERENCES E1(A, C, D),
F VARCHAR(255) NOT NULL);


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 could be group of employees' details where E2 could be their dependents. 
Column A - Name
Column C - Email
Column D - Mobile
Column B - Age

Column J - Age
Column G - IC Number
Column K - Location
Column H - Relationship to Employee

Set S could be the insurance policy.
Column F - Max coverage/Insurance Type.
*/

