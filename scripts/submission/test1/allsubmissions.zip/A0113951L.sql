/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0113951L						                    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.continent_name, c.continent_code
from country c
group by c.continent_name, c.continent_code

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select a.name as app, c.name as country
from app a, available aa, country c, store s1, store s2
where a.name = aa.name
and aa.country = c.code3
and c.continent_code = 'EU'
and a.name = s1.name
and a.name = s2.name
and s1.os = 'iOS'
and s2.os = 'Android'

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.name
from country c
group by c.name
having count(c.continent_name)>1

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct c1.name
from country c1, country c2
where c1.name = c2.name
and c1.continent_code <> c2.continent_code

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
I DONT KNOW YET!
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.name, count (distinct aa.name)
from available aa, country c
where aa.country = c.code3
group by c.name
order by count desc
limit 6

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

create table e1(
	A text not null,
	B text not null,
	C text not null,
	D text not null,
	primary key (A,C,D));
	
	
create table e2(
	G text not null primary key,
	H text not null,
	J text not null,
	K text not null);
	
	
create table s(
	A text not null,
	C text not null,
	D text not null,
	foreign key (A,C,D) references e1(A,C,D),
	G text not null,
	foreign key (G) references e2(G),
	F text not null,
	primary key (A,C,D,G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

A potential real world application would be a tracking system for a manufacturing plant (E1)
that delivers products made from its plant to the stores (E2). It produces multiple items
and each product follows its own production batch tracking number, and manufactured on a specific date. 
These 3 form the pimary keys of A, C  and D, forming the unique identifier. B is the price. 

In the entity set E2, each store has its own unique identifier code in the system (primary key G), with 
other details like the Country, State, and City of location. A city could have multiple store locations. 

Relationship set F therefore defines the date the specific batch of product is delivered to the 
store which is asking for stock.

The relationship constraint makes sense as each batch of product produced by the plant can only be delivered 
to one location upon ordering (1,1) constraint, whereas a store can receive many orders for differnet products
or place no orders.

A = Product Name
C = Production Batch Number
D = Date of Manufacturing
B = Cost

F = Delivered on

G = Retail store unique code
H = Country
J = State
K = City

*/

