/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0232015Y>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct(continent_name),continent_code
from country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select app.name app ,c.name
from app, available av,country c,appfunctionality af, store s1,store s2
where app.name=af.name
and app.name=av.name
and app.name=s1.name
and app.name=s2.name
and s1.os='iOS'
and s2.os='Android'
and af.functionality='contact tracing'
and av.country=c.code3
and c.continent_code='EU';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select name
from country
group by name
having count(*) >=2;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct(c1.name)
from country c1, country c2
where c1.name=c2.name
and c1.continent_code<>c2.continent_code;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select app.name
from app
where not exists (
	select *
	from country c, available av
	where c.continent_name='Oceania'
	and av.country=c.code3
	and not exists (
	select *
	from store s
	where s.name=av.name
	and	s.name=app.name));
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name as name, count(*) as count
from country c,available av,app
where c.code3=av.country
and app.name=av.name
group by c.name
order by count desc
limit 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/************************************************************************/

CREATE TABLE E1 (
A VARCHAR(16) NOT NULL unique,
B VARCHAR(64) NOT NULL,
C VARCHAR(64) NOT NULL unique,
D VARCHAR(64) NOT NULL unique,
primary key(A,C,D)
);    

CREATE TABLE E2 (
G VARCHAR(16) NOT NULL primary key,
H VARCHAR(64) NOT NULL,
J VARCHAR(64) NOT NULL,
K VARCHAR(64) NOT NULL
);   

CREATE TABLE S (
F VARCHAR(16) NOT NULL,	
A VARCHAR(16) NOT NULL REFERENCES E1(A),
C VARCHAR(64) NOT NULL REFERENCES E1(C),
D VARCHAR(64) NOT NULL REFERENCES E1(D),
G VARCHAR(16) NOT NULL,
primary key(A,C,D,G),
foreign key (G) REFERENCES E2(G)
	);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Table E1 can be interpreted as information of a house. Table E2 can be information of a person.
The relationship S is a buying contract between a person and a house.
One can buy (0,n) houses but a house can only have one buyer.
Attribute G can indentify an entity(ID number for a person in this example)
Attributes A and the combination of C and D identify entity E1.

*/

