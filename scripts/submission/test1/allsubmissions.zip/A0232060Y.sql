/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0232060Y>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT distinct co.continent_name,co.continent_code FROM 
country co
order by co.continent_name desc;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT distinct st.name, c.name FROM 
country c,store st 
where c.continent_name= 'Europe'
and st.os = 'iOS'
or st.os = 'Android'

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT distinct c.name FROM 
country c
where c.continent_code = 
group by c.name

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT distinct c.name FROM 
country c
where count(continent_code)=!count(c.name)
group by c.name

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT distinct av.name FROM 
available av
inner join country co on av.country = co.code3
where continent_code = 'OC'
and continent_name = 'Oceania'
intersect 
select distinct av.name FROM 
available av, store st
where st.os = 'iOS'
or st.os = 'Android'

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select co.name, count(av.name)
from country co
inner join available av on av.country = co.code3
group by co.name
order by count(av.name) desc limit 6

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE e1 (
A VARCHAR(64) PRIMARY KEY,
B VARCHAR(64) not null,
D VARCHAR(64) not null,
D VARCHAR(64) not null;

CREATE TABLE e2 (
J VARCHAR(64) not null,
K VARCHAR(64) not null,
G VARCHAR(64) PRIMARY KEY,
H VARCHAR(64) not null;

create table S (
F CHAR(8) NOT NULL,
e1C VARCHAR(32) not null,
e1D VARCHAR (32) not null,
e2G CHAR(8) NOT NULL,
e1A CHAR(8) NOT NULL,
Primary key(e1C,e1D,e2G,e1A),
FOREIGN KEY (e1C,e1D ) REFERENCES E1(C,D),
FOREIGN KEY (e1A) REFERENCES E1(A),
FOREIGN KEY (e2G) REFERENCES E2(G));


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*


*/

