/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232013A                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT app.name AS app, c.name AS country
FROM app app, available av, store s, country c, appfunctionality af
WHERE app.name=s.name AND app.name=av.name AND av.country=c.code3 AND app.name=af.name
AND s.os='iOS' AND c.continent_name='Europe' AND af.functionality='contact tracing'
INTERSECT
SELECT app.name AS app, c.name AS country
FROM app app, available av, store s, country c, appfunctionality af
WHERE app.name=s.name AND app.name=av.name AND av.country=c.code3 AND app.name=af.name
AND s.os='Android' AND c.continent_name='Europe' AND af.functionality='contact tracing';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(c.name) >1
ORDER BY c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.name
FROM country c, country c1
WHERE c.name=c1.name AND c.continent_code <> c1.continent_code
ORDER BY c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT app.name
FROM country c, available av, (app app LEFT OUTER JOIN store s ON app.name=s.name)
WHERE app.name=av.name AND av.country=c.code3
AND continent_name='Oceania'
AND s.os IS NOT NULL
ORDER BY app.name;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, count(av.name) AS ct
FROM country c, available av
WHERE av.country=c.code3
GROUP BY c.name
ORDER BY ct DESC
LIMIT (6);

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS E1 (
	A VARCHAR(50) PRIMARY KEY NOT NULL,
	B VARCHAR(50) NOT NULL,
	C VARCHAR(50) NOT NULL,
	D VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS E2 (
	G VARCHAR(50) PRIMARY KEY NOT NULL,
	H VARCHAR(50) NOT NULL,
	J VARCHAR(50) NOT NULL,
	K VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS S (
	A VARCHAR(50) NOT NULL REFERENCES E1 (A) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
	G VARCHAR(50) NOT NULL REFERENCES E2 (G) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
	F VARCHAR(50) NOT NULL,
	PRIMARY KEY (A, G)
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 could be schools, S could be head of departments and E2 could be teachers. 
In this scenario, the columns could be:
A = School ID
B = Type of School (Private or Public)
C = Latitude of School
D = Longitude of School
F = Date which the teacher took up office
G = IC number of teacher
H = Date joined
J = Salary drawn
K = Sex (Male/Female)

*/

