/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231851L                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.continent_name, c.continent_code
from country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select a.name as app, (select c.name from country c where c.code3=av.country) as country
from appfunctionality a right join available av on a.name=av.name 
where exists(
	select s.name
	from store s
	where s.name=a.name and s.os='iOS'
	intersect
	select s.name
	from store s
	where s.name=a.name and s.os='Android')
and a.functionality='contact tracing'
and av.country in(
select c.code3
from country c
where c.continent_name='Europe');

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c
group by c.name
having count(c.continent_code)>1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.name
from country c, country d
where c.name=d.name and c.continent_code<>d.continent_code;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name
from available a left join country c on a.country=c.code3 
					left join store s on s.name=a.name
where c.continent_name='Oceania'
intersect
select distinct s.name
from store s,store st
where st.name=s.name and st.os<>s.os;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.name,count(*)
from available a left join country c on a.country=c.code3
group by c.name
order by count(*) desc
limit 6;

/*reference:https://www.runoob.com/postgresql/postgresql-limit.html*/

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

create table E1(
A TEXT primary key,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
UNIQUE(C,D));

create table E2(
G TEXT PRIMARY KEY,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL);

CREATE TABLE S(
F TEXT NOT NULL,
A TEXT REFERENCES E1(A) PRIMARY KEY,
G TEXT REFERENCES E2(G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 could be a student and A is the identifier, B is gerder,
C is class_id and D is id_inClass.
E2 is the info about the school. G is the location/postcode, J could be the headmaster, K could be type,
and H could be area.
S stands for 'studies at', and F represents the rank.
(1,1)means a student must studies at one and only one school.
(0,n) means a school could have no students, maybe it's at its very beginning of construction.

*/

