/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231994W                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select Distinct c.continent_name, c.continent_code
From country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select ap.name As app, c.name As country
From app ap, store s, available av, country c,
appfunctionality af, functionality f
Where ap.name = s.name
And ap.name = av.name
And av.country = c.code3
And ap.name = af.name
And af.functionality = f.type
And f.type = 'contact tracing'
And c.continent_name = 'Europe'
And s.os = 'iOS'
Group By ap.name,c.name
Intersect
Select ap.name As app, c.name As country
From app ap, store s, available av, country c,
appfunctionality af, functionality f
Where ap.name = s.name
And ap.name = av.name
And av.country = c.code3
And ap.name = af.name
And af.functionality = f.type
And f.type = 'contact tracing'
And c.continent_name = 'Europe'
And s.os = 'Android'
Group By ap.name,c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select c.name
From country c
Group By c.name
Having count(c.continent_name) >=2
Order By c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select c.name
From country c
Group By c.name
Having count(c.continent_name) >=2
Order By c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select ap.name
From app ap Left Outer Join available av On ap.name = av.name
Left Outer Join country c On av.country = c.code3
Left Outer Join store s On s.name = ap.name
Where c.continent_name = 'Oceania'
Group By ap.name, s.os
Having s.os NOTNULL;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select count(distinct ap.name),c.name
From country c, available av, app ap
Where ap.name = av.name
And av.country = c.code3
Group By c.name
Order By count(*) Desc
Limit 6 Offset 0;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Create Table if Not Exists E1(
A Text Not Null
B Text Not Null
C Text Not Null
D Text Not Null
Primary Key (A,C,D));

Create Table if Not Exists E2(
J Text Not Null
K Text Not Null
G Text Primary Key
H Text Not Null
);

Create Table if Not Exists S(
F Text Not Null);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Let E1 be 'university dorm student' and E2 be 'university dorm'. Then S becomes 
'live in'. A student living in a dorm can only be assigned and live in one dorm
per semester
while one dorm can contain many students (or no student), 
satisfying the (1,1) and (0,n) requirements.

For E2, the primary key G should be the 'dormID', and J, K, H should be
'building_name', 'dorm_house_number' and 'aircon'.
For E1, A, C, D, B should be 'studentID', 'Gender', 'Year' and 'health_status'.
A, C and D should together be the primary key.
*/

