/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231880H>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT(continent_name), continent_code
FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT s.name AS app, c.name as country
FROM available av, country c, store s, appfunctionality ap
WHERE av.country = c.code3
AND ap.name = av.name
AND c.continent_code = 'EU'
AND av.name = s.name
AND ap.functionality = 'contact tracing'
GROUP BY s.name, c.name, s.name
HAVING count(s.name)>1
ORDER BY app;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT name
FROM country
GROUP BY name
HAVING count(continent_code)>1
ORDER BY name;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT(c1.name)
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_code <> c2.continent_code
ORDER BY c1.name;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E2 (
	J TEXT NOT NULL,
	K TEXT NOT NULL,
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL);
	
CREATE TABLE E1 (
	A TEXT NOT NULL,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	G TExT NOT NULL,
	F TEXT NOT NULL,
	PRIMARY KEY (A,C,D),
	FOREIGN KEY (G) REFERENCES E2 (G));
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*E2 is primary schools, E1 is student, S is the admission form. 
Primary school can have many students or nil, if it is a very bad school and no one wants to enter.
Kid must attend one primary school but no more than 1.
J,K,G,H is district, gender(boy/girl/co-ed), school name and principle name respectively.
School name is the primary key, assuming no same school name in a city.
A,B,C,D is student's name, gender, class, class number.
F is date of admission of the student.

*/

