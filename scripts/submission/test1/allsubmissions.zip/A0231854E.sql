/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231854E>            						        */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name, continent_code 
from country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name as app, c.name as country
from available a, country c, store
where a.country = c.code3 and c.continent_name = 'Europe' and 
(store.os = 'iOS' and store.os = 'Android');

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct name 
from country 
where code3 in (
	select code3 
	from country 
	group by code3 having count(code3) > 1);
	
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct name 
from country 
where not exists (
	select * 
	from country 
	where code3 = 'MEX');
	
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct name from store where 
(store.os = 'iOS' or store.os = 'Android')
and exists (
select available.name from available left join country on country.code3 = available.country 
where country.continent_name = 'Oceania'
order by available.name);
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT country.name, COUNT(available.name)
FROM available left join country on country.code3 = available.country
GROUP BY country.name
order by COUNT(available.name) desc;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS employees (
first_name VARCHAR(20) NOT NULL,
last_name VARCHAR(20) NOT NULL,
passport NUMERIC PRIMARY KEY,
address VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS ethnicicity (
ethnic_code VARCHAR(20) PRIMARY KEY,
hair_color VARCHAR(20) NOT NULL,
eye_color VARCHAR(20) NOT NULL,
yearsworked NUMERIC NOT NULL
);

CREATE TABLE IF NOT EXISTS identify (
employee NUMERIC(50),
race VARCHAR(20),
review VARCHAR(50) NOT NULL,
PRIMARY KEY (employee, race),
FOREIGN KEY (employee) REFERENCES employees(passport),
FOREIGN KEY (race) REFERENCES ethnicicity(ethnic_code)
);


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 is the list of employees working for the company.
E2 is the ethnicicity table where there're a list of ethnicicities.
S is the relationship where employees identify themselves as what ethnicicity.
A is the passport number of employees, B is their addresses, C and D are first and last names
F is the review of the employee to the company on workplace equality.
G is the ethnicicity code assigned to each ethnicicity.
J is the hair color of the employee.
K is the eye color of the employee.
H is the number of years that the employee worked at this company.
C and D, first and last name, makes a set of candidate key.
The relationship identify is a one-to-many relationship from ethnicicity to employees.
It is mandatory for employees to identify with at least one ethnicicity code.
It is optional for the ethnicicity entity. There can be zero or many under each ethnicicity. 
The participation constraints for the entity set ethnicicity is (0, n). 
The participation constraints for the entity set employees is (1, 1).
*/

