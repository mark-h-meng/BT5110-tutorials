/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0212524U                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT continent_name, continent_code
FROM country
GROUP BY continent_name,continent_code;



/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT av.name AS app, c.name AS country
FROM available av, country c, store s1, store s2
WHERE av.name = s1.name
  AND av.name = s2.name
  AND av.country = c.code3
  AND c.continent_code = 'EU'
  AND s1.os = 'iOS'
  AND s2.os = 'Android';
-- return 41



/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT name
FROM country
GROUP BY name
HAVING count(DISTINCT continent_name) > 1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select name from(
select name, row_number() over (partition by name order by continent_name) as index)
from country)t1
where t1.index = '2';
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, count(*)
FROM available av, country c
WHERE av.country = c.code3
GROUP BY c.name
ORDER BY count(*) DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E1(
	A TEXT NOT NULL,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	PRIMARY KEY (C, D));

CREATE TABLE E2(
	J TEXT NOT NULL,
	K TEXT NOT NULL,
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL);

CREATE TABLE S(
	F TEXT NOT NULL,
	SA TEXT,
	SC TEXT NOT NULL,
	SD TEXT NOT NULL,
	SG TEXT REFERENCES E2(G),
	PRIMARY KEY (SC, SD, SA),
	FOREIGN KEY (SC, SD) REFERENCES E1(C, D)
	);

ALTER TABLE E1
ADD FOREIGN KEY (C,D) REFERENCES S(SC,SD);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
This entity relationship model can be applyed in company.

E1 is the table contains the identification information of enployee.
	A: employee ID
	B: sex
	C: first_name
	D: last_name
	primary key: A, C+D
	Candidate key: C+D or A
S is the table contains information of personal account that have one-to-one
relationship with table (E1) employee.
	F: open account time
E2 is the table contains information of login actions
	G: login time (Primary key)
	H: logout time
	K: stay time
	J: login position
*/

