/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218919N               */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT al.name AS app, c.name AS country
FROM available al, country c, store s1, store s2
WHERE al.country = c.code3
AND al.name = s1.name 
AND s1.os = 'iOS'
AND al.name = s2.name
AND s2.os = 'Android'
AND c.continent_name = 'Europe';


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(DISTINCT c.continent_name) > 1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_code <> c2.continent_code;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT al.name
FROM available al, country c
WHERE al.country = c.code3
AND c.continent_name = 'Oceania'
AND al.name NOT IN (
	SELECT idx.name
	FROM store s RIGHT OUTER JOIN
	(SELECT a.name, os.os
	FROM app a, (SELECT DISTINCT s.os FROM store s) AS os) AS idx
	ON s.name = idx.name
	AND s.os = idx.os
	WHERE s.name IS NULL);
	
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT loser.name, loser.count
FROM (
	SELECT c.name, COUNT(*)
	FROM country c, available al
	WHERE c.code3 = al.country
	GROUP BY c.name) as loser 
LEFT OUTER JOIN (
	SELECT c.name, COUNT(*)
	FROM country c, available al
	WHERE c.code3 = al.country
	GROUP BY c.name) as winner
ON winner.name <> loser.name
AND winner.count > loser.count
GROUP BY loser.name, loser.count
HAVING COUNT(loser.name) < 6
ORDER BY loser.count DESC;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E2 (
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL,
	J TEXT NOT NULL,
	K TEXT NOT NULL);

CREATE TABLE E1 (
	A TEXT PRIMARY KEY,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	F TEXT NOT NULL,
	G TEXT NOT NULL REFERENCES E2(G),
	UNIQUE (C,D));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

The diagram can represent the current inpatients at the hospital.

E1: inpatient
E2: doctor-in-charge

A: NRIC of inpatient
B: gender
C: ward number
D: bed number

F: date of admission

G: employee number of doctor
H: gender
J: seniority (e.g. consultant)
K: date joined hospital

Candidate keys: Inpatient can be identified by either NRIC or a combination
of ward and bed number.

Participation constraints: Patient must have one and only one doctor-in-charge
assigned, so the hospital can track who is responsible.

But a doctor may have zero or many patients under his care at any one time.

*/

