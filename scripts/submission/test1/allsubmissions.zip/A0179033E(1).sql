/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0179033E						                    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT continent_name, continent_code FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name, c.name FROM available a, country c, app app, store s
WHERE a.country = c.code3
	AND a.name = app.name
	AND app.name = s.name
	AND c.continent_name = 'Europe'
	AND a.name IN (SELECT name FROM store
GROUP BY name
HAVING COUNT(os) =1)
GROUP BY a.name, c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT name FROM country
GROUP BY name
HAVING COUNT(continent_name)>1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT c.name FROM country c
LEFT JOIN (SELECT DISTINCT ON(c2.name) c2.name, c2.continent_name FROM country c2) as c3 ON (c.name, c.continent_name) = (c3.name, c3.continent_name)
WHERE c3.continent_name ISNULL
ORDER BY c3.continent_name DESC;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name FROM available a, country c, app app, store s
WHERE a.country = c.code3
	AND a.name = app.name
	AND app.name = s.name
	AND c.continent_name = 'Oceania'
	AND a.name IN (SELECT name FROM store
GROUP BY name
HAVING COUNT(os) >=2)
GROUP BY a.name, c.name;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT con.name, COUNT(a.name) FROM available a, (SELECT DISTINCT c.name, c.code3 FROM country c) AS con
WHERE a.country = con.code3
GROUP BY con.name
ORDER BY COUNT(country) DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E1(
A VARCHAR(30) UNIQUE NOT NULL,
B VARCHAR(30) NOT NULL,
C VARCHAR(30),
D VARCHAR(30),
F VARCHAR(30) NOT NULL,
E2_G VARCHAR(30) NOT NULL,
PRIMARY KEY (C,D),
FOREIGN KEY (E2_G) REFERENCES E2(G));

CREATE TABLE E2(
J VARCHAR(30) NOT NULL,
K VARCHAR(30) NOT NULL,
G VARCHAR(30) PRIMARY KEY,
H VARCHAR(30) NOT NULL);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
In this scenario we are assuming this is a database for a centralized conglomerate which has a record
of all locations. In this case, the conglomerate has several related businesses for which each business has their specific factories (controled by the conglomerate. As such, IDs are unique).
They are concenrned with the global carbon emission objectives they have to follow. e.g: usually, every country/business unit has a specific objective to be achieved by a specified date.

E1: factory directory for a conglomerate.
	A:Factory ID code
	B:address
	C:factory name
	D:business it belongs to 
	(we assume that a factory could have the same coloquial name in multiple businesses
	as such, name+business would provide a primary key)

S: Subscribed to. (realates each factory to the global CO2 reduction objective to be followed)
	F: Goal limit date

E2: Environmental objectives.
	G: Objective ID
	J: %CO2 to be reduced
	K: Category of CO2 reduction (In environmental CO2 reduction there are different scopes under which CO2 is classified)
	H: Imposed by law?

E1 has a (1,1) relationship since every location is subject to environmental regulations. In the case that there is not a specified objective, then it is usually stated as 0% reduction.
As such, it will always have a (1,1) relationship with the objectives.
On the other hand on E2, each objective can have any amount of factories which follow it (0,n).

*/

