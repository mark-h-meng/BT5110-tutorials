
/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232022A                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select  distinct continent_name,continent_code from country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t1.name, t2.name from available as t1
left join country as t2
on t1.country = t2.code3
where t2.continent_name = 'Europe';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select name  from country 
group by name
having count(continent_name) > 1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select name from (
select  name, row_number() over (partition by name order by continent_name) as index
from country)t1
where t1.index >='2';
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t1.name from available as t1
left join country as t2
on t1.country = t2.code3
left join store t3
on t1.name = t3.name
where t2.continent_name = 'Oceania';
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t2.name as country, count(t1.name) as num from available as t1
left join country as t2
on t1.country = t2.code3
group by t2.name
order by num desc
limit 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1 (
A VARCHAR(20) not null ,
B VARCHAR(20) not null ,
C VARCHAR(20) not null,
D VARCHAR(20) not null,
PRIMARY KEY (C,D));

create table IF NOT EXISTS E2 (
J VARCHAR(20) not null ,
K VARCHAR(20) not null ,
G VARCHAR(20) not null ,
F VARCHAR(20) not null ,
H VARCHAR(20) not null ,
FOREIGN KEY (F) REFERENCES s(F);


create table 

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*


*/

