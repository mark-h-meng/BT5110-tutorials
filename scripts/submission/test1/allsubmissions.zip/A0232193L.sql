/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232193L                                           */

/************************************************************************/
/*                                                                       */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name, continent_code
FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name AS app, c.name AS country
FROM appfunctionality a, available b, country c, store d
WHERE a.name = b.name
AND b.country = c.code3
AND a.name = d.name
AND c.continent_name = 'Europe'
AND a.functionality = 'contact tracing'
AND d.os = 'iOS'
INTERSECT
SELECT a.name AS app, c.name AS country
FROM appfunctionality a, available b, country c, store d
WHERE a.name = b.name
AND b.country = c.code3
AND a.name = d.name
AND c.continent_name = 'Europe'
AND a.functionality = 'contact tracing'
AND d.os = 'Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT B.name
FROM
(SELECT a.name as name, count(*) as num
FROM country a
GROUP BY a.name) b
WHERE num > 1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT a.name 
FROM country a, country b
WHERE a.name = b.name
AND a.continent_name <> b.continent_name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name
FROM available a, country b, store c
WHERE a.country = b.code3
AND a.name = c.name
AND b.continent_name = 'Oceania'
AND c.os = 'Android' 
INTERSECT
SELECT a.name
FROM available a, country b, store c
WHERE a.country = b.code3
AND a.name = c.name
AND b.continent_name = 'Oceania'
AND c.os = 'iOS' ;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT b.name AS name, count(*) AS num
FROM available a, country b
WHERE a.country = b.code3
GROUP BY b.name
ORDER BY num DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E2(
    J TEXT NOT NULL,
    K TEXT NOT NULL,
    H TEXT NOT NULL,
    G TEXT PRIMARY KEY
);

CREATE TABLE E1(
    A TEXT,
    B TEXT NOT NULL,
    C TEXT,
    D TEXT,
    F TEXT NOT NULL,
    G TEXT NOT NULL,
    PRIMARY KEY(A, C, D),
    FOREIGN KEY (G) REFERENCES E2(G)
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Entity set E1 includes the information of stores in one city. 
Entity set E2 includes the information of owners who own at least one store in any cities.
To be specific, the candidate key of E2 is owners' names(G). E2(owners) has three attributes, 'age'(J), 'gender'(K), 'education'(H).
The candidate key of E1 is each store' 'name'(A), 'district'(C) and 'street_name'(D). A city has many districts, and each district has many streets. Different districts may have streets with the same
name. Thus, stores' names. districts and street names jointly identify a specific store. Moreover, each store also has one more attribute, type(B), which shows the type of things it sells.
As for the relationship set S, it means the owners in E2 may own all kinds of number of stores in E1, from 0 to a large number of stores(participation constraints(0,n)). Moreover, each store must have only one owner(participation constraints(1,1)).
Relationship set S also has one attribute F, which is length_of_ownership. It indicates how much owners have owned the corresponding stores.

*/

