/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231918A                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT continent_name, continent_code
FROM country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT af.name AS app, c.name AS country
FROM appfunctionality af, country c, store s, available av, functionality f
WHERE af.name = s.name
AND af.functionality = f.type
AND af.name = av.name
AND av.country = c.code3
AND s.os = 'iOS'
AND c.continent_code = 'EU'
AND f.type = 'contact tracing'
INTERSECT
SELECT af.name AS app, c.name AS country
FROM appfunctionality af, country c, store s, available av, functionality f
WHERE af.name = s.name
AND af.functionality = f.type
AND af.name = av.name
AND av.country = c.code3
AND s.os = 'Android'
AND c.continent_code = 'EU'
AND f.type = 'contact tracing';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(c.continent_code) > 1
ORDER BY c.name;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT av.name
FROM available av
WHERE NOT EXISTS(
SELECT * 
FROM store s
WHERE s.name = av.name
AND NOT EXISTS(
SELECT *
FROM country c
WHERE c.continent_code = 'OC'
AND c.code3 = av.country
));
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(*)
FROM available av, country c
WHERE av.country = c.code3
GROUP BY c.name
ORDER BY COUNT(*) DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1(
A TEXT NOT NULL,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
PRIMARY KEY(A,C,D)
);

CREATE TABLE E2(
G TEXT PRIMARY KEY,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL);

CREATE TABLE S(
F TEXT NOT NULL,
A TEXT, 
C TEXT,
D TEXT,
G TEXT,
FOREIGN KEY(A,C,D) REFERENCES E1(A,C,D),
FOREIGN KEY (G) REFERENCES E2(G),
PRIMARY KEY(A,C,D,G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1: person
A: first_name
C: last_name
D: email
B: birth_date

Assume that there is not exist two people with the same first name, last name and email address.
So these three attributes can denote a particular person, then they are the primary key of E1.

E2: company
G: company number
H: company name
J: company address
K: company post code

Assume company number is a unique index for a company, which can not be same in any other companies.
So company number can denote a company and it is the primary key of E2.

S: workfor
F: start_year

A particular person works for a particular company, so the primary keys of E1 AND E2
will be the primary key of S, and start_year indecates in which year the person started to work for the company.
*/

