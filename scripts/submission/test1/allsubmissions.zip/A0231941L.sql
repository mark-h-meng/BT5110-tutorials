/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231941L                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name AS app, c.name AS country
FROM available a, country c, store s
WHERE a.country = c.code3
AND a.name = s.name
AND c.continent_name='Europe'
AND s.os='iOS'
INTERSECT
SELECT a.name AS app, c.name AS country
FROM available a, country c, store s
WHERE a.country = c.code3
AND a.name = s.name
AND c.continent_name='Europe'
AND s.os='Android';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING count(c.continent_name)>1
ORDER BY c.name ASC;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name, c.continent_name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name 
FROM available a, store s, country c
WHERE a.name=s.name
AND a.country=c.code3
AND c.continent_name='Oceania'
GROUP BY a.name
HAVING COUNT(*) = (
	SELECT COUNT(DISTINCT s.os)
	FROM store s);
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(DISTINCT(a.name)) AS count
FROM country c, available a
WHERE c.code3=a.country
GROUP BY c.name
ORDER BY count DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E2(
G TEXT PRIMARY KEY,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS E1(
A TEXT UNIQUE,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
G TEXT NOT NULL,
F TEXT NOT NULL,
PRIMARY KEY (C,D),
FOREIGN KEY (G) REFERENCES E2(G));
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
This could be a manager-employee relationship database to record employee information and 
their manager in a company. An employee in a company must have one and only one manager,
but a manager could have no reportee or multiple reportees.
Let E1 as employee, which stores employee information. A is employee email address
that is unique and can be used to identity each employee. C is the department employee 
belongs to and D is employee number. With C and D composition, we will be able identify
an employee. B is employee address.
E2 as manager, which stroes manager inforamtion including G- managerID, H - date of birth
K - position, H - manager address.
F stores the start year when the manager start to manage the employee.
*/

