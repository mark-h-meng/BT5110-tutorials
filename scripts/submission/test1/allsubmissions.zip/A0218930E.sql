/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0218930E>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT continent_name, continent_code
FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT af.name as app, c.name as country
FROM appfunctionality af, available a, country c, store s
WHERE af.name = a.name
AND af.name = s.name
AND a.country = c.code3
AND c.continent_name = 'Europe'
AND af.functionality = 'contact tracing'
AND s.os = 'iOS'
INTERSECT
SELECT DISTINCT af.name as app, c.name as country
FROM appfunctionality af, available a, country c, store s
WHERE af.name = a.name
AND af.name = s.name
AND a.country = c.code3
AND c.continent_name = 'Europe'
AND af.functionality = 'contact tracing'
AND s.os = 'Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.name
FROM country c
GROUP BY c.name
HAVING count(c.name) > 1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c1.name
FROM country c1
JOIN country c2 ON c1.name = c2.name
AND c1.continent_name != c2.continent_name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.name
FROM country c, available a, store s
WHERE c.code3 = a.country
AND a.name = s.name
AND continent_name = 'Oceania'
AND EXISTS (SELECT DISTINCT os
			   FROM store);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.name, count(a.name)
FROM country c, available a
WHERE c.code3 = a.country
GROUP BY c.name
ORDER BY count(a.name) DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS E1(
    A VARCHAR(32),
    B VARCHAR(32) NOT NULL,
    C VARCHAR(32),
    D VARCHAR(32),
	PRIMARY KEY (A, C, D)
);

CREATE TABLE IF NOT EXISTS E2(
    G VARCHAR(32),
    H VARCHAR(32) NOT NULL,
    J VARCHAR(32) NOT NULL,
    K VARCHAR(32) NOT NULL,
    PRIMARY KEY (G)
);

CREATE TABLE IF NOT EXISTS S(
    F VARCHAR(32) NOT NULL,
    E1_A VARCHAR(32),
    E1_C VARCHAR(32),
    E1_D VARCHAR(32),
    E2_G VARCHAR(32) NOT NULL,
    PRIMARY KEY (E1_A, E1_C, E1_D),
    FOREIGN KEY (E1_A, E1_C, E1_D) REFERENCES E1(A, C, D),
    FOREIGN KEY (E2_G) REFERENCES E2(G)
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
The example could be about Grabfood/foodpanda application, which consist of three entity sets
E1 is customer data, which has A: customer_id, C: first_name, D: last_name, D: contact_number;
So, A: customer_id and (C: fisrt_name, D: last_name) are the PRIMARY KEY, D: contact_number cannot be NULL.
S is order data, which has F: oder_time
E2 is courier data, has the G: courier_id, J: vehicle_type, K: active_area, H: active_time_period


*/

