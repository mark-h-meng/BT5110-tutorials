/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0124294H                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*    DONE                                                              */
/************************************************************************/
select distinct continent_name,continent_code from country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/

-- select distinct a.name as app, c.name as country from app a, country c, available avail, store s1,store s2
-- where avail.country = c.code3 
-- and ((s1.os='iOS' and s2.os ='Android') or (s1.os='Android' and s2.os ='iOS'))  
-- and s1.name = a.name
-- and avail.name = a.name
-- and c.continent_name ='Europe';

select a.name as app, c.name as country from 
app a,available avail,country c
where 
a.name in (select s1.name from store s1
group by s1.name
having count(*) = (select count(distinct os) from store s2))
and a.name = avail.name 
and avail.country = c.code3 
and c.continent_name ='Europe';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*        DONE                                                              */
/************************************************************************/

select c1.name as name from country c1 
inner join country c2 
on c1.name = c2.name
group by c1.name 
having count(*) > 1
order by c1.name;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*           DONE                                                           */
/************************************************************************/

select distinct(c1.name) from country c1,country c2
where c1.name = c2.name
and c1.continent_name <> c2.continent_name 
order by c1.name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                               */
/************************************************************************/

select a.name as app, c.name as country from 
app a,available avail,country c
where 
a.name in (select s1.name from store s1
group by s1.name
having count(*) = (select count(distinct os) from store s2))
and a.name = avail.name 
and avail.country = c.code3 
and c.continent_name ='Oceania';

/************************************************************************/
/*                                                          */
/* Question 1.f                                                         */
/*             DONE                                                         */
/************************************************************************/

select c.name,count(*) as count from available avail, country c
where c.code3 = avail.country
group by c.name
order by count desc limit 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*           DONE                                                       */
/************************************************************************/
CREATE TABLE E2 (
G TEXT NOT NULL,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL,
Primary KEY(G));

CREATE TABLE E1_S(
A TEXT NOT NULL,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
F TEXT NOT NULL,
G TEXT NOT NULL,
Primary KEY(A,C,D,G),
FOREIGN KEY (G) REFERENCES E2(G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*          DONE                                                        */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1 can represent an employee
E2 can represent a Company
S can be the contract
Each employee can only work for 1 company therefore (1,1)
Each Company can have zero to many employee, therefore (0,n)
Attribute J,K,H can describe the company profile : size, assets etc.
Attribute G can be the company UEN that is tagged to identify that the employee is part of company
Attribute C and D can be the first and last name of the employee
Attribute A can be the staff ID
B can be the gender
F can be the date of contract signed
*/

