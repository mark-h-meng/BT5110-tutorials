/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0125002E>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.name as app , c.name as country
FROM app a, country c, store s1, available av, store s2
WHERE s1.name = a.name AND a.name = av.name AND
c.code3 = av.country
AND c.continent_code = 'EU' AND s1.os = 'iOS' AND s2.os ='Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(*) >=2;

/*source: https://stackoverflow.com/questions/6095567/sql-query-to-obtain-value-that-occurs-more-than-once */
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1
WHERE EXISTS(
SELECT c2.name
FROM country c2
WHERE c1.name = c2.name AND c1.continent_code <> c2.continent_code);
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT a.name 
FROM app a, country c, available av, store s
WHERE av.country = c.code3 AND c.continent_name = 'Oceania' AND av. name = a.name AND
s.name = a.name AND s.os IS NOT NULL;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name, COUNT(av.name)
FROM country c, available av, app a 
WHERE av.name = a.name AND av.country = c.code3
GROUP BY c.name
ORDER BY COUNT(av.name) DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1(
A TEXT UNIQUE NOT NULL,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
PRIMARY KEY (C,D));

CREATE TABLE IF NOT EXISTS E2(
G TEXT PRIMARY KEY,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS E1_S (
A TEXT UNIQUE NOT NULL,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
F TEXT NOT NULL,
PRIMARY KEY (C,D),
G TEXT NOT NULL,
FOREIGN KEY (G) REFERENCES E2(G),
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Figure 1 can correspond to a system tracking long-distance trains & the drivers operating it to keep track of the date it was run so as to help in preventive maintenance. 
One such example would be long-distance trains especially prevalent in Europe. We shall use France as an example and its TGVs under the SNCF network.

E1 will be trains and is (1,1) as 1 train can  only be driven by 1 train driver. 
Attribute A of E1 can be the train_ID which can aid in identification and is unique to each train.
Attribute B can be the age of the train 
Attribute C can be the rolling stock which identifies the regions it operates for e.g. TGV Atlantique, TGV Sud-est, TGV Lyria etc. Given that the rolling stock can serve many routes in that area, 
another attribute D which is date_time of arrival 
[for e.g. TGV Sud-Est from Lyon to Paris Gare de Lyon on 29th September 2021 at 1300hrs]
This will provide a more accurate picture of utilisation of train as in one instance the route and duration can be seen.

Relationship S will be drives/driven by to and its attribute F will be the date that the train is driven so that a log of its usage in a month can be kept.

E2 will be train driver with (0,n) as a driver can drive no or multiple trains on the day
Attribute G as ID to identify him/her 
Attribute H will be years_of_experience
Attribute J will be name
Attribute H will be department which indicates which department/function in the SNCF network is in charge of the driver.


*/

