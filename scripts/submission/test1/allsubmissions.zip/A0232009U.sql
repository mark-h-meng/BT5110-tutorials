/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232009U               */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name, continent_code
from country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select ap.name as app, c.name as country
from app ap, available a, country c, store s1, store s2
where ap.name = s1.name and ap.name = s2.name and ap.name = a.name and a.country = c.code3 
and c.continent_name = 'Europe'
and s1.os = 'iOS' and s2.os = 'Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name
from country c
group by c.name
having count(*) > 1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.name
from country c
where c.name = ANY(
select c1.name
from country c1
where c.continent_name <> c1.continent_name);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select ap.name
from app ap, available a, country c, store s
where ap.name = a.name and a.country = c.code3 and ap.name = s.name
and c.continent_name = 'Oceania' 
and s.os >= ALL(select s1.os from store s1);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name, count(*)
from country c inner join available a on c.code3 = a.country
group by c.name
order by count(*) desc
limit 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E1(
	A TEXT UNIQUE NOT NULL,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	PRIMARY KEY(C, D)
);

CREATE TABLE IF NOT EXISTS E2(
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL,
	J TEXT NOT NULL,
	K TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS S(
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	G TEXT NOT NULL,
	PRIMARY KEY(C, D, G),
	FOREIGN KEY(C, D) REFERENCES E1(C, D),
	FOREIGN KEY(G) REFERENCES E2(G)
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*


*/

