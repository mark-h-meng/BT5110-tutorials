/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231957X                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT continent_name, continent_code
FROM country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT ap.name AS app,c.name AS country
FROM app ap, available av, store s, appfunctionality af,
country c
WHERE ap.name=av.name
AND ap.name=s.name
AND ap.name=af.name
AND av.country=c.code3
AND af.functionality='contact tracing'
AND c.continent_name='Europe'
AND ap.name in (select s.name
			FROM store s
		    where s.os='iOS'
			intersect
			select s.name
			FROM store s
		    where s.os='Android')
			group by ap.name,c.name;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
group by c.name
having COUNT(c.continent_name) >1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT ap.name
FROM app ap, available av, store s,
country c
WHERE ap.name=av.name
AND ap.name=s.name
AND av.country=c.code3
AND c.continent_name='Oceania'
AND ap.name = any (select s1.name
			FROM store s1
		    where s1.os='iOS'
			intersect
			select s2.name
			FROM store s2
		    where s2.os='Android');
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name,COUNT(ap.name)
FROM app ap, available av, store s,
country c
WHERE ap.name=av.name
AND ap.name=s.name
AND av.country=c.code3
GROUP BY c.name
ORDER BY COUNT(ap.name) DESC
LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E2(
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL,
	K TEXT NOT NULL,
	J TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS E1(
	A TEXT NOT NULL,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	PRIMARY KEY (C,D),
	FOREIGN KEY (A) REFERENCES E2(G));
CREATE TABLE IF NOT EXISTS S(
	F TEXT NOT NULL,
	G TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	FOREIGN KEY (G) REFERENCES E2(G),
	FOREIGN KEY (C,D) REFERENCES E1(C,D)
);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
this is the database of political participants
E2 is the table of jobs in government,
G means the job title, 
J,K,H is features of one job, like work period,salary,duty
the key is G.
E1 is tha table of participants,
C,D is his first name and last name,
A is his job title,
B can be his address,
the combination of first name and last name is the key,
S is their relationship table.
Two tables' relationship is that 
one participants can have multiple job title or zero
but one job title only give one participant
F can be when participants get the job title
*/

