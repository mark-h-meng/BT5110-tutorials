/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231902R>                                         */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
select distinct(country.continent_name, upper(substring(country.continent_name,1,2)))
from country;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
select app.name as app, country.name as country
from app, country, available, store
where app.name = available.name
and app.name = store.name
and available.country = country.code3
and country.continent_name = 'Europe'
and store.os = 'iOS'
intersect
select app.name as app, country.name as country
from app, country, available, store
where app.name = available.name
and app.name = store.name
and available.country = country.code3
and country.continent_name = 'Europe'
and store.os = 'Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
select country.name
from country
group by country.name
having count(country.continent_name) >= 2;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
select app.name 
from app, country, store, available
where app.name = available.name
and available.country = country.code3
and app.name = store.name
and country.continent_name = 'Europe'
and store.os = 'iOS'
intersect
select app.name 
from app, country, store, available
where app.name = available.name
and available.country = country.code3
and app.name = store.name
and country.continent_name = 'Europe'
and store.os = 'Android';


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
select country.name, count(app.name) as count
from app, available, country, store
where app.name = available.name
and available.country = country.code3
and app.name = store.name
group by country.name
order by count desc
limit(6);


/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
CREATE TABLE E1 (
A VARCHAR(64) Unique,
B VARCHAR(64) not null,
C VARCHAR(64) not NULL,
D VARCHAR(64) not NULL,
primary key(C,D) );

CREATE TABLE E2 (
J VARCHAR(64) not null,
K VARCHAR(64) not null,
G VARCHAR(64) primary key,
H VARCHAR(64) not null);

create table S (
SA VARCHAR(64) not null,
SC VARCHAR(64) not null,
SD VARCHAR(64) not null,
F VARCHAR(64) not null,
SG VARCHAR(64) not null,
foreign key (SA) references E1(A),
foreign key (SC,SD) references E1(C,D),
foreign key (SG) references E2(G),
primary key(SC,SD)
);


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
We can assume that 
E1 is the entity of children,
E2 is the entity of fathers, and
S is the blood relationship between children and fathers.

A is the ID number of the child, 
B is the name of the child, 
C is the code of the school where the child is studying, 
D is the ID of the child in the school which is unique within the school,
F is the name of the mother,
G is the ID number of the father,
H is the company where the father works,
J is the name of the father, and
K is the citizenship of the father.

Unique constraint for A means a child can only have one ID number.
Unique constraint for C and D means we can use the combination of school's code and the ID of the child in that school to identify each child.
Unique constraint for G means a father can only have one ID number.

The (1,1) constraint means every child must have a father.
The (0,n) constraint means a father can have many children or no child that is recorded in the E1 table.
*/

