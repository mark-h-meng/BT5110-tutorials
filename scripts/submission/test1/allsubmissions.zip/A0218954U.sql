/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218954U                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.continent_name, c.continent_code
FROM country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT av.name AS app, c.name AS country
FROM available av, country c, appfunctionality af, store s1, store s2
WHERE av.country=c.code3 AND av.name=af.name AND av.name=s1.name AND av.name=s2.name 
AND c.continent_name = 'Europe'
AND s1.os='iOS' AND s2.os='Android' 
AND af.functionality ='contact tracing';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT c.name 
FROM country c
GROUP BY c.name
HAVING COUNT (c.continent_code) >1;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c1.name FROM country c1,country c2
WHERE c1.continent_code<>c2.continent_code
AND c1.name=c2.name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT s.name 
FROM store s, store s1, available av, country c
WHERE s.name=s1.name 
AND s.name=av.name 
AND av.country=c.code3
AND s.os<>s1.os 
AND c.continent_name ='Oceania' ;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT c.name, COUNT (DISTINCT av.name)as count
FROM available av, country c
WHERE av.country=c.code3
GROUP BY c.name
ORDER BY count DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS E2(
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL,
G TEXT PRIMARY KEY);

CREATE TABLE IF NOT EXISTS E1_S (
A TEXT NOT NULL UNIQUE,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
F TEXT NOT NULL,
G TEXT NOT NULL,
UNIQUE (C,D),
PRIMARY KEY (A,G),
FOREIGN KEY (G) REFERENCES E2 (G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

An example would be a company and it's employees. E1 is the employee and E2 is the company while the relationship set S represents work for.

For E1, it is a (1,1) participation constraint as each employee can only work for 1 company and each employee must
work for at least 1 company. A would represent the employee number which is a unique number for each employee.
B represents other attributes of the employee such as the employee's birthday. C represents the employee's first name.
D represents the employee's last name. The combination of the employee first and last name is unique (combination of C and D is thus unique). 

Relationship set S represents the relationship "works for" and F represents the date the employee joined the company.

Since the employee ID depends on the company the employee works for (different company can give same employee id), we can merge the table E1 and 
table S and use a combination of employee ID and company ID as the primay key.

For E2, it is a (0,n) participation constraint as a company can have no employees or many employees.
G represents the company registration number (such as UEN which is a unique entity number for each company registered in Singapore). 
H represents the date the company was registered.  J represents the company name and K represents the type of industry the company operates in.

For E1,there are 2 candidate keys (either employee ID which is A or the combination of first and last name which is combination of C and D). 
This is because the entity set E1 can be uniquely identified either by the employee's ID or the unique combination of the employee first and last name. 

For E2, there is only 1 candidate key which is the company's registration number, which is G.

*/

