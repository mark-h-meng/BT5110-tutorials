/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231868W                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name, continent_code
from country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select af.name as app, c.name as country
from appfunctionality af, available av, country c, store s
where af.name = av.name
and av.country = c.code3
and af.name = s.name
and af.functionality = 'contact tracing'
and c.continent_name = 'Europe'
and os = 'iOS'
intersect
select af.name as app, c.name as country
from appfunctionality af, available av, country c, store s
where af.name = av.name
and av.country = c.code3
and af.name = s.name
and af.functionality = 'contact tracing'
and c.continent_name = 'Europe'
and os = 'Android';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select name
from country c
group by name
having count(continent_name) > 1
order by name;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.name
from country c
where exists(
select c1.name, c1.continent_name
from country c1
where c1.name = c.name
and c1.continent_name <> c.continent_name)
order by name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select av.name
from available av, store s, country c
where av.name = s.name
and c.code3 = av.country
and c.continent_name = 'Oceania'
except
select w.name from
(select distinct s1.name, s2.os from store s1, store s2 order by name) w
left join
store s on w.name = s.name and s.os = w.os
where s.name ISNULL;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name, count(distinct av.name)
from country c, available av
where av.country = c.code3
group by c.name
order by count DESC
limit 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS E2(
G TEXT NOT NULL PRIMARY KEY,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS E1(
A TEXT UNIQUE NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
F TEXT NOT NULL,
G TEXT NOT NULL,
PRIMARY KEY(C, D),
FOREIGN KEY(G) references E2(G)
);
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
Example:
Suppose this is an entity-relationship diagram describing games
and their publishers with their relationship.

Entity set E1 represents 'Games'; entity set E2 represents 'Publishers';
relation set S represents 'Publications of games'.

In E1, A represents the issue number of the game, which is unique; B represents
the category of the game; C represents the name of the game; and D represents
the version of the game.The game could be identified either by A or
by the combination of C and D. And one game only has one publisher.

In E2, G represents the full name of the publisher; H represents the country
the publisher belongs to; J represents the address of the publisher company;
and K represents the year the publisher company was founded.

In S, F represents the initial publication date of the game.
*/
