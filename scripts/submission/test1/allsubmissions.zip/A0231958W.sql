/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231958W                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct c.continent_name, c.continent_code
from country c;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct a.name as app, c.name as country
from app a, country c, store s, available av
where c.continent_name = 'Europe'
and s.os in ('iOS','Android')
and av.country = c.code3;


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.name
from country c, available av, app a
where a.name = av.name and av.country = c.code3
group by a.name, c.name
having count(av.country) not in (0,1)
order by c.name asc;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.name
from country c, available av, app a
where a.name = av.name and av.country = c.code3
group by a.name, c.name
having count(av.country) not in (0,1)
order by c.name asc;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct a.name
from app a
where exists(
 	select c.continent_name
 	from country c, available av, app a, store s
 	where c.code3 = av.country and c.continent_name = 'Oceania'
 	and s.os in ('iOS','Android'));

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.name, count(a.name)
from country c, app a, available av
where av.country = c.code3 and av.name = a.name
group by c.name
order by count(a.name) desc
limit 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*


*/

