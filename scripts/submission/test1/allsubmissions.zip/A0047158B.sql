/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0047158B               */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT continent_name, continent_code 
FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT a.name AS app, c.name AS country
FROM available a, country c, store s, appfunctionality af
WHERE c.continent_name = 'Europe'
AND a.name = af.name
AND af.functionality = 'contact tracing'
AND a.country = c.code3
AND a.name = s.name
AND a.name IN (
	SELECT s1.name
	FROM store s1
	WHERE s1.os = 'iOS')
AND a.name IN (
	SELECT s2.name
	FROM store s2
	WHERE s2.os = 'Android');

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.name AS name
FROM country c
WHERE c.name IN (
	SELECT c1.name
	FROM country c1
	GROUP BY c1.name
	HAVING COUNT(DISTINCT c1.continent_code)>1);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c1.name AS name
FROM country c1, country c2
WHERE c1.continent_code <> c2.continent_code
AND c1.name = c2.name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT a.name AS name
FROM available a, country c, store s
WHERE a.country = c.code3
AND c.continent_name = 'Oceania'
AND a.name = s.name
AND s.name IN (
	SELECT DISTINCT s1.name
	FROM store s1, store s2
	WHERE s1.os <> s2.os
	AND s1.name = s2.name
	AND s.os = s1.os);


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name AS name, COUNT(DISTINCT a.name) AS count
FROM available a, country c
WHERE a.country = c.code3
GROUP BY c.name
ORDER BY count DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E2 (
	J TEXT NOT NULL,
	K TEXT NOT NULL,
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL);
	
CREATE TABLE E1S (
	A TEXT PRIMARY KEY,
	B TEXT NOT NULL,
	C TEXT NOT NULL,
	D TEXT NOT NULL,
	F TEXT NOT NULL,
	G TEXT NOT NULL,
	FOREIGN KEY G REFERENCES E2(G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

E1S - Child Birth Certificate (Details on the child and its birth details)
A - birth certificate number (primary key, uniquely identifiable across babies)
B - date of birth
C - child's name (forms the candidate key with mother's identification number)
D - mother's identification number (forms the candidate key with child's name)
F - time of birth (each child will only correspond to 1 time of birth)

E2 - Hospitals (Details on the hospitals)
G - hospital registration number (unique identifier for hospitals)
H - hospital name
J - state
K - hospital establishment date

*/

