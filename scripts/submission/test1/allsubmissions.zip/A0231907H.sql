/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231907H>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.continent_name, c.continent_code
FROM country c

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT av.name AS app, c.name AS country
FROM country c, available av, store s1, store s2, appfunctionality af
WHERE av.name = s1.name
AND av.name = s2.name
AND s1.os = 'iOS'
AND s2.os = 'Android'
AND av.country = c.code3
AND c.continent_code = 'EU'
AND av.name = af.name
AND af.functionality = 'contact tracing'
GROUP BY av.name, c.name



/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name
FROM country c
GROUP BY c.name
HAVING count(*) > 1


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_name <> c2.continent_name

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT av.name
FROM available av, store s, country c
WHERE s.name = av.name
AND av.country = c.code3
AND c.continent_name ='Oceania'
GROUP BY av.name
HAVING count(*) = count(DISTINCT s.os)



/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT av.country, count(*) AS number
FROM available av
GROUP BY av.country
ORDER BY number DESC
LIMIT 6

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS E1(
A TEXT,
B TEXT NOT NULL，
C TEXT，
D TEXT,
PRIMARY KEY （A, C, D)
);

CREATE TABLE IF NOT EXISTS E2(
G TEXT PRIMARY KEY,
H TEXT NOT NULL,
J TEXT NOT NULL,
K TEXT NOT NULL,
);

/*Original Table S*/
CREATE TABLE IF NOT EXISTS S(
F TEXT NOT NULL,
A TEXT,
C TEXT,
D TEXT,
G TEXT,
PRIMARY KEY (A,C,D,G),
FOREIGN KEY (A,C,D) REFERENCES E1(A,C,D),
FOREIGN KEY (G) REFERENCES E2(G)
);

/*Update table because of (1,1) relationship*/
/*Merge the table E1 and the table S and use the primary key of the E1 table*/
CREATE TABLE IF NOT EXISTS E1_S(
F TEXT NOT NULL,
A TEXT,
C TEXT,
D TEXT,
B TEXT NOT NULL,
G TEXT NOT NULL,
PRIMARY KEY (A,C,D),
FOREIGN KEY (G) REFERENCES E2(G)
);


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

Description
A school has several deparments, each deparment has only one head to
lead the whole department, but an excellent head can lead several relative deparments.
Each school will also elect a committee through their unterstanding teachers, including
both headers and non-headers.
Now we want to build a database to record the head relationship between
different school deparments and committees. The member of the committee can be the head of 
one or more school departments, amd they can also not be the head of any department and be chosen
just because of their good performance.

So the database is shown as figure 1.
The actual meaning is as follows:

E1 records school deparment;
  A is school_name
  B is number of members in this department
  C is department_name
  D is office address
  ACD together form the primary key to identigy a department
E2 records school educational committee;
  G is the unique committe_number as the primary key to identify a person
  H is the name
  J is the email
  K is the address of the member
R functions as head connecting E1 and E2
  F is the term of office
  ACD is the foreign key referring to E1
  G is the foreign key referring to E2
  
*/

