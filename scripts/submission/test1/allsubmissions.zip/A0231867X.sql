/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231867X>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct continent_name, continent_code
from country;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


select t1.name as app, c.name as country
from
(
	select *
	from
	(
		select *
		from
		(
			select *
			from available
			where available.name = any(
			select name 
			from appfunctionality
			where functionality = 'contact tracing'
			)
		) n1
		where country in(select code3
		from country
		where continent_code = 'EU')
	)a 
	where name = any
	(
	select name
	from
	(
		select name,count(os) as provider
		from store
		group by name
		having count(os) >1
	) t
	)
) t1
left join country c
on t1.country = c.code3
;




/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


select name
from
(
select name, count(continent_code) as span
from country
group by name
having count(continent_code) > 1
) a
;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


select distinct c1.name as name
from country c1
left join country c2
on c1.name = c2.name
where c1.continent_code <> c2.continent_code
order by c1.name 
;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select name
from available
where country = any(select code3
from country
where continent_name = 'Oceania'
)
;




/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select country, count(distinct name) as app_count
from available
group by country
order by count(distinct name) desc
limit 6
;



/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE Table E1(
A TEXT not null unique,
B TEXT not null,
C TEXT not null,
D TEXT not null,
Primary Key (C, D)
);

CREATE Table E2(
J TEXT not null,
K TEXT not null,
G TEXT not null Primary Key,
H TEXT not null
)
;


CREATE TABLE S(
F TEXT NOT NULL,
sc TEXT NOT NULL,
sd TEXT NOT NULL,
PRIMARY KEY (sc, sd),
FOREIGN KEY (sc,sd) REFERENCES E1(C,D))
;


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
In real life, E1 could be a record of patients be admitted to hospital, 
while E2 could be the details of each hospital, and S informs us who was
admitted to which hosptial. 

In E1, A could be one's identity number, which is absolutely a primary key.
C and D could be one's first name and last name respectively. B could be the
age. Suppose everyone has a distinctive name in this table,
then both A and (C,D) can be the candidate key.

Each patient could only be admitted to one hospital during a specific period.
But a hospital could admit several patients at the same time, or didn't admit
anyone at all. 

In E2, G could be the official code of each hospital, which is a primary key. 
H could be the contact number and J could be the adress of this hospital.
K could be the capacity of the hospital. The only candidate key is G.

In S, F could be the date each petient was admitted to the hospital.

*/

