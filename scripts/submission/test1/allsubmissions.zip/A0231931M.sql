/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231931M>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.continent_name, c.continent_code
FROM country c;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT av.name AS app, c.name 
FROM available av, store s, country c
WHERE av.name = s.name
AND s.os = 'Android'
AND av.country = c.code3
INTERSECT
SELECT av.name AS app, c.name
FROM available av, store s, country c
WHERE av.name = s.name
AND s.os = 'iOS'
AND av.country = c.code3
INTERSECT
SELECT av.name AS app, c.name
FROM available av, store s, country c
WHERE av.name = s.name
AND av.country = c.code3
AND c.continent_code = 'EU'


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(*) > 1;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.name
FROM country c
WHERE exists
	(select 1 from country c2
	where c.name = c2.name and c.continent_code  <> c2.continent_code );

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT av.name
FROM available av, store s
WHERE av.country = 'AUS'
OR av.country = 'PNG'
OR av.country = 'NZL'
OR av.country = 'FJI'
OR av.country = 'SLB'
OR av.country = 'FSM'
OR av.country = 'VUT'
OR av.country = 'WSM'
OR av.country = 'KIR'
OR av.country = 'TON'
OR av.country = 'MHL'
OR av.country = 'PLW'
OR av.country = 'TUV'
OR av.country = 'NRU'
GROUP BY av.name
HAVING COUNT(*) > 2;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT av.country, COUNT(*)
FROM available av
GROUP BY av.country
ORDER BY COUNT(*) DESC;


/*
CREATE TABLE top6 (
name VARCHAR(64) NOT NULL,
number NUMERIC);

INSERT INTO public.top6 VALUES ('United States of America', 65);
INSERT INTO public.top6 VALUES ('India, Republic of', 52);
INSERT INTO public.top6 VALUES ('Mexico, United Mexican States', 21);
INSERT INTO public.top6 VALUES ('Brazil, Federatie Republic of', 17);
INSERT INTO public.top6 VALUES ('Spain, Kingdon of', 16);
INSERT INTO public.top6 VALUES ('United Kingdom of Great Britain & Northern Ireland', 14);
*/
/*
SELECT *
FROM top6
*/

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


CREATE TABLE E1 (
A VARCHAR(32),
C VARCHAR(32),
D VARCHAR(32),
B VARCHAR(32) NOT NULL,
PRIMARY KEY (A, C, D));

CREATE TABLE E2 (
G VARCHAR(32) PRIMARY KEY,
J VARCHAR(32) NOT NULL,
K VARCHAR(32) NOT NULL,
H VARCHAR(32) NOT NULL);

CREATE TABLE S (
F VARCHAR(32) NOT NULL,
A VARCHAR(32),
C VARCHAR(32),
D VARCHAR(32),
B VARCHAR(32) NOT NULL,
G VARCHAR(32) NOT NULL,
J VARCHAR(32) NOT NULL,
K VARCHAR(32) NOT NULL,
H VARCHAR(32) NOT NULL,
PRIMARY KEY (A, C, D),
FOREIGN KEY (G) REFERENCES E2(G));


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
A real world example for entity set E1 could be for students around the world. The student id, first name, last time could be A, C, D 
and their age is in B
The id, first name, and last name will be the primary key which is connected to S where it shows the student's contact number in F.

Enity set E2 could be the record of how student booking the SAT test. G could be the email the student
used to register to be the primary key to recognize which student it is
J, K, H could be the location, date, and time where the test was booked
*/

