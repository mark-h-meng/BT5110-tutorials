/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231887U / Donghwan Kim / E0709142                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct continent_name, continent_code 
from country
;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select app, country
from(
	select a.name as app, c.name as country, s.os as os
	from country c
	inner join available a on c.code3 = a.country
	inner join store s on s.name = a.name
	inner join appfunctionality f on f.name = a.name
	where 1=1
	  and c.continent_name = 'Europe'
	  and f.functionality = 'contact tracing'
) t
group by 1,2
having count(*) > 1
;


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select name
from country
group by 1
having count(distinct continent_name) > 1 
;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select name
from country
where continent_name >= ALL(select continent_name from country group by 1)
;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.name
from country c
inner join available a on a.country = c.code3
inner join store s on s.name = a.name
where 1=1
  and continent_name = 'Oceania'
  and s.os in (select os from store group by 1)
group by 1
order by 1
;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.name, count(distinct a.name) 
from available a
inner join country c on c.code3 = a.country
group by 1
order by 2 desc 
limit 6
;


/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE E1(
	B VARCHAR(32) NOT NULL,
	A VARCHAR(32),
	C VARCHAR(32),
	D VARCHAR(32),
	PRIMARY KEY (A, C, D)
)
;
CREATE TABLE E2(
	G VARCHAR(32) PRIMARY KEY,
	H VARCHAR(32) NOT NULL,
	J VARCHAR(32) NOT NULL,
	K VARCHAR(32) NOT NULL
)
;
CREATE TABLE S(
	F VARCHAR(32) NOT NULL,
	e1_a VARCHAR(32),
	e1_c VARCHAR(32),
	e1_d VARCHAR(32), 
	e2_g VARCHAR(32),
	PRIMARY KEY (e1_a, e1_c, e1_d, e2_g),
	FOREIGN KEY (e1_a, e1_c, e1_d) 
	REFERENCES E1(A, C, D),
	FOREIGN KEY (e2_g) REFERENCES E2(G)
)
;


/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

We can think about the case of students applying for the companies to work for. 

In this case, the entity set 'E1' can be 'Students' 
and the entity set 'E2' can be 'Companies'. 
The relationship set 'S' can be described as 'Apply', 
and here, it means that one student can apply for many different companies.

Attributes A, C, D can be 'First name', 'Last name', 'gender' respectively 
and the attribute B can be 'the country that the student is living' 
while the attributes A, C, and D are composite key for the table E1.

Attribute F can be 'the datetime that the student applied',
and the attributes G, H, J, K can be 'company id', 
'number of employees in the company', 'the industry of the company', 
and 'the name of the CEO of the company' respectively.
while the 'company id' is the primary key that indicates one unique company.

*/





















