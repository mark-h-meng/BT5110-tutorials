/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231990A                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT continent_name, continent_code
FROM country;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT
	av.name AS app, 
	c.name AS country
FROM available av, country c, store s
WHERE av.country = c.code3
AND av.name = s.name
AND continent_code = 'EU'
AND s.os = 'iOS'
INTERSECT
SELECT
	av.name AS app, 
	c.name AS country
FROM available av, country c, store s
WHERE av.country = c.code3
AND av.name = s.name
AND continent_code = 'EU'
AND s.os = 'Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.name
FROM country c
GROUP BY name
HAVING COUNT(c.name) >= 2;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.name
FROM country c
WHERE c.name IN (
	SELECT c1.name
	FROM country c1
	WHERE c1.name = c.name
	AND c1.continent_code <> c.continent_code);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT
	av.name
FROM available av, country c
WHERE av.country = c.code3
AND continent_code = 'OC';

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
	c.name,
	COUNT(*) as count
FROM available av, country c
WHERE av.country = c.code3
GROUP BY c.name
ORDER BY count DESC
LIMIT 6;

/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE e2(
	G TEXT PRIMARY KEY,
	H TEXT NOT NULL,
	J TEXT NOT NULL,
	K TEXT NOT NULL);

CREATE TABLE e1_s(
	F TEXT NOT NULL,
	A TEXT,
	B TEXT NOT NULL,
	C TEXT,
	D TEXT,
	G TEXT NOT NULL,
	PRIMARY KEY (A, C, D),
	FOREIGN KEY (G) REFERENCES e2(G));

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*

The real world example in this case could be a Yoga Studio.

The entity set E1 represents the information of the studio's customers. This entity set is comprised of:
A - Customer's Email
C - Customer's First Name
D - Customer's Last Name
B - Customer's Membership Type. Some examples could be 'Student', 'Senior', 'Monthly Adult', 'Pay As You Go Adult', etc.
The primary key in this entity set is a composite of the customer's email, first name and last name.
There could be customers with the same first and last names. There could also be a case where a couple decides to furnish only one email.
Hence a composite of these three fields would serve as the primary key.

The entity set E2 represents the information of the studio's yoga instructors. This entity set is comprised of:
G - Instructor's Employee ID
H - Instructor's First Name
J - Instructor's Last Name
K - Instructor's Full Time Status (i.e. Boolean where 1 = Full Time, 0 = Part Time)
In this case, the instructor's employee ID is sufficient to serve as the primary key since it is unique to each instructor.

The relationship set S represents the assignment of customers to an instructor. 
In this case, each customer is always assigned to one instructor.
Each instructor can be assigned to any number of customers. It is also possible that an instructor is not assigned any customers.

The relationship set S includes the attribute F, which records down the date on which the customer was assigned to his/her instructor.

*/

