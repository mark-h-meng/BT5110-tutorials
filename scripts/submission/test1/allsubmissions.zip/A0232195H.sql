/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0232195H>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select continent_name, continent_code
From country;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select v.name as app, c.name as country
From available v , country c, store s1, store s2
Where c.code3=v.country AND s1.name=v.name AND s2.name=v.name
AND c.continent_code='EU'
AND s1.os='iOS'
AND s2.os='Android';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select c.name as name
From country c
Group by c.name
Having count(Distinct c.continent_name)>1;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select DISTINCT c1.name as name
From country c1, country c2
Where c1.continent_code<>c2.continent_code
AND c1.name=c2.name;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select DISTINCT v.name as name
From available v, country c
Where v.country=c.code3
AND c.continent_name='Oceania';
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select c.name as name, count (v.name)
From country c, available v
Where v.country=c.code3
Group by c.name
ORDER BY count (v.name) Desc
Limit 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table E2(
J TEXT not null,
K TEXT not null,
H TEXT not null,
G TEXT PRIMARY KEY);

create table E1S(
F TEXT not null,
A TEXT not null,
B TEXT not null,
C TEXT not null,
D TEXT not null,
G TEXT not null,
Primary key (A,C,D),
Foreign key (G) references E2(G));
/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
E1: Laptops S: is bought by E2: students
Attrubute:
A: laptop brand; B: color; C: Date of buying; D: Laptop model
F: Shops that the students bought the laptop
G: student's identification number
J: student's gender
K: Student's name
H: Student's address
Participant constraint explained: usually one laptop can only be bought by one student;
But student can buy from 0 to n laptops based on their willingness;
Candidate keys explained: laptops are similar so one attibute alone can't identify the exact laptop;
usually laptop's brand, model and the date of buying can be used to identify the laptop;
For students, the idenfitication number issued by government can idenfify the students,
other attributes like gender, names and addresses are too vague to be candidat keys.

*/

