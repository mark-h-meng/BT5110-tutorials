/************************************************************************/
/*                                                                      */
/* Test 1.                                                              */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232321Y                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.continent_name,c.continent_code
FROM country c;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT  av.name AS APP, c.name AS country
FROM store s1, country c, available av, store s2, appfunctionality af
WHERE s1.name = av.name
AND s2.name = av.name
AND s1.name = s2.name
AND av.name = af.name
AND af.functionality = 'contact tracing'
AND av.country = c.code3
AND c.continent_name = 'Europe'
AND s1.os = 'iOS'
AND s2.os = 'Android';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name
FROM country c
GROUP BY c.name
HAVING COUNT(*)>1
ORDER BY c.name;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c1.name
FROM country c1, country c2
WHERE c1.name = c2.name
AND c1.continent_code <> c2.continent_code
ORDER BY c1.name;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT app.name
FROM app, available av, country c
WHERE app.name = av.name
AND av.country = c.code3
AND c.continent_name = 'Oceania'
AND NOT EXISTS(
	SELECT *
	FROM available av1
	WHERE av1.name = app.name
	AND NOT EXISTS(
		SELECT DISTINCT s.os
		FROM store s
		WHERE s.name = av.name
		));

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.name AS country, COUNT(av.name)
FROM country c, available av
WHERE av.country = c.code3
GROUP BY c.name
ORDER BY COUNT(av.name) DESC LIMIT 6;
/************************************************************************/
/*                                                                      */
/* Question 2.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE E1 (
A TEXT PRIMARY KEY,
B TEXT NOT NULL,
C TEXT NOT NULL,
D TEXT NOT NULL,
UNIQUE (C,D)
);

CREATE TABLE E2 (
J TEXT NOT NULL,
K TEXT NOT NULL,
H TEXT NOT NULL,
G TEXT PRIMARY KEY
);

CREATE TABLE S(
A TEXT PRIMARY KEY REFERENCES E1(A),
F TEXT NOT NULL,
G TEXT NOT NULL REFERENCES E2(G)
);

/************************************************************************/
/*                                                                      */
/* Question 2.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in English below (between the comment markers):    */
/*
We can assume that E1 is fresh students of a university and E2 is high schools.
Graduation is the S.Every student have a graduated high school, 
and a high school can have many graduates. So it is a one to many relationship, 
so its primary key is students'IDs.
Graduation can also has attribute year(F).
Students can be identified by their National IDs (A), and can also be indentified by 
their first name and last name as C and D. It can also has attribute such as age, B.
High schools can be identified by school names(G), and they has address, number of students,
starting year as J K H.
*/

