/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0080400B                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn
FROM transactions t, credit_cards cc
WHERE DATE(t.datetime) = '2017-12-25'
	AND t.number=cc.number
	AND cc.type='visa'
;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.first_name, c.last_name
FROM customers c
WHERE c.country ='Singapore'
	AND c.ssn IN (
		SELECT cc1.ssn
		FROM credit_cards cc1, credit_cards cc2
		WHERE cc1.ssn = cc2.ssn
			AND cc1.type = 'visa' 
			AND cc2.type = 'jcb'
	)
;


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.ssn, COUNT(number) AS no_of_cards 
FROM credit_cards cc
GROUP BY cc.ssn 
UNION 
  ( SELECT c.ssn, 0 
    FROM customers c
    EXCEPT 
    SELECT cc.ssn, 0 
    FROM credit_cards cc
  );

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT ssn, cc.type, COUNT(number) AS no_of_cards 
FROM credit_cards cc 
GROUP BY ssn, cc.type 
UNION 
SELECT ssn, type, 0 
FROM 
  (SELECT c.ssn, ty.type 
    FROM customers c, 
      (SELECT DISTINCT type 
       FROM credit_cards
      )AS ty 
    EXCEPT 
    SELECT cc.ssn, cc.type 
    FROM credit_cards cc
  ) AS no_cards;



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT(c.ssn)
FROM customers c
WHERE EXISTS (
	SELECT cc.ssn
	FROM merchants m, transactions t, credit_cards cc
	WHERE t.number = cc.number
		AND m.code = t.code
		AND m.country <> c.country
		AND c.ssn = cc.ssn
	)
GROUP BY c.country;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
  tr.identifier
FROM 
  transactions tr
  LEFT JOIN credit_cards cc ON cc.number=tr.number
  INNER JOIN (
  				SELECT cc1.type, MAX(t.amount) AS max_amt
	  			FROM transactions t, credit_cards cc1
	  			WHERE t.number = cc1.number
	  			GROUP BY cc1.type) AS max_tab
	ON tr.amount = max_tab.max_amt AND cc.type=max_tab.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t1.identifier
FROM 
	transactions t1 
    LEFT JOIN credit_cards cc1 
		ON cc1.number=t1.number
	LEFT JOIN (
    		SELECT t2.amount, cc2.type 
    		FROM transactions t2, credit_cards cc2
			WHERE cc2.number=t2.number) AS tc2 
		ON cc1.type = tc2.type AND t1.amount < tc2.amount 
WHERE 
  tc2.amount IS NULL;


/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT code, name 
FROM merchants 
WHERE 
  code NOT IN (
    SELECT t.code 
    FROM transactions t 
      LEFT JOIN credit_cards cc USING(number) 
    WHERE 
      (cc.type LIKE 'visa%' OR cc.type LIKE 'diners-club%') 
      AND (t.amount >= 888)
  );