/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231957X                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.ssn,EXTRACT(day FROM T.datetime) AS DAY, EXTRACT(month FROM T.datetime) AS MONTH
FROM credit_cards cc, transactions t
WHERE cc.type='visa' 
AND cc.number=t.number
AND EXTRACT(day FROM T.datetime)=25
AND EXTRACT(month FROM T.datetime)=12
AND EXTRACT(year FROM T.datetime)=2017;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cu.first_name, cu.last_name,  cu.ssn
FROM customers cu, credit_cards cc
WHERE cu.ssn=cc.ssn
AND cc.type='JCB' OR cc.type='visa'
GROUP BY cu.ssn, cu.first_name, cu.last_name;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cu.ssn, count(cc.number)
FROM customers cu full outer join credit_cards cc on cu.ssn=cc.ssn
group by cu.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cu.country, count(cu.ssn)
from customers cu
where cu.ssn in(
select cu.ssn
from customers cu, credit_cards cc,transactions t,merchants m
where cu.ssn=cc.ssn
and cc.number=t.number
and t.code=m.code
and m.country<>cu.country)
group by cu.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select frm.maz,frm.tp
from (select max(t.amount) as maz,cc.type as tp
	  from credit_cards cc, transactions t
	  where cc.number=t.number
	  group by cc.type) as frm;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cc.type,t.identifier
from credit_cards cc, transactions t
where t.amount>=ALL(select t.amount
					from credit_cards cc, transactions t
					where cc.number=t.number 
					GROUP BY cc.type,t.amount) 
					and cc.number=t.number
					group by cc.type,t.identifier;
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select m.code,m.name
from merchants m
where m.code not in
(select m.code
from merchants m, transactions t,credit_cards cc
where t.code=m.code
and cc.number=t.number
and t.amount>=888
and cc.type='visa' or cc.type='diners-club');
