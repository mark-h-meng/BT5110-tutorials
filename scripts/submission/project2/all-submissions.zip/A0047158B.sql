/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0047158B                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT cc.ssn 
FROM credit_cards cc
WHERE cc.type = 'visa'
AND cc.number IN (
	SELECT DISTINCT t.number
	FROM transactions t
	WHERE t.datetime >= '2017-12-25'
	AND t.datetime < '2017-12-26');

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.first_name, c.last_name
FROM customers c
WHERE c.country = 'Singapore'
AND c.ssn IN (
	SELECT DISTINCT cc1.ssn
	FROM credit_cards cc1
	WHERE cc1.type = 'jcb')
AND c.ssn IN (
	SELECT DISTINCT cc2.ssn
	FROM credit_cards cc2
	WHERE cc2.type = 'visa');

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cc.ssn, COUNT(DISTINCT cc.number) AS count
FROM credit_cards cc
GROUP BY cc.ssn
UNION
SELECT DISTINCT c.ssn, 0 AS count
FROM customers c
WHERE c.ssn NOT IN (
	SELECT DISTINCT cc1.ssn
	FROM credit_cards cc1);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.ssn, a.type, CASE WHEN cc3.count IS NULL THEN 0 ELSE cc3.count END as count
FROM 
	(SELECT DISTINCT c.ssn, cc.type
	FROM customers c, (
		SELECT DISTINCT cc1.type
		FROM credit_cards cc1) AS cc) AS a
LEFT JOIN (
	SELECT cc2.ssn, cc2.type, COUNT(DISTINCT cc2.number) AS count
	FROM credit_cards cc2
	GROUP BY cc2.ssn, cc2.type) AS cc3
ON cc3.ssn = a.ssn 
AND cc3.type = a.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT  c.country, COUNT(DISTINCT c.ssn) AS count
FROM transactions t, merchants m, credit_cards cc, customers c
WHERE t.code = m.code
AND t.number = cc.number
AND cc.ssn = c.ssn
AND m.country <> c.country
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cc.type, t.identifier
FROM transactions t, credit_cards cc, (
	SELECT cc1.type, MAX(t1.amount) AS max
	FROM transactions t1, credit_cards cc1
	WHERE t1.number = cc1.number
	GROUP BY cc1.type) AS d
WHERE t.number = cc.number
AND cc.type = d.type
AND t.amount >= d.max;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cc.type, t.identifier
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND t.amount >= ALL (
	SELECT t1.amount
	FROM transactions t1, credit_cards cc1
	WHERE t1.number = cc1.number
	AND cc1.type = cc.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT m.code, m.name
FROM merchants m
WHERE m.code NOT IN (
	SELECT m1.code
	FROM merchants m1, transactions t, credit_cards cc
	WHERE m1.code = t.code
	AND cc.number = t.number
	AND (cc.type LIKE '%visa%' OR cc.type LIKE '%diners-club%')
	AND t.amount >= 888);




