/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231989M                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct(c.ssn)
from customers as c, credit_cards as cc, transactions as tx
where c.ssn = cc.ssn and tx.number = cc.number and cc.type = 'visa' and tx.datetime::timestamp::date = '2017-12-25';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
-- c.first_name, c.last_name

select temp.first_name, temp.last_name
from (select c.ssn,c.first_name, c.last_name
from customers as c, credit_cards as cc
where c.ssn = cc.ssn and cc.type = 'visa' and c.country = 'Singapore'
intersect
select c.ssn,c.first_name, c.last_name
from customers as c, credit_cards as cc
where c.ssn = cc.ssn and cc.type = 'jcb' and c.country = 'Singapore') as temp;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.ssn,count(cc.ssn)
from customers c 
left join credit_cards cc 
on c.ssn = cc.ssn
group by c.ssn;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.ssn,cc.type, (case when count(cc.type) isnull then 0 else count(cc.type) end) as count_cc_type
from credit_cards cc, customers c
where c.ssn = cc.ssn
group by c.ssn, cc.type
union
select c1.ssn,cc1.type,0
from customers c1, credit_cards cc1
where not exists(select c2.ssn,cc2.type, (case when count(cc2.type) isnull then 0 else count(cc2.type) end) as count_cc_type2
				from credit_cards cc2, customers c2
				where c2.ssn = cc2.ssn and c2.ssn = c1.ssn and cc1.ssn = cc2.ssn
				group by c2.ssn, cc2.type)
;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.country, count(distinct(c.ssn))
from customers as c, credit_cards as cc, transactions as tx, merchants as m
where c.ssn = cc.ssn and cc.number = tx.number and tx.code = m.code and c.country != m.country
group by c.country;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select temp2.identifier
from (select cc.type,max((case when tx.amount isnull then 0 else tx.amount end)) as max_tx
from credit_cards as cc, transactions as tx
where tx.number = cc.number 
group by cc.type) as temp
left join (select * from transactions as tx,credit_cards as cc where cc.number = tx.number) as temp2
on temp.max_tx = temp2.amount and temp.type = temp2.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */ 
select tx.identifier
from credit_cards cc, transactions tx
where( tx.number = cc.number and tx.amount >= ALL
	(select tx1.amount
	from transactions as tx1, credit_cards as cc1 
	where cc1.number = tx1.number and cc1.type = cc.type));

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select mm.code, mm.name
from merchants mm
where mm.code not in (select m.code
from merchants m, transactions tx, credit_cards cc
where tx.code = m.code and cc.number = tx.number and tx.amount >= 888.0 and (cc.type like 'visa%' or cc.type like 'diners-club%'));


