/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231904M                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn
FROM customers AS c, credit_cards AS card, transactions AS t
WHERE c.ssn = card.ssn AND card.number = t.number
AND card.type = 'visa' 
AND t.datetime BETWEEN '2017-12-25' AND '2017-12-26';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT temp.first_name, temp.last_name
FROM (SELECT c.ssn, c.first_name, c.last_name
	    FROM customers AS c, credit_cards AS cards
		WHERE c.ssn = cards.ssn
		AND c.country = 'Singapore'
		AND cards.type = ('visa')
		INTERSECT
		SELECT c.ssn, c.first_name, c.last_name
		FROM customers AS c, credit_cards AS cards
		WHERE c.ssn = cards.ssn
		AND c.country = 'Singapore'
		AND cards.type = ('jcb')) AS temp
ORDER BY temp.first_name;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, COUNT(cards.number)
FROM customers AS c
LEFT JOIN credit_cards AS cards ON c.ssn = cards.ssn
GROUP BY c.ssn
ORDER BY COUNT(cards.number);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT temp1.ssn, temp2.type, COUNT(cards.number)
FROM (SELECT DISTINCT c.ssn
	  FROM customers AS c) AS temp1
	  CROSS JOIN
	  (SELECT DISTINCT cards.type
	  FROM credit_cards AS cards) AS temp2
LEFT JOIN credit_cards AS cards 
ON temp1.ssn = cards.ssn AND temp2.type = cards.type
GROUP BY temp1.ssn, temp2.type
ORDER BY temp1.ssn, temp2.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT (DISTINCT c.ssn)
FROM customers AS c, credit_cards AS card, 
     merchants AS m, transactions AS t
WHERE c.ssn = card.ssn AND card.number = t.number AND
      t.code = m.code
AND c.country != m.country
GROUP BY c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM transactions AS t, credit_cards AS cards, 
     (SELECT cards.type, MAX(amount) AS max_amount
		FROM transactions AS t, credit_cards AS cards
		WHERE t.number = cards.number
		GROUP BY cards.type) AS temp
WHERE t.number = cards.number
AND   t.amount = max_amount 
AND   cards.type = temp.type;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM transactions AS t, credit_cards AS cards
WHERE t.number = cards.number
AND t.amount >= ALL(
		SELECT t2.amount
		FROM transactions AS t2, credit_cards AS cards2
		WHERE t2.number = cards2.number
		AND   cards.type = cards2.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m.code, m.name
FROM merchants AS m, transactions AS t, credit_cards AS cards
WHERE m.code = t.code AND t.number = cards.number
EXCEPT
SELECT m.code, m.name
FROM merchants AS m, transactions AS t, credit_cards AS cards
WHERE m.code = t.code AND t.number = cards.number
AND (cards.type LIKE '%visa%' OR cards.type LIKE '%diners-club%')
AND t.amount >= 888
ORDER BY code;