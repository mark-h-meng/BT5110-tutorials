/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231956Y
   Name: Gino Tiu 														*/

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT cc.ssn
FROM transactions t, credit_cards cc
WHERE cc.number = t.number
	and cc.type ='visa'
	and DATE(t.datetime)='2017-12-25';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.first_name,c.last_name,c.ssn
FROM customers c
WHERE c.ssn in(
	SELECT cc1.ssn
	FROM credit_cards cc1, credit_cards cc2
	WHERE c.ssn=cc1.ssn
	and c.ssn=cc2.ssn
	and cc1.ssn=cc2.ssn
	and c.country='Singapore'
	and (cc1.type='visa'and cc2.type='jcb'))
ORDER BY first_name, last_name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn,
	(CASE
	 	WHEN COUNT(cc.ssn) IS NULL THEN 0
	 	ELSE COUNT(cc.ssn)
	 END) as cc_count
FROM customers c
LEFT JOIN credit_cards cc
	ON c.ssn=cc.ssn
GROUP BY c.ssn, cc.ssn
ORDER BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn,cc.type,count(cc.type)
FROM customers c, credit_cards cc
WHERE c.ssn=cc.ssn
GROUP BY c.ssn,cc.type

UNION

SELECT c.ssn,cc.type,0
FROM customers c, credit_cards cc
WHERE (c.ssn,cc.type) NOT IN(
	SELECT c.ssn,cc.type
	FROM customers c, credit_cards cc
	WHERE c.ssn=cc.ssn
	GROUP BY c.ssn,cc.type
	ORDER BY c.ssn)
GROUP BY c.ssn,cc.type
ORDER BY ssn ASC, type ASC;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country, COUNT (DISTINCT c.ssn) 
FROM customers c, credit_cards cc, 
	merchants m, transactions t
WHERE c.ssn = cc.ssn 
	and cc.number = t.number 
	and t.code = m.code 
	and c.country != m.country
GROUP BY c.country
ORDER BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier
FROM transactions t, credit_cards cc
WHERE t.number=cc.number
	and (cc.type,t.amount) IN(
		SELECT cc.type,max(t.amount)
		FROM transactions t, credit_cards cc
		WHERE t.number=cc.number
		GROUP BY cc.type)
ORDER BY t.identifier ASC;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number=cc1.number
	and t1.amount >= ALL(
		SELECT t2.amount
		FROM transactions t2, credit_cards cc2
		WHERE t2.number=cc2.number
			and cc1.type=cc2.type)
ORDER BY t1.identifier;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m.code,m.name
FROM merchants m
WHERE (m.code,m.name) NOT IN(
	SELECT m.code, m.name
	FROM transactions t, credit_cards cc, merchants m
	WHERE t.number=cc.number
		and t.code=m.code
		and (cc.type LIKE '%visa%' or cc.type LIKE '%diners-club%')
		and t.amount>=888)
ORDER BY m.name,m.code;