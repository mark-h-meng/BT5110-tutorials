/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0124216U                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct cc.ssn
from transactions t, credit_cards cc
where t.number = cc.number
and cc.type='visa'
and t.datetime between '2017-12-25' and '2017-12-26';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select a.first_name, a.last_name 
from (
select distinct c.ssn, c.first_name, c.last_name
from credit_cards cc, customers c
where cc.ssn = c.ssn
and cc.type in ('jcb','visa') and c.country = 'Singapore')a;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.ssn,
sum(case when c.ssn=cc.ssn then 1 else 0 end) as "count"
from credit_cards cc, customers c
group by c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.ssn, cc.type,
sum(case when c.ssn=cc.ssn then 1 else 0 end) as "count"
from credit_cards cc, customers c
group by c.ssn, cc.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select m.country, count(c.ssn)
from merchants m, transactions t, credit_cards cc, customers c
where cc.number=t.number and m.code=t.code and c.ssn=cc.ssn
and m.country<>c.country
group by m.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select t2.identifier
from transactions t2, credit_cards cc2
where t2.number = cc2.number and
(cc2.type, t2.amount) in
(select cc.type, MAX(t.amount) as "amount"
from transactions t, credit_cards cc
where t.number=cc.number
group by cc.type);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select t.identifier
from transactions t, credit_cards cc
where t.number=cc.number
and t.amount >= ALL(
select t2.amount
from transactions t2, credit_cards cc2
where t2.number=cc2.number and cc.type=cc2.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select m.code, m.name
FROM transactions t, credit_cards cc, merchants m
WHERE t.number=cc.number and m.code=t.code
and (cc.type like '%visa%' or cc.type like '%diners-club%')
group by m.code, m.name
having max(t.amount)<888;