/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231930N                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT(c.ssn)
FROM customers c, credit_cards cc, transactions t
WHERE c.ssn = cc.ssn
AND t.number = cc.number
AND cc.type = 'visa'
AND DATE(t.datetime) = '2017-12-25';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT first_name,last_name
FROM customers AS x1
INNER JOIN credit_cards AS c1 ON x1.ssn = c1.ssn
WHERE c1.type = 'visa'
AND country = 'Singapore'
INTERSECT
SELECT DISTINCT first_name,last_name
FROM customers AS x2
INNER JOIN credit_cards AS c2 ON x2.ssn = c2.ssn
WHERE c2.type = 'jcb'
AND country = 'Singapore';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, count(cc.number) AS cards_owned
FROM customers c
LEFT JOIN credit_cards cc
ON c.ssn = cc.ssn
GROUP BY c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.type, c.ssn,
CASE
	WHEN COUNT(cc.type) > 0 THEN COUNT(cc.type)
	ELSE 0
END overall_count
FROM credit_cards cc, customers c
WHERE c.ssn = cc.ssn
GROUP BY c.first_name, c.last_name, cc.type, c.ssn
ORDER BY overall_count DESC;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT customers.country, COUNT (DISTINCT customers.ssn) FROM customers, credit_cards, merchants, transactions
WHERE customers.ssn = credit_cards.ssn AND credit_cards.number = transactions.number
AND transactions.code = merchants.code AND customers.country <> merchants.country
GROUP BY customers.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT identifier
FROM transactions t1
JOIN credit_cards cc1
ON t1.number = cc1.number
JOIN(
    SELECT type, MAX(amount) AS max_per_type
    FROM credit_cards cc2, transactions t2
    WHERE t2.number = cc2.number
    GROUP BY type
    ) AS max_cc_t ON t1.amount = max_cc_t.max_per_type
AND max_cc_t.type = cc1.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier,cc.type, t.amount
FROM credit_cards cc
LEFT JOIN transactions t on cc.number = t.number
WHERE (cc.type, t.amount) >= ALL (
SELECT cc1.type, t1.amount
FROM credit_cards cc1
LEFT JOIN transactions t1 on cc1.number = t1.number
WHERE cc.type = cc1.type)
ORDER BY t.amount DESC;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT merchants.code, merchants.name
FROM merchants, transactions, credit_cards
WHERE merchants.code = transactions.code AND transactions.number = credit_cards.number
EXCEPT
SELECT merchants.code, merchants.name
FROM merchants, transactions, credit_cards
WHERE merchants.code = transactions.code AND transactions.number = credit_cards.number
AND (credit_cards.type LIKE '%visa%' OR credit_cards.type LIKE '%diners-club%') AND transactions.amount >= 888
ORDER BY code;




