/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0232194J>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
	DISTINCT cc.ssn
FROM 
	credit_cards cc, transactions t
WHERE 
	t.number = cc.number
	AND (t.datetime BETWEEN '2017-12-25 00:00:00' AND '2017-12-25 23:59:59')
	AND cc.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
	r.first_name, r.last_name
FROM (
	SELECT 
		c.first_name, c.last_name, c.ssn
	FROM 
		customers c, credit_cards cc
	WHERE 
		c.ssn = cc.ssn
		AND c.country = 'Singapore'
		AND cc.type = 'jcb' 
	INTERSECT
	SELECT 
		c.first_name, c.last_name, c.ssn 
	FROM 
		customers c, credit_cards cc
	WHERE 
		c.ssn = cc.ssn
		AND c.country = 'Singapore'
		AND cc.type = 'visa'
) r;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
	c.ssn, 
	COALESCE(r.count, 0) AS count
FROM
	customers c
LEFT OUTER JOIN
(
	SELECT 
		ssn, COUNT(*) AS count 
	FROM 
		credit_cards
	GROUP BY ssn
) r
ON r.ssn = c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT
	a.ssn,
	a.type,
	coalesce(b.count, 0) AS count
FROM
(
	SELECT 
		c.ssn, cc.type
	FROM 
		customers c, credit_cards cc
	GROUP BY c.ssn, cc.type
) a
LEFT OUTER JOIN
(
	SELECT 
		ssn, type, COUNT(*) AS count 
	FROM 
		credit_cards
	GROUP BY ssn, type
) b
ON a.ssn = b.ssn AND a.type = b.type
ORDER BY a.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
	y.cus_country AS country, COUNT(*) AS count
FROM
(
	SELECT DISTINCT x.ssn, x.cus_country
	FROM
	(
		SELECT
			b.ssn, b.country AS cus_country, m.country AS mer_country
		FROM
		(
			SELECT
				t.number, t.code, a.ssn, a.country
			FROM 
				transactions t
			LEFT OUTER JOIN 
			(
				SELECT 
					cc.number, cc.ssn, c.country
				FROM 
					credit_cards cc
				LEFT OUTER JOIN
					customers c
				ON cc.ssn = c.ssn
			) a
			ON t.number = a.number
		) b
		LEFT OUTER JOIN
			merchants m
		ON b.code = m.code
	) x
	WHERE x.cus_country != x.mer_country
) y
GROUP BY y.cus_country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT
	b.identifier, a.type, a.max_amount
FROM
(
	SELECT
		MAX(x.amount) AS max_amount, x.type
	FROM
	(
		SELECT
			t.identifier, t.amount, cc.type
		FROM
			transactions t
		LEFT OUTER JOIN
			credit_cards cc
		ON t.number = cc.number
	) x
GROUP BY x.type
) a
LEFT OUTER JOIN
(
	SELECT
		t.identifier, t.amount, cc.type
	FROM
		transactions t
	LEFT OUTER JOIN
		credit_cards cc
	ON t.number = cc.number
) b
ON a.max_amount = b.amount AND a.type = b.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
	y.identifier, y.type, y.amount 
FROM 
(SELECT
		t1.identifier, t1.amount, cc1.type
	FROM
		transactions t1
	LEFT OUTER JOIN
		credit_cards cc1
	ON t1.number = cc1.number
) y
WHERE y.amount >= ALL (
	SELECT x.amount FROM
	(
		SELECT
			t.identifier, t.amount, cc.type
		FROM
			transactions t
		LEFT OUTER JOIN
			credit_cards cc
		ON t.number = cc.number
	) x
	WHERE x.type = y.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT
	a.code, m.name
FROM
(
	SELECT
		t.amount, t.code
	FROM
		transactions t
	LEFT OUTER JOIN
		credit_cards cc
	ON t.number = cc.number
	WHERE cc.type IN ('visa', 'diners-club')
) a
LEFT OUTER JOIN
merchants m
ON a.code = m.code
WHERE a.amount < 888;
