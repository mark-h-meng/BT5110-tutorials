/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232013A             */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT(d.ssn)
FROM credit_cards d, transactions t
WHERE d.number=t.number
AND EXTRACT(YEAR FROM t.datetime) =  '2017'
AND EXTRACT(MONTH FROM t.datetime) =  '12'
AND EXTRACT(DAY FROM t.datetime) =  '25'
AND d.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT ON(c.ssn) c.first_name, c.last_name
FROM customers c, credit_cards d, credit_cards d2
WHERE c.ssn=d.ssn AND c.ssn=d2.ssn
AND d.type='jcb' AND d2.type='visa' AND c.country='Singapore';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, COUNT(d.number)
FROM customers c LEFT OUTER JOIN credit_cards d ON c.ssn=d.ssn
GROUP BY c.ssn
ORDER BY c.ssn ASC;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cd.ssn, cd.type, COUNT(d2.type)
FROM (
     SELECT DISTINCT c.ssn, d.type 
     FROM customers c, credit_cards d ) AS cd 
     LEFT OUTER JOIN credit_cards d2 ON cd.ssn=d2.ssn 
     AND cd.type=d2.type
GROUP BY cd.ssn, cd.type
ORDER BY cd.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country, COUNT(c.ssn)
FROM merchants m, transactions t, credit_cards d, customers c
WHERE m.code=t.code AND d.number=t.number AND c.ssn=d.ssn
AND c.country <> m.country
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier
FROM transactions t, credit_cards d, (
          SELECT MAX(t2.amount) AS maxvalue, d2.type AS maxcard
          FROM transactions t2, credit_cards d2
          WHERE t2.number=d2.number
          GROUP BY d2.type ) AS a
WHERE t.number=d.number
AND a.maxvalue = t.amount AND a.maxcard=d.type
ORDER BY t.identifier ASC;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier
FROM transactions t, credit_cards d
WHERE t.number=d.number 
AND t.amount >= ALL (
	SELECT t2.amount
	FROM transactions t2, credit_cards d2
	WHERE t2.number=d2.number AND d.type=d2.type);


/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.code, m.name
FROM merchants m, transactions t, credit_cards d
WHERE m.code=t.code AND t.number=d.number
EXCEPT
SELECT t.code, m.name
FROM merchants m, transactions t, credit_cards d
WHERE m.code=t.code AND t.number=d.number
AND (d.type LIKE ('%visa%') OR d.type LIKE '%diners-club%')
GROUP BY t.code, m.name
HAVING MAX(t.amount) >= 888;

