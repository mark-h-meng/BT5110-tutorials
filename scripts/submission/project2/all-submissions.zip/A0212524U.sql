/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0212524U							                */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn 
FROM customers c, transactions t, credit_cards cc
WHERE c.ssn = cc.ssn
  AND cc.number = t.number
  AND date(t.datetime) = '2017-12-25'
  AND cc.type = 'visa';
-- return 26 rows of ssn
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.first_name, c.last_name
FROM customers c
INNER JOIN credit_cards cc1
ON cc1.ssn = c.ssn
INNER JOIN credit_cards cc2
ON cc2.ssn = c.ssn
WHERE cc1.type = 'visa'
  AND cc2.type = 'jcb'
  AND c.country = 'Singapore'
GROUP BY c.ssn;

-- return 21 rows
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, count(cc.ssn) AS number_owned
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
GROUP BY c.ssn
UNION
(SELECT c.ssn, 0 AS number_owned
FROM customers c
EXCEPT
SELECT distinct cc.ssn, 0 AS number_owned
FROM credit_cards cc)
ORDER BY number_owned ASC;
-- return 1301 rows
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/*method 2: cross join dictionary left join customers and types which numbers are not 0*/
SELECT t2.ssn, t2.type, COALESCE(t3.number_type, 0) AS number_type FROM (
	(SELECT c.ssn, t1.type 
		FROM customers c
		CROSS JOIN (
			SELECT type 
			FROM credit_cards
			GROUP BY type
			) t1) t2
	LEFT JOIN (
		SELECT c2.ssn, cc.type, count(cc.type) AS number_type
		FROM customers c2
		INNER JOIN credit_cards cc
		ON c2.ssn = cc.ssn
		GROUP BY c2.ssn, cc.type
		) t3
	ON t2.ssn = t3.ssn
	AND t2.type = t3.type
  )
ORDER BY t2.ssn, t2.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, count(distinct c.ssn)
FROM customers c
RIGHT JOIN credit_cards cc
ON c.ssn = cc.ssn
RIGHT JOIN transactions t
ON t.number = cc.number
INNER JOIN merchants m
ON m.code = t.code
WHERE c.country != m.country
GROUP BY c.country;
----- Return -------
-- "Indonesia"	850
-- "Malaysia"	41
-- "Singapore"	300
-- "Thailand"	109
--------------------
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT B.identifier, A.type, A.max_amount
FROM
(SELECT cc.type, MAX(t.amount) as max_amount
FROM transactions t
INNER JOIN credit_cards cc
ON cc.number = t.number
GROUP BY  cc.type) A
LEFT JOIN
(SELECT t.identifier, t.amount, cc.type
FROM transactions t
INNER JOIN credit_cards cc
ON cc.number = t.number) B
ON
A.max_amount = B.amount
WHERE
A.type = B.type
ORDER BY identifier;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier,cc.type, t.amount
FROM transactions t
INNER JOIN credit_cards cc
ON cc.number = t.number
WHERE t.amount >= ALL(
	SELECT t2.amount
	FROM transactions t2
	INNER JOIN credit_cards cc2
	ON cc2.number = t2.number
	WHERE cc2.type = cc.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT code, name FROM merchants

EXCEPT

SELECT DISTINCT m.code, m.name
FROM merchants m
INNER JOIN transactions t
ON m.code = t.code
INNER JOIN credit_cards cc
ON cc.number = t.number
WHERE t.amount >= 888
  AND (cc.type like '%visa%' OR cc.type like '%diners-club%');