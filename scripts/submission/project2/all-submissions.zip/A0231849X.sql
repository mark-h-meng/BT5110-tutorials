/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231849X>                                         */
/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.ssn from customers c,credit_cards cd, transactions t
where c.ssn=cd.ssn and t.number=cd.number 
and cd.type='visa'
and date(t.datetime) ='2017-12-25';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.first_name,c.last_name from customers c ,credit_cards cd
where c.ssn=cd.ssn and cd.type='jcb'
intersect
select c.first_name,c.last_name from customers c ,credit_cards cd
where c.ssn=cd.ssn and cd.type='visa';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.ssn ,count(cd.number) as number_of_credit_cards_owned
from customers c left outer join credit_cards cd on c.ssn=cd.ssn
group by c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.ssn,cd.type,count(cd.number) as number_of_credit_cards_owned
from customers c left outer join credit_cards cd on c.ssn=cd.ssn
group by c.ssn,cd.type
order by c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.country,count(distinct c.ssn) from customers c,credit_cards cd,merchants m, transactions t
where c.ssn=cd.ssn and t.number=cd.number and t.code=m.code
and c.country<>m.country
group by c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t.identifier,cd.type from transactions t, credit_cards cd
where t.number=cd.number
and t.amount = all(select max(t2.amount) from transactions t2,credit_cards cd2
					where t2.number=cd2.number
				   and cd2.type=cd.type
					group by cd2.type);
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select cd.type,t.identifier from transactions t,credit_cards cd
where t.number=cd.number
and t.amount>= all(select t2.amount from transactions t2,credit_cards cd2
				   where cd.type=cd2.type
				   and t2.number=cd2.number);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select m.code,m.name
from transactions  t,credit_cards cd, merchants m
where t.number=cd.number and t.code=m.code
and (cd.type='visa' or cd.type='diners-club')
group by m.code,m.name
having max(t.amount)<888;