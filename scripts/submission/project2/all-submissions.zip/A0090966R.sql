/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0090966R>                  */
--Wu Bowei
/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn
FROM transactions t,
	credit_cards cc
WHERE cc.number = t.number
	AND cc.type = 'visa'
	AND t.datetime BETWEEN '2017-12-25 00:00:00' AND '2017-12-26 00:00:00';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT x.first_name,
	x.last_name
FROM
	(SELECT DISTINCT c.ssn,
			c.first_name,
			c.last_name
		FROM customers c,
			credit_cards cc1,
			credit_cards cc2
		WHERE c.ssn = cc1.ssn
		    AND c.ssn = cc2.ssn
			AND cc1.type = 'visa'
			AND cc2.type = 'jcb'
			AND c.country = 'Singapore') x;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT x.ssn,
	CASE
		WHEN x.cc_own IS NOT NULL THEN x.cc_own
		ELSE 0
	END AS number_of_cc_own
FROM
	(SELECT DISTINCT c.ssn,
			COUNT(DISTINCT cc.number) AS cc_own
		FROM customers c
		LEFT OUTER JOIN credit_cards cc ON c.ssn = cc.ssn
		GROUP BY c.ssn) x;

---- Alternatively
-- SELECT DISTINCT c.ssn,
-- 			CASE WHEN COUNT(DISTINCT cc.number) IS NOT NULL THEN COUNT(DISTINCT cc.number)
-- 			ESLE 0 END AS cc_own
-- 		FROM customers c
-- 		LEFT OUTER JOIN credit_cards cc ON c.ssn = cc.ssn
-- 		GROUP BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT y.ssn,
	y.type,
	CASE
		WHEN COUNT(number) IS NOT NULL THEN COUNT(number)
		ELSE 0
	END AS number_of_cc_own
FROM
	(SELECT x.*,
			cc2.number
		FROM
			(SELECT c.ssn,
					cc.type
				FROM
					(SELECT DISTINCT ssn
						FROM customers) c
				CROSS JOIN
					(SELECT DISTINCT type
						FROM credit_cards) cc) x
		LEFT JOIN
			(SELECT *
				FROM credit_cards) cc2 ON x.ssn = cc2.ssn
		AND x.type = cc2.type) y
GROUP BY 1,2
ORDER BY 1,2;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country,
	COUNT(DISTINCT c.ssn)
FROM
	(SELECT ssn,
			country
		FROM customers) c
INNER JOIN
	(SELECT number, ssn
		FROM credit_cards) cc ON c.ssn = cc.ssn
INNER JOIN
	(SELECT DISTINCT number, code
		FROM transactions) T ON cc.number = t.number
INNER JOIN
	(SELECT code,
			country
		FROM merchants) m ON t.code = m.code
WHERE c.country <> m.country
GROUP BY 1;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t2.identifier
FROM
	(SELECT identifier,
			amount, 
			number
		FROM transactions) t2
INNER JOIN
	(SELECT type, 
			number
		FROM credit_cards) cc2 ON t2.number = cc2.number 
WHERE (cc2.type,
	   t2.amount) in
		(SELECT cc1.type,
				MAX(t1.amount)
			FROM
				(SELECT type, 
						number
					FROM credit_cards) cc1
			INNER JOIN
				(SELECT identifier, 
						number, 
						amount
					FROM transactions) t1 ON cc1.number = t1.number
			GROUP BY 1);

---- Alternatively
-- SELECT t2.identifier
-- FROM transactions t2,
-- 	credit_cards cc2
-- WHERE t2.number = cc2.number
-- 	AND (cc2.type,
-- 		 t2.amount) IN
-- 		(SELECT cc1.type,
-- 				MAX(t1.amount)
-- 			FROM credit_cards cc1,
-- 				transactions t1
-- 			WHERE cc1.number = t1.number
-- 			GROUP BY cc1.type);


/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t2.identifier
FROM transactions t2,
	credit_cards cc2
WHERE t2.number = cc2.number
	AND t2.amount >= ALL
		(SELECT t1.amount
			FROM credit_cards cc1,
 				 transactions t1
			WHERE cc1.number = t1.number
				AND cc1.type = cc2.type);

---- Alternatively
-- SELECT x.identifier
-- FROM
-- 	(SELECT cc.type,
-- 			t.identifier,
-- 			t.amount,
-- 			ROW_NUMBER() OVER (PARTITION BY cc.type ORDER BY t.amount DESC) AS seq
-- 		FROM
-- 			(SELECT type, number
-- 				FROM credit_cards) cc
-- 		LEFT JOIN
-- 			(SELECT identifier, number, amount
-- 				FROM transactions) t ON cc.number = t.number) x
-- WHERE x.seq = 1
-- ORDER BY 1;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT code,
	name
FROM merchants m
WHERE m.code not in
		(SELECT DISTINCT code
			FROM transactions
			WHERE amount >= '888'
				AND number in
					(SELECT DISTINCT number
						FROM credit_cards
						WHERE type like ANY (array['%visa%', '%diners-club%'])));


