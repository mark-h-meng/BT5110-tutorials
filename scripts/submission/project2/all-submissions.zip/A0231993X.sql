/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231993X                 */


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn
FROM credit_cards c, transactions t
WHERE c.type = 'visa' AND t.number = c.number AND DATE(datetime) = '2017-12-25';

/* can check that it is correct by using 
 SELECT c.ssn, t.number, c.number, c.type, DATE(t.datetime) */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cust.first_name, cust.last_name
FROM customers cust, credit_cards c
WHERE cust.country = 'Singapore' AND c.ssn = cust.ssn  AND (c.type = 'visa' or c.type ='jcb')
group by cust.first_name, cust.last_name, cust.ssn --apparently i can use group by c.ssn even though i do not output select it
order by cust.first_name, cust.last_name;		   -- as long as group by also includes the select (a,b,...) then its okay
-- we need cust.ssn to uniquely identify the customer


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cust.ssn, COUNT(c.ssn)
FROM customers cust, credit_cards c
WHERE cust.ssn = c.ssn
GROUP BY cust.ssn
UNION
SELECT cust.ssn, COUNT(cust.ssn)-1 
FROM customers cust
WHERE cust.ssn NOT IN (SELECT c.ssn FROM credit_cards c)
GROUP BY cust.ssn
ORDER BY COUNT;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select cust.ssn, c.type, count(*) as count
from customers as cust, credit_cards as c
where cust.ssn = c.ssn 
group by cust.ssn, c.type  --the top half finds the card they have
union
select distinct (tempA.ssn), tempA.type, 0 as count
from (select cust.ssn, subquery.type, count(*) 
	from customers cust, credit_cards c, (select distinct c.type from credit_cards as c) as subquery
	where cust.ssn = c.ssn and c.type <> subquery.type
	group by cust.ssn, subquery.type
	order by cust.ssn
) as tempA --temp A finds all possible card type for each ssn (16 each)
	left JOIN  --left join compares tempA and the top half and discard those that the top half has
		(select cust.ssn, c.type
			from customers as cust, credit_cards as c
			where cust.ssn = c.ssn 
			group by cust.ssn, c.type
			order by cust.ssn) as temporaryB
	on tempA.ssn = temporaryB.ssn and (tempA.type = temporaryB.type  )
where temporaryB.ssn IS NULL --NULL condition on the right table tells us the card type that each ssn dont have
order by ssn;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select aact.cust_country, sum(aact.count) as number_of_overseas_purchase
from (SELECT m.country as m_country, cust.country as cust_country, COUNT(*)
from transactions t, merchants m, customers cust, credit_cards c
where t.code = m.code AND t.number = c.number AND c.ssn = cust.ssn AND m.country = cust.country
GROUP BY m.country, cust.country) as sct --sct means same country transactions 
left join (SELECT m.country as m_country, cust.country as cust_country, COUNT(*)
from transactions t, merchants m, customers cust, credit_cards c
where t.code = m.code AND t.number = c.number AND c.ssn = cust.ssn 
GROUP BY m.country, cust.country) as aact --aact means all-to-all country transactions
on sct.m_country = aact.m_country and sct.cust_country <> aact.cust_country
group by aact.cust_country; 

--please ignore the comments below. they are for my own working and understanding

/*
SELECT m.country, COUNT(*)
from transactions t, merchants m
where t.code = m.code 
GROUP BY m.country; /* number of transactions that happened group by merchants country */
*/

/*
SELECT m.country, cust.country, COUNT(*)
from transactions t, merchants m, customers cust, credit_cards c
where t.code = m.code AND t.number = c.number AND c.ssn = cust.ssn AND m.country = cust.country
GROUP BY m.country, cust.country; */
/* this is the number of same countries transactions*/ 


/* this solution is my working but because i use INTO, i just rewrite again without 

SELECT m.country, cust.country, COUNT(*)
from transactions t, merchants m, customers cust, credit_cards c
where t.code = m.code AND t.number = c.number AND c.ssn = cust.ssn 
GROUP BY m.country, cust.country
-- this is all to all country number of transactions

SELECT m.country as m_country, cust.country as cust_country, COUNT(*)
into sct
from transactions t, merchants m, customers cust, credit_cards c
where t.code = m.code AND t.number = c.number AND c.ssn = cust.ssn AND m.country = cust.country
GROUP BY m.country, cust.country;
/* this is the number of same countries transactions*/ 

SELECT m.country as m_country, cust.country as cust_country, COUNT(*)
into aact
from transactions t, merchants m, customers cust, credit_cards c
where t.code = m.code AND t.number = c.number AND c.ssn = cust.ssn 
GROUP BY m.country, cust.country;
-- this is all to all country number of transactions

select * from sct;

select * from aact;

select aact.cust_country, sum(aact.count)
from sct 
left join aact
on sct.m_country = aact.m_country and sct.cust_country <> aact.cust_country
group by aact.cust_country

-- this block of code is basically what i want, the correct answer
*/


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select t.identifier, t.amount --make sure dont print type. identity and amount only
from transactions as t, credit_cards as c
where c.number = t.number and (c.type, t.amount)  in (SELECT c.type, max(t.amount) --here we can use composite (A,B) to check the in condition
FROM transactions t, credit_cards c
WHERE t.number = c.number 
GROUP BY c.type ) 
order by t.identifier;
--order by c.type;

--ignore comments below. just some outputs to check my own answer
/*SELECT *
FROM transactions t, credit_cards c
WHERE t.number = c.number and c.type = 'visa-electron'  and t.amount = '1000.34'
--GROUP BY c.type */

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

-- try with all (nested query)
select t.identifier, t.amount
from transactions as t, credit_cards as c
where c.number = t.number and t.amount >= ALL(
	SELECT t1.amount 
	from transactions as t1, credit_cards as c1
	where t1.number = c1.number and c.type =c1.type)
order by t.identifier;

--the learning point here is that as long as the inside c1.type matches to the outside c.type
--further, naming c and c1 will allow us more flexiblity to compare inside and outside


/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

-- transactions, merchants, credit_cards
-- transactions number to credit_cards number to type
-- transactions code to merchant code
-- for each card type (visa-like; diners-like), find those that dont have >= 888 dollars amount in transactions

select m.code, m.name
from merchants as m
inner join				 -- inner join to find the matching merchant names after taken out those visa-like and diners-like t amount >= 888 merchants
(select distinct m.name  --all possible merchant names
from merchants as m
except                   -- take out merchant names of those with visa-like or diners-like transaction amount >= 888
select distinct right_table.name
from
(select m.code, m.name, c.type, t.amount --t.amount, t.number, c.number, t.code, m.code, c.type 
from transactions as t, merchants as m, credit_cards as c
where t.amount >= 888 and t.number = c.number and t.code = m.code and ( c.type like 'visa%' or c.type like 'diners-club%')
group by t.amount, t.number, c.number, t.code, m.code, c.type
order by m.name ) as right_table --merchants that have had more than visa-like or diners-like transaction amt >= 888
) as innerjoin
on m.name = innerjoin.name
order by innerjoin.name;

