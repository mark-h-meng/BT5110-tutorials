/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231996R       ZHANG JIAJING                       */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.ssn 
from customers c, transactions t, credit_cards cc
where c.ssn = cc.ssn
and t.number = cc.number
and cc.type = 'visa'
and t.datetime between '2017-12-25' and '2017-12-26'
order by c.ssn asc;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.first_name, c.last_name
from customers c, credit_cards cc, credit_cards ccc
where cc.type = 'visa' 
and ccc.type ='jcb'
and c.country = 'Singapore'
and c.ssn=cc.ssn
and c.ssn=ccc.ssn
group by c.ssn, c.first_name, c.last_name

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.ssn, count(cc.ssn)
from customers c left outer join credit_cards cc on c.ssn=cc.ssn
group by c.ssn
order by c.ssn asc 


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select res2.ssn, res2.type, CASE WHEN count IS NULL THEN 0 ELSE count END
from 
(select ssn, type
from customers
cross join (select distinct type from credit_cards) res) res2
left join
(select c.ssn, cc.type, count(cc.number)
from customers c left outer join credit_cards cc on c.ssn=cc.ssn
group by c.ssn, cc.type) res3
on res2.ssn = res3.ssn and res2.type = res3.type

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.country, count (distinct c.ssn)
from transactions t, merchants m, credit_cards cc, customers c
where t.code = m.code
and t.number = cc.number
and cc.ssn = c.ssn
and m.country <> c.country
group by c.country

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select t.identifier, t.amount
from transactions t, credit_cards cc
where t.number=cc.number
and cc.type || t.amount in (select ccc.type || max(tt.amount) 
    from transactions tt, credit_cards ccc
    where tt.number = ccc.number 
    group by ccc.type)

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select t.identifier, t.amount
from transactions t, credit_cards cc
where t.number=cc.number
and t.amount >= all(
select tt.amount
from transactions tt, credit_cards ccc
where tt.number=ccc.number
and cc.type = ccc.type)

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select m.code, m.name
from merchants m, transactions t, credit_cards cc
where m.code =t.code 
and t.number = cc.number
and cc.type like '%visa%'
group by m.code, m.name
having max(t.amount)<888
intersect
select m.code, m.name
from merchants m, transactions t, credit_cards cc
where m.code =t.code 
and t.number = cc.number
and cc.type like '%diners-club%'
group by m.code, m.name
having max(t.amount)<888
