/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231994W>  Kang Yifan                */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.ssn FROM customers c, credit_cards d, transactions t
WHERE d.type='visa' 
AND c.ssn = d.ssn
AND d.number = t.number
AND t.datetime between '2017-12-25' and '2017-12-26';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.first_name, c.last_name
FROM customers c, credit_cards d
WHERE c.ssn = d.ssn AND (c.first_name, c.last_name) IN(
SELECT c.first_name,c.last_name FROM customers c, credit_cards d
WHERE c.ssn = d.ssn AND d.type = 'jcb')
AND d.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, COUNT(d.number) as A
FROM customers c LEFT OUTER JOIN credit_cards d ON c.ssn = d.ssn
GROUP BY (c.ssn)
Order by A;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn,d.type,COUNT(d.number)
FROM customers c LEFT OUTER JOIN credit_cards d ON c.ssn = d.ssn
GROUP BY (c.ssn,d.type)
UNION
SELECT c.ssn,d.type,0
FROM customers c LEFT OUTER JOIN credit_cards d ON c.ssn = d.ssn
GROUP BY (c.ssn,d.type);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country,COUNT(DISTINCT c.ssn)
FROM transactions t 
LEFT OUTER JOIN credit_cards d ON t.number = d.number
LEFT OUTER JOIN merchants m ON m.code = t.code
LEFT OUTER JOIN customers c on c.ssn = d.ssn
WHERE c.country <> m.country
GROUP BY(c.country);

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* 下面这个，第二个没出来identifier，第一个有一个重复没去掉 */
SELECT t.identifier,t.amount
FROM transactions t
WHERE t.amount = ANY(
	SELECT MAX(t.amount)
FROM transactions t LEFT OUTER JOIN credit_cards d ON t.number = d.number
GROUP BY(d.type)
);


SELECT d.type, MAX(t.amount),count(t.identifier)
FROM transactions t LEFT OUTER JOIN credit_cards d ON t.number = d.number
GROUP BY(d.type);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier,t.amount
FROM transactions t, credit_cards d
WHERE 
t.number = d.number AND
t.amount >= ALL(
	SELECT t.amount
FROM transactions t LEFT OUTER JOIN credit_cards d2 ON t.number = d2.number
WHERE d.type = d2.type
);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m.code, m.name
FROM transactions t
LEFT OUTER JOIN credit_cards d ON t.number = d.number
LEFT OUTER JOIN merchants m ON t.code = m.code
WHERE d.type = 'visa' OR d.type = 'diners-club'
GROUP BY (m.code)
HAVING MAX(t.amount) < 888;

