/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231973B */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/

SELECT DISTINCT c.ssn 
FROM customers c, credit_cards cc, transactions t
WHERE c.ssn = cc.ssn
AND cc.number = t.number
AND t.datetime::date = '2017-12-25'
AND cc.type = 'visa';
/* Outputs 26 rows */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/

SELECT c.first_name, c.last_name
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn 
AND c.country ='Singapore'
AND cc.type = 'jcb'
INTERSECT 
SELECT c.first_name, c.last_name
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
AND c.country ='Singapore'
AND cc.type = 'visa';
/* Outputs 20 rows */


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/

SELECT c.ssn, COUNT(cc.number) AS nb_cc
FROM customers c LEFT JOIN credit_cards cc ON c.ssn = cc.ssn 
GROUP BY c.ssn;
/* Outputs 1301 rows */

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/

SELECT cust_cc.ssn, cust_cc.type, COUNT(cc.number)
FROM (SELECT DISTINCT c.ssn, cc.type 
	  FROM customers c, credit_cards cc) AS cust_cc
LEFT JOIN credit_cards cc ON cust_cc.ssn = cc.ssn AND cust_cc.type = cc.type
GROUP BY cust_cc.ssn, cust_cc.type;
/* Outputs 20816 rows */


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/

SELECT c.country AS customer_country, COUNT(*) AS nb_customers_buying_abroad
FROM customers c, credit_cards cc, transactions t, merchants m
WHERE c.ssn = cc.ssn
AND cc.number = t.number
AND t.code = m.code
AND c.country <> m.country
GROUP BY c.country;
/* Outputs 4 rows */

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/

SELECT t.identifier, cc.type
FROM transactions t LEFT JOIN credit_cards cc ON t.number = cc.number
WHERE (cc.type, t.amount) = ANY (
	SELECT cc.type, MAX(t.amount)
	FROM transactions t LEFT JOIN credit_cards cc ON t.number = cc.number
	GROUP BY cc.type);
/* Outputs 16 rows */

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/

SELECT table1.identifier, table1.type
FROM (transactions t1 LEFT JOIN credit_cards cc1 ON t1.number = cc1.number) AS table1
WHERE NOT EXISTS (SELECT (table2.type, table2.amount) 
				  FROM (transactions t2 LEFT JOIN credit_cards cc2 ON t2.number = cc2.number) AS table2
				  WHERE table1.type = table2.type
				  AND table1.amount < table2.amount);
/* Outputs 16 rows */

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
	   
SELECT m.code, m.name, cc.type, t.amount
FROM credit_cards cc, transactions t, merchants m
WHERE cc.number = t.number
AND m.code = t.code
AND NOT( (cc.type = 'visa' OR cc.type ='diners-club') 
		 AND t.amount >=888);
/* Outputs 30109 rows*/

