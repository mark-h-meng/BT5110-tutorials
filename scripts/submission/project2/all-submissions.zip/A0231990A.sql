/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231990A											*/

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT cc.ssn
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND cc.type = 'visa'
AND t.datetime >= '2017-12-25'
AND t.datetime < '2017-12-26';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT
	cu.first_name,
	cu.last_name
FROM customers cu, credit_cards cc
WHERE cu.ssn = cc.ssn
AND cu.country = 'Singapore'
AND cc.type = 'jcb'
AND EXISTS (
	SELECT
		cu1.ssn
	FROM customers cu1, credit_cards cc1
	WHERE cu1.ssn = cc1.ssn
	AND cc1.type = 'visa'
	AND cu.ssn = cu1.ssn)
GROUP BY cu.ssn, cu.first_name, cu.last_name
ORDER BY cu.first_name, cu.last_name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
	cu.ssn, 
	(CASE WHEN cc.ssn ISNULL THEN 0 ELSE COUNT(*) END) as cc_count
FROM customers cu LEFT OUTER JOIN credit_cards cc
ON cu.ssn = cc.ssn
GROUP BY cu.ssn, cc.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
	cct.ssn, 
	cct.type, 
	(CASE WHEN cc.ssn ISNULL THEN 0 ELSE COUNT(*) END) as cc_count 
FROM 
  	(SELECT 
   		cu1.ssn, 
		cc1.type 
	 FROM customers cu1, 
	 	(SELECT DISTINCT type 
         FROM credit_cards) cc1) cct 
	 LEFT OUTER JOIN credit_cards cc ON (cct.ssn = cc.ssn AND cct.type = cc.type) 
GROUP BY cct.ssn, cct.type, cc.ssn
ORDER BY cct.ssn, cct.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT
	cu1.country,
	count(*) as n_customers
FROM
	(SELECT
		cu.country,
		cu.ssn
	 FROM customers cu, credit_cards cc, transactions t, merchants m
	 WHERE cu.ssn = cc.ssn
	 AND cc.number = t.number
	 AND t.code = m.code
	 AND cu.country <> m.country
	 GROUP BY cu.country, cu.ssn) cu1
GROUP BY cu1.country
ORDER BY cu1.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier
FROM 
	credit_cards cc, 
	transactions t,
	(SELECT 
	 	cc1.type, 
	 	MAX(t1.amount) as amount
	 FROM credit_cards cc1, transactions t1
	 WHERE cc1.number = t1.number
	 GROUP BY cc1.type) tmx
WHERE cc.number = t.number
AND cc.type = tmx.type
AND t.amount = tmx.amount;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* Takes about 10 seconds to run on my system */

SELECT t.identifier
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND t.amount >= ALL (
	SELECT t1.amount
	FROM credit_cards cc1, transactions t1
	WHERE cc1.number = t1.number
	AND cc.type = cc1.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT t.code, m.name
FROM transactions t, merchants m
WHERE t.code = m.code
AND NOT EXISTS (
	SELECT t1.code
	FROM credit_cards cc1, transactions t1
	WHERE cc1.number = t1.number
	AND (cc1.type like 'visa%' OR cc1.type like 'diners-club%')
	AND t1.amount >= 888
	AND t.code = t1.code);
