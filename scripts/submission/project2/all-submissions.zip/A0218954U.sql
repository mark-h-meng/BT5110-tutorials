/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218954U                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT cc.ssn
FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type='visa' AND DATE(t.datetime) = '2017-12-25';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.first_name, c.last_name
FROM customers c, credit_cards cc, credit_cards cc1
WHERE c.ssn=cc.ssn 
AND c.ssn=cc1.ssn 
AND c.country='Singapore' 
AND cc.type='visa' 
AND cc1.type='jcb' 
GROUP BY c.ssn ;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, COUNT(cc.number) 
FROM customers c LEFT OUTER JOIN credit_cards cc
ON c.ssn=cc.ssn
GROUP BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.ssn, a.type, COALESCE(sum(b.cards_held), 0)
FROM
	(SELECT distinct c.ssn, cc.type
	FROM customers c,credit_cards cc ) AS a
LEFT OUTER JOIN
	(SELECT cc1.ssn, cc1.type, COUNT(cc1.number) as cards_held
	FROM credit_cards cc1
	GROUP BY cc1.ssn, cc1.type) AS b
ON a.ssn = b.ssn AND a.type = b.type
GROUP BY a.ssn, a.type
ORDER BY a.ssn, a.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country, COUNT(DISTINCT c.ssn) 
FROM customers c , credit_cards cc, transactions t, merchants m
WHERE c.ssn = cc.ssn AND cc.number = t.number AND t.code = m.code AND c.country <> m.country
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier 
FROM transactions t , credit_cards cc
WHERE t.number=cc.number AND (cc.type,t.amount)
IN (SELECT DISTINCT cc1.type, MAX(t1.amount)
	FROM credit_cards cc1, transactions t1
	WHERE cc1.number=t1.number
	GROUP BY cc1.type);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier 
FROM transactions t , credit_cards cc
WHERE t.number=cc.number AND t.amount >= ALL(
	SELECT t1.amount
	FROM credit_cards cc1, transactions t1
	WHERE cc1.number=t1.number AND cc1.type=cc.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT  m.code,m.name
FROM merchants m 
WHERE m.code NOT IN 
(SELECT t.code 
 FROM transactions t, credit_cards cc
 WHERE t.number=cc.number AND t.amount >=888 
 AND (cc.type LIKE 'visa%' OR cc.type LIKE 'diners-club%'));