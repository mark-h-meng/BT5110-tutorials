/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218855U	                                        */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT card.ssn

FROM customers c, credit_cards card, transactions t
	
WHERE c.ssn = card.ssn
  AND card.number = t.number
  AND t.datetime BETWEEN '2017-12-25 00:00:00' AND '2017-12-25 23:59:59'
  AND card.type = 'visa'
  
ORDER BY card.ssn;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.first_name, c.last_name

FROM customers c LEFT JOIN credit_cards card on c.ssn = card.ssn

WHERE c.country = 'Singapore' 
  AND card.type IN ('jcb','visa')

GROUP BY c.ssn

HAVING COUNT(DISTINCT card.type) = 2;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, COALESCE(count(type), 0) AS no_of_cards

FROM customers c LEFT JOIN credit_cards card on c.ssn = card.ssn

GROUP BY c.ssn

ORDER BY no_of_cards;



/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, card.type, COALESCE(COUNT(NUMBER),0) AS no_of_cards

FROM customers c LEFT JOIN credit_cards card ON c.ssn = card.ssn

GROUP BY c.ssn, card.type

ORDER BY c.ssn;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT  c.country, count (distinct c.ssn)

FROM customers c, credit_cards card, transactions t, merchants m

WHERE c.ssn = card.ssn
  AND card.number = t.number
  AND t.code = m.code 
  AND c.country <> m.country

GROUP BY c.country

ORDER BY count DESC;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* Add card type and max amount to clear cross check with Q1.g */

SELECT t.identifier, card.type, t.amount 

FROM    

	(SELECT card1.type card_type, max(t1.amount) AS max_amount
	
	FROM transactions t1 JOIN credit_cards card1 ON card1.number = t1.number
	
	GROUP BY card1.type) AS t1,
	
	transactions t,
	credit_cards card

WHERE t.number = card.number
  AND card.type = t1.card_type
  AND t.amount = t1.max_amount;



/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT  t.identifier, card.type, t.amount

FROM transactions t, credit_cards card

WHERE t.number = card.number
  AND t.amount >= ALL(
		
  SELECT t1.amount
		
  FROM transactions t1, credit_cards card1
		
  WHERE t1.number = card1.number
    AND card.type = card1.type);



/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m.code, m.name

FROM merchants m

WHERE (m.code, m.name) NOT IN(
  SELECT m1.code, m1.name
	
  FROM merchants m1, transactions t1, credit_cards card
	
  WHERE m1.code = t1.code
    AND t1.number = card.number
    AND t1.amount >= 888
    AND (card.type LIKE 'visa%' OR card.type LIKE 'diners-club%'));



