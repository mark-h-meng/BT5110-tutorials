/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231971E>                                         */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cr.ssn
FROM credit_cards cr, transactions t
WHERE cr.number = t.number
AND (t.datetime BETWEEN '2017-12-25 00:00:00.000000' AND '2017-12-25 23:59:59.999999')
AND cr.type = 'visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cu.first_name, cu.last_name
FROM  customers cu
WHERE cu.country = 'Singapore'
AND cu.ssn IN (
	SELECT DISTINCT ssn
	FROM credit_cards cr
	WHERE cr.type = 'jcb'
	INTERSECT	
	SELECT DISTINCT ssn
	FROM credit_cards cr
	WHERE cr.type = 'visa');
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT q1c.ssn, count(q1c.number)
FROM (SELECT cu.ssn, cr.number
	  FROM customers cu LEFT OUTER JOIN credit_cards cr ON cu.ssn = cr.ssn
	  GROUP BY cu.ssn, cr.number
	  ORDER BY cu.ssn, cr.number) AS q1c
GROUP BY q1c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT q1d.ssn, q1d.type, count(q1d.number)
FROM (SELECT cu.ssn, cr.type, cr.number
	  FROM customers cu LEFT OUTER JOIN credit_cards cr ON cu.ssn = cr.ssn
	  GROUP BY cu.ssn, cr.type, cr.number
	  ORDER BY cu.ssn, cr.type) AS q1d
GROUP BY q1d.ssn, q1d.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cu.country, count(*)
FROM customers cu, credit_cards cr, merchants m, transactions t
WHERE cu.ssn = cr.ssn
AND cr.number = t.number 
AND t.code = m.code
AND m.country <> cu.country
GROUP BY cu.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier, t.amount
FROM transactions t
WHERE t.amount IN (
	SELECT MAX(t.amount)
	FROM transactions t, credit_cards cr
	WHERE cr.number = t.number
	GROUP BY cr.type)
ORDER BY t.amount;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier, t.amount
FROM transactions t
WHERE t.amount IN (
	SELECT temp1.amount
	FROM (SELECT cr1.type, t1.amount
		  FROM credit_cards cr1, transactions t1
	 	  WHERE cr1.number = t1.number
		  GROUP BY cr1.type, t1.amount
		  ORDER BY cr1.type, t1.amount desc) AS temp1
	WHERE temp1.amount >= ALL (
		SELECT temp2.amount
		FROM (SELECT cr2.type, t2.amount
			  FROM credit_cards cr2, transactions t2
			  WHERE cr2.number = t2.number
			  GROUP BY cr2.type, t2.amount
			  ORDER BY cr2.type, t2.amount desc) AS temp2
		WHERE temp1.type = temp2.type))
ORDER BY t.amount;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m.code, m.name 
FROM merchants m LEFT OUTER JOIN(
	SELECT m.code, m.name
	FROM merchants m
	WHERE m.code IN(
		SELECT t.code
		FROM transactions t
		WHERE t.amount >= 888
		AND t.number in (
			SELECT t.number 
			FROM credit_cards cr, transactions t
			WHERE t.number = cr.number
			AND (cr.type = 'visa' or cr.type = 'diners-club')))) AS opp
ON m.code = opp.code
WHERE opp.code ISNULL;
		