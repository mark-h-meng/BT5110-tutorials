/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232193L                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: 26 */
select distinct c.ssn
from customers c, transactions d, credit_cards e
where c.ssn = e.ssn
and e.number = d.number
and EXTRACT(DAY FROM d.datetime) = 25
and e.type= 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: 21*/
select a.first_name, a.last_name
from(select distinct c.first_name, c.last_name, c.ssn
from customers c, credit_cards d, credit_cards e
where c.ssn = d.ssn
and d.ssn = e.ssn
and c.country = 'Singapore'
and d.type = 'jcb'
and e.type = 'visa') a;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: 1301*/
select c.ssn, count(distinct d.number) as num
from customers c
left join credit_cards d
on c.ssn = d.ssn
group by c.ssn

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: 20816*/
select c.ssn, d.type, count(distinct d.number) as num_of_credit_cards
from
(select *, 1 as link 
from customers) as c
outer join
(select distinct type, 1 as link
from credit_cards) as d
on c.link = d.link
left join credit_cards e
on c.ssn = e.ssn
and d.type = e.type
group by c.ssn, d.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: 4*/
select c.country, count(distinct c.ssn)
from customers c
left join credit_cards d
on c.ssn = d.ssn
left join transactions e
on d.number = e.number
left join merchants f
on e.code = f.code
where c.country <> f.country
group by c.country;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: 16*/
select c.identifier, d.type
from transactions c, credit_cards d
where c.number = d.number
and c.amount >= (
    select max(e.amount)
    from transactions e, credit_cards f
    where e.number = f.number
    and f.type = d.type
    group by f.type
)

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: 16*/
SELECT d.type, c.identifier
FROM transactions c, credit_cards d
WHERE c.number = d.number
AND c.amount >= ALL(
    SELECT e.amount 
    FROM transactions e, credit_cards f 
    WHERE e.number = f.number AND f.type=d.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: 7*/
select c.code, c.name
from merchants c
left join transactions d
on c.code = d.code
left join credit_cards e
on d.number = e.number
where e.type like '%visa%' or e.type like '%diners-club%'
group by c.code, c.name
having max(d.amount) < 888;