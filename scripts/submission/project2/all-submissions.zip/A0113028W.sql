/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0113028W                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT cr.ssn
FROM credit_cards cr, transactions t
WHERE cr.number = t.number
AND (SELECT date(t.datetime)) = '2017-12-25'
AND cr.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT cu.first_name, cu.last_name
FROM customers cu, credit_cards cr1, credit_cards cr2
WHERE cu.ssn = cr1.ssn
AND cu.ssn = cr2.ssn
AND cu.country = 'Singapore'
AND cr1.type = 'jcb'
AND cr2.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cu.ssn, COUNT(cr.number) AS no_of_cc_owned
FROM customers cu LEFT JOIN credit_cards cr ON cu.ssn = cr.ssn
GROUP BY cu.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cu.ssn, (CASE WHEN cr.type IS NULL THEN '0' ELSE cr.type END), COUNT(cr.type) AS no_of_cctype_owned
FROM customers cu LEFT JOIN credit_cards cr ON cu.ssn = cr.ssn
GROUP BY cu.ssn, cr.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cu.country, count(DISTINCT cu.ssn) AS no_of_customer
FROM customers cu, credit_cards cr, transactions t, merchants m
WHERE cu.ssn = cr.ssn
AND cr.number = t.number
AND t.code = m.code
AND m.country <> cu.country
GROUP BY cu.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t1.identifier
FROM transactions t1, credit_cards cr1
WHERE t1.number = cr1.number
AND (cr1.type, t1.amount) IN (
		SELECT cr2.type, MAX(t2.amount)
		FROM transactions t2, credit_cards cr2
		WHERE cr2.number = t2.number
		GROUP BY cr2.type);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t1.identifier
FROM transactions t1, credit_cards cr1
WHERE t1.number = cr1.number
AND t1.amount >= ALL (
		SELECT t2.amount
		FROM transactions t2, credit_cards cr2
		WHERE cr2.number = t2.number
		AND cr1.type = cr2.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT m1.code, m1.name
FROM merchants m1
WHERE m1.name IN (
	SELECT m2.name
	FROM merchants m2, transactions t, credit_cards cr
	WHERE t.code = m2.code
	AND cr.number = t.number
	AND cr.type LIKE '%diners-club%'
	GROUP BY m2.name
	HAVING MAX(t.amount) < 888
	UNION
	SELECT m3.name
	FROM merchants m3, transactions t, credit_cards cr
	WHERE t.code = m3.code
	AND cr.number = t.number
	AND cr.type LIKE '%visa%'
	GROUP BY m3.name
	HAVING MAX(t.amount) < 888)