/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232007X                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
select distinct c.ssn
from customers c
inner join credit_cards cc on c.ssn=cc.ssn
inner join transactions t on t.number=cc.number
where cc.type='visa'
and date(t.datetime)='2017-12-25';
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.first_name, c.last_name
from customers c
inner join credit_cards cc on c.ssn=cc.ssn
inner join credit_cards cc2 on c.ssn=cc2.ssn
where c.country='Singapore'
and cc.type='jcb'
and cc2.type='visa'
group by c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.ssn, count(*) as number_of_credit_cards
from customers c
inner join credit_cards cc on c.ssn=cc.ssn
where c.ssn=cc.ssn
group by c.ssn
union
(select c.ssn, 0 as number_of_credit_cards
from customers c
except
select distinct cc.ssn, 0 as number_of_credit_cards
from credit_cards cc)
order by number_of_credit_cards asc;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
-- create a table of all customers with all kinds of credit_cards.
drop table if exists l1;
drop table if exists l2;

select distinct c.ssn, cc.type into table l1
from customers c, credit_cards cc;

select c.ssn, cc.type, count(*) as number_of_credit_cards into table l2
from customers c
inner join credit_cards cc on c.ssn=cc.ssn
group by c.ssn, cc.type;

select l1.ssn,l1.type,coalesce(l2.number_of_credit_cards,0)
from l1
left join l2
on l1.ssn=l2.ssn and l1.type=l2.type
order by l1.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.country, count(distinct c.ssn)
from customers c
inner join credit_cards cc on cc.ssn=c.ssn
inner join transactions t on cc.number=t.number
inner join merchants m on m.code=t.code
where c.country != m.country
group by c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
drop table if exists l3;
drop table if exists l4;

select t.identifier, t.amount, cc.type into table l3
from credit_cards cc
inner join transactions t on cc.number=t.number;

select max(amount),type into table l4
from l3
group by type;

select l3.identifier,l3.amount,l3.type
from l3
inner join l4
on l3.amount=l4.max and l3.type=l4.type;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
drop table if exists l5;

select t.identifier, t.amount, cc.type into table l5
from credit_cards cc
inner join transactions t on cc.number=t.number;

select identifier,amount,type
from (select *,
		rank() over(partition by type
		   order by amount desc) as ranking
		from l5) l6
where l6.ranking=1;
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select m.code,m.name
from merchants m
except
select m.code,m.name
from merchants m
inner join transactions t on m.code=t.code
inner join credit_cards cc on t.number=cc.number
where t.amount >= 888
and (cc.type like '%visa%' or cc.type like '%diners-club%');