/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231912N>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND t.datetime >= '2017-12-25 00:00:00.000000' AND t.datetime <'2017-12-26 00:00:00.000000'
AND cc.type LIKE '%visa%';


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT subtable.first_name, subtable.last_name
FROM
(SELECT DISTINCT cc.ssn, c.last_name, c.first_name
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
AND cc.type LIKE '%visa%' 
INTERSECT
SELECT DISTINCT c.ssn,c.last_name, c.first_name
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
AND cc.type LIKE '%jcb%') as subtable
ORDER BY subtable.first_name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn,coalesce(m.count,0) AS number
FROM
(SELECT cc.ssn,COUNT(*) 
FROM credit_cards cc
GROUP BY cc.ssn  )AS m 

RIGHT JOIN customers c
ON m.ssn =c.ssn
ORDER BY COUNT desc


/*SELECT c.ssn 
FROM customers c
WHERE c.ssn NOT IN(
	SELECT cc.ssn
	FROM credit_cards cc)	
*/

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT atp.ssn,atp.type,coalesce(tp.count,0)
FROM
(SELECT DISTINCT cc.ssn,cc.type, COUNT(cc.type)
FROM credit_cards cc
GROUP BY cc.ssn, cc.type) as tp
RIGHT JOIN
(SELECT DISTINCT c.ssn,cc.type
FROM customers c,credit_cards cc
ORDER BY c.ssn) AS atp
ON tp.ssn = atp.ssn AND tp.type = atp.type
ORDER BY atp.ssn,atp.type;



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT tb.c1, count(*)
FROM 
(select c.ssn,c.country as c1,m.country as c2 ,t.identifier
FROM customers c, credit_cards cc, transactions t, merchants m
WHERE c.ssn=cc.ssn
AND cc.number =t.number
AND t.code=m.code) as tb
WHERE tb.c1!=tb.c2
GROUP BY tb.c1;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t2.identifier
FROM transactions t2, credit_cards cc2,
(SELECT cc.type, MAX(t.amount)
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
GROUP BY cc.type) AS maxtable

WHERE maxtable.max = t2.amount
AND maxtable.type = cc2.type
AND t2.number = cc2.number

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t2.identifier
FROM transactions t2, credit_cards cc2,

(SELECT DISTINCT ON(gt.TYPE) *
FROM
(SELECT cc.type, t.amount
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
ORDER BY cc.type,t.amount desc)AS gt ) AS gt2

WHERE gt2.amount = t2.amount
AND gt2.type = cc2.type
AND t2.number = cc2.number


/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m.code,m.name
FROM 
(SELECT *
FROM credit_cards
WHERE type LIKE '%visa' OR type LIKE '%diners-club%') AS cc, 
merchants m,
(SELECT *
FROM transactions  
WHERE amount<=888) AS t 
WHERE 
cc.number = t.number
AND m.code =t.code



