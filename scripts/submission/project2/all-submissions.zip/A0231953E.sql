/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231953E */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct ssn
from credit_cards cr, transactions t
where t.number = cr.number
and cr.type = 'visa'
and t.datetime >= '2017-12-25 00:00:00'
and t.datetime < '2017-12-26 00:00:00';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct cu.ssn, first_name, last_name
from customers cu, credit_cards cr
where country = 'Singapore'
and cu.ssn = cr.ssn
and type = 'jcb'
intersect
select distinct cu.ssn, first_name, last_name
from customers cu, credit_cards cr
where country = 'Singapore'
and cu.ssn = cr.ssn
and type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct cr.ssn, count(distinct cr.number) as number_of_cards
from credit_cards cr
group by cr.ssn
union
(select distinct cu1.ssn, 0 as number_of_cards
 from customers cu1
 except
 select distinct cr2.ssn, 0 as number_of_cards
 from credit_cards cr2)
order by number_of_cards;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct cr.ssn, cr.type, count(distinct cr.number) as number_of_cards
from credit_cards cr
group by cr.ssn, cr.type
union
(select distinct cu1.ssn, cr1.type, 0 as number_of_cards
 from customers cu1, credit_cards cr1
except
select distinct cr2.ssn, cr2.type, 0 as number_of_cards
from credit_cards cr2)
order by ssn, type, number_of_cards;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct cu.country, count(distinct cu.ssn)
from customers cu, merchants m, transactions t, credit_cards cr
where cu.country <> m.country
and m.code = t.code
and t.number = cr.number
and cr.ssn = cu.ssn
group by cu.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t.identifier, cr.type, max_amount
from transactions t, credit_cards cr, (
	select cr.type, max(t1.amount) as max_amount 
	from credit_cards cr, transactions t1
	where cr.number = t1.number
	group by cr.type) as A
where t.amount = A.max_amount
and cr.number = t.number
and cr.type = A.type
order by type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t.identifier, type, amount
from credit_cards cr, transactions t
where cr.number = t.number
and t.amount >= all(
	select t1.amount 
	from credit_cards cr1, transactions t1 
	where cr1.number = t1.number 
	and cr1.type = cr.type)
order by type;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select code, name
from merchants m
except
(select distinct m1.code, m1.name
from merchants m1, transactions t1, credit_cards cr1
where t1.code = m1.code
and t1.number = cr1.number
and cr1.type in (
	select distinct cr2.type
	from credit_cards cr2
	where cr2.type like '%diners-club%' or cr2.type like 'visa')
and amount >= 888);

