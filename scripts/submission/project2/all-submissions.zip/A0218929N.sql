/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218929N                */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.ssn
FROM 
	customers c, 
	credit_cards cc, 
	transactions t
WHERE
	c.ssn = cc.ssn 
	AND cc.number = t.number
	AND t.datetime >= '2017-12-25'
	AND t.datetime < '2017-12-26'
	AND cc.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.first_name, c.last_name
FROM credit_cards cc1, credit_cards cc2, customers c
WHERE 
	cc1.type = 'visa'
	AND cc2.type = 'jcb'
	AND cc1.ssn = cc2.ssn
	AND c.ssn = cc1.ssn
	AND c.ssn = cc2.ssn
	AND c.country = 'Singapore'
GROUP BY c.ssn, c.first_name, c.last_name
ORDER BY c.first_name, c.last_name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, COUNT(*)
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
GROUP BY c.ssn
UNION
SELECT c.ssn, 0
FROM customers c 
LEFT OUTER JOIN credit_cards cc
ON c.ssn = cc.ssn
WHERE cc.ssn ISNULL
ORDER BY count;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT left_join.ssn, left_join.type, SUM(COALESCE(right_join.total, 0)) as number_of_cards
FROM
	(SELECT *
	FROM customers c,
	(SELECT DISTINCT cc.type
	FROM credit_cards cc) AS cctype) AS left_join
LEFT OUTER JOIN
	(SELECT cc.ssn, cc.type, COUNT(*) as total
	FROM credit_cards cc
	GROUP BY cc.ssn, cc.type) AS right_join
ON left_join.ssn = right_join.ssn AND left_join.type = right_join.type
GROUP BY left_join.ssn, left_join.type
ORDER BY left_join.ssn, left_join.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country, COUNT(DISTINCT c.ssn) AS number_of_customers
FROM customers c, credit_cards cc, merchants m, transactions t
WHERE c.ssn = cc.ssn AND cc.number = t.number and t.code = m.code
AND c.country != m.country
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT all_trans.type, all_trans.identifier
FROM
	(SELECT cc1.type, MAX(t1.amount) AS amount
	FROM transactions t1, credit_cards cc1
	WHERE t1.number = cc1.number 
	GROUP BY cc1.type) AS max_trans,
	(SELECT *
	 FROM transactions t2, credit_cards cc2
	 WHERE t2.number = cc2.number) AS all_trans
WHERE max_trans.amount = all_trans.amount AND max_trans.type = all_trans.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cc1.type, t1.identifier
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND t1.amount >= ALL (
	SELECT t2.amount
	FROM transactions t2, credit_cards cc2
	WHERE t2.number = cc2.number AND cc1.type = cc2.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m.code, m.name
FROM merchants m
WHERE NOT EXISTS (
		SELECT *
		FROM transactions t, credit_cards cc
		WHERE t.number = cc.number 
		AND t.amount >= 888
		AND (cc.type LIKE '%visa%' OR cc.type LIKE '%diners-club%')
		AND m.code = t.code);
