/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0086956J						                    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn, cc.type
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
	AND cc.type='visa'
	AND (t.datetime BETWEEN '2017-12-25 00:00:00' AND '2017-12-25 23:59:59');

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, c.first_name, c.last_name
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
	AND c.country='Singapore'
	AND cc.type='jcb'
INTERSECT
SELECT c.ssn, c.first_name, c.last_name
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
	AND c.country='Singapore'
	AND cc.type='visa';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.ssn, COUNT(*) AS count
FROM credit_cards cc
GROUP BY cc.ssn
UNION
SELECT c.ssn, 0
FROM customers c
WHERE c.ssn NOT IN (
	SELECT cc.ssn
	FROM credit_cards cc)
ORDER BY count;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t1.ssn,t1.type,SUM(t1.count)
FROM(
	SELECT cc.ssn AS ssn, cc.type AS type, COUNT(*) AS count
	FROM credit_cards cc
	GROUP BY cc.ssn, cc.type
	UNION
	SELECT DISTINCT c.ssn AS ssn, cc.type AS type, 0 as count
	FROM customers c
	CROSS JOIN credit_cards cc) t1
GROUP BY t1.ssn, t1.type
ORDER BY t1.ssn, t1.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT(DISTINCT c.ssn)
FROM customers c, credit_cards cc, transactions t, merchants m
WHERE c.ssn = cc.ssn
	AND t.number = cc.number
	AND m.code = t.code
	AND m.country <> c.country
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier, MAX(t.amount) AS amount
FROM transactions t, credit_cards cc
WHERE t.number=cc.number
GROUP BY cc.type, t.identifier
HAVING amount >= ALL
	(SELECT MAX(t1.amount)
	 FROM transactions t1, credit_cards cc1
	 WHERE t1.number=cc1.number
	 AND cc.type=cc1.type
	 GROUP BY cc1.type)
ORDER BY amount;
	 
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
	AND t.amount >= ALL(
		SELECT t2.amount
		FROM transactions t2, credit_cards cc2
		WHERE t2.number = cc2.number
			AND cc2.type = cc.type)
ORDER BY t.amount;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m.code, m.name
FROM merchants m, transactions t, credit_cards cc
WHERE m.code = t.code
	AND t.number = cc.number
	AND (cc.type LIKE 'visa%' OR cc.type LIKE 'diners-club%')
GROUP BY m.code, m.name
HAVING  MAX(t.amount)<888;
