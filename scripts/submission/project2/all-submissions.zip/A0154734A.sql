/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0154734A                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  distinct cc.ssn 
from 
  credit_cards cc, 
  transactions t 
where 
  cc.number = t.number 
  and cc.type = 'visa' 
  and extract(
    year 
    from 
      t.datetime
  ) = 2017 
  and extract(
    month 
    from 
      t.datetime
  ) = 12 
  and extract(
    day 
    from 
      t.datetime
  ) = 25 
order by 
  cc.ssn

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  list.first_name, 
  list.last_name 
from 
  (
    select 
      distinct visa.ssn, 
      visa.first_name, 
      visa.last_name 
    from 
      (
        select 
          c.ssn, 
          c.first_name, 
          c.last_name 
        from 
          customers c, 
          credit_cards cc 
        where 
          c.country = 'Singapore' 
          and cc.type = 'visa' 
          and c.ssn = cc.ssn
      ) as visa, 
      (
        select 
          c.ssn, 
          c.first_name, 
          c.last_name 
        from 
          customers c, 
          credit_cards cc 
        where 
          c.country = 'Singapore' 
          and cc.type = 'jcb' 
          and c.ssn = cc.ssn
      ) as jcb 
    where 
      visa.ssn = jcb.ssn
  ) as list 
order by 
  list.first_name
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  distinct (c.ssn), 
  Coalesce(
    count(cc.ssn), 
    0
  ) 
from 
  customers c 
  left outer join credit_cards cc on c.ssn = cc.ssn 
group by 
  c.ssn, 
  cc.ssn 
order by 
  c.ssn


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  z.ssn, 
  z.type, 
  sum(z.count_label) as count 
from 
  (
    select 
      c.ssn, 
      cc.type, 
      cc.ssn as label, 
      (
        case when c.ssn = cc.ssn then 1 else 0 end
      ) as count_label 
    from 
      customers c, 
      credit_cards cc 
    group by 
      c.ssn, 
      cc.type, 
      cc.ssn 
    order by 
      c.ssn, 
      cc.type
  ) as z 
group by 
  z.ssn, 
  z.type 
order by 
  z.ssn, 
  z.type


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  c.country, 
  count(c.country) 
from 
  customers c, 
  credit_cards cc, 
  merchants m, 
  transactions t 
where 
  c.ssn = cc.ssn 
  and cc.number = t.number 
  and t.code = m.code 
  and c.country != m.country 
group by 
  c.country 
order by 
  c.country


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  final.identifier 
from 
  (
    select 
      t.identifier, 
      max_amt.max as amt, 
      max_amt.type 
    from 
      (
        select 
          cc.type, 
          max(t.amount) 
        from 
          credit_cards cc, 
          transactions t 
        where 
          cc.number = t.number 
        group by 
          cc.type
      ) as max_amt, 
      transactions t 
    where 
      t.amount = max_amt.max 
    order by 
      max_amt.type
  ) as final


/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  final.identifier 
from 
  (
    select 
      distinct m2.identifier, 
      m2.amount, 
      m2.type 
    from 
      (
        SELECT 
          z.identifier, 
          z.amount, 
          z.type 
        FROM 
          (
            SELECT 
              cc.type, 
              t.identifier, 
              t.amount, 
              ROW_NUMBER() OVER(
                PARTITION BY cc.type 
                ORDER BY 
                  t.amount DESC
              ) rowNumber 
            FROM 
              transactions t, 
              credit_cards cc 
            where 
              t.number = cc.number
          ) as z 
        WHERE 
          z.rowNumber = 1 
        order by 
          z.type
      ) as m1, 
      (
        select 
          t.identifier, 
          t.amount, 
          cc.type 
        from 
          transactions t, 
          credit_cards cc
      ) as m2 
    where 
      m1.amount = m2.amount 
      and m1.type = m2.type 
    order by 
      m2.identifier
  ) as final

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  m.code, 
  m.name 
from 
  merchants m, 
  credit_cards cc, 
  transactions t 
where 
  m.code = t.code 
  and cc.number = t.number 
except 
select 
  m.code, 
  m.name 
from 
  merchants m, 
  credit_cards cc, 
  transactions t 
where 
  m.code = t.code 
  and cc.number = t.number 
  and t.amount >= 888 
  and (
    cc.type like '%visa%' 
    or cc.type like '%diners-club%'
  )


