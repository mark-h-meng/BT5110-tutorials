/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231869U>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.ssn
FROM customers c, credit_cards cc, transactions t
WHERE c.ssn = cc.ssn
AND cc.number = t.number
AND t.datetime BETWEEN '2017-12-25 00:00:00' AND '2017-12-26 00:00:00'
AND cc.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c1.first_name, c1.last_name
FROM customers c1
WHERE c1.country = 'Singapore'
AND c1.ssn IN (
	SELECT cc1.ssn
	FROM credit_cards cc1, credit_cards cc2
	WHERE cc1.ssn = cc2.ssn
	AND cc1.type = 'jcb'
	AND cc2.type = 'visa');
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, count(DISTINCT cc.number) AS number_of_credit_cards
FROM customers c FULL OUTER JOIN credit_cards cc ON c.ssn = cc.ssn
GROUP BY c.ssn
ORDER BY number_of_credit_cards ASC;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, cdtype.type, count(DISTINCT cc.number) AS number_of_credit_cards
FROM (SELECT *, 1 AS a FROM customers) AS c
JOIN (SELECT DISTINCT type, 1 AS a FROM credit_cards) AS cdtype 
	ON c.a = cdtype.a
LEFT JOIN credit_cards AS cc ON c.ssn = cc.ssn
	AND cdtype.type = cc.type
GROUP BY c.ssn, cdtype.type
ORDER BY c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, count(DISTINCT c.ssn)
FROM customers c LEFT JOIN credit_cards cc ON c.ssn = cc.ssn
LEFT JOIN transactions t ON cc.number = t.number
LEFT JOIN merchants m ON t.code = m.code
WHERE m.country <> c.country
GROUP BY c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT DISTINCT cc1.type, t1.identifier
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND cc1.type || t1.amount in
 (SELECT cc.type || MAX(t.amount) FROM transactions t, credit_cards cc
 WHERE t.number = cc.number
 GROUP BY cc.type);
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.type, t.identifier
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND t.amount >= ALL(
	SELECT t2.amount FROM transactions t2, credit_cards cc2 
	WHERE t2.number = cc2.number AND cc2.type=cc.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT m.code, m.name
FROM merchants m LEFT JOIN transactions t ON m.code = t.code 
LEFT JOIN credit_cards cc ON t.number =cc.number
WHERE cc.type LIKE 'visa%'
OR cc.type LIKE 'diners-club%'
GROUP BY m.code, m.name
HAVING max(t.amount) < 888
