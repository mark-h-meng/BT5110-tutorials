/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231945A               */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: 26行 */


select distinct ct.ssn
from customers ct, transactions t,credit_cards c
where c.number = t.number
and ct.ssn = c.ssn
and date(t.datetime)='2017-12-25'
and c.type='visa';


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below:  21行*/
select ct.first_name,ct.last_name
from customers ct,(select c.ssn
from credit_cards c
where c.type='visa'
intersect
select c.ssn
from credit_cards c
where c.type='jcb') as new_card
where new_card.ssn =ct.ssn
and ct.country ='Singapore';
/*第二种写法
/*这里面人名有重名，在找人的时候需要用ssn识别，之后再用这里的ssn,再找对应的名字
		注意要加distinct 可能有两张a卡和两张b卡*/
select ct.first_name,ct.last_name
from customers ct,(select distinct ct.ssn
from customers ct, credit_cards c1,credit_cards c2
where ct.ssn = c1.ssn
and ct.ssn = c2.ssn
and c1.type='jcb'
and c2.type ='visa'
and ct.country ='Singapore')as temp
where temp.ssn=ct.ssn*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below:  1301
要先left join 后
count(*)是一条记录  NULL
count(ct.number)是0 
看每个人有多少银行卡、先left join后count 就是0*/


SELECT c.ssn, COUNT(cc.number)
FROM customers c
LEFT  JOIN credit_cards cc
ON c.ssn = cc.ssn
GROUP BY c.ssn
ORDER BY COUNT(cc.number);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below:
select c.ssn,neww.type, neww.card_num
from customers c
left outer join(select c.ssn,c.type,count(*) as card_num
from credit_cards c
group by c.ssn,c.type) as neww
on c.ssn = neww.ssn*/
SELECT aa.ssn, aa.type, COUNT(cc1.number)
FROM (
	SELECT c.ssn, cc.type
	FROM customers c, (
		SELECT DISTINCT type
		FROM credit_cards
	) cc
) aa
LEFT JOIN credit_cards cc1
ON (aa.ssn, aa.type) = (cc1.ssn, cc1.type)
GROUP BY aa.ssn, aa.type
ORDER BY aa.ssn, aa.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select ct.country,count(distinct ct.ssn)
from merchants m ,customers ct,transactions t,credit_cards c
where ct.country <> m.country
and t.number = c.number
and t.code = m.code
and c.ssn = ct.ssn
group by ct.country;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier, t.amount, cc.type
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND (cc.type, t.amount) IN (
	SELECT cc1.type, MAX(t1.amount) as max_amount
	FROM credit_cards cc1, transactions t1
	WHERE cc1.number = t1.number
	GROUP BY cc1.type);
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select t.identifier,t.amount,cc.type
from transactions t, credit_cards cc
where t.number = cc.number
and t.amount>=all(
	select t.amount
	from transactions t, credit_cards c
	where c.number= t.number
	and c.type = cc.type);
	
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT m.code, m.name
FROM merchants m
WHERE m.code NOT IN (
	SELECT DISTINCT m.code
	FROM merchants m, transactions t, (
		SELECT *
		FROM credit_cards
		WHERE type LIKE '%visa%'
		OR type LIKE '%diners-club%'
		) cc
	WHERE m.code = t.code
	AND t.number = cc.number
	GROUP BY m.code, cc.type
	HAVING MAX(t.amount) >= 888
);
/*另一种写法
select distinct m.code, m.name
from merchants m
where m.code not in(
	select m.code
	from merchants m, transactions t, credit_cards c
	where m.code = t.code
	AND t.number = c.number
	and t.amount >=888
	and (c.type LIKE '%visa%'
		OR c.type LIKE '%diners-club%'))*/



