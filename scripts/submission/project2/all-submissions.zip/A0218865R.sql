/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218865R                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct ssn from transactions tx
left join credit_cards cc on cc.number=tx.number
where date(datetime)='2017-12-25'
and type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select first_name, last_name from customers c
where ssn in (((select cc.ssn from credit_cards cc where type = 'jcb') 
 intersect (select cc.ssn from credit_cards cc where type = 'visa')))
and country = 'Singapore';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.ssn, case when num_cc is null then 0 else num_cc end as num_cc  
from customers c
left join (select ssn, count(distinct number) as num_cc 
		   from credit_cards
		   group by ssn) cc on cc.ssn = c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select total.ssn, total.type,
case when num_type_cc is null then 0 else num_type_cc end as num_type_cc
from (select distinct cust.ssn, cc.type
from customers cust, credit_cards cc) total
left join (select ssn, type, count(distinct number) as num_type_cc 
		   from credit_cards
		   group by ssn,type) a on total.type = a.type and total.ssn = a.ssn 
		   order by total.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cust_country, count(distinct ssn) as num_customers from (
select c.ssn, c.country as cust_country, tx.number, m.code, m.country as merchant_country,
case when c.country != m.country then 1 else 0 end as is_different_country
from customers c, credit_cards cc, transactions tx, merchants m
where cc.ssn= c.ssn
and tx.number = cc.number
and m.code = tx.code
) A where is_different_country =1
group by cust_country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select identifier from (
select type, max(amount) as largest_amt 
from transactions tx, credit_cards cc
where tx.number=cc.number group by type) agg
inner join (
select identifier, tx.number, amount, cc.type 
from transactions tx, credit_cards cc
where cc.number = tx.number) B on B.amount = largest_amt and B.type = agg.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select tx.identifier from transactions tx, credit_cards cc
where tx.number=cc.number
and tx.amount>=ALL(select amount from transactions tx2, credit_cards cc2
				  where tx2.number=cc2.number and cc2.type=cc.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select code, name from merchants
where code not in (
select m.code
from merchants m, transactions tx, credit_cards cc
where m.code = tx.code
and cc.number = tx.number
and amount>=888 and (type like '%visa%' or type like '%diners-club%'));