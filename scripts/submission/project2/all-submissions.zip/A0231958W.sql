/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231958W                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn
FROM customers c, transactions t, credit_cards d
WHERE
(t.datetime BETWEEN '2017-12-25 00:00:00.000000' AND '2017-12-25 23:59:59.999999')
AND (d.type = 'visa');

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.first_name, c.last_name
FROM customers c, credit_cards d
WHERE c.country = 'Singapore'
AND (d.type ='jcb' OR d.type = 'visa')
GROUP BY c.first_name, c.last_name
ORDER BY c.first_name, c.last_name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn,
(CASE
 WHEN count(*) is null
 THEN 0
 ELSE count(*) END) AS nb_credit_cards
FROM customers c, credit_cards d
WHERE c.ssn = d.ssn
GROUP BY c.ssn
ORDER BY count(*);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, d.type, 
(CASE
 WHEN count(*) is null
 THEN 0
 ELSE count(*) END) AS nb_credit_cards
FROM customers c, credit_cards d
WHERE c.ssn = d.ssn
GROUP BY c.ssn, d.type
ORDER BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country, count(c.ssn)
FROM customers c, credit_cards d, merchants m, transactions t
WHERE t.number = d.number AND  t.code = m.code AND d.ssn = c.ssn
GROUP BY c.country
HAVING count(c.ssn) = ALL (
	SELECT count(c.ssn)
	FROM customers c1, merchants m1
	WHERE c1.country <> m1.country);
	
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier, d.type, max(t.amount)
FROM transactions t, credit_cards d
GROUP BY t.identifier, d.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t1.identifier, d.type, t1.amount
FROM transactions t1, credit_cards d
WHERE t1.amount >= ALL (
	SELECT t2.amount
	FROM transactions t2
	WHERE t1.identifier = t2.identifier)
GROUP BY t1.identifier, d.type;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m.code, m.name
FROM merchants m, credit_cards d, transactions t
WHERE NOT EXISTS (
	SELECT d.type, t.amount
	WHERE d.type LIKE 'visa%' OR d.type LIKE 'diners-club%' AND t.amount >= 888)
GROUP BY m.code, m.name
ORDER BY m.code, m.name;