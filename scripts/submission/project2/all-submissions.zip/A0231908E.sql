/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231908E                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.ssn
from customers as c, credit_cards as d, transactions as t
where c.ssn=d.ssn
and d.number=t.number
and date(t.datetime) = '2017-12-25'
and d.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select temp.first_name,temp.last_name,temp.ssn
from
(select c.first_name,c.last_name,c.ssn
from customers c, credit_cards d
where c.ssn=d.ssn
and d.type = 'visa'
and c.country='Singapore'
intersect
select c.first_name,c.last_name,c.ssn
from customers c, credit_cards d
where c.ssn=d.ssn
and d.type = 'jcb'
and c.country='Singapore') as temp
order by temp.first_name,temp.last_name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.ssn,
(CASE WHEN count(d.number) IS NULL
THEN 0
ELSE count(d.number) END) as cards_owned
from customers c left join credit_cards d
on c.ssn=d.ssn
group by c.ssn
order by cards_owned;

select c.ssn,count(d.number) as cards_owned
from customers c left join credit_cards d
on c.ssn=d.ssn
group by c.ssn
order by cards_owned;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/* 	
another answers: 
select main.ssn, main.type, count(main.number) cards_owned
from (select distinct temp.ssn,temp.type,d.number from
(
(select distinct ssn from customers ) as customers cross join
(select distinct type from credit_cards) as cards_type
) temp
left join
credit_cards d
on temp.ssn=d.ssn
and temp.type=d.type) main 
group by main.ssn,main.type
*/
/************************************************************************/
/* Write your answer in SQL below: */
select main.ssn, main.type,
coalesce(sub.cards_owned, 0) as cards_owned 
from
(select distinct c.ssn,cards_type.type
from customers c,
(select distinct type
from credit_cards) as cards_type) main
left join
(select c.ssn,d.type,count(*) as cards_owned
from customers c,credit_cards d
where c.ssn=d.ssn
group by c.ssn, d.type
order by cards_owned,c.ssn,d.type) sub
on main.ssn=sub.ssn
and main.type=sub.type
order by main.ssn,main.type,cards_owned;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select temp.customer_country,count(distinct temp.ssn) number 
from
(select c.ssn,c.country customer_country,d.number,m.code,m.country merchant_country
from customers c,credit_cards d,merchants m,transactions t
where c.ssn=d.ssn
and d.number=t.number
and t.code=m.code) temp
where temp.customer_country != temp.merchant_country
group by temp.customer_country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*
select d.type,t.identifier
from transactions t,credit_cards d
where t.number=d.number
and t.amount = all
(select max(t1.amount)
from transactions t1,credit_cards d1
where t1.number=d1.number
group by d1.type
having d.type=d1.type);                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select d.type,t.identifier
from transactions t,credit_cards d
where t.number=d.number
and (d.type,t.amount) in
(select d1.type,max(t1.amount)
from transactions t1,credit_cards d1
where t1.number=d1.number
group by d1.type);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select d.type,t.identifier
from transactions t,credit_cards d
where t.number=d.number
and t.amount >= all (
select t1.amount
from transactions t1,credit_cards d1
where t1.number=d1.number
and d.type=d1.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct m.name, m.code
from merchants m
where not exists(
select t.amount
from transactions t,credit_cards d
where t.number=d.number
and (d.type like '%visa%'
or d.type like '%diners-club%')
and t.amount >= 888
and m.code=t.code);
