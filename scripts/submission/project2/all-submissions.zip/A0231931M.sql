/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231931M                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cc.ssn
FROM credit_cards cc, transactions tx
WHERE tx.number = cc.number
	AND CAST(tx.datetime AS date) = '2017-12-25'
	AND cc.type = 'visa';


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cs.first_name, cs.last_name
FROM customers cs, credit_cards cc
WHERE cc.ssn = cs.ssn
	AND cs.country = 'Singapore'
	AND cc.type = 'jcb' 
INTERSECT
SELECT cs.first_name, cs.last_name
FROM customers cs, credit_cards cc
WHERE cc.ssn = cs.ssn
	AND cs.country = 'Singapore'
	AND cc.type = 'visa'; 

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cc.ssn, COUNT(cc.number)
FROM customers cs, credit_cards cc
WHERE cc.ssn = cs.ssn
GROUP BY cc.ssn
UNION
SELECT cs.ssn, 0 AS count
FROM customers cs LEFT OUTER JOIN credit_cards cc 
ON cc.ssn = cs.ssn
WHERE cc.ssn IS NULL;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT cus1.ssn, cus2.type, COUNT(credit_cards.number)
FROM (SELECT DISTINCT customers.ssn
	  FROM customers) AS cus1
	  CROSS JOIN
	  (SELECT DISTINCT credit_cards.type
	  FROM credit_cards) AS cus2
LEFT JOIN credit_cards 
ON cus1.ssn = credit_cards.ssn AND cus2.type = credit_cards.type
GROUP BY cus1.ssn, cus2.type
ORDER BY cus1.ssn, cus2.type;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */



SELECT cs.country, COUNT(*) AS total
FROM customers cs, credit_cards cc, transactions tx, merchants mc
WHERE mc.code = tx.code
	AND tx.number = cc.number
	AND cc.ssn = cs.ssn
	AND cs.country != mc.country
GROUP BY cs.country;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT tx.identifier, cc.type, tx.amount
FROM transactions tx
LEFT JOIN credit_cards cc on cc.number = tx.number
WHERE (cc.type, tx.amount) IN (
	SELECT cc.type, MAX(tx1.amount)
	FROM transactions tx1
	LEFT JOIN credit_cards cc ON tx1.number = cc.number
	GROUP BY cc.type)
ORDER BY tx.identifier;


/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT tx.identifier, cc.type, tx.amount
FROM credit_cards cc
LEFT OUTER JOIN transactions tx ON cc.number= tx.number
WHERE (cc.type, tx.amount) >= ALL (
	SELECT cc1.type, tx1.amount
	FROM credit_cards cc1
	LEFT OUTER JOIN transactions tx1 ON cc1.number = tx1.number
	WHERE cc.type = cc1.type)
ORDER BY tx.identifier;



/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT DISTINCT mer.code, mer.name
FROM merchants mer, transactions tx, credit_cards cc
WHERE tx.code = mer.code
AND tx.number = cc.number
AND tx.amount < 888
AND cc.type IN ('visa', 'diners-club')
ORDER BY mer.code;

