/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0119430N                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT cc.ssn FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND cc.type = 'visa'
AND t.datetime >= '2017-12-25'
AND t.datetime < '2017-12-26';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.first_name, c.last_name
FROM customers c, credit_cards cc1, credit_cards cc2
WHERE c.ssn = cc1.ssn AND cc1.type = 'visa'
AND c.ssn = cc2.ssn AND cc2.type = 'jcb'
GROUP BY c.ssn, c.first_name, c.last_name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, COUNT(cc.number) AS card_count
FROM customers c LEFT JOIN credit_cards cc
ON c.ssn = cc.ssn
GROUP BY c.ssn
ORDER BY card_count;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, ct.type, COUNT(cc.number) AS card_count
FROM customers c
CROSS JOIN (SELECT DISTINCT cc.type FROM credit_cards cc) AS ct
LEFT JOIN credit_cards cc
ON  ct.type = cc.type AND c.ssn = cc.ssn
GROUP BY c.ssn, ct.type
ORDER BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country, COUNT(DISTINCT c.ssn)
FROM customers c, credit_cards cc, transactions t, merchants m
WHERE c.ssn = cc.ssn
AND cc.number = t.number
AND t.code = m.code
AND NOT c.country = m.country
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t1.identifier
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND t1.amount = ALL(
	SELECT MAX(t2.amount)
	FROM transactions t2, credit_cards cc2
	WHERE t2.number = cc2.number
	AND cc2.type = cc1.type);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t1.identifier
FROM transactions t1, credit_cards cc1
WHERE t1.amount >= ALL(
	SELECT t2.amount
	FROM transactions t2, credit_cards cc2
	WHERE t2.number = cc2.number
	AND cc2.type = cc1.type)
AND t1.number = cc1.number;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m.code, m.name
FROM merchants m
EXCEPT(
SELECT m2.code, m2.name
FROM credit_cards cc, transactions t, merchants m2
WHERE cc.number = t.number
AND t.code = m2.code
AND t.amount >= 888
AND (cc.type LIKE 'visa%' OR cc.type LIKE 'diners-club%')
GROUP BY m2.code, m2.name);
