/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <replace with your student number>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn
FROM customers c, transactions t, credit_cards cc
WHERE c.ssn = cc.ssn
AND t.number = cc.number
AND t.datetime >= '2017-12-25'
AND t.datetime < '2017-12-26'
AND cc.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.first_name, c.last_name 
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
AND cc.type = 'visa'
AND c.country = 'Singapore'
UNION
SELECT DISTINCT c.first_name, c.last_name 
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
AND cc.type = 'jcb'
AND c.country = 'Singapore';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.ssn, COUNT(cc.number) AS count
FROM credit_cards cc, customers c
WHERE c.ssn = cc.ssn
GROUP BY cc.ssn
UNION
SELECT cc.ssn, 0 AS count
FROM credit_cards cc LEFT OUTER JOIN customers c
ON c.ssn = cc.ssn
WHERE cc.number ISNULL;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.ssn, cc.type, COUNT(cc.type) AS count
FROM credit_cards cc, customers c
WHERE c.ssn = cc.ssn
GROUP BY cc.ssn,cc.type
UNION
SELECT cc.ssn, cc.type, 0 AS count
FROM credit_cards cc LEFT OUTER JOIN customers c
ON c.ssn = cc.ssn
WHERE cc.number ISNULL;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COALESCE(COUNT(c.ssn),0) AS count
FROM customers c, merchants m, credit_cards cc, transactions t
WHERE c.country <> m.country
AND t.number = cc.number
AND t.code = m.code
AND cc.ssn = c.ssn
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t1.identifier, t1.amount
FROM credit_cards cc, transactions t1
WHERE cc.number = t1.number
AND t1.amount = (SELECT MAX(amount) 
                FROM credit_cards cc2, transactions t2
                WHERE cc2.number = t2.number
                AND cc2.type = cc.type
                );
				
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t1.identifier, t1.amount
FROM credit_cards cc, transactions t1
WHERE cc.number = t1.number
AND t1.amount = (SELECT t2.amount
                FROM credit_cards cc2, transactions t2
                WHERE cc2.number = t2.number
                AND cc2.type = cc.type
				ORDER BY t2.amount DESC
				LIMIT 1);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT m.code, m.name
FROM merchants m
WHERE (m.code, m.name) NOT IN (
	SELECT DISTINCT m.code, m.name
	FROM merchants m, transactions t, (
  		SELECT *
  		FROM credit_cards
  		WHERE type LIKE 'visa%'
  		OR type LIKE 'diners-club%') cc
	WHERE t.number = cc.number
	AND m.code = t.code
	AND t.amount >= 888)
