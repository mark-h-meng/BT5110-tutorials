/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0111496H                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn
FROM customers c, credit_cards d, transactions t
WHERE d.ssn = c.ssn
AND t.number = d.number
AND d.type = 'visa'
AND t.datetime BETWEEN '2017-12-25 00:00:00.00000'AND '2017-12-25 23:59:59.99999';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT first_name, last_name
FROM customers
WHERE country = 'Singapore'
AND ssn IN(
	SELECT ssn
	FROM credit_cards
	WHERE type = 'jcb'
	INTERSECT 
	SELECT ssn
	FROM credit_cards
	WHERE type = 'visa');

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, COUNT(d.ssn) AS no_of_cards
FROM customers c LEFT JOIN credit_cards d ON c.ssn = d.ssn
GROUP BY c.ssn
ORDER BY no_of_cards, c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, cs.type, count(d1.type)
FROM (customers c CROSS JOIN (SELECT DISTINCT d.type FROM credit_cards d) AS cs)
	LEFT JOIN credit_cards d1 ON cs.type = d1.type AND c.ssn = d1.ssn
GROUP BY c.ssn, cs.type
ORDER BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT(DISTINCT c.ssn)
FROM transactions t, merchants m, credit_cards d, customers c
WHERE c.ssn = d.ssn
AND t.code = m.code
AND t.number = d.number
AND c.country != m.country
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT bb.identifier 
FROM (
	SELECT d.type, MAX(t.amount)
	FROM credit_cards d, transactions t
	WHERE t.number = d.number
	GROUP BY d.type) AS aa
INNER JOIN (
	SELECT d1.type, t1.amount, t1.identifier
	FROM credit_cards d1, transactions t1
	WHERE t1.number = d1.number) AS bb
ON aa.max = bb.amount AND aa.type = bb.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t1.identifier
FROM credit_cards d1, transactions t1
WHERE d1.number = t1.number
AND t1.amount >= ALL (
	SELECT t2.amount
	FROM credit_cards d2, transactions t2
	WHERE d2.number = t2.number
	AND d1.type = d2.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m.code, m.name
FROM merchants m
EXCEPT
SELECT DISTINCT m.code, m.name
FROM merchants m, transactions t, credit_cards d
WHERE m.code = t.code
AND t.number = d.number
AND t.amount >=888
AND (d.type LIKE '%visa%' OR d.type LIKE '%diners-club%');
