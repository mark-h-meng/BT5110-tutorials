/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232016X                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn 
FROM credit_cards cc
WHERE cc.number IN (
	SELECT t.number
	FROM transactions t
	WHERE t.datetime >= '2017-12-25 00:00:00'
	AND t.datetime <= '2017-12-25 23:59:59')
AND cc.type = 'visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT i.first_name, i.last_name
FROM (
	SELECT c.ssn, c.first_name, c.last_name
	FROM customers c, credit_cards cc
	WHERE c.ssn = cc.ssn
	AND c.country = 'Singapore'
	AND cc.type = 'jcb'
	INTERSECT
	SELECT c.ssn, c.first_name, c.last_name
	FROM customers c, credit_cards cc
	WHERE c.ssn = cc.ssn
	AND c.country = 'Singapore'
	AND cc.type = 'visa'
	) i;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, count(cc.number)
FROM customers c
FULL OUTER JOIN credit_cards cc ON c.ssn = cc.ssn
GROUP BY c.ssn
ORDER BY COUNT(cc.number);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT allcards.ssn, allcards.type, COUNT(cc1.number)
FROM (
	SELECT c.ssn, cc.type
	FROM customers c, (
		SELECT DISTINCT type
		FROM credit_cards
	) cc
) allcards
LEFT JOIN credit_cards cc1 ON (allcards.ssn, allcards.type) = (cc1.ssn, cc1.type)
GROUP BY allcards.ssn, allcards.type
Order BY allcards.ssn, allcards.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.country, count(*)
FROM customers c
WHERE c.ssn IN(
	SELECT cc.ssn
	FROM (credit_cards cc FULL OUTER JOIN transactions t ON cc.number =  t.number) FULL OUTER JOIN merchants m ON t.code = m.code
	WHERE t.identifier IS NOT NULL
	AND m.country <> c.country)
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t1.identifier
FROM transactions t1 FULL OUTER JOIN credit_cards cc1 ON t1.number = cc1.number
WHERE (t1.amount, cc1.type) IN (
	SELECT MAX(t2.amount), cc2.type
	FROM transactions t2 FULL OUTER JOIN credit_cards cc2 ON t2.number = cc2.number
	GROUP BY cc2.type);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t1.identifier
FROM transactions t1 FULL OUTER JOIN credit_cards cc1 ON t1.number = cc1.number
WHERE t1.amount >= ALL (
	SELECT t2.amount
	FROM transactions t2 FULL OUTER JOIN credit_cards cc2 ON t2.number = cc2.number
	WHERE cc1.type = cc2.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT code, name
FROM merchants
WHERE (code, name) NOT IN (
	SELECT DISTINCT m.code, m.name
	FROM merchants m, transactions t, (
		SELECT *
		FROM credit_cards
		WHERE type LIKE '%visa%' OR type LIKE '%diners-club%') cc
	WHERE m.code = t.code
	AND t.number = cc.number
	GROUP BY m.code, cc.type
	HAVING MAX(t.amount) >= 888);

	
