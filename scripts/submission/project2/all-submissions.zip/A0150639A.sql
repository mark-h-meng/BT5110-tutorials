/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0150639A	                                        */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn
FROM 
	customers c, 
	transactions t, 
	credit_cards cc
WHERE c.ssn = cc.ssn
	  AND cc.number = t.number
	  AND t.datetime BETWEEN '2017-12-25 00:00:00.000000' AND '2017-12-25 23:59:59.999999'
	  AND cc.type = 'visa';


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn
FROM customers c LEFT JOIN credit_cards cc
	 on c.ssn = cc.ssn
WHERE c.country = 'Singapore'
	  AND cc.type IN ('jcb','visa')
GROUP BY c.ssn
HAVING COUNT(DISTINCT cc.type) = 2;


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
	c.ssn, 
	count(cc.number)
FROM customers c 
	 LEFT JOIN credit_cards cc 
	 ON c.ssn = cc.ssn
GROUP BY c.ssn;



/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT
	c.ssn, 
	cc.type, 
	count(cc.number)
FROM customers c 
	 LEFT JOIN credit_cards cc 
	 ON c.ssn = cc.ssn
GROUP BY c.ssn,cc.type;



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
	c.country, 
	count(distinct c.ssn)
FROM 
	 customers c,
	 credit_cards cc, 
	 transactions t,
	 merchants m
WHERE 
	 c.ssn = cc.ssn
	 AND cc.number = t.number
	 AND t.code = m.code 
	 AND c.country <> m.country
GROUP BY c.country;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT
	t1.identifier
FROM(
	SELECT 
		cc2.type card_type,
		max(t2.amount) largest_amount
	FROM 
		transactions t2,
		credit_cards cc2
	WHERE
		cc2.number = t2.number
	GROUP BY
		cc2.type) as tb,
	transactions t1,
	credit_cards cc1
WHERE
	t1.number = cc1.number
	AND cc1.type = tb.card_type
	AND t1.amount = tb.largest_amount;



/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT
	t1.identifier
FROM
	transactions t1,
	credit_cards cc1
WHERE
	t1.number = cc1.number
	AND t1.amount >= ALL(
		SELECT t2.amount
		FROM 
			transactions t2,
			credit_cards cc2
		WHERE
			t2.number = cc2.number
			AND cc1.type = cc2.type);


/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT
	m2.code,
	m2.name
FROM
	merchants m2
WHERE
	(m2.code, m2.name) NOT IN(
	SELECT
		m1.code,
		m1.name
	FROM
		merchants m1,
		transactions t1,
		credit_cards cc1
	WHERE
		m1.code = t1.code
		AND t1.number = cc1.number
		AND t1.amount >= 888
		AND (cc1.type LIKE 'visa%' OR cc1.type LIKE 'diners-club%'));



