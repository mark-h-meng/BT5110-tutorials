/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231867X                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select count(distinct c.ssn) ssn
from customers c, transactions t, credit_cards d
where type = 'visa'
and date(datetime) = '2017-12-25'
and amount <> 0;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select first_name, last_name
from customers
where ssn in
(
	select ssn
	from credit_cards c1
	where c1.type = 'jcb'
	INTERSECT
	select ssn
	from credit_cards c2
	where c2.type = 'visa'
)
and country = 'Singapore'
order by first_name, last_name asc;



/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select b.ssn, (case when card_own is null then 0 else card_own end) as card_own
from
(
	select distinct ssn
	from customers c
) b
left join
(
	select distinct ssn, count(distinct number) card_own
	from credit_cards d 
	group by ssn
) a
on b.ssn = a.ssn
order by card_own desc;



/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select a1.ssn, a1.type, (case when card_num is null then 0 else card_num end) as card_num
from
(
	select distinct ssn, type
	from customers c
	cross join
	(
		select distinct type
		from credit_cards
	) a
) a1
left join
(
	select ssn, type, count(distinct number) card_num
	from credit_cards d 
	group by ssn, type
) b
on a1.ssn = b.ssn and a1.type = b.type
order by ssn asc;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select country, count(distinct a2.ssn) num
from
(
	select d.ssn ssn, country m_country
	from
	(
		select number, country
		from transactions t
		left join
		merchants m 
		on t.code = m.code
	) a1 
	left join
	credit_cards d
	on a1.number = d.number
) a2
left join
customers c 
on a2.ssn = c.ssn
where m_country <> c.country
group by country;




/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select identifier, t1.type
from
(
	select identifier, amount, type
	from transactions t 
	left join
	credit_cards d 
	on t.number = d.number
) t1
left join
(
	select type, max(amount) amount
	from transactions t
	left join
	credit_cards d
	on t.number = d.number
	group by type
) a  
on t1.type = a.type
where t1.amount = a.amount;



/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


select identifier
from
(
	select identifier, row_number() over(partition by type order by amount desc) rn
	from transactions t
	left join
	credit_cards d 
	on t.number = d.number
) a 
where rn = 1
order by identifier asc;




/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


select distinct a.code, name
from
(
	select code, type, amount
	from transactions t 
	left join
	credit_cards d
	on t.number = d.number
	where type in ('visa', 'diners-club')
	and amount < 888
) a 
left join
merchants m
on a.code = m.code;



/* The end of Zeng Jiaqi's assignment 2  */


