/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231850M                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn
FROM credit_cards cc, transactions t
WHERE t.datetime >= '2017-12-25'
AND t.datetime < '2017-12-26'
AND t.number = cc.number
AND cc.type = 'visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.first_name, c.last_name
FROM customers c
WHERE c.ssn IN (SELECT DISTINCT(c1.ssn)
				FROM credit_cards c1, credit_cards c2
				WHERE c1.type = 'visa'
				AND c2.type = 'jcb'
				AND c1.ssn = c2.ssn);
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
(SELECT c.ssn, COUNT(*) AS count
 FROM customers c, credit_cards cc
 WHERE c.ssn = cc.ssn
 GROUP BY c.ssn)
UNION
(SELECT c.ssn, 0 AS count
FROM customers c LEFT JOIN credit_cards cc
ON c.ssn = cc.ssn
WHERE cc.ssn ISNULL);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.ssn, types.type, COUNT(*) as count
FROM credit_cards cc,
	 (SELECT DISTINCT cc.type
	 FROM credit_cards cc) AS types
WHERE cc.type = types.type
GROUP BY cc.ssn, types.type
ORDER BY ssn, type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT(*)
FROM customers c, merchants m
WHERE c.country != m.country
GROUP BY c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM transactions t,(
	SELECT cc.type, MAX(t.amount)
	FROM transactions t, credit_cards cc
	WHERE t.number = cc.number
	GROUP BY cc.type) as temp
WHERE t.amount = temp.max;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t1.identifier
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND t1.amount >= ALL(SELECT t2.amount
					 FROM transactions t2, credit_cards cc2
					 WHERE t2.number = cc2.number
					 AND cc1.type = cc2.type)
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m.code, m.name
FROM 
