/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231880H>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.SSN
FROM customers c, credit_cards r, transactions t
WHERE c.SSN = r.SSN
AND r.number = t.number
AND t.datetime between '2017-12-25' and '2017-12-26'
AND r.type = 'visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.first_name, c.last_name
FROM customers c, credit_cards r
WHERE c.SSN = r.SSN
AND r.type = 'jcb'
AND c.country = 'Singapore'
GROUP by c.SSN
INTERSECT
SELECT c.first_name, c.last_name
FROM customers c, credit_cards r
WHERE c.SSN = r.SSN
AND r.type = 'visa'
AND c.country = 'Singapore'
GROUP BY c.SSN;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.SSN, COUNT(r.number) 
FROM customers c LEFT OUTER JOIN credit_cards r ON c.SSN = r.SSN
GROUP BY c.SSN;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE VIEW view1 AS
SELECT c.SSN, r.type, c.SSN ||' '|| r.type AS ssntype, count(r.number) AS cards_owned
FROM customers c CROSS JOIN credit_cards r
WHERE c.SSN = r.SSN
GROUP BY c.SSN, r.type
ORDER BY c.SSN;

CREATE VIEW view2 AS
SELECT c.SSN, r.type, c.SSN ||' '|| r.type AS ssntype
FROM customers c CROSS JOIN credit_cards r
GROUP BY c.SSN, r.type
ORDER BY c.SSN;

SELECT v1.SSN as SSN, v1.type as type, v1.cards_owned
FROM view1 v1
Union
SELECT v2.SSN as SSN, v2.type as type, 0 as cards_owned
FROM view2 v2
WHERE v2.ssntype NOT IN (SELECT v1.ssntype FROM view1 v1)
ORDER BY SSN, type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE VIEW tempc AS
SELECT c.SSN, c.country AS own, m.country AS merchant
FROM customers c, credit_cards r, merchants m, transactions t
WHERE c.SSN = r.SSN AND r.number = t.number AND t.code = m.code;

SELECT own, COUNT(*)
FROM tempc
WHERE own <> merchant
GROUP BY own;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE VIEW maxtemp AS
SELECT t.identifier, t.amount, r.type
FROM transactions t, credit_cards r
WHERE t.number = r.number
AND t.amount IN (SELECT max(t.amount)
					FROM credit_cards r, transactions t
					WHERE t.number = r.number
					GROUP BY r.type) 
AND r.type IN (SELECT DISTINCT(r.type) FROM credit_cards r)
ORDER BY r.type;

SELECT a1.identifier
FROM maxtemp a1
WHERE a1.amount >= ALL (
	SELECT a2.amount
	FROM maxtemp a2 
	WHERE a1.type = a2.type)
ORDER BY a1.identifier;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE VIEW temp AS
SELECT t.identifier, t.amount, r.type 
FROM transactions t, credit_cards r
WHERE t.number = r.number;

SELECT t1.identifier
FROM temp t1
WHERE t1.amount >= ALL (SELECT t2.amount FROM temp t2 WHERE t1.type = t2.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT(m.code), m.name
FROM merchants m, credit_cards r, transactions t
WHERE r.number = t.number AND m.code = t.code
AND m.code NOT IN (SELECT t.code 
				   FROM transactions t, credit_cards r 
				   WHERE r.number = t.number
				   AND t.amount >= 888
				   AND (r.type LIKE '%visa%' OR r.type LIKE '%diners-club%'));
