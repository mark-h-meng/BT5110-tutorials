/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231884Y                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct cc.ssn 
from credit_cards cc, transactions t
where cc.number = t.number
and cc.type = 'visa'
and t.datetime >= '2017-12-25'
and t.datetime < '2017-12-26';


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select cus1.first_name, cus1.last_name
from (
	select distinct cus.ssn
	from customers cus, credit_cards cc1, credit_cards cc2
	where cus.ssn = cc1.ssn
	and cus.ssn = cc2.ssn
	and cus.country = 'Singapore'
	and cc1.type = 'jcb'
	and cc2.type = 'visa') as dssn, customers cus1
where cus1.ssn = dssn.ssn;


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select joint.ssn, count(joint.number) as numbercc
from (
	select cus1.ssn, cc1.number from
	customers cus1 left join credit_cards cc1
	on cus1.ssn = cc1.ssn) as joint
group by joint.ssn
order by numbercc;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
--the number of the results rows should be : ssn * credit_cards.type = 1301 * 16 = 20816
--count(wh.number) when wh.number is null, it will count as 0

select wh.ssn, wh.type, count(wh.number)
from (
	select distinct df.ssn, df.type, cc.number from
	((select ssn from customers) as cusssn
	cross join (select distinct type from credit_cards)as cct) as df
	left join credit_cards cc
	on df.ssn = cc.ssn and df.type = cc.type
) as wh
group by wh.ssn, wh.type
order by wh.ssn, wh.type;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select cus.country, count(distinct cus.ssn)
from customers cus, credit_cards cc, transactions t, merchants m
where cus.ssn = cc.ssn
and cc.number = t.number
and m.code = t.code
and cus.country != m.country
group by cus.country;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select type_max.type, t.identifier, type_max.max_amount
from (
	select cc1.type, max(t1.amount) as max_amount
	from credit_cards cc1, transactions t1
	where cc1.number = t1.number
	group by cc1.type) as type_max, transactions t, credit_cards cc
where cc.number = t.number
and cc.type = type_max.type
and t.amount = type_max.max_amount;


/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select cc.type, t.identifier, t.amount
from transactions t, credit_cards cc
where t.number = cc.number
and t.amount >= all(
	select t1.amount
	from transactions t1, credit_cards cc1
	where t1.number = cc1.number
	and cc.type = cc1.type);


/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct m.code, m.name
from merchants m
where m.code not in(
	select distinct m1.code
	from merchants m1, transactions t, credit_cards cc
	where m1.code = t.code
	and cc.number = t.number
	and t.amount >= 888
	and (cc.type like '%visa%' or cc.type like '%diners-club%'))
order by m.code;

