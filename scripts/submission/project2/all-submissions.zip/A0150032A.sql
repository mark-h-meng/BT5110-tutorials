/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0150032A      */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn
FROM transactions t
JOIN 
credit_cards cc 
ON t.number = cc.number
JOIN 
customers c
ON cc.ssn = c.ssn
WHERE 
cc.type = 'visa'
AND date(t.datetime) = '2017-12-25';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT first_name, last_name
FROM
credit_cards cc
JOIN 
customers c
ON cc.ssn = c.ssn
WHERE 
cc.type = 'jcb' AND c.country = 'Singapore' 
INTERSECT
SELECT DISTINCT first_name, last_name
FROM 
credit_cards cc
JOIN
customers c
ON cc.ssn = c.ssn
WHERE 
cc.type = 'visa' AND c.country = 'Singapore';
 
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn as ssn, COALESCE(COUNT(cc.number),0) as num_cc
FROM
customers c
LEFT JOIN credit_cards cc
ON c.ssn = cc.ssn
GROUP BY c.ssn
ORDER BY num_cc DESC;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT ccc.ssn, ccc.type, COALESCE(count_cc.num_cc, 0) as number_credit_card
FROM
(
SELECT DISTINCT ssn as ssn, type as type
FROM(
(SELECT ssn FROM customers) c
CROSS JOIN
(SELECT type FROM credit_cards) cc)
ORDER BY ssn, type
) ccc
LEFT JOIN 
(
SELECT ssn, type, COUNT(*) as num_cc
FROM credit_cards
GROUP BY ssn, type
) count_cc
ON ccc.ssn = count_cc.ssn
AND ccc.type = count_cc.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.c_country, COUNT(ssn)
FROM
(SELECT DISTINCT c.ssn, c.country as c_country
FROM customers c
JOIN credit_cards cc
ON c.ssn = cc.ssn
JOIN transactions t
ON t.number = cc.number
JOIN merchants m
ON t.code = m.code
WHERE
c.country <> m.country) a
GROUP BY c_country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT x2.identifier, x1.type, x1.amount
FROM
(SELECT cc1.type, MAX(t1.amount) amount
FROM transactions t1
JOIN credit_cards cc1
ON t1.number = cc1.number
GROUP BY cc1.type
ORDER BY cc1.type) x1
JOIN 
(SELECT t1.identifier, cc1.type, t1.amount
FROM
transactions t1
JOIN credit_cards cc1
ON t1.number = cc1.number
) x2
ON x1.type = x2.type 
AND x1.amount = x2.amount 
ORDER BY x1.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t1.identifier, cc1.type , t1.amount
FROM transactions t1
JOIN credit_cards cc1
ON t1.number = cc1.number
WHERE t1.amount >= ALL
(
SELECT t2.amount
FROM transactions t2
JOIN credit_cards cc2
ON t2.number = cc2.number
WHERE cc1.type = cc2.type
) 
ORDER BY cc1.type;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m.code, m.name
FROM merchants m
WHERE m.code
NOT IN
(
SELECT DISTINCT m.code
FROM transactions t
JOIN credit_cards cc
ON t.number = cc.number
JOIN merchants m
ON t.code = m.code
WHERE t.amount >= 888
AND (cc.type LIKE 'visa%' OR cc.type LIKE 'diners-club%')
);
