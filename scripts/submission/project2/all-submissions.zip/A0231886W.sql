/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231886W                                           */
/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select
    distinct a.ssn
from
    credit_cards a
    left join
        transactions b
    on
        a.number = b.number
where
    a.type = 'visa'
and
    date(b.datetime) = '2017-12-24'
and
    amount != 0
;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select
    a.first_name
    , a.last_name
from
    customers a
    left join
        credit_cards b
    on
        a.ssn = b.ssn
group by
    a.ssn
having
    sum(case when b.type = 'visa' then 1 else 0 end) > 0
and
    sum(case when b.type = 'jcb' then 1 else 0 end) > 0
;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select
    a.ssn
    , count(distinct b.number) as credit_card_number
from
    customers a
    left join
        credit_cards b
    on
        a.ssn = b.ssn
group by
    a.ssn
;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select
    a.ssn
    , b.type as credit_card_type
    , count(b.number) as credit_card_number
from
    customers a
    left join
        credit_cards b
    on
        a.ssn = b.ssn
group by
    a.ssn
    , b.type
;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select
    c.country
    , count(1) as target_customer_number
from
    transactions a
    left join
        credit_cards b
    on
        a.number = b.number
    left join
        customers c
    on
        b.ssn = c.ssn
    left join
        merchants d
    on
        a.code = d.code
where
    c.country != d.country
group by
    c.country
;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select
    b.type
    , a.identifier
from
    transactions a
    left join
        credit_cards b
    on
        a.number = b.number
group by
    b.type
having
    a.amount = max(a.amount)
;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select
    c.type
    , c.identifier
from
    (
        select
            b.type
            , a.identifier
            , row_number() over(partition by b.type order by a.amount desc) rnk
        from
            transactions a
            left join
                credit_cards b
            on
                a.number = b.number
    ) c
where
    c.rnk = 1
;
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select
    a.code
    , a.name
from
    merchants a
    left join
        transactions b
    on
        a.code = b.code
    left join
        credit_cards c
    on
        b.number = c.number
where
    c.type in ('visa', 'diners-club')
group by
    a.code
having
    max(b.amount) < 888
;
