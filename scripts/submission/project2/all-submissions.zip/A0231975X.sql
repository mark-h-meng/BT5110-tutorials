/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231975X                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select DISTINCT c.ssn
From customers c, credit_cards k, merchants m, transactions t
Where c.ssn = k.ssn
AND k.number = t.number
AND m.code = t.code
AND k.type = 'visa'
AND EXTRACT(DAY FROM t.datetime) = 25;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select DISTINCT c.first_name, c.last_name, c.ssn
From customers c, credit_cards k
Where c.ssn = k.ssn
AND k.type = 'visa'
AND c.country = 'Singapore'
INTERSECT
Select DISTINCT c.first_name, c.last_name, c.ssn
From customers c, credit_cards k
Where c.ssn = k.ssn
AND k.type = 'jcb'
AND c.country = 'Singapore';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select c.ssn, count(k.number) as cards_number
From customers c LEFT OUTER JOIN credit_cards k ON c.ssn = k.ssn
GROUP BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select c.ssn, k.type, count(k.number) as cards_number
From customers c LEFT OUTER JOIN credit_cards k ON c.ssn = k.ssn
GROUP BY c.ssn, k.type
ORDER BY c.ssn, k.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select c.country, count(distinct c.ssn) as customers_number
From customers c
	left join credit_cards k
	on c.ssn = k.ssn
	left join transactions t
	on k.number = t.number
	left join merchants m
	on t.code = m.code
Where c.country <> m.country
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select k.type, t.identifier 
From transactions t natural join credit_cards k 
    left join
	(select max(t.amount) as max_amount, k.type
	from transactions t left join credit_cards k
	on t.number=k.number 
	group by k.type) A 
	on A.max_amount=t.amount 
Where A.type= k.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select k1.type, t1.identifier 
From transactions t1 natural join credit_cards k1
Where t1.amount >= ALL(
	Select t2.amount
	From transactions t2 natural join credit_cards k2
	Where k1.type = k2.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select m.code, m.name
From merchants m
	left join transactions t
	on m.code = t.code
	left join credit_cards k
	on t.number = k.number
Where k.type like '%visa%' or k.type like '%diners-club%'
GROUP BY m.code, m.name
HAVING max(t.amount) < 888;