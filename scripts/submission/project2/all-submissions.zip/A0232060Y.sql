/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0232060Y>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT distinct cr.ssn FROM credit_cards cr, transactions t 
WHERE (cr.type = 'visa' 
	   and t.datetime BETWEEN '2017-12-24 23:59:59.999999 '
	   AND'2017-12-25 23:59:59.999999')

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT distinct cu.first_name,cu.last_name FROM 
customers cu
INNER JOIN credit_cards d ON cu.ssn = d.ssn
INNER JOIN credit_cards d2 ON d.ssn = d2.ssn
WHERE
d.type = 'visa'
and d2.type= 'jcb'
and cu.country = 'Singapore'

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.ssn, count(*)
from customers c left join credit_cards t on c.ssn = t.ssn
group by t.ssn

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cr.ssn, cr.type, count(*) 
from credit_cards cr, customers c,transactions t
where c.ssn = cr.ssn
and t.number = cr.number
group by cr.ssn, cr.type 
ORDER BY cr.ssn DESC

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select q.country,count(distinct q.ssn)
from transactions t
inner join credit_cards cr on t.number = cr.number
inner join customers q on cr.ssn = q.ssn
inner join merchants me on me.code = t.code
where me.country != q.country
group by q.country 
order by count(*) desc

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cr.type, t.identifier, t.amount 
from transactions t
inner join credit_cards cr on t.number = cr.number
where t.amount = (
     select max(tr.amount)
     from transactions tr inner join credit_cards cr1
     on tr.number = cr1.number
     and cr.type = cr1.type)
group by t.identifier, cr.type, t.amount
ORDER BY t.identifier ASC

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select cr.type, t.identifier,t.amount
from transactions t
inner join credit_cards cr on t.number = cr.number
where t.amount >= all (
select t1.amount
from transactions t1 inner join 
	credit_cards cr1 on t1.number = cr1.number
where cr1.type = cr.type)

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT distinct me.code, me.name
from merchants me 
where me.code not in 
(select distinct me.code 
 from transactions tr 
inner join merchants me on tr.code = me.code
inner join credit_cards cr on cr.number = tr.number
 where tr.amount >= 888
 and (cr.type like '%visa%' or cr.type like '%diners-club%') )
 

