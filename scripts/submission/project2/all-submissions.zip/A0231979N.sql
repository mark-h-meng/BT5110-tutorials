/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231979N      */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/


/* Write your answer in SQL below: */

SELECT c.ssn
FROM customers c, credit_cards cc, transactions t
WHERE c.ssn = cc.ssn AND cc.number = t.number
AND cc.type= 'visa' AND t.datetime::date ='2017-12-25'


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT  c.first_name, c.last_name
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn  AND c.country= 'Singapore' AND cc.type = 'jcb'
INTERSECT 
SELECT  c.first_name, c.last_name
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn  AND c.country= 'Singapore' AND cc.type = 'visa'
 
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT  c.ssn,COUNT(cc.number) as result
FROM customers c LEFT JOIN credit_cards cc ON c.ssn= cc.ssn
GROUP BY c.ssn
ORDER BY result

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT sub.ssn, sub.type,COUNT(cc.number)
FROM  (SELECT DISTINCT c.ssn,cc.type FROM customers c,credit_cards cc) as sub
LEFT JOIN credit_cards cc ON sub.ssn = cc.ssn AND sub.type = cc.type
GROUP BY sub.ssn, sub.type
ORDER BY sub.ssn



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country, COUNT(*)
FROM customers c, credit_cards cc, transactions t, merchants m
WHERE c.ssn = cc.ssn AND t.number = cc.number AND t.code = m.code AND c.country != m.country
GROUP BY c.country

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below:  */


SELECT cc.type,t.identifier
FROM credit_cards cc, transactions t 
WHERE cc.number = t.number
AND (cc.type,t.amount) IN (SELECT cc.type,MAX(t.amount) FROM  credit_cards cc, transactions t WHERE cc.number = t.number GROUP BY cc.type)
ORDER BY cc.type
           
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT cc.type,t.identifier
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND NOT EXISTS ( SELECT t2.identifier FROM credit_cards cc2, transactions t2 WHERE cc2.number=t2.number AND cc2.type = cc.type AND t2.amount>t.amount)
ORDER BY cc.type


/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: 
	
		*/

SELECT DISTINCT m.code, m.name
FROM credit_cards cc, transactions t, merchants m
WHERE t.number = cc.number AND t.code = m.code 
AND NOT EXISTS (SELECT *
			FROM credit_cards cc, transactions t, merchants m2
			WHERE t.number = cc.number AND t.code = m2.code AND m2.code = m.code
			AND t.amount >= 888 and (cc.type = 'visa' or cc.type='diners-club'))
ORDER BY m.code, m.name	
				
				
				
				
				
				
				