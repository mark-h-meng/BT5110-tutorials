/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231952H>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.ssn
from customers c, credit_cards cc, transactions t
where c.ssn=cc.ssn and cc.number=t.number
and t.datetime between '2017-12-25 0:00:00' and '2017-12-25 24:00:00' and cc.type='visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct m.ssn, m.first_name, m.last_name
from (select distinct c.ssn, c.first_name, c.last_name
	  from customers c, credit_cards cc
	  where c.ssn=cc.ssn and cc.type='visa' and c.country='Singapore'
	  order by c.first_name) m, credit_cards cc
where m.ssn=cc.ssn and cc.type='jcb' 
order by m.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.ssn, count(cc.number) as number_of_credit_card 
from customers c left join credit_cards cc on c.ssn=cc.ssn
group by c.ssn
order by number_of_credit_card;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cc3.ssn, cc3.type, count(cc3.number) as number_of_credit_card 
from 
(select t.type, t.ssn, cc1.number
from (select distinct cc2.type, c.ssn
from credit_cards cc2, customers c) as t left join credit_cards cc1 
on t.ssn=cc1.ssn and t.type=cc1.type
order by t.ssn, t.type) as cc3
group by cc3.ssn, cc3.type
order by cc3.ssn, cc3.type, number_of_credit_card;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.country, count(distinct c.ssn)
from customers c, merchants m, (select m.code, cc.ssn, cc.number, t.identifier
from merchants m, transactions t, credit_cards cc
where t.code=m.code and cc.number=t.number) as tcm
where tcm.code=m.code and tcm.ssn=c.ssn and c.country<>m.country
group by c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select tttt.identifier, tttt.type, ttt.maxamount
from (select tt.type, max(tt.amount) as maxamount
	  from (select cc.type, cc.ssn, cc.number, t.identifier, t.amount
			from transactions t, credit_cards cc
			where cc.number=t.number) as tt
	  group by tt.type
	  order by tt.type) as ttt, (select cc.type, cc.number, t.identifier, t.amount
								 from transactions t, credit_cards cc
								 where cc.number=t.number) as tttt
where tttt.type=ttt.type and tttt.amount=ttt.maxamount
order by tttt.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select tt.identifier, tt.type, tt.amount
from (select cc.type, cc.ssn, cc.number, t.identifier, t.amount
from transactions t, credit_cards cc
where cc.number=t.number) as tt
where tt.amount>=all(
select tt1.amount 
	from (select cc.type, cc.ssn, cc.number, t.identifier, t.amount
		  from transactions t, credit_cards cc
		  where cc.number=t.number) as tt1 
	where tt1.type=tt.type)
order by tt.type;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select m.code, m.name
from merchants m, (select max(mm.amount) as maxamount, mm.code
from (select m.code, cc.ssn, cc.number, cc.type, t.identifier,t.amount
	  from merchants m, transactions t, credit_cards cc
	  where (t.code=m.code and cc.number=t.number) and 
	  (cc.type like '%visa%' or cc.type like '%diners-club%')) as mm
group by mm.code) as mmm
where m.code=mmm.code and maxamount<888
order by m.code;
