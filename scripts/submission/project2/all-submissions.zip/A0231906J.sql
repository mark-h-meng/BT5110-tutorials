/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231906J>                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.ssn
FROM credit_cards cr, transactions t, customers c
WHERE cr.number = t.number
AND c.ssn = cr.ssn
AND cr.type = 'visa'
AND DATE(t.datetime) ='2017-12-25';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT set.first_name, set.last_name
FROM (SELECT cr.ssn, c.first_name, c.last_name
	  FROM customers c, credit_cards cr
	  WHERE c.ssn = cr.ssn
	  AND c.country = 'Singapore'
	  AND cr.type ='visa'
	  
	  INTERSECT
	  
	  SELECT cr.ssn, c.first_name, c.last_name
	  FROM customers c, credit_cards cr
	  WHERE c.ssn = cr.ssn
	  AND c.country = 'Singapore'
	  AND cr.type ='jcb') set;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cr.ssn,  (CASE WHEN count(*) IS NULL THEN 0 ELSE count(*) END)
FROM customers c LEFT OUTER JOIN credit_cards cr ON c.ssn = cr.ssn
GROUP BY cr.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c1.ssn, cr1.type, count(cr2.number)
FROM (SELECT DISTINCT c.ssn
	  FROM customers c) AS c1
	  CROSS JOIN
	 (SELECT DISTINCT cr.type
	  FROM credit_cards cr) AS cr1
LEFT OUTER JOIN credit_cards cr2 ON cr1.type = cr2.type
AND c1.ssn = cr2.ssn
GROUP BY c1.ssn, cr1.type
ORDER BY c1.ssn, cr1.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country, count(DISTINCT c.ssn) AS customers_count
FROM customers c, merchants m, transactions t, credit_cards cr
WHERE cr.number = t.number
AND t.code = m.code
AND c.ssn = cr.ssn
AND NOT c.country = m.country
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier
FROM transactions t, credit_cards cr, (
	SELECT cr.type, MAX(t.amount) AS max
	FROM transactions t, credit_cards cr
	WHERE cr.number = t.number
	GROUP BY cr.type)m
WHERE t.number = cr.number
AND cr.type = m.type
AND t.amount = max;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier
FROM transactions t, credit_cards cr
WHERE t.amount >= ALL (
	SELECT t2.amount
	FROM transactions t2, credit_cards cr2
	WHERE t2.number = cr2.number
	AND cr.type = cr2.type)
AND t.number = cr.number;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT m.code, m.name
FROM merchants m, transactions t, credit_cards cr
WHERE m.code = t.code
AND cr.number = t.number
EXCEPT
SELECT DISTINCT m.code, m.name
FROM merchants m, transactions t, credit_cards cr
WHERE m.code = t.code
AND cr.number = t.number
AND (t.amount >= 888)
AND (cr.type LIKE '%visa%' OR cr.type LIKE '%diners-club%');

