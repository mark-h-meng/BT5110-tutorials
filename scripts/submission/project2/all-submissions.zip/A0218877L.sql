/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218877L                  							*/

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/

SELECT DISTINCT CC.SSN
FROM CREDIT_CARDS CC LEFT JOIN TRANSACTIONS T
ON CC.NUMBER = T.NUMBER 
WHERE CC.TYPE = 'visa' AND DATE(T.DATETIME) = '2017-12-25'; 

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/

SELECT CUST.FIRST_NAME, CUST.LAST_NAME 
FROM CUSTOMERS CUST INNER JOIN (
	SELECT DISTINCT CCJCB.SSN 
	FROM CREDIT_CARDS CCJCB INNER JOIN (
	SELECT DISTINCT SSN FROM CREDIT_CARDS WHERE TYPE = 'visa') CCVISA
	ON CCJCB.SSN = CCVISA.SSN WHERE CCJCB.TYPE = 'jcb') CC 
ON CUST.SSN = CC.SSN
WHERE COUNTRY = 'Singapore'; 

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/

SELECT CUST.SSN, COALESCE(CC.CC, 0) AS NO_OF_CREDIT_CARDS 
FROM CUSTOMERS CUST LEFT JOIN (
	SELECT DISTINCT SSN, COUNT (*) AS CC 
	FROM CREDIT_CARDS 
	GROUP BY SSN) CC
ON CUST.SSN = CC.SSN
ORDER BY NO_OF_CREDIT_CARDS, SSN;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/

SELECT CU_CC_CJ.SSN, CU_CC_CJ.TYPE, COALESCE(CUST_CC.CC, 0) AS NO_OF_CREDIT_CARDS FROM
(
SELECT CU.SSN, CC_CJ.TYPE FROM CUSTOMERS CU
CROSS JOIN 
(SELECT DISTINCT TYPE FROM CREDIT_CARDS) CC_CJ -- 20816 rows, full list of customers and credit cards
) CU_CC_CJ
LEFT JOIN 
(		-- CUSTOMERS WITH CC
SELECT CUST.SSN, CC.TYPE, CC.CC
FROM CUSTOMERS CUST LEFT JOIN (
	SELECT DISTINCT TYPE, SSN, COUNT (*) AS CC 
	FROM CREDIT_CARDS 
	GROUP BY SSN, TYPE) CC
ON CUST.SSN = CC.SSN
ORDER BY SSN, TYPE
) CUST_CC
ON CU_CC_CJ.SSN = CUST_CC.SSN AND CU_CC_CJ.TYPE = CUST_CC.TYPE
ORDER BY SSN, TYPE;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/

SELECT CUST_COUNTRY AS COUNTRY, COUNT(*) AS NO_OF_COUNTRY_CUST_WHO_PURCHASED_OVERSEAS FROM
(
SELECT DISTINCT SSN, CUST_COUNTRY FROM 
(
SELECT CUST.SSN, CUST.COUNTRY AS CUST_COUNTRY, CCTM.COUNTRY AS CCTM_COUNTRY 
FROM CUSTOMERS CUST INNER JOIN
	(
	SELECT CC.SSN, CC.NUMBER, TM.COUNTRY 
	FROM CREDIT_CARDS CC INNER JOIN 
		(
		SELECT T.NUMBER, T.CODE, M.COUNTRY 
		FROM TRANSACTIONS T INNER JOIN MERCHANTS M 
		ON T.CODE = M.CODE
		) TM	-- TRANSACTIONS FROM MERCHANT COUNTRY
	ON CC.NUMBER = TM.NUMBER
	) CCTM	-- CC DETAILS OF TRANSACTIONS FROM MERCHANT COUNTRY
ON CUST.SSN = CCTM.SSN
) CUST_CCTM	-- CUST DETAILS OF TRANSACTIONS FROM MERCHANT COUNTRY
WHERE CUST_COUNTRY <> CCTM_COUNTRY
) DIST_CUST_CCTM	-- CUST DETAILS OF TRANSACTIONS MADE OVERSEAS
GROUP BY CUST_COUNTRY
ORDER BY CUST_COUNTRY;

-- 1300 customers who purchased from different countries 		

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/

SELECT IDENTIFIER FROM  
(
SELECT T.*, CC.TYPE, T_CC_MAX.TYPE AS T_CC_MAX_TYPE, T_CC_MAX.MAX AS T_CC_MAX_MAX FROM TRANSACTIONS T 
INNER JOIN 
CREDIT_CARDS CC ON T.NUMBER = CC.NUMBER
LEFT JOIN (
SELECT TYPE, MAX(AMOUNT) AS MAX FROM
	(
	SELECT T.*, CC.TYPE
	FROM TRANSACTIONS T INNER JOIN CREDIT_CARDS CC
	ON T.NUMBER = CC.NUMBER
	) T_CC
GROUP BY TYPE
) T_CC_MAX
ON 
T.AMOUNT = T_CC_MAX.MAX AND 
CC.TYPE = T_CC_MAX.TYPE
) FINAL_MAX
WHERE T_CC_MAX_MAX IS NOT NULL AND T_CC_MAX_TYPE IS NOT NULL
ORDER BY IDENTIFIER;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/

SELECT IDENTIFIER FROM 
(
SELECT T.*, CC.TYPE , ROW_NUMBER() OVER (PARTITION BY TYPE ORDER BY AMOUNT DESC) AS CCTYPE_RANK 
FROM TRANSACTIONS T INNER JOIN CREDIT_CARDS CC
ON T.NUMBER = CC.NUMBER
) RANK
WHERE CCTYPE_RANK = 1
ORDER BY IDENTIFIER;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/

SELECT DISTINCT CODE, NAME FROM 
(
SELECT CODE, NAME, MAX(F_OTHERS) AS F2_OTHERS, MAX(F_VISA) AS F2_VISA, MAX(F_DINERSCLUB) AS F2_DINERSCLUB
FROM
(		-- To check if the merchants have >= 888 transactions under other types.
SELECT CODE, NAME,
CASE WHEN TYPE_DER = 'OTHERS' AND MAX_AMOUNT >= 888 THEN 1 ELSE 0 END AS F_OTHERS,
CASE WHEN TYPE_DER = 'VISA' AND MAX_AMOUNT >= 888 THEN 1 ELSE 0 END AS F_VISA,
CASE WHEN TYPE_DER = 'DINERS-CLUB' AND MAX_AMOUNT >= 888 THEN 1 ELSE 0 END AS F_DINERSCLUB
FROM
(		-- Merchants, CC type, Max Amount
SELECT T.CODE, M.NAME, CC_DER.TYPE_DER, MAX(T.AMOUNT) AS MAX_AMOUNT FROM TRANSACTIONS T
INNER JOIN
(		-- Grouping of CC types
SELECT *, 
CASE
	WHEN TYPE LIKE ('%visa%') THEN 'VISA'
	WHEN TYPE LIKE ('%diners-club%') THEN 'DINERS-CLUB'
	ELSE 'OTHERS'
END AS TYPE_DER
FROM CREDIT_CARDS
) CC_DER
ON T.NUMBER = CC_DER.NUMBER
INNER JOIN MERCHANTS M
ON T.CODE = M.CODE 
GROUP BY T.CODE, M.NAME, CC_DER.TYPE_DER
ORDER BY NAME, MAX_AMOUNT DESC
) T_M_CC_DER
) T_M_CC_DER_FLAG
GROUP BY CODE, NAME
ORDER BY NAME
) T_M_CC_DER_FLAG2
WHERE F2_OTHERS = 1 AND F2_VISA = 0 AND F2_DINERSCLUB = 0
ORDER BY NAME;



