/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232009U                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct cc.ssn
from credit_cards cc, transactions t
where cc.type = 'visa' and t.datetime between '2017-12-25' and '2017-12-26';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.first_name, c.last_name
from customers c
inner join credit_cards cc on c.ssn= cc.ssn
inner join credit_cards cc1 on c.ssn = cc1.ssn
where c.country = 'Singapore' and cc.type = 'visa' and cc1.type = 'jcb';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.ssn, (case when count(*) isnull then 0 else count(*) end) as num_of_cc_owned
from customers c
left outer join credit_cards cc on c.ssn = cc.ssn
group by c.ssn
order by c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cc.ssn, cc.type, (case when count(*) isnull then 0 else count(*) end) as num
from credit_cards cc
group by cc.ssn, cc.type
order by cc.ssn, cc.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.country, count(distinct c.ssn) as num_of_customers
from customers c
inner join credit_cards cc on c.ssn = cc.ssn
inner join transactions t on cc.number = t.number
inner join merchants m on t.code = m.code
where c.country <> m.country
group by c.country
order by num_of_customers asc;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t.identifier
from transactions t
inner join credit_cards cc on t.number = cc.number
where t.amount = (
select max(t1.amount)
from transactions t1
inner join credit_cards cc1 on t1.number = cc1.number
where cc1.type = cc.type);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t.identifier
from transactions t
inner join credit_cards cc on t.number = cc.number
where t.amount >= ALL(
select t1.amount
from transactions t1
inner join credit_cards cc1 on t1.number = cc1.number
where cc1.type = cc.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select m.code, m.name
from merchants m
except
select m1.code, m1.name
from transactions t
left outer join merchants m1 on m1.code = t.code
left outer join credit_cards cc on cc.number = t.number
where t.amount >= 888 and (cc.type like '%visa%' or cc.type like '%diners-club%');
