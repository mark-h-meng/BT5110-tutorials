/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/* Mukeshwaran Baskaran                                                                     */
/************************************************************************/
/* Student Number : A0165086Y                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT customers.ssn
FROM customers, credit_cards, transactions
WHERE customers.ssn = credit_cards.ssn AND credit_cards.number = transactions.number AND credit_cards.type = 'visa' 
AND transactions.datetime BETWEEN '2017-12-25' AND '2017-12-26';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT final.first_name, final.last_name
FROM (SELECT customers.ssn, customers.first_name, customers.last_name FROM customers, credit_cards
		WHERE customers.ssn = credit_cards.ssn
		AND customers.country = 'Singapore' AND credit_cards.type = ('visa')
		INTERSECT
		SELECT c2.ssn, c2.first_name, c2.last_name
		FROM customers AS c2, credit_cards AS cards2
		WHERE c2.ssn = cards2.ssn
		AND c2.country = 'Singapore' AND cards2.type = ('jcb')) AS final
ORDER BY final.first_name;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT customers.ssn, COUNT(credit_cards.number)
FROM customers
LEFT JOIN credit_cards ON customers.ssn = credit_cards.ssn
GROUP BY customers.ssn
ORDER BY COUNT(credit_cards.number);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cus1.ssn, cus2.type, COUNT(credit_cards.number)
FROM (SELECT DISTINCT customers.ssn
	  FROM customers) AS cus1
	  CROSS JOIN
	  (SELECT DISTINCT credit_cards.type
	  FROM credit_cards) AS cus2
LEFT JOIN credit_cards 
ON cus1.ssn = credit_cards.ssn AND cus2.type = credit_cards.type
GROUP BY cus1.ssn, cus2.type
ORDER BY cus1.ssn, cus2.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT customers.country, COUNT (DISTINCT customers.ssn) FROM customers, credit_cards, merchants, transactions
WHERE customers.ssn = credit_cards.ssn AND credit_cards.number = transactions.number 
AND transactions.code = merchants.code AND customers.country <> merchants.country
GROUP BY customers.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT transactions.identifier
FROM transactions, credit_cards, 
     (SELECT credit_cards.type, MAX(amount) as maximum
		FROM transactions, credit_cards
		WHERE transactions.number = credit_cards.number
		GROUP BY credit_cards.type) AS variable
WHERE transactions.number = credit_cards.number
AND   transactions.amount = maximum 
AND   credit_cards.type = variable.type;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT transactions.identifier FROM transactions, credit_cards 
WHERE transactions.number = credit_cards.number
AND transactions.amount >= ALL(
		SELECT transact2.amount
		FROM transactions AS transact2, credit_cards AS credit_cards2
		WHERE transact2.number = credit_cards2.number
		AND   credit_cards.type = credit_cards2.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT merchants.code, merchants.name
FROM merchants, transactions, credit_cards
WHERE merchants.code = transactions.code AND transactions.number = credit_cards.number
EXCEPT
SELECT merchants.code, merchants.name
FROM merchants, transactions, credit_cards
WHERE merchants.code = transactions.code AND transactions.number = credit_cards.number
AND (credit_cards.type LIKE '%visa%' OR credit_cards.type LIKE '%diners-club%') AND transactions.amount >= 888
ORDER BY code;