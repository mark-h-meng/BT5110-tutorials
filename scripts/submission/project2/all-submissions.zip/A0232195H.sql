/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232195H              */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn
FROM customers c, credit_cards e, transactions t
WHERE c.ssn=e.ssn AND e.number=t.number
AND e.type='visa'
AND (t.datetime>='2017-12-25 00:00:00.000000'AND t.datetime<'2017-12-26 00:00:00.000000');
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.first_name, c.last_name
From customers c, credit_cards e
WHERE c.ssn=e.ssn
AND c.country='Singapore'
AND e.type='jcb'
INTERSECT
SELECT c.first_name, c.last_name
From customers c, credit_cards e
WHERE c.ssn=e.ssn
AND c.country='Singapore'
AND e.type='visa';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select c.ssn, count (DISTINCT e.number) 
From customers c, credit_cards e
WHERE c.ssn=e.ssn
Group By c.ssn
UNION
SELECT c.ssn, 0
FROM customers c
Where c.ssn NOT IN (
       Select e.ssn
       From credit_cards e);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Select c.ssn,
      (CASE WHEN c.ssn NOT IN (
	  SELECT e.ssn
	  From credit_cards e)
	  Then 'O'
	  ELSE e.type END) As type,
	   (CASE WHEN c.ssn NOT IN (
	  SELECT e.ssn
	  From credit_cards e)
	  Then '0'
	  ELSE count (e.type)END ) As number
From customers c, credit_cards e
WHERE c.ssn=e.ssn
GROUP By c.ssn, e.type
ORDER By c.ssn, e.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, count(distinct c.ssn)
FROM customers c, credit_cards e, transactions t, merchants m
WHERE c.ssn=e.ssn
AND e.number=t.number
AND t.code=m.code
GROUP BY c.country
Except
SELECT c.country, count(distinct c.ssn)
FROM customers c, credit_cards e, transactions t, merchants m
WHERE c.ssn=e.ssn
AND e.number=t.number
AND t.code=m.code
AND c.country =m.country
GROUP BY c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT e.type, t.identifier
FROM transactions t, credit_cards e
WHERE t.number=e.number
GROUP BY e.type, t.identifier
Having t.amount =ANY
         (select  max(t.amount)
		 From transactions t, credit_cards e
		  Where t.number = e.number
		 Group By e.type);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT e.type, t.identifier
FROM transactions t, credit_cards e
WHERE t.number=e.number
AND t.amount>= ALL
 (select t.amount
 From transactions t);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
(SELECT DISTINCT m.code, m.name
From merchants m, transactions t, credit_cards e
WHERE e.number=t.number AND t.code=m.code
AND 'visa' in (e.type)
EXCEPT
SELECT DISTINCT m.code, m.name
From merchants m, transactions t, credit_cards e
WHERE e.number=t.number AND t.code=m.code
AND 'visa' in (e.type)
AND t.amount >=888)
UNION
(SELECT DISTINCT m.code, m.name
From merchants m, transactions t, credit_cards e
WHERE e.number=t.number AND t.code=m.code
AND 'diners-club' in (e.type)
EXCEPT
SELECT DISTINCT m.code, m.name
From merchants m, transactions t, credit_cards e
WHERE e.number=t.number AND t.code=m.code
AND 'diners-club' in (e.type)
AND t.amount >=888);
