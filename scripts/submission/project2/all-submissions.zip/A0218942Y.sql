/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218942Y                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.ssn
FROM transactions t
JOIN credit_cards cc ON cc.number = t.number
JOIN customers c ON c.ssn = cc.ssn
WHERE cc.type = 'visa' AND t.datetime:: date = '2017-12-25'
ORDER BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.first_name, c.last_name 
FROM customers c
WHERE c.ssn IN (
	(SELECT cc.ssn 
	FROM credit_cards cc WHERE cc.type = 'visa') 
	INTERSECT
	(SELECT cc.ssn 
	 FROM credit_cards cc WHERE cc.type = 'jcb'))
AND country ='Singapore';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, count(cc.type)
FROM customers c
LEFT OUTER JOIN credit_cards cc ON cc.ssn = c.ssn
GROUP BY c.ssn
ORDER BY COUNT;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, cc.type, count(cc.type)
FROM customers c
LEFT OUTER JOIN credit_cards cc ON cc.ssn = c.ssn
GROUP BY c.ssn, cc.type
ORDER BY c.ssn, cc.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country, count(DISTINCT c.ssn)
FROM customers c, credit_cards cc, merchants m, transactions t
WHERE cc.ssn = c.ssn
AND cc.number = t.number
AND t.code = m.code
AND c.country <> m.country
GROUP BY c.country
ORDER BY count DESC;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t1.identifier
FROM credit_cards cc1, transactions t1
WHERE cc1.number = t1.number AND
(cc1.type, t1.amount) IN (
SELECT cc2.type, MAX(t2.amount)
FROM credit_cards cc2, transactions t2
WHERE cc2.number = t2.number
GROUP BY cc2.type);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t1.identifier 
FROM credit_cards cc1, transactions t1
WHERE t1.number = cc1.number AND t1.amount >= ALL (
SELECT t2.amount
FROM credit_cards cc2, transactions t2
WHERE cc2.type = cc1.type AND t2.number = cc2.number);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m.code, m.name
FROM merchants m, 
(SELECT code 
 FROM merchants
 EXCEPT
 SELECT DISTINCT code
 FROM credit_cards cc, transactions t
 WHERE cc.number = t.number and t.amount >= 888 and (type like '%diners-club%' or type like '%visa%')) did
 WHERE m.code=did.code;


