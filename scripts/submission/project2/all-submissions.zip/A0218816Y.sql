/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218816Y             						        */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT cc.ssn
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND t.datetime BETWEEN '2017-12-25 00:00:00' AND '2017-12-25 23:59:59'
AND cc.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.first_name, c.last_name
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
AND c.country = 'Singapore'
AND cc.type = 'visa'
INTERSECT
SELECT c.first_name, c.last_name
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
AND c.country = 'Singapore'
AND cc.type = 'jcb';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, COUNT(DISTINCT cc.number) AS no_of_cc
FROM customers c
LEFT JOIN credit_cards cc ON cc.ssn = c.ssn
GROUP BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c1.ssn, c1.type, COALESCE(c2.count, 0) AS count
FROM (SELECT c.ssn, cc.type
	  FROM customers c, (SELECT DISTINCT cc.type
						 FROM credit_cards cc) AS cc) AS c1 LEFT OUTER JOIN (
							 SELECT c2.ssn, cc2.type, COUNT(DISTINCT cc2.number) AS count
							 FROM customers c2, credit_cards cc2
							 WHERE c2.ssn = cc2.ssn
							 GROUP BY c2.ssn, cc2.type
							 ORDER BY c2.ssn, cc2.type) AS c2
							 ON c1.ssn = c2.ssn
							 AND c1.type = c2.type
ORDER BY ssn, type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country, COUNT(DISTINCT c.ssn)
FROM customers c, credit_cards cc, transactions t, merchants m
WHERE c.ssn = cc.ssn
AND cc.number = t.number
AND t.code = m.code
AND c.country <> m.country
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
GROUP BY t.identifier, cc.type
HAVING t.amount >= ALL(
	SELECT t.amount
	FROM transactions t, credit_cards cc1
	WHERE cc1.number = t.number
	AND cc1.type = cc.type);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND t.amount >= ALL(
	SELECT t.amount
	FROM transactions t, credit_cards cc1
	WHERE t.number = cc1.number
	AND cc1.type = cc.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m1.code, m1.name
FROM merchants m1
WHERE m1.code NOT IN (
	SELECT m.code
	FROM merchants m, transactions t, credit_cards cc
	WHERE m.code = t.code
	AND t.number = cc.number
	AND t.amount >= 888
	AND cc.type LIKE '%visa%'
	UNION
	SELECT m.code
	FROM merchants m, transactions t, credit_cards cc
	WHERE m.code = t.code
	AND t.number = cc.number
	AND t.amount >= 888
	AND cc.type LIKE '%diners-club%');