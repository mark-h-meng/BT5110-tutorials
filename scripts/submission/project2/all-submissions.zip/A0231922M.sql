/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231922M */

/************************************************************************/
/*                                                                      */
/* Question 1.a         (26)                                                */
/*                                                                      */
/************************************************************************/
-- Find the ssn of customers who purchased something on Christmas day
-- 2017 with their Visa credit card (the credit card type is viss.)
SELECT distinct c.ssn
FROM customers c, transactions t,credit_cards cc
WHERE c.ssn = cc.ssn
and cc.number = t.number
and t.datetime between '2017-12-25 00:00:01' AND '2017-12-26 00:00:00'
and cc.type ='visa';


/************************************************************************/
/*                                                                      */
/* Question 1.b    (21)    (can we use order by?                                                 */
/*                                                                      */
/************************************************************************/
-- Find the names of customers in Singapore who own both a JCB and an Visa
-- credit card. Make sure that the same customer is not printed twice 
-- (note that your answer should cater for the fact that there could be, in this or in future instances
-- of the database, dierent customers with the same name: each dierent customer must be printed.
-- SELECT c.ssn, c.first_name, c.last_name
-- FROM customers c,credit_cards cc
-- WHERE c.ssn = cc.ssn
-- and c.country = 'Singapore'
-- and cc.type = 'visa'
-- group by c.ssn
-- intersect
-- SELECT c.ssn, c.first_name, c.last_name
-- FROM customers c,credit_cards cc
-- WHERE c.ssn = cc.ssn
-- and c.country = 'Singapore'
-- and cc.type ='jcb'
-- group by c.ssn;
SELECT  c.first_name, c.last_name
FROM customers c,credit_cards cc1, credit_cards cc2
WHERE c.ssn = cc1.ssn
and c.ssn = cc2.ssn
and c.country = 'Singapore'
and cc1.type = 'visa'
and cc2.type ='jcb'
group by c.ssn;


/************************************************************************/
/*                                                                      */
/* Question 1.c     1301    (need to write a case when count() is null..?                                                */
/*                                                                      */
/************************************************************************/
-- For each customer, how many credit cards the customer owns. 
-- Print the customer ssn and the number of credit cards owned. 
-- Print zero if a customer does not own any credit card

SELECT c.ssn, count (cc.number) as num_cards
FROM customers c left outer join credit_cards cc 
on c.ssn = cc.ssn
group by c.ssn
order by  num_cards asc;



/************************************************************************/
/*                                                                      */
/* Question 1.d    20816                                                     */
/*                                                                      */
/************************************************************************/
-- For each customer and for each credit card type, nd how many credit cards of that type the customer
-- owns. Print the customer ssn, the credit card type and the number of credit cards
-- of the given type owned. 
-- Print zero if a customer does not own any credit card of the given type.
SELECT c.ssn, temp.type, count(cc.number)
FROM customers c 
left outer join 
(SELECT c.ssn, cards.type
FROM customers c, (select distinct cc.type from credit_cards cc) as cards) as temp
on c.ssn = temp.ssn
left outer join credit_cards cc on c.ssn = cc.ssn
and temp.type = cc.type
group by  c.ssn, temp.type
order by c.ssn,temp.type;

-- COUNT(*) returns the number of items in a group. 
-- This includes NULL values and duplicates.

-- COUNT(column_name)
-- When a column name is used as an argument, 
-- it simply counts the total number of rows excluding the NULLs 
-- meaning it will not take NULLs into consideration.

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
-- For each country, nd the number of customers from this country who purchased something from a
-- merchant from a dierent country. You may ignore countries for which there is no such customer.
SELECT c.country,count(distinct c.ssn) as num_cust_buy_elsewhere
FROM customers c, merchants m, transactions t, credit_cards cc
WHERE t.code = m.code
and t.number = cc.number
and cc.ssn = c.ssn
and c.country <> m.country
group by c.country
order by c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f    16                                                    */
/*                                                                      */
/************************************************************************/
-- Print the identier of the transactions with the largest amount among all other transactions using the
-- same type of credit card. Use aggregate queries.

select t1.identifier, temp.type, temp.max_amt
from
	(select cc.type, max( t.amount) as max_amt
	FROM transactions t, credit_cards cc
	WHERE t.number = cc.number
	group by cc.type
	) as temp, transactions t1,credit_cards cc1
where t1.amount = temp.max_amt
and t1.number = cc1.number
and cc1.type = temp.type
order by temp.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g        16                                                 */
/*                                                                      */
/************************************************************************/

select t1.identifier,cc1.type,t1.amount
from transactions t1, credit_cards cc1
where cc1.number = t1.number 
and t1.amount >= all
	(select t2.amount
	from transactions t2, credit_cards cc2
	where cc2.number = t2.number
	and cc1.type = cc2.type)
order by cc1.type;

/************************************************************************/
/*                                                                      */
/* Question 1.h       7                                                */
/*                                                                      */
/************************************************************************/
-- Find the codes and names of merchants who did not entertain transactions for an amount
-- larger than or equal to 888 dollars for any kind of Visa or Diners Club credit card (the credit card type
-- contains visa or diners-club)

-- select m.code, m.name
-- from merchants m
-- where not exists (
-- select * from transactions t where m.code = t.code and t.amount >= 888

-- and not exists(
-- select * from credit_cards cc where cc.number = t.number
-- and cc.type like 'visa%' or cc.type like 'diners-club%'))
-- order by m.code;

select m.code, m.name
from merchants m
where not exists (
select *
from transactions t, credit_cards cc 
where cc.number = t.number 
and m.code = t.code
and t.amount >= 888
and (cc.type like 'visa%' or cc.type like 'diners-club%'));
