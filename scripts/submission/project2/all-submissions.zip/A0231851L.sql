/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231851L */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct cc.ssn
from credit_cards cc
where cc.number in(
		select tx.number
		from transactions tx
		where tx.datetime between '2017-12-25' and '2017-12-26'
	intersect
		select cc.number
		from credit_cards cc
		where cc.type='visa');

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select cs.first_name, cs.last_name
from customers cs
where cs.ssn in(
		select cs.ssn
		from customers cs
		where cs.country='Singapore'
		group by cs.ssn
	intersect
		select cc.ssn
		from credit_cards cc
		where cc.type='jcb'
		group by cc.ssn
		having cc.ssn in(
			select cc.ssn
			from credit_cards cc
			where cc.type='visa')
);

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select noc.ssn,count(noc.number)
from(
	select cs.ssn, cc.number
	from customers cs left join credit_cards cc on cc.ssn=cs.ssn) noc
group by noc.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select ssn_tp.ssn,ssn_tp.type,count(cc.number)
from (
	(select cs.ssn from customers cs) ssn 
	cross join 
	(select distinct cc.type from credit_cards cc) tp 
) ssn_tp left join credit_cards cc on ssn_tp.ssn=cc.ssn and ssn_tp.type=cc.type
group by ssn_tp.ssn,ssn_tp.type
order by ssn_tp.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select buy_oversea.country, count(*)
from(
	select distinct cs_tx.ssn,cs_tx.country
	from ((customers cs left join (select cc.ssn as ssn1,cc.number from credit_cards cc) card_no on cs.ssn=card_no.ssn1) cs_cc 
					left join transactions tx on cs_cc.number=tx.number) cs_tx
					left join merchants mt on cs_tx.code=mt.code
	where cs_tx.country<>mt.country
	) buy_oversea
group by buy_oversea.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select i_a_t.type,i_a_t.identifier
from(
	select tx.identifier,tx.amount, cc.type
	from transactions tx left join credit_cards cc on tx.number=cc.number) i_a_t
	left join (
		select i_a_t.type,max(i_a_t.amount)
		from (
			select tx.identifier,tx.amount, cc.type
			from transactions tx left join credit_cards cc on tx.number=cc.number) i_a_t
		group by i_a_t.type) max_table 
	on i_a_t.type=max_table.type
where i_a_t.amount=max_table.max and i_a_t.type=max_table.type
order by i_a_t.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select cc.type,tx.identifier 
from transactions tx join credit_cards cc on tx.number = cc.number
where tx.amount >= all(
	select tx1.amount
	from transactions tx1 join credit_cards cc1 on tx1.number = cc1.number
	where cc.type = cc1.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select mt.code,mt.name
from merchants mt
where mt.code not in(
select tx.code
from transactions tx left join credit_cards cc on tx.number=cc.number
where (cc.type like 'visa%' or cc.type like 'diners-club%') and tx.amount>=888
);

