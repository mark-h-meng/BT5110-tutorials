/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0093740E>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/* social security number of the different customers, purchased something on Christmas day 2017, VISA*/
/************************************************************************/
/* Write your answer in SQL below: */

SELECT * FROM customers;
SELECT * FROM credit_cards;
SELECT * FROM merchants;
SELECT * FROM transactions;


SELECT DISTINCT cc.ssn
FROM transactions t, credit_cards cc
WHERE cc.number = t.number
AND cc.type='visa'
AND t.datetime BETWEEN '2017-12-25 00:00:00' AND '2017-12-26 00:00:00';

--26 rows

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/* first and last names of the different customers in Singapore, own JCB & Visa */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.first_name, a.last_name
FROM (
 	(SELECT c.first_name, c.last_name, c.ssn
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
AND cc.type = 'visa'
AND c.country = 'Singapore') a
	INNER JOIN
	(SELECT c.first_name, c.last_name, c.ssn
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
AND cc.type = 'jcb'
AND c.country = 'Singapore') b
	on a.ssn = b.ssn
	
)
	GROUP BY a.ssn, a.first_name, a.last_name;

--Total 21 customers

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/* how many credit cards each customer owns, Print the customer's SSN and no. of credit cards owned, print 0 if no credit card */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, COUNT(cc.number)
FROM customers c LEFT OUTER JOIN credit_cards cc ON c.ssn = cc.ssn
GROUP BY c.ssn;

--Total 1301 rows

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/* how many credit cards of that type the customer owns, Print the customer's SSN, CC type, and No. of CC of the given type owned */
/* Print zero if a customer does not own any credit card of the given type. */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT a.ssn, a.type, 
   CASE WHEN b.nocc ISNULL THEN 0
	ELSE b.nocc END

	FROM (
		SELECT c.ssn, cc.type
			FROM customers c, credit_cards cc
			GROUP BY c.ssn, cc.type) a
		LEFT OUTER JOIN
		(SELECT c.ssn, cc.type,COUNT(cc.number) as nocc
			FROM customers c, credit_cards cc
			WHERE c.ssn=cc.ssn
			GROUP BY c.ssn, cc.type) b
		ON a.ssn=b.ssn AND a.type = b.type;

--Total 20816 rows

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/* For each country, No. of customers from this country who purchased something from a merchant from a different country */
/* ignore countries for which there is no such customer */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT
country, COUNT (DISTINCT ssn)
	FROM
	(
	SELECT DISTINCT c.ssn, c.country
	FROM customers c, merchants m, transactions t, credit_cards cc
	WHERE c.ssn = cc.ssn
	AND cc.number = t.number
	AND m.code = t.code
	AND c.country <> m.country
		) b
GROUP BY country ;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/* Print the identifier of the transactions with the largest amount among all other transactions using the same type of CC */
/* Use aggregate queries */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
t2.identifier
FROM transactions t2, credit_cards cc2
WHERE t2.number = cc2.number 
AND(cc2.type, t2.amount) IN
	(SELECT cc1.type, MAX(t1.amount)
     FROM transactions t1, credit_cards cc1
     WHERE t1.number=cc1.number
	 GROUP BY cc1.type);

--Total 16 rows

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/* Print the identifier of the transactions with the largest amount among all other transactions using the same type of CC */
/* Do not use aggregate functions and queries */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number AND t1.amount >= ALL
	(SELECT t2.amount
	 FROM transactions t2, credit_cards cc2
	 WHERE t2.number = cc2.number AND cc2.type = cc1.type);

--Total 16 rows

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/* Find codes & names of merchants who didn't entertain transactions for an amount >= $888 for any kind Visa or diners-club CC */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT m1.code, m1.name
FROM merchants m1
WHERE m1.code NOT IN (
    SELECT m.code
    FROM merchants m, transactions t, credit_cards cc
    WHERE m.code = t.code
    AND t.number = cc.number
    AND t.amount >= 888
    AND cc.type IN 
	( SELECT DISTINCT cc2.type FROM credit_cards cc2
	WHERE cc2.type LIKE 'visa%'
	OR cc2.type LIKE 'diners-club%' )
	);
	
--Total 7 rows
	
/* this is to find codes & names of the different merchants who did not entertain transactions for every type of CC */


