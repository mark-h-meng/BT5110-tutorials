/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0057228A>                  			    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cu.ssn, cc.type
FROM customers cu, credit_cards cc, transactions t
WHERE cu.ssn = cc.ssn
AND cc.number = t.number
AND cc.type = 'visa'
AND cast(t.datetime as date) = '2017-12-25';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cu.ssn, cu.first_name, cu.last_name
FROM customers cu, credit_cards cc
WHERE cu.ssn = cc.ssn
AND cc.type = 'visa' 
AND cu.country = 'Singapore'
INTERSECT
SELECT cu.ssn, cu.first_name, cu.last_name
FROM customers cu, credit_cards cc
WHERE cu.ssn = cc.ssn
AND cc.type = 'jcb' 
AND cu.country = 'Singapore';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cu.ssn, (CASE WHEN COUNT (cc.ssn) IS NULL THEN 0 ELSE COUNT (cc.ssn) END) as no_of_credit_cards
FROM customers cu LEFT OUTER JOIN credit_cards cc ON cu.ssn = cc.ssn
GROUP BY cu.ssn
ORDER BY no_of_credit_cards ASC;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cu.ssn,
SUM(CASE WHEN cc.type = 'diners-club-us-ca' THEN 1 ELSE 0 END) AS diners_club_us_ca, 
SUM(CASE WHEN cc.type = 'instapayment' THEN 1 ELSE 0 END) AS instapayment,
SUM(CASE WHEN cc.type = 'bankcard' THEN 1 ELSE 0 END) AS bankcard,
SUM(CASE WHEN cc.type = 'diners-club-carte-blanche' THEN 1 ELSE 0 END) AS diners_club_carte_blanche,
SUM(CASE WHEN cc.type = 'visa' THEN 1 ELSE 0 END) AS visa,
SUM(CASE WHEN cc.type = 'diners-clubs-international' THEN 1 ELSE 0 END) AS diners_club_international,
SUM(CASE WHEN cc.type = 'laser' THEN 1 ELSE 0 END) AS laser,
SUM(CASE WHEN cc.type = 'americanexpress' THEN 1 ELSE 0 END) AS americanexpress,
SUM(CASE WHEN cc.type = 'maestro' THEN 1 ELSE 0 END) AS maestro,
SUM(CASE WHEN cc.type = 'solo' THEN 1 ELSE 0 END) AS solo,
SUM(CASE WHEN cc.type = 'switch' THEN 1 ELSE 0 END) AS switch,
SUM(CASE WHEN cc.type = 'jcb' THEN 1 ELSE 0 END) AS jcb,
SUM(CASE WHEN cc.type = 'visa-electron' THEN 1 ELSE 0 END) AS visa_electron,
SUM(CASE WHEN cc.type = 'china-unionpay' THEN 1 ELSE 0 END) AS china_unionpay,
SUM(CASE WHEN cc.type = 'diners-club-enroute' THEN 1 ELSE 0 END) AS diners_club_enroute,
SUM(CASE WHEN cc.type = 'mastercard' THEN 1 ELSE 0 END) AS mastercard
FROM customers cu LEFT OUTER JOIN credit_cards cc ON cu.ssn = cc.ssn
GROUP BY cu.ssn, cc.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cu.country, COUNT (DISTINCT t.code)
FROM transactions t, customers cu, merchants m
WHERE t.code = m.code
AND cu.country <> m.country
GROUP BY cu.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier, t.amount as largestamount, cc.type
FROM transactions t, credit_cards cc 
WHERE t.number = cc.number
AND (t.amount, cc.type) IN (
	SELECT MAX (t.amount), cc.type
	FROM transactions t LEFT OUTER JOIN credit_cards cc ON t.number = cc.number
	GROUP BY cc.type )
ORDER BY largestamount DESC;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t1.identifier, t1.amount as largestamount, c1.type
FROM transactions t1, credit_cards c1 
WHERE t1.number = c1.number
AND NOT EXISTS (SELECT * 
		FROM transactions t2, credit_cards c2 
		WHERE t2.number = c2.number AND t2.amount > t1.amount AND c1.type = c2.type)
ORDER BY largestamount DESC;
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT m1.code, m1.name
FROM transactions t1 LEFT OUTER JOIN merchants m1 ON m1.code = t1.code LEFT OUTER JOIN credit_cards c1 ON t1.number = c1.number
WHERE NOT EXISTS (SELECT * 
		FROM transactions t2 LEFT OUTER JOIN merchants m2 ON m2.code = t2.code LEFT OUTER JOIN credit_cards c2 ON t2.number = c2.number
		WHERE (t2.amount >= 888 AND (c2.type LIKE '%visa%' or c2.type LIKE '%diners-club%' ) AND m1.name = m2.name));

