/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232322X 					        */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT cc.ssn 
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND (t.datetime >= '2017-12-25 00:00:01' AND t.datetime <= '2017-12-25 23:59:59')
AND cc.type = 'visa'
ORDER BY cc.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cs.first_name, cs.last_name 
FROM (SELECT c.ssn, c.first_name, c.last_name
	FROM credit_cards cc, customers c
	WHERE cc.type = 'visa'
	AND c.country = 'Singapore' 
	AND cc.ssn = c.ssn
	INTERSECT
	SELECT c.ssn, c.first_name, c.last_name
	FROM credit_cards cc, customers c
	WHERE cc.type = 'jcb'
	AND c.country = 'Singapore' 
	AND cc.ssn = c.ssn) AS cs
ORDER BY cs.first_name, cs.last_name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, COUNT(cc.number) AS number_of_cc_owned
FROM customers c 
LEFT OUTER JOIN credit_cards cc ON c.ssn= cc.ssn
GROUP BY c.ssn
ORDER BY number_of_cc_owned, c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */ 

SELECT c.ssn, cc.type, COUNT(credit_cards.number) as number_of_cc_owned
FROM customers c CROSS JOIN(
	SELECT DISTINCT credit_cards.type
	FROM credit_cards) AS cc
LEFT OUTER JOIN credit_cards ON c.ssn = credit_cards.ssn 
AND cc.type = credit_cards.type
GROUP BY c.ssn, cc.type
ORDER BY c.ssn, cc.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country, COUNT(DISTINCT c.ssn) AS number_of_customers
FROM customers c, credit_cards cc, merchants m, transactions t
WHERE c.ssn = cc.ssn
AND t.code = m.code
AND t.number = cc.number
AND c.country <> m.country
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier, cc.type, t.amount
FROM transactions t
LEFT OUTER JOIN credit_cards cc ON t.number=cc.number
WHERE (cc.type, t.amount) IN (
	SELECT cc.type, MAX(t1.amount)
	FROM transactions t1
	LEFT OUTER JOIN credit_cards cc ON t1.number = cc.number
	GROUP BY cc.type)
ORDER BY cc.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier, cc.type, t.amount
FROM credit_cards cc
LEFT OUTER JOIN transactions t ON cc.number = t.number
WHERE (cc.type, t.amount) >= ALL(
	SELECT cc1.type, t1.amount
	FROM credit_cards cc1
	LEFT OUTER JOIN transactions t1 ON cc1.number = t1.number
	WHERE cc.type = cc1.type)
ORDER BY t.identifier, cc.type;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT m.code, m.name
FROM merchants m
WHERE m.code NOT IN (
	SELECT m1.code
	FROM merchants m1
	INNER JOIN transactions t ON t.code = m1.code
	INNER JOIN credit_cards cc ON t.number = cc.number
	WHERE t.amount >= 888
	AND (cc.type LIKE '%visa%' OR cc.type LIKE '%diners-club%'))
ORDER BY m.code;