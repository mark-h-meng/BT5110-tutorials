/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218840E                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn
FROM transactions t, credit_cards cc
WHERE cc.type = 'visa'
AND DATE_TRUNC('day', t.datetime) = '2017-12-25';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.first_name, c.last_name
FROM customers c

INNER JOIN credit_cards ccv
ON c.ssn = ccv.ssn

INNER JOIN credit_cards ccj
ON c.ssn = ccj.ssn

WHERE c.country = 'Singapore'
AND ccv.type = 'visa'
AND ccj.type = 'jcb'
GROUP BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn, COALESCE(COUNT(cc.number),0) num
FROM customers c

LEFT JOIN credit_cards cc
ON cc.ssn = c.ssn

GROUP BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, cc.type, SUM(CASE WHEN c.ssn = cc.ssn THEN 1 ELSE 0 END)
FROM credit_cards cc, customers c
GROUP BY c.ssn, cc.type
ORDER BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT(c.ssn)
FROM customers c, merchants m
WHERE c.country <> m.country
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.type, n.identifier, n.cardmax
FROM credit_cards cc

INNER JOIN (SELECT t.number, t.identifier, MAX(t.amount) cardmax
		   FROM transactions t
		   GROUP BY t.identifier) AS n
		   
ON cc.number = n.number

INNER JOIN (SELECT cc.type, MAX(t.amount) AS maximum
			FROM credit_cards cc
			INNER JOIN transactions t
			ON t.number = cc.number
		   GROUP BY cc.type) AS m
			
ON m.type = cc.type
AND m.maximum = n.cardmax

GROUP BY cc.type, n.identifier, n.cardmax;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t1.identifier, t1.amount, cc1.type
FROM transactions t1, credit_cards cc1

WHERE t1.amount >= ALL (SELECT t2.amount
					  FROM transactions t2, credit_cards cc2
					  WHERE t2.number = cc2.number
					   AND cc1.type = cc2.type)

AND t1.number = cc1.number;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m.code, m.name
FROM merchants m

WHERE m.code NOT IN (

SELECT m.code
FROM transactions t

INNER JOIN merchants m
ON m.code = t.code 

INNER JOIN credit_cards cc
on cc.number = t.number 

WHERE t.amount >= 888
AND (cc.type LIKE 'visa%' OR cc.type LIKE 'diners%'));
