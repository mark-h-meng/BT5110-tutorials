/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231891A                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select 
  distinct cc.ssn 
from 
  credit_cards cc, 
  transactions t 
where 
  cc.number = t.number 
  and t.datetime BETWEEN TIMESTAMP '2017-12-25 00:00:00' 
  AND TIMESTAMP '2017-12-25 23:59:59' 
  and cc.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.first_name, a.last_name
from
	(select cc.ssn, c.first_name, c.last_name
	from customers c, credit_cards cc
	where c.ssn = cc.ssn
	and c.country = 'Singapore'
	and cc.type = 'jcb'
	group by cc.ssn, c.first_name, c.last_name
	intersect 
	select cc.ssn, c.first_name, c.last_name
	from customers c, credit_cards cc
	where c.ssn = cc.ssn
	and c.country = 'Singapore'
	and cc.type = 'visa'
	group by cc.ssn, c.first_name, c.last_name) a;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.ssn, count(cc.number)
from customers c 
left outer join credit_cards cc 
on cc.ssn = c.ssn
group by c.ssn
order by c.ssn Asc, count Asc;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.ssn, c.type, count(cc.number)
from( 
	(select ssn
	from customers) a
	cross join
	(select distinct type 
	from credit_cards) b
	) c
left join credit_cards cc 
on (cc.type, cc.ssn) =  (c.type, c.ssn)
group by c.ssn, c.type
order by c.ssn Asc, c.type Asc;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
 
select c.country, count(distinct c.ssn)
from customers c, merchants m, credit_cards cc, transactions t
where c.ssn = cc.ssn 
and cc.number = t.number
and t.code = m.code
and c.country <>m.country
group by c.country

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cc1.type, t1.identifier
from transactions t1, credit_cards cc1
where cc1.number = t1.number
and (cc1.type, t1.amount) in
	(SELECT cc2.type, max(t2.amount)
	from transactions t2, credit_cards cc2
	where  cc2.number = t2.number
	group by cc2.type)
order by cc1.type ASC, t1.identifier ASC;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT distinct cc1.type, t1.identifier
from credit_cards cc1, transactions t1
where cc1.number = t1.number
and t1.amount >= all(
	select t2.amount
	from credit_cards cc2, transactions t2
	where cc2.number = t2.number
	and cc1.type = cc2.type)
order by cc1.type ASC, t1.identifier ASC;
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select m.code, m.name
from merchants m 
except
select m.code, m.name
from transactions t, credit_cards cc, merchants m
where t.number = cc.number
and m.code = t.code 
and (cc.type like '%visa%' or cc.type like '%diners-club%')
and t.amount >= 888
	


