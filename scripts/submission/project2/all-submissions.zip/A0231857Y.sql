/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231857Y							                */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  DISTINCT ssn 
FROM 
  credit_cards 
WHERE 
  number in (
    SELECT 
      number 
    FROM 
      transactions 
    WHERE 
      datetime BETWEEN '2017-12-25 00:00:00' 
      AND '2017-12-25 23:59:59'
  ) 
  AND type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  first_name, 
  last_name 
FROM 
  customers c 
WHERE 
  ssn IN (
    SELECT 
      cc1.ssn 
    FROM 
      credit_cards cc1, 
      credit_cards cc2 
    WHERE 
      cc1.ssn = cc2.ssn 
      AND cc1.type = 'visa' 
      AND cc2.type = 'jcb'
  ) 
  AND country = 'Singapore';

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  ssn, 
  0 as cc_count 
FROM 
  customers 
where 
  ssn NOT IN (
    SELECT 
      ssn 
    FROM 
      credit_cards 
    GROUP BY 
      ssn
  ) 
UNION 
SELECT 
  ssn, 
  count(number) 
FROM 
  credit_cards 
GROUP BY 
  ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  c.ssn, 
  cc1.type, 
  COALESCE(count_cc, 0) AS count_cc 
FROM 
  customers c CROSS 
  JOIN (
    SELECT 
      type 
    FROM 
      credit_cards 
    GROUP BY 
      type
  ) AS cc1 
  LEFT JOIN (
    SELECT 
      ssn, 
      type, 
      COUNT(number) AS count_cc 
    FROM 
      credit_cards 
    GROUP BY 
      ssn, 
      type
  ) AS cc2 ON c.ssn = cc2.ssn 
  AND cc1.type = cc2.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  c.country, 
  COUNT(DISTINCT c.ssn) 
FROM 
  customers c, 
  credit_cards cc, 
  transactions t, 
  merchants m 
WHERE 
  c.ssn = cc.ssn 
  AND cc.number = t.number 
  AND t.code = m.code 
  AND c.country != m.country 
GROUP BY 
  c.country;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  identifier 
FROM 
  transactions tx1 
  JOIN credit_cards cc1 ON tx1.number = cc1.number 
  JOIN (
    SELECT 
      type, 
      max(amount) AS max_per_type 
    FROM 
      credit_cards cc2, 
      transactions tx2 
    WHERE 
      tx2.number = cc2.number 
    GROUP BY 
      type
  ) as max_cc_tx ON tx1.amount = max_cc_tx.max_per_type 
  AND max_cc_tx.type = cc1.type;


/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  cc_amount1.identifier 
FROM 
  (
    SELECT 
      type, 
      amount, 
      identifier 
    FROM 
      credit_cards cc1, 
      transactions tx1 
    WHERE 
      cc1.number = tx1.number
  ) AS cc_amount1 
  LEFT JOIN (
    SELECT 
      type, 
      amount 
    FROM 
      credit_cards cc2, 
      transactions tx2 
    WHERE 
      cc2.number = tx2.number
  ) AS cc_amount2 ON cc_amount1.type = cc_amount2.type 
  AND cc_amount1.amount < cc_amount2.amount 
WHERE 
  cc_amount2.amount is NULL;


/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  code, 
  name 
FROM 
  merchants m 
where 
  code NOT IN (
    SELECT 
      code 
    FROM 
      credit_cards cc 
      JOIN (
        SELECT 
          code, 
          number 
        FROM 
          transactions 
        WHERE 
          amount >= 888
      ) AS tx ON cc.number = tx.number 
    WHERE 
      type LIKE 'visa%' 
      OR type LIKE 'diners-club%'
      );