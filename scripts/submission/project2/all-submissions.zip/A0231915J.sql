/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231915J                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.ssn
from customers c inner join credit_cards b on c.ssn=b.ssn inner join transactions t on t.number=b.number
where b.type='visa' and to_date(t.datetime::text,'YYYY-MM-DD')='2017-12-25';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.first_name,c.last_name
from customers c,credit_cards b,credit_cards a
where c.ssn=b.ssn and c.ssn=a.ssn and b.type='jcb' and a.type='visa' and c.country='Singapore'
group by c.ssn,c.first_name,c.last_name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.ssn,count(b.number)
from customers c left outer join credit_cards b
on c.ssn=b.ssn
group by c.ssn
order by c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

create view DType As
select distinct(b1.type) from credit_cards b1;

select c.ssn,d.type,count(b.number)
from customers c cross join DType d left join credit_cards b on c.ssn=b.ssn and d.type=b.type
group by c.ssn,d.type
order by c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.country,count(distinct c.ssn) 
from customers c inner join credit_cards b on c.ssn=b.ssn inner join transactions t on b.number=t.number inner join merchants m on m.code=t.code
where c.country != m.country
group by c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t.identifier
from credit_cards b inner join transactions t on b.number=t.number
where t.amount=any(select T1.Amount from (select b1.type AS Type,MAX(t1.amount) AS Amount 
														 from credit_cards b1 inner join transactions t1 on b1.number=t1.number where b1.type=b.type
														 group by b1.type)AS T1);		
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t.identifier
from credit_cards b inner join transactions t on b.number=t.number
where t.amount>=ALL (select t1.amount from transactions t1 inner join credit_cards b1 on b1.number=t1.number where b.type=b1.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select m.code,m.name
from credit_cards b inner join transactions t on b.number=t.number inner join merchants m on m.code=t.code
where position ('visa' in b.type)>0 or position ('diners-club' in b.type)>0 
group by m.code,m.name
having MAX(t.amount)<888;


