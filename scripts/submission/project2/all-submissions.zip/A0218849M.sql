/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218849M                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT cust.ssn
FROM customers cust, credit_cards cc, transactions t
WHERE cust.ssn = cc.ssn
AND cc.number = t.number
AND cc.type = 'visa'
AND DATE(t.datetime) = '2017-12-25';


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cust.first_name, cust.last_name, cust.ssn
FROM customers cust, credit_cards cc
WHERE cust.ssn = cc.ssn
AND cust.country = 'Singapore'
AND cc.type = 'jcb' 
INTERSECT
SELECT cust.first_name, cust.last_name, cust.ssn
FROM customers cust, credit_cards cc
WHERE cust.ssn = cc.ssn
AND cust.country = 'Singapore'
AND cc.type = 'visa'   
ORDER BY first_name;


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cust.ssn, COALESCE(cc.cc, 0) AS no_of_credit_cards
FROM customers cust LEFT JOIN (
	SELECT DISTINCT ssn, COUNT(*) AS cc
	FROM credit_cards
	GROUP BY ssn) cc
ON cust.ssn = cc.ssn
ORDER BY no_of_credit_cards; 


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cu_cc_cj.ssn, cu_cc_cj.type, COALESCE(cust_cc.cc, 0) AS no_of_credit_cards 
FROM
(
	SELECT cu.ssn, cc_cj.type FROM customers cu
	CROSS JOIN
		(SELECT DISTINCT type FROM credit_cards) cc_cj
		) cu_cc_cj
	LEFT JOIN
	(
	SELECT cust.ssn, cc.type, cc.cc
	FROM customers cust LEFT JOIN (
		SELECT DISTINCT ssn, type, COUNT (*) AS cc
		FROM credit_cards
		GROUP BY ssn, type) cc
	ON cust.ssn = cc.ssn
	ORDER BY ssn, type
	) cust_cc
ON cu_cc_cj.ssn = cust_cc.ssn AND cu_cc_cj.type = cust_cc.type
ORDER BY ssn, type;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cust.country AS country, COUNT(*) AS no_of_country_cust_who_purchased_overseas
FROM customers cust, credit_cards cc, transactions t, merchants m
WHERE cust.ssn = cc.ssn
AND cc.number = t.number
AND t.code = m.code
AND cust.country != m.country
GROUP BY cust.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT identifier FROM 
(
	SELECT t.*, cc.type, t_cc_max.type AS t_cc_max_type, t_cc_max.max AS t_cc_max_max FROM transactions t
	INNER JOIN
	credit_cards cc on t.number = cc.number
		LEFT JOIN (
			SELECT type, MAX(amount) AS max from
			(
			SELECT t.*, cc.type
			FROM transactions t INNER JOIN credit_cards cc
			ON t.number = cc.number
			) t_cc
		GROUP BY type
		) t_cc_max
		ON
		t.amount = t_cc_max.max AND
		cc.type = t_cc_max.type
	) final_max
WHERE t_cc_max_max IS NOT NULL AND t_cc_max_type IS NOT NULL
ORDER BY identifier;


/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

(SELECT t.identifier, cc.type, t.amount AS max_amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'americanexpress'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'bankcard'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'china-unionpay'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'diners-club-carte-blanche'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'diners-club-enroute'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'diners-club-international'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'diners-club-us-ca'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'instapayment'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'jcb'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'laser'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'maestro'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'mastercard'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'solo'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'switch'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'diners-club-us-ca'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'visa'
ORDER BY amount DESC
LIMIT 1)
UNION
(SELECT t.identifier, cc.type, t.amount
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND cc.type = 'visa-electron'
ORDER BY amount DESC
LIMIT 1)
ORDER BY identifier;


/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m.code, m.name
FROM merchants m
EXCEPT 
SELECT DISTINCT m.code, m.name
FROM transactions t, credit_cards cc, merchants m
WHERE t.number = cc.number
AND m.code = t.code
AND (cc.type LIKE 'diners-club%'
OR cc.type LIKE 'visa%')
AND t.amount >888;

