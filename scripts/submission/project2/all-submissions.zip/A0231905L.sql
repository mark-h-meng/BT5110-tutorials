/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231905L                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  DISTINCT cc.ssn 
FROM 
  credit_cards cc, 
  transactions tr 
WHERE 
  cc.number = tr.number 
  AND cc.type = 'visa' 
  AND tr.datetime :: date = '2017-12-25';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  cu_names.first_name, 
  cu_names.last_name 
FROM 
  (
    SELECT 
      cu.first_name, 
      cu.last_name, 
      cu.ssn 
    FROM 
      customers cu, 
      credit_cards cc 
    WHERE 
      cu.ssn = cc.ssn 
      AND cu.country = 'Singapore' 
      AND cc.type = 'visa' 
    INTERSECT 
    SELECT 
      cu.first_name, 
      cu.last_name, 
      cu.ssn 
    FROM 
      customers cu, 
      credit_cards cc 
    WHERE 
      cu.ssn = cc.ssn 
      AND cu.country = 'Singapore' 
      AND cc.type = 'jcb'
  ) AS cu_names;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  cu.ssn, 
  COUNT(cc.number) 
FROM 
  customers cu 
  LEFT JOIN credit_cards cc ON cu.ssn = cc.ssn 
GROUP BY 
  cu.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  cc_list.ssn, 
  cc_list.type, 
  COALESCE (cc_count.card_count, 0) 
FROM 
  (
    SELECT 
      DISTINCT cc.type, 
      cu.ssn 
    FROM 
      customers cu, 
      credit_cards cc
  ) AS cc_list 
  LEFT JOIN (
    SELECT 
      cu.ssn, 
      cc.type, 
      COUNT(cc.number) AS card_count 
    FROM 
      customers cu 
      LEFT JOIN credit_cards cc ON cu.ssn = cc.ssn 
    GROUP BY 
      cu.ssn, 
      cc.type
  ) AS cc_count ON cc_count.ssn = cc_list.ssn 
  AND cc_count.type = cc_list.type 
ORDER BY 
  cc_list.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  cu.country, 
  COUNT (DISTINCT cu.ssn) 
FROM 
  customers cu, 
  credit_cards cc, 
  transactions tr, 
  merchants me 
WHERE 
  cu.ssn = cc.ssn 
  AND cc.number = tr.number 
  AND tr.code = me.code 
  AND cu.country <> me.country 
GROUP BY 
  cu.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  t.identifier 
FROM 
  transactions t, 
  credit_cards c, 
  (
    SELECT 
      cc.type, 
      MAX (tr.amount) AS maximum_amount 
    FROM 
      credit_cards cc, 
      transactions tr 
    WHERE 
      cc.number = tr.number 
    GROUP BY 
      cc.type
  ) as max_amounts 
WHERE 
  t.amount = max_amounts.maximum_amount 
  AND c.number = t.number 
  AND c.type = max_amounts.type;



/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  tr.identifier
FROM 
  transactions tr, 
  credit_cards cc 
WHERE 
  tr.number = cc.number 
  AND NOT EXISTS (
    SELECT 
      1 
    FROM 
      transactions tr2, 
      credit_cards cc2 
    WHERE 
      cc2.number = tr2.number 
      AND tr2.amount > tr.amount 
      AND cc2.type = cc.type
  );

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  me.code, 
  me.name 
FROM 
  merchants me 
EXCEPT 
SELECT 
  me.code, 
  me.name 
FROM 
  merchants me, 
  transactions tr, 
  credit_cards cc 
WHERE 
  me.code = tr.code 
  AND tr.number = cc.number 
  AND tr.amount >= 888 
  AND (
    cc.type LIKE 'visa%' 
    OR cc.type LIKE 'diners-club%'
  );
