/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231847B                   */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
  DISTINCT c.ssn 
FROM 
  customers c, 
  credit_cards cc, 
  transactions t 
WHERE 
  t.number = cc.number 
  AND cc.ssn = c.ssn 
  AND DATE(t.datetime) = '2017-12-25' 
  AND cc.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
  c.first_name, 
  c.last_name 
FROM 
  customers c 
WHERE 
  c.ssn IN (
    SELECT 
      DISTINCT c.ssn 
    FROM 
      customers c, 
      credit_cards cc1, 
      credit_cards cc2 
    WHERE 
      c.country = 'Singapore' 
      AND c.ssn = cc1.ssn 
      AND c.ssn = cc2.ssn 
	  AND cc1.type = 'jcb' 
      AND cc2.type = 'visa'
	  
  );


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  c.ssn, 
  COUNT(cc.number) AS number_of_cards 
FROM 
  customers c 
  LEFT OUTER JOIN credit_cards cc ON c.ssn = cc.ssn 
GROUP BY 
  c.ssn 
ORDER BY 
  number_of_cards ASC;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/*View created to store unique credit card type */ 
CREATE VIEW card_type AS 
SELECT 
  DISTINCT cc.type 
FROM 
  credit_cards cc;

SELECT 
  c.ssn, 
  card_type.type, 
  COUNT (cc.number) 
FROM 
  customers c CROSS 
  JOIN card_type 
  LEFT OUTER JOIN credit_cards cc ON c.ssn = cc.ssn 
  AND card_type.type = cc.type 
GROUP BY 
  card_type.type, 
  c.ssn 
ORDER BY 
  c.ssn ASC, 
  card_type.type ASC;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  c.country, 
  COUNT (DISTINCT c.ssn) AS customer_number 
FROM 
  customers c, 
  credit_cards cc, 
  merchants m, 
  transactions t 
WHERE 
  t.code = m.code 
  AND t.number = cc.number 
  AND cc.ssn = c.ssn 
  AND c.country <> m.country 
GROUP BY 
  c.country;


/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  cc.type, 
  t.identifier, 
  t.amount 
FROM 
  transactions t, 
  credit_cards cc 
WHERE 
  t.number = cc.number 
GROUP BY 
  cc.type, 
  t.identifier, 
  t.amount 
HAVING 
  t.amount >= ALL (
    SELECT 
      t1.amount 
    FROM 
      transactions t1, 
      credit_cards cc1 
    WHERE 
      t1.number = cc1.number 
      AND cc1.type = cc.type
  ) 
ORDER BY 
  cc.type ASC;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  cc.type, 
  t.identifier, 
  t.amount 
FROM 
  transactions t, 
  credit_cards cc 
WHERE 
  t.number = cc.number 
  AND t.amount >= ALL (
    SELECT 
      t1.amount 
    FROM 
      transactions t1, 
      credit_cards cc1 
    WHERE 
      t1.number = cc1.number 
      AND cc1.type = cc.type
  ) 
ORDER BY 
  cc.type ASC;
	 
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT 
  m.code, 
  m.name 
FROM 
  merchants m 
WHERE 
  m.code NOT IN (
    SELECT 
      t.code 
    FROM 
      transactions t, 
      credit_cards cc 
    WHERE 
      t.number = cc.number 
      AND (
        cc.type LIKE 'visa%' 
        OR cc.type LIKE 'diners-club%'
      ) 
      AND t.amount >= 888
  );
