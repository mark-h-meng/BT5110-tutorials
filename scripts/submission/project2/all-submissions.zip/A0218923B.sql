/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218923B                  */
/* Student Name : Zhou Yin                      */
/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn 
FROM credit_cards c, transactions t
WHERE t.number = c.number
AND cast("datetime" as date)  = '2017-12-25'
AND c.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cu.first_name, cu.last_name
FROM credit_cards c, customers cu
WHERE c.ssn = cu.ssn 
AND cu.country = 'Singapore'
AND c.type = 'jcb' 
AND c.ssn IN (SELECT DISTINCT crd.ssn
	FROM credit_cards crd
	WHERE crd.type='visa');

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, count(cr.number) FROM customers c
LEFT JOIN credit_cards cr
ON c.ssn = cr.ssn
GROUP BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, cr.type, count(cr.number) FROM customers c
LEFT JOIN credit_cards cr
ON c.ssn = cr.ssn
GROUP BY c.ssn, cr.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cu.country, count(cu.ssn)
FROM customers cu 
JOIN credit_cards cr ON cu.ssn = cr.ssn
JOIN transactions t ON cr.number=t.number
JOIN merchants m ON t.code = m.code
WHERE cu.country != m.country
GROUP BY cu.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT tr.identifier, tr.amount, cre.type
FROM transactions tr, credit_cards cre, 
    (SELECT cr.type, MAX(t.amount) as max_amount
    FROM transactions t 
    JOIN credit_cards cr ON t.number = cr.number
    GROUP BY cr.type) Z
WHERE tr.number = cre.number AND concat(tr.amount, cre.type) IN (concat(Z.max_amount, Z.type));


/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t1.identifier, cr1.type, t1.amount 
FROM transactions t1, credit_cards cr1
WHERE t1.number = cr1.number 
AND t1.amount >= ALL 
(SELECT t2.amount 
FROM transactions t2, credit_cards cr2
WHERE t2.number = cr2.number
AND cr2.type = cr1.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT me.code, me.name 
FROM merchants me
WHERE me.code NOT IN (
	SELECT m.code
	FROM merchants m
	LEFT JOIN transactions t ON m.code = t.code
	LEFT JOIN credit_cards cr ON t.number = cr.number
	WHERE t.amount>=888 
	AND (cr.type LIKE '%visa%' OR cr.type LIKE '%diners-club%')
);
