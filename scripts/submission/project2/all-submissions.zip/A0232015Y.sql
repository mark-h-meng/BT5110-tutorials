/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232015Y    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cm.ssn 
from customers cm, credit_cards cc, transactions t
where TO_CHAR(t.datetime,'yyyy-mm-dd')='2017-12-25'
and cc.type='visa'
and t.number=cc.number
and cc.ssn=cm.ssn
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cms.first_name, cms.last_name
from (select distinct(cm.ssn) ,cm.first_name, cm.last_name
	  from customers cm, credit_cards cc1, credit_cards cc2
where cc1.type='jcb'
and cc2.type='visa'
and cm.country='Singapore'
and cc1.ssn=cc2.ssn
and cm.ssn=cc2.ssn) as cms

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cm.ssn, (case when count(cc.*) isnull 
				then 0 else count(cc.*) 
				end) as number_of_cards
from customers cm
left outer join credit_cards cc on cm.ssn=cc.ssn
group by cm.ssn
order by number_of_cards asc
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cm.ssn, t4.type, count(cc.number) as number_of_cards
from customers cm
cross join (select distinct type 
			from credit_cards) as t4
left outer join credit_cards cc 
	on cm.ssn=cc.ssn and cc.type=t4.type
group by cm.ssn,t4.type
order by cm.ssn asc, t4.type asc, number_of_cards asc
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cm.country, count(*)
from customers cm
where cm.ssn in (
	select distinct(cm.ssn)
	from customers cm, merchants m, credit_cards cc, transactions t
	where m.code=t.code
	and t.number=cc.number
	and cc.ssn=cm.ssn
	and cm.country <> m.country)
group by cm.country
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select tt.identifier
from (select cc.type, max(t.amount)as max_amount
	from credit_cards cc, transactions t
	where t.number=cc.number
	group by cc.type) as mx
left join (select * 
		   from credit_cards cc, transactions t
	       where t.number=cc.number ) as tt
	on mx.type=tt.type and mx.max_amount=tt.amount
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select x1.identifier
from (select *
	 from transactions t1, credit_cards cc1
	 where t1.number=cc1.number) 
	 as x1
where x1.amount>= all (
	select t2.amount
	from credit_cards cc2, transactions t2
	where t2.number=cc2.number
	and x1.type=cc2.type)

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select code, name 
from merchants
where code not in (
	select m.code 
	from merchants m,credit_cards cc, transactions t
	where m.code=t.code
	and cc.number=t.number
	and t.amount>=888
	and (cc.type='visa' or cc.type='diners-club')
)
