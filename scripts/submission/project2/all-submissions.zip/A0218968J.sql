/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218968J                */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn
FROM credit_cards cc, transactions t
WHERE cc.type = 'visa' 
AND t.number = cc.number
AND t.datetime >= '2017-12-25 00:00:00' 
AND t.datetime < '2017-12-26 00:00:00'
ORDER BY cc.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT r.first_name, r.last_name FROM (
	SELECT c.ssn, c.first_name, c.last_name
	FROM credit_cards cc, customers c
	WHERE cc.type = 'visa' 
	AND c.country='Singapore' AND cc.ssn = c.ssn
	INTERSECT
	SELECT c.ssn, c.first_name, c.last_name
	FROM credit_cards cc, customers c
	WHERE cc.type = 'jcb' 
	AND c.country='Singapore' AND cc.ssn = c.ssn
) AS r
ORDER BY r.first_name, r.last_name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
SELECT c.ssn, COUNT(cc.number) AS NumberOfCards 
FROM customers c 
LEFT JOIN credit_cards cc ON c.ssn = cc.ssn
GROUP BY c.ssn
ORDER by NumberOfCards, c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/

SELECT dc.ssn, dcc.type, COUNT(cc.number)
FROM (
	SELECT DISTINCT c.ssn
	FROM customers c
	) dc
	CROSS JOIN 
	(
	SELECT DISTINCT cc.type
	FROM credit_cards cc
	) dcc
	LEFT JOIN credit_cards cc ON dc.ssn = cc.ssn AND dcc.type = cc.type
GROUP BY dc.ssn, dcc.type
ORDER BY dc.ssn, dcc.type;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/

SELECT c.country, COUNT(DISTINCT c.ssn) AS Number_Of_Customers
FROM customers c 
INNER JOIN credit_cards cc ON c.ssn = cc.ssn
INNER JOIN transactions t ON t.number = cc.number
INNER JOIN merchants m ON t.code = m.code
WHERE c.country <> m.country
GROUP BY c.country
ORDER BY c.country;	

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
SELECT t.identifier
FROM transactions t  
LEFT JOIN credit_cards cc ON t.number = cc.number
WHERE ( cc.type, t.amount ) IN (
	SELECT cc.type, MAX(t2.amount)
	FROM transactions t2
	LEFT JOIN credit_cards cc ON t2.number = cc.number
	GROUP BY cc.type);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
SELECT t.identifier
FROM credit_cards cc1
LEFT JOIN transactions t ON cc1.number = t.number 
WHERE (cc1.type, t.amount) >= ALL( 
	SELECT cc2.type, t2.amount
	FROM credit_cards cc2 
	LEFT JOIN transactions t2 ON cc2.number = t2.number
	WHERE cc2.type = cc1.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
SELECT DISTINCT m.code, m.name
FROM merchants m 
WHERE m.code NOT IN (
	SELECT m.code
	FROM merchants m 
	INNER JOIN transactions t ON t.code=m.code
	INNER JOIN credit_cards cc ON t.number = cc.number
	WHERE t.amount >= 888
	AND (cc.type LIKE '%visa%' OR cc.type LIKE '%diners-club%'))
ORDER BY m.code;