/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0124294H                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
select distinct ssn from credit_cards cc where cc.number in 
(select distinct number from transactions trans where CAST(trans.datetime AS DATE) = '2017-12-25') and cc.type = 'visa' order by ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
select first_name,last_name from customers cust where cust.ssn in 
((select cc.ssn from credit_cards cc where "type" = 'jcb') intersect (select cc.ssn from credit_cards cc where "type" = 'visa'))
and country ='Singapore';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                               */
/************************************************************************/
select ssn,
	CASE when counter is null
	then 0 
	else counter end	
from 
(select cust.ssn, tem.counter from customers cust left outer join 
(select ssn, count(*) as counter FROM credit_cards group by ssn) tem ON tem.ssn = cust.ssn) as tempo;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
select ssn,cardtype,
	CASE when counter is null
	then 0 
	else counter end	
from 
(select tempo.ssn,tempo.cardtype,tem.counter from 
(select cust.ssn,cc.cardtype from (select distinct "type" as cardtype from credit_cards) cc, customers cust) tempo
left outer join 
(select ssn, "type", count(*) as counter FROM credit_cards
 group by "type",ssn) tem on tem.ssn = tempo.ssn and tem.type = tempo.cardtype) as tt;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
select cust_ctry,count(distinct cust_ssn) from 
(select cc.ssn as cust_ssn, tran.number as cust_card,mer.country as merchant_ctry, cust.country as cust_ctry 
from transactions tran,merchants mer,credit_cards cc, customers cust
where tran.code = mer.code and cc.number = tran.number  and cust.ssn = cc.ssn) tempctry 
where not merchant_ctry = cust_ctry group by cust_ctry order by cust_ctry;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
SELECT tablethree.identifier
FROM (select trans.identifier,trans.amount,cc.type from transactions trans,credit_cards cc
where trans.number = cc.number) tablethree 
INNER JOIN
(select tableone.type,max(tableone.amount) as largest_amt from
(select trans.identifier,trans.amount,cc.type from transactions trans,credit_cards cc
where trans.number = cc.number) tableone group by tableone.type) tabletwo 
ON tabletwo.type = tablethree.type and tabletwo.largest_amt = tablethree.amount;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
SELECT t1.identifier FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number AND t1.amount >= ALL
(SELECT t2.amount
FROM transactions t2, credit_cards cc2
WHERE t2.number = cc2.number AND cc2.type = cc1.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
select mer.code, mer.name from merchants mer, 
(select code from merchants
except
select distinct code from transactions trans,credit_cards cc where 
cc.number = trans.number and amount >= 888 and (type like '%visa%' or type like '%diners-club%')) codes
where mer.code=codes.code;







