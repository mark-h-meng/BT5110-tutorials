/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0119542H                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn
FROM customers c, credit_cards cc, transactions t
WHERE cc.ssn = c.ssn
AND t.number = cc.number
AND date_trunc('day',t.datetime) = '2017-12-25 00:00:00'
AND cc.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DROP VIEW IF EXISTS distinct_customer_jcb_visa;

CREATE VIEW distinct_customer_jcb_visa AS
		SELECT DISTINCT c.first_name, c.last_name, c.ssn
		FROM customers c, credit_cards cc
		WHERE cc.ssn = c.ssn
		AND c.country = 'Singapore'
		AND cc.type = 'visa' 
	INTERSECT
		SELECT DISTINCT  c2.first_name, c2.last_name, c2.ssn 
		FROM customers c2, credit_cards cc2
		WHERE cc2.ssn = c2.ssn
		AND c2.country = 'Singapore'
		AND cc2.type = 'jcb' ;
		
SELECT first_name, last_name
FROM distinct_customer_jcb_visa;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, COUNT(cc.number) AS "number_of_credit_cards"
FROM customers c
	LEFT JOIN credit_cards cc ON c.ssn = cc.ssn
GROUP BY c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DROP VIEW IF EXISTS customer_card_type;

CREATE VIEW customer_card_type AS
SELECT *
FROM customers c CROSS JOIN (SELECT DISTINCT cc.type 
							 FROM credit_cards cc) AS c_type;

SELECT cct.ssn, cct.type, count(number)
FROM customer_card_type cct LEFT OUTER JOIN credit_cards cc
ON (cct.ssn, cct.type) = (cc.ssn, cc.type)
GROUP BY cct.ssn, cct.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT(DISTINCT c.ssn)
FROM customers c NATURAL JOIN credit_cards cc NATURAL JOIN  transactions t LEFT JOIN merchants m ON t.code=m.code
WHERE c.country <>  m.country
GROUP BY c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.type, t.identifier, t.amount
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND (cc.type, t.amount) IN(
	SELECT cc2.type, MAX(t2.amount)
	FROM credit_cards cc2, transactions t2
	WHERE cc2.number = t2.number
	GROUP BY cc2.type);
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DROP VIEW IF EXISTS type_identifier_amt;

CREATE VIEW type_identifier_amt AS 
SELECT cc.type, t1.identifier, t1.amount
FROM transactions t1, credit_cards cc
WHERE t1.number = cc.number;

SELECT tia1.type, tia1.identifier, tia1.amount
FROM type_identifier_amt tia1
WHERE tia1.amount>= ALL(
	SELECT tia2.amount 
	FROM type_identifier_amt tia2
	WHERE tia1.type = tia2.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m.code, m.name
FROM credit_cards cc LEFT OUTER JOIN transactions t ON cc.number = t.number 
LEFT OUTER JOIN merchants m on m.code = t.code
WHERE cc.type LIKE 'visa%' OR cc.type LIKE 'diners-club%'
GROUP BY m.code, m.name
HAVING MAX(t.amount)<888;