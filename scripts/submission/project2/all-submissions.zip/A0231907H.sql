/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <replace with your student number>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.ssn
FROM customers c, credit_cards cd, transactions t
WHERE EXTRACT(YEAR FROM t.datetime) = '2017'
AND EXTRACT(MONTH FROM t.datetime) = '12'
AND EXTRACT(DAY FROM t.datetime) = '25'
AND cd.number = t.number
AND c.ssn = cd.ssn
AND cd.type = 'visa'

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.first_name, c.last_name
FROM (SELECT c1.ssn, c1.first_name, c1.last_name
      FROM  customers c1 
	  LEFT JOIN credit_cards cd1 ON c1.ssn = cd1.ssn
      WHERE c1.country = 'Singapore'
      AND cd1.type = 'jcb'
      INTERSECT
      SELECT c2.ssn, c2.first_name, c2.last_name
      FROM customers c2 
	  LEFT JOIN credit_cards cd2 ON c2.ssn = cd2.ssn
      WHERE c2.country = 'Singapore'
      AND cd2.type = 'visa') AS c
ORDER BY c.first_name

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, count(*)
FROM customers c
LEFT JOIN  credit_cards cd ON c.ssn = cd.ssn
GROUP BY c.ssn
ORDER BY c.ssn

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn,cd.type,count(cd2.number) as num_of_cards
FROM (SELECT DISTINCT c1.ssn FROM customers c1) AS c
      CROSS JOIN 
      (SELECT DISTINCT cd1.type FROM credit_cards cd1) AS cd
      LEFT JOIN credit_cards cd2 
	  ON cd2.ssn = c.ssn AND cd2.type = cd.type
GROUP BY c.ssn, cd.type

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country, count(DISTINCT c.ssn) AS num
FROM customers c
LEFT JOIN credit_cards cd ON c.ssn = cd.ssn
LEFT JOIN transactions t ON cd.number = t.number
LEFT JOIN merchants m ON t.code = m.code
WHERE c.country <> m.country
GROUP BY c.country

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t1.identifier, cd1.type
FROM transactions t1, credit_cards cd1
WHERE t1.number = cd1.number
AND t1.amount = ALL (
  SELECT MAX(t2.amount)
  FROM transactions t2, credit_cards cd2
  WHERE t2.number = cd2.number
  AND cd1.type = cd2.type)

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t1.identifier, cd1.type
FROM transactions t1, credit_cards cd1
WHERE t1.number = cd1.number
AND t1.amount >= ALL (
  SELECT t2.amount
  FROM transactions t2, credit_cards cd2
  WHERE t2.number = cd2.number
  AND cd1.type = cd2.type)
  
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m.code, m.name
FROM merchants m 
WHERE m.code NOT IN
  (SELECT m1.code
   FROM merchants m1, transactions t1, credit_cards cd1
   WHERE t1.code = m1.code
   AND t1.number = cd1.number
   AND t1.amount >= 888
   AND cd1.type like '%visa%')
INTERSECT
SELECT m.code, m.name
FROM merchants m 
WHERE m.code NOT IN
   (SELECT m2.code
   FROM merchants m2, transactions t2, credit_cards cd2
   WHERE t2.code = m2.code
   AND t2.number = cd2.number
   AND t2.amount >= 888
   AND cd2.type like '%diners-club%')
   
/*
SELECT DISTINCT cd.type FROM credit_cards cd
WHERE cd.type like '&diners-club%'
OR cd.type like '%visa%'

OUTPUT: visa visa-electron
*/
