/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232004A                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cu.ssn
from credit_cards cr, transactions tr, customers cu
where cu.ssn = cr.ssn
and cr.number = tr.number
and date(tr.datetime) = '2017-12-25'
and cr.type = 'visa'
group by cu.ssn
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cu2.first_name, cu2.last_name
from	(select cr1.ssn, cu1.first_name, cu1.last_name
		from customers cu1, credit_cards cr1
		where cu1.ssn = cr1.ssn
		and cu1.country = 'Singapore'
		and cr1.type = 'visa'
		group by cr1.ssn, cu1.first_name, cu1.last_name, cr1.type) as vi, customers cu2, credit_cards cr2
where cu2.ssn = cr2.ssn
and cr2.ssn = vi.ssn
and cr2.type = 'jcb'
group by cr2.ssn, cu2.first_name, cu2.last_name
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cu.ssn, count(cr.ssn)
from customers cu
	left join credit_cards cr on cu.ssn = cr.ssn
group by cu.ssn
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cu.ssn, cr.type, count(cr.type)
from customers cu
	left join credit_cards cr on cu.ssn = cr.ssn
group by cu.ssn, cr.type
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select co.country, count(*)
from 	(select cu.ssn, cu.country
		from customers cu, credit_cards cr, merchants me, transactions tr
		where cr.number = tr.number
		and cu.ssn = cr.ssn
		and me.code = tr.code
		and cu.country <> me.country
		group by cu.ssn) as co
group by co.country
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select tr1.identifier, cr1.type
from transactions tr1, credit_cards cr1, 	(select cr2.type, max(tr2.amount)
											from transactions tr2, credit_cards cr2
											where tr2.number = cr2.number
											group by cr2.type) as trcr
where tr1.number = cr1.number
and trcr.type = cr1.type
and tr1.amount = trcr.max
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select tr1.identifier, cr1.type
from transactions tr1, credit_cards cr1
where tr1.number = cr1.number
and tr1.amount >= all	(select tr2.amount
					  	from transactions tr2, credit_cards cr2
					 	where tr2.number = cr2.number
						and cr1.type = cr2.type)
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select me2.code,me2.name
from merchants me2
where not exists	(select me.name
					from merchants me, credit_cards cr, transactions tr
					where cr.number = tr.number
					and me.code = tr.code 
					and (cr.type like '%visa%' or cr.type like '%diners-club%')
					and tr.amount >= 888
					and me.name = me2.name)
