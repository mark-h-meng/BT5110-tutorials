/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218820J (Yu Zhe)                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn
FROM customers c,credit_cards cc,transactions t
WHERE c.ssn=cc.ssn
AND t.number=cc.number
AND Date(t.datetime)='2017-12-25'
And cc.type='visa'
ORDER BY c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT n.first_name, n.last_name
FROM (SELECT DISTINCT c.ssn, c.first_name, c.last_name
FROM customers c,credit_cards cc
WHERE c.ssn=cc.ssn
AND cc.type='jcb'
AND c.country='Singapore'
INTERSECT
SELECT DISTINCT c.ssn, c.first_name, c.last_name
FROM customers c,credit_cards cc
WHERE c.ssn=cc.ssn
AND cc.type='visa'
AND c.country='Singapore') AS n
ORDER BY first_name,last_name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, COUNT(cc.number)
FROM customers c LEFT JOIN credit_cards cc ON c.ssn=cc.ssn
GROUP BY c.ssn
ORDER BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cr_ty.ssn,cr_ty.type, COUNT(cc.number)
FROM (SELECT DISTINCT credit_cards.type,customers.ssn
FROM credit_cards, customers) AS cr_ty LEFT JOIN credit_cards cc
ON (cr_ty.ssn=cc.ssn AND cr_ty.type= cc.type)
GROUP BY cr_ty.ssn,cr_ty.type
ORDER BY cr_ty.ssn,cr_ty.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country,COUNT(c.ssn)
FROM customers c, merchants m,transactions t,credit_cards cc
WHERE m.code=t.code
AND t.number=cc.number
AND cc.ssn=c.ssn
AND c.country !=m.country
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM credit_cards c,transactions t
WHERE c.number=t.number
AND (c.type,t.amount) IN (SELECT c.type,MAX(t.amount) FROM credit_cards c,transactions t
WHERE c.number=t.number GROUP BY c.type);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t1.identifier
FROM credit_cards c1,transactions t1
WHERE c1.number=t1.number
AND NOT EXISTS(
SELECT *
FROM transactions t2, credit_cards c2
WHERE t2.number = c2.number
AND c1.type = c2.type
AND t1.amount < t2.amount);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT m.code, m.name
FROM merchants m,transactions t,credit_cards cc
WHERE m.code=t.code
AND t.number=cc.number
EXCEPT
SELECT DISTINCT m.code, m.name
FROM merchants m,transactions t,credit_cards cc
WHERE m.code=t.code
AND t.number=cc.number
AND t.amount>=888
AND (cc.type LIKE 'visa%' OR cc.type LIKE 'diners-club%')

