/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232022A     Mingzhe Xu                            */

/************************************************************************/
/*                                                                      */

/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select  a.ssn from (
	select * from credit_cards a
	left join
	transactions b
	on a.number=b.number
	where substr(cast(b.datetime as VARCHAR(32)),1,10) = '2017-12-25'
	and a.type = 'visa') as a
group by ssn;


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select first_name, last_name 
from credit_cards a
inner join credit_cards b
on a.ssn = b.ssn
inner join customers c
on c.ssn = b.ssn
where a.type= 'visa'
and b.type = 'jcb'
and c.country='Singapore'
group by c.ssn;



/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select a.ssn, count(b.number) as num from customers a
left join credit_cards b
on a.ssn=b.ssn
group by a.ssn;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */   


select t2.ssn,t2.type,coalesce(t3.num,'0') as num from 
	(select ssn,t1.type from customers
	cross join 
		(select type from credit_cards
		group by type)t1)t2
left join 
	(select ssn,type, num as num from (
	select a.ssn,b.type, count(b.type) as num
	from customers a
	left join 
		credit_cards b
		on a.ssn = b.ssn
		group by a.ssn,b.type) t1) t3
on t2.ssn = t3.ssn
and t2.type=t3.type; 



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select x.country, count(1) from (
select  distinct a.ssn,a.country from
customers a 
inner join credit_cards b
on a.ssn=b.ssn
inner join transactions c
on b.number = c.number
inner join merchants d
on c.code = d.code
where a.country <> d.country ) x
group by x.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select identifier from 
(select a.type, max(b.amount) as max_amt
from credit_cards a
inner join transactions b 
on a.number=b.number
group by a.type) z
left join 
(select v.type, c.amount, c.identifier
from credit_cards v
inner join transactions c
on v.number=c.number ) x
on z.max_amt = x. amount
and z.type = x.type;


/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select identifier from (
select identifier,
ROW_NUMBER() OVER(PARTITION BY a.type ORDER BY b.amount) as index
from credit_cards a
inner join transactions b 
on a.number=b.number) g
where g.index = '1';

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


select  z.code, z.name from 
(select c.code,c.name,b.amount,
ROW_NUMBER() OVER(PARTITION BY b.code,c.name ORDER BY b.amount desc) as index
from credit_cards a
inner join transactions b
on a.number = b. number
inner join merchants c
on b.code = c.code 
where a.type like '%visa%'
or a.type like '%diners-club%')z
where z.index ='1'
and z.amount < '888'
group by  z.code, z.name;


