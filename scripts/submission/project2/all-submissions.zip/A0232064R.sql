/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <replace with your student number>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* use DATE, results show 26 rows values */
select  distinct c.ssn from customers c, transactions t,credit_cards cr
where 
c.ssn=cr.ssn
and t.number=cr.number
and date(t.datetime) = '2017-12-25' 
and cr.type='visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* find the unique customer-- 21 rows with 2 different customers having the same name*/
select uni.first_name, uni.last_name from (

select c.ssn, c.first_name, c.last_name
from customers c 
join credit_cards cr ON c.ssn = cr.ssn
where cr.type = 'visa' 
and c.country = 'Singapore'

intersect

select c.ssn, c.first_name, c.last_name
from customers c 
join credit_cards cr ON c.ssn = cr.ssn
where cr.type = 'jcb' 
and c.country = 'Singapore'

) as uni;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.ssn, count(cr.number) as number_of_cards from customers c 
left join 
credit_cards cr on c.ssn = cr.ssn
group by c.ssn
;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select id.ssn, bank.type, Count(cr.number) as number_of_cards
from (
Select distinct c.ssn
from customers c
	) id
cross join 
	(
select distinct cr.type
from credit_cards cr
	) bank
	left Join credit_cards cr ON id.ssn = cr.ssn 
	                        and bank.type = cr.type
group by id.ssn, 
         bank.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.country, count(distinct c.ssn)
from transactions t 
join credit_cards cc on t.number = cc.number
join customers c ON cc.ssn = c.ssn
join merchants m ON t.code = m.code
where c.country <> m.country
group by c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Use max */
select t.identifier from transactions t
                    join credit_cards cr on t.number = cr.number
where (cr.type, t.amount) in
	(
	select cr.type, max(t1.amount) 
 	from transactions t1
 	join credit_cards cr on t1.number = cr.number
 	group by cr.type
 	);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Use ALL*/

select t.identifier from transactions t 
                    join credit_cards cr on t.number = cr.number
where t.amount >= all(

	select t1.amount from transactions t1
	join credit_cards cre on t1.number = cre.number
	where cr.type = cre.type);


/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select distinct m.name,m.code
from merchants m
where (m.name, m.code) NOT IN
(
	select m.name,m.code from transactions t 
	join credit_cards cr on t.number = cr.number
	join merchants m on t.code = m.code
	where t.amount >= 888
	and (cr.type like '%visa%' or 
		  cr.type like '%diners-club%')
 );