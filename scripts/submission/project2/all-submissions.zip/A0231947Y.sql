/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231947Y                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn
FROM customers c, credit_cards d, transactions t
WHERE c.ssn = d.ssn 
AND d.type = 'visa'
AND d.number = t.number
AND EXTRACT(year from t.datetime)='2017' 
AND EXTRACT(month from t.datetime)='12' 
AND EXTRACT(day FROM t.datetime) = 25;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT temp.first_name, temp.last_name
FROM (SELECT c.ssn, c.first_name, c.last_name
	  FROM customers c, credit_cards d
	  WHERE c.ssn = d.ssn
	  AND c.country = 'Singapore'
	  AND d.type = 'jcb'
	  INTERSECT
	  SELECT c.ssn, c.first_name, c.last_name
	  FROM customers c, credit_cards d
	  WHERE c.ssn = d.ssn
	  AND c.country = 'Singapore'
	  AND d.type = 'visa') AS temp
ORDER BY temp.first_name;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
(SELECT c.ssn, COUNT(d.number) AS number_owned
FROM customers c, credit_cards d
WHERE c.ssn = d.ssn
GROUP BY c.ssn)
UNION
(SELECT c.ssn, 0 AS cards_type_number
FROM customers c LEFT OUTER JOIN credit_cards d ON c.ssn = d.ssn
WHERE d.ssn ISNULL)
ORDER BY number_owned;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, d.type, COUNT (temp.number)
FROM customers c CROSS JOIN (SELECT DISTINCT d.type FROM credit_cards d) AS d
LEFT OUTER JOIN credit_cards temp ON c.ssn = temp.ssn and d.type = temp.type
GROUP BY c.ssn, d.type
ORDER BY c.ssn, d.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT(DISTINCT c.ssn)
FROM customers c, credit_cards d, merchants m, transactions t
WHERE c.ssn = d.ssn
AND d.number = t.number
AND t.code = m.code
AND c.country <> m.country
GROUP BY c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM credit_cards d, transactions t,
(SELECT d1.type, MAX(t1.amount) AS max_amount
 FROM credit_cards d1, transactions t1 
 WHERE d1.number = t1.number
 GROUP BY d1.type) AS temp
WHERE d.number = t.number
AND d.type = temp.type
AND t.amount = max_amount;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM credit_cards d, transactions t
WHERE d.number = t.number
AND t.amount >= ALL (
	SELECT t1.amount
	FROM credit_cards d1, transactions t1
	WHERE d1.number = t1.number
	AND d.type = d1.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT m.code, m.name 
FROM merchants m, credit_cards d, transactions t
WHERE m.code = t.code
AND t.number = d.number
AND (d.type like 'visa%' or d.type like 'diners-club%')
AND t.amount <> 0
EXCEPT
SELECT DISTINCT m.code, m.name
FROM merchants m, credit_cards d, transactions t
WHERE m.code = t.code
AND t.number = d.number
AND (d.type like 'visa%' or d.type like 'diners-club%')
AND t.amount >= 888;