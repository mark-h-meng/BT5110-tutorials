/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231875Y   									    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn
FROM credit_cards AS c, transactions AS t
WHERE c.type = 'visa'
AND t.number = c.number 
AND DATE(t.datetime) = '2017-12-25'
AND t.amount >0;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cust.first_name, cust.last_name 
FROM 
	(SELECT c.ssn
	FROM credit_cards AS c
	WHERE c.type = 'visa'
	INTERSECT 
	SELECT c.ssn
	FROM credit_cards AS c
	WHERE c.type = 'jcb') AS cards
INNER JOIN customers AS cust ON cust.ssn = cards.ssn
WHERE cust.country = 'Singapore'; 

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cust.ssn, 
	(CASE WHEN card_count ISNULL THEN 0 
		  WHEN card_count >0 THEN card_count end) AS card_count
FROM customers AS cust 
LEFT JOIN
	(SELECT c.ssn, count(c.type) AS card_count 
	FROM credit_cards AS c
	GROUP BY c.ssn) AS cards
ON cust.ssn = cards.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cust.ssn, cs.type, count(c.type) 
FROM customers AS cust
CROSS JOIN
	  (SELECT DISTINCT c.type 
	  FROM credit_cards AS c) AS cs
LEFT JOIN
	credit_cards AS c 
	ON c.type = cs.type AND c.ssn = cust.ssn 
GROUP BY cust.ssn, cs.type
ORDER BY cust.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cust_country, SUM(country_count)
FROM 
	(SELECT t.identifier, t.amount, c.ssn, m.country AS merchant_country, cust.country AS cust_country,
		(CASE WHEN cust.country <> m.country THEN 1 ELSE 0 END) AS country_count 
	FROM transactions AS t, credit_cards AS c, merchants AS m, customers AS cust 
	WHERE  t.number = c.number 
	AND t.code = m.code
	AND c.ssn = cust.ssn) AS subquery
GROUP BY cust_country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT s1.identifier
FROM 
	(SELECT c.type, t.identifier, t.amount 
	FROM transactions AS t, credit_cards AS c
	WHERE t.number = c.number) AS s1
RIGHT JOIN  
	(SELECT cc.type, MAX(tt.amount) AS max_amt
	FROM transactions AS tt, credit_cards AS cc
	WHERE tt.number = cc.number
	GROUP BY cc.type) AS s2	
ON s1.amount = s2.max_amt 
AND s1.type = s2.type
ORDER BY s1.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT tt.identifier
FROM transactions AS tt, credit_cards AS cc
WHERE tt.number = cc.number
AND tt.amount >= ALL 
	(SELECT t.amount
	FROM transactions AS t, credit_cards AS c
	WHERE t.number = c.number
	AND cc.type = c.type
	AND t.amount <> tt.amount); 
	
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m.code, m.name 
FROM merchants AS m 
EXCEPT 
SELECT m.code, m.name
FROM transactions AS t, credit_cards AS c, merchants AS m 
WHERE t.number = c.number
AND t.code = m.code 
AND t.amount >= 888 
AND (c.type LIKE '%visa%' OR c.type LIKE '%diners-club%');