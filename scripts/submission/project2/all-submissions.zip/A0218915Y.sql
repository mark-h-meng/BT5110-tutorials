/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0218915Y>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn
	FROM customers c, credit_cards cc, transactions t
	WHERE cc.ssn = c.ssn
		AND t.number = cc.number
		AND DATE(t.datetime) = '2017-12-25'
		AND cc.type = 'visa'
;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c1.first_name, c1.last_name
	FROM customers c1, customers c2,credit_cards cc1,credit_cards cc2
	WHERE cc1.ssn = c1.ssn
		AND cc2.ssn = c2.ssn
		AND cc1.type = 'jcb' 
		AND cc2.type = 'visa'
		AND c1.country = 'Singapore'
		AND c1.ssn = c2.ssn
	GROUP BY c1.ssn, c1.first_name, c1.last_name
	ORDER BY c1.first_name, c1.last_name
;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn,
		CASE WHEN COUNT(cc.number) ISNULL THEN 0
		ELSE COUNT(cc.number) END
	FROM customers c LEFT OUTER JOIN credit_cards cc ON c.ssn = cc.ssn
	GROUP BY c.ssn
	ORDER BY COUNT (cc.number) ASC
; 
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.ssn, a.type,
	CASE WHEN b.count ISNULL THEN 0
	ELSE b.count END
	FROM (
		SELECT c.ssn, cc.type
			FROM customers c, credit_cards cc
			GROUP BY c.ssn, cc.type
			ORDER BY c.ssn) a
		LEFT OUTER JOIN
		(SELECT c.ssn, cc.type,COUNT(cc.number)
			FROM customers c, credit_cards cc
			WHERE c.ssn=cc.ssn
			GROUP BY c.ssn, cc.type) b
		ON a.ssn=b.ssn AND a.type = b.type
;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT(DISTINCT c.ssn) 
	FROM customers c, credit_cards cc, merchants m, transactions t
	WHERE c.country <> m.country
		AND c.ssn = cc.ssn
		AND cc.number = t.number
		AND m.code = t.code
	GROUP BY c.country
;	
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t1.identifier
	FROM credit_cards cc1, transactions t1
	WHERE cc1.number = t1.number
		AND (cc1.type, t1.amount) IN
			(SELECT cc2.type, MAX(t2.amount)
				FROM credit_cards cc2, transactions t2
				WHERE cc2.number = t2.number
			GROUP BY cc2.type)
;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t1.identifier
	FROM credit_cards cc1, transactions t1
	WHERE cc1.number = t1.number
		AND t1.amount >= ALL(
	SELECT t2.amount
		FROM credit_cards cc2, transactions t2
		WHERE cc2.number = t2.number
			AND cc2.type = cc1.type)
;
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT m.code, m.name
	FROM merchants m, credit_cards cc
	WHERE NOT EXISTS (
		SELECT *
			FROM merchants m1, transactions t1, credit_cards cc1
			WHERE m1.code = t1.code
				AND t1.number = cc1.number
				AND t1.code = m.code
				AND t1.amount >=888
				AND cc1.type IN 
					(SELECT DISTINCT cc2.type 
						FROM credit_cards cc2
						WHERE cc2.type LIKE 'visa%'
							OR cc2.type LIKE 'diners-club%'))
;