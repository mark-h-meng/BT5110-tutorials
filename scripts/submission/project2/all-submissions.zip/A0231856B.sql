/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231856B>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.ssn
from customers c, credit_cards d, transactions t
where c.ssn=d.ssn
and d.number=t.number
and extract(year from t.datetime)=2017
and extract(month from t.datetime)=12
and extract(day from t.datetime)=25
and d.type='visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.first_name, a.last_name from
(select distinct c.ssn, c.first_name, c.last_name
from customers c, credit_cards d
where c.ssn=d.ssn
and d.type ='jcb'
and country='Singapore'
intersect
select distinct c.ssn, c.first_name, c.last_name
from customers c, credit_cards d
where c.ssn=d.ssn
and d.type ='visa'
and country='Singapore'
) as a;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct a.ssn,
case when b.sum_cards isnull then 0 else b.sum_cards end as cards
from customers as a
left join
(select ssn,count(distinct number) as sum_cards
from credit_cards
group by ssn) as b
on a.ssn=b.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct all_sample.ssn, all_sample.type,
case when record.sum_cards isnull then 0 else record.sum_cards end as cards
from
(select * from
(select distinct type from credit_cards) as a cross join
(select distinct ssn from customers) as b) as all_sample
left join
(select ssn, type, count(distinct number) as sum_cards from credit_cards
group by ssn,type) as record
on all_sample.ssn=record.ssn
and all_sample.type=record.type
order by all_sample.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.country, count(distinct c.ssn) as customers_number
from customers as c, credit_cards as d, transactions as t, merchants as m
where c.ssn=d.ssn
and d.number = t.number
and t.code=m.code
and c.country<>m.country
group by c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select ident.type, ident.identifier from

(select max(t.amount) as max_amount, d.type
from transactions as t
left join
credit_cards as d
on t.number=d.number group by d.type) as max_value

left join

(select t.identifier, t.amount, d.type
from transactions as t
left join
credit_cards as d
on t.number=d.number) as ident

on max_value.max_amount=ident.amount
and max_value.type=ident.type;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select d1.type, t1.identifier
from transactions as t1, credit_cards as d1
where t1.number=d1.number
and t1.amount>=ALL(
select t2.amount
from transactions as t2, credit_cards as d2
where t2.number=d2.number
and d1.type=d2.type
);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct m.code, m.name
from merchants as m, transactions as t, credit_cards as d
where m.code=t.code
and t.number=d.number
except
select m.code, m.name
from merchants as m, transactions as t, credit_cards as d
where m.code=t.code
and t.number=d.number
and (d.type like '%visa%' or d.type like '%diners-club%')
and amount>=888;
