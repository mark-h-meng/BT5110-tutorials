/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number :                       A0231917E                     */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.ssn
FROM credit_cards c, transactions t
WHERE c.number = t.number
AND c.type = 'visa'
AND t.datetime BETWEEN '2017-12-25 00:00:00' AND '2017-12-25 23:59:59'

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT a.first_name, a.last_name, a.ssn
FROM customers a, credit_cards c
WHERE a.ssn = c.ssn
AND a.country = 'Singapore'
AND c.type = 'jcb'
INTERSECT
SELECT DISTINCT a.first_name, a.last_name, a.ssn
FROM customers a, credit_cards c
WHERE a.ssn = c.ssn
AND a.country = 'Singapore'
AND c.type = 'visa'

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT a.ssn, 
(CASE WHEN c.ssn IS NULL THEN '0' ELSE COUNT(*) END) AS cardnumber
FROM customers a LEFT OUTER JOIN credit_cards c ON a.ssn = c.ssn
GROUP BY a.ssn,c.ssn
ORDER BY a.ssn

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT ak.ssn, ak.type,
(CASE WHEN c3.type IS NULL THEN '0' ELSE COUNT(*) END) AS cardnumber
FROM	(SELECT c2.type, c2.ssn
		FROM (SELECT DISTINCT c.type
	 		FROM credit_cards c) AS c1 
	 		LEFT OUTER JOIN 
	 		(SELECT DISTINCT a.ssn, c.type
	 		FROM customers a, credit_cards c) AS c2
		 	ON c1.type = c2.type) AS ak 
		LEFT OUTER JOIN credit_cards c3
		ON ak.ssn = c3.ssn AND ak.type = c3.type
GROUP BY ak.ssn, ak.type,c3.type

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT am.country, COUNT(*)
FROM (
	SELECT DISTINCT a.ssn, a.country
	FROM customers a, credit_cards c, merchants m, transactions t
	WHERE a.ssn = c.ssn AND c.number = t.number AND t.code = m.code
	AND m.country <> a.country
	GROUP BY a.ssn, a.country, m.country) AS am
GROUP BY am.country
	
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT t2.identifier 
FROM (
	SELECT DISTINCT c1.type, MAX(t1.amount)
	FROM credit_cards c1 JOIN transactions t1 ON c1.number = t1.number
	GROUP BY c1.type) AS c1t1, transactions t2, credit_cards c2
WHERE c1t1.max = t2.amount
AND c1t1.type = c2.type
AND t2.number = c2.number

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t2.identifier
FROM (
	(SELECT t.identifier,
	MAX(t.amount) OVER (partition by c.type) AS maxi
	FROM transactions t JOIN credit_cards c ON t.number = c.number) AS t1
	JOIN transactions t2 ON t1.maxi = t2.amount AND t1.identifier = t2.identifier)

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT m.code, m.name
FROM merchants m
EXCEPT
SELECT DISTINCT vd.code, vd.name
FROM (
	SELECT t.amount, c.type, m.name, m.code
	FROM merchants m, transactions t, credit_cards c
	WHERE m.code = t.code
	AND t.number = c.number
	AND t.amount >= 888
	AND c.type LIKE 'visa%'
	UNION
	SELECT t.amount, c.type, m.name, m.code
	FROM merchants m, transactions t, credit_cards c
	WHERE m.code = t.code
	AND t.number = c.number
	AND t.amount >= 888
	AND c.type LIKE '%diners-club%') AS vd
