/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218871X

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn
FROM credit_cards c,transactions t
WHERE c.number = t.number
AND c.type = 'visa'
AND DATE(t.datetime) = '2017-12-25'
;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.first_name, c.last_name
FROM customers c, credit_cards cc1, credit_cards cc2
WHERE c.country = 'Singapore'
AND (c.ssn = cc1.ssn AND cc1.type = 'visa')
AND (c.ssn = cc2.ssn AND cc2.type = 'jcb')
;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, COUNT(cc.number)
FROM credit_cards cc RIGHT JOIN customers c ON cc.ssn = c.ssn
GROUP BY c.ssn
;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DROP VIEW IF EXISTS temp_c;
DROP VIEW IF EXISTS cc_type;

CREATE VIEW cc_type AS
SELECT DISTINCT type from credit_cards;

CREATE VIEW temp_c AS
SELECT * FROM customers,cc_type;

SELECT c.ssn,c.type,COUNT(cc.ssn)
FROM temp_c c LEFT JOIN credit_cards cc ON (c.ssn = cc.ssn AND c.type = cc.type)
GROUP BY c.ssn,c.type
ORDER BY c.ssn,c.type ASC
;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country , COUNT(*)
FROM customers c
WHERE EXISTS
(SELECT DISTINCT c.ssn
FROM merchants m,transactions t, credit_cards cc
WHERE c.ssn = cc.ssn AND t.number = cc.number AND t.code = m.code
AND c.country <> m.country)
GROUP BY c.country
;



/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DROP VIEW IF EXISTS amount_1;

CREATE VIEW amount_1 AS
SELECT cc.type,MAX(t.amount)
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
GROUP BY cc.type
;

SELECT t.identifier , cc.type, t.amount
FROM credit_cards cc, transactions t, amount_1 amt
WHERE t.number = cc.number AND cc.type = amt.type AND t.amount = amt.max
;





/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT type FROM credit_cards;
/* By using distinct, we are able to know there are 16 types of credit cards in table credit cards.
"diners-club-us-ca"
"instapayment"
"china-unionpay"
"bankcard"
"diners-club-carte-blanche"
"visa"
"diners-club-international"
"laser"
"americanexpress"
"maestro"
"solo"
"switch"
"jcb"
"visa-electron"
"diners-club-enroute"
"mastercard"

Then, we will be able to get the identifier of the transaction with largest amount using '>= ALL' with a subquery for each type of credit card
and connect them altogether using UNION.
*/

SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='diners-club-us-ca'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'diners-club-us-ca')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='instapayment'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'instapayment')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='china-unionpay'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'china-unionpay')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='bankcard'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'bankcard')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='diners-club-carte-blanche'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'diners-club-carte-blanche')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='visa'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'visa')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='diners-club-international'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'diners-club-international')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='laser'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'laser')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='americanexpress'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'americanexpress')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='maestro'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'maestro')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='solo'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'solo')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='switch'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'switch')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='jcb'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'jcb')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='visa-electron'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'visa-electron')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='diners-club-enroute'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'diners-club-enroute')
UNION
SELECT cc.type,t.identifier,t.amount FROM credit_cards cc, transactions t
WHERE cc.number = t.number AND cc.type ='mastercard'
AND t.amount >= ALL (SELECT t.amount from credit_cards cc,transactions t WHERE cc.number = t.number AND cc.type = 'mastercard')
;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT *
FROM merchants m
WHERE NOT EXISTS (SELECT m.code
FROM transactions t,  credit_cards cc
WHERE t.number = cc.number AND t.code = m.code
AND t.amount >= 888
AND (cc.type LIKE '%visa%' OR cc.type LIKE '%diners-club%'))
;


/*
"50-9541874"	"Bartoletti-Wilderman"	"Indonesia"
"37-2421122"	"Torp-Vandervort"	"Indonesia"
"44-3387143"	"Flatley Inc"	"Thailand"
"47-0770742"	"Bartoletti and Sons"	"Indonesia"
"57-6774544"	"Olson, Corwin and Emard"	"Singapore"
"44-6155344"	"Bernhard and Sons"	"Singapore"
"87-5899014"	"Nicolas, Olson and Krajcik"	"Singapore"
 */
