/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0218875N>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn
FROM customers c, credit_cards cc, transactions t
WHERE c.ssn = cc.ssn
AND cc.number = t.number
AND cc.type = 'visa'
AND t.datetime:: date = '2017-12-25'
ORDER BY c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
WITH Visa AS (
SELECT DISTINCT c.ssn, c.first_name, c.last_name, c.country, cc.type
FROM customers c, credit_cards cc
WHERE c.country = 'Singapore'
AND c.ssn = cc.ssn
AND cc.type = 'visa'
ORDER BY c.first_name),

Jcb AS(
SELECT DISTINCT c.ssn, c.first_name, c.last_name, c.country, cc.type
FROM customers c, credit_cards cc
WHERE c.country = 'Singapore'
AND c.ssn = cc.ssn
AND cc.type = 'jcb'
ORDER BY c.first_name)

SELECT v.ssn, v.type as creditcard1, j.type as creditcard2, v.first_name, v.last_name, v.country
FROM Visa v, Jcb j
WHERE v.ssn = j.ssn
Order by v.first_name;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, count(cc.type)
FROM customers c
LEFT OUTER JOIN credit_cards cc
ON c.ssn = cc.ssn
GROUP BY c.ssn
ORDER BY COUNT;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, cc.type, count(cc.type)
FROM customers c
LEFT OUTER JOIN credit_cards cc
ON c.ssn = cc.ssn
GROUP BY c.ssn, cc.type
ORDER BY c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, count(DISTINCT c.ssn)
FROM customers c, credit_cards cc, transactions t, merchants m
WHERE cc.number = t.number
AND cc.ssn = c.ssn
AND t.code = m.code
AND c.country != m.country
GROUP BY c.country
ORDER BY count DESC;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc2.type, t2.amount, t2.identifier
FROM transactions t2, credit_cards cc2
WHERE t2.number = cc2.number 
AND (cc2.type, t2.amount) = ANY

(SELECT  cc.type, max(t.amount) as max_amt
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
GROUP BY cc.type
ORDER BY max_amt DESC)

ORDER BY cc2.type;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc1.type, t1.amount, t1.identifier
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc
	WHERE t.number = cc.number
	AND cc.type = 'americanexpress'
	ORDER BY t.amount DESC
	LIMIT 1)
	
UNION 
	
SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'bankcard' 
	ORDER BY t.amount DESC LIMIT 1)  
	
UNION

SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'china-unionpay' 
	ORDER BY t.amount DESC LIMIT 1)  
	
UNION

SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'diners-club-carte-blanche' 
	ORDER BY t.amount DESC LIMIT 1)  
	
UNION

SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'diners-club-enroute' 
	ORDER BY t.amount DESC LIMIT 1)  
	
UNION

SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'diners-club-international' 
	ORDER BY t.amount DESC LIMIT 1)  
	
UNION

SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'diners-club-us-ca' 
	ORDER BY t.amount DESC LIMIT 1)  
	
UNION

SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'instapayment' 
	ORDER BY t.amount DESC LIMIT 1)  
	
UNION

SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'jcb' 
	ORDER BY t.amount DESC LIMIT 1)  
	
UNION

SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'laser' 
	ORDER BY t.amount DESC LIMIT 1)  

UNION

SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'maestro' 
	ORDER BY t.amount DESC LIMIT 1)  
	
UNION

SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'mastercard' 
	ORDER BY t.amount DESC LIMIT 1)  
	
UNION

SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'solo' 
	ORDER BY t.amount DESC LIMIT 1)  
	
UNION

SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'switch' 
	ORDER BY t.amount DESC LIMIT 1)  
	
UNION

SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'visa' 
	ORDER BY t.amount DESC LIMIT 1)  
	
UNION

SELECT cc1.type, t1.amount, t1.identifier 
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND (cc1.type, t1.amount) = ANY (SELECT cc.type, t.amount
	FROM transactions t, credit_cards cc 
	WHERE t.number = cc.number 
	AND cc.type = 'visa-electron' 
	ORDER BY t.amount DESC LIMIT 1);  
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m.code, m.name
FROM  merchants m
WHERE m.code NOT IN ( WITH h999 AS( WITH h888 AS
(SELECT *
FROM transactions t, credit_cards as cc
WHERE t.amount >= 888
AND t.number = cc.number
GROUP by cc.type, t.identifier, cc.ssn, cc.number
ORDER BY cc.type)
SELECT DISTINCT code, type
FROM h888
WHERE type like '%visa%' OR type like '%diners-club%'
ORDER BY code)
SELECT DISTINCT code
FROM H999)
ORDER BY m.code;
