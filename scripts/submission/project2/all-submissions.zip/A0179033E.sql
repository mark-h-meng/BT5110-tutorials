/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0179033E						                    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.ssn
FROM credit_cards c, transactions t
WHERE c.number = t.number
	AND t.datetime::date = '2017-12-25'
	AND c.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cus.first_name, cus.last_name
FROM customers cus, credit_cards c
WHERE c.ssn = cus.ssn
	AND cus.country = 'Singapore'
	AND (c.type = 'jcb' OR c.type = 'visa')
GROUP BY c.ssn, cus.first_name, cus.last_name
ORDER BY cus.first_name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cus.ssn,COUNT(c.ssn)
FROM customers cus
LEFT OUTER JOIN credit_cards c ON c.ssn=cus.ssn
GROUP BY cus.ssn, c.ssn
ORDER BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cus.ssn, c.type, COUNT(*)
FROM customers cus, credit_cards c
WHERE c.ssn=cus.ssn
GROUP BY cus.ssn, c.type
UNION
SELECT cus.ssn, c.type,0
FROM credit_cards c, customers cus
WHERE (cus.ssn,c.type) NOT IN (
	SELECT cus.ssn, c.type
	FROM customers cus, credit_cards c
	WHERE c.ssn=cus.ssn
	GROUP BY cus.ssn, c.type)
GROUP BY cus.ssn, c.type
ORDER BY ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cus.country, COUNT(*)
FROM customers cus
WHERE cus.ssn IN(
	SELECT cus.ssn
	FROM customers cus, transactions t, merchants m, credit_cards c
	WHERE cus.ssn = c.ssn
		AND c.number = t.number
		AND t.code = m.code
		AND cus.country <> m.country
	GROUP BY cus.ssn,cus.country, m.country)
GROUP BY cus.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM transactions t, credit_cards c
WHERE t.number = c.number
	AND (c.type, t.amount) IN(
	SELECT c.type, MAX(t.amount)
	FROM transactions t, credit_cards c
	WHERE t.number = c.number
	GROUP BY c.type)
GROUP BY t.identifier, c.type
ORDER BY t.amount;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t1.identifier
FROM transactions t1, credit_cards cc1
WHERE t1.number=cc1.number
	AND t1.amount >=ALL(
		SELECT t2.amount
		FROM transactions t2, credit_cards cc2
		WHERE t2.number=cc2.number
			AND cc1.type=cc2.type)
ORDER BY cc1.type;
	

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT m.code, m.name
FROM merchants m
WHERE m.code NOT IN(
	SELECT DISTINCT m.code
	FROM merchants m, transactions t, credit_cards c
	WHERE m.code = t.code
		AND t.number = c.number
		AND (c.type LIKE 'visa%'OR c.type LIKE 'diners-club%')
		AND t.amount >= 888);