/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231918A                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn
FROM customers c, credit_cards cc, transactions t
WHERE c.ssn = cc.ssn
AND cc.number = t.number
AND date(t.datetime) = '2017-12-25'
AND cc.type = 'visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.first_name, a.last_name
FROM (
	SELECT c.ssn, c.first_name, c.last_name
	FROM customers c, credit_cards cc
	WHERE c.ssn = cc.ssn
	AND c.country = 'Singapore'
	AND cc.type = 'jcb'
	INTERSECT
	SELECT c.ssn, c.first_name, c.last_name
	FROM customers c, credit_cards cc
	WHERE c.ssn = cc.ssn
	AND c.country = 'Singapore'
	AND cc.type = 'visa'
	) a;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, COUNT(cc.number)
FROM customers c
LEFT OUTER JOIN credit_cards cc
ON c.ssn = cc.ssn
GROUP BY c.ssn
ORDER BY COUNT(cc.number);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.ssn, a.type, COUNT(cc1.number)
FROM (
	SELECT c.ssn, cc.type
	FROM customers c, (
		SELECT DISTINCT type
		FROM credit_cards
	) cc
) a
LEFT JOIN credit_cards cc1
ON (a.ssn, a.type) = (cc1.ssn, cc1.type)
GROUP BY a.ssn, a.type
ORDER BY a.ssn, a.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT(DISTINCT c.ssn)
FROM customers c, credit_cards cc, merchants m, transactions t
WHERE cc.number = t.number
AND m.code = t.code
AND c.ssn = cc.ssn
AND c.country <> m.country
GROUP BY c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND (cc.type, t.amount) IN (
	SELECT cc1.type, MAX(t1.amount)
	FROM credit_cards cc1, transactions t1
	WHERE cc1.number = t1.number
	GROUP BY cc1.type);
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND t.amount >= ALL(
	SELECT t1.amount
	FROM credit_cards cc1, transactions t1
	WHERE cc1.number = t1.number
	AND cc1.type = cc.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT code, name
FROM merchants
WHERE (code, name) NOT IN (
	SELECT DISTINCT m.code, m.name
	FROM merchants m, transactions t, (
		SELECT *
		FROM credit_cards
		WHERE type LIKE 'visa%'
		OR type LIKE 'diners-club%'
		) cc
	WHERE m.code = t.code
	AND t.number = cc.number
	GROUP BY m.code, cc.type
	HAVING MAX(t.amount) >= 888
);