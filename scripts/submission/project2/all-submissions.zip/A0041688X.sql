/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0041688X                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND date(t.datetime)='2017-12-25'
AND cc.type='visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.first_name,c.last_name
FROM customers c, credit_cards cc
WHERE c.ssn=cc.ssn
AND c.country='Singapore'
AND cc.type = 'visa' 
INTERSECT
SELECT c1.first_name,c1.last_name
FROM customers c1, credit_cards cc1
WHERE c1.ssn = cc1.ssn
AND c1.country='Singapore'
AND cc1.type='jcb';
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, COUNT(cc.number) AS no_credit_card
FROM customers c
LEFT OUTER JOIN credit_cards cc ON c.ssn=cc.ssn
GROUP BY c.ssn
ORDER BY COUNT(cc.number) ASC;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn, cc.type, COUNT(cc1.type) AS num_cc
FROM customers c
CROSS JOIN credit_cards cc
LEFT OUTER JOIN credit_cards cc1 
ON cc1.ssn=cc.ssn
AND cc1.ssn=c.ssn
AND cc1.number=cc.number
GROUP BY cc.type,c.ssn
ORDER BY c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT(DISTINCT c.ssn) AS no_of_customers
FROM customers c, merchants m, transactions t, credit_cards cc
WHERE cc.number=t.number
AND cc.ssn=c.ssn
AND t.code=m.code
AND c.country<>m.country
GROUP BY c.country
ORDER BY COUNT(c.ssn) ASC;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier, cc.type, t.amount
FROM credit_cards cc
INNER JOIN transactions t ON cc.number=t.number
INNER JOIN (SELECT cc1.type,
			MAX(t1.amount) AS max_value
			FROM transactions t1,credit_cards cc1 
			WHERE t1.number=cc1.number
			GROUP BY cc1.type) combo
			ON cc.type=combo.type 
			AND t.amount=combo.max_value
GROUP BY cc.type,t.identifier
ORDER BY cc.type;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

DROP VIEW IF EXISTS combot;
--creating a combined view on the highest transaction of each credit card number with type
CREATE VIEW combot AS 
(SELECT t.identifier, cc.type, t.amount 
FROM credit_cards cc, transactions t
LEFT OUTER JOIN transactions t1
ON t1.number=t.number
AND t1.amount >t.amount
WHERE t1.amount ISNULL
AND cc.number=t.number);

SELECT ct.identifier,ct.type,ct.amount
FROM combot ct
LEFT OUTER JOIN combot ct1
ON ct1.type=ct.type
AND ct1.amount > ct.amount
WHERE ct1 ISNULL
ORDER BY ct.type;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT m.code,m.name
FROM merchants m, transactions t, credit_cards cc
WHERE m.code = t.code
AND t.number=cc.number
AND (cc.type LIKE 'visa%' OR cc.type LIKE 'diners-club%')
AND m.code NOT IN (SELECT DISTINCT m1.code 
				   FROM merchants m1,transactions t1,credit_cards cc1
				   WHERE m1.code=t1.code
				   AND t1.number=cc1.number
				   AND t1.amount>=888
				   AND(cc1.type like 'visa%' or cc1.type like 'diners-club%'))
ORDER BY m.code;