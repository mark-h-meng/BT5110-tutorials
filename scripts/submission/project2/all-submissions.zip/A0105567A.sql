/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0105567A                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn 
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND cc.type = 'visa'
AND t.datetime Between '2017-12-25' AND '2017-12-26'
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT first_name, last_name 
FROM(
	SELECT DISTINCT c.first_name, c.last_name, c.ssn
	FROM customers c, credit_cards cc
	WHERE c.ssn = cc.ssn
	AND c.country = 'Singapore'
	AND cc.type = 'jcb'
INTERSECT 
	SELECT DISTINCT c2.first_name, c2.last_name, c2.ssn
	FROM credit_cards cc2, customers c2
	WHERE c2.country = 'Singapore'
	AND c2.ssn = cc2.ssn
	AND cc2.type = 'visa') AS temp

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, count(number) 
FROM customers c LEFT OUTER JOIN credit_cards cc 
ON c.ssn = cc.ssn
GROUP by c.ssn

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

DROP VIEW IF EXISTS all_cards;
CREATE VIEW all_cards AS
SELECT *
FROM customers c CROSS JOIN (SELECT DISTINCT cc.type 
							FROM credit_cards cc) AS c_type;

SELECT ac.ssn, ac.type, count(number)
FROM all_cards ac LEFT OUTER JOIN credit_cards cc
ON (ac.ssn, ac.type) = (cc.ssn, cc.type)
GROUP BY ac.ssn, ac.type

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, count(DISTINCT c.ssn)
FROM customers c, credit_cards cc, merchants m, transactions t
WHERE m.code = t.code
AND c.ssn = cc.ssn
AND cc.number = t.number
AND c.country <> m.country
GROUP by c.country

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.type, t.identifier
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND (cc.type, t.amount) in (
	SELECT cc2.type, MAX(t2.amount)
	FROM credit_cards cc2, transactions t2
	WHERE cc2.number = t2.number
	GROUP BY cc2.type)

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cc.type, t.identifier
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND (cc.type, t.amount) >=ALL(
	SELECT cc2.type, t2.amount
	FROM credit_cards cc2, transactions t2
	WHERE cc2.number = t2.number
	AND cc.type = cc2.type)

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m.name
FROM merchants m
WHERE m.name NOT IN (
	SELECT m2.name
	FROM merchants m2, transactions t2, credit_cards cc2
	WHERE m2.code = t2.code
	AND t2.number = cc2.number
    AND (cc2.type like '%visa%' OR cc2.type like '%diners-club%')
	AND t2.amount >=888)

