/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0232012E                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
\i CCSchema.sql
\i CCCustomers.sql
\i CCCreditCards.sql
\i CCMerchants.sql
\i CCTransactions.sql

SELECT DISTINCT cc.ssn
FROM credit_cards cc, transactions t
WHERE t.number = cc.number
AND cc.type = 'visa'
AND t.datetime > '2017-12-24'
AND t.datetime < '2017-12-26';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT tmp_b.first_name, tmp_b.last_name
FROM(
SELECT DISTINCT c.first_name, c.last_name, c.ssn
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
AND cc.type = 'visa'
INTERSECT
SELECT DISTINCT c.first_name, c.last_name, c.ssn
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
AND cc.type = 'jcb') AS tmp_b;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, COUNT(cc.number)
FROM customers c LEFT OUTER JOIN credit_cards cc ON c.ssn = cc.ssn
GROUP BY c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT tmp_d.ssn, tmp_d.type, COUNT(tmp_d.type)
FROM(
SELECT c.ssn, cc.number, cc.type
FROM customers c LEFT JOIN credit_cards cc ON c.ssn = cc.ssn
) AS tmp_d
GROUP BY tmp_d.ssn, tmp_d.type
ORDER BY tmp_d.ssn, tmp_d.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country as cutomers_country, m.country as merchants_country, COUNT(*)
FROM customers c, credit_cards cc, merchants m, transactions t
WHERE t.number = cc.number
AND cc.ssn = c.ssn
AND m.code = t.code
AND m.country <> c.country
GROUP BY c.country, m.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
GROUP BY t.identifier, cc.type
HAVING (cc.type, MAX(t.amount)) IN (
SELECT cc1.type, MAX(t1.amount)
FROM transactions t1, credit_cards cc1
WHERE cc1.number = t1.number
GROUP BY cc1.type
);
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM transactions t, credit_cards cc
WHERE t.number = cc.number
AND t.amount >= ALL(
SELECT t2.amount
FROM transactions t2, credit_cards cc2
WHERE t2.number = cc2.number
AND cc2.type = cc.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT t.code, m.name
FROM transactions t, merchants m, credit_cards cc
WHERE t.number = cc.number
AND t.code = m.code
AND t.code NOT IN(
SELECT DISTINCT t2.code
FROM transactions t2, credit_cards cc2
WHERE t2.amount >= 888
AND cc2.number = t2.number
AND ((cc2.type LIKE '%visa%') OR (cc2.type LIKE '%diners-club%'))
);

\i CCClean.sql