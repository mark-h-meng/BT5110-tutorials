/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231982B                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*   */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct ssn
from credit_cards c,transactions t
where c.number=t.number
and date(t.datetime)='2017-12-25'
and t.amount>0
and c.type='visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.first_name,a.last_name
from
(select cu.ssn, cu.first_name, cu.last_name
from customers cu join credit_cards cc on cu.ssn=cc.ssn
where cc.type='visa' and cu.country='Singapore'
intersect
select cu.ssn, cu.first_name, cu.last_name
from customers cu join credit_cards cc on cu.ssn=cc.ssn
where cc.type='visa' and cu.country='Singapore') as a ;


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select cu.ssn, count(cc.number)
from customers cu
left join credit_cards cc
on cu.ssn=cc.ssn
group by cu.ssn;


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.ssn, b.type, count(cc.number)
from(select distinct cu.ssn from customers cu)as a cross join (select distinct cc.type from credit_cards cc)as b
left join credit_cards cc
on a.ssn=cc.ssn and b.type=cc.type
group by a.ssn, b.type
order by a.ssn, b.type;


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cu.country, count(distinct cu.ssn)
from transactions t
join merchants m on t.code=m.code
join credit_cards cc on cc.number=t.number
join customers cu on cu.ssn=cc.ssn
where cu.country<>m.country
group by cu.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t.identifier
from transactions t
join credit_cards cc on cc.number=t.number
where (cc.type,t.amount) in (select cc.type,max(t1.amount) 
							 from transactions t1
							 join credit_cards cc
							 on cc.number=t1.number
							 group by cc.type
							);
							
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t.identifier
from transactions t
join credit_cards cc on cc.number=t.number
where t.amount >= all (select t1.amount
					   from transactions t1
					   join credit_cards cc1
					   on cc1.number=t1.number
					   where cc1.type=cc.type
							);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct m.code, m.name
from merchants m
where (m.code,m.name) not in
(select m.code, m.name
from merchants m
join transactions t on m.code=t.code
join credit_cards cc on cc.number=t.number
where t.amount>=888
and (cc.type like '%visa%' OR cc.type LIKE '%diners-club%'));
