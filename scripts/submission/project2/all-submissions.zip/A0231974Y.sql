/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231974Y                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select distinct c.ssn, c.first_name, c.last_name
From Customers AS c, Transactions AS t, Credit_cards AS cc
Where cc.type = 'visa' AND t.datetime Between '2017-12-24 23:59:59.999999' AND '2017-12-25 23:59:59.999999'
AND c.ssn = cc.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select c.first_name, c.last_name
From customers c Inner Join credit_cards cc ON c.ssn = cc.ssn Inner Join Transactions t ON cc.number = t.number
AND c.country = 'Singapore' AND cc.type = ('visa')
INTERSECT
Select c.first_name, c.last_name
From customers c Inner Join credit_cards cc ON c.ssn = cc.ssn Inner Join Transactions t ON cc.number = t.number
AND c.country = 'Singapore' AND cc.type = ('jcb');

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select c.ssn, count(cc.number)
From customers c LEFT Join credit_cards cc ON c.ssn = cc.ssn
Group By c.ssn
Order by count;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select c.ssn, cc.type, count(cc.number)
From customers c LEFT Join credit_cards cc ON c.ssn = cc.ssn
Group By c.ssn, cc.type
Order by c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select c.country, count(distinct c.ssn)
From transactions t
Inner Join credit_cards cc ON t.number = cc.number
Inner Join customers c ON c.ssn = cc.ssn
Inner Join merchants m ON m.code = t.code
Where c.country <> m.country
Group By c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select t.identifier
From transactions t
Join credit_cards cc ON t.number = cc.number
Where t.amount = (
	Select MAX(t1.amount)
	From transactions t1
	Join credit_cards cc1 on t1.number = cc1.number
	Where cc.type = cc1.type
);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select t.identifier
From transactions t
Join credit_cards cc ON t.number = cc.number
Where t.amount >= ALL(
	Select t1.amount
	From transactions t1
	Join credit_cards cc1 on t1.number = cc1.number
	Where cc.type = cc1.type
);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

Select m.code
From merchants m
Where m.code NOT IN(
	Select m.code
	From transactions t
	Inner Join merchants m ON t.code = m.code
	Inner Join credit_cards cc ON t.number = cc.number
	Where t.amount >= 888
	AND (cc.type IN ('visa', 'diners-club'))
);
