/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218949L						                                */
/************************************************************************/
/*                                                                      */
/* Question 1.a      										                           			*/
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn
FROM transactions t LEFT JOIN credit_cards cc ON t.number = cc.number
WHERE cc.type = 'visa'
AND DATE(t.datetime) = '2017-12-25';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT first_name, last_name
FROM customers
WHERE country = 'Singapore'
AND ssn IN (
	SELECT ssn FROM credit_cards WHERE type = 'jcb'
	INTERSECT
	SELECT ssn FROM credit_cards WHERE type = 'visa'
)
GROUP BY ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn AS ssn,
       COALESCE(cc.count, 0) AS number_of_cards
FROM customers c LEFT JOIN (
    SELECT ssn,
           COUNT(number)
    FROM credit_cards
    GROUP BY ssn) cc
ON c.ssn = cc.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c_ssn.ssn AS ssn, c_type.type AS type,
	   CASE WHEN num_cards ISNULL THEN 0
	   ELSE num_cards
	   END AS num_cards
FROM (
	SELECT DISTINCT(ssn) FROM customers) c_ssn CROSS JOIN (select DISTINCT(type) FROM credit_cards) c_type
	LEFT JOIN (
		SELECT ssn, type, COUNT(distinct(number)) AS num_cards
		FROM credit_cards
		GROUP BY SSN, TYPE
	) counts ON c_ssn.ssn = counts.ssn AND c_type.type = counts.type
ORDER BY ssn, type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT(DISTINCT c.ssn)
FROM customers c, merchants m, transactions t, credit_cards cc
WHERE c.ssn = cc.ssn
AND cc.number = t.number
AND m.code = t.code
AND c.country <> m.country
GROUP BY c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM transactions t LEFT JOIN credit_cards cc ON t.number = cc.number
WHERE (cc.type, t.amount) IN (
    SELECT cc.type,
           MAX(t.amount) AS max_amount
    FROM transactions t LEFT JOIN credit_cards cc ON t.number = cc.number
    GROUP BY cc.type
  );
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT agg1.identifier
FROM (transactions t LEFT JOIN credit_cards c ON t.number = c.number) agg1
WHERE agg1.amount >= ALL (
  	SELECT agg2.amount
  	FROM (transactions t LEFT JOIN credit_cards c ON t.number = c.number) agg2
    WHERE agg1.type = agg2.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT code, name
FROM merchants
WHERE code IN (
  	SELECT code
  	FROM transactions t LEFT JOIN credit_cards cc ON t.number = cc.number
  	WHERE cc.type LIKE '%visa%'
  	OR cc.type LIKE '%diners-club%'
  	GROUP BY code
  	HAVING MAX(
    		CASE WHEN amount >= 888 THEN 'True'
    		ELSE 'False'
    		END
    		) = 'False'
);
