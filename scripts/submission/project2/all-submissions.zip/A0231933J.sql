/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231933J>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct ssn
from credit_cards c2,transactions t
where c2.number=t.number
and date(t.datetime)='2017-12-25'
and c2.type='visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c1.first_name,c1.last_name
from customers c1
where c1.ssn in (
	select c1.ssn
	from customers c1,credit_cards c2
	where c1.ssn=c2.ssn
	and c1.country='Singapore'
	and c2.type='jcb'
	intersect
	select c1.ssn
	from customers c1,credit_cards c2
	where c1.ssn=c2.ssn
	and c1.country='Singapore'
	and c2.type='visa');
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c1.ssn, count(c2.number)
from customers c1 left outer join credit_cards c2 on c1.ssn=c2.ssn
group by c1.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c1.ssn, c4.type, count(number)
from customers c1 cross join (select distinct c3.type from credit_cards c3) as c4 left outer join credit_cards c2 
on c1.ssn=c2.ssn and c2.type=c4.type
group by c1.ssn, c4.type
order by ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c1.country, count(distinct c1.ssn)
from customers c1, credit_cards c2, merchants m,transactions t
where c1.ssn=c2.ssn
and t.number=c2.number
and t.code=m.code
and c1.country!=m.country
group by c1.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c2.type,t.identifier
from (select c2.type, max(t.amount) as max_amount
	from credit_cards c2,transactions t
	where c2.number=t.number
	group by c2.type) as s, transactions t, credit_cards c2
where c2.number=t.number
and c2.type=s.type
and s.max_amount=t.amount
order by c2.type;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct on (c2.type) c2.type, t.identifier
from credit_cards c2,transactions t
where c2.number=t.number
order by c2.type, t.amount desc;
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select m.code,m.name
from merchants m,transactions t,credit_cards c2
where m.code=t.code
and t.number=c2.number
and (c2.type='visa' or c2.type='diners-club')
group by m.code,m.name
having sum(t.amount)<888;
