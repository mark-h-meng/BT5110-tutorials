/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0125002E>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
  DISTINCT cu.ssn as Social_Security_Number 
FROM 
  customers cu, 
  credit_cards cc, 
  transactions t 
WHERE 
  t.number = cc.number 
  AND cc.type = 'visa' 
  AND cu.ssn = cc.ssn 
  AND DATE(t.datetime) = '2017-12-25';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
  foo.first_name, 
  foo.last_name 
FROM 
  (
    SELECT 
      cu.first_name, 
      cu.last_name, 
      cu.SSN 
    FROM 
      customers cu, 
      credit_cards cc 
    WHERE 
      cu.country = 'Singapore' 
      AND cc.type = 'jcb' 
      AND cc.SSN = cu.SSN 
    INTERSECT 
    SELECT 
      cu.first_name, 
      cu.last_name, 
      cu.SSN 
    FROM 
      customers cu, 
      credit_cards cc 
    WHERE 
      cu.country = 'Singapore' 
      AND cc.type = 'visa' 
      AND cc.SSN = cu.SSN
  ) AS foo;


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
  cu.SSN, 
  (
    CASE WHEN COUNT(cc.SSN) ISNULL THEN '0' ELSE COUNT(cc.SSN) END
  ) as Number_of_CreditCard_owned 
FROM 
  customers cu 
  LEFT OUTER JOIN credit_cards cc ON cu.SSN = cc.SSN 
GROUP BY 
  cu.SSN 
ORDER BY 
  number_of_CreditCard_owned ASC;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
  _cartesian_16cards_with_cu.ssn, 
  _cartesian_16cards_with_cu.type, 
  (
    CASE WHEN COUNT(numb_cards_owned.SSN) ISNULL THEN '0' ELSE COUNT(numb_cards_owned.SSN) END
  ) as Number_of_CreditCard_owned 
FROM 
  (
    SELECT 
      cc_types.type, 
      cu.ssn 
    FROM 
      (
        SELECT 
          DISTINCT (cc.type) 
        FROM 
          credit_cards cc
      ) AS cc_types, 
      customers cu
  ) AS _cartesian_16cards_with_cu 
  LEFT OUTER JOIN (
    SELECT 
      cc.ssn, 
      cc.type, 
      COUNT(cc.ssn) 
    FROM 
      credit_cards cc 
    GROUP BY 
      cc.ssn, 
      cc.type
  ) AS numb_cards_owned ON numb_cards_owned.ssn = _cartesian_16cards_with_cu.ssn 
  AND numb_cards_owned.type = _cartesian_16cards_with_cu.type 
GROUP BY 
  _cartesian_16cards_with_cu.ssn, 
  _cartesian_16cards_with_cu.type 
ORDER BY 
  _cartesian_16cards_with_cu.SSN ASC;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
  cu.country, 
  count(DISTINCT cu.SSN) 
FROM 
  customers cu, 
  credit_cards cc, 
  merchants m, 
  transactions t 
WHERE 
  cu.ssn = cc.ssn 
  AND cc.number = t.number 
  AND t.code = m.code 
  AND m.country <> cu.country 
GROUP BY 
  cu.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
  t.identifier
FROM 
  credit_cards cc, 
  transactions t 
WHERE 
  (t.amount, cc.type) IN (
    SELECT 
      MAX(t.amount), 
      cc.type 
    FROM 
      credit_cards cc, 
      transactions t 
    WHERE 
      cc.number = t.number 
    GROUP BY 
      cc.type
  ) 
  AND cc.number = t.number;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
  t.identifier 

FROM 
  credit_cards cc, 
  transactions t 
WHERE 
  cc.number = t.number 
  AND (
    t.amount >= ALL (
      SELECT 
        t2.amount 
      FROM 
        transactions t2, 
        credit_cards cc2 
      WHERE 
        cc2.number = t2.number 
        AND cc.type = cc2.type
    )
  );
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
  DISTINCT m1.code, 
  m1.name 
FROM 
  merchants m1, 
  transactions t1, 
  credit_cards cc1 
WHERE 
  m1.code = t1.code 
  AND cc1.number = t1.number 
  AND NOT EXISTS (
    SELECT 
      m.code, 
      m.name, 
      t.amount, 
      cc.type 
    FROM 
      merchants m, 
      transactions t, 
      credit_cards cc 
    WHERE 
      m.code = t.code 
      AND t.number = cc.number 
      AND t.amount >= 888 
      AND (
        cc.type LIKE 'visa%' 
        OR cc.type LIKE 'diners%'
      ) 
      AND m1.code = m.code
  );
			  
