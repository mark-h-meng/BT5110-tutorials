/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0142279B>						                    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND cc.type='visa'
AND t.datetime::date = '2017-12-25';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.first_name, c.last_name
FROM customers c
WHERE c.country = 'Singapore'
AND c.ssn IN (
	SELECT DISTINCT c.ssn
	FROM customers c, credit_cards cc
	WHERE c.ssn=cc.ssn 
	AND cc.type='visa'
	INTERSECT 
	SELECT DISTINCT c.ssn
	FROM customers c, credit_cards cc
	WHERE c.ssn=cc.ssn 
	AND cc.type='jcb');


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, COUNT(cc.number) AS number_of_card
FROM customers c LEFT OUTER JOIN credit_cards cc ON c.ssn = cc.ssn
GROUP BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT to_fill.ssn, to_fill.type, COUNT(number) AS number_of_card
FROM (SELECT c.ssn, cc_type.type
	  FROM customers c, (SELECT DISTINCT cc.type FROM credit_cards cc) AS cc_type) AS to_fill
	  LEFT JOIN credit_cards cc1 ON cc1.ssn = to_fill.ssn AND cc1.type = to_fill.type
GROUP BY to_fill.ssn, to_fill.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT diff_cty.country, COUNT(DISTINCT diff_cty.ssn)
FROM (SELECT c.country, c.ssn
	  FROM customers c, credit_cards cc, transactions t, merchants m
	  WHERE c.ssn = cc.ssn
	  AND cc.number = t.number
	  AND t.code = m.code
	  AND c.country <> m.country) AS diff_cty
GROUP BY diff_cty.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT t.identifier
FROM transactions t, credit_cards cc,
	(SELECT cc1.type, MAX(t1.amount)
	  FROM credit_cards cc1, transactions t1
	  WHERE cc1.number = t1.number
	  GROUP BY cc1.type) AS max_trans  
WHERE t.amount = max_trans.max
AND cc.number = t.number
AND cc.type = max_trans.type;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT t.identifier
FROM credit_cards cc, transactions t 
WHERE cc.number = t.number
AND t.amount >= ALL(SELECT t1.amount 
				   FROM credit_cards cc1, transactions t1
				   WHERE cc1.number = t1.number
				   AND cc.type = cc1.type);


/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m1.code, m1.name
FROM merchants m1
WHERE m1.code NOT IN (
	SELECT m.code
	FROM merchants m, credit_cards cc, transactions t
	WHERE cc.number = t.number
	AND t.code = m.code
	AND t.amount >= 888
	AND (cc.type LIKE 'visa%' OR cc.type LIKE 'diners-club%'))
