﻿/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231902R>                                         */
/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.ssn
from customers c, credit_cards cc, transactions t
where c.ssn = cc.ssn
and cc.number = t.number
and t.datetime >= '2017-12-24'
and t.datetime < '2017-12-25'
and cc.type = 'visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.first_name, c.last_name
from customers c, credit_cards cc
where c.ssn = cc.ssn
and cc.type = 'jcb' 
or cc.type = 'visa'
;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.ssn, count(cc.type) as num
from customers c, credit_cards cc
where c.ssn = cc.ssn
group by c.ssn
union
select ssn, 0 as num
from customers
where ssn not in (
select distinct ssn
from credit_cards)
;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.ssn,a.type,case when num is not null then num else 0 end as num
from 
(select distinct c.ssn,cc.type
from customers c, credit_cards cc) a
left join 
(select c.ssn,type,count(cc.type) as num
from customers c, credit_cards cc
where c.ssn = cc.ssn
group by c.ssn,type) b
on a.ssn=b.ssn
and a.type=b.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.country, count(*) as num
from customers c
where exists(
select c.ssn
from customers c, credit_cards cc, merchants m, transactions t
where c.ssn = cc.ssn
and cc.number = t.number
and t.code = m.code
and c.country <> m.country)
group by c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select identifier,a.amount
from (select type,amount,identifier
from transactions t,credit_cards cc
where t.number=cc.number) a,
(select type,max(amount) as amount
from transactions t,credit_cards cc
where t.number=cc.number
group by type) b
where a.type=b.type
and a.amount=b.amount;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select a.identifier
from 
(select identifier,type,amount
from transactions t,credit_cards cc
where t.number=cc.number)  a
where amount >= all (select amount
from transactions t,credit_cards cc
where t.number=cc.number
and type=a.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
select code,name
from merchants
where code not in (
select m.code
from merchants m,transactions t,credit_cards cc
where m.code=t.code
and cc.number=t.number
and type in (
select distinct type
from credit_cards
where type like 'diners-club%'
or type like 'visa%'
)
group by m.code
having max(amount)>=888);

