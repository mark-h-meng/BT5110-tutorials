/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0177964J               */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.ssn
FROM credit_cards c, transactions t
WHERE c.type = 'visa'
AND c.number = t.number
AND t.datetime >= '2017-12-25' AND t.datetime < '2017-12-26';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c1.first_name, c1.last_name 
FROM (
	SELECT DISTINCT c.first_name, c.last_name, c.ssn
	FROM customers c, credit_cards cc
	WHERE c.country = 'Singapore'
	AND c.ssn = cc.ssn
	AND cc.type = 'visa' 
	INTERSECT 
	SELECT DISTINCT c.first_name, c.last_name, c.ssn
	FROM customers c, credit_cards cc
	WHERE c.country = 'Singapore'
	AND c.ssn = cc.ssn
	AND cc.type = 'jcb') AS c1;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, COUNT(cc.number)
FROM customers c LEFT JOIN credit_cards cc ON c.ssn = cc.ssn
GROUP BY c.ssn
ORDER BY COUNT(cc.number);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c1.ssn, cc1.type, COUNT(cc.number)
FROM (
	SELECT DISTINCT c.ssn
	FROM customers c) AS c1
	CROSS JOIN 
	(SELECT DISTINCT cc.type
	FROM credit_cards cc) AS cc1
	LEFT JOIN
	credit_cards cc 
	ON c1.ssn = cc.ssn 
	AND cc1.type = cc.type
GROUP BY c1.ssn, cc1.type
ORDER BY c1.ssn, cc1.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country, COUNT(c.ssn)
FROM customers c 
WHERE EXISTS (
	SELECT *
	FROM merchants m, transactions t, credit_cards cc
	WHERE m.code = t.code
	AND t.number = cc.number
	AND cc.ssn = c.ssn
	AND m.country <> c.country)
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier
FROM credit_cards cc 
	JOIN transactions t ON cc.number = t.number,
	(SELECT cc1.type, MAX(t1.amount)
	 FROM transactions t1 JOIN credit_cards cc1 
	 ON t1.number = cc1.number
	 GROUP BY cc1.type) AS a
WHERE cc.type = a.type
AND t.amount = a.max;
	
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT t.identifier
FROM transactions t
JOIN credit_cards cc ON t.number = cc.number 
WHERE  t.amount >= ALL 
	(SELECT t1.amount
	FROM transactions t1 
	JOIN credit_cards cc1 ON t1.number = cc1.number
	WHERE cc.type = cc1.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m.code, m.name
FROM merchants m 
WHERE m.code NOT IN (
	SELECT m.code
	FROM merchants m 
	JOIN transactions t ON m.code = t.code
	JOIN credit_cards cc ON cc.number = t.number 
	WHERE (cc.type LIKE '%visa%' OR cc.type LIKE '%diners-club%')
	AND t.amount >= 888)
ORDER BY m.code;


