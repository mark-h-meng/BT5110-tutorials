/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : E0709255                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT c.ssn
FROM customers c, credit_cards cc, transactions t
WHERE c.ssn = cc.ssn
AND cc.number = t.number
AND cc.type = 'visa'
AND (t.datetime >='2017-12-25' AND t.datetime< '2017-12-26')
ORDER BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.first_name, a.last_name
FROM (
SELECT DISTINCT c1.ssn, c1.first_name, c1.last_name
FROM customers c1, customers c2, credit_cards cc1, credit_cards cc2
WHERE c1. ssn = cc1. ssn
AND c2.ssn = cc2.ssn
AND cc1.type = 'visa' 
AND cc2.type = 'jcb'
AND c1.ssn=c2.ssn)a
ORDER BY a.first_name, a.last_name;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, count(*) as num_of_cards
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
GROUP BY c.ssn
UNION 
SELECT c.ssn, 0 AS num_of_cards
FROM customers c LEFT OUTER JOIN credit_cards cc
ON c.ssn = cc.ssn
WHERE cc.number ISNULL
ORDER BY num_of_cards; 
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.ssn, a.type, sum(num_of_cards) num_of_cards
FROM(
SELECT cc.ssn, cc.type, count(*)as num_of_cards
FROM credit_cards cc
GROUP BY cc.ssn, cc.type
UNION
SELECT DISTINCT c.ssn, cc.type, 0 as num_of_cards
FROM customers c, credit_cards cc)a
GROUP BY a.ssn, a.type
ORDER BY a.ssn, a.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, count(DISTINCT c.ssn)
FROM customers c, credit_cards cc, merchants m, transactions t
WHERE c.ssn = cc.ssn
AND cc.number = t.number
AND t.code = m.code
AND c.country <> m.country
GROUP BY c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
WITH max_amt AS
(
SELECT cc.type as type, MAX(t.amount)as max_number
FROM credit_cards cc, transactions t
WHERE cc.number=t.number
GROUP BY cc.type
)
SELECT cc1.type, t1.identifier
FROM credit_cards cc1, transactions t1, max_amt
WHERE cc1.number=t1.number
AND t1.amount = max_amt.max_number
AND cc1.type= max_amt.type
ORDER BY cc1.type;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.type, t.identifier, t.amount
FROM credit_cards cc, transactions t
WHERE cc.number=t.number
GROUP BY cc.type, t.identifier
HAVING t.amount >= ALL
	(SELECT t1.amount 
	FROM credit_cards cc1, transactions t1 
	WHERE cc1.number=t1.number
	AND cc.type=cc1.type
	GROUP BY t1.identifier); 
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT m.code, m.name
FROM merchants m, transactions t, credit_cards cc
WHERE m.code = t.code
AND t.number = cc.number
AND t.amount < 888.00
AND (cc.type = 'visa' or cc.type = 'diners-club');
