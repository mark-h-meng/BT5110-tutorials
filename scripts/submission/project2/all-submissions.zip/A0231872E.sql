/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231872E>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct cc.ssn
from credit_cards cc, transactions t
where cc.number=t.number
and extract(year from t.datetime)=2017
and extract(month from t.datetime)=12
and extract(day from t.datetime)=25
and cc.type='visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select A.first_name,A.last_name
from(
select c.ssn,c.first_name,c.last_name
from customers c natural join credit_cards cc
where cc.type='jcb'
and c.country='Singapore'
intersect 
select c.ssn,c.first_name,c.last_name
from customers c left join credit_cards cc on cc.ssn=c.ssn
where cc.type='visa'
and c.country='Singapore')A;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cc.ssn,count(*)
from customers c natural join credit_cards cc 
group by cc.ssn
union
select c.ssn,count(*)-1
from customers c left join credit_cards cc on cc.ssn=c.ssn
where cc.type is null
group by c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cc.ssn,cc.type,count(*) 
from credit_cards cc
group by cc.type,cc.ssn
union
select B.ssn,A.type,count(*)-1
from (select distinct cc.type
from credit_cards cc) A,(select c.ssn
from customers c
where c.ssn not in 
(select cc.ssn
from credit_cards cc
) )B
group by B.ssn,A.type
union
select C.ssn,C.type,count(*)-1
from (select * from(select distinct cc.ssn
from credit_cards cc) D,(select distinct cc.type
from credit_cards cc) E
except
select cc.ssn,cc.type
from credit_cards cc) C
group by C.ssn,C.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.country,count(distinct c.ssn)
from customers c
left join credit_cards cc
on c.ssn=cc.ssn
left join transactions t
on t.number =cc.number
left join merchants m
on m.code=t.code
where c.country<>m.country
group by c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select  t.identifier 
from transactions t natural join credit_cards cc left join (select max(t.amount) max_amount, cc.type
from transactions t left join credit_cards cc
on t.number=cc.number 
group by cc.type) A on A.max_amount=t.amount
where A.type=cc.type;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t.identifier
from transactions t left join credit_cards cc on cc.number=t.number
where t.amount>=all(
select t1.amount
from transactions t1 left join credit_cards cc1 on cc1.number=t1.number
where cc.type=cc1.type );
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select m.code,m.name
from merchants m left join transactions t on m.code=t.code left join credit_cards cc on t.number=cc.number 
except
select m.code,m.name
from merchants m left join transactions t on m.code=t.code left join credit_cards cc on t.number=cc.number 
where (cc.type like '%visa%' or cc.type like '%diners-club%')
and t.amount>=888;
