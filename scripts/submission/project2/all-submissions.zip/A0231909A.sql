/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231909A                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn
FROM credit_cards c
INNER JOIN transactions t ON c.number = t.number
WHERE c.type = 'visa'
AND t.datetime between '2017-12-25' AND '2017-12-26';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m.first_name, m.last_name
FROM customers m
INNER JOIN credit_cards c ON m.ssn = c.ssn
WHERE m.country = 'Singapore'
AND c.type in ('jcb', 'visa')
GROUP BY m.ssn, m.first_name, m.last_name
HAVING COUNT(DISTINCT c.type) = 2;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m.ssn, COUNT(c.number)
FROM customers m
LEFT outer JOIN credit_cards c ON m.ssn = c.ssn
GROUP BY m.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m.ssn, c.type, COUNT(c.number)
FROM customers m
LEFT outer JOIN credit_cards c ON m.ssn = c.ssn
GROUP BY m.ssn, c.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT u.country, COUNT(DISTINCT u.ssn)
FROM customers u
INNER JOIN credit_cards c ON u.ssn = c.ssn
INNER JOIN transactions t ON t.number = c.number
INNER JOIN merchants m ON m.code = t.code
WHERE u.country <> m.country
GROUP BY u.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier, c.type
FROM transactions t
INNER JOIN credit_cards c ON t.number = c.number
INNER JOIN (
    SELECT c.type, MAX(t.amount) AS max_amount
    FROM transactions t
    INNER JOIN credit_cards c ON t.number = c.number
    GROUP BY c.type
) AS a ON c.type = a.type
WHERE t.amount = a.max_amount;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT identifier, type
FROM
(
    SELECT t.identifier, c.type
        , dense_rank() over(partition BY c.type ORDER BY t.amount desc) AS amount_rank
    FROM transactions t
    INNER JOIN credit_cards c ON t.number = c.number
) AS a
WHERE a.amount_rank = 1;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT code, name
FROM merchants m
WHERE NOT EXISTS(
	SELECT t.identifier
	FROM transactions t
	INNER JOIN credit_cards c ON t.number = c.number
	WHERE t.code = m.code
	AND t.amount >= 888
	AND (c.type LIKE '%visa%' OR c.type LIKE '%diners-club%')
);

