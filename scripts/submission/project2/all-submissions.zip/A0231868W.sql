/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231868W                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn
FROM customers c, credit_cards cc, transactions t
WHERE c.ssn = cc.ssn
AND t.number = cc.number
AND (SELECT EXTRACT(DAY FROM t.datetime ))= '25'
AND (SELECT EXTRACT(MONTH FROM t.datetime ))= '12'
AND cc.type = 'visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT first_name, last_name
FROM (SELECT DISTINCT ssn, first_name, last_name
	  FROM customers
	  WHERE country = 'Singapore'
	  AND ssn IN
	  (SELECT ssn
	   FROM credit_cards
       WHERE type ='visa'
	  )
	  AND ssn IN
	  (SELECT ssn
	   FROM credit_cards
       WHERE type ='jcb'
	  )
	 ) d;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, count(cc.number) AS number_of_cards
FROM customers c LEFT JOIN credit_cards cc
ON c.ssn = cc.ssn
GROUP BY c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT r.ssn, g.type, COUNT(d.type) num
FROM (SELECT DISTINCT type FROM credit_cards) g CROSS JOIN
     (SELECT DISTINCT ssn FROM customers) r LEFT JOIN
     (SELECT c.ssn, cc.type FROM customers c LEFT JOIN credit_cards cc
			ON c.ssn = cc.ssn) d
      ON d.ssn = r.ssn AND d.type = g.type
GROUP BY r.ssn, g.type
ORDER BY r.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, count( distinct c.ssn ) as num
FROM customers c, merchants m, transactions t, credit_cards cc
WHERE c.ssn = cc.ssn
AND cc.number = t.number
AND t.code = m.code
AND c.country <> m.country
GROUP BY c.country
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT n.identifier, s.type, s.largest
FROM (SELECT cc.type, t.identifier, t.amount
	    FROM transactions t, credit_cards cc
      WHERE t.number = cc.number) n,

     (SELECT cc.type, max(t.amount) largest
      FROM transactions t, credit_cards cc
      WHERE t.number = cc.number
      GROUP BY cc.type) s
WHERE n.amount = s.largest
AND n.type = s.type
ORDER BY type
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier, cc1.type, t.amount
FROM transactions t, credit_cards cc1
WHERE cc1.number = t.number
AND t.amount >=
ALL (SELECT t1.amount
	   FROM transactions t1, credit_cards cc2
	   WHERE cc2.number = t1.number
	   AND cc1.type = cc2.type
	  )
ORDER BY type
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT code, name
FROM merchants
EXCEPT
SELECT DISTINCT m.code, m.name
FROM merchants m, transactions t, credit_cards cc
WHERE m.code = t.code
AND cc.number = t.number
AND t.amount >=888
AND (cc.type = 'visa'
OR cc.type = 'diners-club')
