/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231894X                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cu.ssn 
FROM customers cu, transactions t, credit_cards cc 
WHERE cu.ssn = cc.ssn 
AND cc.number = t.number 
AND t.datetime BETWEEN '2017-12-25' AND '2017-12-26' 
AND cc.type = 'visa'; 
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cu.first_name, cu.last_name 
FROM customers cu
WHERE cu.ssn = ANY(
	SELECT cc1.ssn 
	FROM credit_cards cc1, credit_cards cc2 
	WHERE cu.country = 'Singapore' 
	AND cc1.ssn = cc2.ssn 
	AND cc1.ssn = cu.ssn 
	AND cc1.type = 'visa' 
	AND cc2.type = 'jcb' 
);
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */ 
SELECT cu.ssn, COUNT(cc.number) 
FROM customers cu LEFT OUTER JOIN credit_cards cc 
ON cu.ssn = cc.ssn 
GROUP BY cu.ssn ; 
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t2.ssn, t2.type, CASE WHEN t3.count ISNULL THEN 0 ELSE t3.count END AS t
FROM (
	SELECT cu.ssn, t1.type FROM customers cu, (
		SELECT DISTINCT type FROM credit_cards
	) AS t1
) AS t2 
LEFT OUTER JOIN (
	SELECT cu.ssn, cc.type, COUNT(cc.number) AS count
	FROM customers cu LEFT OUTER JOIN credit_cards cc
	ON cu.ssn = cc.ssn
	GROUP BY cu.ssn, cc.type
) AS t3
ON t2.ssn = t3.ssn
AND t2.type = t3.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cu.country, COUNT(DISTINCT cc.ssn) 
FROM customers cu, credit_cards cc, merchants m, transactions t 
WHERE cu.ssn = cc.ssn 
AND cc.number = t.number 
AND m.code = t.code 
AND cu.country <> m.country 
GROUP BY cu.country; 
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.type, t.identifier, t.amount 
FROM credit_cards cc, transactions t, (
	SELECT cc.type, MAX(t.amount) AS amount
	FROM credit_cards cc, transactions t 
	WHERE cc.number = t.number 
	GROUP BY cc.type 
) AS max_amount 
WHERE t.amount = max_amount.amount 
AND cc.type = max_amount.type 
AND cc.number = t.number;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc1.type, t1.identifier, t1.amount 
FROM credit_cards cc1, transactions t1 
WHERE cc1.number = t1.number
AND NOT EXISTS (
	SELECT *
	FROM credit_cards cc2, transactions t2 
	WHERE t1.amount < t2.amount 
	AND cc2.number = t2.number 
	AND cc1.type = cc2.type
);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below:*/
SELECT m.code, m.name 
FROM merchants m 
WHERE m.code NOT IN (
	SELECT m.code
	FROM merchants m, transactions t, credit_cards cc 
	WHERE cc.number = t.number 
	AND m.code = t.code 
	AND (cc.type LIKE 'visa%' OR cc.type LIKE 'diners-club%')
	AND t.amount >= 888 
);