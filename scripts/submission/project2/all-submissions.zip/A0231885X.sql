/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231885X                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn
FROM credit_cards cc JOIN transactions t ON cc.number=t.number
WHERE cc.type = 'visa'
AND CAST(t.datetime AS DATE) = '2017-12-25';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT name.first_name, name.last_name 
FROM (SELECT cu.ssn, cu.first_name, cu.last_name
FROM customers cu INNER JOIN credit_cards cc ON cu.ssn = cc.ssn 
	  INNER JOIN Transactions t ON cc.number=t.number
WHERE cu.country = 'Singapore' AND cc.type = 'jcb'
INTERSECT
SELECT cu.ssn, cu.first_name, cu.last_name
FROM customers cu INNER JOIN credit_cards cc ON cu.ssn = cc.ssn 
	  INNER JOIN Transactions t ON cc.number=t.number
WHERE cu.country = 'Singapore' AND cc.type = 'visa'
) AS name;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cu.ssn, COUNT(cc.number)
FROM customers cu 
LEFT OUTER JOIN credit_cards cc ON cu.ssn = cc.ssn
GROUP BY cu.ssn
ORDER BY COUNT;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT sin.ssn, card.type, COUNT(*)
FROM (SELECT cu.ssn FROM customers cu) sin CROSS JOIN (SELECT cc.type FROM credit_cards cc) card
	LEFT OUTER JOIN credit_cards cc ON sin.ssn = cc.ssn AND card.type = cc.type
GROUP BY sin.ssn, card.type
ORDER BY sin.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cu.country, COUNT(*)
FROM transactions t INNER JOIN credit_cards cc ON t.number = cc.number 
INNER JOIN customers cu ON cc.ssn = cu.ssn INNER JOIN merchants m ON t.code = m.code
WHERE cu.country < m.country OR cu.country > m.country
GROUP BY cu.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM transactions t INNER JOIN credit_cards cc ON t.number = cc.number
WHERE t.amount = (select MAX(transfer.amount)
 	FROM transactions transfer
 	INNER JOIN credit_cards cc1 ON transfer.number = cc1.number
    WHERE cc1.type=cc.type);
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM transactions t 
JOIN credit_cards cc ON t.number = cc.number
WHERE t.amount >= ALL(
	SELECT t1.amount FROM transactions t1
	JOIN credit_cards cc1 ON t1.number = cc1.number
	WHERE cc.type = cc1.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT m.code, m.name FROM merchants m
WHERE m.code NOT IN
(SELECT m.code FROM transactions t LEFT OUTER JOIN merchants m ON t.code = m.code
	LEFT OUTER JOIN credit_cards cc ON t.number = cc.number
	WHERE t.amount >= 888 AND (cc.type LIKE '%visa%' OR cc.type LIKE '%diners-club%'));
