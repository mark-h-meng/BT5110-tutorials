/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0231854E>                						    */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
-- ##(a) Used like function because I interpreted the question as to include electronic visa as well
-- ##Thus both 'visa' and 'visa-electron' will be showing in the result
select credit_cards.ssn, credit_cards.type from 
(transactions inner join credit_cards on transactions.number = credit_cards.number)
where credit_cards.type like '%visa%' and transactions.datetime between '2017-12-25 00:00:00' and '2017-12-25 23:59:59';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
-- ##(b) interepreted the 'visa' requirement as 'including visa-electron' as well
select distinct credit_cards.ssn, first_name, last_name  from credit_cards 
inner join customers on credit_cards.ssn = customers.ssn
where country='Singapore' and (credit_cards.type like '%visa%' or credit_cards.type = 'jcb');

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select customers.ssn, count(credit_cards.number) from 
customers left join credit_cards on customers.ssn = credit_cards.ssn
group by customers.ssn order by customers.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select customers.ssn, credit_cards.type, count(credit_cards.number) from 
customers left join credit_cards on customers.ssn = credit_cards.ssn
group by customers.ssn, credit_cards.type order by customers.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select customers.country, count(customers.ssn) from merchants, transactions, credit_cards, customers where
merchants.code = transactions.code and
transactions.number = credit_cards.number and
credit_cards.ssn = customers.ssn and 
merchants.country <> customers.country
group by customers.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select identifier
from credit_cards inner join transactions on credit_cards.number = transactions.number
where (credit_cards.type, amount) in (
	select credit_cards.type, max(transactions.amount) as amount 
	from credit_cards inner join transactions on credit_cards.number = transactions.number
	group by credit_cards.type);
	
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select T.identifier
from (credit_cards inner join transactions on credit_cards.number = transactions.number) as T
where not exists (
	select * 
	from (credit_cards inner join transactions on credit_cards.number = transactions.number) 
	where T.amount < transactions.amount and T.type = credit_cards.type );

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select merchants.code, merchants.name 
from merchants 
where merchants.code 
not in (
	select merchants.code from merchants, transactions, credit_cards 
	where merchants.code = transactions.code 
	and transactions.number = credit_cards.number 
	and transactions.amount >888 
	and transactions.amount =888 
	and (credit_cards.type like '%visa%' or credit_cards.type = 'dinners-club')
);
