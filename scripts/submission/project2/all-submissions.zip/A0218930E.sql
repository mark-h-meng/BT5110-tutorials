/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0218930E>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cc.ssn
FROM transactions t
LEFT JOIN credit_cards cc
ON t.number = cc.number
WHERE DATE(datetime) = DATE('2017-12-25') AND cc.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.first_name, c.last_name
FROM customers c
LEFT JOIN credit_cards cc ON cc.ssn = c.ssn
WHERE c.country = 'Singapore'
AND cc.type = 'jcb'
AND cc.ssn IN (SELECT DISTINCT cc.ssn
				FROM credit_cards cc
				WHERE cc.type='visa');

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, COALESCE(count(type), 0) AS num_card_types_own
FROM customers c
LEFT JOIN credit_cards cc ON c.ssn = cc.ssn
GROUP BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.ssn, type, COALESCE(count(number), 0) AS num_cards_own
FROM customers c
INNER JOIN credit_cards cc ON c.ssn = cc.ssn
GROUP BY 1, 2;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT c.country, count(c.ssn)
FROM customers c
INNER JOIN (SELECT t.code, cc.ssn
			FROM transactions t
			LEFT JOIN credit_cards cc ON t.number = cc.number) temp ON temp.ssn = c.ssn
LEFT JOIN merchants m ON m.code = temp.code
WHERE c.country <> m.country
GROUP BY c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT cc.type, t.identifier, t.amount
FROM transactions t, credit_cards cc, (SELECT cc.type, MAX(t.amount) as max_amount
										FROM transactions t
										JOIN credit_cards cc ON t.number = cc.number
										GROUP BY cc.type) temp
WHERE t.number = cc.number AND concat(t.amount, cc.type) = concat(temp.max_amount, temp.type);

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* fast */
SELECT temp.identifier, temp.type, temp.amount
FROM (SELECT cc.type, t.identifier, t.amount,
        ROW_NUMBER() OVER (PARTITION BY cc.type ORDER BY t.amount DESC) AS rank_num
	  FROM credit_cards cc
	  LEFT JOIN transactions t ON t.number = cc.number) temp
WHERE temp.rank_num = 1;

/* slow */
SELECT t1.identifier, cc1.type, t1.amount
FROM transactions t1, credit_cards cc1
WHERE t1.number = cc1.number
AND t1.amount >= ALL (SELECT t2.amount
                      FROM transactions t2, credit_cards cc2
                      WHERE t2.number = cc2.number
                      AND cc2.type = cc1.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m.code, m.name
FROM merchants m
WHERE m.code NOT IN (SELECT m.code
					FROM merchants m
					LEFT JOIN transactions t ON t.code = m.code
					LEFT JOIN credit_cards cc ON cc.number = t.number
					WHERE t.amount >= 888
					AND (cc.type LIKE '%visa%' OR cc.type LIKE '%diners-club%'));
