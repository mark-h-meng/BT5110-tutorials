/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0232196E>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.ssn from transactions t join credit_cards c 
on t.number = c.number where date(t.datetime) = '2017-12-25' 
and c.type = 'visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select first_name, last_name from customers where ssn in 
(select c.ssn from customers c join credit_cards cc on c.ssn = cc.ssn
where c.country = 'Singapore' and cc.type = 'jcb')
and ssn in 
(select c.ssn from customers c join credit_cards cc on c.ssn = cc.ssn
where c.country = 'Singapore' and cc.type = 'visa')
;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.ssn, count(cc.ssn) 
from customers c left join credit_cards cc 
on c.ssn = cc.ssn
group by c.ssn
order by count(cc.ssn) desc;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select a.ssn, a.type, COUNT(cc.type)
from (select distinct c.ssn, cc.type
FROM customers c, credit_cards cc) a
left join credit_cards cc
on a.ssn = cc.ssn
and a.type = cc.type
group by a.ssn, a.type
order by a.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.country, count(distinct c.ssn) from
transactions t join merchants m on t.code = m.code
join credit_cards cc on t.number = cc.number 
join customers c on cc.ssn = c.ssn
where c.country != m.country
group by c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select cc.type, t.amount, t.identifier 
from transactions t
join credit_cards cc on t.number = cc.number
where (cc.type, t.amount) in (select cc.type, max(tt.amount)
from transactions tt join credit_cards cc on tt.number = cc.number
group by cc.type);


/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.type, t.identifier, t.amount
from credit_cards cc join transactions t
on cc.number = t.number 
and t.amount >= all(
select tt.amount from transactions tt, credit_cards ccc
where tt.number = ccc.number and cc.type = ccc.type);


/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct m.code, m.name
from merchants m
where m.code not in 
(select m.code from transactions t, credit_cards cc, merchants m
where m.code = t.code and t.number = cc.number
and t.amount >= 888
and (cc.type like 'visa%' or cc.type like 'diners_club%'));
