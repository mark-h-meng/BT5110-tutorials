/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231941L  */
/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn
FROM customers c, credit_cards cc, transactions t
WHERE c.ssn=cc.ssn
AND cc.number=t.number
AND cc.type='visa'
AND date(t.datetime)='2017-12-25';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c1.first_name, c1.last_name
FROM(
	SELECT c.ssn, c.first_name, c.last_name
	FROM customers c, credit_cards cc
	WHERE c.ssn=cc.ssn
	AND cc.type='jcb'
	AND c.country='Singapore'
	INTERSECT
	SELECT c.ssn, c.first_name, c.last_name
	FROM customers c, credit_cards cc
	WHERE c.ssn=cc.ssn
	AND cc.type='visa'
	AND c.country='Singapore') c1;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, COUNT(cc.number)
FROM customers c LEFT OUTER JOIN credit_cards cc ON c.ssn=cc.ssn
GROUP BY c.ssn
ORDER BY COUNT(cc.number);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT a.ssn, a.type, COUNT(cc1.number)
FROM (
	SELECT c.ssn, cc.type
	FROM customers c, (
		SELECT DISTINCT type
		FROM credit_cards) cc
) a
LEFT JOIN credit_cards cc1 ON (a.ssn, a.type) = (cc1.ssn, cc1.type)
GROUP BY a.ssn, a.type
ORDER BY a.ssn, a.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT(DISTINCT c.ssn)
FROM customers c, credit_cards cc, transactions t, merchants m
WHERE c.ssn=cc.ssn
AND cc.number=t.number
AND t.code=m.code
AND c.country <> m.country
GROUP BY c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.type, t.identifier
FROM credit_cards cc, transactions t
WHERE cc.number=t.number
AND (cc.type,t.amount) IN (
	SELECT cc1.type, max(t1.amount)
	FROM credit_cards cc1, transactions t1
	WHERE cc1.number=t1.number
	GROUP BY cc1.type);
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT cc.type, t.identifier
FROM credit_cards cc, transactions t
WHERE cc.number=t.number
GROUP BY cc.type, t.identifier
HAVING t.amount >= ALL(
	SELECT t1.amount
	FROM transactions t1, credit_cards cc1
	WHERE cc1.number=t1.number
	AND cc.type=cc1.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT m.code, m.name
FROM merchants m
WHERE (m.code, m.name) NOT IN(
	SELECT DISTINCT m1.code, m1.name
	FROM merchants m1, transactions t, (
		SELECT * 
		FROM credit_cards cc
		WHERE cc.type LIKE 'visa%' OR cc.type LIKE 'diners-club%') cc1
	WHERE m1.code=t.code
	AND t.number=cc1.number
	GROUP BY m1.code, m1.name, cc1.type
	HAVING max(t.amount)>=888);
