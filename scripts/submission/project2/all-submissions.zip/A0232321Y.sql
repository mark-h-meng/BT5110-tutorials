/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0232321Y>                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT cc.ssn
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND date(t.datetime) = '2017-12-25'
AND cc.type = 'visa';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.first_name, c.last_name
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
AND cc.type = 'jcb'
AND c.country = 'Singapore'
GROUP BY c.ssn
INTERSECT
SELECT c.first_name, c.last_name
FROM customers c, credit_cards cc
WHERE c.ssn = cc.ssn
AND cc.type = 'visa'
AND c.country = 'Singapore'
GROUP BY c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, COUNT(cc.number)
FROM customers c
LEFT JOIN credit_cards cc ON c.ssn = cc.ssn
GROUP BY c.ssn
ORDER BY c.ssn;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, type.type, COUNT(cc.number)
FROM customers c
CROSS JOIN
(SELECT DISTINCT cc.type FROM credit_cards cc) type
LEFT JOIN credit_cards cc ON c.ssn = cc.ssn AND type.type = cc.type
GROUP BY c.ssn,type.type
ORDER BY c.ssn, type.type;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT(DISTINCT c.ssn)
FROM customers c, credit_cards cc, transactions t, merchants m
WHERE c.ssn = cc.ssn
AND cc.number = t.number
AND t.code = m.code
AND c.country != m.country
GROUP BY c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM transactions t, credit_cards cc,
	(SELECT cc1.type AS type, MAX(t1.amount) AS amount
	FROM transactions t1,credit_cards cc1
	WHERE cc1.number = t1.number
	GROUP BY cc1.type) max_amount
WHERE t.number = cc.number
AND t.amount = max_amount.amount
AND cc.type = max_amount.type;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM transactions t, credit_cards cc
WHERE t.amount >= ALL (
		SELECT t1.amount
		FROM transactions t1, credit_cards cc1
		WHERE t1.number = cc1.number
		AND cc1.type = cc.type)
AND cc.number = t.number;
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT x.code, x.name
FROM  
	(SELECT m.code AS code, m.name AS name, MAX(t.amount) AS max_amount
	FROM transactions t, merchants m, credit_cards cc
	WHERE t.code = m.code
	AND t.number = cc.number
	AND (cc.type = 'visa' or cc.type = 'diners_club')
	GROUP BY m.code) x
WHERE x.max_amount < 888;


