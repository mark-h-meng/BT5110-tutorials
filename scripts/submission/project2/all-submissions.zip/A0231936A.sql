/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231936A                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT c.ssn
FROM customers c, credit_cards cc, transactions t
WHERE c.ssn = cc.ssn
AND cc.number = t.number
AND cc.type = 'visa'
AND date(t.datetime) = '2017-12-25';
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT jv.first_name, jv.last_name
FROM (SELECT c.first_name, c.last_name, c.ssn
	  FROM customers c, credit_cards cc
	  WHERE c.ssn = cc.ssn
	  AND cc.type = 'jcb'
	  AND c.country = 'Singapore'
	  INTERSECT
	  SELECT c.first_name, c.last_name, c.ssn
	  FROM customers c, credit_cards cc
	  WHERE c.ssn = cc.ssn
	  AND cc.type = 'visa'
	  AND c.country = 'Singapore') AS jv
ORDER BY jv.first_name;
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.ssn, COUNT(cc.number) AS number_of_cards
FROM customers c LEFT JOIN credit_cards cc
ON c.ssn = cc.ssn
GROUP BY c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE VIEW card_type AS
SELECT DISTINCT c.ssn, cc.type
FROM customers c, credit_cards cc;

SELECT ct.ssn, ct.type, COUNT(cc.type) AS number_of_cards
FROM card_type ct
LEFT JOIN credit_cards cc
ON ct.ssn = cc.ssn
AND ct.type = cc.type
GROUP BY ct.ssn, ct.type
ORDER BY ct.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT c.country, COUNT(DISTINCT c.ssn)
FROM customers c, credit_cards cc, transactions t, merchants m
WHERE c.ssn = cc.ssn
AND cc.number = t.number
AND t.code = m.code
AND c.country != m.country
GROUP BY c.country;
/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM credit_cards cc,
	 transactions t,
	 (SELECT cc2.type AS type, MAX(t2.amount) AS max
	  FROM transactions t, transactions t2, credit_cards cc2
	  WHERE t2.number = cc2.number
	  AND t.identifier = t2.identifier
	  GROUP BY cc2.type) AS m
WHERE cc.number = t.number
AND t.amount = m.max
AND cc.type = m.type;
/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT t.identifier
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
AND t.amount >= ALL(SELECT t2.amount
					FROM transactions t2, credit_cards cc2
					WHERE t2.number = cc2.number
				    AND cc.type = cc2.type);
/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT DISTINCT m.code, m.name
FROM merchants m
WHERE m.code NOT IN (SELECT m.code
					FROM merchants m, transactions t, credit_cards cc
					WHERE m.code = t.code
					AND t.number = cc.number
					AND t.amount >= 888
					AND (cc.type LIKE '%visa%' OR cc.type LIKE '%diners-club%'))