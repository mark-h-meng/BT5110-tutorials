/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0218897H                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.ssn from transactions t 
left join credit_cards c on t.number = c.number
where t.datetime >= '2017-12-25 00:00:00' and t.datetime < '2017-12-26 00:00:00'
and c.type = 'visa';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select first_name, last_name from customers c1
where c1.ssn in (select c2.ssn from credit_cards c2 where c2.type = 'jcb'
				or c2.type = 'visa' group by c2.ssn having 
				 count(concat(c2.ssn, c2.type)) >= 2)
order by first_name;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c1.ssn, count(c2.number) as n_cards from customers c1
left join credit_cards c2 on c1.ssn = c2.ssn
group by c1.ssn
order by n_cards asc;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select A.ssn, A.type, count(B.type) from
(select c1.ssn, c2.type
from customers c1, (select distinct type from credit_cards) c2)A
left join credit_cards B on A.ssn = B.ssn and A.type = B.type
group by A.ssn, A.type
order by A.ssn, A.type;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c2.country, count(distinct c2.ssn) from transactions t
left join merchants m on t.code = m.code
left join credit_cards c1 on t.number = c1.number
left join customers c2 on c1.ssn =c2.ssn
where m.country <> c2.country
group by c2.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select B.identifier from
(select c.type, max(amount) as num from transactions t
left join credit_cards c on t.number = c.number
group by c.type) A
left join
(select c.type, t.identifier, t.amount from transactions t
left join credit_cards c on t.number = c.number) B 
on A.type = B.type and A.num = B.amount;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t.identifier from transactions t
left join credit_cards c on t.number = c.number
where t.amount >= ALL(
	select t1.amount from transactions t1
	left join credit_cards c1 on t1.number = c1.number
	where c.type = c1.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select code, name from merchants 
where code not in 
	(select t.code from transactions t left join credit_cards c
	on t.number = c.number where t.amount >= 888
	and
	('visa' ~ c.type or 'diners-club' ~ c.type));
