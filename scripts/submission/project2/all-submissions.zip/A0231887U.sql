/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231887U / Donghwan Kim                            */



/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select cc.ssn
from credit_cards as cc  
inner join transactions as t on cc.number = t.number
where 1=1
  and cc.type = 'visa' 
  and t.datetime >= '2017-12-25 00:00:00.000000' 
  and t.datetime < '2017-12-26 00:00:00.000000' 
group by 1
;



/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select j.first_name, j.last_name
from (
	 select c.ssn, c.first_name, c.last_name
	 from customers c
	 inner join credit_cards cc on c.ssn = cc.ssn
	 where 1=1 
	   and c.country = 'Singapore'
	   and cc.type = 'jcb'
	 group by 1,2,3
) as j
inner join (
	 select c.ssn, c.first_name, c.last_name
	 from customers c
	 inner join credit_cards cc on c.ssn = cc.ssn
	 where 1=1
	   and c.country = 'Singapore'
	   and cc.type = 'visa'
	 group by 1,2,3
) as v
on (j.ssn = v.ssn and j.first_name = v.first_name and j.last_name = v.last_name)



/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.ssn as ssn, count(*) as cnt
from customers c  
left join credit_cards cc on c.ssn = cc.ssn  
where 1=1  
  -- and c.first_name = 'John'
  and cc.ssn is not null
group by 1
union
select c.ssn as ssn, 0 as cnt
from customers c  
left join credit_cards cc on c.ssn = cc.ssn  
where 1=1  
  -- and c.first_name = 'John'
  and cc.ssn is null
group by 1
;



/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.ssn, cc.type, count(*) as cnt
from customers as c
left join credit_cards cc on c.ssn = cc.ssn
where 1=1
  and cc.ssn is not null
group by 1,2
union
select c.ssn, cc.type, 0 as cnt
from customers as c
left join credit_cards cc on c.ssn = cc.ssn
where 1=1
  and cc.ssn is null
group by 1,2
;



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select c.country as cntr_c
	 , count(distinct c.ssn) as cnt
--     c.country as ctr_customer
-- 	 , count(distinct ssn)
from transactions t
inner join credit_cards cc on cc.number = t.number
inner join merchants m on m.code = t.code
inner join customers c on c.ssn = cc.ssn
where 1=1
  and c.country != m.country
group by 1
order by 1
;



/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select cc.type, count(distinct t.identifier) as cnt
from transactions as t
inner join credit_cards as cc on cc.number = t.number 
group by 1
limit 1



/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select t.identifier 
from (
	select cc.type, t.identifier
	from transactions as t
	inner join credit_cards as cc on cc.number = t.number 
	order by 1
	limit 1
) t



/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

select m.code, m.name
from transactions t 
inner join merchants m on m.code = t.code
inner join credit_cards cc on cc.number = t.number
where 1=1
  and (cc.type like '%visa%' or cc.type like '%diners-club%')
group by 1,2
having max(t.amount) < 888
;




