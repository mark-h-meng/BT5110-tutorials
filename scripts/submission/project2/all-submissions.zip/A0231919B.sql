/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231919B                  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct c.ssn from customers c, credit_cards cc, transactions t
where c.ssn = cc.ssn
and cc.number = t.number
and cc.type = 'visa'
and date(t.datetime) = '2017-12-25';

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.first_name, c.last_name, count(cc.type) from customers c, credit_cards cc
where c.ssn = cc.ssn
and c.country = 'Singapore'
and (cc.type = 'jcb' or cc.type = 'visa')
group by c.first_name, c.last_name, c.ssn 
having count(distinct cc.type) >1;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.ssn, case when count(cc.number) is null then 0 else count(cc.number) end
from customers c 
left join credit_cards cc
on c.ssn = cc.ssn
group by c.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select ct.ssn, ct.type, case when count(cc.type) is null then 0 else count(cc.type) end
from (
	select distinct c.ssn, cc.type
	from customers c, credit_cards cc) as ct
left join credit_cards cc
on ct.ssn = cc.ssn
and ct.type = cc.type
group by ct.ssn, ct.type
order by ct.ssn;
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select c.country, count(distinct c.ssn)
from customers c, credit_cards cc, merchants m, transactions t
where c.ssn = cc.ssn
and cc.number = t.number
and m.code = t.code
and m.country <> c.country
group by c.country;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t.identifier
from transactions t
inner join credit_cards cc 
on cc.number = t.number
inner join(
	select cc.type as type, max(t.amount) as amount 
	from transactions t, credit_cards cc
	where cc.number = t.number 
	group by cc.type) mm
on cc.type = mm.type
and t.amount = mm.amount;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select t1.identifier
from transactions t1
inner join credit_cards cc1 
on cc1.number = t1.number
where not exists(
	select t2.identifier
	from transactions t2
	inner join credit_cards cc2
	on cc2.number = t2.number
	where t1.amount<t2.amount
	and cc1.type = cc2.type);

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
select distinct m.code, m.name
from merchants m
where m.code not in (
	select m.code
	from merchants m, transactions t, credit_cards cc
	where m.code = t.code
	and t.number = cc.number
	and t.amount >= 888
	and (cc.type like '%visa%' or cc.type like '%diners-club%'));