/************************************************************************/
/*                                                                      */
/* Project Credit Cards                                                 */
/*                                                                      */
/************************************************************************/
/* Student Number : A0231921N                 */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT DISTINCT cc.ssn
FROM credit_cards cc, transactions t
WHERE cc.number = t.number
    AND cc.type = 'visa' 
    AND date(t.datetime) = '2017-12-25'
;

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

WITH jcb_ssn AS (
    SELECT DISTINCT cc.ssn
    FROM credit_cards cc
    WHERE cc.type = 'jcb'),
    
    visa_ssn AS
    (SELECT DISTINCT cc.ssn
    FROM credit_cards cc
    WHERE cc.type = 'visa')

SELECT ct.first_name, ct.last_name
FROM jcb_ssn jcb, visa_ssn vs, customers ct
WHERE jcb.ssn = vs.ssn 
    AND vs.ssn = ct.ssn
    AND ct.country = 'Singapore'
;

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


SELECT ct.ssn, COUNT(cc.number)
FROM customers ct LEFT JOIN credit_cards cc
    ON ct.ssn = cc.ssn
GROUP BY ct.ssn
;

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

WITH cardtypes AS(
	SELECT DISTINCT type
	FROM credit_cards cc)
	
SELECT ct.ssn, typ.type, count(cc.number)
FROM customers ct
	CROSS JOIN cardtypes typ 
	LEFT JOIN credit_cards cc
	ON ct.ssn = cc.ssn
	AND typ.type = cc.type
GROUP BY ct.ssn, typ.type
ORDER BY ct.ssn, typ.type
;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT ct.country AS buyer_country, COUNT (DISTINCT ct.ssn) AS bought_overseas
FROM transactions t, credit_cards cc, customers ct, merchants m
WHERE t.number = cc.number
    AND cc.ssn = ct.ssn
	AND t.code = m.code
	AND ct.country <> m.country
GROUP BY ct.country
;

/************************************************************************/
/*                                                                      */
/* Question 1.f                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
WITH max_by_card_type AS 
	(SELECT cc.type, MAX(amount) as amount
	FROM transactions t, credit_cards cc
	WHERE t.number = cc.number
	GROUP BY cc.type)

SELECT t.identifier
FROM transactions t, max_by_card_type mx, credit_cards cc
WHERE t.number = cc.number
	AND cc.type = mx.type
	AND t.amount = mx.amount
;

/************************************************************************/
/*                                                                      */
/* Question 1.g                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT trank.identifier
FROM (SELECT t.identifier, t.amount, cc.type, RANK() OVER(PARTITION BY cc.type ORDER BY t.amount DESC) rank
	FROM transactions t, credit_cards cc
	WHERE t.number = cc.number) AS trank
WHERE trank.rank = 1
ORDER BY trank.identifier
;

/************************************************************************/
/*                                                                      */
/* Question 1.h                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT m.code, m.name
FROM merchants m
WHERE m.code NOT IN (
	SELECT DISTINCT m.code
	FROM transactions t, merchants m, credit_cards cc
	WHERE t.number = cc.number
		AND t.code = m.code
		AND t.amount >=888
		AND (cc.type LIKE '%visa%' OR cc.type LIKE '%diners-club%')
	)
;