CREATE OR REPLACE FUNCTION random_between(min INT ,max INT) 
   RETURNS INT AS
$$
BEGIN
   RETURN floor(random()* (max-min + 1) + min);
END;
$$ language 'plpgsql';

SELECT random_between(1, 10) AS A
FROM generate_series(1,5);

INSERT INTO R (A, B, C, D, E) SELECT DISTINCT 
    random_between(0, 999)  AS A, 
    random_between(0, 9) AS B,
	0 AS C,
	0 AS D,
	0 AS E
FROM generate_series(1, 10000);

UPDATE R SET C = A + (B * 1000);
UPDATE R SET D = MOD(C, 2);
UPDATE R SET E = MOD(C, 3);

SELECT R0.C 
FROM R R0
WHERE R0.E = 0
AND R0.C NOT IN (SELECT R1.C 
FROM R R1 
WHERE R1.E = R0.E 
	AND (R1.C, R1.A) IN (
	   SELECT R2.C, R2.C 
	   FROM R R2 
	   WHERE R2.A = R2.C 
	   AND R1.B <> R2.B));
