/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for SQLite */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
My exmaple is from a zoo DBMS where data of zoo-keepers and animals are 
linked with `feed` relationship. The zoo-keepers' data are in `Employee` 
table, which contains basic infomation of employees in the zoo. The 
animals' data are kept in `Animal` table, which contains basic infomation 
of the animals. The feeding relationship is kept in `Feed` table, which 
contains the duties and details of zoo-keepers.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table Employee (
	EmployeeId VARCHAR(50) NOT NULL,
	Name VARCHAR(50) NOT NULL,
	Gender VARCHAR(50) NOT NULL,
	Age INT NOT NULL,
    PRIMARY KEY (EmployeeId)
);
create table Animal (
	AnimalId VARCHAR(50) NOT NULL,
	Name VARCHAR(50) NOT NULL,
	Gender VARCHAR(50) NOT NULL,
	Age INT NOT NULL,
	Carnivorous INT NOT NULL,
    PRIMARY KEY (AnimalId)
);
create table Feed (
	EmployeeId VARCHAR(50) NOT NULL,
	AnimalId VARCHAR(50) NOT NULL,
	Food VARCHAR(50) NOT NULL,
	Frequency INT NOT NULL,
    PRIMARY KEY (EmployeeId, AnimalId),
    FOREIGN KEY (EmployeeId) REFERENCES Employee(EmployeeId) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (AnimalId) REFERENCES Animal(AnimalId) ON DELETE CASCADE ON UPDATE CASCADE
);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into Employee (EmployeeId, Name, Gender, Age) values ('60-0845032', 'Aleece Collet', 'Male', 48);
insert into Employee (EmployeeId, Name, Gender, Age) values ('92-9930708', 'Pearline McAndie', 'Female', 48);
insert into Employee (EmployeeId, Name, Gender, Age) values ('99-8627071', 'Becca Pires', 'Male', 44);
insert into Employee (EmployeeId, Name, Gender, Age) values ('00-7658191', 'June Besque', 'Male', 26);
insert into Employee (EmployeeId, Name, Gender, Age) values ('99-2477599', 'Leonelle Torvey', 'Female', 41);
insert into Employee (EmployeeId, Name, Gender, Age) values ('46-1349805', 'Court Peddie', 'Male', 29);
insert into Employee (EmployeeId, Name, Gender, Age) values ('30-4709587', 'Virgie Crookes', 'Male', 29);
insert into Employee (EmployeeId, Name, Gender, Age) values ('06-1385536', 'Emmalyn Stitcher', 'Female', 44);
insert into Employee (EmployeeId, Name, Gender, Age) values ('77-8726787', 'Bonni Precious', 'Female', 24);
insert into Employee (EmployeeId, Name, Gender, Age) values ('12-6035386', 'Izabel Goodnow', 'Female', 32);
insert into Employee (EmployeeId, Name, Gender, Age) values ('06-4410304', 'Ursala Willavize', 'Female', 42);
insert into Employee (EmployeeId, Name, Gender, Age) values ('22-2491940', 'Reeba Chisholm', 'Female', 26);
insert into Employee (EmployeeId, Name, Gender, Age) values ('51-1456348', 'Burt MacKilroe', 'Female', 44);
insert into Employee (EmployeeId, Name, Gender, Age) values ('25-8607686', 'Cornela Jenkyn', 'Female', 40);
insert into Employee (EmployeeId, Name, Gender, Age) values ('51-7425470', 'Nydia Blewitt', 'Male', 31);
insert into Employee (EmployeeId, Name, Gender, Age) values ('55-0139397', 'Nerita Sharvell', 'Female', 20);
insert into Employee (EmployeeId, Name, Gender, Age) values ('25-4383035', 'Godiva Filppetti', 'Female', 23);
insert into Employee (EmployeeId, Name, Gender, Age) values ('63-1070824', 'Pansie Abells', 'Female', 38);
insert into Employee (EmployeeId, Name, Gender, Age) values ('89-4591229', 'Bathsheba Skett', 'Male', 35);
insert into Employee (EmployeeId, Name, Gender, Age) values ('06-4596435', 'Elene Grog', 'Female', 27);
insert into Employee (EmployeeId, Name, Gender, Age) values ('06-7323469', 'Warde Huzzey', 'Female', 22);
insert into Employee (EmployeeId, Name, Gender, Age) values ('37-6722121', 'Elmira Kildahl', 'Male', 46);
insert into Employee (EmployeeId, Name, Gender, Age) values ('90-2631532', 'Bev MacGillivray', 'Female', 44);
insert into Employee (EmployeeId, Name, Gender, Age) values ('53-6316930', 'Julian Phittiplace', 'Male', 29);
insert into Employee (EmployeeId, Name, Gender, Age) values ('57-1990775', 'Raff Greenroyd', 'Male', 33);
insert into Employee (EmployeeId, Name, Gender, Age) values ('58-7665170', 'Winston Hanshawe', 'Male', 18);
insert into Employee (EmployeeId, Name, Gender, Age) values ('41-8414997', 'Madelyn Levison', 'Female', 26);
insert into Employee (EmployeeId, Name, Gender, Age) values ('30-7376571', 'Cherrita Chasemoore', 'Male', 37);
insert into Employee (EmployeeId, Name, Gender, Age) values ('56-1348075', 'Archambault Merida', 'Female', 41);
insert into Employee (EmployeeId, Name, Gender, Age) values ('86-0899668', 'Lilllie Watkiss', 'Female', 20);
insert into Employee (EmployeeId, Name, Gender, Age) values ('84-4418891', 'Barris Whapham', 'Female', 39);
insert into Employee (EmployeeId, Name, Gender, Age) values ('80-3571087', 'Lanette Bygate', 'Male', 48);
insert into Employee (EmployeeId, Name, Gender, Age) values ('94-8397686', 'Anselm Casham', 'Female', 49);
insert into Employee (EmployeeId, Name, Gender, Age) values ('53-0137127', 'Wakefield Soppeth', 'Male', 50);
insert into Employee (EmployeeId, Name, Gender, Age) values ('36-4303443', 'Odell Bosward', 'Female', 24);
insert into Employee (EmployeeId, Name, Gender, Age) values ('28-5587781', 'Isabelle Coleiro', 'Female', 40);
insert into Employee (EmployeeId, Name, Gender, Age) values ('83-6069914', 'Kennie Brozsset', 'Female', 31);
insert into Employee (EmployeeId, Name, Gender, Age) values ('69-4017254', 'Coralie Ramsted', 'Female', 37);
insert into Employee (EmployeeId, Name, Gender, Age) values ('31-2259967', 'Jenny Barrack', 'Female', 46);
insert into Employee (EmployeeId, Name, Gender, Age) values ('70-4035655', 'Theo Bishop', 'Female', 31);
insert into Employee (EmployeeId, Name, Gender, Age) values ('76-4017543', 'Gabbi Chadwell', 'Female', 20);
insert into Employee (EmployeeId, Name, Gender, Age) values ('15-1273524', 'Gratia Cordobes', 'Male', 38);
insert into Employee (EmployeeId, Name, Gender, Age) values ('42-5143642', 'Lydie Rangall', 'Male', 40);
insert into Employee (EmployeeId, Name, Gender, Age) values ('84-3180410', 'Laurent McParlin', 'Female', 20);
insert into Employee (EmployeeId, Name, Gender, Age) values ('72-9529384', 'Dix Duval', 'Male', 43);
insert into Employee (EmployeeId, Name, Gender, Age) values ('83-3676333', 'Ashby Folkes', 'Male', 42);
insert into Employee (EmployeeId, Name, Gender, Age) values ('11-9518163', 'Kittie Farman', 'Male', 33);
insert into Employee (EmployeeId, Name, Gender, Age) values ('04-8948446', 'Idalina Lindup', 'Male', 33);
insert into Employee (EmployeeId, Name, Gender, Age) values ('68-6207026', 'Kizzie Fawks', 'Male', 31);
insert into Employee (EmployeeId, Name, Gender, Age) values ('35-3639384', 'Herschel Foskin', 'Female', 42);
insert into Employee (EmployeeId, Name, Gender, Age) values ('61-7189054', 'Jayne Gibbett', 'Male', 32);
insert into Employee (EmployeeId, Name, Gender, Age) values ('32-2569239', 'Deeyn Shattock', 'Male', 30);
insert into Employee (EmployeeId, Name, Gender, Age) values ('33-4432578', 'Gavin Agge', 'Female', 45);
insert into Employee (EmployeeId, Name, Gender, Age) values ('44-5018416', 'Armand Lethbridge', 'Female', 21);
insert into Employee (EmployeeId, Name, Gender, Age) values ('55-6757447', 'Theadora Orrom', 'Male', 48);
insert into Employee (EmployeeId, Name, Gender, Age) values ('60-7334039', 'Marrilee Dyhouse', 'Female', 34);
insert into Employee (EmployeeId, Name, Gender, Age) values ('44-0079799', 'Roseanna Halwood', 'Male', 35);
insert into Employee (EmployeeId, Name, Gender, Age) values ('90-4431584', 'Amelita Jatczak', 'Male', 49);
insert into Employee (EmployeeId, Name, Gender, Age) values ('24-8244186', 'Ingunna Weeke', 'Female', 41);
insert into Employee (EmployeeId, Name, Gender, Age) values ('88-8278364', 'Regine Boldock', 'Female', 43);
insert into Employee (EmployeeId, Name, Gender, Age) values ('82-5346314', 'Melisent Spanton', 'Male', 19);
insert into Employee (EmployeeId, Name, Gender, Age) values ('70-9826671', 'Madelena Dowears', 'Female', 47);
insert into Employee (EmployeeId, Name, Gender, Age) values ('68-5914764', 'Brett Josifovic', 'Male', 21);
insert into Employee (EmployeeId, Name, Gender, Age) values ('20-2640649', 'Sheryl Northrop', 'Female', 20);
insert into Employee (EmployeeId, Name, Gender, Age) values ('94-9380811', 'Karola Heenan', 'Male', 37);
insert into Employee (EmployeeId, Name, Gender, Age) values ('52-7913694', 'Rosita Dranfield', 'Male', 49);
insert into Employee (EmployeeId, Name, Gender, Age) values ('00-6694804', 'Murvyn Dunsford', 'Female', 35);
insert into Employee (EmployeeId, Name, Gender, Age) values ('50-3605463', 'Edik Fradgley', 'Male', 22);
insert into Employee (EmployeeId, Name, Gender, Age) values ('89-2085675', 'Diarmid Godly', 'Female', 39);
insert into Employee (EmployeeId, Name, Gender, Age) values ('30-8864238', 'Myer Leverton', 'Female', 32);
insert into Employee (EmployeeId, Name, Gender, Age) values ('01-9166376', 'Anthony Ligoe', 'Male', 45);
insert into Employee (EmployeeId, Name, Gender, Age) values ('29-6362950', 'Ericka Ilyinski', 'Female', 50);
insert into Employee (EmployeeId, Name, Gender, Age) values ('61-0336681', 'Tailor Bartoszewski', 'Female', 24);
insert into Employee (EmployeeId, Name, Gender, Age) values ('35-0357484', 'Llywellyn Haly', 'Female', 30);
insert into Employee (EmployeeId, Name, Gender, Age) values ('84-4384537', 'Delly Corran', 'Female', 44);
insert into Employee (EmployeeId, Name, Gender, Age) values ('99-0741919', 'Eartha Jurries', 'Male', 48);
insert into Employee (EmployeeId, Name, Gender, Age) values ('07-8120472', 'Susan Vial', 'Female', 43);
insert into Employee (EmployeeId, Name, Gender, Age) values ('42-6364406', 'Ami Brahms', 'Female', 31);
insert into Employee (EmployeeId, Name, Gender, Age) values ('11-2721450', 'Lani Boyen', 'Male', 40);
insert into Employee (EmployeeId, Name, Gender, Age) values ('77-2538014', 'Tucky Clardge', 'Female', 28);
insert into Employee (EmployeeId, Name, Gender, Age) values ('27-6607554', 'Lauralee Thirlwell', 'Male', 24);
insert into Employee (EmployeeId, Name, Gender, Age) values ('98-3829884', 'Cary Wigin', 'Female', 31);
insert into Employee (EmployeeId, Name, Gender, Age) values ('56-4977875', 'Kingsly Fritchly', 'Male', 42);
insert into Employee (EmployeeId, Name, Gender, Age) values ('49-7614035', 'Jillian Torvey', 'Male', 45);
insert into Employee (EmployeeId, Name, Gender, Age) values ('57-2599778', 'Juliann Deam', 'Female', 47);
insert into Employee (EmployeeId, Name, Gender, Age) values ('31-6264253', 'Ronna Vaughten', 'Male', 38);
insert into Employee (EmployeeId, Name, Gender, Age) values ('82-3120792', 'Anton Ratt', 'Male', 36);
insert into Employee (EmployeeId, Name, Gender, Age) values ('60-5190479', 'Hussein Hessing', 'Male', 45);
insert into Employee (EmployeeId, Name, Gender, Age) values ('70-0471353', 'Wilt Cham', 'Female', 27);
insert into Employee (EmployeeId, Name, Gender, Age) values ('79-2402184', 'Selene Dunn', 'Female', 18);
insert into Employee (EmployeeId, Name, Gender, Age) values ('00-5128036', 'Dion Beardwell', 'Female', 21);
insert into Employee (EmployeeId, Name, Gender, Age) values ('35-8468081', 'Diann Sibary', 'Male', 24);
insert into Employee (EmployeeId, Name, Gender, Age) values ('53-9638643', 'Kaitlynn Speedin', 'Female', 20);
insert into Employee (EmployeeId, Name, Gender, Age) values ('24-1544073', 'Shel Benninger', 'Female', 26);
insert into Employee (EmployeeId, Name, Gender, Age) values ('67-2705053', 'Jethro Martonfi', 'Male', 38);
insert into Employee (EmployeeId, Name, Gender, Age) values ('85-0396843', 'Merissa Daintry', 'Male', 44);
insert into Employee (EmployeeId, Name, Gender, Age) values ('44-9920180', 'Gayle Yule', 'Male', 23);
insert into Employee (EmployeeId, Name, Gender, Age) values ('88-4906101', 'Niccolo Dudderidge', 'Female', 32);
insert into Employee (EmployeeId, Name, Gender, Age) values ('31-1568563', 'Dee Dibdin', 'Male', 50);
insert into Employee (EmployeeId, Name, Gender, Age) values ('64-6785665', 'Trudi Allbones', 'Female', 39);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('96-8024105', 'Tockus flavirostris', 'Male', 20, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('87-4897901', 'Nyctea scandiaca', 'Male', 0, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('71-9240411', 'Varanus sp.', 'Male', 13, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('56-5337970', 'Zosterops pallidus', 'Male', 14, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('21-6346624', 'Hyaena brunnea', 'Female', 13, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('14-2024716', 'Aegypius occipitalis', 'Male', 13, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('07-7544492', 'Ammospermophilus nelsoni', 'Male', 20, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('32-4258273', 'Dasypus septemcincus', 'Male', 19, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('36-9389963', 'Bugeranus caruncalatus', 'Male', 2, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('59-7936229', 'Potamochoerus porcus', 'Male', 10, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('07-1503900', 'Oreamnos americanus', 'Male', 1, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('73-8163159', 'Ephipplorhynchus senegalensis', 'Male', 7, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('09-0220450', 'unavailable', 'Male', 11, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('12-5319258', 'Kobus leche robertsi', 'Male', 20, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('19-3514482', 'Cathartes aura', 'Male', 16, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('01-4133983', 'Kobus vardonii vardoni', 'Female', 4, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('34-8913303', 'Dusicyon thous', 'Male', 4, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('59-1687335', 'Acrantophis madagascariensis', 'Male', 0, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('72-2375253', 'Streptopelia senegalensis', 'Male', 14, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('92-2467949', 'Megaderma spasma', 'Female', 10, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('99-6155908', 'Pseudalopex gymnocercus', 'Male', 0, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('33-8939194', 'Equus burchelli', 'Male', 19, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('38-4833459', 'Marmota caligata', 'Male', 18, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('07-0449377', 'Gyps fulvus', 'Male', 20, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('86-7381021', 'Geochelone elegans', 'Female', 16, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('45-4361338', 'Axis axis', 'Male', 0, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('66-9759296', 'Estrilda erythronotos', 'Male', 9, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('05-6085814', 'Corvus albicollis', 'Female', 0, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('36-4626676', 'Tapirus terrestris', 'Female', 5, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('53-5247302', 'Cynictis penicillata', 'Female', 0, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('52-0647005', 'Macaca nemestrina', 'Male', 2, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('09-0677701', 'Bettongia penicillata', 'Male', 11, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('73-4049425', 'Sciurus niger', 'Female', 20, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('38-7389977', 'Phoca vitulina', 'Male', 10, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('33-6691169', 'Rhea americana', 'Male', 1, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('97-1769484', 'Ceryle rudis', 'Male', 11, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('26-4158326', 'Geochelone elegans', 'Female', 17, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('74-5808856', 'Odocoileus hemionus', 'Female', 3, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('03-5011650', 'Tyto novaehollandiae', 'Male', 4, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('03-0934747', 'Tachybaptus ruficollis', 'Female', 20, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('34-6152114', 'Pseudalopex gymnocercus', 'Male', 0, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('42-4126428', 'Lepus townsendii', 'Male', 19, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('23-5115435', 'Plectopterus gambensis', 'Male', 3, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('94-5448617', 'Anastomus oscitans', 'Male', 6, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('03-6180360', 'Anathana ellioti', 'Male', 9, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('39-1568397', 'Varanus sp.', 'Male', 3, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('97-5264443', 'Canis lupus', 'Male', 2, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('03-6104678', 'Sarkidornis melanotos', 'Male', 12, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('46-1031701', 'Grus antigone', 'Female', 18, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('65-1120414', 'Pelecans onocratalus', 'Female', 4, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('11-2978392', 'Hystrix cristata', 'Female', 14, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('79-8564718', 'Alcelaphus buselaphus caama', 'Female', 9, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('16-9921983', 'Colobus guerza', 'Female', 4, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('26-2088212', 'Myrmecophaga tridactyla', 'Male', 20, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('74-8466281', 'Naja haje', 'Female', 14, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('89-4344915', 'Acridotheres tristis', 'Male', 20, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('27-8591513', 'Ateles paniscus', 'Male', 1, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('20-5594089', 'Junonia genoveua', 'Male', 14, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('33-3320448', 'Uraeginthus bengalus', 'Female', 1, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('21-0140576', 'Ninox superciliaris', 'Male', 1, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('69-6569007', 'Bucorvus leadbeateri', 'Female', 11, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('98-3320624', 'Spermophilus lateralis', 'Male', 5, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('44-6384990', 'Bubalus arnee', 'Female', 4, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('17-4279749', 'Bucorvus leadbeateri', 'Female', 16, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('96-4190336', 'Connochaetus taurinus', 'Male', 17, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('32-8447063', 'Eolophus roseicapillus', 'Male', 3, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('80-6203132', 'Papio cynocephalus', 'Female', 17, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('20-7484588', 'Tiliqua scincoides', 'Male', 19, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('91-1000882', 'Lepus townsendii', 'Female', 13, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('89-5671189', 'Cereopsis novaehollandiae', 'Female', 7, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('48-5991327', 'Pelecans onocratalus', 'Female', 18, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('00-5770525', 'Eubalaena australis', 'Male', 7, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('89-8566052', 'Eolophus roseicapillus', 'Female', 19, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('13-0208596', 'Trachyphonus vaillantii', 'Female', 4, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('77-9691692', 'Chlidonias leucopterus', 'Male', 6, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('32-6849131', 'Microcebus murinus', 'Female', 19, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('11-6625993', 'Naja haje', 'Female', 1, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('97-8365900', 'Lemur catta', 'Male', 4, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('94-7866190', 'Canis aureus', 'Male', 0, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('41-6233301', 'Cercatetus concinnus', 'Male', 9, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('84-2805971', 'Eolophus roseicapillus', 'Male', 12, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('92-9448685', 'Pelecans onocratalus', 'Female', 16, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('83-8227152', 'Macropus robustus', 'Female', 20, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('31-1928414', 'Perameles nasuta', 'Female', 16, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('65-5633698', 'Plectopterus gambensis', 'Male', 6, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('21-4017977', 'Pseudoleistes virescens', 'Male', 15, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('41-0509050', 'Acrobates pygmaeus', 'Male', 9, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('35-9015925', 'Anastomus oscitans', 'Male', 7, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('61-1652480', 'Zosterops pallidus', 'Female', 9, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('25-4484730', 'Columba palumbus', 'Female', 13, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('39-8961915', 'Picoides pubescens', 'Female', 13, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('43-9962835', 'Streptopelia senegalensis', 'Female', 6, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('69-4419213', 'Felis yagouaroundi', 'Male', 20, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('51-0458615', 'Eremophila alpestris', 'Female', 0, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('78-3359571', 'Actophilornis africanus', 'Male', 3, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('95-7737635', 'Eutamias minimus', 'Male', 18, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('01-7484466', 'Iguana iguana', 'Male', 15, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('52-8641808', 'Bradypus tridactylus', 'Female', 0, 1);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('14-7525728', 'Aonyx cinerea', 'Female', 7, 0);
insert into Animal (AnimalId, Name, Gender, Age, Carnivorous) values ('12-4977110', 'Hymenolaimus malacorhynchus', 'Male', 3, 0);
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into Feed (EmployeeId, AnimalId, Food, Frequency)
select
    a.EmployeeId
    , b.AnimalId
    , case when b.Carnivorous = 0 then 'Vegetable' else 'Meat' end
    , abs(random() % 5) + 1
from
    (
        select
            EmployeeId
            , row_number() over(order by random()) as seq
        from
            Employee
    ) a
    join (
        select
            AnimalId
            , Carnivorous
            , row_number() over(order by random()) as seq
        from
            Animal
    ) b
    on
        a.seq = b.seq
limit 1000 offset 0;
