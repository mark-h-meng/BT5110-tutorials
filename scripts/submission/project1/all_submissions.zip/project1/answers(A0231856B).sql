/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*  Matilda Yingge Xu                                                                    */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
In recent days, telecom fraud is rampant globally. One of the police offices have
gathered recent data of telecom fraud, especially from victims who always fall into the scam trap.

1)We got the first table to store victims' information, including their phone number,
name, ID number, country, date of birth, etc. The primary key is ID number,
which means this table only stores unique victims' information.

2)The second table is for the suspects, including their real phone number,
fake phone number, name, country, whether a recidivist or not, etc. Most suspects
won't confess, therefore we don't have much personal information. So the
primary key is a combination of their fake phone numbers and real phone numbers.

3)The relation of these two tables is captured by every scam, we could see from the table
"mapping", which actually acts as a big map of victims' and suspects' phone numbers,
that some victims repeatedly received fraudulent calls, and some suspects made calls
to many different victims. Through this mapping, we are able to extract clues about
whether a suspect is a perpetrator or not, also the severity of telecom fraud of
these victims.

*The codes are written for PostgreSQL
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS victims (
 first_name VARCHAR(64) NOT NULL,
 last_name VARCHAR(64) NOT NULL,
 phone VARCHAR(64) UNIQUE NOT NULL,
 id VARCHAR(64) PRIMARY KEY NOT NULL,
 dob DATE NOT NULL,
 country VARCHAR(64) NOT NULL,
 card VARCHAR(64) NOT NULL
);

CREATE TABLE IF NOT EXISTS suspects(
 first_name VARCHAR(64) NOT NULL,
 last_name VARCHAR(64) NOT NULL,
 fake_phone VARCHAR(64) NOT NULL,
 real_phone VARCHAR(64) NOT NULL,
 country VARCHAR(64) NOT NULL,
 recidivist BOOLEAN NOT NULL,
 PRIMARY KEY (fake_phone, real_phone));

 CREATE TABLE mapping(
 victim_phone VARCHAR(64) REFERENCES victims(phone) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
 suspect_f_phone VARCHAR(64),
 suspect_r_phone VARCHAR(64),
 PRIMARY KEY (victim_phone, suspect_f_phone, suspect_r_phone),
 FOREIGN KEY (suspect_f_phone, suspect_r_phone) REFERENCES suspects(fake_phone, real_phone) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Gawain', 'McInulty', '5278984023', '793-38-4675', '1967-09-22', 'Czech Republic', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Farrand', 'Felgat', '4403198473', '521-72-6636', '1949-09-26', 'Pakistan', 'mastercard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Carissa', 'Demangeot', '4068617319', '862-33-3679', '1985-07-20', 'Syria', 'visa-electron');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Kellsie', 'Couvet', '3545729393', '292-69-3203', '1997-08-16', 'China', 'laser');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Darrel', 'Pike', '1575013551', '294-17-9822', '1982-08-29', 'Indonesia', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Khalil', 'Bellis', '8647747834', '795-90-9522', '1966-09-07', 'Mexico', 'visa');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Lavina', 'McAree', '4118322584', '210-41-6083', '1994-01-28', 'Portugal', 'laser');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Maible', 'Kays', '3043335825', '593-15-8499', '1950-04-11', 'China', 'diners-club-international');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Cookie', 'Ellacott', '3226717940', '594-90-7239', '1961-08-08', 'Sweden', 'maestro');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Dee dee', 'Sambidge', '8961762939', '567-63-8866', '1959-03-20', 'Poland', 'solo');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Cordy', 'Rowley', '2297501102', '354-78-4304', '1984-10-19', 'Yemen', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Diahann', 'Slocom', '4834188078', '390-75-7542', '1954-12-23', 'China', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Patti', 'Tittletross', '5249189051', '896-17-5296', '1949-10-24', 'Croatia', 'bankcard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Elsbeth', 'Mackie', '2264664025', '894-02-5332', '1965-12-23', 'Indonesia', 'switch');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Susanetta', 'Sharples', '5118266711', '343-58-0621', '1972-06-23', 'Japan', 'diners-club-us-ca');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Gard', 'Crang', '9128944089', '834-97-6539', '1977-01-21', 'Ireland', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Irene', 'Mibourne', '9202333605', '784-78-7010', '1991-06-04', 'Brazil', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Melvyn', 'Cogdell', '8691250167', '279-83-1999', '1990-11-07', 'China', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Thaddus', 'Alexsandrowicz', '8434170443', '370-23-3574', '1978-06-18', 'China', 'diners-club-carte-blanche');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Itch', 'Kettlestringe', '8481004367', '499-55-1214', '2000-06-21', 'China', 'laser');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Ara', 'Piscopo', '9997224544', '165-51-1719', '1977-04-13', 'Poland', 'diners-club-enroute');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Fred', 'Boissieux', '3943890983', '246-92-6431', '1987-04-27', 'Peru', 'maestro');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Evonne', 'Bayman', '1766006188', '266-42-6838', '1971-09-20', 'Madagascar', 'americanexpress');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Ellene', 'Kunz', '4078971963', '521-83-5944', '1981-09-23', 'Portugal', 'bankcard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Deena', 'Sconce', '9605083690', '605-86-5646', '1966-09-09', 'China', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Tracy', 'Kaesmans', '7651719836', '382-73-2543', '1969-05-14', 'Panama', 'bankcard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Herculie', 'Blackbrough', '1578006765', '632-08-4240', '1949-11-15', 'Macedonia', 'diners-club-enroute');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Ilsa', 'Baynon', '1429823649', '891-92-4241', '1962-12-04', 'Czech Republic', 'mastercard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Susann', 'Kidgell', '2253532111', '586-55-8818', '1978-12-01', 'Venezuela', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Steve', 'Beavors', '4205684277', '217-56-6415', '1985-07-23', 'Tanzania', 'maestro');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Jasun', 'Toppes', '2074729759', '459-57-5508', '1960-07-21', 'Mongolia', 'diners-club-carte-blanche');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Tome', 'Nutty', '1084464521', '714-90-3755', '1975-01-29', 'Tunisia', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Sabine', 'Marlow', '3109558077', '258-40-4957', '1980-08-09', 'United States', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Cesar', 'O''Mohun', '3959547451', '508-77-7884', '1977-12-05', 'Mongolia', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Lotti', 'Bryett', '9451757570', '414-77-1318', '2001-01-13', 'Sweden', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Alvinia', 'Lyddy', '3446363879', '424-03-3121', '1988-08-08', 'Albania', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Ronalda', 'McCrow', '9102428178', '883-92-6880', '1999-05-12', 'Poland', 'visa-electron');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Goddard', 'Potes', '8177426338', '159-10-0277', '1983-04-19', 'Indonesia', 'bankcard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Gertrude', 'McCroary', '9513798958', '106-23-7844', '1992-03-30', 'Russia', 'maestro');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Moina', 'Bea', '5173930160', '526-88-7901', '1978-04-20', 'Gabon', 'americanexpress');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Cristal', 'Edlington', '6908783634', '407-84-6225', '1988-11-24', 'Indonesia', 'mastercard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Christophorus', 'Bewshaw', '1073225973', '238-24-3251', '1989-11-15', 'Nigeria', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Tracy', 'de Clercq', '7715654834', '776-11-7899', '1962-06-13', 'China', 'diners-club-enroute');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Amos', 'Huxham', '6684495572', '534-72-4929', '1989-01-24', 'China', 'laser');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Adolf', 'Doxey', '5125165513', '883-89-7942', '1953-09-22', 'Canada', 'diners-club-us-ca');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Baudoin', 'Abrey', '1789966677', '623-29-6798', '1955-04-13', 'Mongolia', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Ellwood', 'Hardwick', '8582256950', '456-72-7226', '1959-04-05', 'Honduras', 'diners-club-carte-blanche');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Hedi', 'Belone', '5392116825', '441-43-7537', '1956-06-05', 'China', 'mastercard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Neile', 'Arias', '3596448461', '484-82-3008', '1981-04-08', 'Philippines', 'diners-club-carte-blanche');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Tom', 'Maunton', '1525573734', '268-67-7763', '1985-11-07', 'Russia', 'switch');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Margalo', 'Liddyard', '9177270526', '259-15-5114', '1979-12-25', 'China', 'diners-club-us-ca');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Jedediah', 'Pott', '3827393679', '419-56-6060', '1956-08-02', 'Ukraine', 'visa-electron');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Marquita', 'Pawelec', '6077938003', '753-01-2440', '1962-04-03', 'Guinea', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Randi', 'Lavers', '9752208243', '763-17-4194', '1962-05-16', 'China', 'solo');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Frederic', 'Colegate', '9316844214', '432-46-2221', '1954-03-30', 'Kazakhstan', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Nixie', 'Sweetnam', '8201494786', '430-10-5009', '1980-04-07', 'China', 'bankcard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Hurley', 'Pankettman', '8507956584', '895-63-8861', '1959-07-29', 'United States', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Amelina', 'Brocks', '9629670973', '827-58-6563', '1954-01-29', 'Russia', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Georgianne', 'Schohier', '5736643778', '149-99-5965', '1982-04-09', 'Poland', 'mastercard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Arron', 'Stothert', '7539228497', '387-95-6449', '1998-07-06', 'Czech Republic', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Joyce', 'Easter', '7308259464', '437-90-4730', '2000-07-31', 'Syria', 'switch');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Winne', 'Hansill', '2071225442', '652-60-5363', '1960-11-18', 'Costa Rica', 'mastercard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Siouxie', 'Cossons', '3925965389', '528-66-7726', '1968-09-12', 'France', 'diners-club-enroute');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Mickie', 'Truwert', '2346248629', '241-11-3022', '1991-05-03', 'China', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Robbyn', 'Gandley', '9767357265', '224-42-5938', '1967-12-27', 'Pakistan', 'switch');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Kalle', 'Imlach', '9671092860', '395-43-8988', '1960-05-30', 'Argentina', 'bankcard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Rafaela', 'Aird', '9708896042', '269-45-4336', '1977-12-13', 'Indonesia', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Colman', 'Mintrim', '8294380767', '632-60-3177', '1955-08-31', 'Nicaragua', 'mastercard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Dame', 'Leake', '8208028148', '202-22-6697', '1958-03-24', 'Brazil', 'diners-club-carte-blanche');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Dory', 'Fleckney', '8092782585', '672-22-1224', '1979-12-16', 'Poland', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Helen', 'Scourgie', '6461912783', '780-10-0925', '1998-06-15', 'China', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Annie', 'Maile', '4434997563', '425-92-2468', '1999-11-12', 'Kyrgyzstan', 'maestro');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Clary', 'Jaggs', '6879869179', '553-55-7712', '1955-06-16', 'Indonesia', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Sergeant', 'Esser', '3733180013', '187-42-3030', '1971-08-03', 'Indonesia', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Ricky', 'Andreuzzi', '5144770891', '382-74-2236', '1963-06-21', 'Poland', 'switch');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Charlene', 'Dunkley', '9178828119', '473-05-1161', '1979-06-30', 'United States', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Alexandre', 'Clemenzi', '7163275501', '790-82-8308', '1995-07-05', 'Indonesia', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Jerrie', 'Gaine of England', '9028444935', '182-66-2874', '1976-11-10', 'Cuba', 'solo');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Brigid', 'Kippin', '2223532587', '636-81-5748', '1962-05-28', 'Syria', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Edmund', 'De Freitas', '6786697139', '187-89-7333', '1975-01-24', 'United States', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Gearalt', 'Norvel', '4145276973', '381-23-9038', '1966-01-15', 'Palestinian Territory', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Darn', 'Yo', '5895635510', '588-54-7962', '1974-11-12', 'Paraguay', 'solo');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Corilla', 'Glennie', '5584299710', '673-37-9183', '1991-11-04', 'Indonesia', 'bankcard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Jake', 'Bosomworth', '6481440655', '179-58-4438', '1999-05-25', 'China', 'diners-club-carte-blanche');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Jonis', 'Sedger', '7569129889', '811-44-0665', '1968-05-24', 'Russia', 'mastercard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Luella', 'Pavey', '7194903451', '670-80-8818', '1951-05-15', 'China', 'mastercard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Cecil', 'Marklow', '4686252869', '695-63-6560', '1955-09-05', 'Denmark', 'maestro');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Walliw', 'Slarke', '1684086803', '736-06-7151', '1981-06-22', 'Madagascar', 'mastercard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Shay', 'Woolard', '5745740882', '210-58-2837', '1956-10-26', 'China', 'maestro');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Simona', 'Nipper', '1621420336', '353-54-5734', '1997-07-25', 'Russia', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Mirella', 'Erswell', '7337818109', '183-58-3807', '1971-02-23', 'Denmark', 'diners-club-enroute');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Aubrey', 'Test', '6771186934', '266-23-1712', '1985-12-10', 'Indonesia', 'jcb');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Charisse', 'Batha', '5113909488', '800-55-1442', '1959-05-29', 'Ethiopia', 'solo');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Renard', 'Wodeland', '8712005019', '578-03-8316', '1989-10-11', 'Malaysia', 'visa-electron');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Roxana', 'Juarez', '3961855875', '222-26-0818', '1957-07-13', 'Norway', 'china-unionpay');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Allys', 'Rannells', '1551519212', '784-53-5050', '1963-09-19', 'Argentina', 'laser');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Claude', 'Sibary', '7343027041', '858-82-5330', '1954-04-04', 'China', 'mastercard');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Roana', 'Boecke', '9454684699', '238-84-9251', '1987-12-27', 'Czech Republic', 'switch');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Andre', 'Mabbot', '7602219891', '321-59-5899', '1989-12-14', 'Tokelau', 'americanexpress');
insert into public.victims (first_name, last_name, phone, id, dob, country, card) values ('Shoshana', 'Bartunek', '9121376735', '449-56-4247', '1974-02-21', 'China', 'jcb');


  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Sidonia', 'Cadagan', '4562750872', '5049123661', 'Sri Lanka', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Hilda', 'Linscott', '3799793620', '1309302282', 'Nicaragua', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Vachel', 'Cuddehay', '1062981517', '4969777597', 'China', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Vina', 'Blesli', '4645139863', '9259817156', 'Argentina', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Keelby', 'Rosenkranc', '2238638989', '4021812112', 'Iran', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Yulma', 'Pottle', '9364223059', '8021696167', 'Belarus', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Tonia', 'Melonby', '7629974360', '2023410401', 'Indonesia', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Vidovik', 'Brownlie', '2149185225', '5963498891', 'China', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Cristabel', 'Iacovucci', '8226139109', '4072197677', 'Mauritius', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Channa', 'Fleisch', '7233143945', '4876704710', 'Poland', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Clerkclaude', 'Raubenheimers', '1583005755', '5954739477', 'Uganda', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Ava', 'Mishaw', '6046758252', '7254780627', 'Czech Republic', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Robbin', 'Farrar', '8531542332', '3468984125', 'China', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Denys', 'Maghull', '2021987779', '1996009289', 'China', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Chalmers', 'Garbar', '8323648543', '9369898208', 'China', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Leda', 'Cisland', '8382717131', '5448797371', 'Russia', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Nevins', 'Stookes', '7353939515', '1286471996', 'China', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Bernetta', 'Shawell', '1551344370', '4092779618', 'Latvia', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Wileen', 'Giller', '7768093793', '3141919721', 'Brazil', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Nathalia', 'Brecknell', '8378801884', '3027767403', 'Czech Republic', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Bertine', 'Shemming', '2347228388', '2147241574', 'Indonesia', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Jerrie', 'Spadotto', '6015309609', '6806298137', 'Colombia', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Cassondra', 'Finey', '4124506015', '7214129404', 'China', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Armand', 'McGready', '1309995216', '2116621405', 'China', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Kacy', 'Pischof', '5433608821', '5091803177', 'China', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Westbrook', 'Payley', '9547646383', '8174225281', 'Indonesia', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Mamie', 'MacKnocker', '9523905321', '3322389533', 'Vietnam', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Rebbecca', 'Noot', '5896749396', '6628612060', 'China', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Dahlia', 'Blaxeland', '4049400998', '4732831092', 'Brazil', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Chelsae', 'Jellis', '6698765946', '5771536253', 'Peru', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Rip', 'Ivashchenko', '3514229494', '1304751357', 'China', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Spence', 'Bensusan', '2206921919', '3444686571', 'Tonga', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Arabele', 'Gaudon', '4562750872', '6888659308', 'Indonesia', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Ashley', 'Baskerfield', '3362006435', '7277281132', 'China', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Norry', 'Rottenbury', '2724604580', '8527875746', 'United Kingdom', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Yulma', 'Pottle', '9364223059', '2022930111', 'Belarus', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Mord', 'Wadlow', '9194187788', '3038367675', 'China', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Gabbi', 'Filintsev', '5002083908', '8548391137', 'Indonesia', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Joline', 'Corballis', '9119698981', '8101855394', 'Russia', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Giulietta', 'Hewson', '3249451937', '1895346295', 'China', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Jaymie', 'Melmar', '3006346374', '9513403230', 'Sweden', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Dollie', 'Kerbey', '3885247217', '8339106990', 'Philippines', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Belicia', 'Beagen', '5342945748', '8293880553', 'Netherlands', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Mart', 'Gilluley', '5301603245', '7357370221', 'Indonesia', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Orsa', 'Heineking', '5255260374', '7581379675', 'Syria', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Shelden', 'Forre', '7719095807', '2852201513', 'Iraq', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Ilyssa', 'Inge', '2601059518', '2247709102', 'Indonesia', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Wyndham', 'Draysay', '1593927567', '5101458155', 'Dominican Republic', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Kaja', 'McCorkindale', '9018950146', '4029501081', 'United States', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Deerdre', 'Bortoloni', '6686172487', '3447580118', 'Thailand', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Rafaelita', 'Kewish', '1625427193', '1406990271', 'China', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Vivianne', 'Mithan', '5547835061', '7883741571', 'Venezuela', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Mari', 'Loughman', '7747889242', '7896772312', 'Finland', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Mohammed', 'Shrieve', '7218434592', '5558551442', 'South Korea', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Alis', 'McCerery', '5342639650', '7343603796', 'Afghanistan', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Henry', 'Yekel', '5472169571', '5925269635', 'Peru', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Delila', 'Earpe', '9717684617', '7351843141', 'Spain', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Dre', 'MacCleod', '9684778183', '5316880405', 'South Africa', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Fletcher', 'Davern', '7996603245', '2433325414', 'France', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Beatriz', 'Belham', '4247834179', '6545344992', 'Sweden', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Jobyna', 'Gilbee', '9349534305', '5542092263', 'Ukraine', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Halley', 'Petrolli', '2991093189', '5196991693', 'China', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('La verne', 'Coldbath', '4939394256', '7304546835', 'Russia', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Sanford', 'Kingdon', '2805707441', '9892258289', 'Albania', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Carol', 'Wellington', '8855252701', '4316873721', 'Bolivia', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Margarete', 'Felgat', '8945557837', '9912532030', 'Tajikistan', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Shirleen', 'Juschka', '6475676533', '3663241718', 'Austria', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Sophia', 'Weinberg', '9102110829', '4606598211', 'United Kingdom', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Franciska', 'Beecraft', '9334186371', '3304524127', 'China', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Mellie', 'Cantwell', '9781682257', '9379881469', 'Poland', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Marje', 'Laughtisse', '3326119699', '4788380508', 'China', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Frederique', 'MacQuarrie', '8134389618', '3949507276', 'Russia', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Tobe', 'Verillo', '5519996908', '4916599101', 'Russia', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Myrna', 'Bidmead', '9612168954', '1125632285', 'Italy', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Cybil', 'Halfacree', '4058910624', '7723153931', 'Poland', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Grady', 'O''Concannon', '6105361900', '8391926304', 'Ukraine', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Bill', 'O''Donnelly', '9558148243', '7262734104', 'Peru', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Rory', 'Seamarke', '1426050468', '2928076822', 'Greece', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Minne', 'Kenrack', '6092911582', '6988718249', 'Pakistan', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Vaclav', 'Camidge', '6309789219', '2972438803', 'Ukraine', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Thalia', 'Servis', '2517970623', '1104150681', 'Indonesia', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Robbi', 'Wigsell', '8381162275', '7225903495', 'Sweden', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Hernando', 'Gewer', '7218050403', '6229860844', 'China', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Selig', 'Calder', '2133358100', '3141974340', 'Poland', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Rosalinde', 'Collman', '1251145431', '3082882044', 'China', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Melvyn', 'MacKaile', '4089873572', '7988827943', 'Japan', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Michaela', 'Fishleigh', '4339226177', '7398415683', 'Indonesia', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Brittni', 'Hrynczyk', '1658470151', '5903140118', 'China', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Gwennie', 'Mountstephen', '2379336733', '2485238868', 'Portugal', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Cinderella', 'Burr', '5738805754', '6817138611', 'Estonia', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Buffy', 'Florey', '5939037292', '7183031737', 'Sri Lanka', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Hermie', 'Shalliker', '6262957332', '8929741234', 'United States', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Clair', 'Newgrosh', '2299536623', '2501167018', 'Ethiopia', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Marianne', 'Lente', '4562750872', '4545449077', 'Brazil', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Evita', 'Penniell', '9588353296', '9008651408', 'Brazil', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Cathe', 'Pagin', '9045807327', '4316374189', 'France', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Lorry', 'Sheardown', '2241964235', '2579161152', 'China', false);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Massimiliano', 'Rylance', '6839282971', '1424568003', 'Norway', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Valencia', 'MacGregor', '9086881191', '2021317092', 'China', true);
  insert into public.suspects (first_name, last_name, fake_phone, real_phone, country, recidivist) values ('Alleen', 'Wickardt', '3496807658', '7233019990', 'Brazil', false);


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO public.mapping (victim_phone, suspect_f_phone, suspect_r_phone)
select a.phone, b.fake_phone, b.real_phone from
public.victims as a
cross join public.suspects as b
order by random()
limit 1000
