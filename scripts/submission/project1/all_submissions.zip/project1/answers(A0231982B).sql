-- Database: BT5110

-- DROP DATABASE "BT5110";

/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
This case is generalized based on real world experiences. Luckily I got
admitted by NUS. :D

Table Students contains the information for students who applied for different
universities. It contains basic information of each applicant, applicant_id
is the primary key since it's unique. For realistic reason, this table has more
rows than table Universities.

Table Universities contains the information for each univerisity, I hope I
can also include country, city, etc. but randomly generalized data will 
make it less realistic. The primary key is school_name, which is also unique.

The relationship is table Admitted. It associates the applicant_id
of the students to the names of the universities for which they have been 
admitted. It's clearly a many-to-many relationship, because one applicant 
can be admitted by more than one university, hopefully; and one university
can admit hundreds of applicants. 

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
drop table Students;
drop table Universities;
drop table Admitted;

create table Students (
	applicant_id INT,
	first_name VARCHAR(50),
	last_name VARCHAR(50),
	gender VARCHAR(50),
	email VARCHAR(50),
	nationality VARCHAR(50),
	primary key(applicant_id)
);
create table Universities (
	school_name VARCHAR(80),
	application_received INT,
	primary key(school_name)
);
create table Admitted (
	applicant_id INT,
	school_name VARCHAR(80)
);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (415133, 'Kaitlyn', 'Asbury', 'Bigender', 'kasbury0@columbia.edu', 'Iran');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (319918, 'Cicely', 'Antoszczyk', 'Male', 'cantoszczyk1@facebook.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (316259, 'Sigismund', 'Gligorijevic', 'Polygender', 'sgligorijevic2@privacy.gov.au', 'France');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (628652, 'Anders', 'Sapseed', 'Male', 'asapseed3@whitehouse.gov', 'Jamaica');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (382790, 'Olive', 'Lello', 'Genderqueer', 'olello4@discovery.com', 'Bangladesh');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (246461, 'Ofella', 'Kidsley', 'Polygender', 'okidsley5@va.gov', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (735191, 'Osmund', 'Matveiko', 'Bigender', 'omatveiko6@sciencedirect.com', 'Thailand');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (958424, 'Donna', 'Bridge', 'Bigender', 'dbridge7@chronoengine.com', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (335340, 'Lazarus', 'Worner', 'Agender', 'lworner8@ihg.com', 'South Africa');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (348211, 'Blanche', 'Najafian', 'Female', 'bnajafian9@blogspot.com', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (735126, 'Gabie', 'McGinly', 'Female', 'gmcginlya@newsvine.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (605178, 'Enos', 'Padfield', 'Genderfluid', 'epadfieldb@github.com', 'Thailand');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (405409, 'Alisha', 'Jouhning', 'Genderfluid', 'ajouhningc@hubpages.com', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (116970, 'Rosalia', 'Wooffinden', 'Female', 'rwooffindend@businessweek.com', 'Armenia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (966930, 'Harv', 'Percival', 'Genderqueer', 'hpercivale@nature.com', 'France');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (961011, 'Emmett', 'Duddin', 'Bigender', 'eduddinf@dell.com', 'Finland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (842557, 'Danny', 'Street', 'Polygender', 'dstreetg@youku.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (146385, 'Leicester', 'Kiernan', 'Genderfluid', 'lkiernanh@bluehost.com', 'Ethiopia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (458799, 'Rheta', 'Petersen', 'Bigender', 'rpeterseni@goodreads.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (500157, 'Denny', 'Folliott', 'Bigender', 'dfolliottj@go.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (739181, 'Audrey', 'Cheesworth', 'Bigender', 'acheesworthk@cocolog-nifty.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (384944, 'Artemis', 'Dufaur', 'Male', 'adufaurl@elegantthemes.com', 'Lithuania');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (612996, 'Dorolice', 'Delooze', 'Polygender', 'ddeloozem@china.com.cn', 'Spain');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (520113, 'Daniella', 'Wrighton', 'Polygender', 'dwrightonn@mapy.cz', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (786151, 'Ginger', 'Lillecrop', 'Female', 'glillecropo@wisc.edu', 'Nigeria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (288588, 'Thadeus', 'Gagg', 'Non-binary', 'tgaggp@discovery.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (306841, 'Brittne', 'Yarnley', 'Polygender', 'byarnleyq@howstuffworks.com', 'Czech Republic');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (589549, 'Rodge', 'Ready', 'Polygender', 'rreadyr@constantcontact.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (669640, 'Walker', 'Bartholat', 'Female', 'wbartholats@flickr.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (690724, 'Sergio', 'Farnham', 'Bigender', 'sfarnhamt@gov.uk', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (981797, 'Waly', 'Biswell', 'Genderfluid', 'wbiswellu@utexas.edu', 'Bulgaria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (619480, 'Karly', 'Tabourel', 'Non-binary', 'ktabourelv@cbc.ca', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (901009, 'Doro', 'Marr', 'Female', 'dmarrw@miibeian.gov.cn', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (548327, 'Adore', 'Losbie', 'Female', 'alosbiex@homestead.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (919998, 'Alisun', 'Tomkys', 'Genderqueer', 'atomkysy@jalbum.net', 'Albania');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (524552, 'Meara', 'Laxen', 'Bigender', 'mlaxenz@google.com.hk', 'Colombia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (358108, 'Meta', 'Bram', 'Genderqueer', 'mbram10@examiner.com', 'Peru');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (405372, 'Lucinda', 'Coultous', 'Genderfluid', 'lcoultous11@nsw.gov.au', 'Finland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (397068, 'Hanna', 'Coot', 'Genderfluid', 'hcoot12@arizona.edu', 'Pakistan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (998219, 'Jo ann', 'Cicculi', 'Genderqueer', 'jcicculi13@rediff.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (733036, 'Teirtza', 'Fairy', 'Genderfluid', 'tfairy14@wikispaces.com', 'Chad');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (574668, 'Sara-ann', 'Grinsted', 'Agender', 'sgrinsted15@ucoz.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (325616, 'Antonius', 'Hastie', 'Genderfluid', 'ahastie16@mac.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (560494, 'Catherin', 'Bardwell', 'Bigender', 'cbardwell17@sphinn.com', 'Kazakhstan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (695181, 'Elena', 'Falkner', 'Non-binary', 'efalkner18@dropbox.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (977069, 'Brody', 'Duchatel', 'Non-binary', 'bduchatel19@google.es', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (740132, 'Nonie', 'Halbert', 'Genderfluid', 'nhalbert1a@amazonaws.com', 'Yemen');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (757100, 'Garv', 'Yacobsohn', 'Bigender', 'gyacobsohn1b@tinypic.com', 'Peru');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (772847, 'Lindie', 'Champagne', 'Male', 'lchampagne1c@wikia.com', 'Czech Republic');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (416571, 'Korie', 'Tregiddo', 'Agender', 'ktregiddo1d@addthis.com', 'Colombia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (817380, 'Brenn', 'Delves', 'Polygender', 'bdelves1e@qq.com', 'Belarus');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (856044, 'Melonie', 'Olding', 'Male', 'molding1f@cmu.edu', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (391014, 'Cordey', 'Tysack', 'Male', 'ctysack1g@scientificamerican.com', 'Serbia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (734480, 'Carley', 'Shee', 'Non-binary', 'cshee1h@toplist.cz', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (183374, 'Tobit', 'Beidebeke', 'Genderqueer', 'tbeidebeke1i@hud.gov', 'Canada');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (249428, 'Shandra', 'Iscowitz', 'Non-binary', 'siscowitz1j@usda.gov', 'Czech Republic');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (918426, 'Aura', 'Branson', 'Female', 'abranson1k@bigcartel.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (392985, 'Irvin', 'Quincee', 'Agender', 'iquincee1l@usda.gov', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (621897, 'Jesse', 'Durrell', 'Agender', 'jdurrell1m@imdb.com', 'Japan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (975281, 'Woody', 'MacKomb', 'Female', 'wmackomb1n@dedecms.com', 'United States');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (835186, 'Alisander', 'Leber', 'Genderfluid', 'aleber1o@statcounter.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (860952, 'Kary', 'Jozwik', 'Genderfluid', 'kjozwik1p@shinystat.com', 'Nauru');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (324011, 'Billi', 'Bleue', 'Genderqueer', 'bbleue1q@unicef.org', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (185096, 'Allegra', 'Bassam', 'Agender', 'abassam1r@who.int', 'Argentina');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (522576, 'Arabelle', 'Langmead', 'Female', 'alangmead1s@nifty.com', 'Nigeria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (947890, 'Shadow', 'McDougle', 'Polygender', 'smcdougle1t@elegantthemes.com', 'Afghanistan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (649896, 'Granger', 'McGruar', 'Female', 'gmcgruar1u@hibu.com', 'Costa Rica');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (863385, 'Denny', 'Bernuzzi', 'Agender', 'dbernuzzi1v@tiny.cc', 'Netherlands');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (102675, 'Karena', 'Shorbrook', 'Non-binary', 'kshorbrook1w@cdbaby.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (961256, 'Johnna', 'Masser', 'Genderfluid', 'jmasser1x@redcross.org', 'United States');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (671451, 'Hamlen', 'Rowden', 'Genderfluid', 'hrowden1y@businessinsider.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (517239, 'Jacky', 'Sture', 'Bigender', 'jsture1z@hp.com', 'France');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (707649, 'Lethia', 'Coker', 'Non-binary', 'lcoker20@t-online.de', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (573704, 'Marjorie', 'Gwinnel', 'Bigender', 'mgwinnel21@51.la', 'Libya');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (464640, 'Ora', 'Innocent', 'Polygender', 'oinnocent22@wp.com', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (368775, 'Lenci', 'Hindmore', 'Male', 'lhindmore23@nydailynews.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (696328, 'Maisey', 'Sparey', 'Bigender', 'msparey24@mozilla.com', 'Slovenia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (358594, 'Mora', 'Verheijden', 'Genderqueer', 'mverheijden25@phoca.cz', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (407899, 'Lenette', 'Dradey', 'Non-binary', 'ldradey26@amazon.co.jp', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (110086, 'Gael', 'Stit', 'Genderqueer', 'gstit27@oakley.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (317112, 'Mil', 'Diggar', 'Female', 'mdiggar28@discovery.com', 'Czech Republic');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (198823, 'Jehu', 'Gregorace', 'Genderqueer', 'jgregorace29@woothemes.com', 'Zimbabwe');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (194041, 'Chaim', 'Cone', 'Agender', 'ccone2a@wikispaces.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (829204, 'Ignatius', 'Toth', 'Genderfluid', 'itoth2b@imgur.com', 'Panama');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (216550, 'Liz', 'Fourman', 'Male', 'lfourman2c@theguardian.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (634531, 'Sibel', 'Goosnell', 'Non-binary', 'sgoosnell2d@netvibes.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (593764, 'Franky', 'Eadmead', 'Agender', 'feadmead2e@bizjournals.com', 'United States');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (920924, 'Jemima', 'Adrain', 'Bigender', 'jadrain2f@ed.gov', 'Egypt');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (338265, 'Alon', 'Bigadike', 'Non-binary', 'abigadike2g@nymag.com', 'Japan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (242530, 'Vida', 'Lyndon', 'Non-binary', 'vlyndon2h@skyrock.com', 'Peru');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (627058, 'Sara-ann', 'Velde', 'Genderfluid', 'svelde2i@fc2.com', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (621611, 'Estele', 'Pallaske', 'Genderfluid', 'epallaske2j@ehow.com', 'Bulgaria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (735455, 'Beale', 'Ditchfield', 'Male', 'bditchfield2k@about.com', 'Dominican Republic');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (639081, 'Trix', 'Hillock', 'Genderfluid', 'thillock2l@digg.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (547828, 'Terrijo', 'Treasure', 'Female', 'ttreasure2m@comsenz.com', 'Thailand');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (825524, 'Ferd', 'Dixson', 'Male', 'fdixson2n@sbwire.com', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (191164, 'Annadiane', 'Niemetz', 'Genderqueer', 'aniemetz2o@shutterfly.com', 'Egypt');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (936188, 'Gloriana', 'Lill', 'Genderfluid', 'glill2p@multiply.com', 'Honduras');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (963996, 'Legra', 'Casebourne', 'Bigender', 'lcasebourne2q@bloomberg.com', 'Denmark');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (110066, 'Armando', 'Poynzer', 'Genderfluid', 'apoynzer2r@amazon.co.uk', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (933876, 'Britteny', 'Sheach', 'Female', 'bsheach2s@netlog.com', 'Thailand');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (218731, 'Caryl', 'Fresson', 'Genderqueer', 'cfresson2t@google.com.au', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (768365, 'Vladamir', 'Kurth', 'Polygender', 'vkurth2u@meetup.com', 'Albania');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (137555, 'Ramsey', 'Clothier', 'Non-binary', 'rclothier2v@skyrock.com', 'Serbia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (791389, 'Garreth', 'Swalwel', 'Genderqueer', 'gswalwel2w@google.nl', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (833863, 'Ivie', 'Gostling', 'Genderfluid', 'igostling2x@mac.com', 'Finland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (695471, 'Jehanna', 'Jecks', 'Polygender', 'jjecks2y@marriott.com', 'Greece');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (589228, 'Philbert', 'Maggiori', 'Bigender', 'pmaggiori2z@dailymail.co.uk', 'France');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (412172, 'Madelle', 'Amer', 'Female', 'mamer30@aboutads.info', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (365205, 'Aldous', 'Ellerton', 'Male', 'aellerton31@yahoo.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (911938, 'Gusta', 'Topes', 'Bigender', 'gtopes32@springer.com', 'Mongolia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (256834, 'Noelyn', 'Simao', 'Genderqueer', 'nsimao33@google.nl', 'South Sudan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (129805, 'Maxy', 'Vedyashkin', 'Non-binary', 'mvedyashkin34@hao123.com', 'Argentina');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (140470, 'Jamal', 'Heinl', 'Bigender', 'jheinl35@google.com.br', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (222698, 'Delly', 'McRitchie', 'Genderfluid', 'dmcritchie36@skype.com', 'Bulgaria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (401208, 'Abdel', 'Menguy', 'Agender', 'amenguy37@tripod.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (956078, 'Brianne', 'Prew', 'Female', 'bprew38@mit.edu', 'Mongolia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (251306, 'Lelah', 'Queyos', 'Bigender', 'lqueyos39@opera.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (225794, 'Cody', 'Korejs', 'Male', 'ckorejs3a@i2i.jp', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (591523, 'Kermit', 'Pelos', 'Non-binary', 'kpelos3b@alexa.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (330083, 'Lemmie', 'Earley', 'Agender', 'learley3c@rambler.ru', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (710778, 'Ronnie', 'Guiness', 'Female', 'rguiness3d@friendfeed.com', 'Georgia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (213681, 'Ronica', 'Tirone', 'Genderqueer', 'rtirone3e@wp.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (707204, 'Emma', 'Westover', 'Agender', 'ewestover3f@wikipedia.org', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (347483, 'Saxe', 'Posse', 'Non-binary', 'sposse3g@disqus.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (522862, 'Tine', 'Harbin', 'Male', 'tharbin3h@auda.org.au', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (208154, 'Finlay', 'Cornil', 'Bigender', 'fcornil3i@google.fr', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (634349, 'Brook', 'Hebblewhite', 'Agender', 'bhebblewhite3j@reference.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (866107, 'Julius', 'Fennessy', 'Genderqueer', 'jfennessy3k@wp.com', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (936836, 'Alene', 'Greendale', 'Genderqueer', 'agreendale3l@google.com', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (454256, 'Graehme', 'Ash', 'Male', 'gash3m@tuttocitta.it', 'United States');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (136310, 'Caesar', 'Grigor', 'Genderqueer', 'cgrigor3n@woothemes.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (127615, 'Bill', 'Blampy', 'Bigender', 'bblampy3o@vistaprint.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (179605, 'Willi', 'Dwane', 'Genderqueer', 'wdwane3p@icq.com', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (349299, 'Tobie', 'Maffei', 'Bigender', 'tmaffei3q@de.vu', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (387871, 'Roberta', 'Stilldale', 'Genderfluid', 'rstilldale3r@google.nl', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (475228, 'Scotty', 'Giacopelo', 'Female', 'sgiacopelo3s@51.la', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (905738, 'Torr', 'Beaton', 'Agender', 'tbeaton3t@dot.gov', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (176179, 'Petunia', 'Lyst', 'Genderqueer', 'plyst3u@imdb.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (337415, 'Shelley', 'Buckthorp', 'Female', 'sbuckthorp3v@mozilla.org', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (260502, 'Honey', 'Dederich', 'Male', 'hdederich3w@dion.ne.jp', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (619150, 'Joletta', 'MacTerrelly', 'Polygender', 'jmacterrelly3x@nature.com', 'Argentina');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (302702, 'Drusie', 'Lafont', 'Genderqueer', 'dlafont3y@yelp.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (474779, 'Mala', 'Twigge', 'Male', 'mtwigge3z@about.me', 'Ukraine');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (120192, 'Jerrold', 'Brame', 'Agender', 'jbrame40@discovery.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (938781, 'Vivienne', 'Gossling', 'Polygender', 'vgossling41@gov.uk', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (878287, 'Kimberli', 'Mozzetti', 'Male', 'kmozzetti42@baidu.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (702119, 'Winifred', 'Martinson', 'Non-binary', 'wmartinson43@networkadvertising.org', 'Czech Republic');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (679249, 'Danette', 'Jendrassik', 'Female', 'djendrassik44@google.co.jp', 'Ukraine');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (497418, 'Abbe', 'Follett', 'Genderfluid', 'afollett45@cbslocal.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (953897, 'Wynn', 'Laxon', 'Genderfluid', 'wlaxon46@umn.edu', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (172130, 'Heloise', 'Sergeaunt', 'Female', 'hsergeaunt47@cargocollective.com', 'Greece');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (100449, 'Webb', 'Gratton', 'Agender', 'wgratton48@creativecommons.org', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (360443, 'Dalis', 'Morpeth', 'Non-binary', 'dmorpeth49@mozilla.com', 'United States');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (974425, 'Archaimbaud', 'Callington', 'Agender', 'acallington4a@mit.edu', 'Kazakhstan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (693803, 'Jeffy', 'Hodgets', 'Non-binary', 'jhodgets4b@list-manage.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (213993, 'Coraline', 'Warriner', 'Female', 'cwarriner4c@blogger.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (509624, 'Arman', 'Livsey', 'Non-binary', 'alivsey4d@infoseek.co.jp', 'Nigeria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (361454, 'Charlie', 'Ollerhead', 'Polygender', 'collerhead4e@wikispaces.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (680517, 'Johnny', 'Salisbury', 'Male', 'jsalisbury4f@bbb.org', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (137855, 'Laurie', 'Hayter', 'Non-binary', 'lhayter4g@de.vu', 'Nigeria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (739569, 'Allissa', 'Kenrat', 'Polygender', 'akenrat4h@huffingtonpost.com', 'South Africa');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (595056, 'Vicky', 'Midgely', 'Bigender', 'vmidgely4i@ucoz.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (775775, 'Dom', 'Tofanelli', 'Bigender', 'dtofanelli4j@dailymail.co.uk', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (346170, 'Lyman', 'Allkins', 'Male', 'lallkins4k@aol.com', 'France');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (743396, 'Eleanor', 'Virgo', 'Bigender', 'evirgo4l@xinhuanet.com', 'Nigeria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (873790, 'Dav', 'Cornils', 'Female', 'dcornils4m@upenn.edu', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (130936, 'Beverlee', 'Lavrick', 'Male', 'blavrick4n@4shared.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (189101, 'Blancha', 'Malamore', 'Female', 'bmalamore4o@qq.com', 'Greece');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (394993, 'Victoria', 'Kenyon', 'Genderfluid', 'vkenyon4p@parallels.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (241160, 'Tanney', 'Crucetti', 'Non-binary', 'tcrucetti4q@histats.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (111276, 'Amy', 'Cripwell', 'Bigender', 'acripwell4r@blogtalkradio.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (118785, 'Erskine', 'Di Francecshi', 'Non-binary', 'edifrancecshi4s@businesswire.com', 'Germany');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (857529, 'Debby', 'Baldacco', 'Female', 'dbaldacco4t@fda.gov', 'Yemen');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (409584, 'Daryn', 'Simic', 'Bigender', 'dsimic4u@sakura.ne.jp', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (452366, 'May', 'Cuttelar', 'Bigender', 'mcuttelar4v@cloudflare.com', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (922282, 'Teodora', 'Bough', 'Female', 'tbough4w@guardian.co.uk', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (372076, 'Lin', 'Pethrick', 'Bigender', 'lpethrick4x@wikia.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (477795, 'Auroora', 'Dunsford', 'Bigender', 'adunsford4y@desdev.cn', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (788222, 'Kathleen', 'Parkes', 'Bigender', 'kparkes4z@ox.ac.uk', 'Vietnam');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (322640, 'Lilas', 'Jennaroy', 'Female', 'ljennaroy50@discuz.net', 'United States');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (928990, 'Filia', 'Hastwall', 'Male', 'fhastwall51@hubpages.com', 'Peru');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (695427, 'Wendell', 'Kingscote', 'Genderqueer', 'wkingscote52@e-recht24.de', 'Venezuela');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (175207, 'Federico', 'Whithorn', 'Genderfluid', 'fwhithorn53@over-blog.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (545690, 'Theo', 'Vitler', 'Polygender', 'tvitler54@freewebs.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (996781, 'Kath', 'Colborn', 'Genderqueer', 'kcolborn55@networksolutions.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (289571, 'Derek', 'Tickner', 'Male', 'dtickner56@topsy.com', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (109795, 'Cornie', 'Wayon', 'Agender', 'cwayon57@thetimes.co.uk', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (651708, 'Roland', 'Fishbourne', 'Agender', 'rfishbourne58@stumbleupon.com', 'Israel');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (119432, 'Eziechiele', 'Gantz', 'Agender', 'egantz59@flavors.me', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (104585, 'Marcellina', 'Currao', 'Bigender', 'mcurrao5a@eventbrite.com', 'Argentina');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (626372, 'Bar', 'Whetton', 'Female', 'bwhetton5b@yale.edu', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (467960, 'Shina', 'Lemmer', 'Genderfluid', 'slemmer5c@cbc.ca', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (310422, 'Tabbitha', 'Brackley', 'Female', 'tbrackley5d@howstuffworks.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (621456, 'Shell', 'Totton', 'Polygender', 'stotton5e@ustream.tv', 'Mexico');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (487733, 'Harrietta', 'Kentwell', 'Bigender', 'hkentwell5f@disqus.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (939688, 'Wilhelm', 'Leeds', 'Bigender', 'wleeds5g@illinois.edu', 'Azerbaijan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (444717, 'Pebrook', 'Sharkey', 'Non-binary', 'psharkey5h@archive.org', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (718248, 'Sapphire', 'Iseton', 'Genderfluid', 'siseton5i@tamu.edu', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (888001, 'Madlen', 'Morman', 'Genderqueer', 'mmorman5j@indiegogo.com', 'Czech Republic');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (665854, 'Nadeen', 'Whaplington', 'Female', 'nwhaplington5k@pen.io', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (613481, 'Sandra', 'Warret', 'Genderqueer', 'swarret5l@hubpages.com', 'Mexico');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (148454, 'Benedict', 'Edmunds', 'Genderqueer', 'bedmunds5m@google.pl', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (436114, 'Shep', 'Gerant', 'Bigender', 'sgerant5n@pcworld.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (304969, 'Rudiger', 'Rodda', 'Polygender', 'rrodda5o@ask.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (594680, 'Lorette', 'Rochell', 'Genderqueer', 'lrochell5p@tumblr.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (942281, 'Haze', 'Harly', 'Male', 'hharly5q@psu.edu', 'Myanmar');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (240611, 'Annabel', 'Concklin', 'Female', 'aconcklin5r@marriott.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (902614, 'Gerry', 'Blythe', 'Bigender', 'gblythe5s@skyrock.com', 'Mozambique');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (320812, 'Ferdinand', 'Margrem', 'Non-binary', 'fmargrem5t@devhub.com', 'United States');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (996938, 'Elysha', 'Lisciandri', 'Non-binary', 'elisciandri5u@aboutads.info', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (510074, 'Katharine', 'Duff', 'Polygender', 'kduff5v@nifty.com', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (617518, 'Brnaby', 'Pautot', 'Female', 'bpautot5w@twitter.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (837352, 'Gualterio', 'Thunnercliff', 'Bigender', 'gthunnercliff5x@bizjournals.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (430017, 'Mariele', 'Fuzzey', 'Genderfluid', 'mfuzzey5y@theatlantic.com', 'Japan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (696117, 'Geoffrey', 'Tennick', 'Female', 'gtennick5z@theguardian.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (992527, 'Stefania', 'Kempstone', 'Male', 'skempstone60@yelp.com', 'Bulgaria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (773793, 'Babbette', 'Hucknall', 'Agender', 'bhucknall61@moonfruit.com', 'Japan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (576075, 'Natalya', 'Richarz', 'Female', 'nricharz62@scribd.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (324023, 'Wendy', 'Mattin', 'Non-binary', 'wmattin63@bloglines.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (314845, 'Spense', 'Nickols', 'Bigender', 'snickols64@shop-pro.jp', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (759149, 'Skipp', 'Schimmang', 'Polygender', 'sschimmang65@yelp.com', 'Syria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (352280, 'Irwinn', 'Thwaites', 'Genderfluid', 'ithwaites66@ebay.com', 'Tanzania');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (400884, 'Berkie', 'todor', 'Agender', 'btodor67@shutterfly.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (969981, 'Bradford', 'Crump', 'Male', 'bcrump68@imdb.com', 'Uganda');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (628731, 'Katya', 'Wadie', 'Genderqueer', 'kwadie69@instagram.com', 'Argentina');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (103282, 'Dorothee', 'Rubica', 'Genderqueer', 'drubica6a@adobe.com', 'Yemen');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (374778, 'Audrey', 'Spittall', 'Genderfluid', 'aspittall6b@mlb.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (632320, 'Neils', 'Spellicy', 'Non-binary', 'nspellicy6c@accuweather.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (215472, 'Burr', 'Gabbatt', 'Non-binary', 'bgabbatt6d@disqus.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (683032, 'Buiron', 'Menat', 'Agender', 'bmenat6e@aol.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (371188, 'Nedi', 'Lomaz', 'Genderqueer', 'nlomaz6f@prlog.org', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (399762, 'Geoffrey', 'Pachmann', 'Male', 'gpachmann6g@ehow.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (858246, 'Abra', 'Hebbes', 'Agender', 'ahebbes6h@walmart.com', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (973653, 'Silvana', 'Hainey', 'Genderfluid', 'shainey6i@nydailynews.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (618194, 'Sammy', 'Casterton', 'Bigender', 'scasterton6j@google.com.hk', 'Macedonia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (168729, 'Michel', 'Bonniface', 'Agender', 'mbonniface6k@dedecms.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (199322, 'Dinnie', 'Shiel', 'Male', 'dshiel6l@utexas.edu', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (941765, 'Margaretta', 'Ugoni', 'Polygender', 'mugoni6m@spotify.com', 'Zimbabwe');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (492525, 'Madel', 'Pote', 'Genderqueer', 'mpote6n@g.co', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (321165, 'Steffi', 'de Wilde', 'Agender', 'sdewilde6o@tinyurl.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (616862, 'Aurelie', 'Wigsell', 'Female', 'awigsell6p@economist.com', 'Senegal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (764178, 'Jerrylee', 'Soppit', 'Non-binary', 'jsoppit6q@hostgator.com', 'Martinique');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (994932, 'Kinnie', 'Leyburn', 'Genderqueer', 'kleyburn6r@scribd.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (720598, 'Fina', 'Baldacchi', 'Male', 'fbaldacchi6s@noaa.gov', 'Japan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (994244, 'Teena', 'Joselovitch', 'Genderqueer', 'tjoselovitch6t@delicious.com', 'Netherlands');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (268727, 'Cosme', 'Meek', 'Genderfluid', 'cmeek6u@guardian.co.uk', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (955680, 'Maryjane', 'Corgenvin', 'Female', 'mcorgenvin6v@linkedin.com', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (169505, 'Wolfgang', 'Trillo', 'Female', 'wtrillo6w@ucsd.edu', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (304792, 'Ferdinand', 'Crone', 'Polygender', 'fcrone6x@sfgate.com', 'Mexico');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (211857, 'Natividad', 'Maun', 'Male', 'nmaun6y@amazon.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (252007, 'Daloris', 'Deave', 'Agender', 'ddeave6z@npr.org', 'Finland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (522190, 'Kathleen', 'Emlyn', 'Female', 'kemlyn70@hud.gov', 'Iraq');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (285066, 'Candis', 'Realy', 'Non-binary', 'crealy71@si.edu', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (111814, 'Trumaine', 'Pavelin', 'Agender', 'tpavelin72@amazon.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (775774, 'Sidney', 'Josiah', 'Female', 'sjosiah73@biblegateway.com', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (351234, 'George', 'Tathacott', 'Bigender', 'gtathacott74@imdb.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (771573, 'Rhetta', 'Galton', 'Genderfluid', 'rgalton75@nationalgeographic.com', 'Germany');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (586346, 'Betsey', 'Devorill', 'Male', 'bdevorill76@geocities.com', 'Ukraine');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (255083, 'Flossie', 'Bootes', 'Polygender', 'fbootes77@delicious.com', 'Australia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (842363, 'Reinhard', 'Shelbourne', 'Bigender', 'rshelbourne78@pinterest.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (993570, 'Horten', 'Pitcaithly', 'Female', 'hpitcaithly79@youtu.be', 'Argentina');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (118029, 'Chelsie', 'Llewellyn', 'Non-binary', 'cllewellyn7a@umich.edu', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (554348, 'Kahaleel', 'Kraft', 'Genderfluid', 'kkraft7b@purevolume.com', 'France');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (864185, 'Odessa', 'Eakeley', 'Polygender', 'oeakeley7c@thetimes.co.uk', 'France');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (328427, 'Elias', 'Dubery', 'Agender', 'edubery7d@photobucket.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (233399, 'Shepherd', 'Allery', 'Agender', 'sallery7e@businessinsider.com', 'Cuba');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (652752, 'Maurizia', 'Doberer', 'Agender', 'mdoberer7f@netlog.com', 'Spain');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (490401, 'Timmie', 'Reide', 'Polygender', 'treide7g@blog.com', 'Bolivia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (847044, 'Konstanze', 'Roll', 'Genderfluid', 'kroll7h@spotify.com', 'Gambia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (522390, 'Morey', 'Richfield', 'Agender', 'mrichfield7i@cocolog-nifty.com', 'Micronesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (335503, 'Nels', 'Sclanders', 'Polygender', 'nsclanders7j@usda.gov', 'Italy');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (239356, 'Adriaens', 'Deathridge', 'Bigender', 'adeathridge7k@twitpic.com', 'Finland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (724340, 'Evangelin', 'Bresnahan', 'Bigender', 'ebresnahan7l@woothemes.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (149006, 'Issi', 'McDonough', 'Genderqueer', 'imcdonough7m@adobe.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (383550, 'Lilah', 'Dorman', 'Bigender', 'ldorman7n@slate.com', 'France');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (837810, 'Stormie', 'Thomkins', 'Non-binary', 'sthomkins7o@i2i.jp', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (455458, 'Hubert', 'Gronauer', 'Male', 'hgronauer7p@nydailynews.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (320155, 'Akim', 'Peealess', 'Bigender', 'apeealess7q@nydailynews.com', 'Venezuela');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (250797, 'Maurice', 'Humbee', 'Genderfluid', 'mhumbee7r@scientificamerican.com', 'Peru');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (548016, 'Jo-anne', 'Maruszewski', 'Agender', 'jmaruszewski7s@photobucket.com', 'Czech Republic');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (167084, 'Annmaria', 'Parell', 'Agender', 'aparell7t@zdnet.com', 'Czech Republic');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (210468, 'Aurelea', 'Sergeant', 'Agender', 'asergeant7u@kickstarter.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (892317, 'Roxanne', 'Tadgell', 'Female', 'rtadgell7v@godaddy.com', 'Cayman Islands');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (534037, 'Rodd', 'Godby', 'Bigender', 'rgodby7w@spotify.com', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (238961, 'Jaclin', 'Belham', 'Polygender', 'jbelham7x@hp.com', 'Uganda');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (815687, 'Mischa', 'Avarne', 'Bigender', 'mavarne7y@drupal.org', 'Nicaragua');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (913601, 'Isadora', 'McMonies', 'Bigender', 'imcmonies7z@about.me', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (876360, 'Ann-marie', 'McCook', 'Female', 'amccook80@springer.com', 'Norway');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (100006, 'Charin', 'Skillman', 'Bigender', 'cskillman81@independent.co.uk', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (165771, 'Hendrika', 'Dietsche', 'Female', 'hdietsche82@wisc.edu', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (356199, 'Madlen', 'Thody', 'Genderfluid', 'mthody83@thetimes.co.uk', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (889846, 'Ula', 'Taunton.', 'Agender', 'utaunton84@blogs.com', 'France');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (444778, 'Catherin', 'Stigers', 'Genderfluid', 'cstigers85@cam.ac.uk', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (930237, 'Carmelle', 'Dowzell', 'Genderqueer', 'cdowzell86@paginegialle.it', 'Chile');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (419328, 'Perle', 'Spraging', 'Bigender', 'pspraging87@nymag.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (955120, 'Myrtia', 'Buzine', 'Genderqueer', 'mbuzine88@cdc.gov', 'Mexico');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (933658, 'Lizzie', 'Clemetts', 'Genderqueer', 'lclemetts89@apache.org', 'Benin');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (638500, 'Marve', 'Pensom', 'Male', 'mpensom8a@mediafire.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (489596, 'Desiree', 'Kalinsky', 'Female', 'dkalinsky8b@xrea.com', 'Uganda');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (308376, 'Byran', 'Deadman', 'Non-binary', 'bdeadman8c@pagesperso-orange.fr', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (376189, 'Octavia', 'Passby', 'Polygender', 'opassby8d@yale.edu', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (675604, 'Bertrand', 'Burnet', 'Bigender', 'bburnet8e@guardian.co.uk', 'Kuwait');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (871089, 'Clark', 'Gorman', 'Genderfluid', 'cgorman8f@spiegel.de', 'Greece');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (515763, 'Aldo', 'Bielefeld', 'Genderqueer', 'abielefeld8g@geocities.com', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (149549, 'Lindsay', 'Snelman', 'Genderqueer', 'lsnelman8h@ox.ac.uk', 'Chile');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (198056, 'Jacquette', 'Witherden', 'Polygender', 'jwitherden8i@indiatimes.com', 'Pakistan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (523773, 'Daloris', 'Elloway', 'Female', 'delloway8j@wikia.com', 'United States');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (294821, 'Mendel', 'Hearn', 'Bigender', 'mhearn8k@bizjournals.com', 'Greece');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (889347, 'Redd', 'Walmsley', 'Genderqueer', 'rwalmsley8l@cisco.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (621186, 'Jayson', 'Charlotte', 'Non-binary', 'jcharlotte8m@go.com', 'Thailand');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (538359, 'Derick', 'Creany', 'Female', 'dcreany8n@ask.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (757186, 'Robert', 'Noddings', 'Bigender', 'rnoddings8o@aboutads.info', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (257628, 'Sabina', 'Lowing', 'Genderqueer', 'slowing8p@youtu.be', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (999263, 'Nobie', 'Barthorpe', 'Genderfluid', 'nbarthorpe8q@omniture.com', 'Norway');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (735903, 'Margarette', 'Lilbourne', 'Polygender', 'mlilbourne8r@dot.gov', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (948009, 'Blinnie', 'McCarry', 'Polygender', 'bmccarry8s@elegantthemes.com', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (722817, 'Consolata', 'Ashbey', 'Agender', 'cashbey8t@epa.gov', 'United States');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (352398, 'Marc', 'Trangmar', 'Non-binary', 'mtrangmar8u@bbb.org', 'United States');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (521275, 'Ford', 'Armall', 'Agender', 'farmall8v@tmall.com', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (798339, 'Caspar', 'Waterworth', 'Polygender', 'cwaterworth8w@mapy.cz', 'France');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (191749, 'Mitch', 'Glancey', 'Female', 'mglancey8x@economist.com', 'Cuba');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (503409, 'Pattie', 'Matteau', 'Genderqueer', 'pmatteau8y@people.com.cn', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (755021, 'Johnath', 'Espadero', 'Male', 'jespadero8z@loc.gov', 'Japan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (952602, 'Dyana', 'Marousek', 'Male', 'dmarousek90@netlog.com', 'Tunisia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (882567, 'Morganne', 'Miliffe', 'Bigender', 'mmiliffe91@histats.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (303765, 'Wendel', 'Espinoy', 'Agender', 'wespinoy92@hostgator.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (182437, 'Anne', 'Siddeley', 'Agender', 'asiddeley93@army.mil', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (372460, 'Gussy', 'Markovich', 'Female', 'gmarkovich94@hud.gov', 'Canada');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (398934, 'Gunar', 'Sporrij', 'Bigender', 'gsporrij95@microsoft.com', 'France');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (265750, 'Caterina', 'Leathes', 'Bigender', 'cleathes96@ehow.com', 'Malaysia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (919762, 'Lyndsey', 'Devenny', 'Genderfluid', 'ldevenny97@admin.ch', 'Myanmar');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (123240, 'Hammad', 'Isard', 'Female', 'hisard98@jugem.jp', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (332409, 'Fannie', 'Gower', 'Polygender', 'fgower99@hp.com', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (766322, 'Raddy', 'Gadie', 'Polygender', 'rgadie9a@virginia.edu', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (395382, 'Rivy', 'Freddi', 'Genderqueer', 'rfreddi9b@tripod.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (980824, 'Jazmin', 'Ettels', 'Genderqueer', 'jettels9c@wp.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (534824, 'Eugene', 'Markushkin', 'Female', 'emarkushkin9d@hud.gov', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (501874, 'Israel', 'Middleweek', 'Male', 'imiddleweek9e@msu.edu', 'Guatemala');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (230398, 'Gunner', 'Grestie', 'Genderfluid', 'ggrestie9f@meetup.com', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (389172, 'Cece', 'Riddington', 'Female', 'criddington9g@gmpg.org', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (324368, 'Keen', 'Seamans', 'Non-binary', 'kseamans9h@storify.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (182356, 'Davin', 'Paulo', 'Male', 'dpaulo9i@smugmug.com', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (628823, 'Curt', 'McCombe', 'Non-binary', 'cmccombe9j@virginia.edu', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (359083, 'Cindra', 'Beggs', 'Agender', 'cbeggs9k@trellian.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (765798, 'Twila', 'Doel', 'Polygender', 'tdoel9l@amazon.com', 'Belize');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (554810, 'Gaby', 'Wykes', 'Polygender', 'gwykes9m@lulu.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (279762, 'Jewell', 'Guest', 'Polygender', 'jguest9n@sourceforge.net', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (724955, 'Ware', 'Humphery', 'Agender', 'whumphery9o@epa.gov', 'Malaysia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (693614, 'Jana', 'Meineken', 'Bigender', 'jmeineken9p@vinaora.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (458876, 'Britta', 'Perel', 'Male', 'bperel9q@goo.gl', 'Bangladesh');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (653016, 'Tildie', 'Jachtym', 'Genderfluid', 'tjachtym9r@over-blog.com', 'Egypt');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (211990, 'Wat', 'Garbar', 'Polygender', 'wgarbar9s@nytimes.com', 'Ecuador');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (869601, 'Annie', 'Ganforthe', 'Non-binary', 'aganforthe9t@histats.com', 'Ethiopia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (925506, 'Ban', 'Aylen', 'Male', 'baylen9u@last.fm', 'Ukraine');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (681821, 'Quentin', 'Ciobutaro', 'Genderqueer', 'qciobutaro9v@g.co', 'Greece');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (990044, 'Simonette', 'Oldaker', 'Non-binary', 'soldaker9w@admin.ch', 'Cuba');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (643340, 'Obadiah', 'Dunabie', 'Female', 'odunabie9x@foxnews.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (678068, 'Jaclin', 'Sellstrom', 'Agender', 'jsellstrom9y@prweb.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (889503, 'Ody', 'Wheeldon', 'Male', 'owheeldon9z@spotify.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (197465, 'Marja', 'Dreye', 'Bigender', 'mdreyea0@auda.org.au', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (369286, 'Junina', 'Lamberteschi', 'Male', 'jlamberteschia1@skype.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (181341, 'Katrinka', 'MacRury', 'Male', 'kmacrurya2@elpais.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (437461, 'Winslow', 'Crudgington', 'Polygender', 'wcrudgingtona3@redcross.org', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (408899, 'Inglis', 'Rosevear', 'Bigender', 'iroseveara4@google.cn', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (143509, 'Meryl', 'Oakenfall', 'Non-binary', 'moakenfalla5@cmu.edu', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (828623, 'Glenn', 'Earie', 'Polygender', 'geariea6@woothemes.com', 'Canada');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (784645, 'Rafaelita', 'Schutt', 'Female', 'rschutta7@geocities.jp', 'Japan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (237211, 'Vernor', 'Lortzing', 'Non-binary', 'vlortzinga8@sciencedirect.com', 'Bosnia and Herzegovina');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (660733, 'Jonah', 'Tweede', 'Polygender', 'jtweedea9@over-blog.com', 'Morocco');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (712169, 'Bev', 'Giron', 'Genderfluid', 'bgironaa@sbwire.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (924652, 'Sisile', 'Neno', 'Genderqueer', 'snenoab@businessweek.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (116848, 'Vladimir', 'Gurg', 'Male', 'vgurgac@archive.org', 'Nigeria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (568718, 'Sosanna', 'Durek', 'Genderqueer', 'sdurekad@macromedia.com', 'Ethiopia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (231105, 'Alix', 'Harrowell', 'Bigender', 'aharrowellae@tripod.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (404856, 'Donalt', 'Patience', 'Agender', 'dpatienceaf@ft.com', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (794009, 'Vito', 'Womack', 'Female', 'vwomackag@goodreads.com', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (368911, 'Rodge', 'Hacking', 'Genderfluid', 'rhackingah@apple.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (184081, 'Calley', 'Howatt', 'Non-binary', 'chowattai@nifty.com', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (338876, 'Feodora', 'Gwyn', 'Male', 'fgwynaj@buzzfeed.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (388541, 'Mathian', 'Elgey', 'Polygender', 'melgeyak@salon.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (472558, 'Cristine', 'Worrill', 'Non-binary', 'cworrillal@chronoengine.com', 'Peru');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (248031, 'Etta', 'Russam', 'Female', 'erussamam@spiegel.de', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (749103, 'Traci', 'Giblett', 'Polygender', 'tgiblettan@liveinternet.ru', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (513452, 'Shara', 'Brogini', 'Agender', 'sbroginiao@princeton.edu', 'Pakistan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (657502, 'Benedikt', 'Cattroll', 'Genderfluid', 'bcattrollap@amazon.de', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (837395, 'Leoline', 'Jouannisson', 'Polygender', 'ljouannissonaq@ustream.tv', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (344232, 'Johannes', 'Dongles', 'Agender', 'jdonglesar@pagesperso-orange.fr', 'Ethiopia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (431050, 'Zebadiah', 'Galpen', 'Non-binary', 'zgalpenas@msu.edu', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (889030, 'Clarke', 'Whifen', 'Male', 'cwhifenat@google.ca', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (632268, 'Onfroi', 'Pitone', 'Bigender', 'opitoneau@msn.com', 'Mexico');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (424571, 'Heddie', 'Sooper', 'Agender', 'hsooperav@wordpress.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (905501, 'Minda', 'Wyer', 'Female', 'mwyeraw@dion.ne.jp', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (710696, 'Juan', 'Birtwisle', 'Female', 'jbirtwisleax@squarespace.com', 'Andorra');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (430479, 'April', 'Cardoso', 'Genderfluid', 'acardosoay@shutterfly.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (243644, 'Wilt', 'Elsdon', 'Genderfluid', 'welsdonaz@walmart.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (612637, 'Valerie', 'Ashburne', 'Non-binary', 'vashburneb0@cloudflare.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (954490, 'Gilbertina', 'Aim', 'Female', 'gaimb1@typepad.com', 'Ecuador');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (120359, 'Thorstein', 'Gisburne', 'Bigender', 'tgisburneb2@cornell.edu', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (136797, 'Concordia', 'Maxwale', 'Non-binary', 'cmaxwaleb3@topsy.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (890007, 'Rois', 'Buggs', 'Genderfluid', 'rbuggsb4@yahoo.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (714161, 'Judah', 'Goane', 'Polygender', 'jgoaneb5@so-net.ne.jp', 'Cuba');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (632758, 'Werner', 'O''Sharkey', 'Non-binary', 'wosharkeyb6@samsung.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (570162, 'Bellina', 'Zorzoni', 'Male', 'bzorzonib7@ycombinator.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (981816, 'Bartie', 'Bursnall', 'Genderfluid', 'bbursnallb8@exblog.jp', 'North Korea');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (459876, 'Merrick', 'Sterrie', 'Bigender', 'msterrieb9@telegraph.co.uk', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (821202, 'Meir', 'Oulner', 'Non-binary', 'moulnerba@telegraph.co.uk', 'Canada');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (351975, 'Coral', 'Ferrettino', 'Genderqueer', 'cferrettinobb@geocities.jp', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (961767, 'Conrado', 'Buckingham', 'Bigender', 'cbuckinghambc@usda.gov', 'Yemen');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (136201, 'Hercules', 'D''Agostino', 'Male', 'hdagostinobd@hugedomains.com', 'Vietnam');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (396602, 'Jarrid', 'Bruyns', 'Non-binary', 'jbruynsbe@altervista.org', 'Peru');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (166719, 'Rosita', 'Vallack', 'Genderfluid', 'rvallackbf@dailymail.co.uk', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (739688, 'Danny', 'Sambrok', 'Polygender', 'dsambrokbg@barnesandnoble.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (259569, 'Emylee', 'Foreman', 'Female', 'eforemanbh@prlog.org', 'United States');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (828643, 'Daryn', 'Mandifield', 'Genderfluid', 'dmandifieldbi@seesaa.net', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (473301, 'Audry', 'Marks', 'Polygender', 'amarksbj@marriott.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (333624, 'Rosaline', 'Artingstall', 'Non-binary', 'rartingstallbk@uiuc.edu', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (830264, 'Clarine', 'Placstone', 'Polygender', 'cplacstonebl@ustream.tv', 'Pakistan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (111401, 'Rosco', 'Hugk', 'Non-binary', 'rhugkbm@fastcompany.com', 'Saint Kitts and Nevis');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (422663, 'Bent', 'Ritmeier', 'Male', 'britmeierbn@friendfeed.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (513686, 'Andee', 'Lamas', 'Genderqueer', 'alamasbo@omniture.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (221025, 'Ronnie', 'Gosney', 'Female', 'rgosneybp@fda.gov', 'Thailand');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (552784, 'Zorina', 'McIlvaney', 'Polygender', 'zmcilvaneybq@ucsd.edu', 'Colombia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (945048, 'Elroy', 'Revell', 'Agender', 'erevellbr@wiley.com', 'Vietnam');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (826913, 'Ladonna', 'Castelluzzi', 'Agender', 'lcastelluzzibs@theguardian.com', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (254338, 'Ody', 'Lyver', 'Non-binary', 'olyverbt@i2i.jp', 'Poland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (914748, 'Gearalt', 'Tordoff', 'Bigender', 'gtordoffbu@epa.gov', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (884243, 'Myrtie', 'Twinning', 'Genderfluid', 'mtwinningbv@ucla.edu', 'Argentina');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (518443, 'Dwayne', 'Andrejevic', 'Female', 'dandrejevicbw@ox.ac.uk', 'Jordan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (644643, 'Thayne', 'Lindro', 'Non-binary', 'tlindrobx@theguardian.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (800138, 'Kalie', 'Twinborne', 'Female', 'ktwinborneby@ucoz.ru', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (170336, 'Toiboid', 'Picardo', 'Agender', 'tpicardobz@google.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (929564, 'Alethea', 'Tupling', 'Genderqueer', 'atuplingc0@mozilla.com', 'Argentina');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (312454, 'Carroll', 'Allman', 'Male', 'callmanc1@google.es', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (941942, 'Justis', 'Elton', 'Bigender', 'jeltonc2@gnu.org', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (288858, 'Atlanta', 'Dubique', 'Genderqueer', 'adubiquec3@princeton.edu', 'Malta');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (919886, 'Trescha', 'Deverall', 'Bigender', 'tdeverallc4@google.ca', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (575172, 'Derrick', 'Chopin', 'Male', 'dchopinc5@alibaba.com', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (436457, 'Robena', 'Letford', 'Agender', 'rletfordc6@is.gd', 'United States');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (358089, 'Laurena', 'Rowntree', 'Genderqueer', 'lrowntreec7@mlb.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (480108, 'Laughton', 'Woolrich', 'Genderfluid', 'lwoolrichc8@google.co.jp', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (777588, 'Donal', 'Ivimey', 'Polygender', 'divimeyc9@statcounter.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (695512, 'Kirsteni', 'Michie', 'Genderfluid', 'kmichieca@ft.com', 'Ireland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (284173, 'Cathleen', 'Setterington', 'Genderfluid', 'csetteringtoncb@columbia.edu', 'Mexico');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (950368, 'Dian', 'Sparrowhawk', 'Male', 'dsparrowhawkcc@vkontakte.ru', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (533781, 'Gregg', 'Davio', 'Genderqueer', 'gdaviocd@cloudflare.com', 'Japan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (968044, 'Gwynne', 'Jeannon', 'Genderfluid', 'gjeannonce@ed.gov', 'Thailand');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (985226, 'Cristian', 'O'' Culligan', 'Genderqueer', 'coculligancf@economist.com', 'Argentina');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (145762, 'Arielle', 'Coxen', 'Agender', 'acoxencg@people.com.cn', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (380759, 'Beryl', 'Robe', 'Genderqueer', 'brobech@topsy.com', 'Jamaica');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (899856, 'Spike', 'Light', 'Genderqueer', 'slightci@irs.gov', 'Nigeria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (706091, 'Parnell', 'Foxon', 'Non-binary', 'pfoxoncj@delicious.com', 'Egypt');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (310364, 'Marcia', 'Piniur', 'Genderqueer', 'mpiniurck@google.pl', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (836176, 'Adey', 'MattiCCI', 'Female', 'amatticcicl@hibu.com', 'Thailand');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (213501, 'Herta', 'Earey', 'Female', 'heareycm@cisco.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (923479, 'Auguste', 'Meeus', 'Genderfluid', 'ameeuscn@yolasite.com', 'Bolivia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (835539, 'Marylynne', 'Barraclough', 'Bigender', 'mbarracloughco@angelfire.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (384530, 'Gwenette', 'Ziehms', 'Agender', 'gziehmscp@google.es', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (368912, 'Yasmin', 'Dorrins', 'Male', 'ydorrinscq@pcworld.com', 'Latvia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (215095, 'Berkley', 'Hicken', 'Genderfluid', 'bhickencr@odnoklassniki.ru', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (199278, 'Renae', 'Wagon', 'Male', 'rwagoncs@redcross.org', 'Colombia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (165216, 'Riki', 'Frangello', 'Non-binary', 'rfrangelloct@theguardian.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (421389, 'Jehanna', 'Konerding', 'Genderqueer', 'jkonerdingcu@phoca.cz', 'Hungary');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (788132, 'Catriona', 'Jizhaki', 'Agender', 'cjizhakicv@loc.gov', 'United States');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (311712, 'Orville', 'O''Sharkey', 'Male', 'oosharkeycw@msn.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (368216, 'Dennet', 'Windaybank', 'Genderqueer', 'dwindaybankcx@ucoz.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (178934, 'Ivory', 'Rogan', 'Agender', 'irogancy@exblog.jp', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (784960, 'Wendeline', 'Desorts', 'Bigender', 'wdesortscz@sina.com.cn', 'Iran');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (723183, 'Renado', 'Kelwaybamber', 'Polygender', 'rkelwaybamberd0@miitbeian.gov.cn', 'Japan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (513982, 'Lisetta', 'Kivlehan', 'Polygender', 'lkivlehand1@aboutads.info', 'Germany');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (666295, 'Roberto', 'Willey', 'Polygender', 'rwilleyd2@slashdot.org', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (702354, 'Jan', 'Dowson', 'Female', 'jdowsond3@yelp.com', 'Vietnam');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (495696, 'Burg', 'Edds', 'Agender', 'beddsd4@woothemes.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (127257, 'Courtney', 'Milesap', 'Female', 'cmilesapd5@narod.ru', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (963007, 'Reggi', 'Cleveley', 'Agender', 'rcleveleyd6@csmonitor.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (606672, 'Perren', 'Bruun', 'Bigender', 'pbruund7@home.pl', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (434533, 'Roseann', 'Brabham', 'Bigender', 'rbrabhamd8@globo.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (922271, 'Emogene', 'Swiggs', 'Male', 'eswiggsd9@newsvine.com', 'Mexico');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (967869, 'Jacqui', 'Chessell', 'Genderqueer', 'jchessellda@cdc.gov', 'Azerbaijan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (318616, 'Christan', 'Minot', 'Non-binary', 'cminotdb@archive.org', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (859172, 'Nikolaos', 'Junkin', 'Non-binary', 'njunkindc@google.it', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (209711, 'Kathye', 'Mioni', 'Male', 'kmionidd@cnn.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (110738, 'Tamqrah', 'Symcock', 'Non-binary', 'tsymcockde@comcast.net', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (651762, 'Dulce', 'Weddeburn - Scrimgeour', 'Bigender', 'dweddeburnscrimgeourdf@pbs.org', 'South Korea');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (789384, 'Sidoney', 'Gellier', 'Male', 'sgellierdg@walmart.com', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (194657, 'Sarge', 'Hurrell', 'Non-binary', 'shurrelldh@ovh.net', 'Japan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (363573, 'Corissa', 'Saunper', 'Genderqueer', 'csaunperdi@uiuc.edu', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (501079, 'Myrtle', 'Sherman', 'Bigender', 'mshermandj@ucoz.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (378013, 'Cassie', 'Menguy', 'Bigender', 'cmenguydk@bloglovin.com', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (375239, 'Frans', 'Loughhead', 'Non-binary', 'floughheaddl@answers.com', 'Paraguay');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (422077, 'Arlyne', 'Waleran', 'Polygender', 'awalerandm@timesonline.co.uk', 'Greece');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (399915, 'Sherline', 'Kiggel', 'Male', 'skiggeldn@ask.com', 'Slovenia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (520962, 'Liesa', 'VanBrugh', 'Genderqueer', 'lvanbrughdo@ucsd.edu', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (267931, 'Reuben', 'Roffe', 'Bigender', 'rroffedp@tmall.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (533307, 'Orelle', 'Stranger', 'Polygender', 'ostrangerdq@symantec.com', 'Egypt');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (225593, 'Ardisj', 'Iveagh', 'Male', 'aiveaghdr@jiathis.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (462198, 'Michell', 'Willan', 'Bigender', 'mwillands@storify.com', 'Ecuador');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (590546, 'Kata', 'Billyard', 'Non-binary', 'kbillyarddt@google.ru', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (800851, 'Gerard', 'Carik', 'Non-binary', 'gcarikdv@cyberchimps.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (366176, 'Francene', 'MacEveley', 'Male', 'fmaceveleydw@webs.com', 'Djibouti');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (726820, 'Chic', 'Illwell', 'Polygender', 'cillwelldx@g.co', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (856526, 'Whitaker', 'Playford', 'Agender', 'wplayforddy@yelp.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (365114, 'Eulalie', 'Acreman', 'Genderfluid', 'eacremandz@163.com', 'South Korea');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (884605, 'Natalee', 'MacParlan', 'Agender', 'nmacparlane0@aboutads.info', 'Argentina');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (543708, 'Anny', 'Oakenfall', 'Bigender', 'aoakenfalle1@facebook.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (188628, 'Nonnah', 'Clearie', 'Male', 'ncleariee2@apache.org', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (217473, 'Frederico', 'Derington', 'Agender', 'fderingtone3@sitemeter.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (296225, 'Rube', 'Jenkison', 'Male', 'rjenkisone4@go.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (116583, 'Babara', 'Knotton', 'Genderfluid', 'bknottone5@freewebs.com', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (486166, 'Beitris', 'Cranke', 'Genderqueer', 'bcrankee6@ft.com', 'Norway');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (692436, 'Shane', 'Hurnell', 'Female', 'shurnelle7@jugem.jp', 'Colombia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (381700, 'Jania', 'Kiley', 'Polygender', 'jkileye8@geocities.com', 'Eritrea');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (629662, 'Sauncho', 'Herries', 'Polygender', 'sherriese9@canalblog.com', 'Macedonia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (602510, 'Marin', 'Greenalf', 'Polygender', 'mgreenalfea@statcounter.com', 'Canada');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (743769, 'Yancy', 'Fenner', 'Bigender', 'yfennereb@delicious.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (117696, 'Seth', 'Cheeney', 'Bigender', 'scheeneyec@mapy.cz', 'Bulgaria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (793237, 'Roch', 'Lainton', 'Male', 'rlaintoned@usgs.gov', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (862404, 'Amble', 'Battle', 'Agender', 'abattleee@nationalgeographic.com', 'Pakistan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (344946, 'Katleen', 'Trelease', 'Non-binary', 'ktreleaseef@sciencedaily.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (533435, 'Aluino', 'Fearick', 'Non-binary', 'afearickeg@rediff.com', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (297824, 'Dalt', 'Curm', 'Non-binary', 'dcurmeh@godaddy.com', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (248502, 'Ellsworth', 'Birks', 'Genderfluid', 'ebirksei@marketwatch.com', 'Ecuador');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (517556, 'Frederica', 'Clampe', 'Genderqueer', 'fclampeej@clickbank.net', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (577544, 'Sebastien', 'Green', 'Polygender', 'sgreenek@tuttocitta.it', 'Armenia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (984087, 'Barnett', 'Seeds', 'Genderqueer', 'bseedsel@jiathis.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (884267, 'Damara', 'Brettel', 'Male', 'dbrettelem@answers.com', 'Portugal');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (129066, 'Harcourt', 'Blamire', 'Genderfluid', 'hblamireen@studiopress.com', 'Uzbekistan');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (717472, 'Veradis', 'Adrienne', 'Non-binary', 'vadrienneeo@baidu.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (728243, 'Tiffie', 'Coper', 'Non-binary', 'tcoperep@google.fr', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (951470, 'Charity', 'Isaksson', 'Bigender', 'cisakssoneq@gnu.org', 'Colombia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (239359, 'Florinda', 'Haxley', 'Genderfluid', 'fhaxleyer@si.edu', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (358769, 'Raeann', 'Syalvester', 'Non-binary', 'rsyalvesteres@twitter.com', 'Syria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (994854, 'Corbet', 'Heigold', 'Male', 'cheigoldet@multiply.com', 'Norway');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (747653, 'Tedd', 'Goodson', 'Female', 'tgoodsoneu@businessinsider.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (492920, 'Salomone', 'Della Scala', 'Non-binary', 'sdellascalaev@japanpost.jp', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (336953, 'Brewster', 'Icke', 'Genderfluid', 'bickeew@gov.uk', 'Finland');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (114958, 'Friedrick', 'Mynett', 'Female', 'fmynettex@npr.org', 'Brazil');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (385010, 'Kendall', 'Cescoti', 'Bigender', 'kcescotiey@cafepress.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (965364, 'Adiana', 'Cove', 'Female', 'acoveez@163.com', 'Bulgaria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (813382, 'Karalynn', 'Goozee', 'Genderqueer', 'kgoozeef0@spiegel.de', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (799849, 'Kaleb', 'Woodfin', 'Male', 'kwoodfinf1@bizjournals.com', 'Laos');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (183347, 'Sky', 'Annets', 'Female', 'sannetsf2@bloglines.com', 'France');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (719354, 'Merill', 'MacHoste', 'Polygender', 'mmachostef3@noaa.gov', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (746368, 'Devon', 'McTavish', 'Agender', 'dmctavishf4@utexas.edu', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (987456, 'Shawn', 'Mance', 'Non-binary', 'smancef5@cnn.com', 'Russia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (652616, 'Maryanne', 'Doumenc', 'Non-binary', 'mdoumencf6@opera.com', 'Georgia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (400470, 'Westleigh', 'Kernock', 'Agender', 'wkernockf7@eventbrite.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (399862, 'Midge', 'Mansel', 'Male', 'mmanself8@fda.gov', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (437152, 'Rees', 'Lipp', 'Genderfluid', 'rlippf9@ox.ac.uk', 'Nigeria');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (194765, 'Gilda', 'Velte', 'Genderqueer', 'gveltefa@vkontakte.ru', 'Haiti');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (849864, 'Doll', 'Gribben', 'Agender', 'dgribbenfb@spiegel.de', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (912007, 'Nelle', 'Benedicto', 'Agender', 'nbenedictofc@sohu.com', 'Philippines');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (506948, 'Alvis', 'Taaffe', 'Polygender', 'ataaffefd@facebook.com', 'Argentina');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (146131, 'Cyb', 'Addis', 'Genderfluid', 'caddisfe@google.com.br', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (248710, 'Gaylor', 'Etchells', 'Bigender', 'getchellsff@hao123.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (533841, 'Barrett', 'Linton', 'Non-binary', 'blintonfg@tiny.cc', 'Tanzania');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (229700, 'Guido', 'Lightman', 'Genderfluid', 'glightmanfh@devhub.com', 'Indonesia');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (296028, 'Margot', 'Ackenson', 'Agender', 'mackensonfi@ebay.com', 'Nicaragua');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (276524, 'Elisha', 'Caban', 'Bigender', 'ecabanfj@ameblo.jp', 'Peru');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (492905, 'Kristoffer', 'Delgado', 'Bigender', 'kdelgadofk@last.fm', 'United States');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (842454, 'Valentine', 'Merigot', 'Non-binary', 'vmerigotfl@walmart.com', 'Sweden');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (533803, 'Terrell', 'Hanway', 'Male', 'thanwayfm@purevolume.com', 'China');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (705690, 'Branden', 'Clewlowe', 'Female', 'bclewlowefn@state.gov', 'Albania');
insert into Students (applicant_id, first_name, last_name, gender, email, nationality) values (182774, 'Freddy', 'Gerb', 'Female', 'fgerbfo@adobe.com', 'Uganda');


insert into Universities (school_name, application_received) values ('University of Cyprus', 5687);
insert into Universities (school_name, application_received) values ('Kazan State Pedagogical University', 9265);
insert into Universities (school_name, application_received) values ('Kagawa Institute of Nutrition', 9166);
insert into Universities (school_name, application_received) values ('Hong Kong Polytechnic University', 8442);
insert into Universities (school_name, application_received) values ('Geneva College', 9994);
insert into Universities (school_name, application_received) values ('Kansas Wesleyan University', 4778);
insert into Universities (school_name, application_received) values ('Kanpur University', 8322);
insert into Universities (school_name, application_received) values ('Hannam University', 2949);
insert into Universities (school_name, application_received) values ('Universidad Eugenio Maria de Hostos', 1343);
insert into Universities (school_name, application_received) values ('Umutara Polytechnic', 7758);
insert into Universities (school_name, application_received) values ('Université de Bretagne Occidentale', 9755);
insert into Universities (school_name, application_received) values ('Gnesins Russian Academy of Music', 4104);
insert into Universities (school_name, application_received) values ('Universidad Los Angeles de Chimbote', 6539);
insert into Universities (school_name, application_received) values ('Salahddin University (Kurdistan Region)', 7525);
insert into Universities (school_name, application_received) values ('Western Kentucky University', 1065);
insert into Universities (school_name, application_received) values ('Crescent University', 1673);
insert into Universities (school_name, application_received) values ('Instituto Universitario de La Paz', 5103);
insert into Universities (school_name, application_received) values ('Lithunian University of Agriculture', 6631);
insert into Universities (school_name, application_received) values ('Télé-université, Université du Québec', 6699);
insert into Universities (school_name, application_received) values ('Universitas Madura', 4343);
insert into Universities (school_name, application_received) values ('California University of Pennsylvania', 9891);
insert into Universities (school_name, application_received) values ('St. Augustine University of Tanzania', 1466);
insert into Universities (school_name, application_received) values ('Longwood College', 3850);
insert into Universities (school_name, application_received) values ('Institut Teknologi Adhi Tama Surabaya', 4180);
insert into Universities (school_name, application_received) values ('Hankyong National University', 6442);
insert into Universities (school_name, application_received) values ('University of Michigan - Ann Arbor', 1256);
insert into Universities (school_name, application_received) values ('College of Notre Dame of Maryland', 6951);
insert into Universities (school_name, application_received) values ('Ecole des Hautes Etudes en Gestion Informatique et Communication', 5044);
insert into Universities (school_name, application_received) values ('Mohammad Ali Jinnah University', 4580);
insert into Universities (school_name, application_received) values ('Guru Nanak Dev University', 7347);
insert into Universities (school_name, application_received) values ('Pontifícia Universidade Católica do Rio de Janeiro', 7856);
insert into Universities (school_name, application_received) values ('Universidad EAFIT', 3063);
insert into Universities (school_name, application_received) values ('Thomas Jefferson University', 9085);
insert into Universities (school_name, application_received) values ('University of Calgary', 7374);
insert into Universities (school_name, application_received) values ('National Institute of Industrial Engineering', 4072);
insert into Universities (school_name, application_received) values ('Ecole Supérieure de Commerce de Toulouse', 2370);
insert into Universities (school_name, application_received) values ('Maltepe University', 7483);
insert into Universities (school_name, application_received) values ('Islamic Azad University, Parand', 9252);
insert into Universities (school_name, application_received) values ('Mindanao State University', 8564);
insert into Universities (school_name, application_received) values ('Universidade Federal de Mato Grosso do Sul', 1373);
insert into Universities (school_name, application_received) values ('Iact College', 2961);
insert into Universities (school_name, application_received) values ('College for Creative Studies', 2384);
insert into Universities (school_name, application_received) values ('Global University', 9707);
insert into Universities (school_name, application_received) values ('University of Jammu', 3321);
insert into Universities (school_name, application_received) values ('Europäische Betriebswirtschafts-Akademie', 9185);
insert into Universities (school_name, application_received) values ('Al-baha University', 6825);
insert into Universities (school_name, application_received) values ('Toyohashi University of Technology', 9739);
insert into Universities (school_name, application_received) values ('Miryang National University', 8811);
insert into Universities (school_name, application_received) values ('Khalifa University of Science, Technology and Research', 2990);
insert into Universities (school_name, application_received) values ('Chang Gung University', 6281);
insert into Universities (school_name, application_received) values ('Northwest University', 5122);
insert into Universities (school_name, application_received) values ('Technische Universität Carolo-Wilhelmina Braunschweig', 5145);
insert into Universities (school_name, application_received) values ('Kyushu Institute of Technology', 4585);
insert into Universities (school_name, application_received) values ('St. Mary''s University of San Antonio', 9090);
insert into Universities (school_name, application_received) values ('University of California, San Diego', 9255);
insert into Universities (school_name, application_received) values ('Institut National des Sciences Appliquées de Rouen', 7748);
insert into Universities (school_name, application_received) values ('Georgetown College', 1503);
insert into Universities (school_name, application_received) values ('Ukhta State Technical University', 8145);
insert into Universities (school_name, application_received) values ('University of Glamorgan', 3972);
insert into Universities (school_name, application_received) values ('Universidade Ibirapuera', 3822);
insert into Universities (school_name, application_received) values ('Universidad Hispanoamericana', 1065);
insert into Universities (school_name, application_received) values ('Shandong University of Art and Design', 7878);
insert into Universities (school_name, application_received) values ('University of the Thai Chamber of Commerce', 6033);
insert into Universities (school_name, application_received) values ('University of the South Pacific School of Agriculture', 6244);
insert into Universities (school_name, application_received) values ('Universidad Internacional de Integración de América Latina', 4471);
insert into Universities (school_name, application_received) values ('Argosy University', 9420);
insert into Universities (school_name, application_received) values ('Mamoun Private University for Science and Technology', 8103);
insert into Universities (school_name, application_received) values ('Link Campus University of Malta', 2757);
insert into Universities (school_name, application_received) values ('University of East Anglia', 1247);
insert into Universities (school_name, application_received) values ('Universidad Juan Misael Saracho', 9767);
insert into Universities (school_name, application_received) values ('University of Sadat City', 9190);
insert into Universities (school_name, application_received) values ('Coppin State College', 1289);
insert into Universities (school_name, application_received) values ('Medical Faculty, Osh State University', 7043);
insert into Universities (school_name, application_received) values ('Universidad Tecnológica del Centro', 5088);
insert into Universities (school_name, application_received) values ('Ramapo College of New Jersey', 1098);
insert into Universities (school_name, application_received) values ('Universidad Norbert Wiener', 3411);
insert into Universities (school_name, application_received) values ('Ambrose Alli University', 2915);
insert into Universities (school_name, application_received) values ('O''More College of Design', 6007);
insert into Universities (school_name, application_received) values ('University of Mining and Geology "St. Ivan Rils"', 4268);
insert into Universities (school_name, application_received) values ('National Academy for Theatre and Film Arts "Krustju Sarafov"', 3798);
insert into Universities (school_name, application_received) values ('University of Kalamoon', 6735);
insert into Universities (school_name, application_received) values ('Universidad del Valle de Atemajac', 7089);
insert into Universities (school_name, application_received) values ('University of Ontario Institute of Technology', 5807);
insert into Universities (school_name, application_received) values ('Universitas Islam Riau', 8143);
insert into Universities (school_name, application_received) values ('Universidad de San Andres', 1462);
insert into Universities (school_name, application_received) values ('Samara State Academy of Architecture and Civil Engineering', 7920);
insert into Universities (school_name, application_received) values ('Inha University', 8834);
insert into Universities (school_name, application_received) values ('Universidade Gregorio Semedo', 8392);
insert into Universities (school_name, application_received) values ('Universiti Kebangsaan Malaysia', 4378);
insert into Universities (school_name, application_received) values ('Universidad Fidélitas', 6320);
insert into Universities (school_name, application_received) values ('Georgia Health Sciences University', 1215);
insert into Universities (school_name, application_received) values ('University of Texas at Dallas', 2593);
insert into Universities (school_name, application_received) values ('University of Petra', 5118);
insert into Universities (school_name, application_received) values ('Universidade Federal Rural de Pernambuco', 2813);
insert into Universities (school_name, application_received) values ('Indian Institute of Technology, Roorkee', 7639);
insert into Universities (school_name, application_received) values ('Vikram University', 7238);
insert into Universities (school_name, application_received) values ('Busoga University', 5029);
insert into Universities (school_name, application_received) values ('College of Notre Dame', 1538);
insert into Universities (school_name, application_received) values ('Al-Ahliyya Amman University', 6300);
insert into Universities (school_name, application_received) values ('Ecole Nationale Supérieure des Mines de St-Etienne', 6625);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into Admitted (applicant_id, school_name)
select applicant_id , school_name
from Students, Universities
order by random()
limit 1000;
