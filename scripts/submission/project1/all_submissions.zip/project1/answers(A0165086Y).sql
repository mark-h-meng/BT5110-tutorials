/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/* Mukeshwaran Baskaran / A0165086Y                                     */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */

/* 
E1 is the Car_Data.sql file. It contains details of all the cars owned by the ride sharing company, Gruber.
The details of each car are its unique identity number[PRIMARY KEY], its model, its model year, age of car and a row number for ordering purposes. There are a total of 100 cars.
E2 is the Taxi_Driver_Data.sql file. It contains details of all the drivers working for Gruber.
The details of each drivers is their identity number [PRIMARY KEY], full name, contact number, email and their age. There are a total of 100 drivers.
E1 and E2 are connected through R (Car_Driver_Relation), which is the table containing the relations between drivers and cars. Depending on availability, any driver can drive any car and any car can be driven by any driver. Many to many relationship between cars and drivers.The Car_Driver_Relation references car identity number from car_data and driver identity number from driver_data. The primary key is a composite of car_id and driver_id.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE Car_Data (
	Car_ID VARCHAR(50) PRIMARY KEY,
	Car_Model VARCHAR(50) NOT NULL,
	Car_Model_Year VARCHAR(50) NOT NULL,
	Car_Age INT NOT NULL,
	_row_ INT NOT NULL
);

CREATE TABLE Taxi_Driver_Data (
	Driver_ID INT PRIMARY KEY,
	Driver_Full_Name VARCHAR(50) NOT NULL,
	Driver_Phone_No VARCHAR(50) NOT NULL,
	Driver_Email VARCHAR(50) NOT NULL,
	Driver_Age INT NOT NULL
);


CREATE TABLE Car_Driver_Relation (
    Car_ID VARCHAR(50) REFERENCES Car_Data(Car_ID)
    ON UPDATE CASCADE ON DELETE CASCADE
    DEFERRABLE INITIALLY DEFERRED,
    Driver_ID INT REFERENCES Taxi_Driver_Data(Driver_ID)
    ON UPDATE CASCADE ON DELETE CASCADE
    DEFERRABLE INITIALLY DEFERRED,
    PRIMARY KEY (Car_ID,Driver_ID)
);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/*Insert Car Data*/
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WAUEFBFL9AN425879', 'Rapide', 2011, 77, 1);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1C4RJEAG0EC411790', 'Skylark', 1992, 80, 2);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('YV4852CT0A1165688', 'RL', 2010, 35, 3);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1GKS1HE05BR004691', 'Sentra', 2007, 77, 4);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1C3CDFCB8ED291546', 'MX-5', 2007, 97, 5);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1GTN1TEH4EZ295190', 'Cirrus', 1997, 88, 6);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1FTNF1E82AK636303', 'Navigator', 1998, 51, 7);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1G6KH5E62BU160598', 'Suburban 2500', 1996, 67, 8);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1GYS4JKJ4FR957576', 'Econoline E150', 1997, 96, 9);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('5UXKS4C51E0729633', 'Bronco', 1988, 37, 10);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('3D4PG9FV4AT364706', '626', 1993, 84, 11);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WAUMFAFR7FA772183', 'RX', 2009, 55, 12);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('5TDBW5G18ES557505', 'Civic', 2006, 33, 13);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1GD422CGXEF791752', 'Taurus', 2012, 9, 14);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WVGEF9BP7ED960530', '2500', 1993, 95, 15);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('2C3CDXJG3FH185014', 'Taurus', 2010, 56, 16);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1GYFK66878R278206', 'Express', 2008, 27, 17);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('2T1BURHE4FC775532', 'Dakota', 2010, 99, 18);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('3C4PDDAG0FT985756', 'Suburban 2500', 2007, 83, 19);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('3D73M3CL8BG356600', 'Navigator', 2003, 58, 20);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('3VW8S7AT1FM632295', '9-5', 2000, 47, 21);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1FTNX2A51AE369751', 'Passport', 2000, 26, 22);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WBALL5C56EJ485638', 'TT', 2004, 49, 23);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('JN1CV6AP2CM258288', 'Thunderbird', 1972, 66, 24);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('19UUA75578A962203', 'E350', 2005, 51, 25);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WA1DVAFE8AD537375', 'Skyhawk', 1989, 66, 26);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WBA3K5C54EK966372', 'Eclipse', 1997, 85, 27);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('JH4CU2F88DC843313', 'Ram 1500 Club', 2001, 44, 28);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WBALW3C57FC571235', 'Savana 1500', 1999, 47, 29);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1FTWX3B50AE236164', 'C-Class', 1995, 53, 30);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WDCGG0EB6DG273326', 'X3', 2005, 18, 31);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WVWGU7AN0BE001757', 'Concorde', 2001, 35, 32);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1G4HD572X6U918105', 'S4', 2011, 64, 33);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1G6YV34A545790867', 'Prius', 2009, 82, 34);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1G6AX5S38E0952954', 'Accord', 2000, 79, 35);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('3C4PDCAB3FT421050', 'F450', 2009, 78, 36);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('3GYFNFE35FS587082', 'Odyssey', 2006, 18, 37);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1G6AK5S36F0024009', 'CC', 2011, 86, 38);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('JN1CV6EL7FM318481', 'Prizm', 1996, 43, 39);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('2C3CDZAT0FH296242', 'Sebring', 2001, 81, 40);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('KNADH4A32B6990849', 'MKX', 2007, 20, 41);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('5N1AT2ML3EC721667', 'Firebird', 1987, 97, 42);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1C3CDZBG4EN567486', 'Tiburon', 2001, 44, 43);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('KMHDB8AE0BU421907', 'Savana 3500', 1996, 33, 44);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1G6DE8E54C0022841', 'Ram Van 3500', 2002, 58, 45);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('3VW507AT6FM161950', 'Legacy', 2006, 18, 46);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('3D7JV1EP6BG434834', 'Savana 3500', 2006, 26, 47);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WA1LMAFE7FD970093', '350Z', 2008, 53, 48);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1GYFK66858R651730', 'Veyron', 2011, 55, 49);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1G6DV5EP8C0875503', 'Mazda2', 2011, 30, 50);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WAUJT68EX4A780147', 'Suburban 2500', 2001, 18, 51);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('5TDDK4CC6AS382669', 'Sprinter', 2006, 46, 52);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1GD12ZCG5BF053672', 'Elantra', 1995, 39, 53);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WA1VYAFEXAD252463', 'S6', 2002, 26, 54);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('JN1CV6FEXEM442033', 'Routan', 2009, 64, 55);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1GYUCEEJ6AR504065', 'Astro', 1993, 95, 56);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('3D7JB1EP1AG658424', 'M', 2008, 74, 57);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1D4RD2GG8BC075883', 'Silverado Hybrid', 2006, 53, 58);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('KMHGC4DE6AU003865', 'Countryman', 2012, 82, 59);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WBABN53473J672087', 'Rodeo', 1993, 19, 60);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('JTHSE5BC2F5512173', 'Wrangler', 2008, 12, 61);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WAUAFAFH4BN615529', 'Capri', 1984, 54, 62);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('KMHHT6KD4DU020825', 'G5', 2008, 11, 63);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('3D73Y3HL4AG572701', 'R-Class', 2008, 87, 64);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WBA3G7C5XFK005208', 'Mirage', 1988, 63, 65);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1G4HP52K534176612', 'Regal', 2011, 42, 66);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1GYFK56239R830310', 'Forester', 2003, 52, 67);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('3VW4T7AT2EM426834', 'GTO', 1968, 44, 68);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('4T1BK3DB5CU119610', 'Tacoma', 1995, 57, 69);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('2G4GN5EX0F9225659', 'Thunderbird', 1986, 42, 70);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1HGCP2E71CA435135', 'Century', 2001, 80, 71);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('3C4PDCEG2CT156073', 'Compass', 2011, 96, 72);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WAUDF98E85A496653', 'Durango', 2001, 88, 73);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WA1WMBFE8CD139930', 'Savana 2500', 2002, 62, 74);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1G6AA5RA1D0233310', 'Passat', 2001, 34, 75);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1GD311CG5FF242504', 'Leaf', 2012, 38, 76);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WAUBF78EX7A732654', 'Astro', 1994, 23, 77);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('JTHBB1BA5B2797074', '3 Series', 1994, 80, 78);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('2GKALMEK9F6330883', 'Ridgeline', 2012, 94, 79);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1GTN1TEH9EZ513950', 'Tahoe', 2005, 23, 80);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1N4CL2AP2AC794467', 'Cooper', 2002, 72, 81);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1G6AK5SXXD0707749', 'C30', 2010, 67, 82);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('2G4WS52J351768070', 'XC70', 2010, 25, 83);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('5FRYD3H99GB160447', 'Armada', 2006, 67, 84);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1D4PU7GXXBW120812', 'TundraMax', 2012, 40, 85);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('JM1GJ1T60F1160500', 'Malibu', 2013, 73, 86);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('3VW4A7AT7CM617264', 'Sundance', 1993, 53, 87);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('2C3CCABG6EH870122', 'Montego', 2005, 83, 88);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1G6KD57Y89U205273', 'Outback', 2010, 53, 89);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WAUAVAFDXCN225617', 'SRX', 2008, 54, 90);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1G4HP52K83U212552', 'Patriot', 2009, 46, 91);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('5TFCM5F16AX435287', 'Torrent', 2008, 26, 92);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('3D4PH6FV4AT876851', 'LR3', 2007, 89, 93);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WAUEH98E86A135889', 'XF', 2011, 11, 94);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('SAJWA4HA4EM320421', 'Galant', 2008, 49, 95);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('5GADT13S272276160', 'QX56', 2009, 45, 96);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('WDBWK5EA1BF152550', '350Z', 2005, 41, 97);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('5J6TF2H52FL899744', 'Cutlass', 1997, 76, 98);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('1G4GF5G32CF227987', 'Town Car', 2003, 78, 99);
insert into Car_Data (Car_ID, Car_Model, Car_Model_Year, Car_Age, _row_) values ('SCFLDCFP1EG893111', 'Maxima', 2003, 94, 100);
/*Insert Driver Data*/
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (1, 'Lilli Cordrey', '652-583-3631', 'lcordrey0@china.com.cn', 81);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (2, 'Fran Hirsthouse', '771-501-4527', 'fhirsthouse1@hugedomains.com', 38);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (3, 'Ryann Hobbing', '513-742-7117', 'rhobbing2@netscape.com', 35);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (4, 'Emelda Cordingly', '512-875-7442', 'ecordingly3@state.tx.us', 90);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (5, 'Tailor McDonald', '745-612-2556', 'tmcdonald4@123-reg.co.uk', 59);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (6, 'Magda Topp', '201-379-0335', 'mtopp5@epa.gov', 40);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (7, 'Ludvig Gillanders', '743-567-0343', 'lgillanders6@zimbio.com', 42);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (8, 'Cherlyn Tallow', '645-456-1349', 'ctallow7@amazonaws.com', 81);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (9, 'Dmitri Garahan', '977-802-9919', 'dgarahan8@blogger.com', 63);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (10, 'Bibbye Audiss', '180-420-5038', 'baudiss9@mozilla.org', 23);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (11, 'Lenore Handyside', '569-190-2824', 'lhandysidea@goo.ne.jp', 60);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (12, 'Hayward Knewstub', '314-344-2175', 'hknewstubb@wiley.com', 26);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (13, 'Desiri Signorelli', '629-792-6385', 'dsignorellic@newyorker.com', 61);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (14, 'Edita Slide', '452-898-0204', 'eslided@newsvine.com', 83);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (15, 'Rupert Pascall', '549-776-0219', 'rpascalle@statcounter.com', 40);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (16, 'Guillaume Damiral', '475-497-5775', 'gdamiralf@cnet.com', 47);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (17, 'Abbe Peirazzi', '416-687-4566', 'apeirazzig@google.pl', 34);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (18, 'Scotty Chaffen', '620-497-4781', 'schaffenh@over-blog.com', 100);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (19, 'Luce Bail', '949-670-8045', 'lbaili@epa.gov', 77);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (20, 'Hortensia Springham', '890-113-1620', 'hspringhamj@upenn.edu', 91);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (21, 'Aile Scown', '568-885-0582', 'ascownk@thetimes.co.uk', 62);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (22, 'Blondie Threadkell', '608-560-5042', 'bthreadkelll@geocities.com', 70);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (23, 'Livia Brobeck', '308-229-3123', 'lbrobeckm@lulu.com', 60);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (24, 'Tallulah Beecham', '955-715-4671', 'tbeechamn@ucla.edu', 74);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (25, 'Corrine Harden', '558-216-3288', 'chardeno@un.org', 36);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (26, 'Lonny Kelberer', '329-121-6727', 'lkelbererp@soup.io', 33);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (27, 'Missy Adami', '314-416-3609', 'madamiq@ehow.com', 41);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (28, 'Lionello Shillom', '750-928-5269', 'lshillomr@dagondesign.com', 82);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (29, 'Minnnie Frisel', '352-721-9820', 'mfrisels@psu.edu', 54);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (30, 'Mildred Basillon', '437-656-1107', 'mbasillont@tmall.com', 41);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (31, 'Benedikt Emtage', '456-800-2073', 'bemtageu@sciencedirect.com', 100);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (32, 'Hettie Oxbe', '890-352-0181', 'hoxbev@bluehost.com', 73);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (33, 'Ezmeralda Porritt', '492-636-2096', 'eporrittw@a8.net', 88);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (34, 'Harper Lindores', '575-834-9611', 'hlindoresx@jimdo.com', 40);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (35, 'Waldo Blunsden', '216-844-2703', 'wblunsdeny@smugmug.com', 49);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (36, 'Husein Rabjohn', '779-484-4603', 'hrabjohnz@si.edu', 99);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (37, 'Johnette Jellico', '905-781-1625', 'jjellico10@earthlink.net', 34);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (38, 'Ronald Wildbore', '280-566-4058', 'rwildbore11@biblegateway.com', 29);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (39, 'Kellia Dayer', '357-827-7626', 'kdayer12@tumblr.com', 61);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (40, 'Ernst McAllan', '588-794-0919', 'emcallan13@cargocollective.com', 31);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (41, 'Gabriellia McMurray', '530-427-7524', 'gmcmurray14@bbc.co.uk', 86);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (42, 'Alfi Yate', '475-878-4826', 'ayate15@berkeley.edu', 26);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (43, 'Nannie Hayth', '881-566-5939', 'nhayth16@comcast.net', 31);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (44, 'Frank Bletso', '173-104-3907', 'fbletso17@hostgator.com', 99);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (45, 'Mamie Simmig', '639-260-9619', 'msimmig18@hc360.com', 43);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (46, 'Jose Gawne', '341-250-4783', 'jgawne19@delicious.com', 21);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (47, 'Garrot Bisley', '795-896-1432', 'gbisley1a@acquirethisname.com', 59);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (48, 'Jania Pearsall', '293-218-0313', 'jpearsall1b@wsj.com', 66);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (49, 'Hale Guitton', '478-597-8584', 'hguitton1c@bbb.org', 43);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (50, 'Ludvig Ivanikhin', '950-204-1411', 'livanikhin1d@t.co', 56);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (51, 'Mada Innerstone', '611-946-7613', 'minnerstone1e@is.gd', 58);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (52, 'Marilyn Pau', '167-878-5727', 'mpau1f@google.de', 20);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (53, 'Davidde Botcherby', '238-881-5867', 'dbotcherby1g@psu.edu', 23);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (54, 'Goddard Wickliffe', '571-652-3214', 'gwickliffe1h@yandex.ru', 33);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (55, 'Darby Rookledge', '429-332-1770', 'drookledge1i@paginegialle.it', 91);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (56, 'Yasmin Bicheno', '560-807-7137', 'ybicheno1j@privacy.gov.au', 28);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (57, 'Carlina Kingzeth', '505-444-3739', 'ckingzeth1k@google.es', 29);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (58, 'Anette Stooders', '367-907-3521', 'astooders1l@ezinearticles.com', 87);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (59, 'Liesa Bittlestone', '172-197-3614', 'lbittlestone1m@prweb.com', 29);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (60, 'Arlinda Ulyatt', '222-974-7940', 'aulyatt1n@google.fr', 46);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (61, 'Clemmy Gallop', '507-138-9878', 'cgallop1o@ucsd.edu', 88);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (62, 'Clevey Eddolls', '367-291-7062', 'ceddolls1p@w3.org', 38);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (63, 'Norma Ledger', '546-425-9273', 'nledger1q@de.vu', 70);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (64, 'Easter Redolfi', '937-501-9961', 'eredolfi1r@addthis.com', 86);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (65, 'Alfonso Hurdwell', '676-593-0878', 'ahurdwell1s@redcross.org', 59);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (66, 'Nydia Schusterl', '406-696-5613', 'nschusterl1t@imageshack.us', 88);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (67, 'Toni Braunton', '100-506-8172', 'tbraunton1u@gnu.org', 97);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (68, 'Lorinda Goshawke', '612-178-3603', 'lgoshawke1v@weibo.com', 60);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (69, 'Anthea Neathway', '969-956-9246', 'aneathway1w@so-net.ne.jp', 45);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (70, 'Murdock Lisamore', '503-851-3043', 'mlisamore1x@themeforest.net', 54);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (71, 'Sampson Tuckey', '987-895-4904', 'stuckey1y@wisc.edu', 48);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (72, 'Alicia Hailwood', '788-735-1483', 'ahailwood1z@yale.edu', 60);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (73, 'Ryan Banasevich', '174-168-8427', 'rbanasevich20@topsy.com', 55);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (74, 'Rosalyn Papis', '932-320-8565', 'rpapis21@fc2.com', 46);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (75, 'Kippie Byrde', '780-655-3635', 'kbyrde22@studiopress.com', 32);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (76, 'Margarette Borman', '743-785-2828', 'mborman23@amazon.co.uk', 98);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (77, 'Augie Radloff', '707-551-7106', 'aradloff24@bbc.co.uk', 43);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (78, 'Reese Bonifacio', '252-400-9806', 'rbonifacio25@aol.com', 62);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (79, 'Perkin Emmanuele', '338-594-0796', 'pemmanuele26@networksolutions.com', 46);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (80, 'Verine Bolino', '210-103-7480', 'vbolino27@reddit.com', 19);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (81, 'Sindee Hodge', '617-836-8402', 'shodge28@list-manage.com', 96);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (82, 'Toddy Gauden', '206-925-8067', 'tgauden29@census.gov', 59);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (83, 'Tobiah Goodbourn', '400-352-8614', 'tgoodbourn2a@studiopress.com', 28);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (84, 'Jackie Attewill', '355-605-5881', 'jattewill2b@bloglovin.com', 82);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (85, 'Alex Loffhead', '952-983-4512', 'aloffhead2c@sourceforge.net', 50);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (86, 'Trace Iggo', '461-919-4632', 'tiggo2d@360.cn', 44);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (87, 'Solly Coon', '505-257-1056', 'scoon2e@php.net', 25);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (88, 'Gerry Sollis', '294-102-3659', 'gsollis2f@desdev.cn', 23);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (89, 'Jenine Ritter', '221-625-0685', 'jritter2g@washingtonpost.com', 88);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (90, 'Jaye Ends', '155-374-0783', 'jends2h@studiopress.com', 96);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (91, 'Giorgi Barde', '570-607-8980', 'gbarde2i@prnewswire.com', 94);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (92, 'Beverie Siney', '230-298-3334', 'bsiney2j@fema.gov', 45);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (93, 'Elbertina Fugere', '518-326-9201', 'efugere2k@blogs.com', 88);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (94, 'Steward Sandbach', '765-486-9144', 'ssandbach2l@seesaa.net', 70);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (95, 'Delphine Davidek', '126-939-7269', 'ddavidek2m@t.co', 23);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (96, 'Fenelia Powlesland', '223-629-6198', 'fpowlesland2n@vimeo.com', 99);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (97, 'Enid Kaygill', '761-188-9713', 'ekaygill2o@flickr.com', 23);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (98, 'Cinda Batram', '970-811-9977', 'cbatram2p@trellian.com', 39);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (99, 'Judie Trout', '641-549-4502', 'jtrout2q@example.com', 32);
insert into Taxi_Driver_Data (Driver_ID, Driver_Full_Name, Driver_Phone_No, Driver_Email, Driver_Age) values (100, 'Stacee Kelk', '687-505-9690', 'skelk2r@liveinternet.ru', 79);


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO Car_Driver_Relation (Car_ID,Driver_ID) SELECT c.Car_ID, d.Driver_ID FROM Car_Data as c, Taxi_Driver_Data as d ORDER BY RANDOM() LIMIT 1000;