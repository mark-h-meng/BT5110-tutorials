/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */

/* There are thousands of movie websites on the internet. These websites all should have a database that keeps their users' information and their watching history, */
/* so that they can know which movie is more popular or keep records of the website acticity. Suppose I'm asked to build and maintain this database. */
/* I choose the entity set E1 to be users， storing the users' attributes including names, emails, gender, DOB, country and userid as the primary key. These columns should reflect the users' profile with the information that users provided during registration.*/
/* For entity set E2, I set it as movies, storing the movie names, types and publishing year. The combination of these three columns serves as the primary key, because these three columns should be sufficient to identify a movie. */
/* In the relation set, I keep the record of userid and the movie details (movie names, types and publishing year), retrieved by referencing E1 and E2. The combination of these four columns serves as the primary key. The code is written for PostgreSQL. */


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS users (
	first_name VARCHAR(128) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	email VARCHAR(64) UNIQUE NOT NULL,
	gender VARCHAR(2) NOT NULL,
	DOB DATE NOT NULL,
	country VARCHAR(64) NOT NULL,
	userid VARCHAR(64) PRIMARY KEY);

CREATE TABLE IF NOT EXISTS movies(
	name VARCHAR(128),
	type VARCHAR(128),
	year CHAR(4),
	PRIMARY KEY (name, type, year));

CREATE TABLE IF NOT EXISTS watch(
	userid VARCHAR(128) REFERENCES users(userid) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
	name VARCHAR(128),
	type VARCHAR(128),
	year CHAR(4),
	PRIMARY KEY (userid, name, type, year),
	FOREIGN KEY (name, type, year) REFERENCES movies(name, type, year) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Kip', 'Gregan', 'kgregan0@alexa.com', 'F', '11/15/2011', 'Canada', 'kgregan0');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Sibylle', 'Crowcroft', 'scrowcroft1@ustream.tv', 'F', '06/18/2013', 'China', 'scrowcroft1');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Elke', 'Kaye', 'ekaye2@tmall.com', 'F', '02/05/2003', 'Togo', 'ekaye2');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Cosmo', 'Danilenko', 'cdanilenko3@va.gov', 'M', '06/17/1975', 'Thailand', 'cdanilenko3');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Guilbert', 'Wasmuth', 'gwasmuth4@sbwire.com', 'M', '12/15/1993', 'Dominica', 'gwasmuth4');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Isadore', 'Blaxlande', 'iblaxlande5@friendfeed.com', 'M', '06/13/1994', 'Ethiopia', 'iblaxlande5');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Osbourn', 'Churchill', 'ochurchill6@dedecms.com', 'M', '01/03/1976', 'China', 'ochurchill6');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Fraze', 'Bellinger', 'fbellinger7@wp.com', 'M', '03/31/2004', 'France', 'fbellinger7');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Gae', 'Mixter', 'gmixter8@g.co', 'F', '05/26/1975', 'Philippines', 'gmixter8');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Dolores', 'Munt', 'dmunt9@mayoclinic.com', 'F', '08/31/1996', 'Argentina', 'dmunt9');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Antoni', 'Lawfull', 'alawfulla@irs.gov', 'M', '03/16/1998', 'China', 'alawfulla');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Cynde', 'Roache', 'croacheb@zdnet.com', 'F', '10/05/1991', 'Mexico', 'croacheb');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Minny', 'Betham', 'mbethamc@blogspot.com', 'F', '11/26/2006', 'Malaysia', 'mbethamc');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Marchall', 'Malpas', 'mmalpasd@narod.ru', 'M', '11/30/1971', 'United States', 'mmalpasd');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Ernestine', 'Lebbon', 'elebbone@youku.com', 'F', '10/27/1971', 'Kosovo', 'elebbone');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Luciana', 'Sapp', 'lsappf@acquirethisname.com', 'F', '11/30/1998', 'Thailand', 'lsappf');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Valry', 'Diggons', 'vdiggonsg@craigslist.org', 'F', '07/13/1991', 'Colombia', 'vdiggonsg');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Ambrosi', 'Spring', 'aspringh@bloglines.com', 'M', '10/03/2006', 'South Africa', 'aspringh');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Ab', 'Stanlick', 'astanlicki@jimdo.com', 'M', '05/09/1964', 'Pakistan', 'astanlicki');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Merwyn', 'Martignon', 'mmartignonj@dropbox.com', 'M', '06/15/1985', 'Russia', 'mmartignonj');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Veronika', 'Rawlison', 'vrawlisonk@pagesperso-orange.fr', 'F', '06/24/1974', 'Ireland', 'vrawlisonk');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Constanta', 'Bockmann', 'cbockmannl@canalblog.com', 'F', '05/20/1983', 'Croatia', 'cbockmannl');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Luise', 'Farquar', 'lfarquarm@opera.com', 'F', '07/04/2012', 'Czech Republic', 'lfarquarm');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Gunter', 'Martyn', 'gmartynn@nih.gov', 'M', '09/09/1984', 'Indonesia', 'gmartynn');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Randy', 'Thoresbie', 'rthoresbieo@live.com', 'M', '04/24/1994', 'Mongolia', 'rthoresbieo');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Cornie', 'Bulford', 'cbulfordp@yahoo.com', 'M', '01/11/1991', 'Indonesia', 'cbulfordp');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Trefor', 'Awin', 'tawinq@timesonline.co.uk', 'M', '10/19/1971', 'Russia', 'tawinq');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Marabel', 'Cluney', 'mcluneyr@blogtalkradio.com', 'F', '04/18/2002', 'Kenya', 'mcluneyr');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('William', 'Munns', 'wmunnss@yahoo.co.jp', 'M', '04/24/1968', 'Portugal', 'wmunnss');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Harriette', 'Illiston', 'hillistont@discovery.com', 'F', '05/21/2004', 'Croatia', 'hillistont');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Rosabella', 'Cooke', 'rcookeu@t-online.de', 'F', '03/29/2006', 'Indonesia', 'rcookeu');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Alexandro', 'Rice', 'aricev@sciencedaily.com', 'M', '09/22/2012', 'Indonesia', 'aricev');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Fidole', 'MacGovern', 'fmacgovernw@naver.com', 'M', '09/27/2012', 'China', 'fmacgovernw');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Kesley', 'Page', 'kpagex@canalblog.com', 'F', '01/08/1984', 'Portugal', 'kpagex');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Elbert', 'Sesser', 'esessery@ebay.co.uk', 'M', '09/26/2003', 'Zambia', 'esessery');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Colene', 'Brayn', 'cbraynz@dagondesign.com', 'F', '09/13/2008', 'China', 'cbraynz');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Siegfried', 'Cordrey', 'scordrey10@imageshack.us', 'M', '03/14/1973', 'Sweden', 'scordrey10');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Tadio', 'Bramstom', 'tbramstom11@gizmodo.com', 'M', '07/24/2012', 'Sudan', 'tbramstom11');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Stephana', 'Orleton', 'sorleton12@zdnet.com', 'F', '10/27/2011', 'Japan', 'sorleton12');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Yuri', 'Wanklin', 'ywanklin13@xrea.com', 'M', '06/17/2000', 'France', 'ywanklin13');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Iggie', 'Kilpin', 'ikilpin14@cnbc.com', 'M', '04/15/1962', 'Indonesia', 'ikilpin14');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Melany', 'Rothchild', 'mrothchild15@etsy.com', 'F', '10/06/1968', 'Russia', 'mrothchild15');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Gaby', 'Jevons', 'gjevons16@github.io', 'F', '01/09/1993', 'Philippines', 'gjevons16');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Ibrahim', 'Worssam', 'iworssam17@ezinearticles.com', 'M', '09/12/1983', 'Philippines', 'iworssam17');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Easter', 'Caldicot', 'ecaldicot18@ucsd.edu', 'F', '12/26/1971', 'China', 'ecaldicot18');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Lily', 'Massingberd', 'lmassingberd19@squarespace.com', 'F', '11/26/1996', 'Croatia', 'lmassingberd19');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Carny', 'Tarbin', 'ctarbin1a@ca.gov', 'M', '12/04/2012', 'Portugal', 'ctarbin1a');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Fina', 'Ballinger', 'fballinger1b@adobe.com', 'F', '01/17/1986', 'Poland', 'fballinger1b');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Trudy', 'Iacobassi', 'tiacobassi1c@gnu.org', 'F', '05/23/1984', 'Kosovo', 'tiacobassi1c');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Ulric', 'Brockington', 'ubrockington1d@myspace.com', 'M', '05/05/1977', 'Kazakhstan', 'ubrockington1d');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Chic', 'Denyer', 'cdenyer1e@shareasale.com', 'M', '06/12/1995', 'United States', 'cdenyer1e');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Ransell', 'Sparke', 'rsparke1f@amazon.co.uk', 'M', '07/10/1992', 'China', 'rsparke1f');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Sheelah', 'MacEveley', 'smaceveley1g@nasa.gov', 'F', '12/29/1964', 'Russia', 'smaceveley1g');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Taddeusz', 'Renn', 'trenn1h@seesaa.net', 'M', '05/26/1981', 'United States', 'trenn1h');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Richmound', 'Jantot', 'rjantot1i@oaic.gov.au', 'M', '04/19/1971', 'North Korea', 'rjantot1i');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Peggi', 'Amott', 'pamott1j@examiner.com', 'F', '06/12/2007', 'Indonesia', 'pamott1j');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Cristiano', 'Hayto', 'chayto1k@godaddy.com', 'M', '01/05/1996', 'France', 'chayto1k');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Marlow', 'Coultard', 'mcoultard1l@chronoengine.com', 'M', '06/14/2012', 'Czech Republic', 'mcoultard1l');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Elroy', 'Algate', 'ealgate1m@rediff.com', 'M', '02/25/1972', 'China', 'ealgate1m');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Row', 'Sturton', 'rsturton1n@bing.com', 'F', '07/26/1974', 'Ukraine', 'rsturton1n');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Thorvald', 'Mahood', 'tmahood1o@dropbox.com', 'M', '01/31/1964', 'China', 'tmahood1o');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Harri', 'Chesley', 'hchesley1p@dot.gov', 'F', '07/23/2002', 'Peru', 'hchesley1p');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Ripley', 'MacGinley', 'rmacginley1q@sina.com.cn', 'M', '08/29/1985', 'Poland', 'rmacginley1q');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Zorine', 'Dugood', 'zdugood1r@fema.gov', 'F', '07/03/2008', 'Indonesia', 'zdugood1r');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Irita', 'Cloney', 'icloney1s@narod.ru', 'F', '08/19/1994', 'Indonesia', 'icloney1s');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Essa', 'Piddlehinton', 'epiddlehinton1t@zimbio.com', 'F', '10/12/1963', 'China', 'epiddlehinton1t');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Bernardo', 'Sholl', 'bsholl1u@deliciousdays.com', 'M', '05/22/1970', 'China', 'bsholl1u');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Clea', 'Craker', 'ccraker1v@cpanel.net', 'F', '02/24/1995', 'Peru', 'ccraker1v');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Lemmie', 'Jammet', 'ljammet1w@cloudflare.com', 'M', '12/01/1996', 'China', 'ljammet1w');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Michele', 'Chitham', 'mchitham1x@ed.gov', 'F', '03/15/2012', 'Philippines', 'mchitham1x');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Martie', 'Spincks', 'mspincks1y@example.com', 'F', '01/26/1988', 'Colombia', 'mspincks1y');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Kelila', 'Haensel', 'khaensel1z@moonfruit.com', 'F', '03/13/2003', 'Cambodia', 'khaensel1z');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Orelee', 'Balentyne', 'obalentyne20@chron.com', 'F', '02/22/1986', 'Portugal', 'obalentyne20');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Lester', 'Creelman', 'lcreelman21@fda.gov', 'M', '03/12/1962', 'Croatia', 'lcreelman21');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Jessalyn', 'Allaker', 'jallaker22@stumbleupon.com', 'F', '12/14/1984', 'Taiwan', 'jallaker22');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Burton', 'Iggalden', 'biggalden23@nydailynews.com', 'M', '04/06/1983', 'China', 'biggalden23');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Rudyard', 'Norman', 'rnorman24@rakuten.co.jp', 'M', '10/09/1969', 'Bulgaria', 'rnorman24');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Darbie', 'Lothlorien', 'dlothlorien25@boston.com', 'F', '05/17/1979', 'Brazil', 'dlothlorien25');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Lynsey', 'Ridgers', 'lridgers26@woothemes.com', 'F', '01/13/1999', 'Morocco', 'lridgers26');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Pietro', 'Daw', 'pdaw27@bravesites.com', 'M', '10/09/1960', 'Estonia', 'pdaw27');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Alexander', 'Thow', 'athow28@rambler.ru', 'M', '03/06/1981', 'China', 'athow28');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Aviva', 'Matschek', 'amatschek29@webs.com', 'F', '07/01/2005', 'Italy', 'amatschek29');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Karine', 'Heggadon', 'kheggadon2a@php.net', 'F', '12/05/1984', 'Indonesia', 'kheggadon2a');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Felic', 'Vassano', 'fvassano2b@psu.edu', 'M', '12/02/2009', 'Indonesia', 'fvassano2b');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Cassius', 'Coom', 'ccoom2c@nationalgeographic.com', 'M', '08/29/1990', 'China', 'ccoom2c');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Kelcie', 'Davies', 'kdavies2d@surveymonkey.com', 'F', '02/04/2009', 'China', 'kdavies2d');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Myrtia', 'Wharrier', 'mwharrier2e@ox.ac.uk', 'F', '06/04/1998', 'Nigeria', 'mwharrier2e');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Dore', 'Gravatt', 'dgravatt2f@hc360.com', 'M', '06/30/2002', 'China', 'dgravatt2f');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Kakalina', 'Cliss', 'kcliss2g@quantcast.com', 'F', '05/13/2012', 'China', 'kcliss2g');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Idelle', 'Gilyott', 'igilyott2h@shutterfly.com', 'F', '03/07/1993', 'Philippines', 'igilyott2h');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Jakie', 'Tottman', 'jtottman2i@springer.com', 'M', '10/07/1986', 'Peru', 'jtottman2i');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Raimund', 'MacCracken', 'rmaccracken2j@dell.com', 'M', '10/18/1986', 'China', 'rmaccracken2j');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Teddie', 'Clipson', 'tclipson2k@businessinsider.com', 'M', '11/05/1973', 'China', 'tclipson2k');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Any', 'Whitchurch', 'awhitchurch2l@cnn.com', 'M', '08/09/1977', 'Croatia', 'awhitchurch2l');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Kassi', 'Fodden', 'kfodden2m@slashdot.org', 'F', '03/30/1978', 'Haiti', 'kfodden2m');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Carmelle', 'Billham', 'cbillham2n@tinypic.com', 'F', '04/21/1966', 'Greece', 'cbillham2n');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Philippa', 'McAirt', 'pmcairt2o@buzzfeed.com', 'F', '07/16/1988', 'China', 'pmcairt2o');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Hort', 'Sinisbury', 'hsinisbury2p@intel.com', 'M', '09/05/1970', 'Tunisia', 'hsinisbury2p');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Ashlie', 'Matis', 'amatis2q@adobe.com', 'F', '09/16/2011', 'Costa Rica', 'amatis2q');
insert into users (first_name, last_name, email, gender, DOB, country, userid) values ('Dorella', 'Armor', 'darmor2r@census.gov', 'F', '09/16/1998', 'China', 'darmor2r');



insert into movies (name, type, year) values ('Dudley Do-Right', 'Children|Comedy', 2006);
insert into movies (name, type, year) values ('Let''s Not Keep in Touch!', 'Comedy', 2007);
insert into movies (name, type, year) values ('Alien Nation: Millennium', 'Sci-Fi', 2006);
insert into movies (name, type, year) values ('Nothing But the Night', 'Crime|Horror|Mystery|Thriller', 2009);
insert into movies (name, type, year) values ('Arctic Blast', 'Sci-Fi|Thriller', 2002);
insert into movies (name, type, year) values ('Innocent, The', 'Drama', 2007);
insert into movies (name, type, year) values ('Volcano (Eldfjall)', 'Drama', 2004);
insert into movies (name, type, year) values ('Innocent Man, An', 'Crime|Drama', 1996);
insert into movies (name, type, year) values ('Thesis (Tesis)', 'Drama|Horror|Thriller', 1994);
insert into movies (name, type, year) values ('Extremely Loud and Incredibly Close', 'Drama', 1957);
insert into movies (name, type, year) values ('Dyatlov Pass Incident, The (Devil''s Pass)', 'Mystery|Thriller', 1984);
insert into movies (name, type, year) values ('Man for All Seasons, A', 'Drama', 2004);
insert into movies (name, type, year) values ('Jack-O', 'Horror', 2008);
insert into movies (name, type, year) values ('Chain of Command', 'Action|Thriller', 2004);
insert into movies (name, type, year) values ('Cold Storage', 'Thriller', 1967);
insert into movies (name, type, year) values ('Passenger Side', 'Comedy|Drama', 2002);
insert into movies (name, type, year) values ('In the Good Old Summertime', 'Musical', 2006);
insert into movies (name, type, year) values ('S.F.W.', 'Drama', 1987);
insert into movies (name, type, year) values ('Legend II, The (Fong Sai Yuk juk jaap)', 'Action|Adventure|Comedy', 2005);
insert into movies (name, type, year) values ('Antz', 'Adventure|Animation|Children', 1990);
insert into movies (name, type, year) values ('Rocky Balboa', 'Action|Drama', 2003);
insert into movies (name, type, year) values ('Swindle', 'Action|Comedy', 1999);
insert into movies (name, type, year) values ('Moving Out', 'Drama', 2006);
insert into movies (name, type, year) values ('Rasen', 'Drama|Fantasy|Horror|Mystery|Thriller', 2004);
insert into movies (name, type, year) values ('How the Grinch Stole Christmas!', 'Animation|Comedy|Fantasy|Musical', 2007);
insert into movies (name, type, year) values ('Casablanca Express', 'Action|War', 2009);
insert into movies (name, type, year) values ('Mr Hockey The Gordie Howe Story', 'Drama', 1964);
insert into movies (name, type, year) values ('Alien Nation: Body and Soul', 'Sci-Fi', 1989);
insert into movies (name, type, year) values ('Koko, a Talking Gorilla', 'Documentary', 2009);
insert into movies (name, type, year) values ('Jet Li''s Fearless (Huo Yuan Jia)', 'Action|Drama', 2006);
insert into movies (name, type, year) values ('Waterboy, The', 'Comedy', 2011);
insert into movies (name, type, year) values ('Bless the Beasts & Children', 'Drama', 2001);
insert into movies (name, type, year) values ('Delivery, The', 'Action|Adventure|Horror|Thriller', 1996);
insert into movies (name, type, year) values ('Da Vinci Code, The', 'Drama|Mystery|Thriller', 1983);
insert into movies (name, type, year) values ('Marley & Me', 'Comedy|Drama', 2012);
insert into movies (name, type, year) values ('Pacifier, The', 'Action|Comedy', 1986);
insert into movies (name, type, year) values ('The Death and Life of Bobby Z', 'Action|Crime|Drama|Thriller', 2005);
insert into movies (name, type, year) values ('Microcosmos (Microcosmos: Le peuple de l''herbe)', 'Documentary', 1993);
insert into movies (name, type, year) values ('Snowblind', 'Western', 2001);
insert into movies (name, type, year) values ('Classic, The (Klassikko)', 'Comedy|Drama', 2007);
insert into movies (name, type, year) values ('Temptress, The', 'Drama|Romance', 2006);
insert into movies (name, type, year) values ('Romeo Must Die', 'Action|Crime|Romance|Thriller', 1996);
insert into movies (name, type, year) values ('Toy Soldiers', 'Action|Drama', 2008);
insert into movies (name, type, year) values ('It Happened to Jane', 'Comedy', 1995);
insert into movies (name, type, year) values ('Maid, The (Nana, La)', 'Drama', 1989);
insert into movies (name, type, year) values ('Imagine Me & You', 'Comedy|Drama|Romance', 1997);
insert into movies (name, type, year) values ('Ed and His Dead Mother', 'Comedy|Horror', 1997);
insert into movies (name, type, year) values ('Story of G.I. Joe', 'War', 1998);
insert into movies (name, type, year) values ('Bug', 'Drama|Horror|Thriller', 2010);
insert into movies (name, type, year) values ('Korengal', 'Documentary|War', 1989);
insert into movies (name, type, year) values ('Blood Games ', 'Action|Thriller', 2007);
insert into movies (name, type, year) values ('Games', 'Thriller', 1990);
insert into movies (name, type, year) values ('Gabbeh', 'Drama', 1992);
insert into movies (name, type, year) values ('Wisegirls', 'Crime|Drama', 2008);
insert into movies (name, type, year) values ('A Pigeon Sat on a Branch Reflecting on Existence', 'Comedy|Drama', 2006);
insert into movies (name, type, year) values ('Promise Her Anything', 'Comedy|Drama', 1989);
insert into movies (name, type, year) values ('Tigger Movie, The', 'Animation|Children', 1997);
insert into movies (name, type, year) values ('Lovers on the Bridge, The (Amants du Pont-Neuf, Les)', 'Drama|Romance', 1997);
insert into movies (name, type, year) values ('Faster Pussycat! Kill! Kill!', 'Action|Crime|Drama', 1993);
insert into movies (name, type, year) values ('Fallen Art (Sztuka spadania)', 'Action|Animation|Comedy', 2008);
insert into movies (name, type, year) values ('Holidays by the Sea (Ni à vendre ni à louer)', 'Comedy', 2007);
insert into movies (name, type, year) values ('Pursuit of Happyness, The', 'Drama', 2010);
insert into movies (name, type, year) values ('Dark, The', 'Horror|Mystery|Thriller', 1997);
insert into movies (name, type, year) values ('Predators', 'Action|Sci-Fi|Thriller', 1996);
insert into movies (name, type, year) values ('Frenzy', 'Thriller', 1992);
insert into movies (name, type, year) values ('Fitzcarraldo', 'Adventure|Drama', 1995);
insert into movies (name, type, year) values ('Crimes of the Future', 'Comedy|Sci-Fi', 1998);
insert into movies (name, type, year) values ('Moonlight Murder', 'Mystery', 2001);
insert into movies (name, type, year) values ('Outer Space', 'Animation|Horror', 1994);
insert into movies (name, type, year) values ('Flight of the Conchords: A Texan Odyssey', 'Comedy', 2011);
insert into movies (name, type, year) values ('Scorpio Rising', '(no genres listed)', 1992);
insert into movies (name, type, year) values ('Unholy', 'Horror|Thriller', 1993);
insert into movies (name, type, year) values ('Sound Barrier, The', 'Drama', 1991);
insert into movies (name, type, year) values ('Broadway', 'Drama|Musical', 2012);
insert into movies (name, type, year) values ('Godzilla vs. Hedorah (Gojira tai Hedorâ) (Godzilla vs. The Smog Monster) ', 'Horror|Sci-Fi', 1999);
insert into movies (name, type, year) values ('Fugitive Pieces', 'Drama', 2001);
insert into movies (name, type, year) values ('Hoot', 'Children|Comedy', 1977);
insert into movies (name, type, year) values ('Doctor Who', 'Adventure|Sci-Fi', 2004);
insert into movies (name, type, year) values ('Guardian, The', 'Action|Adventure|Drama', 2002);
insert into movies (name, type, year) values ('Paul', 'Adventure|Comedy|Sci-Fi', 2007);
insert into movies (name, type, year) values ('En på miljonen', '(no genres listed)', 1999);
insert into movies (name, type, year) values ('Ping Pong Playa', 'Comedy', 1995);
insert into movies (name, type, year) values ('Carcasses', 'Documentary', 2012);
insert into movies (name, type, year) values ('Pretty Baby', 'Drama', 2005);
insert into movies (name, type, year) values ('Below Sea Level', 'Documentary', 2008);
insert into movies (name, type, year) values ('Answer This!', 'Comedy|Romance', 1998);
insert into movies (name, type, year) values ('Thérèse', 'Drama', 1989);
insert into movies (name, type, year) values ('Monkey''s Tale, A (Château des singes, Le)', 'Animation|Children', 2007);
insert into movies (name, type, year) values ('Planes, Trains & Automobiles', 'Comedy', 2006);
insert into movies (name, type, year) values ('Lemming', 'Drama|Mystery|Thriller', 1985);
insert into movies (name, type, year) values ('Ay, Carmela! (¡Ay, Carmela!)', 'Drama|War', 1998);
insert into movies (name, type, year) values ('Wilby Conspiracy, The', 'Thriller', 2010);
insert into movies (name, type, year) values ('Joan of Arc', 'Adventure|Drama', 2003);
insert into movies (name, type, year) values ('All These Women (För att inte tala om alla dessa kvinnor)', 'Comedy', 2001);
insert into movies (name, type, year) values ('Pride and Prejudice', 'Comedy|Drama|Romance', 1997);
insert into movies (name, type, year) values ('Barbershop 2: Back in Business', 'Comedy', 1988);
insert into movies (name, type, year) values ('Satan''s Sword (Daibosatsu tôge)', 'Action|Drama', 2001);
insert into movies (name, type, year) values ('Titus', 'Drama', 1996);
insert into movies (name, type, year) values ('Poolboy: Drowning Out the Fury', 'Comedy', 2007);
insert into movies (name, type, year) values ('Finding Fela!', 'Documentary', 1996);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO watch
SELECT u.userid, m.name, m.type, m.year
FROM users u, movies m
ORDER BY random()
LIMIT 1000;
