/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
It's a case of vaccination appointment.
E1 contains the information of permanent resproidents and long-term pass 
holders in Singapore. But the NRIC/FIN coding rule is different from real
world.
E2 contains the information of the three kinds of vaccines allowed in SG.
R means the relationship of who has appointed which vaccine of how many
doses.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/*E1*/
CREATE TABLE IF NOT EXISTS SG_people (
	NRICorFIN VARCHAR(50) PRIMARY KEY,
	first_name VARCHAR(50) NOT NULL,
	last_name VARCHAR(50) NOT NULL,
	email VARCHAR(50) UNIQUE,
	gender VARCHAR(50),
	age INT CHECK(age>=12 AND age<=60),
	mobile VARCHAR(50) UNIQUE NOT NULL
);


/*E2*/
CREATE TABLE IF NOT EXISTS vaccine (
	proid INT UNIQUE,
	vaccine_name VARCHAR(32) NOT NULL CHECK(vaccine_name='Pfizer&BioNTech' OR vaccine_name = 'Moderna' OR vaccine_name = 'Sinovac'), 
	appoint_date DATE NOT NULL,
	dose INT NOT NULL CHECK(dose=1 OR dose=2),
	PRIMARY KEY(vaccine_name, appoint_date)
);

/*R*/
CREATE TABLE IF NOT EXISTS appointed (
	NRICorFIN VARCHAR(50) REFERENCES SG_people(NRICorFIN)ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
	vaccine_name VARCHAR(32),
	appoint_date DATE,
	PRIMARY KEY (NRICorFIN, vaccine_name, appoint_date),
	FOREIGN KEY (vaccine_name, appoint_date) REFERENCES vaccine(vaccine_name, appoint_date) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED
);


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/*E1*/
DELETE FROM SG_people;
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('Z1450852W', 'Eduard', 'Benoey', 'ebenoey0@state.gov', 'Male', 57, '802-141-0558');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('W6343813I', 'Gabi', 'Dallow', 'gdallow1@sbwire.com', 'Female', 20, '688-611-4772');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('O3549495M', 'Sheffield', 'Tregproiddo', 'stregproiddo2@usnews.com', 'Male', 13, '650-576-6564');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('I1195980Q', 'Andrea', 'Jenoure', 'ajenoure3@japanpost.jp', 'Male', 25, '313-900-8771');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('P7127034T', 'Kristan', 'Jeffels', 'kjeffels4@wix.com', 'Female', 13, '182-512-6066');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('H3704873C', 'Teddy', 'Verman', 'tverman5@over-blog.com', 'Female', 57, '413-260-9868');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('Z1537272F', 'Worth', 'Avraham', 'wavraham6@tuttocitta.it', 'Male', 22, '221-943-9414');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('C4237165W', 'Delmor', 'Ruscoe', 'druscoe7@mashable.com', 'Female', 60, '973-576-1651');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('N1811435A', 'Elsey', 'Hamley', null, 'Male', 36, '749-503-8616');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('S7503520R', 'Kristy', 'Cristea', 'kcristea9@japanpost.jp', 'Female', 54, '509-936-0560');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('C2601224L', 'Kamilah', 'Larwell', 'klarwella@163.com', 'Female', 32, '199-256-5542');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('C2189332I', 'Fernande', 'McNickle', 'fmcnickleb@spiegel.de', 'Female', 49, '912-817-1887');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('S5751248W', 'Trudie', 'Swaine', 'tswainec@simplemachines.org', 'Female', 33, '667-575-3410');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('B5468028L', 'James', 'Etty', 'jettyd@altervista.org', 'Male', 55, '870-869-8911');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('M1163602F', 'Ruy', 'Prosch', 'rprosche@pagesperso-orange.fr', 'Female', 15, '417-808-9492');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('Q0189664Y', 'Gretchen', 'Skipperbottom', 'gskipperbottomf@ocn.ne.jp', 'Male', 41, '915-570-1453');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('X9427761Q', 'Gris', 'Amthor', 'gamthorg@bandcamp.com', 'Female', 25, '644-420-0532');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('N1243164D', 'Nicolai', 'Corstorphine', 'ncorstorphineh@myspace.com', 'Male', 47, '969-260-0548');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('S8583041R', 'Clari', 'Damrel', 'cdamreli@samsung.com', 'Male', 44, '923-644-2745');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('N7143844U', 'Constantin', 'Ismay', 'cismayj@addtoany.com', 'Female', 36, '350-319-1945');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('D2216759L', 'proidalina', 'Shovlar', 'ishovlark@oaic.gov.au', 'Male', 30, '272-680-5240');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('H7366679X', 'Joni', 'Bruni', 'jbrunil@miitbeian.gov.cn', 'Male', 46, '626-365-3251');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('E9205302W', 'Cloris', 'Oliver', 'coliverm@techcrunch.com', 'Male', 45, '362-267-9627');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('E2286504V', 'Fleming', 'Maile', 'fmailen@vinaora.com', 'Female', 44, '956-601-9165');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('C5836916L', 'Bernie', 'Scones', 'bsconeso@aol.com', 'Male', 46, '450-859-8155');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('E6739089C', 'Sallie', 'Standingford', null, 'Male', 46, '700-377-4983');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('K7634792L', 'Ardeen', 'Dearnaly', 'adearnalyq@hhs.gov', 'Female', 35, '761-476-3958');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('A0335254O', 'Friedrick', 'Saunderson', 'fsaundersonr@rakuten.co.jp', 'Female', 15, '961-795-7401');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('F4707542F', 'Jobey', 'McAlester', 'jmcalesters@cocolog-nifty.com', 'Female', 60, '433-611-8614');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('W5483756P', 'Florance', 'Credland', 'fcredlandt@about.com', 'Female', 29, '472-421-9044');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('J7634390C', 'Mike', 'Eake', 'meakeu@stumbleupon.com', 'Female', 16, '119-500-1487');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('I6873433P', 'Fredrick', 'Fargie', 'ffargiev@google.com.br', 'Female', 38, '111-220-2499');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('I3780369H', 'Eddy', 'Shattock', 'eshattockw@opera.com', 'Male', 18, '737-566-6110');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('B0656469N', 'Leo', 'Piotr', 'lpiotrx@hc360.com', 'Male', 28, '468-405-8096');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('F0881055G', 'Earvin', 'Reeme', 'ereemey@cnet.com', 'Male', 29, '146-712-9207');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('R7377552E', 'Laurene', 'Iseton', 'lisetonz@epa.gov', 'Female', 51, '268-162-5231');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('D4420521U', 'Maximilian', 'McIlherran', 'mmcilherran10@house.gov', 'Male', 12, '245-871-8661');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('O5612212C', 'Madonna', 'Nowland', 'mnowland11@zimbio.com', 'Female', 40, '657-910-6335');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('Y5904251T', 'Rosabelle', 'Thrproidgould', 'rthrproidgould12@kickstarter.com', 'Female', 14, '429-678-4670');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('Q0777163A', 'Kaleena', 'Janus', 'kjanus13@vimeo.com', 'Female', 41, '133-811-3386');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('W7294220L', 'Sheelah', 'Huot', 'shuot14@hhs.gov', 'Male', 33, '213-414-5229');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('C0082885U', 'Heloise', 'Wilding', 'hwilding15@reuters.com', 'Female', 21, '480-689-6411');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('B0454491R', 'Dulcia', 'Marklow', 'dmarklow16@state.tx.us', 'Female', 47, '940-236-8520');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('A3879939G', 'Udall', 'Melsom', 'umelsom17@deviantart.com', 'Male', 41, '130-237-5964');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('W7557952S', 'Tammie', 'Libbie', 'tlibbie18@sina.com.cn', 'Male', 51, '860-288-2318');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('G5339613Q', 'Inga', 'Killingbeck', 'ikillingbeck19@army.mil', 'Male', 56, '217-750-1577');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('E7065354L', 'Kendrick', 'Whickman', 'kwhickman1a@hubpages.com', 'Male', 22, '748-276-8260');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('T2745159O', 'Evangelin', 'Rhyme', 'erhyme1b@gov.uk', 'Male', 21, '990-371-0797');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('P4301335N', 'Arlen', 'Lindro', null, 'Female', 46, '519-881-8837');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('M3905720Z', 'Jedd', 'Bingell', 'jbingell1d@dedecms.com', 'Male', 41, '728-130-0130');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('I1843254C', 'Steffie', 'Handling', 'shandling1e@diigo.com', 'Female', 59, '384-127-1795');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('Z9018509R', 'Barclay', 'Elt', 'belt1f@quantcast.com', 'Male', 60, '831-751-6296');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('Z1159911S', 'Clayborn', 'Burkman', 'cburkman1g@chicagotribune.com', 'Female', 32, '115-826-8661');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('G3860407D', 'Jeanine', 'Giffin', 'jgiffin1h@list-manage.com', 'Female', 29, '383-896-0417');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('T5523724P', 'Aubrette', 'Jankin', 'ajankin1i@purevolume.com', 'Female', 17, '304-771-1018');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('Z3608991M', 'Rickard', 'Shortell', 'rshortell1j@mashable.com', 'Female', 25, '530-930-4083');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('Y2110364P', 'Gianina', 'Cuardall', 'gcuardall1k@hexun.com', 'Female', 40, '654-974-6521');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('I7086413Y', 'Lucie', 'Attock', 'lattock1l@macromedia.com', 'Male', 17, '558-286-2789');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('G9864412L', 'Retha', 'McCloud', 'rmccloud1m@slproideshare.net', 'Male', 29, '285-737-4241');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('W9175171L', 'Caressa', 'Camous', 'ccamous1n@hud.gov', 'Male', 46, '496-412-6313');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('I4338072W', 'Zilvia', 'Bunstone', 'zbunstone1o@go.com', 'Female', 37, '727-965-9964');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('A6811139A', 'Sisely', 'Keeting', 'skeeting1p@freewebs.com', 'Female', 35, '486-109-2690');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('V4249974J', 'Zoe', 'Kitchensproide', 'zkitchensproide1q@cisco.com', 'Female', 31, '435-492-0814');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('K2151854D', 'Jenn', 'Cowdery', 'jcowdery1r@angelfire.com', 'Female', 59, '292-317-7970');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('S7977257D', 'Lorianna', 'O''Fearguise', 'lofearguise1s@businesswire.com', 'Female', 52, '698-901-6730');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('D7450069W', 'Loretta', 'Paffley', 'lpaffley1t@go.com', 'Male', 51, '865-408-2008');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('W6083146D', 'Lazarus', 'Chatteris', 'lchatteris1u@newsvine.com', 'Male', 37, '834-244-6034');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('M4001668Q', 'Ravi', 'Dunniom', 'rdunniom1v@omniture.com', 'Male', 17, '754-162-0307');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('H5453538U', 'Hymie', 'Whyard', 'hwhyard1w@google.ca', 'Female', 22, '217-564-4372');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('V3833365D', 'Daniela', 'Kestle', 'dkestle1x@bloglines.com', 'Female', 16, '955-168-2041');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('V5761410T', 'Lulu', 'Redhouse', 'lredhouse1y@infoseek.co.jp', 'Male', 42, '751-817-5685');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('R9154050C', 'Shanon', 'Wrassell', 'swrassell1z@paypal.com', 'Male', 28, '604-998-5748');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('Q9108366P', 'Marabel', 'Brahams', 'mbrahams20@rediff.com', 'Male', 39, '141-522-5205');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('F7216882E', 'Chrystal', 'Gorvette', 'cgorvette21@reddit.com', 'Female', 23, '862-160-8930');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('A7926365J', 'Palm', 'Gasken', 'pgasken22@nytimes.com', 'Male', 47, '903-180-4353');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('P7599652T', 'Olly', 'Ferreo', 'oferreo23@tumblr.com', 'Male', 16, '657-107-2807');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('V7836448M', 'Barby', 'Malster', 'bmalster24@hatena.ne.jp', 'Male', 12, '619-733-6143');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('G0385544U', 'Mickie', 'Reavell', 'mreavell25@cdbaby.com', 'Female', 33, '829-703-4502');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('R4100446R', 'Gerek', 'Stearnes', 'gstearnes26@google.com', 'Female', 12, '573-346-8399');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('V8174799Q', 'Renae', 'Ickovici', 'rickovici27@goo.gl', 'Female', 16, '880-830-4979');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('G1104907D', 'Dillie', 'Pharo', 'dpharo28@loc.gov', 'Female', 41, '181-601-9263');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('L9208705Y', 'Nedi', 'Mauchline', 'nmauchline29@4shared.com', 'Male', 59, '625-454-8268');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('E9678166H', 'Hewie', 'Bosward', null, 'Female', 38, '333-553-5037');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('A1085894L', 'Berke', 'Bilsborrow', 'bbilsborrow2b@i2i.jp', 'Female', 32, '658-660-7673');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('C1708588A', 'Bryn', 'Rayburn', 'brayburn2c@dailymotion.com', 'Female', 45, '499-156-1231');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('M0856190C', 'Bill', 'Fowley', 'bfowley2d@flavors.me', 'Male', 23, '608-240-5010');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('Z6996248H', 'Krishnah', 'Nock', 'knock2e@de.vu', 'Male', 38, '225-455-1039');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('W3961802M', 'Cissiee', 'Saveall', 'csaveall2f@friendfeed.com', 'Male', 57, '489-998-8193');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('X3107761L', 'Merrel', 'Escalero', null, 'Male', 53, '739-317-4342');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('B4205521M', 'Curtis', 'Andrioli', 'candrioli2h@sogou.com', 'Female', 13, '596-960-1838');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('X5072456O', 'Lissy', 'Sattin', 'lsattin2i@china.com.cn', 'Female', 48, '242-508-8296');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('M4159528C', 'Cynthie', 'Adne', 'cadne2j@miitbeian.gov.cn', 'Female', 58, '212-131-6192');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('J6744211I', 'Davproide', 'Scrannage', 'dscrannage2k@disqus.com', 'Male', 14, '847-755-1860');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('L5379878W', 'Silvano', 'Whisby', 'swhisby2l@sogou.com', 'Female', 57, '964-751-0764');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('C5656490S', 'Alyosha', 'Brownlea', 'abrownlea2m@github.io', 'Female', 20, '965-120-8534');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('M4767877T', 'Cinda', 'Hovell', 'chovell2n@w3.org', 'Male', 44, '345-126-4075');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('J8562605J', 'Sydney', 'Gatfield', 'sgatfield2o@spiegel.de', 'Male', 46, '761-891-8794');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('Z0637936W', 'Essy', 'Flori', 'eflori2p@youtube.com', 'Male', 55, '174-965-7268');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('E2377730Q', 'Alexia', 'De Lascy', 'adelascy2q@quantcast.com', 'Female', 27, '471-464-3798');
insert into SG_people (NRICorFIN, first_name, last_name, email, gender, age, mobile) values ('A4695274X', 'Katinka', 'Biaggioni', 'kbiaggioni2r@istockphoto.com', 'Female', 59, '838-254-0154');

SELECT * FROM SG_people;

/*E2*/
DELETE FROM vaccine;
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (1, 'Pfizer&BioNTech', '2021-05-20', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (2, 'Pfizer&BioNTech', '2021-07-23', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (3, 'Moderna', '2021-06-05', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (4, 'Sinovac', '2021-06-01', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (5, 'Pfizer&BioNTech', '2021-06-20', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (6, 'Sinovac', '2021-07-18', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (7, 'Sinovac', '2021-05-31', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (8, 'Moderna', '2021-07-23', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (9, 'Moderna', '2021-07-08', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (10, 'Pfizer&BioNTech', '2021-06-15', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (11, 'Sinovac', '2021-05-16', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (12, 'Moderna', '2021-06-29', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (13, 'Sinovac', '2021-07-08', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (14, 'Pfizer&BioNTech', '2021-07-16', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (15, 'Sinovac', '2021-08-20', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (16, 'Moderna', '2021-08-03', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (17, 'Pfizer&BioNTech', '2021-05-26', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (18, 'Sinovac', '2021-05-24', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (19, 'Pfizer&BioNTech', '2021-07-01', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (20, 'Pfizer&BioNTech', '2021-07-10', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (21, 'Sinovac', '2021-08-03', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (22, 'Pfizer&BioNTech', '2021-05-14', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (23, 'Pfizer&BioNTech', '2021-07-02', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (24, 'Sinovac', '2021-05-26', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (25, 'Pfizer&BioNTech', '2021-07-18', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (26, 'Sinovac', '2021-07-05', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (27, 'Moderna', '2021-06-30', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (28, 'Moderna', '2021-06-06', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (29, 'Sinovac', '2021-05-17', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (30, 'Sinovac', '2021-06-30', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (31, 'Pfizer&BioNTech', '2021-05-25', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (32, 'Pfizer&BioNTech', '2021-06-11', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (33, 'Sinovac', '2021-07-25', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (34, 'Pfizer&BioNTech', '2021-07-04', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (35, 'Pfizer&BioNTech', '2021-05-07', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (36, 'Moderna', '2021-05-03', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (37, 'Sinovac', '2021-07-24', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (38, 'Pfizer&BioNTech', '2021-07-13', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (39, 'Sinovac', '2021-06-27', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (40, 'Moderna', '2021-06-28', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (41, 'Moderna', '2021-05-27', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (42, 'Pfizer&BioNTech', '2021-07-05', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (43, 'Pfizer&BioNTech', '2021-05-11', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (44, 'Moderna', '2021-08-06', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (45, 'Pfizer&BioNTech', '2021-06-07', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (46, 'Moderna', '2021-08-23', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (47, 'Pfizer&BioNTech', '2021-08-01', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (48, 'Moderna', '2021-05-04', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (49, 'Pfizer&BioNTech', '2021-08-23', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (50, 'Sinovac', '2021-08-17', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (51, 'Sinovac', '2021-05-25', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (52, 'Moderna', '2021-05-07', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (53, 'Pfizer&BioNTech', '2021-06-27', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (54, 'Pfizer&BioNTech', '2021-06-14', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (55, 'Pfizer&BioNTech', '2021-06-12', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (56, 'Pfizer&BioNTech', '2021-08-04', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (57, 'Sinovac', '2021-07-19', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (58, 'Pfizer&BioNTech', '2021-07-11', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (59, 'Pfizer&BioNTech', '2021-06-21', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (60, 'Sinovac', '2021-05-06', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (61, 'Moderna', '2021-07-12', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (62, 'Sinovac', '2021-05-27', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (63, 'Pfizer&BioNTech', '2021-05-24', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (64, 'Moderna', '2021-08-10', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (65, 'Sinovac', '2021-05-18', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (66, 'Pfizer&BioNTech', '2021-07-28', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (67, 'Moderna', '2021-07-22', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (68, 'Pfizer&BioNTech', '2021-05-27', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (69, 'Pfizer&BioNTech', '2021-08-10', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (70, 'Sinovac', '2021-07-15', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (71, 'Moderna', '2021-05-13', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (72, 'Sinovac', '2021-06-28', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (73, 'Sinovac', '2021-05-30', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (74, 'Pfizer&BioNTech', '2021-08-03', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (75, 'Pfizer&BioNTech', '2021-07-03', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (76, 'Moderna', '2021-06-26', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (77, 'Sinovac', '2021-08-01', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (78, 'Sinovac', '2021-06-04', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (79, 'Pfizer&BioNTech', '2021-06-03', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (80, 'Sinovac', '2021-05-21', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (81, 'Sinovac', '2021-07-11', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (82, 'Sinovac', '2021-05-29', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (83, 'Sinovac', '2021-08-18', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (84, 'Moderna', '2021-05-26', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (85, 'Sinovac', '2021-06-29', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (86, 'Sinovac', '2021-06-26', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (87, 'Pfizer&BioNTech', '2021-05-13', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (88, 'Sinovac', '2021-08-11', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (89, 'Sinovac', '2021-08-12', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (90, 'Pfizer&BioNTech', '2021-07-07', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (91, 'Moderna', '2021-07-05', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (92, 'Pfizer&BioNTech', '2021-06-17', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (93, 'Moderna', '2021-08-05', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (94, 'Moderna', '2021-08-27', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (95, 'Moderna', '2021-08-09', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (96, 'Pfizer&BioNTech', '2021-08-16', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (97, 'Moderna', '2021-05-01', 2);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (98, 'Pfizer&BioNTech', '2021-08-17', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (99, 'Pfizer&BioNTech', '2021-08-21', 1);
insert into vaccine (proid, vaccine_name, appoint_date, dose) values (100, 'Sinovac', '2021-08-07', 2);

SELECT * FROM vaccine;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DELETE FROM appointed;
INSERT INTO appointed(NRICorFIN, vaccine_name, appoint_date) SELECT NRICorFIN, vaccine_name, appoint_date FROM SG_people, vaccine ORDER BY RANDOM();
SELECT * FROM appointed;
/*Sorry I failed to limit the row around 1000 ;( */