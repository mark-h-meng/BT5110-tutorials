/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */
/* A0231922M */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/*
Senario: we are interested to know animals' ecological distribution, 
2 tables are created, animals and thier habitat/locations respectively;

A relationship "lives in" is used to map specific animal and the city it is in. 
E1 is table "animals", with their common name, sicentific name(primary key), 
estimated life span, and wether or not a carnivore.
E2 is table "locations", with country, country code, and city name(primary key).
R is the relationship "lives_in", with 2 foreign keys 
animals(scientific name) and locations(city name).
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */                                                                
/************************************************************************/


CREATE TABLE IF NOT EXISTS animals (
com_name VARCHAR(64) NOT NULL,
sci_name VARCHAR(64) PRIMARY KEY,
life_span NUMERIC NOT NULL,
carnivore BOOL NOT NULL,
CHECK (life_span > 0)
); 

CREATE TABLE IF NOT EXISTS locations (
country VARCHAR(64) NOT NULL,
code CHAR(2) NOT NULL,
city VARCHAR(32) PRIMARY KEY
); 

CREATE TABLE IF NOT EXISTS Lives_in (
animal_name VARCHAR(64) REFERENCES animals(sci_name),
place varchar(64) REFERENCES locations(city),
PRIMARY KEY(animal_name, place)
); 

/*DELETE FROM lives_in;
DELETE FROM animals;
DELETE FROM locations;*/




/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
insert into animals (com_name, sci_name, carnivore, life_span) values ('Mississippi alligator', 'Alligator mississippiensis', false, 18.56);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Snake-necked turtle', 'Chelodina longicollis', true, 25.31);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Lesser flamingo', 'Phoeniconaias minor', false, 20.99);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Crimson-breasted shrike', 'Laniaurius atrococcineus', true, 12.6);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Heron, striated', 'Butorides striatus', true, 32.28);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Glider, sugar', 'Petaurus breviceps', false, 48.93);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Cape wild cat', 'Felis libyca', true, 9.3);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Vulture, white-headed', 'Aegypius occipitalis', true, 7.27);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Hyena, spotted', 'Crocuta crocuta', false, 40.86);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Mexican beaded lizard', 'Heloderma horridum', false, 48.84);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Fox, pampa gray', 'Pseudalopex gymnocercus', false, 13.47);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Western pygmy possum', 'Cercatetus concinnus', true, 40.1);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Chipmunk, least', 'Eutamias minimus', true, 31.63);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Seal, southern elephant', 'Mirounga leonina', true, 45.72);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Otter, north american river', 'Lutra canadensis', false, 17.57);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Platypus', 'Ornithorhynchus anatinus', true, 35.79);
insert into animals (com_name, sci_name, carnivore, life_span) values ('African pied wagtail', 'Motacilla aguimp', false, 31.99);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Eastern grey kangaroo', 'Macropus giganteus', true, 28.13);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Capuchin, weeper', 'Cebus nigrivittatus', false, 19.72);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Great horned owl', 'Bubo virginianus', false, 10.87);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Skink, african', 'Mabuya spilogaster', false, 42.59);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Cockatoo, red-breasted', 'Eolophus roseicapillus', true, 25.89);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Rock dove', 'Columba livia', false, 39.47);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Red howler monkey', 'Alouatta seniculus', true, 15.41);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Kiskadee, great', 'Pitangus sulphuratus', false, 45.56);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Squirrel, thirteen-lined', 'Spermophilus tridecemlineatus', true, 48.22);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Hornbill, red-billed', 'Tockus erythrorhyncus', false, 13.66);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Pine squirrel', 'Tamiasciurus hudsonicus', true, 26.23);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Tern, arctic', 'Sterna paradisaea', false, 28.88);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Colobus, black and white', 'Colobus guerza', true, 27.33);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Capuchin, white-fronted', 'Cebus albifrons', true, 37.6);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Admiral, indian red', 'Vanessa indica', false, 45.61);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Sheep, american bighorn', 'Ovis canadensis', false, 44.55);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Rhinoceros, black', 'Diceros bicornis', true, 21.02);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Crested bunting', 'Melophus lathami', false, 42.24);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Lion, african', 'Panthera leo', false, 25.3);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Genoveva', 'Junonia genoveua', false, 2.58);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Eastern indigo snake', 'Drymarchon corias couperi', true, 17.19);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Marine iguana', 'Amblyrhynchus cristatus', false, 4.8);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Deer, swamp', 'Cervus duvauceli', true, 21.84);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Arctic hare', 'Lepus arcticus', false, 45.29);
insert into animals (com_name, sci_name, carnivore, life_span) values ('White-bellied sea eagle', 'Haliaetus leucogaster', true, 42.39);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Peregrine falcon', 'Falco peregrinus', false, 2.25);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Southern lapwing', 'Vanellus chilensis', false, 41.93);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Common seal', 'Phoca vitulina', true, 33.84);
insert into animals (com_name, sci_name, carnivore, life_span) values ('European spoonbill', 'Platalea leucordia', false, 1.75);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Pied kingfisher', 'Ceryle rudis', true, 14.5);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Ox, musk', 'Ovibos moschatus', true, 46.83);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Hornbill, yellow-billed', 'Tockus flavirostris', true, 20.46);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Gelada baboon', 'Theropithecus gelada', true, 21.82);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Stanley bustard', 'Neotis denhami', false, 14.25);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Civet, small-toothed palm', 'Arctogalidia trivirgata', true, 15.68);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Peccary, white-lipped', 'Tayassu pecari', false, 11.87);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Cape fox', 'Vulpes chama', true, 10.75);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Water legaan', 'Varanus salvator', true, 32.47);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Egyptian cobra', 'Naja haje', true, 43.46);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Cattle egret', 'Bubulcus ibis', true, 45.46);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Kalahari scrub robin', 'Certotrichas paena', true, 45.58);
insert into animals (com_name, sci_name, carnivore, life_span) values ('White-rumped vulture', 'Gyps bengalensis', false, 43.7);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Grouse, sage', 'Centrocercus urophasianus', true, 25.12);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Goose, canada', 'Branta canadensis', true, 14.72);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Bear, polar', 'Ursus maritimus', true, 45.65);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Asiatic jackal', 'Canis aureus', false, 47.12);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Heron, yellow-crowned night', 'Nyctanassa violacea', true, 2.29);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Grenadier, purple', 'Uraeginthus granatina', true, 27.19);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Sparrow, house', 'Passer domesticus', false, 21.13);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Tree porcupine', 'Coendou prehensilis', true, 24.14);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Baboon, savanna', 'Papio cynocephalus', true, 16.24);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Magellanic penguin', 'Spheniscus magellanicus', true, 13.15);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Cat, civet', 'Bassariscus astutus', false, 37.53);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Python, carpet', 'Morelia spilotes variegata', false, 42.62);
insert into animals (com_name, sci_name, carnivore, life_span) values ('European shelduck', 'Tadorna tadorna', false, 47.85);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Rhinoceros, white', 'Ceratotherium simum', false, 17.43);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Oryx, beisa', 'Oryx gazella', true, 22.7);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Praying mantis (unidentified)', 'unavailable', true, 11.7);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Gecko, barking', 'Phylurus milli', true, 33.08);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Black-throated butcher bird', 'Cracticus nigroagularis', true, 37.43);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Legaan, Monitor (unidentified)', 'Varanus sp.', false, 34.63);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Owl, snowy', 'Nyctea scandiaca', true, 37.88);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Sloth, pale-throated three-toed', 'Bradypus tridactylus', true, 48.11);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Beaver, north american', 'Castor canadensis', false, 43.41);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Penguin, little blue', 'Eudyptula minor', true, 37.9);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Sunbird, lesser double-collared', 'Nectarinia chalybea', false, 14.92);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Helmeted guinea fowl', 'Numida meleagris', true, 23.83);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Turkey, wild', 'Meleagris gallopavo', true, 12.4);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Curlew, black', 'Haematopus ater', false, 12.44);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Robin, white-throated', 'Irania gutteralis', true, 45.96);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Asian water buffalo', 'Bubalus arnee', true, 33.71);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Common nighthawk', 'Chordeiles minor', false, 13.14);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Bulbul, african red-eyed', 'Pycnonotus nigricans', true, 46.86);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Bare-faced go away bird', 'Lorythaixoides concolor', true, 33.96);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Black swan', 'Cygnus atratus', false, 28.69);
insert into animals (com_name, sci_name, carnivore, life_span) values ('South American sea lion', 'Otaria flavescens', false, 36.62);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Great skua', 'Catharacta skua', false, 28.97);
insert into animals (com_name, sci_name, carnivore, life_span) values ('American buffalo', 'Bison bison', true, 6.91);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Verreaux''s sifaka', 'Propithecus verreauxi', true, 49.47);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Brown capuchin', 'Cebus apella', false, 27.13);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Pie, rufous tree', 'Dendrocitta vagabunda', true, 47.37);
insert into animals (com_name, sci_name, carnivore, life_span) values ('Javanese cormorant', 'Phalacrocorax niger', false, 12.35);
insert into animals (com_name, sci_name, carnivore, life_span) values ('American black bear', 'Ursus americanus', false, 24.47);
/************************************************************************/
insert into locations (country, code, city) values ('Cyprus', 'CY', 'Meneou');
insert into locations (country, code, city) values ('France', 'FR', 'Saint-Maixent-l''École');
insert into locations (country, code, city) values ('Indonesia', 'ID', 'Sadang Kulon');
insert into locations (country, code, city) values ('Philippines', 'PH', 'Cawayan Bugtong');
insert into locations (country, code, city) values ('China', 'CN', 'Langxi');
insert into locations (country, code, city) values ('Indonesia', 'ID', 'Nakajah');
insert into locations (country, code, city) values ('Japan', 'JP', 'Ise');
insert into locations (country, code, city) values ('Indonesia', 'ID', 'Pangkalanbuun');
insert into locations (country, code, city) values ('Nepal', 'NP', 'Ithari');
insert into locations (country, code, city) values ('Sweden', 'SE', 'Ludvika');
insert into locations (country, code, city) values ('Togo', 'TG', 'Kara');
insert into locations (country, code, city) values ('Peru', 'PE', 'Ramón Castilla');
insert into locations (country, code, city) values ('Portugal', 'PT', 'Cachada');
insert into locations (country, code, city) values ('France', 'FR', 'Bobigny');
insert into locations (country, code, city) values ('Japan', 'JP', 'Ogawa');
insert into locations (country, code, city) values ('Poland', 'PL', 'Gwoźnica Górna');
insert into locations (country, code, city) values ('Russia', 'RU', 'Chesma');
insert into locations (country, code, city) values ('Vietnam', 'VN', 'Phong Điền');
insert into locations (country, code, city) values ('Vietnam', 'VN', 'Thị Trấn Việt Lâm');
insert into locations (country, code, city) values ('China', 'CN', 'Xiacang');
insert into locations (country, code, city) values ('France', 'FR', 'Nantes');
insert into locations (country, code, city) values ('Russia', 'RU', 'Karasuk');
insert into locations (country, code, city) values ('Georgia', 'GE', 'Tqibuli');
insert into locations (country, code, city) values ('China', 'CN', 'Shuinan');
insert into locations (country, code, city) values ('Ireland', 'IE', 'Balrothery');
insert into locations (country, code, city) values ('Nigeria', 'NG', 'Misau');
insert into locations (country, code, city) values ('Indonesia', 'ID', 'Lundo');
insert into locations (country, code, city) values ('China', 'CN', 'Youlongchuan');
insert into locations (country, code, city) values ('Nigeria', 'NG', 'Sade');
insert into locations (country, code, city) values ('China', 'CN', 'Zhangpu');
insert into locations (country, code, city) values ('United States', 'US', 'Dallas');
insert into locations (country, code, city) values ('Peru', 'PE', 'Canchaque');
insert into locations (country, code, city) values ('Georgia', 'GE', 'T’et’ri Tsqaro');
insert into locations (country, code, city) values ('Japan', 'JP', 'Ayabe');
insert into locations (country, code, city) values ('Costa Rica', 'CR', 'Limón');
insert into locations (country, code, city) values ('Paraguay', 'PY', 'Tobatí');
insert into locations (country, code, city) values ('France', 'FR', 'Lille');
insert into locations (country, code, city) values ('China', 'CN', 'Longquan');
insert into locations (country, code, city) values ('Argentina', 'AR', 'General Viamonte');
insert into locations (country, code, city) values ('Nigeria', 'NG', 'Madagali');
insert into locations (country, code, city) values ('Sweden', 'SE', 'Borås');
insert into locations (country, code, city) values ('Russia', 'RU', 'Surovikino');
insert into locations (country, code, city) values ('Afghanistan', 'AF', 'Mandōl');
insert into locations (country, code, city) values ('China', 'CN', 'Xiachengzi');
insert into locations (country, code, city) values ('Laos', 'LA', 'Ban Houakhoua');
insert into locations (country, code, city) values ('Indonesia', 'ID', 'Krajan');
insert into locations (country, code, city) values ('China', 'CN', 'Xinquansi');
insert into locations (country, code, city) values ('Indonesia', 'ID', 'Meukek');
insert into locations (country, code, city) values ('Russia', 'RU', 'Novokuz’minki');
insert into locations (country, code, city) values ('Indonesia', 'ID', 'Kroya');
insert into locations (country, code, city) values ('Indonesia', 'ID', 'Tanenofunan');
insert into locations (country, code, city) values ('Mongolia', 'MN', 'Jargalant');
insert into locations (country, code, city) values ('Indonesia', 'ID', 'Kalipucang');
insert into locations (country, code, city) values ('China', 'CN', 'Batou');
insert into locations (country, code, city) values ('United States', 'US', 'Danbury');
insert into locations (country, code, city) values ('Nigeria', 'NG', 'Okpo');
insert into locations (country, code, city) values ('China', 'CN', 'Xijiadian');
insert into locations (country, code, city) values ('Somalia', 'SO', 'Xarardheere');
insert into locations (country, code, city) values ('China', 'CN', 'Wuying');
insert into locations (country, code, city) values ('United States', 'US', 'Richmond');
insert into locations (country, code, city) values ('Czech Republic', 'CZ', 'Tlumačov');
insert into locations (country, code, city) values ('Cameroon', 'CM', 'Batouri');
insert into locations (country, code, city) values ('Macedonia', 'MK', 'Srbica');
insert into locations (country, code, city) values ('Sweden', 'SE', 'Stockholm');
insert into locations (country, code, city) values ('Czech Republic', 'CZ', 'Svatava');
insert into locations (country, code, city) values ('Indonesia', 'ID', 'Mekarsari');
insert into locations (country, code, city) values ('South Africa', 'ZA', 'Whittlesea');
insert into locations (country, code, city) values ('Argentina', 'AR', 'Quilino');
insert into locations (country, code, city) values ('Philippines', 'PH', 'Bolong');
insert into locations (country, code, city) values ('Portugal', 'PT', 'Tojeira');
insert into locations (country, code, city) values ('Vietnam', 'VN', 'Thị Trấn Mường Tè');
insert into locations (country, code, city) values ('Russia', 'RU', 'Verkhniye Kigi');
insert into locations (country, code, city) values ('China', 'CN', 'Samajie Ewenkeminzu');
insert into locations (country, code, city) values ('Japan', 'JP', 'Shimokizukuri');
insert into locations (country, code, city) values ('France', 'FR', 'Vesoul');
insert into locations (country, code, city) values ('Iran', 'IR', 'Chenārān');
insert into locations (country, code, city) values ('Poland', 'PL', 'Fabianki');
insert into locations (country, code, city) values ('China', 'CN', 'Huangludian');
insert into locations (country, code, city) values ('Indonesia', 'ID', 'Trucuk');
insert into locations (country, code, city) values ('Poland', 'PL', 'Łęknica');
insert into locations (country, code, city) values ('Argentina', 'AR', 'Loreto');
insert into locations (country, code, city) values ('United States', 'US', 'Rochester');
insert into locations (country, code, city) values ('Mongolia', 'MN', 'Khujirt');
insert into locations (country, code, city) values ('China', 'CN', 'Tianshan');
insert into locations (country, code, city) values ('Poland', 'PL', 'Milówka');
insert into locations (country, code, city) values ('Russia', 'RU', 'Primorsk');
insert into locations (country, code, city) values ('China', 'CN', 'Tashi');
insert into locations (country, code, city) values ('Czech Republic', 'CZ', 'Valašská Polanka');
insert into locations (country, code, city) values ('Chile', 'CL', 'Río Bueno');
insert into locations (country, code, city) values ('Greece', 'GR', 'Vónitsa');
insert into locations (country, code, city) values ('Russia', 'RU', 'Pryazha');
insert into locations (country, code, city) values ('Indonesia', 'ID', 'Oesena');
insert into locations (country, code, city) values ('Indonesia', 'ID', 'Kalianget');
insert into locations (country, code, city) values ('United States', 'US', 'Trenton');
insert into locations (country, code, city) values ('China', 'CN', 'Rudong');
insert into locations (country, code, city) values ('China', 'CN', 'Zhoujiadian');
insert into locations (country, code, city) values ('Greece', 'GR', 'Káto Miliá');
insert into locations (country, code, city) values ('United States', 'US', 'Canton');
insert into locations (country, code, city) values ('Colombia', 'CO', 'Madrid');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
insert into Lives_in (animal_name, place)
	SELECT animals.sci_name as random, locations.city as random
	FROM animals, locations
	ORDER BY random() limit 1000
	;


	







