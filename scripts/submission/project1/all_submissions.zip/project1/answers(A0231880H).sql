/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* The three tables are to record the (1) Staff information - 'staff' (2) Stock information - 'stock' (3) The stocks that the staff bought - 'holdings'.
There are 100 rows each in staff and stock, and 1000 relationships in holdings.
For the staff table, staff ID is the primary key. For the stock table, stock market and stock symbol are the primary keys. 
For holdings, no primary key is set but staff ID, stock market and stock symbol will be foreign keys to the other two tables.

The context here is that some professional firms require staff to report the investments or securities that they purchased and sold,
as this concerns independence with clients. Here assuming the firms do keep track of all the available securities in the market, by obtaining data from service provider.
To make it a bit more real, after populating the holdings table with staff and stock relationships, a random number of stock purchased and purchase date has been inserted.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS Staff (
staff_id VARCHAR(10) PRIMARY KEY,
first_name VARCHAR(32) NOT NULL,
last_name VARCHAR(32) NOT NULL,
department VARCHAR(64) NOT NULL,
job_title VARCHAR(64) NOT NULL,
social_sec_num VARCHAR(11) NOT NULL);

CREATE TABLE IF NOT EXISTS Stock (
stock_mkt VARCHAR(10) NOT NULL,
stock_symb VARCHAR(10) NOT NULL,
stock_name VARCHAR(80) NOT NULL,
stock_indt VARCHAR(80) NOT NULL,
stock_sect VARCHAR(32) NOT NULL,
PRIMARY KEY (stock_mkt, stock_symb));

CREATE TABLE IF NOT EXISTS Holdings (
staff_id VARCHAR(10) REFERENCES Staff(staff_id),
stock_mkt VARCHAR(10) NOT NULL,
stock_symb VARCHAR(10) NOT NULL,
shares_num NUMERIC,
stock_pur_date DATE,
stock_sell_date DATE,
FOREIGN KEY (stock_mkt, stock_symb) REFERENCES Stock(stock_mkt, stock_symb));

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('84-7663363', 'Egon', 'Coniam', 'Sales', 'Web Developer III', '680-02-2846');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('05-3822493', 'Bernardina', 'Venners', 'Product Management', 'Biostatistician III', '209-19-1834');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('21-7345080', 'Munroe', 'Pengelley', 'Training', 'Financial Analyst', '719-47-6282');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('24-5463017', 'Lelah', 'Burnie', 'Business Development', 'Health Coach II', '151-19-0150');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('68-7162811', 'Laurette', 'Vials', 'Product Management', 'Statistician I', '895-06-9268');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('63-8392734', 'Judd', 'Brewer', 'Support', 'Chemical Engineer', '291-53-6092');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('24-6779009', 'Eleen', 'Unger', 'Support', 'Assistant Professor', '806-07-2336');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('27-4887707', 'Dareen', 'McAne', 'Services', 'Environmental Specialist', '535-45-4329');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('78-2730481', 'Elora', 'Whitty', 'Marketing', 'Safety Technician IV', '226-43-7391');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('75-5534871', 'Eve', 'Knibley', 'Engineering', 'Clinical Specialist', '786-72-9856');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('77-3012802', 'Rouvin', 'Cohalan', 'Human Resources', 'Research Nurse', '863-96-3666');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('38-3818014', 'Mauricio', 'Breache', 'Services', 'Information Systems Manager', '439-29-4968');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('00-7489934', 'Wilona', 'Caughtry', 'Product Management', 'Actuary', '801-53-2620');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('41-7723064', 'Abagael', 'Sparling', 'Training', 'Environmental Tech', '460-47-7686');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('22-0186112', 'Jori', 'Cuschieri', 'Engineering', 'Nuclear Power Engineer', '859-85-0231');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('52-8814385', 'Laughton', 'Mangham', 'Sales', 'GIS Technical Architect', '799-53-6755');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('82-4304464', 'Morganne', 'Leefe', 'Sales', 'Occupational Therapist', '419-06-4370');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('43-1299956', 'Rogers', 'Mylan', 'Legal', 'VP Sales', '721-21-4588');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('68-1236778', 'Daveen', 'Ainger', 'Services', 'Librarian', '215-51-6350');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('53-0014816', 'Dilly', 'Dimic', 'Engineering', 'Food Chemist', '808-99-5097');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('84-8430274', 'Jerry', 'China', 'Legal', 'Recruiting Manager', '874-45-1433');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('84-4415039', 'Deonne', 'Greggs', 'Services', 'Systems Administrator IV', '711-62-3684');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('68-6098294', 'Micky', 'Baterip', 'Product Management', 'Biostatistician II', '833-41-5790');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('62-1035877', 'Ban', 'Tresvina', 'Legal', 'Assistant Professor', '533-79-9155');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('65-2485862', 'Rhianon', 'Seid', 'Human Resources', 'Sales Representative', '818-44-8882');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('93-0618924', 'Ossie', 'Corley', 'Human Resources', 'Staff Scientist', '526-26-3460');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('41-7111358', 'Dona', 'Manntschke', 'Marketing', 'Computer Systems Analyst IV', '552-51-8937');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('22-5160229', 'Homer', 'O''Farrell', 'Sales', 'Occupational Therapist', '405-89-5924');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('82-0371954', 'Adey', 'Floodgate', 'Sales', 'Chemical Engineer', '295-11-4521');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('02-1207360', 'Leisha', 'Inman', 'Engineering', 'VP Product Management', '343-91-5062');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('70-7391464', 'Aigneis', 'Tonks', 'Research and Development', 'Nuclear Power Engineer', '112-05-6267');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('37-3398047', 'Suzann', 'Humbert', 'Services', 'Accounting Assistant III', '595-84-8216');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('92-0755796', 'Myrtia', 'Lindroos', 'Human Resources', 'VP Product Management', '322-66-9693');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('26-0458425', 'Ana', 'Cohane', 'Training', 'Administrative Officer', '335-30-1545');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('61-9290603', 'Corrinne', 'Baysting', 'Training', 'Graphic Designer', '226-67-3785');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('19-3130373', 'Tiebout', 'Huriche', 'Legal', 'Pharmacist', '432-45-1259');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('60-0366433', 'Karney', 'La Padula', 'Sales', 'Senior Cost Accountant', '491-66-1709');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('50-0839779', 'Margeaux', 'Blandford', 'Research and Development', 'Structural Engineer', '226-64-4863');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('84-9539011', 'Alissa', 'Beaney', 'Accounting', 'Nurse', '408-14-8815');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('47-4281193', 'Martynne', 'Vondrasek', 'Support', 'Account Representative III', '706-33-8099');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('20-4144976', 'Hulda', 'Dener', 'Marketing', 'Clinical Specialist', '458-98-3494');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('85-2015475', 'Amandie', 'Winslade', 'Product Management', 'VP Accounting', '194-29-3817');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('73-1430971', 'Joeann', 'Rookwell', 'Human Resources', 'Chemical Engineer', '272-12-4326');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('62-7017426', 'Rudy', 'Dumphreys', 'Engineering', 'Electrical Engineer', '809-80-8011');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('89-0254255', 'Thurstan', 'Fairlem', 'Accounting', 'Research Associate', '560-91-3836');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('62-5034821', 'Tabina', 'Fayers', 'Support', 'Chief Design Engineer', '369-45-5621');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('73-5878664', 'Sandye', 'Bollin', 'Engineering', 'VP Accounting', '318-45-2272');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('43-4754824', 'Curran', 'Shutle', 'Engineering', 'Electrical Engineer', '708-46-9265');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('28-2365784', 'Parke', 'Sutcliffe', 'Legal', 'Computer Systems Analyst I', '716-93-8087');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('67-3172198', 'Lalo', 'Torvey', 'Training', 'Technical Writer', '741-43-7917');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('51-5669739', 'Dalia', 'Mulqueeny', 'Support', 'Information Systems Manager', '541-44-6335');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('08-1383555', 'Jonie', 'Griffe', 'Accounting', 'Food Chemist', '374-73-1648');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('75-3717695', 'Chiquia', 'Janowski', 'Product Management', 'Clinical Specialist', '309-45-9868');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('97-3382768', 'Ardyce', 'Alabone', 'Research and Development', 'Professor', '277-61-7626');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('07-5771738', 'Darcy', 'Jonin', 'Human Resources', 'Professor', '567-76-5317');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('67-3206905', 'Arvin', 'Flohard', 'Training', 'Help Desk Technician', '804-29-5213');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('29-1339730', 'Robinia', 'Kinnar', 'Engineering', 'Help Desk Technician', '317-60-9927');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('41-5412787', 'Allen', 'Duffie', 'Research and Development', 'VP Marketing', '333-92-6725');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('78-6600191', 'Kenn', 'Lafayette', 'Research and Development', 'Budget/Accounting Analyst II', '478-15-7055');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('26-6162848', 'Montgomery', 'O''Hearn', 'Services', 'Account Representative I', '541-05-5013');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('51-2738994', 'Rossy', 'Gon', 'Product Management', 'VP Marketing', '895-42-0909');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('17-0691868', 'Donelle', 'Willatt', 'Support', 'VP Accounting', '255-04-4360');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('93-2768800', 'Allin', 'Revill', 'Support', 'Senior Developer', '482-74-0129');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('49-1595260', 'Richart', 'Tarbin', 'Product Management', 'Professor', '668-40-3111');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('62-0108563', 'Berny', 'Venn', 'Engineering', 'Electrical Engineer', '776-77-9891');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('74-3927809', 'Carney', 'Yapp', 'Product Management', 'Developer IV', '171-07-2169');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('39-9909484', 'Carly', 'Twopenny', 'Research and Development', 'Help Desk Technician', '401-70-3853');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('90-8415776', 'Martina', 'Pettiward', 'Accounting', 'Teacher', '380-56-5216');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('20-2718379', 'Baldwin', 'Cock', 'Services', 'Nuclear Power Engineer', '376-49-9715');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('59-8546355', 'Carolann', 'Delaprelle', 'Research and Development', 'General Manager', '319-56-5090');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('41-9279018', 'Ellswerth', 'Schubart', 'Training', 'Product Engineer', '364-55-1363');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('69-6078074', 'Costanza', 'Cowterd', 'Accounting', 'Associate Professor', '283-12-8358');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('14-9435394', 'Bree', 'Gilliat', 'Training', 'Account Representative III', '773-64-9132');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('01-0886898', 'Markos', 'Madoc-Jones', 'Accounting', 'Computer Systems Analyst II', '446-22-9706');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('45-1014017', 'Gert', 'Meharg', 'Product Management', 'Research Nurse', '755-56-3347');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('40-2186956', 'Atalanta', 'Spencock', 'Sales', 'Nuclear Power Engineer', '109-52-6291');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('90-7578028', 'Rochell', 'McPhaden', 'Product Management', 'Senior Cost Accountant', '100-10-4297');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('49-1102743', 'Wilone', 'Highton', 'Training', 'Junior Executive', '320-52-0589');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('87-8588740', 'Isidor', 'MacKartan', 'Legal', 'Nuclear Power Engineer', '835-76-0514');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('14-8135499', 'Kynthia', 'Pelerin', 'Services', 'Physical Therapy Assistant', '842-18-9043');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('45-5246392', 'Katherine', 'Giberd', 'Product Management', 'Technical Writer', '344-95-2700');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('63-2202968', 'Maye', 'Bygott', 'Training', 'Professor', '323-60-6231');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('77-0573274', 'Brooke', 'Haddeston', 'Sales', 'Database Administrator III', '366-08-0311');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('94-3820272', 'Elisabeth', 'Vaux', 'Legal', 'Graphic Designer', '132-97-5506');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('39-8738061', 'Weidar', 'Wardley', 'Training', 'Structural Engineer', '796-19-9706');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('98-8490759', 'Effie', 'Shildrick', 'Services', 'Account Coordinator', '613-66-5024');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('29-2401210', 'Meredithe', 'Cranage', 'Accounting', 'Sales Associate', '432-67-7956');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('74-7811244', 'Muire', 'Patullo', 'Services', 'Sales Representative', '864-37-4906');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('31-2285314', 'Aubree', 'Mathissen', 'Training', 'Web Developer II', '768-24-8859');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('92-6875709', 'Matthias', 'Garton', 'Business Development', 'Software Test Engineer I', '828-25-4078');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('59-4558049', 'Elianore', 'Thaim', 'Business Development', 'Software Engineer I', '536-84-7518');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('63-5043972', 'Malcolm', 'Labrum', 'Legal', 'Data Coordiator', '823-06-6475');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('14-3276426', 'Audrie', 'Shirtcliffe', 'Support', 'Administrative Assistant I', '498-16-3519');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('29-7888436', 'Brenna', 'Towns', 'Research and Development', 'Chemical Engineer', '589-96-5501');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('31-3229054', 'Terencio', 'Patching', 'Support', 'Chemical Engineer', '729-75-7581');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('63-4104270', 'Eugenius', 'Brahams', 'Services', 'Electrical Engineer', '843-62-0415');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('33-2825164', 'Gordy', 'Jehan', 'Sales', 'Environmental Tech', '589-45-3688');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('04-8204890', 'Justinn', 'Sinkin', 'Services', 'Software Engineer IV', '227-08-5394');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('81-0547056', 'Winny', 'Mabon', 'Support', 'Programmer Analyst II', '214-91-8790');
insert into staff (staff_id, first_name, last_name, department, job_title, social_sec_num) values ('47-6166357', 'Lynne', 'Tolomio', 'Support', 'Social Worker', '759-93-4348');

insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'WHLRD', 'Wheeler Real Estate Investment Trust, Inc.', 'Real Estate Investment Trusts', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'VGR', 'Vector Group Ltd.', 'Farming/Seeds/Milling', 'Consumer Non-Durables');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'NCB', 'Nuveen California Municipal Value Fund 2', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'JCS', 'Communications Systems, Inc.', 'Telecommunications Equipment', 'Public Utilities');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'JW.A', 'John Wiley & Sons, Inc.', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'VLY^A', 'Valley National Bancorp', 'Major Banks', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'CDOR', 'Condor Hospitality Trust, Inc.', 'Real Estate Investment Trusts', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'LMRK', 'Landmark Infrastructure Partners LP', 'Real Estate', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'EXXI', 'Energy XXI Gulf Coast, Inc.', 'Oil & Gas Production', 'Energy');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'ASNA', 'Ascena Retail Group, Inc.', 'Clothing/Shoe/Accessory Stores', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'ABCD', 'Cambium Learning Group, Inc.', 'Publishing', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'WST', 'West Pharmaceutical Services, Inc.', 'Specialty Chemicals', 'Basic Industries');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'HBANP', 'Huntington Bancshares Incorporated', 'Major Banks', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'SNBC', 'Sun Bancorp, Inc.', 'Commercial Banks', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'MFD', 'Macquarie/First Trust Global', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'CFFI', 'C&F Financial Corporation', 'Major Banks', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'HBHC', 'Hancock Holding Company', 'Major Banks', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'LBTYK', 'Liberty Global plc', 'Television Services', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'FTXO', 'First Trust Nasdaq Bank ETF', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'SNR', 'New Senior Investment Group Inc.', 'Real Estate Investment Trusts', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'SR', 'Spire Inc.', 'Oil/Gas Transmission', 'Public Utilities');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'NYMTP', 'New York Mortgage Trust, Inc.', 'Finance: Consumer Services', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'SRI', 'Stoneridge, Inc.', 'Auto Parts:O.E.M.', 'Capital Goods');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'NGHCZ', 'National General Holdings Corp', 'Property-Casualty Insurers', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'DX', 'Dynex Capital, Inc.', 'Real Estate Investment Trusts', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'LIVN', 'LivaNova PLC', 'Biotechnology: Electromedical & Electrotherapeutic Apparatus', 'Health Care');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'GSL^B', 'Global Ship Lease, Inc.', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'AAOI', 'Applied Optoelectronics, Inc.', 'Semiconductors', 'Technology');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'KYO', 'Kyocera Corporation', 'Semiconductors', 'Technology');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'ATLO', 'Ames National Corporation', 'Major Banks', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'PNC.WS', 'PNC Financial Services Group, Inc. (The)', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'RYAM^A', 'Rayonier Advanced Materials Inc.', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'CBMX', 'CombiMatrix Corporation', 'Hospital/Nursing Management', 'Health Care');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'EROS', 'Eros International PLC', 'Movies/Entertainment', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'EMO', 'ClearBridge Energy MLP Opportunity Fund Inc.', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'SRTS', 'Sensus Healthcare, Inc.', 'Medical/Dental Instruments', 'Health Care');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'RLI', 'RLI Corp.', 'Property-Casualty Insurers', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'TOT', 'Total S.A.', 'Oil & Gas Production', 'Energy');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'BSMX', 'Grupo Financiero Santander Mexico S.A. B. de C.V.', 'Commercial Banks', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'EDN', 'Empresa Distribuidora Y Comercializadora Norte S.A. (Edenor)', 'Electric Utilities: Central', 'Public Utilities');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'IPAS', 'iPass Inc.', 'EDP Services', 'Technology');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'PDI', 'PIMCO Dynamic Income Fund', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'GOOG', 'Alphabet Inc.', 'Computer Software: Programming, Data Processing', 'Technology');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'DVAX', 'Dynavax Technologies Corporation', 'Major Pharmaceuticals', 'Health Care');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'NICE', 'NICE Ltd', 'Computer Manufacturing', 'Technology');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'GDL^B', 'The GDL Fund', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'SPKE', 'Spark Energy, Inc.', 'Power Generation', 'Public Utilities');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'BATRK', 'Liberty Media Corporation', 'Broadcasting', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'FINQ', 'Purefunds Solactive FinTech ETF', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'AKAM', 'Akamai Technologies, Inc.', 'Business Services', 'Miscellaneous');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'SYT', 'Syngenta AG', 'Agricultural Chemicals', 'Basic Industries');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'CAAS', 'China Automotive Systems, Inc.', 'Auto Parts:O.E.M.', 'Capital Goods');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'DNKN', 'Dunkin'' Brands Group, Inc.', 'Restaurants', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'GWR', 'Genesee & Wyoming, Inc.', 'Railroads', 'Transportation');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'OVID', 'Ovid Therapeutics Inc.', 'Major Pharmaceuticals', 'Health Care');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'ARCB', 'ArcBest Corporation', 'Trucking Freight/Courier Services', 'Transportation');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'MS', 'Morgan Stanley', 'Investment Bankers/Brokers/Service', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'ANDAR', 'Andina Acquisition Corp. II', 'Business Services', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'AYX', 'Alteryx, Inc.', 'Computer Software: Prepackaged Software', 'Technology');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'YTEN', 'Yield10 Bioscience, Inc.', 'Containers/Packaging', 'Basic Industries');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'PSTB', 'Park Sterling Corporation', 'Major Banks', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'CYS', 'CYS Investments, Inc.', 'Real Estate Investment Trusts', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'BHE', 'Benchmark Electronics, Inc.', 'Electrical Products', 'Technology');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'ECPG', 'Encore Capital Group Inc', 'Finance Companies', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'VTA', 'Invesco Credit Opportunities Fund', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'AGTC', 'Applied Genetic Technologies Corporation', 'Biotechnology: Biological Products (No Diagnostic Substances)', 'Health Care');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'DRQ', 'Dril-Quip, Inc.', 'Metal Fabrications', 'Energy');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'KIRK', 'Kirkland''s, Inc.', 'Other Specialty Stores', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'DSE', 'Duff & Phelps Select Energy MLP Fund Inc.', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'LEE', 'Lee Enterprises, Incorporated', 'Newspapers/Magazines', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'PFSI', 'PennyMac Financial Services, Inc.', 'Finance: Consumer Services', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'GRID', 'First Trust NASDAQ Clean Edge Smart Grid Infrastructure Index ', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'NVIV', 'InVivo Therapeutics Holdings Corp.', 'Medical/Dental Instruments', 'Health Care');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'G', 'Genpact Limited', 'Professional Services', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'YUME', 'YuMe, Inc.', 'Advertising', 'Technology');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'PJT', 'PJT Partners Inc.', 'Investment Managers', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'TSNU', 'Tyson Foods, Inc.', 'Meat/Poultry/Fish', 'Consumer Non-Durables');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'OFIX', 'Orthofix International N.V.', 'Medical/Dental Instruments', 'Health Care');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'PRE^H', 'PartnerRe Ltd.', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'BUR', 'Burcon NutraScience Corp', 'Packaged Foods', 'Consumer Non-Durables');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'LBTYA', 'Liberty Global plc', 'Television Services', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'IHG', 'Intercontinental Hotels Group', 'Hotels/Resorts', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'DTUS', 'iPath US Treasury 2-year Bear ETN', 'Commercial Banks', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'CSL', 'Carlisle Companies Incorporated', 'Specialty Chemicals', 'Basic Industries');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'SGLB', 'Sigma Labs, Inc.', 'Miscellaneous manufacturing industries', 'Consumer Durables');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'SBSI', 'Southside Bancshares, Inc.', 'Major Banks', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'AEIS', 'Advanced Energy Industries, Inc.', 'Industrial Machinery/Components', 'Capital Goods');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'DCP', 'DCP Midstream LP', 'Natural Gas Distribution', 'Public Utilities');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'ATEC', 'Alphatec Holdings, Inc.', 'Medical/Dental Instruments', 'Health Care');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'ATTO', 'Atento S.A.', 'Telecommunications Equipment', 'Public Utilities');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'EGF', 'Blackrock Enhanced Government Fund, Inc', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'VGLT', 'Vanguard Long-Term Government Bond ETF', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'MTU', 'Mitsubishi UFJ Financial Group Inc', 'Commercial Banks', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'MGRC', 'McGrath RentCorp', 'Diversified Commercial Services', 'Technology');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'KEYW', 'The KEYW Holding Corporation', 'EDP Services', 'Technology');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'ABC', 'AmerisourceBergen Corporation (Holding Co)', 'Other Pharmaceuticals', 'Health Care');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'CXP', 'Columbia Property Trust, Inc.', 'Real Estate Investment Trusts', 'Consumer Services');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'USB^A', 'U.S. Bancorp', 'Major Banks', 'Finance');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NYSE', 'IFN', 'India Fund, Inc. (The)', 'n/a', 'n/a');
insert into stock (stock_mkt, stock_symb, stock_name, stock_indt, stock_sect) values ('NASDAQ', 'ACNB', 'ACNB Corporation', 'Major Banks', 'Finance');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO holdings (staff_id, stock_mkt, stock_symb)
SELECT staff_id s, stock_mkt t, stock_symb t
FROM staff s, stock t
ORDER BY random()
LIMIT 1000;

UPDATE holdings
SET shares_num = floor(random()*9900::int)+100;

UPDATE holdings
SET stock_pur_date = date( (current_date - '7 years'::interval) +
 trunc(random() * 365) * '1 day'::interval +
 trunc(random() * 6) * '1 year'::interval );
