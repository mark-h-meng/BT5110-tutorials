/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* 
   Over the past few months, people have found indoor activities to 
   entertain themselves. Along with the increase of activities like baking,
   making dalgona coffees and home workouts, reading has also increased. 

   Some MSBA students took the opportunity to create an online library so
   that people who are interested in reading but cannot travel to a library
   have the opportunity to borrow and read books online as per their 
   convenience. As you can see, it was very successful!
   
   Below there are three tables: library_members, books and loans. 
   library_members show us the details of the members of the library, books
   show us the details of the books and the loans table shows us who 
   borrowed what book.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE library_members (
  library_id INT PRIMARY KEY, 
  first_name VARCHAR(16) NOT NULL, 
  last_name VARCHAR(16) NOT NULL, 
  email VARCHAR(32) UNIQUE NOT NULL, 
  username VARCHAR(16) UNIQUE NOT NULL
);
CREATE TABLE books (
  isbn VARCHAR(16) PRIMARY KEY, 
  title VARCHAR(48) NOT NULL, 
  author VARCHAR(32) NOT NULL, 
  language VARCHAR(16) NOT NULL, 
  published VARCHAR(8) NOT NULL
);
CREATE TABLE loans (
  library_id INT NOT NULL REFERENCES library_members(library_id), 
  isbn VARCHAR (16) NOT NULL REFERENCES books(isbn)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into books (isbn, title, author, language, published) values ('064553402-1', 'iterate dynamic networks', 'Boonie Cutting', 'Persian', 2006);
insert into books (isbn, title, author, language, published) values ('980047431-5', 'implement 24/7 content', 'Carley Gaynesford', 'Kazakh', 1989);
insert into books (isbn, title, author, language, published) values ('247160983-X', 'synthesize B2B initiatives', 'Rosalie Middlewick', 'Montenegrin', 2005);
insert into books (isbn, title, author, language, published) values ('833519598-6', 'reinvent user-centric platforms', 'Fletch Yuryev', 'Albanian', 2009);
insert into books (isbn, title, author, language, published) values ('514581302-3', 'matrix ubiquitous users', 'Gabriell Windridge', 'Papiamento', 1995);
insert into books (isbn, title, author, language, published) values ('506834020-0', 'morph cross-media content', 'Becca Baldam', 'Finnish', 1997);
insert into books (isbn, title, author, language, published) values ('033139321-2', 'harness cross-platform e-business', 'Lurlene Baszkiewicz', 'Spanish', 2001);
insert into books (isbn, title, author, language, published) values ('196145169-7', 'monetize revolutionary platforms', 'Katey Josse', 'Dhivehi', 1995);
insert into books (isbn, title, author, language, published) values ('078356897-5', 'transition rich relationships', 'Cecile Bracchi', 'Gujarati', 1994);
insert into books (isbn, title, author, language, published) values ('998545485-5', 'whiteboard leading-edge web-readiness', 'Fayette Le Brun', 'Dzongkha', 2009);
insert into books (isbn, title, author, language, published) values ('830854121-6', 'matrix compelling portals', 'Mab Cahan', 'Albanian', 2007);
insert into books (isbn, title, author, language, published) values ('853426448-1', 'unleash out-of-the-box experiences', 'Ingeborg Horley', 'Sotho', 2009);
insert into books (isbn, title, author, language, published) values ('680049546-8', 'aggregate holistic channels', 'Ardelis Glossup', 'Catalan', 1985);
insert into books (isbn, title, author, language, published) values ('746801993-2', 'drive wireless eyeballs', 'Dar Bewick', 'Moldovan', 2012);
insert into books (isbn, title, author, language, published) values ('988996757-X', 'innovate 24/7 mindshare', 'Rowena Mayoral', 'Ndebele', 1992);
insert into books (isbn, title, author, language, published) values ('496249138-5', 'engineer leading-edge applications', 'Marlin Jozefowicz', 'Irish Gaelic', 2001);
insert into books (isbn, title, author, language, published) values ('081165267-X', 'redefine holistic networks', 'Maria Hammett', 'Assamese', 1992);
insert into books (isbn, title, author, language, published) values ('413361872-6', 'syndicate extensible functionalities', 'Feliks Aleshintsev', 'Japanese', 2009);
insert into books (isbn, title, author, language, published) values ('499819257-4', 'maximize front-end supply-chains', 'My Leathart', 'Macedonian', 2006);
insert into books (isbn, title, author, language, published) values ('386107945-3', 'streamline visionary platforms', 'Robert Mapledoram', 'Hungarian', 1999);
insert into books (isbn, title, author, language, published) values ('949299459-3', 'mesh visionary e-markets', 'Arliene Ruzicka', 'Northern Sotho', 1989);
insert into books (isbn, title, author, language, published) values ('985453635-1', 'morph magnetic web services', 'Riva Gherardelli', 'Korean', 1998);
insert into books (isbn, title, author, language, published) values ('342184336-8', 'harness compelling e-markets', 'Dane Stigell', 'Lithuanian', 1994);
insert into books (isbn, title, author, language, published) values ('258771086-3', 'empower bricks-and-clicks metrics', 'Valentine Sloyan', 'Japanese', 2004);
insert into books (isbn, title, author, language, published) values ('058048725-3', 'reintermediate B2B users', 'Colene Herculson', 'Hungarian', 2008);
insert into books (isbn, title, author, language, published) values ('750961321-3', 'integrate ubiquitous systems', 'Augusta Bindley', 'Thai', 2004);
insert into books (isbn, title, author, language, published) values ('205056068-0', 'productize integrated metrics', 'Cecile Deguara', 'Fijian', 2008);
insert into books (isbn, title, author, language, published) values ('027089077-7', 'iterate B2B bandwidth', 'Fernando Jessen', 'Catalan', 2003);
insert into books (isbn, title, author, language, published) values ('881936509-X', 'redefine transparent metrics', 'Lionel Chivrall', 'Quechua', 2012);
insert into books (isbn, title, author, language, published) values ('311595745-9', 'revolutionize global infrastructures', 'Andrew Longman', 'Spanish', 1993);
insert into books (isbn, title, author, language, published) values ('977568685-7', 'harness e-business paradigms', 'Krista Bromage', 'Latvian', 1989);
insert into books (isbn, title, author, language, published) values ('341148716-X', 'synergize real-time convergence', 'Jacqui Kyte', 'Montenegrin', 2004);
insert into books (isbn, title, author, language, published) values ('537859888-5', 'facilitate next-generation methodologies', 'Raquela Maitland', 'Quechua', 2000);
insert into books (isbn, title, author, language, published) values ('149251553-1', 'incubate rich communities', 'Keriann Choffin', 'Amharic', 1992);
insert into books (isbn, title, author, language, published) values ('698950325-4', 'brand virtual partnerships', 'Lind Kroger', 'Bosnian', 2006);
insert into books (isbn, title, author, language, published) values ('088543531-1', 'productize killer architectures', 'Ringo Koppe', 'Lao', 2006);
insert into books (isbn, title, author, language, published) values ('297907075-0', 'utilize revolutionary markets', 'Deirdre Caffrey', 'Papiamento', 1985);
insert into books (isbn, title, author, language, published) values ('577035949-8', 'grow proactive deliverables', 'Jim Spino', 'Amharic', 1998);
insert into books (isbn, title, author, language, published) values ('227369501-2', 'repurpose strategic infomediaries', 'Giorgi Bagot', 'Kyrgyz', 2003);
insert into books (isbn, title, author, language, published) values ('860964956-3', 'empower rich synergies', 'Cristina Rew', 'German', 2008);
insert into books (isbn, title, author, language, published) values ('638449522-8', 'whiteboard world-class technologies', 'Brande Snowden', 'Somali', 2012);
insert into books (isbn, title, author, language, published) values ('542130992-4', 'unleash impactful systems', 'Adam Vain', 'Romanian', 1988);
insert into books (isbn, title, author, language, published) values ('005174661-1', 'harness dynamic eyeballs', 'Mallissa FitzAlan', 'West Frisian', 2008);
insert into books (isbn, title, author, language, published) values ('966346101-2', 'aggregate intuitive platforms', 'Evan Dalla', 'Oriya', 2003);
insert into books (isbn, title, author, language, published) values ('363976058-1', 'incubate vertical schemas', 'Ravi Titheridge', 'Estonian', 2005);
insert into books (isbn, title, author, language, published) values ('175506856-5', 'embrace one-to-one mindshare', 'Candice Etter', 'Kannada', 2001);
insert into books (isbn, title, author, language, published) values ('197065448-1', 'evolve open-source systems', 'Tamas Innman', 'Croatian', 1985);
insert into books (isbn, title, author, language, published) values ('294274714-5', 'synthesize plug-and-play supply-chains', 'Cati Cowthart', 'Maltese', 2011);
insert into books (isbn, title, author, language, published) values ('356385310-X', 'monetize collaborative niches', 'Huey Drummer', 'Luxembourgish', 1992);
insert into books (isbn, title, author, language, published) values ('111789244-1', 'scale back-end experiences', 'Holly Bigby', 'Kyrgyz', 2004);
insert into books (isbn, title, author, language, published) values ('642935921-2', 'enhance dot-com bandwidth', 'Brooke Gillaspy', 'Aymara', 2007);
insert into books (isbn, title, author, language, published) values ('237708843-0', 'incubate scalable eyeballs', 'Dore Jerisch', 'Georgian', 2003);
insert into books (isbn, title, author, language, published) values ('063450617-X', 'architect clicks-and-mortar content', 'Hildagarde Knuckles', 'Korean', 1992);
insert into books (isbn, title, author, language, published) values ('294401546-X', 'visualize user-centric relationships', 'Stanley Parkhouse', 'Māori', 1988);
insert into books (isbn, title, author, language, published) values ('674185764-8', 'embrace distributed paradigms', 'Malia Broughton', 'Polish', 2000);
insert into books (isbn, title, author, language, published) values ('739899446-X', 'evolve 24/7 models', 'Jory Gamble', 'Swahili', 2009);
insert into books (isbn, title, author, language, published) values ('706806035-8', 'mesh frictionless paradigms', 'Robinet Harvey', 'Nepali', 2008);
insert into books (isbn, title, author, language, published) values ('868975609-4', 'extend strategic portals', 'Krysta Hamlyn', 'Afrikaans', 1992);
insert into books (isbn, title, author, language, published) values ('004024699-X', 'architect enterprise e-tailers', 'Brenn Hrachovec', 'Papiamento', 2002);
insert into books (isbn, title, author, language, published) values ('542152469-8', 'matrix next-generation e-markets', 'Merell Motten', 'Chinese', 1983);
insert into books (isbn, title, author, language, published) values ('195273058-9', 'implement viral partnerships', 'Durand Nuschke', 'Assamese', 1994);
insert into books (isbn, title, author, language, published) values ('022981095-0', 'productize cross-media action-items', 'Rachel Tran', 'Telugu', 1995);
insert into books (isbn, title, author, language, published) values ('997930229-1', 'recontextualize end-to-end experiences', 'Kerk Leport', 'Marathi', 2008);
insert into books (isbn, title, author, language, published) values ('958839437-6', 'incentivize collaborative communities', 'Harley Spon', 'Spanish', 2008);
insert into books (isbn, title, author, language, published) values ('509254557-7', 'envisioneer dot-com partnerships', 'Rozalie Snow', 'German', 1995);
insert into books (isbn, title, author, language, published) values ('588111335-7', 'streamline proactive models', 'Jonis Bandt', 'Korean', 1999);
insert into books (isbn, title, author, language, published) values ('784172136-6', 'seize cross-media communities', 'Odilia Morkham', 'Hebrew', 1997);
insert into books (isbn, title, author, language, published) values ('845739723-0', 'leverage visionary portals', 'Elena Gladwell', 'Māori', 1989);
insert into books (isbn, title, author, language, published) values ('552320425-0', 'synthesize one-to-one ROI', 'Orsa Eliyahu', 'Dutch', 2001);
insert into books (isbn, title, author, language, published) values ('333267650-4', 'incentivize scalable systems', 'Ragnar Hastewell', 'Papiamento', 1985);
insert into books (isbn, title, author, language, published) values ('452751248-X', 'repurpose revolutionary ROI', 'Merrill Roscow', 'Northern Sotho', 1987);
insert into books (isbn, title, author, language, published) values ('288395751-7', 'exploit revolutionary metrics', 'Aguste Hurrion', 'Maltese', 1998);
insert into books (isbn, title, author, language, published) values ('538035928-0', 'benchmark viral deliverables', 'Charmain Henstridge', 'Bulgarian', 2009);
insert into books (isbn, title, author, language, published) values ('225849266-1', 'expedite 24/7 experiences', 'Manda Plaskett', 'Kashmiri', 2004);
insert into books (isbn, title, author, language, published) values ('384597415-X', 'grow extensible e-business', 'Mitch Pilbeam', 'Yiddish', 1998);
insert into books (isbn, title, author, language, published) values ('679459273-8', 'optimize clicks-and-mortar vortals', 'Jobey Gothard', 'Belarusian', 2013);
insert into books (isbn, title, author, language, published) values ('467622727-2', 'drive 24/365 partnerships', 'Lolly Shaw', 'Aymara', 2010);
insert into books (isbn, title, author, language, published) values ('519604482-5', 'productize e-business paradigms', 'Joice Wincott', 'Chinese', 2007);
insert into books (isbn, title, author, language, published) values ('508165959-2', 'cultivate best-of-breed convergence', 'Garald Kruschov', 'Bulgarian', 2012);
insert into books (isbn, title, author, language, published) values ('452841933-5', 'unleash best-of-breed content', 'Ailyn Eouzan', 'Hungarian', 1997);
insert into books (isbn, title, author, language, published) values ('585200425-1', 'generate robust communities', 'Dorella Robrose', 'Armenian', 1998);
insert into books (isbn, title, author, language, published) values ('281400544-8', 'harness turn-key content', 'Sibby Fleckness', 'Papiamento', 2003);
insert into books (isbn, title, author, language, published) values ('149735890-6', 'implement collaborative channels', 'Sherie Echalie', 'Portuguese', 2005);
insert into books (isbn, title, author, language, published) values ('219336033-2', 'iterate cross-platform users', 'Germaine Rossant', 'Haitian Creole', 2012);
insert into books (isbn, title, author, language, published) values ('013203564-2', 'syndicate open-source ROI', 'Claudie Scard', 'Hindi', 1993);
insert into books (isbn, title, author, language, published) values ('546820412-6', 'maximize clicks-and-mortar metrics', 'Rodolphe Garralts', 'Arabic', 1990);
insert into books (isbn, title, author, language, published) values ('887659587-2', 'productize visionary e-business', 'Dot Breache', 'Haitian Creole', 1998);
insert into books (isbn, title, author, language, published) values ('701634169-0', 'syndicate wireless infrastructures', 'Kaela Swindells', 'Papiamento', 2007);
insert into books (isbn, title, author, language, published) values ('750935958-9', 'syndicate plug-and-play users', 'Dyana Doblin', 'Bulgarian', 2002);
insert into books (isbn, title, author, language, published) values ('984412939-7', 'redefine back-end metrics', 'Christa Tinn', 'Fijian', 2011);
insert into books (isbn, title, author, language, published) values ('361857931-4', 'morph collaborative metrics', 'Oona Smittoune', 'Zulu', 2004);
insert into books (isbn, title, author, language, published) values ('628815907-7', 'productize 24/365 channels', 'Sheela Cuddy', 'Khmer', 2001);
insert into books (isbn, title, author, language, published) values ('994491267-0', 'transform holistic synergies', 'Vernon Leftly', 'Belarusian', 1986);
insert into books (isbn, title, author, language, published) values ('430895412-6', 'incubate out-of-the-box infomediaries', 'Pauletta Gommey', 'Swedish', 2004);
insert into books (isbn, title, author, language, published) values ('912164209-5', 'visualize B2B platforms', 'Shaina Beatson', 'French', 2010);
insert into books (isbn, title, author, language, published) values ('383820400-X', 'streamline revolutionary ROI', 'Douglass Janz', 'Quechua', 1988);
insert into books (isbn, title, author, language, published) values ('768294274-6', 'e-enable 24/7 e-tailers', 'Vanny Wallentin', 'Bengali', 2006);
insert into books (isbn, title, author, language, published) values ('844116265-4', 'unleash world-class eyeballs', 'Emeline Trewin', 'Croatian', 2001);
insert into books (isbn, title, author, language, published) values ('914166086-2', 'engineer real-time e-services', 'Albertine Hatcliffe', 'Sotho', 2007);
insert into books (isbn, title, author, language, published) values ('947915497-8', 'maximize robust systems', 'Herbie Glamart', 'Tamil', 1996);


insert into library_members (library_id, first_name, last_name, email, username) values (43193975, 'Kendal', 'Speight', 'kspeight0@blog.com', 'kspeight0');
insert into library_members (library_id, first_name, last_name, email, username) values (98556647, 'Anthe', 'Groger', 'agroger1@senate.gov', 'agroger1');
insert into library_members (library_id, first_name, last_name, email, username) values (83109948, 'Batholomew', 'Benck', 'bbenck2@army.mil', 'bbenck2');
insert into library_members (library_id, first_name, last_name, email, username) values (78231904, 'Jemimah', 'Castano', 'jcastano3@geocities.com', 'jcastano3');
insert into library_members (library_id, first_name, last_name, email, username) values (37707003, 'Vin', 'Senner', 'vsenner4@freewebs.com', 'vsenner4');
insert into library_members (library_id, first_name, last_name, email, username) values (90983673, 'Hally', 'Vellender', 'hvellender5@123-reg.co.uk', 'hvellender5');
insert into library_members (library_id, first_name, last_name, email, username) values (91575166, 'Denyse', 'Nealon', 'dnealon6@networksolutions.com', 'dnealon6');
insert into library_members (library_id, first_name, last_name, email, username) values (61298677, 'Vikki', 'Lock', 'vlock7@umich.edu', 'vlock7');
insert into library_members (library_id, first_name, last_name, email, username) values (56454808, 'Llywellyn', 'Summerside', 'lsummerside8@feedburner.com', 'lsummerside8');
insert into library_members (library_id, first_name, last_name, email, username) values (17358916, 'Pacorro', 'Ollet', 'pollet9@51.la', 'pollet9');
insert into library_members (library_id, first_name, last_name, email, username) values (72215541, 'Annabela', 'Cripps', 'acrippsa@xrea.com', 'acrippsa');
insert into library_members (library_id, first_name, last_name, email, username) values (97190246, 'Lilli', 'Haukey', 'lhaukeyb@indiatimes.com', 'lhaukeyb');
insert into library_members (library_id, first_name, last_name, email, username) values (28087163, 'Lark', 'Sutton', 'lsuttonc@ucsd.edu', 'lsuttonc');
insert into library_members (library_id, first_name, last_name, email, username) values (82039348, 'Rey', 'Risbie', 'rrisbied@yandex.ru', 'rrisbied');
insert into library_members (library_id, first_name, last_name, email, username) values (50205624, 'Martie', 'Kleine', 'mkleinee@oracle.com', 'mkleinee');
insert into library_members (library_id, first_name, last_name, email, username) values (96782180, 'Ricki', 'Roderick', 'rroderickf@cam.ac.uk', 'rroderickf');
insert into library_members (library_id, first_name, last_name, email, username) values (88759792, 'Petra', 'Pavluk', 'ppavlukg@mail.ru', 'ppavlukg');
insert into library_members (library_id, first_name, last_name, email, username) values (59279844, 'Farra', 'McCane', 'fmccaneh@bloomberg.com', 'fmccaneh');
insert into library_members (library_id, first_name, last_name, email, username) values (85773907, 'Orel', 'Petr', 'opetri@livejournal.com', 'opetri');
insert into library_members (library_id, first_name, last_name, email, username) values (18753345, 'Tawnya', 'Cholton', 'tcholtonj@mysql.com', 'tcholtonj');
insert into library_members (library_id, first_name, last_name, email, username) values (67200953, 'Lynelle', 'Billing', 'lbillingk@google.ru', 'lbillingk');
insert into library_members (library_id, first_name, last_name, email, username) values (14875897, 'Laurella', 'Catonne', 'lcatonnel@infoseek.co.jp', 'lcatonnel');
insert into library_members (library_id, first_name, last_name, email, username) values (19177531, 'Perkin', 'Brislane', 'pbrislanem@google.nl', 'pbrislanem');
insert into library_members (library_id, first_name, last_name, email, username) values (27595347, 'Hyatt', 'Streater', 'hstreatern@uiuc.edu', 'hstreatern');
insert into library_members (library_id, first_name, last_name, email, username) values (56688464, 'Ardisj', 'Sapshed', 'asapshedo@github.io', 'asapshedo');
insert into library_members (library_id, first_name, last_name, email, username) values (23852466, 'Fritz', 'Oxtaby', 'foxtabyp@guardian.co.uk', 'foxtabyp');
insert into library_members (library_id, first_name, last_name, email, username) values (87593799, 'Konstantine', 'Fairbard', 'kfairbardq@ameblo.jp', 'kfairbardq');
insert into library_members (library_id, first_name, last_name, email, username) values (99300376, 'Joyce', 'Gallichan', 'jgallichanr@php.net', 'jgallichanr');
insert into library_members (library_id, first_name, last_name, email, username) values (44455283, 'Jessika', 'Rawsthorne', 'jrawsthornes@hubpages.com', 'jrawsthornes');
insert into library_members (library_id, first_name, last_name, email, username) values (25739497, 'Erastus', 'Counihan', 'ecounihant@furl.net', 'ecounihant');
insert into library_members (library_id, first_name, last_name, email, username) values (83749545, 'Kata', 'Grisedale', 'kgrisedaleu@sun.com', 'kgrisedaleu');
insert into library_members (library_id, first_name, last_name, email, username) values (83111481, 'Lynette', 'Langsdon', 'llangsdonv@unblog.fr', 'llangsdonv');
insert into library_members (library_id, first_name, last_name, email, username) values (43244903, 'Reyna', 'Plett', 'rplettw@hubpages.com', 'rplettw');
insert into library_members (library_id, first_name, last_name, email, username) values (76110645, 'Orelee', 'Sprowle', 'osprowlex@nydailynews.com', 'osprowlex');
insert into library_members (library_id, first_name, last_name, email, username) values (99547244, 'Kilian', 'Pheasey', 'kpheaseyy@nature.com', 'kpheaseyy');
insert into library_members (library_id, first_name, last_name, email, username) values (25950558, 'Martino', 'Bywater', 'mbywaterz@washingtonpost.com', 'mbywaterz');
insert into library_members (library_id, first_name, last_name, email, username) values (95217204, 'Ida', 'Olland', 'iolland10@clickbank.net', 'iolland10');
insert into library_members (library_id, first_name, last_name, email, username) values (23824620, 'Wain', 'Booler', 'wbooler11@tripod.com', 'wbooler11');
insert into library_members (library_id, first_name, last_name, email, username) values (87457837, 'Jo', 'Brew', 'jbrew12@slashdot.org', 'jbrew12');
insert into library_members (library_id, first_name, last_name, email, username) values (14099058, 'Halette', 'Boorne', 'hboorne13@china.com.cn', 'hboorne13');
insert into library_members (library_id, first_name, last_name, email, username) values (63998098, 'Phedra', 'Waulker', 'pwaulker14@answers.com', 'pwaulker14');
insert into library_members (library_id, first_name, last_name, email, username) values (34860547, 'Erma', 'Isles', 'eisles15@vistaprint.com', 'eisles15');
insert into library_members (library_id, first_name, last_name, email, username) values (92745482, 'Del', 'Dummigan', 'ddummigan16@yellowpages.com', 'ddummigan16');
insert into library_members (library_id, first_name, last_name, email, username) values (60968851, 'Dasya', 'LaBastida', 'dlabastida17@mit.edu', 'dlabastida17');
insert into library_members (library_id, first_name, last_name, email, username) values (27701235, 'Trevar', 'Spearett', 'tspearett18@nih.gov', 'tspearett18');
insert into library_members (library_id, first_name, last_name, email, username) values (15188281, 'Janis', 'Everleigh', 'jeverleigh19@google.it', 'jeverleigh19');
insert into library_members (library_id, first_name, last_name, email, username) values (59243878, 'Cori', 'Brownill', 'cbrownill1a@wufoo.com', 'cbrownill1a');
insert into library_members (library_id, first_name, last_name, email, username) values (91833182, 'Melisse', 'Bidgod', 'mbidgod1b@domainmarket.com', 'mbidgod1b');
insert into library_members (library_id, first_name, last_name, email, username) values (77617746, 'Gleda', 'Lutsch', 'glutsch1c@phpbb.com', 'glutsch1c');
insert into library_members (library_id, first_name, last_name, email, username) values (93887082, 'Amandie', 'Riba', 'ariba1d@nhs.uk', 'ariba1d');
insert into library_members (library_id, first_name, last_name, email, username) values (58662025, 'Kaiser', 'Backshell', 'kbackshell1e@jigsy.com', 'kbackshell1e');
insert into library_members (library_id, first_name, last_name, email, username) values (59507601, 'Faye', 'Cockshott', 'fcockshott1f@apple.com', 'fcockshott1f');
insert into library_members (library_id, first_name, last_name, email, username) values (74561907, 'Finley', 'Plampeyn', 'fplampeyn1g@goo.gl', 'fplampeyn1g');
insert into library_members (library_id, first_name, last_name, email, username) values (82178658, 'Rosene', 'MacDonough', 'rmacdonough1h@cocolog-nifty.com', 'rmacdonough1h');
insert into library_members (library_id, first_name, last_name, email, username) values (44702945, 'Sephira', 'Point', 'spoint1i@fda.gov', 'spoint1i');
insert into library_members (library_id, first_name, last_name, email, username) values (57853190, 'Alicia', 'Stutard', 'astutard1j@altervista.org', 'astutard1j');
insert into library_members (library_id, first_name, last_name, email, username) values (39424506, 'Karim', 'Le Noury', 'klenoury1k@w3.org', 'klenoury1k');
insert into library_members (library_id, first_name, last_name, email, username) values (32608366, 'Eamon', 'Grutchfield', 'egrutchfield1l@ucoz.com', 'egrutchfield1l');
insert into library_members (library_id, first_name, last_name, email, username) values (71753538, 'Sara', 'Jeffs', 'sjeffs1m@bing.com', 'sjeffs1m');
insert into library_members (library_id, first_name, last_name, email, username) values (47440253, 'Rowen', 'Paff', 'rpaff1n@blinklist.com', 'rpaff1n');
insert into library_members (library_id, first_name, last_name, email, username) values (10628844, 'Cathrine', 'Conochie', 'cconochie1o@fc2.com', 'cconochie1o');
insert into library_members (library_id, first_name, last_name, email, username) values (14381979, 'Analise', 'Cornwell', 'acornwell1p@shop-pro.jp', 'acornwell1p');
insert into library_members (library_id, first_name, last_name, email, username) values (81455226, 'Starla', 'Spickett', 'sspickett1q@biblegateway.com', 'sspickett1q');
insert into library_members (library_id, first_name, last_name, email, username) values (16327246, 'Katrina', 'Ciciari', 'kciciari1r@is.gd', 'kciciari1r');
insert into library_members (library_id, first_name, last_name, email, username) values (79959737, 'Lula', 'Braganza', 'lbraganza1s@phpbb.com', 'lbraganza1s');
insert into library_members (library_id, first_name, last_name, email, username) values (65905656, 'Kincaid', 'Forder', 'kforder1t@squidoo.com', 'kforder1t');
insert into library_members (library_id, first_name, last_name, email, username) values (88222553, 'Georg', 'Bofield', 'gbofield1u@prnewswire.com', 'gbofield1u');
insert into library_members (library_id, first_name, last_name, email, username) values (87325359, 'Riobard', 'Burges', 'rburges1v@creativecommons.org', 'rburges1v');
insert into library_members (library_id, first_name, last_name, email, username) values (61431743, 'Harlan', 'Rimbault', 'hrimbault1w@themeforest.net', 'hrimbault1w');
insert into library_members (library_id, first_name, last_name, email, username) values (43299678, 'Rossie', 'Ondrak', 'rondrak1x@unc.edu', 'rondrak1x');
insert into library_members (library_id, first_name, last_name, email, username) values (72376204, 'Korrie', 'Burney', 'kburney1y@altervista.org', 'kburney1y');
insert into library_members (library_id, first_name, last_name, email, username) values (46331931, 'Edee', 'Luard', 'eluard1z@diigo.com', 'eluard1z');
insert into library_members (library_id, first_name, last_name, email, username) values (65608546, 'Newton', 'Stanman', 'nstanman20@google.cn', 'nstanman20');
insert into library_members (library_id, first_name, last_name, email, username) values (28595286, 'Liuka', 'Mac Geaney', 'lmacgeaney21@about.com', 'lmacgeaney21');
insert into library_members (library_id, first_name, last_name, email, username) values (23343450, 'Darcy', 'Olrenshaw', 'dolrenshaw22@ed.gov', 'dolrenshaw22');
insert into library_members (library_id, first_name, last_name, email, username) values (98386307, 'Cecil', 'MacMoyer', 'cmacmoyer23@ft.com', 'cmacmoyer23');
insert into library_members (library_id, first_name, last_name, email, username) values (61985065, 'Wynne', 'Screase', 'wscrease24@home.pl', 'wscrease24');
insert into library_members (library_id, first_name, last_name, email, username) values (72173347, 'Marisa', 'Jacquot', 'mjacquot25@sphinn.com', 'mjacquot25');
insert into library_members (library_id, first_name, last_name, email, username) values (92642914, 'Rollie', 'Hanlin', 'rhanlin26@example.com', 'rhanlin26');
insert into library_members (library_id, first_name, last_name, email, username) values (25907234, 'Tomi', 'Olford', 'tolford27@lulu.com', 'tolford27');
insert into library_members (library_id, first_name, last_name, email, username) values (58186688, 'Vania', 'Radke', 'vradke28@vinaora.com', 'vradke28');
insert into library_members (library_id, first_name, last_name, email, username) values (53084963, 'Keenan', 'Sapsforde', 'ksapsforde29@bing.com', 'ksapsforde29');
insert into library_members (library_id, first_name, last_name, email, username) values (35801828, 'Garold', 'Britten', 'gbritten2a@upenn.edu', 'gbritten2a');
insert into library_members (library_id, first_name, last_name, email, username) values (12273625, 'Rodolfo', 'Coslitt', 'rcoslitt2b@berkeley.edu', 'rcoslitt2b');
insert into library_members (library_id, first_name, last_name, email, username) values (98402200, 'Roberto', 'Robertsen', 'rrobertsen2c@hatena.ne.jp', 'rrobertsen2c');
insert into library_members (library_id, first_name, last_name, email, username) values (69712204, 'Kiele', 'Aldins', 'kaldins2d@istockphoto.com', 'kaldins2d');
insert into library_members (library_id, first_name, last_name, email, username) values (65209243, 'Yasmeen', 'Rosewarne', 'yrosewarne2e@canalblog.com', 'yrosewarne2e');
insert into library_members (library_id, first_name, last_name, email, username) values (19406279, 'Calypso', 'Peascod', 'cpeascod2f@furl.net', 'cpeascod2f');
insert into library_members (library_id, first_name, last_name, email, username) values (59040008, 'Catie', 'Allbut', 'callbut2g@1und1.de', 'callbut2g');
insert into library_members (library_id, first_name, last_name, email, username) values (50352005, 'Natalya', 'Caltun', 'ncaltun2h@paypal.com', 'ncaltun2h');
insert into library_members (library_id, first_name, last_name, email, username) values (88642692, 'Frederica', 'Winnard', 'fwinnard2i@google.nl', 'fwinnard2i');
insert into library_members (library_id, first_name, last_name, email, username) values (90555092, 'Steffen', 'Fergie', 'sfergie2j@bloglines.com', 'sfergie2j');
insert into library_members (library_id, first_name, last_name, email, username) values (37508802, 'Oliver', 'Cowdry', 'ocowdry2k@lycos.com', 'ocowdry2k');
insert into library_members (library_id, first_name, last_name, email, username) values (56745281, 'Kayley', 'Kimmitt', 'kkimmitt2l@xrea.com', 'kkimmitt2l');
insert into library_members (library_id, first_name, last_name, email, username) values (39534906, 'Jessy', 'Summerson', 'jsummerson2m@trellian.com', 'jsummerson2m');
insert into library_members (library_id, first_name, last_name, email, username) values (94362687, 'Jonell', 'Fillary', 'jfillary2n@people.com.cn', 'jfillary2n');
insert into library_members (library_id, first_name, last_name, email, username) values (94843455, 'Sandy', 'Gatch', 'sgatch2o@gov.uk', 'sgatch2o');
insert into library_members (library_id, first_name, last_name, email, username) values (98871727, 'Port', 'Robion', 'probion2p@statcounter.com', 'probion2p');
insert into library_members (library_id, first_name, last_name, email, username) values (85060915, 'Pepita', 'Bradneck', 'pbradneck2q@simplemachines.org', 'pbradneck2q');
insert into library_members (library_id, first_name, last_name, email, username) values (29739813, 'Joline', 'Stealfox', 'jstealfox2r@deliciousdays.com', 'jstealfox2r');


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO loans 
SELECT 
  library_members.library_id, 
  books.isbn 
FROM 
  library_members, 
  books 
ORDER BY 
  random() 
LIMIT 
  1000;
