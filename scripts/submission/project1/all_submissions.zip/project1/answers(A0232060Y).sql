/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* In an online shopping platform, customers can purchase goods by directly having contact
with the sellers and sellers will get the order information promptly. The profile of customers 
has already been recorded in the system and will be obtained by sellers to fulfill the order. 
The customers' profiles include seven types of information, that are id, cust_id,first name, last name,
email, gender and city. On the other hand, the order will be received once the customer confirm the purchase. 
The system will automatically generate order id numbers and assign them to each particular transaction.
The process also requires the input of payment method that is the type of credit card. In addition,
the price of product, the date of purchase will be stored as well. Therefore, the final summary of 
order information on the side of sellers will include six types of data. To be specific, they are
id, order_id, seller_id, order_value, date and payment. Meanwhile, there is an action for placing order
that connects the buyers to sellers. The information of customer_id will match to one of the order_id in association.
The code is written for PostgreSQL.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE Customer (
  id character varying,
  Cust_id character varying (50), 
  first_name character varying(50)NOT NULL,
  last_name character varying(50)NOT NULL,
  email character varying(50)NOT NULL,
  gender character varying(50)NOT NULL,
  Customer_city character varying(50)NOT NULL,
  PRIMARY KEY (id));

CREATE TABLE Orders (
  id character varying,
  Order_id character varying(50), 
  Seller_id character varying(50)NOT NULL,
  Order_value character varying(50)NOT NULL,
  Order_date date,
  Payment character varying(50)NOT NULL,
  PRIMARY KEY (id));

CREATE TABLE Places ( 
  Cust_id character varying(50),
  Order_id character varying(50)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (1, '4389787225', 'Orson', 'Standage', 'ostandage0@barnesandnoble.com', 'Male', 'Santa Elena de Uairén');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (2, '5754719264', 'Hettie', 'Guillford', 'hguillford1@engadget.com', 'Female', 'Fuyang');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (3, '0670172022', 'Gabriel', 'McCandie', 'gmccandie2@ask.com', 'Female', 'Oslo');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (4, '6660842721', 'Taffy', 'Cawcutt', 'tcawcutt3@chicagotribune.com', 'Female', 'Stara Błotnica');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (5, '1752380223', 'Stoddard', 'Dicty', 'sdicty4@baidu.com', 'Male', 'Sainte-Luce-sur-Loire');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (6, '1577136411', 'Lilith', 'Sherwin', 'lsherwin5@ibm.com', 'Male', 'Kumane');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (7, '2049376138', 'Candace', 'Pym', 'cpym6@si.edu', 'Female', 'San José de Miranda');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (8, '2057136876', 'Morganne', 'Hawkeswood', 'mhawkeswood7@zimbio.com', 'Female', 'Zhinvali');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (9, '8963753565', 'Blane', 'Brosetti', 'bbrosetti8@cdbaby.com', 'Male', 'Bolondrón');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (10, '7232164572', 'Tamar', 'Sebastian', 'tsebastian9@topsy.com', 'Female', 'Las Tunas');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (11, '1775335585', 'Moses', 'Diamond', 'mdiamonda@cbsnews.com', 'Male', 'San Rafael');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (12, '9935655180', 'Lucine', 'Knuckles', 'lknucklesb@ibm.com', 'Male', 'Marseille');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (13, '1866204432', 'Cordie', 'Boas', 'cboasc@csmonitor.com', 'Male', 'Píritu');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (14, '1317548825', 'Curtis', 'Baddeley', 'cbaddeleyd@google.cn', 'Female', 'Rimbo');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (15, '2671312970', 'Happy', 'O''Shavlan', 'hoshavlane@sakura.ne.jp', 'Female', 'Třemošnice');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (16, '5985346188', 'Cass', 'Zellmer', 'czellmerf@twitter.com', 'Female', 'Yujia');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (17, '1351537067', 'Sidnee', 'Bellows', 'sbellowsg@domainmarket.com', 'Male', 'Xiancun');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (18, '5756000313', 'Yank', 'Mulvaney', 'ymulvaneyh@narod.ru', 'Female', 'Ndwedwe');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (19, '6745047195', 'Torey', 'Tanzer', 'ttanzeri@deliciousdays.com', 'Male', 'Auxerre');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (20, '2508719331', 'Say', 'Redihalgh', 'sredihalghj@trellian.com', 'Male', 'Sucre');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (21, '3485862932', 'Inglebert', 'Chatenier', 'ichatenierk@wikispaces.com', 'Male', 'Borovany');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (22, '9635688016', 'Janet', 'Heakey', 'jheakeyl@huffingtonpost.com', 'Female', 'Sōja');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (23, '4539595199', 'Jamil', 'Bummfrey', 'jbummfreym@technorati.com', 'Female', 'Xêgar');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (24, '3928352717', 'Edgard', 'Pearn', 'epearnn@1und1.de', 'Male', 'Macapo');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (25, '0232695415', 'Melisent', 'Jaskiewicz', 'mjaskiewiczo@wp.com', 'Female', 'Traganón');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (26, '1092309276', 'Nola', 'Talboy', 'ntalboyp@zdnet.com', 'Male', 'Ruo');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (27, '0870379585', 'Patricia', 'Halloway', 'phallowayq@bigcartel.com', 'Male', 'Longwan');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (28, '3661098799', 'Sigvard', 'Shotboult', 'sshotboultr@tinyurl.com', 'Male', 'Jinping');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (29, '8857573877', 'Saundra', 'Benzies', 'sbenziess@shop-pro.jp', 'Male', 'Krajenka');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (30, '8588219670', 'Harmony', 'Aspden', 'haspdent@ustream.tv', 'Female', 'Dourados');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (31, '3531080067', 'Allix', 'Croson', 'acrosonu@harvard.edu', 'Female', 'Phu Kam Yao');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (32, '6155677182', 'Nico', 'Bonsul', 'nbonsulv@webnode.com', 'Male', 'Ipirá');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (33, '8719352247', 'Grayce', 'Wind', 'gwindw@go.com', 'Male', 'Guaíba');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (34, '1796276049', 'Anabelle', 'Duchesne', 'aduchesnex@wiley.com', 'Female', 'Oskarshamn');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (35, '8442173382', 'Caralie', 'Leven', 'cleveny@pinterest.com', 'Female', 'Shreveport');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (36, '5330588987', 'Ilyse', 'Allsobrook', 'iallsobrookz@creativecommons.org', 'Female', 'Shuinan');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (37, '4649165148', 'Manon', 'Blachford', 'mblachford10@vistaprint.com', 'Male', 'Rezé');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (38, '9820276780', 'Flore', 'Bolliver', 'fbolliver11@google.it', 'Female', 'Mbanza-Ngungu');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (39, '8054430337', 'Wallace', 'Rainon', 'wrainon12@admin.ch', 'Female', 'Jiangzao');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (40, '1635912822', 'Veda', 'McPake', 'vmcpake13@jiathis.com', 'Male', 'Luzhang');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (41, '9327435958', 'Ulrich', 'Elmhirst', 'uelmhirst14@woothemes.com', 'Male', 'Chrysó');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (42, '9029318902', 'Robyn', 'Dumphreys', 'rdumphreys15@hud.gov', 'Male', 'Dédougou');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (43, '8448942604', 'Ralph', 'Hayton', 'rhayton16@ustream.tv', 'Male', 'Velké Losiny');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (44, '0800934059', 'Brenna', 'Bisson', 'bbisson17@reference.com', 'Female', 'Bara Datu');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (45, '3313348572', 'Matthew', 'Emerton', 'memerton18@kickstarter.com', 'Female', 'Veiros');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (46, '0220437947', 'Tobin', 'Sowman', 'tsowman19@arizona.edu', 'Female', 'Joševa');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (47, '6042778978', 'Gerda', 'Vasilkov', 'gvasilkov1a@webnode.com', 'Male', 'Agkathiá');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (48, '0524117632', 'Fidel', 'Konzel', 'fkonzel1b@addtoany.com', 'Female', 'Farah');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (49, '6785159296', 'Ole', 'Fosher', 'ofosher1c@liveinternet.ru', 'Female', 'Ajuy');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (50, '4313738940', 'Ann-marie', 'Jagson', 'ajagson1d@house.gov', 'Male', 'Tayu');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (51, '5482430049', 'Tera', 'Alastair', 'talastair1e@wufoo.com', 'Male', 'Khafizan');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (52, '2295056349', 'Demetris', 'Booth', 'dbooth1f@cloudflare.com', 'Female', 'Tiechanggou');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (53, '2946008177', 'Mariya', 'Liddall', 'mliddall1g@indiegogo.com', 'Male', 'Zhenping Chengguanzhen');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (54, '5359242132', 'Woodrow', 'Farfull', 'wfarfull1h@youku.com', 'Female', 'Tsalka');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (55, '4909349111', 'Cyndi', 'Killiam', 'ckilliam1i@pcworld.com', 'Female', 'Araxá');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (56, '3145488961', 'Bond', 'Espada', 'bespada1j@phpbb.com', 'Male', 'Al Jawādīyah');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (57, '7479019009', 'Sansone', 'Wiggall', 'swiggall1k@unc.edu', 'Male', 'Laleng');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (58, '7931478827', 'Velvet', 'Bonnick', 'vbonnick1l@sourceforge.net', 'Male', 'Jargalant');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (59, '5385866288', 'Nadiya', 'Giberd', 'ngiberd1m@alexa.com', 'Male', 'Shadrinsk');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (60, '7136970253', 'Kareem', 'Cadany', 'kcadany1n@cnbc.com', 'Male', 'Valencia');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (61, '7726018143', 'Jacenta', 'Serginson', 'jserginson1o@slate.com', 'Female', 'Hatogaya-honchō');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (62, '8457927388', 'Esther', 'Frith', 'efrith1p@drupal.org', 'Female', 'Insiza');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (63, '5854190079', 'Harmonia', 'Spensly', 'hspensly1q@economist.com', 'Female', 'Huyuan');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (64, '0248719076', 'Alyce', 'Quiddinton', 'aquiddinton1r@liveinternet.ru', 'Male', 'Chhātak');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (65, '8606630675', 'Karna', 'Hardstaff', 'khardstaff1s@mysql.com', 'Male', 'Leme');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (66, '0186289669', 'Jackqueline', 'Babe', 'jbabe1t@jalbum.net', 'Female', 'Pashiya');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (67, '7933019625', 'Norbie', 'Carbin', 'ncarbin1u@artisteer.com', 'Male', 'Paderne');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (68, '0871442132', 'Corenda', 'Blant', 'cblant1v@example.com', 'Male', 'Linghu');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (69, '3387940580', 'Marsiella', 'Maren', 'mmaren1w@dion.ne.jp', 'Male', 'Dālbandīn');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (70, '8918333234', 'Paige', 'Bauduin', 'pbauduin1x@mashable.com', 'Female', 'Rote');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (71, '7149116027', 'Adrea', 'Dikels', 'adikels1y@purevolume.com', 'Male', 'Miastko');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (72, '6830080363', 'Currey', 'Connealy', 'cconnealy1z@nymag.com', 'Female', 'Porto-Novo');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (73, '3894081007', 'Raina', 'Hawkes', 'rhawkes20@nasa.gov', 'Male', 'Buhe');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (74, '4034067748', 'Odelinda', 'Dinse', 'odinse21@phoca.cz', 'Female', 'Gurinai');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (75, '7168315684', 'Gerick', 'Tow', 'gtow22@usnews.com', 'Male', 'Longos');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (76, '2589648219', 'Mack', 'Fairney', 'mfairney23@dot.gov', 'Male', 'Magsalangi');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (77, '2241579734', 'Aggy', 'Pover', 'apover24@ameblo.jp', 'Male', 'Rathwire');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (78, '7628247318', 'Missie', 'Geldeford', 'mgeldeford25@altervista.org', 'Female', 'Usab');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (79, '0129696374', 'Salomone', 'Lelliott', 'slelliott26@bandcamp.com', 'Female', 'Foz do Iguaçu');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (80, '2873327464', 'Cairistiona', 'Prigg', 'cprigg27@prweb.com', 'Female', 'Funaishikawa');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (81, '0369705394', 'Saree', 'Livingstone', 'slivingstone28@xrea.com', 'Female', 'Cibinong');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (82, '5932446668', 'Ichabod', 'Paliser', 'ipaliser29@uiuc.edu', 'Female', 'Zaraza');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (83, '2315196485', 'Dominik', 'Deason', 'ddeason2a@yolasite.com', 'Male', 'Ojrzeń');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (84, '1747783927', 'Camila', 'Clampett', 'cclampett2b@harvard.edu', 'Female', 'Bella Vista');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (85, '3227380846', 'Marco', 'Michele', 'mmichele2c@auda.org.au', 'Male', 'Patarrá');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (86, '5281938398', 'Barty', 'Pineaux', 'bpineaux2d@dedecms.com', 'Female', 'Greytown');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (87, '6894069689', 'Gussi', 'Dunstone', 'gdunstone2e@indiegogo.com', 'Female', 'Paris 13');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (88, '0150801505', 'Bogart', 'Satcher', 'bsatcher2f@about.me', 'Male', 'Chengdong');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (89, '3707686930', 'Carey', 'Sanbrooke', 'csanbrooke2g@nih.gov', 'Male', 'Vrakháti');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (90, '2148332759', 'Gearard', 'Fomichkin', 'gfomichkin2h@nasa.gov', 'Male', 'Ebak');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (91, '6632297528', 'Georgina', 'Inggall', 'ginggall2i@artisteer.com', 'Female', 'Riit');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (92, '7803576311', 'Rosalinda', 'Letherbury', 'rletherbury2j@wisc.edu', 'Male', 'Lianhua');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (93, '4877011552', 'Bentlee', 'Leavens', 'bleavens2k@51.la', 'Female', 'Novolugovoye');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (94, '1320135919', 'Wynn', 'Pettersen', 'wpettersen2l@live.com', 'Female', 'Kruengraya');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (95, '8117468840', 'Marge', 'Miskin', 'mmiskin2m@hatena.ne.jp', 'Male', 'San Francisco');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (96, '2076830855', 'Filia', 'Aronow', 'faronow2n@sphinn.com', 'Female', 'Heilongkou');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (97, '3485946613', 'Mart', 'Flacke', 'mflacke2o@nymag.com', 'Female', 'Oinoússes');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (98, '7261583170', 'Yvonne', 'Yurygyn', 'yyurygyn2p@ustream.tv', 'Male', 'Victoria');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (99, '2568527471', 'Albert', 'Micka', 'amicka2q@instagram.com', 'Male', 'Zvëzdnyy');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (100, '2124009818', 'Fannie', 'Goudard', 'fgoudard2r@eventbrite.com', 'Female', 'Janes');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (101, '7983108060', 'Jeremy', 'Vasilischev', 'jvasilischev2s@alibaba.com', 'Male', 'Lawa-an');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (102, '9272951933', 'Darlene', 'Crowson', 'dcrowson2t@redcross.org', 'Female', 'Buldon');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (103, '1541040074', 'Annetta', 'Vigars', 'avigars2u@youtu.be', 'Female', 'Amsterdam Westpoort');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (104, '2335499599', 'Leilah', 'Maggs', 'lmaggs2v@joomla.org', 'Male', 'Angan');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (105, '0057078572', 'Lorraine', 'Yokelman', 'lyokelman2w@cbsnews.com', 'Female', 'Degan');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (106, '3387294360', 'Kalil', 'Gerrie', 'kgerrie2x@cpanel.net', 'Female', 'Santa Catalina');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (107, '2864369648', 'See', 'Wayman', 'swayman2y@goo.gl', 'Male', 'Dnipryany');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (108, '2461475490', 'Lela', 'Auletta', 'lauletta2z@hatena.ne.jp', 'Male', 'Balung Barat');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (109, '2205179306', 'Damara', 'Handman', 'dhandman30@fda.gov', 'Female', 'An Naşr');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (110, '2548712745', 'Sharl', 'Chatelot', 'schatelot31@webnode.com', 'Female', 'Zhangaqorghan');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (111, '8491284338', 'Leshia', 'Beller', 'lbeller32@thetimes.co.uk', 'Male', 'Nagrak');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (112, '3730578049', 'Pembroke', 'Keighly', 'pkeighly33@ucoz.ru', 'Male', 'Jianghua');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (113, '3378842636', 'Dani', 'Bever', 'dbever34@twitter.com', 'Male', 'Babat');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (114, '2513781937', 'Goldia', 'Divisek', 'gdivisek35@com.com', 'Male', 'Midlands');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (115, '9003890986', 'Tallou', 'Benedito', 'tbenedito36@homestead.com', 'Male', 'Cumanayagua');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (116, '3561395163', 'Myrlene', 'Adshed', 'madshed37@360.cn', 'Female', 'Matangpayang');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (117, '4192072580', 'Rosa', 'Becom', 'rbecom38@spotify.com', 'Male', 'Banjeru');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (118, '9454139215', 'Angeline', 'Adcocks', 'aadcocks39@biblegateway.com', 'Female', 'Huazhuang');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (119, '5020600946', 'Sandy', 'Cometto', 'scometto3a@dailymotion.com', 'Male', 'Maiduguri');
insert into customer (id, Cust_id, first_name, last_name, email, gender, Customer_city) values (120, '6735301307', 'Wolfgang', 'Verdy', 'wverdy3b@networkadvertising.org', 'Male', 'Zavet');

SELECT
*
FROM
customer;

insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (1, '5108052715', '8624730538', '$31.16', '3/27/2021', 'laser');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (2, '3110182629', '9817620018', '$77.19', '10/10/2020', 'diners-club-international');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (3, '4998492764', '6842307821', '$77.18', '5/28/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (4, '9187136783', '1054960798', '$49.23', '8/9/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (5, '5515878884', '1409469891', '$52.96', '2/24/2021', 'diners-club-enroute');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (6, '4356724704', '8450144485', '$31.94', '3/21/2021', 'mastercard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (7, '7957758045', '0702652822', '$55.13', '10/21/2020', 'diners-club-carte-blanche');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (8, '4524254536', '1011399806', '$76.32', '1/11/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (9, '5620567141', '9523988018', '$5.95', '8/29/2020', 'visa');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (10, '9446299179', '1598686135', '$87.76', '9/28/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (11, '5895372147', '9513933717', '$66.01', '11/24/2020', 'maestro');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (12, '7122961184', '3727915250', '$84.70', '11/29/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (13, '6498464194', '3282583982', '$27.75', '5/2/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (14, '4924865656', '8539339528', '$97.58', '5/16/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (15, '6472795576', '3133554883', '$77.20', '8/2/2021', 'china-unionpay');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (16, '4567172647', '2252218029', '$17.69', '7/29/2021', 'americanexpress');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (17, '8874031440', '0655466452', '$29.58', '4/23/2021', 'laser');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (18, '8826893659', '6850718304', '$63.41', '2/19/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (19, '9540135958', '5132494447', '$77.84', '6/17/2021', 'mastercard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (20, '4063831388', '0075680092', '$5.70', '6/13/2021', 'mastercard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (21, '7625095282', '2707450596', '$9.00', '11/24/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (22, '7990843595', '1517391768', '$15.96', '3/26/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (23, '4605856870', '1968165223', '$54.76', '6/11/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (24, '7704875167', '9536300036', '$60.60', '2/15/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (25, '1175011118', '5952224644', '$51.90', '11/9/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (26, '3447959649', '8120350383', '$74.99', '9/14/2020', 'diners-club-enroute');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (27, '7679656118', '3672482447', '$96.00', '3/17/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (28, '2375681177', '7362567723', '$53.95', '4/26/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (29, '5567360800', '6243990338', '$31.30', '6/25/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (30, '7447048240', '3562263279', '$92.40', '5/9/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (31, '3420074328', '7561818386', '$82.74', '6/11/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (32, '5352835928', '9858973470', '$66.13', '9/28/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (33, '4971052224', '1321081669', '$53.09', '8/10/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (34, '6648024852', '2132345112', '$21.45', '8/28/2020', 'maestro');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (35, '1479848603', '0608529028', '$10.66', '3/16/2021', 'diners-club-carte-blanche');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (36, '6810058133', '2420681371', '$93.86', '8/28/2020', 'bankcard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (37, '1302852906', '5979636420', '$77.23', '10/22/2020', 'maestro');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (38, '9841004038', '0381748901', '$49.99', '11/29/2020', 'china-unionpay');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (39, '3326224834', '3351146418', '$59.18', '5/17/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (40, '4853647945', '2984422619', '$86.57', '12/17/2020', 'maestro');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (41, '0773811575', '1769000321', '$69.33', '12/9/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (42, '9854683516', '6010985870', '$9.88', '7/15/2021', 'mastercard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (43, '8489681031', '0915968428', '$29.60', '1/26/2021', 'switch');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (44, '4943237010', '9167725678', '$70.09', '5/13/2021', 'diners-club-carte-blanche');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (45, '0204705746', '5748411334', '$70.99', '8/9/2021', 'mastercard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (46, '0658302809', '0237328895', '$58.35', '1/4/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (47, '7498961792', '0801379954', '$52.61', '5/4/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (48, '9941936730', '3767513838', '$76.64', '7/7/2021', 'visa-electron');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (49, '1301424935', '8424272013', '$48.80', '4/29/2021', 'china-unionpay');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (50, '8813957610', '3712057474', '$26.25', '9/10/2020', 'visa-electron');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (51, '5449212585', '2306810516', '$88.05', '4/7/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (52, '7708522757', '8970301747', '$6.99', '5/3/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (53, '0165548703', '3100682866', '$46.15', '6/19/2021', 'mastercard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (54, '0889024650', '2080771752', '$5.31', '6/3/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (55, '0259497770', '3786407894', '$26.51', '9/5/2020', 'diners-club-carte-blanche');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (56, '7549925976', '7860476002', '$95.46', '6/26/2021', 'maestro');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (57, '5255619574', '4756059317', '$42.74', '10/14/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (58, '0791057488', '5495898982', '$70.32', '5/28/2021', 'diners-club-us-ca');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (59, '8296397552', '9209304136', '$72.88', '10/30/2020', 'bankcard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (60, '4696757382', '9229912719', '$69.60', '5/10/2021', 'mastercard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (61, '5123758348', '6125036677', '$32.31', '5/17/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (62, '4049469677', '0571512739', '$60.56', '1/16/2021', 'americanexpress');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (63, '1303303019', '6919422166', '$24.00', '10/7/2020', 'mastercard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (64, '0698410335', '8405905073', '$56.75', '10/7/2020', 'switch');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (65, '9176902110', '2314672429', '$81.33', '9/28/2020', 'maestro');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (66, '5425102496', '0163800952', '$82.63', '9/8/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (67, '5699953868', '8233359319', '$38.59', '11/20/2020', 'bankcard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (68, '1775620778', '4576196456', '$13.74', '11/10/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (69, '6504158231', '7254099021', '$65.41', '3/7/2021', 'bankcard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (70, '2876810484', '4726734938', '$45.85', '4/27/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (71, '1096610396', '8433764306', '$52.67', '1/6/2021', 'mastercard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (72, '4255605114', '3856856250', '$34.37', '1/6/2021', 'maestro');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (73, '1901259846', '4579629825', '$35.76', '1/26/2021', 'diners-club-enroute');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (74, '0287407640', '8676084505', '$32.84', '8/17/2021', 'maestro');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (75, '4143450895', '8664407177', '$49.64', '5/7/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (76, '2065956186', '7532185052', '$31.64', '5/10/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (77, '7915900285', '8064781728', '$16.11', '1/29/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (78, '1905100302', '6000064411', '$98.68', '11/14/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (79, '0448021323', '8941478553', '$73.19', '9/14/2020', 'visa');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (80, '3773212283', '2216712698', '$34.56', '2/11/2021', 'switch');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (81, '3810109835', '0168431564', '$27.18', '10/9/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (82, '7682000406', '9210757963', '$42.68', '1/26/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (83, '6315568750', '2171078995', '$80.59', '6/14/2021', 'diners-club-enroute');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (84, '8791101875', '2667364481', '$67.08', '12/22/2020', 'switch');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (85, '9588960290', '4172742017', '$80.54', '8/28/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (86, '2305862725', '1038942721', '$63.21', '10/11/2020', 'laser');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (87, '5540765206', '4110509947', '$49.65', '4/8/2021', 'visa');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (88, '9553154484', '5458267354', '$41.71', '1/14/2021', 'bankcard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (89, '7360498767', '8636241669', '$47.95', '10/8/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (90, '8840046194', '1608079015', '$79.26', '11/9/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (91, '5274215955', '5885549931', '$59.84', '5/13/2021', 'visa-electron');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (92, '4025376954', '2997242142', '$18.38', '11/8/2020', 'maestro');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (93, '9827344994', '7647841815', '$19.67', '5/15/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (94, '9442355376', '8725320262', '$55.27', '2/10/2021', 'instapayment');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (95, '3426394618', '5783382736', '$88.12', '6/30/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (96, '9693181840', '4662145481', '$95.46', '9/21/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (97, '2209738962', '4501705132', '$13.09', '5/14/2021', 'visa-electron');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (98, '2640337629', '6907844419', '$99.37', '2/19/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (99, '6841412796', '2417997908', '$46.15', '1/28/2021', 'china-unionpay');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (100, '5410725859', '1172465223', '$32.56', '11/10/2020', 'mastercard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (101, '9943224053', '7728952145', '$59.88', '8/23/2021', 'china-unionpay');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (102, '6692494079', '1921715480', '$93.15', '11/12/2020', 'mastercard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (103, '7924080023', '6802588439', '$67.17', '9/8/2020', 'visa-electron');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (104, '3026311073', '2878836723', '$70.04', '12/24/2020', 'diners-club-carte-blanche');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (105, '7270915547', '0269402276', '$34.21', '7/29/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (106, '6660480110', '1971815888', '$83.11', '1/8/2021', 'americanexpress');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (107, '0610361317', '9313562944', '$29.58', '11/13/2020', 'visa-electron');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (108, '3187538541', '8992123787', '$64.06', '2/10/2021', 'mastercard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (109, '8161228140', '6574278813', '$77.05', '12/11/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (110, '6071707129', '1253902895', '$34.93', '11/4/2020', 'diners-club-enroute');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (111, '5965809743', '4089614627', '$57.44', '10/9/2020', 'maestro');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (112, '9076559597', '2633189822', '$70.66', '12/16/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (113, '6640917637', '7750921761', '$41.65', '3/1/2021', 'mastercard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (114, '2414155027', '9742680086', '$73.83', '2/10/2021', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (115, '4557587992', '7048779888', '$30.87', '11/19/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (116, '9933175149', '3354085991', '$55.13', '8/26/2020', 'jcb');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (117, '7382410323', '8686302076', '$91.09', '4/5/2021', 'bankcard');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (118, '9013715982', '4874589251', '$13.64', '4/14/2021', 'maestro');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (119, '5034821184', '8726202417', '$60.50', '7/29/2021', 'maestro');
insert into orders (id, Order_id, Seller_id, Order_value, Order_date, Payment) values (120, '6422459491', '2102353818', '$42.39', '4/6/2021', 'maestro');

SELECT
*
FROM
orders;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into places(cust_id,order_id)
select cust_id,order_id
from customer,orders
order by RANDOM()
limit 1000







