/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/
/* Name: Georgius Gary Gunawan
Student ID: A0113028W */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The Zoo Goes Digital

Zoe the zookeeper wants to ensure that all animals in Kent Ridge Zoo get their food and nutrients.
So, she intend to list down what would be the food needed for each animal she takes care in the zoo.
In order to do so, she created three tables in PostgreSQL as follows:
E1 is animal, it consists of common name, scientific name, and headcount of the animals present in the zoo.
E2 is food, it consists of product name and price per kg of food available in the nearby market.
R is eat, it associates animal scientific name from E1 and the food product name from E2 for which they like to eat.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS animal (
common_name VARCHAR(64) UNIQUE NOT NULL,
scientific_name VARCHAR(64) PRIMARY KEY,
headcount INTEGER CHECK(headcount>0));

CREATE TABLE IF NOT EXISTS food (
product_name VARCHAR(64) PRIMARY KEY,
price_per_kg NUMERIC(10,2) CHECK(price_per_kg>0));

CREATE TABLE IF NOT EXISTS eat (
scientific_name VARCHAR(64),
product_name VARCHAR(64));

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* populate table animal */
insert into animal (common_name, scientific_name, headcount) values ('Rhea, greater', 'Rhea americana', 1);
insert into animal (common_name, scientific_name, headcount) values ('Kite, black', 'Milvus migrans', 18);
insert into animal (common_name, scientific_name, headcount) values ('Bushpig', 'Potamochoerus porcus', 11);
insert into animal (common_name, scientific_name, headcount) values ('Cape cobra', 'Naja nivea', 14);
insert into animal (common_name, scientific_name, headcount) values ('Argalis', 'Ovis ammon', 16);
insert into animal (common_name, scientific_name, headcount) values ('Macaque, pig-tailed', 'Macaca nemestrina', 9);
insert into animal (common_name, scientific_name, headcount) values ('Cormorant, flightless', 'Nannopterum harrisi', 11);
insert into animal (common_name, scientific_name, headcount) values ('Langur, gray', 'Semnopithecus entellus', 3);
insert into animal (common_name, scientific_name, headcount) values ('Masked booby', 'Sula dactylatra', 7);
insert into animal (common_name, scientific_name, headcount) values ('Legaan, ground', 'Varanus sp.', 4);
insert into animal (common_name, scientific_name, headcount) values ('Monkey, black spider', 'Ateles paniscus', 16);
insert into animal (common_name, scientific_name, headcount) values ('Lark, horned', 'Eremophila alpestris', 10);
insert into animal (common_name, scientific_name, headcount) values ('Goldeneye, common', 'Bucephala clangula', 8);
insert into animal (common_name, scientific_name, headcount) values ('Greater sage grouse', 'Centrocercus urophasianus', 9);
insert into animal (common_name, scientific_name, headcount) values ('Whale, killer', 'Orcinus orca', 25);
insert into animal (common_name, scientific_name, headcount) values ('Two-toed sloth', 'Choloepus hoffmani', 1);
insert into animal (common_name, scientific_name, headcount) values ('Blue peacock', 'Pavo cristatus', 4);
insert into animal (common_name, scientific_name, headcount) values ('Hyena, brown', 'Hyaena brunnea', 22);
insert into animal (common_name, scientific_name, headcount) values ('Indian porcupine', 'Hystrix indica', 8);
insert into animal (common_name, scientific_name, headcount) values ('Mongoose, eastern dwarf', 'Helogale undulata', 2);
insert into animal (common_name, scientific_name, headcount) values ('Black-capped chickadee', 'Parus atricapillus', 1);
insert into animal (common_name, scientific_name, headcount) values ('Smith''s bush squirrel', 'Paraxerus cepapi', 6);
insert into animal (common_name, scientific_name, headcount) values ('Bettong, brush-tailed', 'Bettongia penicillata', 5);
insert into animal (common_name, scientific_name, headcount) values ('Duck, blue', 'Hymenolaimus malacorhynchus', 10);
insert into animal (common_name, scientific_name, headcount) values ('Stilt, black-winged', 'Himantopus himantopus', 12);
insert into animal (common_name, scientific_name, headcount) values ('Rat, arboral spiny', 'Echimys chrysurus', 21);
insert into animal (common_name, scientific_name, headcount) values ('Australian sea lion', 'Neophoca cinerea', 16);
insert into animal (common_name, scientific_name, headcount) values ('Cat, ringtail', 'Bassariscus astutus', 18);
insert into animal (common_name, scientific_name, headcount) values ('Sheep, american bighorn', 'Ovis canadensis', 2);
insert into animal (common_name, scientific_name, headcount) values ('Insect, stick', 'Leprocaulinus vipera', 9);
insert into animal (common_name, scientific_name, headcount) values ('Galapagos tortoise', 'Geochelone elephantopus', 8);
insert into animal (common_name, scientific_name, headcount) values ('Flicker, field', 'Colaptes campestroides', 18);
insert into animal (common_name, scientific_name, headcount) values ('White-winged tern', 'Chlidonias leucopterus', 16);
insert into animal (common_name, scientific_name, headcount) values ('Tarantula', 'Lasiodora parahybana', 9);
insert into animal (common_name, scientific_name, headcount) values ('Platypus', 'Ornithorhynchus anatinus', 11);
insert into animal (common_name, scientific_name, headcount) values ('Baleen whale', 'Eubalaena australis', 7);
insert into animal (common_name, scientific_name, headcount) values ('Avocet, pied', 'Recurvirostra avosetta', 12);
insert into animal (common_name, scientific_name, headcount) values ('Australian masked owl', 'Tyto novaehollandiae', 22);
insert into animal (common_name, scientific_name, headcount) values ('Paca', 'Agouti paca', 25);
insert into animal (common_name, scientific_name, headcount) values ('Monkey, vervet', 'Cercopithecus aethiops', 6);
insert into animal (common_name, scientific_name, headcount) values ('Red-cheeked cordon bleu', 'Uraeginthus bengalus', 19);
insert into animal (common_name, scientific_name, headcount) values ('Koala', 'Phascolarctos cinereus', 8);
insert into animal (common_name, scientific_name, headcount) values ('Gull, kelp', 'Larus dominicanus', 17);
insert into animal (common_name, scientific_name, headcount) values ('Tortoise, radiated', 'Geochelone radiata', 9);
insert into animal (common_name, scientific_name, headcount) values ('Red howler monkey', 'Alouatta seniculus', 18);
insert into animal (common_name, scientific_name, headcount) values ('Superb starling', 'Lamprotornis superbus', 4);
insert into animal (common_name, scientific_name, headcount) values ('African clawless otter', 'Aonyx capensis', 10);
insert into animal (common_name, scientific_name, headcount) values ('Wolf, common', 'Canis lupus', 16);
insert into animal (common_name, scientific_name, headcount) values ('Long-tailed jaeger', 'Stercorarius longicausus', 14);
insert into animal (common_name, scientific_name, headcount) values ('Galapagos hawk', 'Buteo galapagoensis', 12);
insert into animal (common_name, scientific_name, headcount) values ('Yellow-billed hornbill', 'Tockus flavirostris', 18);
insert into animal (common_name, scientific_name, headcount) values ('Magpie, australian', 'Gymnorhina tibicen', 10);
insert into animal (common_name, scientific_name, headcount) values ('Lechwe, kafue flats', 'Kobus leche robertsi', 13);
insert into animal (common_name, scientific_name, headcount) values ('Lily trotter', 'Actophilornis africanus', 5);
insert into animal (common_name, scientific_name, headcount) values ('Dragon, western bearded', 'Amphibolurus barbatus', 17);
insert into animal (common_name, scientific_name, headcount) values ('Badger, european', 'Meles meles', 23);
insert into animal (common_name, scientific_name, headcount) values ('North American river otter', 'Lutra canadensis', 6);
insert into animal (common_name, scientific_name, headcount) values ('Crab-eating fox', 'Dusicyon thous', 18);
insert into animal (common_name, scientific_name, headcount) values ('Bald eagle', 'Haliaeetus leucocephalus', 15);
insert into animal (common_name, scientific_name, headcount) values ('Porcupine, african', 'Hystrix cristata', 15);
insert into animal (common_name, scientific_name, headcount) values ('Brolga crane', 'Grus rubicundus', 16);
insert into animal (common_name, scientific_name, headcount) values ('Wallaby, red-necked', 'Macropus rufogriseus', 15);
insert into animal (common_name, scientific_name, headcount) values ('Pied cormorant', 'Phalacrocorax varius', 14);
insert into animal (common_name, scientific_name, headcount) values ('Opossum, american virginia', 'Didelphis virginiana', 1);
insert into animal (common_name, scientific_name, headcount) values ('Dragonfly, russian', 'Libellula quadrimaculata', 18);
insert into animal (common_name, scientific_name, headcount) values ('Boar, wild', 'Sus scrofa', 15);
insert into animal (common_name, scientific_name, headcount) values ('Herring gull', 'unavailable', 18);
insert into animal (common_name, scientific_name, headcount) values ('Fox, pampa gray', 'Pseudalopex gymnocercus', 14);
insert into animal (common_name, scientific_name, headcount) values ('Giant armadillo', 'Priodontes maximus', 3);
insert into animal (common_name, scientific_name, headcount) values ('Southern ground hornbill', 'Bucorvus leadbeateri', 12);
insert into animal (common_name, scientific_name, headcount) values ('Mara', 'Dolichitus patagonum', 1);
insert into animal (common_name, scientific_name, headcount) values ('Lesser masked weaver', 'Ploceus intermedius', 20);
insert into animal (common_name, scientific_name, headcount) values ('Common raccoon', 'Procyon lotor', 15);
insert into animal (common_name, scientific_name, headcount) values ('Crane, sarus', 'Grus antigone', 19);
insert into animal (common_name, scientific_name, headcount) values ('Lesser mouse lemur', 'Microcebus murinus', 23);
insert into animal (common_name, scientific_name, headcount) values ('Gecko, ring-tailed', 'Cyrtodactylus louisiadensis', 13);
insert into animal (common_name, scientific_name, headcount) values ('Jungle kangaroo', 'Macropus agilis', 22);
insert into animal (common_name, scientific_name, headcount) values ('Iguana, common green', 'Iguana iguana', 11);
insert into animal (common_name, scientific_name, headcount) values ('Duck, comb', 'Sarkidornis melanotos', 3);
insert into animal (common_name, scientific_name, headcount) values ('Darwin ground finch (unidentified)', 'Geospiza sp.', 25);
insert into animal (common_name, scientific_name, headcount) values ('Emerald green tree boa', 'Boa caninus', 17);
insert into animal (common_name, scientific_name, headcount) values ('Bear, polar', 'Ursus maritimus', 1);
insert into animal (common_name, scientific_name, headcount) values ('Ring-tailed lemur', 'Lemur catta', 12);
insert into animal (common_name, scientific_name, headcount) values ('Yellow mongoose', 'Cynictis penicillata', 10);
insert into animal (common_name, scientific_name, headcount) values ('Deer, white-tailed', 'Odocoilenaus virginianus', 14);
insert into animal (common_name, scientific_name, headcount) values ('Fisher', 'Martes pennanti', 12);
insert into animal (common_name, scientific_name, headcount) values ('Feral rock pigeon', 'Columba livia', 1);
insert into animal (common_name, scientific_name, headcount) values ('Cormorant, neotropic', 'Phalacrocorax brasilianus', 19);
insert into animal (common_name, scientific_name, headcount) values ('Red-billed buffalo weaver', 'Bubalornis niger', 15);
insert into animal (common_name, scientific_name, headcount) values ('African ground squirrel (unidentified)', 'Xerus sp.', 7);
insert into animal (common_name, scientific_name, headcount) values ('Egyptian cobra', 'Naja haje', 5);
insert into animal (common_name, scientific_name, headcount) values ('Gull, silver', 'Larus novaehollandiae', 20);
insert into animal (common_name, scientific_name, headcount) values ('Little grebe', 'Tachybaptus ruficollis', 22);
insert into animal (common_name, scientific_name, headcount) values ('Frilled dragon', 'Chlamydosaurus kingii', 3);
insert into animal (common_name, scientific_name, headcount) values ('Squirrel, red', 'Tamiasciurus hudsonicus', 23);
insert into animal (common_name, scientific_name, headcount) values ('Asian false vampire bat', 'Megaderma spasma', 3);
insert into animal (common_name, scientific_name, headcount) values ('Sambar', 'Cervus unicolor', 7);
insert into animal (common_name, scientific_name, headcount) values ('Devil, tasmanian', 'Sarcophilus harrisii', 12);
insert into animal (common_name, scientific_name, headcount) values ('Antelope ground squirrel', 'Ammospermophilus nelsoni', 11);
insert into animal (common_name, scientific_name, headcount) values ('Dove, emerald-spotted wood', 'Turtur chalcospilos', 11);

/* populate table food */
insert into food (product_name, price_per_kg) values ('Capon - Breast, Wing On', 31.41);
insert into food (product_name, price_per_kg) values ('Beef - Ground Lean Fresh', 41.51);
insert into food (product_name, price_per_kg) values ('Syrup - Pancake', 23.74);
insert into food (product_name, price_per_kg) values ('Lentils - Green, Dry', 6.63);
insert into food (product_name, price_per_kg) values ('Cheese - Cheddar, Old White', 21.31);
insert into food (product_name, price_per_kg) values ('Water - Spring Water, 355 Ml', 21.99);
insert into food (product_name, price_per_kg) values ('Teriyaki Sauce', 7.99);
insert into food (product_name, price_per_kg) values ('Tomato Paste', 4.96);
insert into food (product_name, price_per_kg) values ('Cucumber - English', 46.71);
insert into food (product_name, price_per_kg) values ('Juice Peach Nectar', 18.99);
insert into food (product_name, price_per_kg) values ('Chocolate - Unsweetened', 44.58);
insert into food (product_name, price_per_kg) values ('Nori Sea Weed - Gold Label', 30.73);
insert into food (product_name, price_per_kg) values ('Tea - Darjeeling, Azzura', 14.85);
insert into food (product_name, price_per_kg) values ('Tomato - Tricolor Cherry', 45.81);
insert into food (product_name, price_per_kg) values ('Rabbit - Saddles', 39.52);
insert into food (product_name, price_per_kg) values ('Icecream - Dibs', 20.12);
insert into food (product_name, price_per_kg) values ('Kahlua', 9.32);
insert into food (product_name, price_per_kg) values ('Ice Cream Bar - Drumstick', 41.46);
insert into food (product_name, price_per_kg) values ('Juice - Lagoon Mango', 38.84);
insert into food (product_name, price_per_kg) values ('Bar Bran Honey Nut', 39.15);
insert into food (product_name, price_per_kg) values ('Sausage - Breakfast', 1.14);
insert into food (product_name, price_per_kg) values ('Wine - Magnotta, Merlot Sr Vqa', 1.4);
insert into food (product_name, price_per_kg) values ('Wine - Sake', 7.69);
insert into food (product_name, price_per_kg) values ('Juice - Cranberry, 341 Ml', 30.08);
insert into food (product_name, price_per_kg) values ('Beans - Black Bean, Preserved', 38.91);
insert into food (product_name, price_per_kg) values ('Wine - Vovray Sec Domaine Huet', 32.76);
insert into food (product_name, price_per_kg) values ('Cheese - Cheddar, Mild', 38.75);
insert into food (product_name, price_per_kg) values ('Pie Shells 10', 46.82);
insert into food (product_name, price_per_kg) values ('Chicken - Leg, Fresh', 36.51);
insert into food (product_name, price_per_kg) values ('Pork - Kidney', 15.34);
insert into food (product_name, price_per_kg) values ('Ginger - Ground', 49.86);
insert into food (product_name, price_per_kg) values ('Pomello', 12.2);
insert into food (product_name, price_per_kg) values ('Cookies - Oreo, 4 Pack', 29.86);
insert into food (product_name, price_per_kg) values ('Cheese - Mozzarella, Shredded', 42.2);
insert into food (product_name, price_per_kg) values ('Carbonated Water - White Grape', 4.06);
insert into food (product_name, price_per_kg) values ('Pastry - Chocolate Marble Tea', 42.84);
insert into food (product_name, price_per_kg) values ('Lettuce - Frisee', 17.57);
insert into food (product_name, price_per_kg) values ('Skirt - 24 Foot', 5.04);
insert into food (product_name, price_per_kg) values ('Bandage - Flexible Neon', 14.17);
insert into food (product_name, price_per_kg) values ('Pepper - Scotch Bonnet', 20.15);
insert into food (product_name, price_per_kg) values ('Lamb - Ground', 28.64);
insert into food (product_name, price_per_kg) values ('Wine - Domaine Boyar Royal', 1.61);
insert into food (product_name, price_per_kg) values ('Maple Syrup', 2.76);
insert into food (product_name, price_per_kg) values ('Flower - Commercial Bronze', 6.98);
insert into food (product_name, price_per_kg) values ('Long Island Ice Tea', 12.89);
insert into food (product_name, price_per_kg) values ('Lemon Grass', 40.88);
insert into food (product_name, price_per_kg) values ('Muffin - Banana Nut Individual', 48.62);
insert into food (product_name, price_per_kg) values ('Sprite, Diet - 355ml', 30.51);
insert into food (product_name, price_per_kg) values ('Fondant - Icing', 17.49);
insert into food (product_name, price_per_kg) values ('Pork - Tenderloin, Frozen', 14.29);
insert into food (product_name, price_per_kg) values ('Beans - Fine', 48.23);
insert into food (product_name, price_per_kg) values ('Cookies Almond Hazelnut', 3.12);
insert into food (product_name, price_per_kg) values ('Vector Energy Bar', 17.97);
insert into food (product_name, price_per_kg) values ('Food Colouring - Red', 38.08);
insert into food (product_name, price_per_kg) values ('Roe - Lump Fish, Red', 6.71);
insert into food (product_name, price_per_kg) values ('Yukon Jack', 47.01);
insert into food (product_name, price_per_kg) values ('Wine - Alsace Gewurztraminer', 5.23);
insert into food (product_name, price_per_kg) values ('Beans - Butter Lrg Lima', 9.1);
insert into food (product_name, price_per_kg) values ('Bread - Rye', 23.78);
insert into food (product_name, price_per_kg) values ('Southern Comfort', 26.99);
insert into food (product_name, price_per_kg) values ('Turkey - Ground. Lean', 28.94);
insert into food (product_name, price_per_kg) values ('Wine - Marlbourough Sauv Blanc', 27.37);
insert into food (product_name, price_per_kg) values ('Wine - Gewurztraminer Pierre', 23.8);
insert into food (product_name, price_per_kg) values ('Ezy Change Mophandle', 14.91);
insert into food (product_name, price_per_kg) values ('Yogurt - Banana, 175 Gr', 26.52);
insert into food (product_name, price_per_kg) values ('Bread - Ciabatta Buns', 32.22);
insert into food (product_name, price_per_kg) values ('Chicken - Tenderloin', 23.5);
insert into food (product_name, price_per_kg) values ('Shrimp - 21/25, Peel And Deviened', 3.85);
insert into food (product_name, price_per_kg) values ('Foam Tray S2', 1.7);
insert into food (product_name, price_per_kg) values ('Wine - Ruffino Chianti Classico', 5.44);
insert into food (product_name, price_per_kg) values ('Cactus Pads', 15.29);
insert into food (product_name, price_per_kg) values ('Blackberries', 34.44);
insert into food (product_name, price_per_kg) values ('Wine - Stoneliegh Sauvignon', 35.75);
insert into food (product_name, price_per_kg) values ('Crackers - Graham', 23.99);
insert into food (product_name, price_per_kg) values ('Pasta - Lasagna, Dry', 41.4);
insert into food (product_name, price_per_kg) values ('Water - Mineral, Carbonated', 4.45);
insert into food (product_name, price_per_kg) values ('Lettuce - Curly Endive', 41.35);
insert into food (product_name, price_per_kg) values ('Water - San Pellegrino', 4.46);
insert into food (product_name, price_per_kg) values ('Turkey - Breast, Smoked', 1.86);
insert into food (product_name, price_per_kg) values ('Milkettes - 2%', 3.66);
insert into food (product_name, price_per_kg) values ('Dill Weed - Dry', 7.19);
insert into food (product_name, price_per_kg) values ('Pepper - Orange', 8.18);
insert into food (product_name, price_per_kg) values ('Sugar - Invert', 39.1);
insert into food (product_name, price_per_kg) values ('Longos - Lasagna Beef', 10.55);
insert into food (product_name, price_per_kg) values ('Juice - Grapefruit, 341 Ml', 23.6);
insert into food (product_name, price_per_kg) values ('Corn - On The Cob', 21.01);
insert into food (product_name, price_per_kg) values ('Arrowroot', 32.77);
insert into food (product_name, price_per_kg) values ('Foie Gras', 48.9);
insert into food (product_name, price_per_kg) values ('Carbonated Water - Strawberry', 42.33);
insert into food (product_name, price_per_kg) values ('Creamers - 10%', 49.73);
insert into food (product_name, price_per_kg) values ('Pork - Bones', 24.44);
insert into food (product_name, price_per_kg) values ('Trueblue - Blueberry Cranberry', 35.51);
insert into food (product_name, price_per_kg) values ('Pie Box - Cello Window 2.5', 42.16);
insert into food (product_name, price_per_kg) values ('Spinach - Packaged', 31.4);
insert into food (product_name, price_per_kg) values ('Nori Sea Weed', 15.91);
insert into food (product_name, price_per_kg) values ('Olives - Kalamata', 37.15);
insert into food (product_name, price_per_kg) values ('Longos - Lasagna Veg', 8.95);
insert into food (product_name, price_per_kg) values ('Sauce - Alfredo', 49.3);
insert into food (product_name, price_per_kg) values ('Beef - Roasted, Cooked', 34.71);
insert into food (product_name, price_per_kg) values ('Fenngreek Seed', 21.54);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO eat (scientific_name, product_name)
SELECT scientific_name,product_name from animal,food
ORDER BY random()
LIMIT 1000;