/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
I want to study the relationship between a person's job and the type of stocks (in sectors) one holds in the portfolio.
Therefore, the contents of the three tables are as follows:
	+ The entity set E1 will be person. Person contains information like first and last name, gender, email, city, country, company, department and job title.
	  The rationale of having the above mentioned information is to uniquely identify individuals. They are also assigned an identification number (id), which takes the serial data type.
	  In addition, factors like age, gender, job title, department, city and company could affect the portfolio breakdown of an individual and are thus included in person.
		All columns are to be non-null. Gender here is binary (M or F) so there is a check to ensure that all values are either 'M' or 'F' to ensure data integrity.
	  The header of E1 would look like, with the primary key id:
	.________________________________________________________________________________________________________.
	|												person 													 |
	.____.____________.___________.________._____._______.______._________._________.____________.___________.
	| id | first_name | last_name | gender | dob | email | city | country | company | department | job_title |
	.____.____________.___________.________._____._______.______._________._________.____________.___________.

	+ The entity set E2 will be stocks. This contains information on stocks in the market, with information like stock code, stock name, stock industry and stock sector.
	  We note that the stock name is unique to each stock code. In fact, each row of the table must be unique.
	  Stock sector and stock industries are non-unique but there is a one-to-one relationship between the stock code and sector or industry.
	  We have the primary key (stock_code, stock_name) and foreign key stock_code. The primary key is strictly unique and not null.

	  The header of E2 will resemble:
	._______________________________________.
	| 			  	  stocks				|
	.____________.______.________.__________.
	| stock_code | name | sector | industry |
	.____________.______.________.__________.

	+ Finally, the relationship set R is trades. The entity-relationship would then be person-trades-stocks.
	  trades will contain the id referencing the id in person, stock code and portfolio_value.
	  There can be multiple rows with the same id, but different stock code.
	.___________________________________.
	| 				trades				|
	.____.____________._________________.
	| id | stock_code | portfolio_value |
	.____.____________._________________.
	Here, it is not necessary to check for portfolio value > 0 because portfolio values can be negative as well. Since trades is representative of the total portfolio value per stock per person,
	there is a unique constraint on the composite pair of id and stock_code to ensure data integrity. Similarly, this is reflected when generating random data for the relationship set.
	I generated 5000 random samples and summed the portfolio value by grouping the data by id and stock_code before taking the top 1000 rows to generate 1000 rows for the table.
	In trades, id references the id in person and stock_code references stock_code in stocks. Since we want any changes in person or stocks to be reflected in trades,
	I added deferrable update and delete cascades to propogate the changes after the end of each transaction.

Together, the entity-relationship is able to generate interesting insights on the whether a person's job or company's sector affects the industries or sectors of one's stock portfolio.
The assumption here is that the people in person trade in the stock market.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DROP TABLE IF EXISTS trades;
DROP TABLE IF EXISTS person;
DROP TABLE IF EXISTS stocks;

CREATE TABLE IF NOT EXISTS person (
  id SERIAL PRIMARY KEY, 
  first_name VARCHAR(64) NOT NULL, 
  last_name VARCHAR(64) NOT NULL, 
  gender CHAR(1) NOT NULL CHECK(
    gender = 'M' 
    OR gender = 'F'), 
  dob DATE NOT NULL, 
  email VARCHAR(64) UNIQUE NOT NULL, 
  city VARCHAR(32) NOT NULL, 
  country VARCHAR(32) NOT NULL, 
  company VARCHAR(64) NOT NULL, 
  department VARCHAR(64) NOT NULL, 
  job VARCHAR(64) NOT NULL);
  
CREATE TABLE IF NOT EXISTS stocks (
  stock_code VARCHAR(16) UNIQUE NOT NULL, 
  name VARCHAR(64) UNIQUE NOT NULL, 
  sector VARCHAR(64) NOT NULL, 
  industry VARCHAR(64) NOT NULL, 
  PRIMARY KEY (stock_code, name));
  
CREATE TABLE IF NOT EXISTS trades (
  id INT REFERENCES person(id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE, 
  stock_code VARCHAR(16) NOT NULL REFERENCES stocks(stock_code) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE, 
  portfolio_value DEC(10, 2) NOT NULL, 
  PRIMARY KEY (id, stock_code));
  
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Populating person - 100 rows */
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (1, 'Blayne', 'Lorkings', 'M', '1961-10-15', 'blorkings0@last.fm', 'Atawutung', 'Indonesia', 'Thoughtbridge', 'Legal', 'Compensation Analyst');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (2, 'Lara', 'Burghall', 'F', '1985-12-25', 'lburghall1@ifeng.com', 'Kokembang', 'Indonesia', 'Feedmix', 'Business Development', 'Senior Sales Associate');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (3, 'Hadlee', 'Mahedy', 'M', '1942-11-05', 'hmahedy2@trellian.com', 'Um Jar Al Gharbiyya', 'Sudan', 'Meemm', 'Accounting', 'Chief Design Engineer');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (4, 'Yolanthe', 'Dorrell', 'F', '1973-04-17', 'ydorrell3@cam.ac.uk', 'Lopatyn', 'Ukraine', 'Vitz', 'Product Management', 'Geologist III');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (5, 'Reese', 'Goodhand', 'M', '1966-02-15', 'rgoodhand4@dailymail.co.uk', 'Al Qaţn', 'Yemen', 'Jabbertype', 'Sales', 'Statistician IV');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (6, 'Mick', 'Pallasch', 'M', '1944-04-29', 'mpallasch5@360.cn', 'Krzynowłoga Mała', 'Poland', 'Yabox', 'Business Development', 'Human Resources Manager');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (7, 'Fey', 'Strass', 'F', '1999-02-03', 'fstrass6@intel.com', 'Vlorë', 'Albania', 'Myworks', 'Accounting', 'Web Designer IV');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (8, 'Jessika', 'Doohey', 'F', '1941-03-12', 'jdoohey7@merriam-webster.com', 'Longtanping', 'China', 'Skyba', 'Accounting', 'Software Consultant');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (9, 'Parsifal', 'Farra', 'M', '1988-08-13', 'pfarra8@discuz.net', 'Strážnice', 'Czech Republic', 'Digitube', 'Training', 'Analog Circuit Design manager');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (10, 'Miguelita', 'Vannuccinii', 'F', '1974-07-22', 'mvannuccinii9@gov.uk', 'Wates', 'Indonesia', 'Oozz', 'Human Resources', 'Mechanical Systems Engineer');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (11, 'Dora', 'Beaford', 'F', '1967-04-08', 'dbeaforda@google.com.hk', 'Oslo', 'Norway', 'Bubblemix', 'Legal', 'Senior Editor');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (12, 'Cate', 'Stollenhof', 'F', '1985-05-08', 'cstollenhofb@ucla.edu', 'Cieplice Śląskie Zdrój', 'Poland', 'Realpoint', 'Product Management', 'Associate Professor');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (13, 'Bryn', 'Storrar', 'M', '1944-01-04', 'bstorrarc@smh.com.au', 'Magok', 'Indonesia', 'Voonyx', 'Research and Development', 'Data Coordiator');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (14, 'Celia', 'MacLese', 'F', '1995-07-29', 'cmaclesed@alexa.com', 'Matai', 'Tanzania', 'Gabvine', 'Accounting', 'Geologist II');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (15, 'Ludovico', 'Haworth', 'M', '1967-06-04', 'lhaworthe@acquirethisname.com', 'Biltine', 'Chad', 'Mynte', 'Research and Development', 'Social Worker');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (16, 'Missy', 'Mountstephen', 'F', '1949-04-27', 'mmountstephenf@opensource.org', 'Buenavista', 'Mexico', 'Kazio', 'Support', 'Automation Specialist III');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (17, 'Willi', 'Mayhow', 'M', '1978-03-15', 'wmayhowg@indiegogo.com', 'Nóvita', 'Colombia', 'Buzzdog', 'Training', 'Office Assistant I');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (18, 'Gorden', 'Blazeby', 'M', '1958-01-19', 'gblazebyh@dyndns.org', 'Mijiang', 'China', 'Realfire', 'Accounting', 'Clinical Specialist');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (19, 'Helyn', 'Sketchley', 'F', '2001-04-26', 'hsketchleyi@drupal.org', 'Yaozhuang', 'China', 'Dabfeed', 'Business Development', 'Assistant Professor');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (20, 'Devi', 'Cottem', 'F', '1971-05-04', 'dcottemj@wordpress.com', 'Yuanqian', 'China', 'Devshare', 'Engineering', 'Director of Sales');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (21, 'Bard', 'Eirwin', 'M', '1951-12-19', 'beirwink@rediff.com', 'Ejido', 'Venezuela', 'Skyndu', 'Research and Development', 'Marketing Assistant');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (22, 'Thaxter', 'Warton', 'M', '1951-08-25', 'twartonl@un.org', 'Saint-Augustin-de-Desmaures', 'Canada', 'Dabfeed', 'Sales', 'Librarian');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (23, 'Marylee', 'Foxten', 'F', '1980-10-14', 'mfoxtenm@patch.com', 'Lidköping', 'Sweden', 'Yodoo', 'Engineering', 'Community Outreach Specialist');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (24, 'Caryl', 'Bealton', 'M', '2003-06-06', 'cbealtonn@oakley.com', 'Hulyaypole', 'Ukraine', 'Skipstorm', 'Services', 'Structural Analysis Engineer');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (25, 'Eustace', 'Voce', 'M', '1974-10-29', 'evoceo@vkontakte.ru', 'Jiazi', 'China', 'Brainbox', 'Research and Development', 'Technical Writer');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (26, 'Ramsey', 'Ipsly', 'M', '1952-03-24', 'ripslyp@senate.gov', 'Yang Chum Noi', 'Thailand', 'Yabox', 'Legal', 'Paralegal');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (27, 'Simon', 'Lynn', 'M', '1953-09-17', 'slynnq@goo.ne.jp', 'Duwakbuter', 'Indonesia', 'Topicstorm', 'Sales', 'Systems Administrator I');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (28, 'Jolie', 'Gegg', 'F', '1985-07-15', 'jgeggr@typepad.com', 'Quzhou', 'China', 'Tagopia', 'Marketing', 'Associate Professor');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (29, 'Ed', 'Girardengo', 'M', '2002-12-22', 'egirardengos@cornell.edu', 'Muchkapskiy', 'Russia', 'Edgewire', 'Legal', 'Director of Sales');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (30, 'Shirl', 'Dengate', 'F', '1967-11-04', 'sdengatet@bloglines.com', 'Dębów', 'Poland', 'Bubblemix', 'Legal', 'Cost Accountant');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (31, 'Paolo', 'Woolston', 'M', '1954-09-04', 'pwoolstonu@noaa.gov', 'Nyimba', 'Zambia', 'InnoZ', 'Engineering', 'Electrical Engineer');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (32, 'Agace', 'Jaye', 'F', '1949-06-13', 'ajayev@mapy.cz', 'San Antonio', 'United States', 'Voolia', 'Legal', 'Help Desk Technician');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (33, 'Fremont', 'Robus', 'M', '1996-03-27', 'frobusw@clickbank.net', 'Mijiang', 'China', 'Dynabox', 'Services', 'Web Designer IV');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (34, 'Dredi', 'Van Arsdalen', 'F', '1978-05-01', 'dvanarsdalenx@columbia.edu', 'Coyaima', 'Colombia', 'Livetube', 'Marketing', 'Cost Accountant');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (35, 'Karly', 'Ohanessian', 'F', '1971-02-16', 'kohanessiany@ezinearticles.com', 'Guanzhou', 'China', 'Dabfeed', 'Services', 'Developer III');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (36, 'Rosene', 'Tainton', 'F', '1966-12-14', 'rtaintonz@yale.edu', 'Rimpakgede', 'Indonesia', 'Wordtune', 'Business Development', 'Administrative Assistant IV');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (37, 'Cathleen', 'McDonand', 'F', '1972-01-24', 'cmcdonand10@hostgator.com', 'Rudong', 'China', 'Dablist', 'Business Development', 'Help Desk Operator');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (38, 'Bruno', 'Greaser', 'M', '1958-12-15', 'bgreaser11@simplemachines.org', 'Huangshi', 'China', 'Shuffledrive', 'Product Management', 'Food Chemist');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (39, 'Clarey', 'Lossman', 'F', '1970-03-25', 'clossman12@fda.gov', 'Lugar Novo', 'Portugal', 'Browsetype', 'Services', 'GIS Technical Architect');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (40, 'Boyd', 'Cronchey', 'M', '1991-08-07', 'bcronchey13@usatoday.com', 'Valerianovsk', 'Russia', 'Kayveo', 'Services', 'Pharmacist');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (41, 'Clem', 'Heindl', 'M', '1944-01-11', 'cheindl14@de.vu', 'Uyskoye', 'Russia', 'Zoomlounge', 'Business Development', 'VP Product Management');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (42, 'Ottilie', 'Saffill', 'F', '1963-10-27', 'osaffill15@4shared.com', 'Changzheng', 'China', 'Kwinu', 'Business Development', 'Structural Engineer');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (43, 'Felicdad', 'Anglin', 'F', '1969-08-06', 'fanglin16@bravesites.com', 'Oratorio', 'Guatemala', 'Blogtags', 'Engineering', 'Electrical Engineer');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (44, 'Oliver', 'Le Marchand', 'M', '1994-08-14', 'olemarchand17@house.gov', 'Kanashevo', 'Russia', 'Midel', 'Training', 'Paralegal');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (45, 'Osborn', 'Husk', 'M', '1990-06-19', 'ohusk18@oakley.com', 'Mawza‘', 'Yemen', 'Leexo', 'Legal', 'Business Systems Development Analyst');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (46, 'Anita', 'Damrell', 'F', '1984-01-03', 'adamrell19@time.com', 'Eguia', 'Philippines', 'Camido', 'Legal', 'Physical Therapy Assistant');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (47, 'Corrina', 'Dicken', 'F', '1981-07-26', 'cdicken1a@yahoo.co.jp', 'Fakaifou Village', 'Tuvalu', 'Edgeify', 'Services', 'Software Test Engineer I');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (48, 'Silvie', 'Gregore', 'F', '1941-01-21', 'sgregore1b@skyrock.com', 'Tyringe', 'Sweden', 'Kazu', 'Legal', 'VP Accounting');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (49, 'Bjorn', 'Blincko', 'M', '1998-12-09', 'bblincko1c@cafepress.com', 'Trbovlje', 'Slovenia', 'Zooxo', 'Marketing', 'Staff Scientist');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (50, 'Margarethe', 'Diack', 'F', '1975-01-12', 'mdiack1d@prlog.org', 'Nouvelle France', 'Mauritius', 'Zoovu', 'Business Development', 'Dental Hygienist');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (51, 'Rhonda', 'McNeil', 'F', '1941-11-13', 'rmcneil1e@google.es', 'Jialu', 'China', 'Photojam', 'Support', 'GIS Technical Architect');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (52, 'Sven', 'Wetherald', 'M', '1960-12-02', 'swetherald1f@bloomberg.com', 'Koygorodok', 'Russia', 'Tagopia', 'Legal', 'Tax Accountant');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (53, 'Jacquetta', 'Popple', 'F', '1983-03-31', 'jpopple1g@nytimes.com', 'Baguio', 'Philippines', 'Innotype', 'Human Resources', 'Sales Associate');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (54, 'Rosemarie', 'Cogdell', 'F', '1994-04-25', 'rcogdell1h@bbc.co.uk', 'Dubu', 'China', 'Eidel', 'Research and Development', 'VP Product Management');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (55, 'Brenda', 'Heers', 'F', '1965-11-15', 'bheers1i@lycos.com', 'Bom Sucesso', 'Portugal', 'Yabox', 'Support', 'Media Manager I');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (56, 'Maye', 'Brushfield', 'F', '1976-07-18', 'mbrushfield1j@unblog.fr', 'Minante Segundo', 'Philippines', 'Kazu', 'Human Resources', 'Help Desk Operator');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (57, 'Gregorio', 'Durrant', 'M', '1959-05-11', 'gdurrant1k@live.com', 'Diofior', 'Senegal', 'Fadeo', 'Training', 'Professor');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (58, 'Wallache', 'Brambley', 'M', '1999-04-02', 'wbrambley1l@webnode.com', 'Bezons', 'France', 'Blogpad', 'Training', 'Community Outreach Specialist');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (59, 'Tawnya', 'Baudou', 'F', '1999-05-19', 'tbaudou1m@rambler.ru', 'Zhijiang', 'China', 'Ooba', 'Training', 'Legal Assistant');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (60, 'Andie', 'Armstrong', 'F', '1969-06-24', 'aarmstrong1n@lycos.com', 'Kraśnik', 'Poland', 'Podcat', 'Marketing', 'Assistant Manager');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (61, 'Indira', 'Spowart', 'F', '1991-08-11', 'ispowart1o@multiply.com', 'Calaba', 'Philippines', 'InnoZ', 'Marketing', 'General Manager');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (62, 'Audra', 'Ison', 'F', '1985-09-25', 'aison1p@nps.gov', 'Gusong', 'China', 'Wordware', 'Accounting', 'Compensation Analyst');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (63, 'Celinda', 'Trim', 'F', '1945-09-01', 'ctrim1q@msn.com', 'Tanenofunan', 'Indonesia', 'Tagtune', 'Training', 'Editor');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (64, 'Mellisa', 'Schapero', 'F', '1988-03-10', 'mschapero1r@xing.com', 'Shigony', 'Russia', 'Yacero', 'Product Management', 'Sales Representative');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (65, 'Trudi', 'Benion', 'F', '1975-12-13', 'tbenion1s@walmart.com', 'Mizunami', 'Japan', 'Ooba', 'Research and Development', 'Recruiting Manager');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (66, 'Zaccaria', 'Ashlin', 'M', '1957-09-06', 'zashlin1t@quantcast.com', 'Doāba', 'Pakistan', 'Twinder', 'Legal', 'VP Sales');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (67, 'Charmine', 'Shrubsall', 'F', '1992-07-23', 'cshrubsall1u@indiatimes.com', 'Dayushu', 'China', 'Eidel', 'Marketing', 'Payment Adjustment Coordinator');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (68, 'Bev', 'Burtwistle', 'F', '1999-01-17', 'bburtwistle1v@mit.edu', 'Offa', 'Nigeria', 'Vitz', 'Product Management', 'Speech Pathologist');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (69, 'Tate', 'Medina', 'F', '1966-09-15', 'tmedina1w@fc2.com', 'Estrada', 'Portugal', 'Yoveo', 'Training', 'Recruiting Manager');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (70, 'Amabelle', 'Dene', 'F', '1977-05-08', 'adene1x@mysql.com', 'Luoxi', 'China', 'Cogibox', 'Legal', 'Staff Scientist');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (71, 'Tibold', 'Clutten', 'M', '1953-09-15', 'tclutten1y@intel.com', 'Orguz', 'Bosnia and Herzegovina', 'Skajo', 'Services', 'Marketing Manager');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (72, 'Lianna', 'Glascott', 'F', '1949-04-04', 'lglascott1z@sbwire.com', 'Kuala Lumpur', 'Malaysia', 'Babbleopia', 'Engineering', 'Paralegal');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (73, 'Jared', 'Bolley', 'M', '1979-11-23', 'jbolley20@guardian.co.uk', 'Quinua', 'Peru', 'Miboo', 'Research and Development', 'VP Quality Control');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (74, 'Conrado', 'Riatt', 'M', '1989-06-25', 'criatt21@virginia.edu', 'Hexi', 'China', 'Gabtune', 'Accounting', 'Design Engineer');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (75, 'Abel', 'Outerbridge', 'M', '1958-04-04', 'aouterbridge22@unblog.fr', 'Detroit', 'United States', 'Wikibox', 'Product Management', 'VP Marketing');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (76, 'Boone', 'Greenhowe', 'M', '1947-07-17', 'bgreenhowe23@ca.gov', 'Changtang', 'China', 'Tagfeed', 'Sales', 'General Manager');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (77, 'Rubin', 'Trehearne', 'M', '1992-02-07', 'rtrehearne24@google.com.au', 'Banqiaodian', 'China', 'Jabbertype', 'Sales', 'Web Developer IV');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (78, 'Marcia', 'Possek', 'F', '1953-08-26', 'mpossek25@go.com', 'Apeldoorn', 'Netherlands', 'Linkbridge', 'Accounting', 'Assistant Professor');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (79, 'Niccolo', 'Southcomb', 'M', '1965-11-02', 'nsouthcomb26@psu.edu', 'Rzeczenica', 'Poland', 'Thoughtblab', 'Legal', 'Project Manager');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (80, 'Damon', 'Allmen', 'M', '1943-01-05', 'dallmen27@theatlantic.com', 'Cam Lộ', 'Vietnam', 'Zoonder', 'Support', 'Civil Engineer');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (81, 'Dede', 'Hatfull', 'F', '1970-10-23', 'dhatfull28@ox.ac.uk', 'Baiguan', 'China', 'Photospace', 'Legal', 'Cost Accountant');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (82, 'Ab', 'Reidie', 'M', '1997-12-06', 'areidie29@wiley.com', 'Del Monte', 'Philippines', 'Leexo', 'Product Management', 'Social Worker');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (83, 'Darcie', 'Kasman', 'F', '1945-08-25', 'dkasman2a@stumbleupon.com', 'Vitória', 'Brazil', 'Camido', 'Product Management', 'VP Accounting');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (84, 'Malvin', 'Rosenwald', 'M', '1986-02-22', 'mrosenwald2b@umn.edu', 'Fengle', 'China', 'Oloo', 'Accounting', 'Food Chemist');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (85, 'Caryl', 'Vern', 'M', '1952-06-17', 'cvern2c@usa.gov', 'Hortolândia', 'Brazil', 'Trunyx', 'Human Resources', 'Media Manager III');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (86, 'Sawyer', 'Akram', 'M', '1945-09-24', 'sakram2d@goo.ne.jp', 'La Palma', 'Panama', 'Latz', 'Business Development', 'Electrical Engineer');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (87, 'Jeramie', 'Wendover', 'M', '1963-03-06', 'jwendover2e@google.es', 'Caraguatatuba', 'Brazil', 'Voomm', 'Human Resources', 'Cost Accountant');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (88, 'Carolann', 'Fanti', 'F', '1961-06-04', 'cfanti2f@wix.com', 'Itacarambi', 'Brazil', 'Avamba', 'Engineering', 'Pharmacist');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (89, 'Brandi', 'Borsay', 'F', '1968-03-13', 'bborsay2g@umn.edu', 'Jianqiao', 'China', 'Buzzdog', 'Services', 'Recruiting Manager');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (90, 'Tildie', 'Summerley', 'F', '1952-01-24', 'tsummerley2h@msn.com', 'Zaslawye', 'Belarus', 'Yadel', 'Product Management', 'Database Administrator I');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (91, 'Farris', 'Grew', 'M', '1976-07-25', 'fgrew2i@salon.com', 'Matozinhos', 'Brazil', 'Jaloo', 'Training', 'Electrical Engineer');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (92, 'Josey', 'Rand', 'F', '1962-07-20', 'jrand2j@mapquest.com', 'Larvik', 'Norway', 'Cogilith', 'Human Resources', 'Structural Engineer');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (93, 'Raphael', 'Sturridge', 'M', '1999-07-27', 'rsturridge2k@addthis.com', 'La Roche-sur-Yon', 'France', 'Jabbercube', 'Services', 'Librarian');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (94, 'Constantine', 'Swannick', 'F', '1969-03-29', 'cswannick2l@list-manage.com', 'Rongelap', 'Marshall Islands', 'Dabfeed', 'Product Management', 'Geologist II');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (95, 'Allison', 'Chaimson', 'F', '1987-03-06', 'achaimson2m@desdev.cn', 'Maluno Sur', 'Philippines', 'Fanoodle', 'Marketing', 'Assistant Professor');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (96, 'Sibley', 'Wixon', 'F', '1975-11-04', 'swixon2n@4shared.com', 'Njivice', 'Croatia', 'Agimba', 'Legal', 'Help Desk Operator');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (97, 'Elden', 'Pyrah', 'M', '1955-06-13', 'epyrah2o@census.gov', 'Novi Beograd', 'Serbia', 'Myworks', 'Business Development', 'Recruiting Manager');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (98, 'Simonette', 'Winckworth', 'F', '1985-03-20', 'swinckworth2p@wp.com', 'Tinambacan', 'Philippines', 'Ailane', 'Human Resources', 'General Manager');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (99, 'Arielle', 'Brabon', 'F', '1992-12-18', 'abrabon2q@oracle.com', 'Jabal os Saraj', 'Afghanistan', 'Kwimbee', 'Sales', 'Environmental Specialist');
INSERT INTO person (id, first_name, last_name, gender, dob, email, city, country, company, department, job) VALUES (100, 'Parke', 'Twinterman', 'M', '1989-11-24', 'ptwinterman2r@etsy.com', 'Honglu', 'China', 'Bluezoom', 'Sales', 'Human Resources Manager');

/* Populating stocks - 100 rows */
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('TGTX', 'TG Therapeutics, Inc.', 'Health Care', 'Major Pharmaceuticals');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('BSAC', 'Banco Santander Chile', 'Finance', 'Commercial Banks');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('MDP', 'Meredith Corporation', 'Consumer Services', 'Newspapers/Magazines');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('VGM', 'Invesco Trust for Investment Grade Municipals', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('C.WS.A', 'Citigroup Inc.', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('IMKTA', 'Ingles Markets, Incorporated', 'Consumer Services', 'Food Chains');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('HNP', 'Huaneng Power International, Inc.', 'Public Utilities', 'Electric Utilities: Central');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('IIN', 'IntriCon Corporation', 'Capital Goods', 'Electrical Products');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('MHO^A', 'M/I Homes, Inc.', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('CTSO', 'Cytosorbents Corporation', 'Health Care', 'Medical/Dental Instruments');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('ROLL', 'RBC Bearings Incorporated', 'Capital Goods', 'Metal Fabrications');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('SLIM', 'The Obesity ETF', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('ROBO', 'ROBO Global Robotics and Automation Index ETF', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('SBOW', 'SilverBow Resorces, Inc.', 'Energy', 'Oil & Gas Production');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('EOS', 'Eaton Vance Enhanced Equity Income Fund II', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('VNCE', 'Vince Holding Corp.', 'Consumer Services', 'Clothing/Shoe/Accessory Stores');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('AL', 'Air Lease Corporation', 'Technology', 'Diversified Commercial Services');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('KEQU', 'Kewaunee Scientific Corporation', 'Capital Goods', 'Medical Specialities');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('RNVAZ', 'Rennova Health, Inc.', 'Health Care', 'Precision Instruments');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('ILG', 'ILG, Inc', 'Finance', 'Real Estate');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('CBX', 'CBX (Listing Market NYSE Networks AE', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('DRQ', 'Dril-Quip, Inc.', 'Energy', 'Metal Fabrications');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('AWH', 'Allied World Assurance Company Holdings, AG', 'Finance', 'Property-Casualty Insurers');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('FWONK', 'Liberty Media Corporation', 'Consumer Services', 'Broadcasting');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('HOPE', 'Hope Bancorp, Inc.', 'Finance', 'Major Banks');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('MNR^C', 'Monmouth Real Estate Investment Corporation', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('TWX', 'Time Warner Inc.', 'Consumer Services', 'Television Services');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('CIA', 'Citizens, Inc.', 'Finance', 'Life Insurance');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('STAG^C', 'Stag Industrial, Inc.', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('NORD', 'Nord Anglia Education, Inc.', 'Consumer Services', 'Other Consumer Services');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('ARCX', 'Arc Logistic Partners LP', 'Energy', 'Oil Refining/Marketing');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('GTS', 'Triple-S Management Corporation', 'Finance', 'Accident &Health Insurance');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('HBANP', 'Huntington Bancshares Incorporated', 'Finance', 'Major Banks');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('SBNB', 'Scorpio Tankers Inc.', 'Transportation', 'Marine Transportation');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('HUBG', 'Hub Group, Inc.', 'Transportation', 'Oil Refining/Marketing');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('PDEX', 'Pro-Dex, Inc.', 'Health Care', 'Medical/Dental Instruments');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('FEYE', 'FireEye, Inc.', 'Technology', 'Computer peripheral equipment');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('GWW', 'W.W. Grainger, Inc.', 'Consumer Services', 'Office Equipment/Supplies/Services');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('UFPI', 'Universal Forest Products, Inc.', 'Basic Industries', 'Forest Products');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('LN', 'LINE Corporation', 'Technology', 'Computer Software: Programming, Data Processing');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('WD', 'Walker & Dunlop, Inc.', 'Finance', 'Finance: Consumer Services');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('AMDA', 'Amedica Corporation', 'Health Care', 'Medical/Dental Instruments');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('PRH', 'Prudential Financial, Inc.', 'Finance', 'Life Insurance');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('MSG', 'MSG Networks Inc.', 'Consumer Services', 'Services-Misc. Amusement & Recreation');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('IO', 'Ion Geophysical Corporation', 'Energy', 'Oil & Gas Production');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('SO', 'Southern Company (The)', 'Public Utilities', 'Electric Utilities: Central');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('LEN', 'Lennar Corporation', 'Basic Industries', 'Homebuilding');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('SGZA', 'Selective Insurance Group, Inc.', 'Finance', 'Property-Casualty Insurers');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('MYC', 'Blackrock MuniYield California Fund, Inc.', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('GPM', 'Guggenheim Enhanced Equity Income Fund', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('AF^C', 'Astoria Financial Corporation', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('NMZ', 'Nuveen Municipal High Income Opportunity Fund', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('CYCC', 'Cyclacel Pharmaceuticals, Inc.', 'Health Care', 'Major Pharmaceuticals');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('CS', 'Credit Suisse Group', 'Finance', 'Investment Bankers/Brokers/Service');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('IPCC', 'Infinity Property and Casualty Corporation', 'Finance', 'Property-Casualty Insurers');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('IFGL', 'iShares FTSE EPRA/NAREIT Global Real Estate ex-U.S. Index Fund', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('CO', 'China Cord Blood Corporation', 'Finance', 'Business Services');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('BGE^B', 'Baltimore Gas & Electric Company', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('IMMR', 'Immersion Corporation', 'Technology', 'Computer peripheral equipment');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('PSCE', 'PowerShares S&P SmallCap Energy Portfolio', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('NBRV', 'Nabriva Therapeutics AG', 'Health Care', 'Major Pharmaceuticals');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('KODK.WS.A', 'Eastman Kodak Company', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('UCP', 'UCP, Inc.', 'Capital Goods', 'Homebuilding');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('THQ', 'Tekla Healthcare Opportunies Fund', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('CSTE', 'Caesarstone Ltd.', 'Capital Goods', 'Building Materials');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('LHO^J', 'LaSalle Hotel Properties', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('EVAR', 'Lombard Medical, Inc.', 'Health Care', 'Medical/Dental Instruments');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('LSTR', 'Landstar System, Inc.', 'Transportation', 'Trucking Freight/Courier Services');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('NVCR', 'NovoCure Limited', 'Health Care', 'Medical/Dental Instruments');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('MMDMW', 'Modern Media Acquisition Corp.', 'Finance', 'Business Services');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('QQQC', 'Global X NASDAQ China Technology ETF', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('INFY', 'Infosys Limited', 'Technology', 'EDP Services');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('FSB', 'Franklin Financial Network, Inc.', 'Finance', 'Major Banks');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('RDWR', 'Radware Ltd.', 'Miscellaneous', 'Business Services');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('BLVDU', 'Boulevard Acquisition Corp. II', 'Finance', 'Business Services');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('WPPGY', 'WPP plc', 'Technology', 'Advertising');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('MVT', 'Blackrock MuniVest Fund II, Inc.', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('NUO', 'Nuveen Ohio Quality Municipal Income Fund', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('VTWV', 'Vanguard Russell 2000 Value ETF', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('RJF', 'Raymond James Financial, Inc.', 'Finance', 'Investment Bankers/Brokers/Service');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('IDA', 'IDACORP, Inc.', 'Public Utilities', 'Electric Utilities: Central');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('VVUS', 'VIVUS, Inc.', 'Health Care', 'Major Pharmaceuticals');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('NSA', 'National Storage Affiliates Trust', 'Consumer Services', 'Real Estate Investment Trusts');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('NID', 'Nuveen Intermediate Duration Municipal Term Fund', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('SELB', 'Selecta Biosciences, Inc.', 'Health Care', 'Major Pharmaceuticals');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('CORE', 'Core-Mark Holding Company, Inc.', 'Consumer Non-Durables', 'Food Distributors');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('GMZ', 'Goldman Sachs MLP Income Opportunities Fund', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('HSGX', 'Histogenics Corporation', 'Health Care', 'Industrial Specialties');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('NNDM', 'Nano Dimension Ltd.', 'Technology', 'Electrical Products');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('S', 'Sprint Corporation', 'Public Utilities', 'Telecommunications Equipment');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('HTLD', 'Heartland Express, Inc.', 'Transportation', 'Trucking Freight/Courier Services');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('HRI', 'Herc Holdings Inc.', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('BCOR', 'Blucora, Inc.', 'Technology', 'EDP Services');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('MRAM', 'Everspin Technologies, Inc.', 'Technology', 'Semiconductors');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('ABR^B', 'Arbor Realty Trust', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('GLOP^A', 'GasLog Partners LP', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('NMI', 'Nuveen Municipal Income Fund, Inc.', 'n/a', 'n/a');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('UEIC', 'Universal Electronics Inc.', 'Consumer Non-Durables', 'Consumer Electronics/Appliances');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('HCOM', 'Hawaiian Telcom Holdco, Inc.', 'Consumer Services', 'Telecommunications Equipment');
INSERT INTO stocks (stock_code, name, sector, industry) VALUES ('FLY', 'Fly Leasing Limited', 'n/a', 'n/a');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO trades (id, stock_code, portfolio_value) 
SELECT * 
FROM (
	SELECT generate_series AS id, 
		   stock_code, 
		   floor(random() * 1000000 + random())/ 100 AS portfolio_value 
	FROM generate_series(1, 100) 
		CROSS JOIN (
			SELECT DISTINCT stock_code 
			FROM stocks
		) stock_symbols 
	) insert_tab
ORDER BY random()
LIMIT 1000;