/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/* Student Number: A0231857Y		     					            */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: 													*/
/* The code is written for PostgreSQL 									*/

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: 					*/
/*																		*/
/* Based on Marvel Comics, S.H.I.E.L.D is a fictional espionage and law	*/
/* enforcement agency, tasked to maintain world peace and order. 		*/
/* The organisation has a wide range of highly skilled and specialiased */
/* agents, scattered all over the world, doing critical, top-secret 	*/
/* missions. 															*/				
/* In this assignment, the database instance is S.H.I.E.L.D's mission 	*/
/* tracking system that records information about agents, their 		*/
/* assigned missions and their mission progress. 						*/		
/*																		*/
/* There will be three tables in this database instance: 				*/
/*																		*/
/* 1. Entity 1 (agent): The database records the name, base, status and */
/* skill of each agent. Each agent is identified in the system by 		*/
/* his/her ID. The database also records the date at which the agent is */
/* activated. 															*/
/*																		*/
/* 2. Entity 2 (mission): The database records the name, country, 		*/
/* threat level (10 being the highest) and status of each mission. Each */
/* mission is identified by its ID.	The start and completion target     */
/* date are also included in the table.									*/
/*							 											*/
/* 3. Relationship Table (progress): The database records the agent 	*/
/* involved in every mission along with the id, name, status and start  */
/* date of the mission.													*/
																	
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS agent (
    first_name VARCHAR(75) NOT NULL,
    last_name VARCHAR(75) NOT NULL,
    base VARCHAR(50) NOT NULL,
    status VARCHAR(10) CHECK (status = 'active' OR status = 'dormant' OR status = 'retired'),
    activation_date DATE,
    top_skill VARCHAR(25),
    id BIGINT PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS mission (
    name VARCHAR(256) NOT NULL UNIQUE,
    country VARCHAR(75),
    status VARCHAR(10) NOT NULL CHECK (status = 'ongoing' OR status = 'completed' OR status = 'aborted'),
    threat_level INT CHECK (threat_level <= 10),
    start_date DATE NOT NULL DEFAULT CURRENT_DATE,
    completion_target_date DATE NOT NULL,
    id BIGINT PRIMARY KEY,
    CHECK (completion_target_date > start_date)
);

CREATE TABLE IF NOT EXISTS progress (
    mission_id BIGINT,
    mission_name VARCHAR(256) REFERENCES mission(name) DEFERRABLE,
    mission_status VARCHAR(10),
    agent_id BIGINT,
    start_date DATE NOT NULL DEFAULT CURRENT_DATE,
    FOREIGN KEY (mission_id) REFERENCES mission(id) ON DELETE CASCADE ON UPDATE CASCADE DEFERRABLE,
    FOREIGN KEY (agent_id) REFERENCES agent(id) ON DELETE CASCADE ON UPDATE CASCADE DEFERRABLE,
    PRIMARY KEY (mission_id, agent_id)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* SQL DML for agent Table: */
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('405508720', 'Bernardine', 'Gowanson', 'BR', 'retired', '2016-07-23', 'Investigation');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('888131227', 'Evita', 'Dunbar', 'JP', 'active', '1976-09-02', 'Diplomacy');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('968464673', 'Loralee', 'Enders', 'CN', 'retired', '1976-02-22', 'Diplomacy');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('421889702', 'Gert', 'Cadogan', 'LV', 'dormant', '2018-11-14', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('707373537', 'Thurston', 'Gosalvez', 'HR', 'dormant', '2020-05-19', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('958030615', 'Wilek', 'Becken', 'SE', 'retired', '1993-02-01', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('480161069', 'Sibelle', 'Smallman', 'CN', 'dormant', '1979-09-14', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('646222708', 'Jillian', 'Dunderdale', 'CN', 'active', '2018-03-22', 'Diplomacy');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('663379067', 'Bartholomew', 'Ollenbuttel', 'SI', 'retired', '1981-07-31', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('238728537', 'Merrili', 'Reiach', 'MD', 'retired', '1982-02-09', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('282227614', 'Jarib', 'Schonfelder', 'HN', 'dormant', '1982-05-26', 'Investigation');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('834548998', 'Edik', 'Banstead', 'FR', 'dormant', '1998-06-10', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('568540277', 'Kara-lynn', 'Brafield', 'AR', 'active', '2013-01-23', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('385411457', 'Leeland', 'Hodgins', 'UA', 'retired', '1997-03-04', 'Diplomacy');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('904299029', 'Gratiana', 'Grinval', 'TV', 'active', '2018-11-05', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('210219533', 'Ham', 'Libbey', 'CN', 'retired', '2015-09-06', 'Investigation');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('567358594', 'Fan', 'Merriment', 'VE', 'dormant', '2005-12-04', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('138159433', 'Becki', 'Dinjes', 'JP', 'dormant', '1980-10-10', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('986747495', 'Lalo', 'Teas', 'AL', 'dormant', '2018-09-10', 'Diplomacy');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('057540720', 'Eldridge', 'Ruggles', 'PT', 'active', '2005-12-22', 'Combat');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('730920195', 'Trueman', 'Giorgio', 'ID', 'dormant', '2021-02-14', 'Diplomacy');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('226029516', 'Eirena', 'Hammill', 'NO', 'dormant', '1989-06-05', 'Combat');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('801816509', 'Maressa', 'Riccardi', 'RU', 'dormant', '2005-09-17', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('530614219', 'Buddie', 'Doud', 'CO', 'dormant', '2004-02-13', 'Investigation');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('801065670', 'Andriana', 'Yuryichev', 'ID', 'retired', '1988-04-13', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('757343449', 'Shaw', 'Gummoe', 'ID', 'retired', '1974-11-14', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('353179216', 'Daniele', 'Rouchy', 'EC', 'retired', '2004-06-05', 'Diplomacy');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('346287978', 'Coretta', 'Robeson', 'ID', 'dormant', '2017-04-21', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('805120262', 'Brant', 'Scruby', 'TM', 'dormant', '1976-07-17', 'Investigation');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('191343782', 'Edan', 'Sarll', 'PH', 'dormant', '2019-09-06', 'Diplomacy');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('545824326', 'Byrle', 'Comport', 'AM', 'dormant', '1985-06-12', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('796655838', 'Lyn', 'Fortoun', 'ID', 'active', '1995-03-09', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('463139621', 'Tilda', 'Southerill', 'ID', 'retired', '2005-09-01', 'Investigation');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('182205774', 'Vaughn', 'Pandie', 'KZ', 'retired', '2021-04-15', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('271866692', 'Lorin', 'Oherlihy', 'TH', 'active', '2017-04-15', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('899742797', 'Bernhard', 'Downham', 'PH', 'dormant', '2003-05-28', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('950086305', 'Maryellen', 'Drust', 'US', 'dormant', '1985-05-05', 'Investigation');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('797577296', 'Krystle', 'Broughton', 'CN', 'retired', '1995-05-12', 'Combat');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('195729276', 'Jodee', 'Pitfield', 'CN', 'active', '1971-12-01', 'Investigation');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('466485951', 'Marwin', 'Hurran', 'ID', 'dormant', '1975-01-29', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('068124496', 'Edy', 'Carvill', 'CN', 'retired', '1971-11-20', 'Combat');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('579053760', 'Vita', 'Barrasse', 'KG', 'active', '2005-09-10', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('648682031', 'Hilly', 'Landsbury', 'UA', 'dormant', '1989-03-17', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('340822062', 'Marcelia', 'Whatley', 'MY', 'active', '1981-09-11', 'Combat');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('341239445', 'Drusy', 'Letty', 'PH', 'dormant', '2001-10-15', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('258018991', 'Ethelind', 'Caslett', 'PL', 'retired', '2014-09-06', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('780698335', 'Stanley', 'McNair', 'UA', 'dormant', '2007-10-02', 'Investigation');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('634673277', 'Iggy', 'Mazonowicz', 'CN', 'retired', '2007-01-17', 'Investigation');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('748648477', 'Anjela', 'Facher', 'AF', 'retired', '1985-02-25', 'Combat');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('944809809', 'Alyse', 'Bosanko', 'US', 'retired', '2014-11-03', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('341083255', 'Christophe', 'Jaslem', 'CN', 'retired', '1975-02-28', 'Investigation');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('559424805', 'Shannan', 'Goering', 'US', 'dormant', '1985-07-14', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('408554700', 'Darrell', 'Pyrke', 'IL', 'dormant', '2020-09-07', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('232367281', 'Barde', 'Heady', 'CL', 'dormant', '1989-11-10', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('839022021', 'Romain', 'Capoun', 'BR', 'dormant', '1995-06-17', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('512915785', 'Lazar', 'Cornwall', 'CN', 'active', '2019-11-10', 'Combat');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('184122808', 'Raimund', 'Beakes', 'UA', 'retired', '2016-06-03', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('089275434', 'Kelly', 'Reglar', 'ES', 'retired', '1996-01-08', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('517688869', 'Lilah', 'Pughsley', 'CO', 'dormant', '1976-01-22', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('482731439', 'Maridel', 'Croy', 'RU', 'retired', '2008-04-19', 'Investigation');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('703809378', 'Deva', 'Jenno', 'ID', 'dormant', '2014-10-25', 'Diplomacy');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('937378524', 'Gaby', 'Ramberg', 'CN', 'dormant', '1975-06-07', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('710816639', 'Atalanta', 'Addyman', 'IT', 'dormant', '1990-08-12', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('534452625', 'Drucill', 'Mabson', 'FI', 'active', '2002-05-27', 'Diplomacy');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('759490605', 'Rolph', 'Cracoe', 'CN', 'retired', '2008-08-29', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('695714117', 'Rollie', 'Janus', 'ET', 'dormant', '1975-01-31', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('063198403', 'Allina', 'Magog', 'CN', 'retired', '2011-12-28', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('724385627', 'Dorita', 'Barmadier', 'TD', 'active', '1982-03-14', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('792723624', 'Blancha', 'Blewmen', 'HN', 'dormant', '2005-04-11', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('479067711', 'Sigrid', 'Cornwell', 'RU', 'active', '2012-06-07', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('152175196', 'Germaine', 'Boshere', 'KZ', 'retired', '1974-07-13', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('292537974', 'Nanon', 'Chrystal', 'PH', 'active', '1984-07-21', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('253100925', 'Aloise', 'Spurier', 'SA', 'active', '1984-08-19', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('607189899', 'Griffin', 'Stemson', 'ID', 'active', '2011-06-09', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('763766624', 'Devin', 'Gutman', 'RS', 'active', '2019-04-01', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('208225651', 'Trumaine', 'Brooksby', 'IQ', 'active', '1982-11-30', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('802440955', 'Maximilian', 'Garrigan', 'CI', 'dormant', '1980-05-03', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('520323636', 'Hy', 'Figgures', 'SE', 'retired', '1995-08-04', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('667108608', 'Giavani', 'Speachley', 'BF', 'retired', '2010-08-19', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('007914611', 'Lazar', 'Biddleston', 'AM', 'dormant', '1971-10-11', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('502920908', 'Alasdair', 'Howsego', 'BR', 'retired', '2008-05-03', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('393600390', 'Gerald', 'Sausman', 'ID', 'dormant', '2017-03-29', 'Combat');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('053138612', 'Kienan', 'Erangy', 'ID', 'active', '1983-02-15', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('338645270', 'Linnell', 'Hackford', 'TZ', 'active', '1994-04-02', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('837559423', 'Liam', 'Ellcock', 'TH', 'dormant', '2001-11-09', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('773824880', 'Geoffrey', 'Lymbourne', 'CN', 'retired', '1982-05-21', 'Investigation');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('056356085', 'Kayley', 'Cogdon', 'ID', 'dormant', '1975-06-19', 'Diplomacy');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('900736933', 'Sibley', 'Griniov', 'CN', 'active', '2017-11-06', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('828163976', 'Fanya', 'Maultby', 'BR', 'dormant', '2019-01-25', 'Trade');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('653539246', 'Gabriellia', 'Elnough', 'ID', 'dormant', '2006-06-22', 'Investigation');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('479944591', 'Park', 'Coggles', 'CO', 'retired', '2012-08-15', 'Diplomacy');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('347720765', 'Reider', 'Pedrocchi', 'PH', 'retired', '2011-03-31', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('905599753', 'Shermy', 'Millthorpe', 'SE', 'dormant', '1971-12-23', 'Infiltration');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('725900058', 'Dacie', 'Izard', 'CN', 'active', '1996-04-24', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('446253378', 'Aldwin', 'Bilbey', 'PE', 'active', '2011-07-31', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('926553017', 'Curry', 'Winfred', 'PL', 'retired', '1976-01-17', 'Combat');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('956800240', 'Jeremy', 'O''Fallowne', 'AL', 'retired', '1985-12-14', 'Research');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('966028758', 'Dorolisa', 'Idel', 'FR', 'active', '1984-09-19', 'Extraction');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('912508752', 'Donny', 'Glandfield', 'UA', 'active', '1986-09-19', 'Combat');
insert into agent (id, first_name, last_name, base, status, activation_date, top_skill) values ('185737099', 'Agretha', 'Swires', 'ID', 'retired', '1989-09-19', 'Research');

/* SQL DML for mission Table */
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('944506857', 'Zoolab 174', 'CN', 'aborted', 8, '2020-04-09', '2024-01-08');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('972387674', 'Y-Solowarm 778', 'PT', 'aborted', 5, '1973-09-08', '1978-11-02');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('301995076', 'Hatity 398', 'ES', 'aborted', 1, '1994-08-19', '2004-10-30');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('018877741', 'Sub-Ex 17', 'IR', 'completed', 1, '1988-08-13', '1989-04-08');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('128861788', 'Overhold 996', 'PE', 'ongoing', 3, '1974-11-29', '1980-02-02');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('651555261', 'Konklux 463', 'CN', 'completed', 1, '1963-04-09', '1975-04-28');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('584211021', 'Tempsoft 746', 'CN', 'ongoing', 7, '1980-09-10', '1993-09-03');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('607866719', 'Ronstring 914', 'BW', 'ongoing', 9, '2016-04-23', '2017-04-27');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('814378215', 'Gembucket 538', 'MR', 'completed', 8, '1993-06-26', '2003-05-03');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('443510208', 'Stronghold 456', 'CO', 'aborted', 3, '2008-07-16', '2016-02-20');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('306374957', 'Solarbreeze 849', 'CN', 'ongoing', 9, '1984-06-22', '1989-07-09');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('430805785', 'Stringtough 293', 'FR', 'completed', 1, '1987-07-29', '2000-10-05');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('253186369', 'Cardguard 195', 'KR', 'ongoing', 7, '1993-03-25', '1998-03-22');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('118971881', 'Voltsillam 886', 'CN', 'completed', 9, '2011-01-20', '2017-03-25');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('527848650', 'Toughjoyfax 994', 'PT', 'aborted', 1, '2001-11-10', '2010-10-09');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('243634338', 'Zathin 844', 'EG', 'completed', 1, '1961-04-14', '1974-08-03');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('096525056', 'Andalax 547', 'PE', 'ongoing', 5, '1973-01-30', '1975-10-02');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('239093242', 'Bigtax 76', 'ID', 'completed', 4, '2017-08-07', '2028-04-06');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('058648551', 'Job 602', 'PS', 'ongoing', 5, '1970-04-06', '1971-03-23');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('455219594', 'Biodex 923', 'PH', 'completed', 8, '1989-05-16', '2000-10-09');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('197770511', 'Tampflex 303', 'IR', 'completed', 6, '2015-05-09', '2019-06-15');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('735344054', 'Holdlamis 850', 'ID', 'completed', 4, '2016-05-14', '2023-03-07');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('128824419', 'Stim 805', 'YE', 'aborted', 9, '1974-02-17', '1974-04-09');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('317460190', 'Temp 727', 'ET', 'completed', 1, '1978-09-06', '1984-02-05');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('714016624', 'Sonsing 853', 'RU', 'aborted', 3, '2020-07-06', '2023-07-11');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('140014432', 'Ronstring 954', 'ID', 'ongoing', 5, '2018-09-29', '2025-09-19');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('537571049', 'Treeflex 321', 'UA', 'completed', 6, '1995-12-19', '2008-05-25');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('278606913', 'Konklux 230', 'RU', 'ongoing', 5, '1963-04-13', '1976-08-24');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('001310450', 'Zamit 828', 'CN', 'completed', 6, '1965-04-11', '1978-01-25');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('855407936', 'Wrapsafe 183', 'BH', 'completed', 10, '1979-01-31', '1983-07-20');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('302956036', 'Job 343', 'ID', 'aborted', 1, '2000-03-16', '2003-08-09');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('611067649', 'Redhold 670', 'PL', 'ongoing', 6, '1970-05-01', '1970-06-27');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('046330530', 'Vagram 990', 'PT', 'aborted', 6, '1965-08-09', '1977-05-24');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('272399662', 'Toughjoyfax 935', 'CL', 'ongoing', 5, '2016-11-25', '2028-07-30');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('367957059', 'Holdlamis 527', 'PH', 'aborted', 1, '1987-11-10', '1989-10-06');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('700528839', 'Bigtax 621', 'CN', 'completed', 6, '2005-04-08', '2012-06-09');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('043040052', 'Y-find 133', 'PA', 'ongoing', 10, '1980-09-28', '1990-01-03');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('503878085', 'Hatity 391', 'CN', 'completed', 6, '1971-08-31', '1982-06-02');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('440739465', 'Bitwolf 575', 'CN', 'aborted', 7, '1969-07-08', '1979-07-06');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('441396509', 'Flexidy 451', 'ID', 'aborted', 10, '2013-10-02', '2016-11-23');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('345323621', 'Tempsoft 912', 'LV', 'ongoing', 9, '2020-04-04', '2025-03-25');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('548518375', 'Voyatouch 44', 'CN', 'completed', 1, '2003-01-26', '2015-08-18');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('448627130', 'Tresom 98', 'CA', 'ongoing', 10, '1995-12-24', '2003-03-24');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('972033217', 'Bytecard 420', 'GR', 'aborted', 8, '1995-05-07', '2007-03-30');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('287268378', 'Gembucket 130', 'PL', 'ongoing', 8, '1984-08-02', '1990-09-06');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('077159629', 'Zaam-Dox 871', 'PT', 'aborted', 10, '2003-10-16', '2005-12-27');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('839804040', 'Bitchip 40', 'NG', 'aborted', 5, '1996-07-15', '2007-10-23');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('003303674', 'Subin 447', 'CA', 'aborted', 9, '1964-11-14', '1964-11-17');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('832110789', 'Domainer 670', 'ZA', 'completed', 3, '2012-03-05', '2015-02-02');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('806134818', 'Daltfresh 5', 'PE', 'aborted', 9, '2008-09-21', '2018-06-07');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('972419729', 'Flowdesk 400', 'ID', 'ongoing', 6, '1981-07-11', '1987-07-27');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('927594517', 'Voyatouch 295', 'JP', 'aborted', 9, '1964-01-25', '1965-10-25');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('313495000', 'Bamity 123', 'CA', 'completed', 1, '1969-09-27', '1973-01-13');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('113691113', 'Subin 336', 'ET', 'completed', 6, '2017-05-07', '2027-07-29');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('558906899', 'Cardify 907', 'CN', 'ongoing', 7, '1971-11-23', '1979-06-01');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('306653719', 'Span 682', 'CN', 'aborted', 10, '2000-09-05', '2011-12-19');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('574059926', 'Veribet 6', 'CN', 'completed', 10, '2004-03-26', '2004-12-09');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('302399319', 'Fix San 61', 'RU', 'completed', 10, '2018-08-02', '2031-08-01');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('292506132', 'Temp 820', 'RU', 'completed', 10, '1962-03-26', '1966-01-03');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('890900994', 'Aerified 470', 'ID', 'completed', 5, '2015-03-12', '2015-08-03');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('403674597', 'Rank 193', 'NP', 'ongoing', 8, '1965-10-29', '1971-06-15');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('921939215', 'Trippledex 987', 'GR', 'aborted', 5, '1994-11-16', '2006-08-18');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('892822218', 'Y-Solowarm 982', 'ID', 'aborted', 4, '1963-09-26', '1968-10-10');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('734432381', 'Holdlamis 476', 'ID', 'ongoing', 8, '1969-07-27', '1972-07-09');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('906044740', 'Stim 712', 'PE', 'ongoing', 1, '1972-01-07', '1978-02-17');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('855764745', 'Stim 347', 'ID', 'completed', 8, '1971-01-07', '1980-03-04');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('625690231', 'Zaam-Dox 278', 'RU', 'ongoing', 3, '2015-01-15', '2028-02-21');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('561140464', 'Subin 849', 'AM', 'ongoing', 10, '2018-07-16', '2022-07-09');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('761615717', 'Zamit 865', 'PH', 'completed', 8, '1966-07-16', '1977-07-02');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('077044688', 'Konklab 760', 'RU', 'completed', 10, '2016-07-27', '2016-12-13');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('295429389', 'Mat Lam Tam 439', 'AL', 'aborted', 8, '1999-06-20', '2006-08-03');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('884778098', 'Y-Solowarm 825', 'BR', 'ongoing', 8, '2021-04-08', '2025-05-28');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('353628520', 'Span 945', 'RU', 'completed', 7, '2002-11-18', '2008-06-04');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('217481391', 'Span 530', 'RU', 'aborted', 9, '2010-03-29', '2023-06-16');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('851892006', 'Zathin 223', 'PL', 'ongoing', 3, '1976-12-23', '1990-05-17');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('161451811', 'Transcof 571', 'SS', 'completed', 9, '1986-11-26', '1990-01-06');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('091468839', 'Opela 80', 'PH', 'completed', 10, '1983-04-10', '1985-12-03');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('828914233', 'Cookley 832', 'ID', 'completed', 6, '1977-07-03', '1985-05-15');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('273783770', 'Ventosanzap 565', 'RU', 'aborted', 5, '1985-07-08', '1995-06-02');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('803366427', 'Viva 354', 'PT', 'completed', 8, '1991-08-19', '1992-07-08');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('577582209', 'Viva 168', 'TZ', 'completed', 9, '1980-11-29', '1985-12-30');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('907630377', 'Alphazap 538', 'UA', 'completed', 5, '1985-05-08', '1988-07-12');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('014486609', 'Viva 910', 'PL', 'completed', 6, '1989-07-24', '1994-07-02');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('200691218', 'Lotlux 999', 'PL', 'ongoing', 6, '1967-11-14', '1978-06-23');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('073139115', 'Overhold 604', 'YE', 'ongoing', 2, '2007-11-16', '2014-02-17');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('343497296', 'Voyatouch 787', 'RU', 'completed', 7, '2017-04-02', '2021-05-13');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('032711987', 'Alpha 321', 'ID', 'completed', 10, '2008-03-31', '2013-12-14');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('649286507', 'Lotlux 743', 'PH', 'aborted', 9, '2015-06-26', '2027-05-17');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('295995079', 'Rank 801', 'CN', 'aborted', 2, '1974-07-20', '1975-12-16');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('685069442', 'Matsoft 973', 'PL', 'completed', 3, '1982-01-05', '1983-12-19');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('278706125', 'Y-find 603', 'GR', 'ongoing', 10, '2006-07-25', '2008-03-06');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('818947471', 'Toughjoyfax 874', 'TH', 'completed', 1, '2020-07-11', '2025-08-15');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('426137359', 'Bitwolf 75', 'PL', 'aborted', 6, '1969-04-29', '1981-07-09');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('961038870', 'Tres-Zap 593', 'KP', 'completed', 3, '1995-12-04', '2009-04-03');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('169170019', 'Alpha 590', 'PH', 'ongoing', 9, '1995-01-19', '2004-08-29');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('807011498', 'Bitchip 592', 'UA', 'ongoing', 3, '1966-09-02', '1973-12-28');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('808244863', 'Gembucket 360', 'CN', 'ongoing', 4, '1986-11-23', '1987-08-15');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('540333437', 'Otcom 903', 'ID', 'aborted', 8, '1991-09-22', '2003-06-17');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('134740644', 'Matsoft 110', 'CL', 'completed', 5, '1997-11-21', '2006-05-16');
insert into mission (id, name, country, status, threat_level, start_date, completion_target_date) values ('884408900', 'Voltsillam 699', 'BG', 'completed', 10, '1973-12-12', '1976-01-29');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO progress (mission_id, mission_name, mission_status, agent_id, start_date)
SELECT mission.id, mission.name, mission.status, agent.id, start_date
FROM agent, mission
ORDER BY random()
LIMIT 1000;