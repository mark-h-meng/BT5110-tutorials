/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/

/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */

/* The example intended to illustrate how Crunchbase (a platform documenting business information about public/private company) works,
focusing on the fundraising activities. There would be 3 tables, where the 1st one will be a master list of all potential investors, their
public email addresses, investor type (ie, family offices or venture capital), country and registration date; while the second one would 
be a master list of all companies, with their registration date and country. The third table will document all fund raising activities between the investors 
and companies, however, the table only document the closed date or the completion date of these activities to ensure compliance while the closed amount is a
column accepting null value since it might be a highly confidential information. Nonetheless, it will minimally document if the fundraising round is a success
or not, and which series it is. 

The code below is written in PostgreSQL.
*/

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/*
 CREATE TABLE if NOT EXISTS investors (
 inv_name VARCHAR(64) NOT NULL,
 email VARCHAR(64) UNIQUE NOT NULL,
 inv_type VARCHAR(64),
 registration DATE NOT NULL,
 country VARCHAR(64) NOT NULL,
 inv_id bigint primary key
 check (inv_type in ('Family Offices', 'Venture Capital')));

 CREATE TABLE if NOT EXISTS company (
 company_name VARCHAR(64) NOT NULL,
 registration_date DATE NOT NULL,
 country VARCHAR(64) NOT NULL,
 company_id bigint primary key) ;
 
CREATE TABLE if not Exists fundraised (
inv_id bigint references investors(inv_id) not null,
company_id bigint references company(company_id) not null,
status VARCHAR(64) check (status in ('Completed', 'Failed')),
closed_amount numeric,
closed_date Date not null,
series VARCHAR(64) check (series in ('Angel-Investment Round', 'Series Funding Round',
									 'IPO')));
*/


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/*
insert into company (company_name, registration_date, country, company_id) values ('Skyba', '02/09/2020', 'China', 1);
insert into company (company_name, registration_date, country, company_id) values ('Riffwire', '04/09/2020', 'Poland', 2);
insert into company (company_name, registration_date, country, company_id) values ('Twitterwire', '07/06/2021', 'Argentina', 3);
insert into company (company_name, registration_date, country, company_id) values ('Zazio', '15/01/2021', 'China', 4);
insert into company (company_name, registration_date, country, company_id) values ('Flipstorm', '11/09/2020', 'United Kingdom', 5);
insert into company (company_name, registration_date, country, company_id) values ('Cogibox', '23/02/2021', 'China', 6);
insert into company (company_name, registration_date, country, company_id) values ('Quatz', '09/09/2020', 'Czech Republic', 7);
insert into company (company_name, registration_date, country, company_id) values ('Eire', '28/03/2021', 'China', 8);
insert into company (company_name, registration_date, country, company_id) values ('Voomm', '05/12/2020', 'Indonesia', 9);
insert into company (company_name, registration_date, country, company_id) values ('Aivee', '26/09/2020', 'Colombia', 10);
insert into company (company_name, registration_date, country, company_id) values ('Skajo', '04/11/2020', 'China', 11);
insert into company (company_name, registration_date, country, company_id) values ('Snaptags', '31/10/2020', 'Brazil', 12);
insert into company (company_name, registration_date, country, company_id) values ('Wordify', '17/12/2020', 'Japan', 13);
insert into company (company_name, registration_date, country, company_id) values ('Zoombeat', '31/08/2020', 'Japan', 14);
insert into company (company_name, registration_date, country, company_id) values ('Photofeed', '24/01/2021', 'Ireland', 15);
insert into company (company_name, registration_date, country, company_id) values ('Latz', '04/12/2020', 'Uganda', 16);
insert into company (company_name, registration_date, country, company_id) values ('Fliptune', '14/11/2020', 'Poland', 17);
insert into company (company_name, registration_date, country, company_id) values ('Topicblab', '07/10/2020', 'Philippines', 18);
insert into company (company_name, registration_date, country, company_id) values ('Fivebridge', '12/12/2020', 'Russia', 19);
insert into company (company_name, registration_date, country, company_id) values ('Skippad', '28/05/2021', 'United States', 20);
insert into company (company_name, registration_date, country, company_id) values ('Teklist', '04/05/2021', 'Iran', 21);
insert into company (company_name, registration_date, country, company_id) values ('Photospace', '13/03/2021', 'Bahamas', 22);
insert into company (company_name, registration_date, country, company_id) values ('Yakijo', '12/02/2021', 'Poland', 23);
insert into company (company_name, registration_date, country, company_id) values ('Photojam', '29/11/2020', 'China', 24);
insert into company (company_name, registration_date, country, company_id) values ('Jatri', '25/12/2020', 'Mali', 25);
insert into company (company_name, registration_date, country, company_id) values ('Chatterpoint', '28/04/2021', 'Russia', 26);
insert into company (company_name, registration_date, country, company_id) values ('Eire', '15/10/2020', 'Argentina', 27);
insert into company (company_name, registration_date, country, company_id) values ('Quatz', '30/11/2020', 'Indonesia', 28);
insert into company (company_name, registration_date, country, company_id) values ('Trupe', '15/07/2021', 'Portugal', 29);
insert into company (company_name, registration_date, country, company_id) values ('Quire', '02/06/2021', 'China', 30);
insert into company (company_name, registration_date, country, company_id) values ('Podcat', '27/01/2021', 'Saint Kitts and Nevis', 31);
insert into company (company_name, registration_date, country, company_id) values ('Zooxo', '02/11/2020', 'Indonesia', 32);
insert into company (company_name, registration_date, country, company_id) values ('Abata', '27/05/2021', 'China', 33);
insert into company (company_name, registration_date, country, company_id) values ('Livefish', '31/10/2020', 'Brazil', 34);
insert into company (company_name, registration_date, country, company_id) values ('Talane', '23/03/2021', 'New Caledonia', 35);
insert into company (company_name, registration_date, country, company_id) values ('JumpXS', '10/11/2020', 'Philippines', 36);
insert into company (company_name, registration_date, country, company_id) values ('Aivee', '11/11/2020', 'Russia', 37);
insert into company (company_name, registration_date, country, company_id) values ('Skyndu', '23/12/2020', 'Brazil', 38);
insert into company (company_name, registration_date, country, company_id) values ('Linkbuzz', '20/06/2021', 'Poland', 39);
insert into company (company_name, registration_date, country, company_id) values ('Riffpath', '30/04/2021', 'Nigeria', 40);
insert into company (company_name, registration_date, country, company_id) values ('Shufflebeat', '29/04/2021', 'China', 41);
insert into company (company_name, registration_date, country, company_id) values ('Livetube', '04/01/2021', 'Venezuela', 42);
insert into company (company_name, registration_date, country, company_id) values ('Livepath', '15/06/2021', 'Sweden', 43);
insert into company (company_name, registration_date, country, company_id) values ('Topicware', '28/09/2020', 'Sweden', 44);
insert into company (company_name, registration_date, country, company_id) values ('Eazzy', '18/12/2020', 'Argentina', 45);
insert into company (company_name, registration_date, country, company_id) values ('Avamm', '21/03/2021', 'Colombia', 46);
insert into company (company_name, registration_date, country, company_id) values ('Edgeify', '14/07/2021', 'Portugal', 47);
insert into company (company_name, registration_date, country, company_id) values ('Meevee', '13/02/2021', 'Indonesia', 48);
insert into company (company_name, registration_date, country, company_id) values ('Photobean', '09/04/2021', 'Bahamas', 49);
insert into company (company_name, registration_date, country, company_id) values ('Tanoodle', '07/04/2021', 'Greece', 50);
insert into company (company_name, registration_date, country, company_id) values ('Realcube', '27/07/2021', 'China', 51);
insert into company (company_name, registration_date, country, company_id) values ('Realbridge', '01/05/2021', 'Hong Kong', 52);
insert into company (company_name, registration_date, country, company_id) values ('Lajo', '21/08/2021', 'Brazil', 53);
insert into company (company_name, registration_date, country, company_id) values ('Rhycero', '18/05/2021', 'Nigeria', 54);
insert into company (company_name, registration_date, country, company_id) values ('Realbuzz', '05/01/2021', 'Philippines', 55);
insert into company (company_name, registration_date, country, company_id) values ('Meeveo', '26/06/2021', 'Indonesia', 56);
insert into company (company_name, registration_date, country, company_id) values ('Blogtag', '18/10/2020', 'Brazil', 57);
insert into company (company_name, registration_date, country, company_id) values ('Einti', '02/12/2020', 'Argentina', 58);
insert into company (company_name, registration_date, country, company_id) values ('Fadeo', '06/12/2020', 'Indonesia', 59);
insert into company (company_name, registration_date, country, company_id) values ('Tazz', '01/02/2021', 'Russia', 60);
insert into company (company_name, registration_date, country, company_id) values ('Tagchat', '20/03/2021', 'Myanmar', 61);
insert into company (company_name, registration_date, country, company_id) values ('Buzzster', '07/11/2020', 'Thailand', 62);
insert into company (company_name, registration_date, country, company_id) values ('Skibox', '20/03/2021', 'China', 63);
insert into company (company_name, registration_date, country, company_id) values ('Devpoint', '24/04/2021', 'Poland', 64);
insert into company (company_name, registration_date, country, company_id) values ('Gabcube', '07/08/2021', 'Germany', 65);
insert into company (company_name, registration_date, country, company_id) values ('Rhynyx', '03/04/2021', 'Indonesia', 66);
insert into company (company_name, registration_date, country, company_id) values ('Eamia', '29/08/2020', 'Indonesia', 67);
insert into company (company_name, registration_date, country, company_id) values ('Buzzdog', '12/04/2021', 'Sweden', 68);
insert into company (company_name, registration_date, country, company_id) values ('Dabjam', '07/03/2021', 'Greece', 69);
insert into company (company_name, registration_date, country, company_id) values ('Quimba', '11/10/2020', 'Burundi', 70);
insert into company (company_name, registration_date, country, company_id) values ('Aibox', '11/03/2021', 'China', 71);
insert into company (company_name, registration_date, country, company_id) values ('Photojam', '02/10/2020', 'Poland', 72);
insert into company (company_name, registration_date, country, company_id) values ('Ntag', '17/12/2020', 'China', 73);
insert into company (company_name, registration_date, country, company_id) values ('Tanoodle', '04/07/2021', 'Indonesia', 74);
insert into company (company_name, registration_date, country, company_id) values ('Geba', '27/11/2020', 'Finland', 75);
insert into company (company_name, registration_date, country, company_id) values ('Vitz', '06/06/2021', 'South Africa', 76);
insert into company (company_name, registration_date, country, company_id) values ('Tagcat', '01/03/2021', 'Argentina', 77);
insert into company (company_name, registration_date, country, company_id) values ('Gigashots', '25/11/2020', 'China', 78);
insert into company (company_name, registration_date, country, company_id) values ('Dabjam', '20/12/2020', 'France', 79);
insert into company (company_name, registration_date, country, company_id) values ('Gabvine', '05/07/2021', 'Russia', 80);
insert into company (company_name, registration_date, country, company_id) values ('Skajo', '17/01/2021', 'Japan', 81);
insert into company (company_name, registration_date, country, company_id) values ('Oozz', '24/08/2020', 'China', 82);
insert into company (company_name, registration_date, country, company_id) values ('Fiveclub', '19/11/2020', 'Russia', 83);
insert into company (company_name, registration_date, country, company_id) values ('Zoomlounge', '19/06/2021', 'Malawi', 84);
insert into company (company_name, registration_date, country, company_id) values ('Gabcube', '15/07/2021', 'Poland', 85);
insert into company (company_name, registration_date, country, company_id) values ('Twitternation', '26/06/2021', 'Philippines', 86);
insert into company (company_name, registration_date, country, company_id) values ('Twiyo', '03/09/2020', 'Brazil', 87);
insert into company (company_name, registration_date, country, company_id) values ('Dabshots', '15/01/2021', 'Russia', 88);
insert into company (company_name, registration_date, country, company_id) values ('Vinder', '06/11/2020', 'Indonesia', 89);
insert into company (company_name, registration_date, country, company_id) values ('Edgeblab', '19/03/2021', 'Russia', 90);
insert into company (company_name, registration_date, country, company_id) values ('Mydo', '03/06/2021', 'Argentina', 91);
insert into company (company_name, registration_date, country, company_id) values ('Buzzster', '11/09/2020', 'Pakistan', 92);
insert into company (company_name, registration_date, country, company_id) values ('Jatri', '14/04/2021', 'Philippines', 93);
insert into company (company_name, registration_date, country, company_id) values ('Camido', '22/07/2021', 'China', 94);
insert into company (company_name, registration_date, country, company_id) values ('Avaveo', '16/05/2021', 'Indonesia', 95);
insert into company (company_name, registration_date, country, company_id) values ('Twitternation', '06/02/2021', 'Spain', 96);
insert into company (company_name, registration_date, country, company_id) values ('Rhynyx', '13/03/2021', 'China', 97);
insert into company (company_name, registration_date, country, company_id) values ('Yakijo', '11/08/2021', 'Brazil', 98);
insert into company (company_name, registration_date, country, company_id) values ('Quaxo', '28/11/2020', 'Nepal', 99);
insert into company (company_name, registration_date, country, company_id) values ('Rhynoodle', '10/05/2021', 'Maldives', 100);

insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Browsedrive', 'lbanishevitz0@sogou.com', 'Family Offices', '05/07/2021', 'United States', 1);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Shuffledrive', 'tnarup1@canalblog.com', 'Venture Capital', '26/06/2021', 'Brazil', 2);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Yoveo', 'kpeplow2@google.co.jp', 'Venture Capital', '27/10/2020', 'Cuba', 3);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Vinder', 'dbrotherhead3@mapy.cz', 'Family Offices', '10/10/2020', 'Niger', 4);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Yambee', 'ajennemann4@yelp.com', 'Venture Capital', '05/04/2021', 'Poland', 5);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Shuffledrive', 'zgaize5@gnu.org', 'Venture Capital', '17/11/2020', 'Indonesia', 6);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Dynava', 'parmfirld6@multiply.com', 'Venture Capital', '23/12/2020', 'Botswana', 7);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Zoomzone', 'smarchiso7@yellowbook.com', 'Family Offices', '09/06/2021', 'Madagascar', 8);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Pixonyx', 'xdumphy8@booking.com', 'Family Offices', '25/09/2020', 'Central African Republic', 9);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Thoughtstorm', 'mcroxley9@squidoo.com', 'Family Offices', '18/12/2020', 'China', 10);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Cogibox', 'eallsopa@studiopress.com', 'Family Offices', '15/08/2021', 'China', 11);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Wikizz', 'mroathb@businessinsider.com', 'Venture Capital', '21/06/2021', 'China', 12);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Meejo', 'mheeneyc@flickr.com', 'Venture Capital', '25/10/2020', 'Burkina Faso', 13);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Jetwire', 'bcarthyd@psu.edu', 'Venture Capital', '17/11/2020', 'China', 14);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Realblab', 'sstantone@amazonaws.com', 'Venture Capital', '05/12/2020', 'Indonesia', 15);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Youtags', 'fsaraf@unesco.org', 'Family Offices', '15/03/2021', 'Indonesia', 16);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Vitz', 'hstennerg@cbslocal.com', 'Venture Capital', '30/08/2020', 'China', 17);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Topdrive', 'gjoyceh@usda.gov', 'Family Offices', '21/12/2020', 'Trinidad and Tobago', 18);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Jabbersphere', 'cduffelli@diigo.com', 'Venture Capital', '01/01/2021', 'United States', 19);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Vidoo', 'jsalkeldj@plala.or.jp', 'Venture Capital', '19/11/2020', 'China', 20);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Dynabox', 'rnutterk@gmpg.org', 'Venture Capital', '15/10/2020', 'Kenya', 21);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Edgetag', 'ekraftl@unc.edu', 'Family Offices', '31/07/2021', 'Indonesia', 22);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Livefish', 'gdallowm@artisteer.com', 'Family Offices', '25/12/2020', 'Japan', 23);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Dynabox', 'hdysartn@arizona.edu', 'Family Offices', '30/04/2021', 'China', 24);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Fivechat', 'dgolagleyo@google.de', 'Venture Capital', '22/02/2021', 'Slovenia', 25);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Yotz', 'ljaynep@cpanel.net', 'Venture Capital', '25/01/2021', 'Ukraine', 26);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Devshare', 'vnoodsq@cmu.edu', 'Venture Capital', '16/12/2020', 'Portugal', 27);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Fanoodle', 'mfranzker@auda.org.au', 'Venture Capital', '10/02/2021', 'Pakistan', 28);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Tambee', 'cchatwins@prlog.org', 'Family Offices', '31/08/2020', 'France', 29);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Edgewire', 'hpickvancet@irs.gov', 'Family Offices', '11/04/2021', 'Tajikistan', 30);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Pixoboo', 'rfreemanu@webeden.co.uk', 'Venture Capital', '12/12/2020', 'Ukraine', 31);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Tazzy', 'eohanlonv@discuz.net', 'Venture Capital', '09/08/2021', 'Armenia', 32);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Shufflebeat', 'jostw@japanpost.jp', 'Venture Capital', '08/11/2020', 'Finland', 33);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Linktype', 'bgeesonx@jigsy.com', 'Venture Capital', '03/06/2021', 'Democratic Republic of the Congo', 34);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Twitternation', 'tdelatremoilley@usnews.com', 'Family Offices', '08/07/2021', 'Poland', 35);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Tagchat', 'mkrinkz@baidu.com', 'Family Offices', '04/02/2021', 'Indonesia', 36);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Mymm', 'aadamthwaite10@networksolutions.com', 'Family Offices', '30/11/2020', 'Slovenia', 37);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Skinte', 'mdoyland11@yandex.ru', 'Family Offices', '21/11/2020', 'France', 38);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Meevee', 'tmccallam12@skyrock.com', 'Family Offices', '08/12/2020', 'Indonesia', 39);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Kaymbo', 'smallows13@berkeley.edu', 'Family Offices', '11/11/2020', 'Poland', 40);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Yoveo', 'wjoerning14@vkontakte.ru', 'Family Offices', '20/02/2021', 'Armenia', 41);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Devify', 'jarundel15@google.de', 'Venture Capital', '10/11/2020', 'Colombia', 42);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Camido', 'bmacpherson16@issuu.com', 'Venture Capital', '08/05/2021', 'Philippines', 43);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Yakitri', 'thiddy17@booking.com', 'Family Offices', '08/06/2021', 'Indonesia', 44);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Cogibox', 'btagg18@histats.com', 'Venture Capital', '21/01/2021', 'Montenegro', 45);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Rooxo', 'gbrisseau19@drupal.org', 'Family Offices', '06/09/2020', 'Thailand', 46);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Lajo', 'cknapton1a@ning.com', 'Family Offices', '29/12/2020', 'China', 47);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Tazz', 'arizziello1b@blogger.com', 'Venture Capital', '06/09/2020', 'China', 48);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Twiyo', 'ksouthan1c@myspace.com', 'Venture Capital', '28/05/2021', 'Ukraine', 49);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Rooxo', 'gjelly1d@ox.ac.uk', 'Venture Capital', '13/04/2021', 'Portugal', 50);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Topiclounge', 'cdoward1e@wsj.com', 'Family Offices', '07/10/2020', 'Indonesia', 51);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Kanoodle', 'dclinch1f@naver.com', 'Family Offices', '11/06/2021', 'Comoros', 52);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Voolia', 'dridding1g@washington.edu', 'Family Offices', '21/02/2021', 'Indonesia', 53);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Meedoo', 'isherrum1h@usatoday.com', 'Family Offices', '17/04/2021', 'Indonesia', 54);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Rhyloo', 'hcoppock1i@sun.com', 'Family Offices', '22/01/2021', 'Portugal', 55);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Vitz', 'bwogdon1j@sakura.ne.jp', 'Family Offices', '19/06/2021', 'Russia', 56);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Skyble', 'kdurrell1k@homestead.com', 'Family Offices', '17/01/2021', 'Canada', 57);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Tekfly', 'fmoral1l@nih.gov', 'Family Offices', '12/09/2020', 'Philippines', 58);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Gabtune', 'rlamberth1m@de.vu', 'Venture Capital', '22/03/2021', 'China', 59);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Topiclounge', 'dtomaszewicz1n@japanpost.jp', 'Family Offices', '28/04/2021', 'Anguilla', 60);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Realmix', 'khugonnet1o@parallels.com', 'Venture Capital', '29/09/2020', 'Syria', 61);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Wikizz', 'sorton1p@dailymotion.com', 'Venture Capital', '08/11/2020', 'Indonesia', 62);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Zoombox', 'vfiggins1q@slideshare.net', 'Venture Capital', '24/11/2020', 'Vietnam', 63);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Trudeo', 'bbroker1r@infoseek.co.jp', 'Family Offices', '12/09/2020', 'Philippines', 64);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Oba', 'crothschild1s@mlb.com', 'Venture Capital', '05/02/2021', 'Macedonia', 65);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Trunyx', 'jdanielsohn1t@goo.gl', 'Family Offices', '27/09/2020', 'Poland', 66);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Geba', 'ltarbet1u@slate.com', 'Family Offices', '03/06/2021', 'Indonesia', 67);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Skippad', 'ccrielly1v@kickstarter.com', 'Family Offices', '17/09/2020', 'Japan', 68);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Podcat', 'rdyet1w@wikispaces.com', 'Family Offices', '07/07/2021', 'Russia', 69);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Realmix', 'vjurgenson1x@icq.com', 'Venture Capital', '11/01/2021', 'China', 70);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Avamm', 'bpadberry1y@reverbnation.com', 'Family Offices', '01/08/2021', 'Indonesia', 71);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Demivee', 'dbamb1z@gravatar.com', 'Family Offices', '08/04/2021', 'China', 72);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Ozu', 'rhekkert20@epa.gov', 'Venture Capital', '16/04/2021', 'China', 73);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Eidel', 'zgwinnett21@constantcontact.com', 'Venture Capital', '09/06/2021', 'Philippines', 74);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Dabshots', 'salder22@jigsy.com', 'Family Offices', '05/08/2021', 'China', 75);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Buzzdog', 'ltelfer23@constantcontact.com', 'Family Offices', '10/10/2020', 'Sweden', 76);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Skyba', 'jdonegan24@technorati.com', 'Venture Capital', '27/12/2020', 'Argentina', 77);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Dabtype', 'vsporle25@cdbaby.com', 'Venture Capital', '25/04/2021', 'China', 78);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Jabbersphere', 'battow26@hud.gov', 'Family Offices', '03/10/2020', 'South Korea', 79);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Agivu', 'naizic27@wiley.com', 'Family Offices', '20/10/2020', 'China', 80);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Pixonyx', 'radess28@1und1.de', 'Venture Capital', '29/11/2020', 'Indonesia', 81);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Voonyx', 'cdrover29@ifeng.com', 'Family Offices', '05/01/2021', 'China', 82);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Devshare', 'nverheijden2a@edublogs.org', 'Venture Capital', '16/09/2020', 'Philippines', 83);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Linkbridge', 'upolin2b@drupal.org', 'Venture Capital', '04/06/2021', 'Indonesia', 84);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Einti', 'fbenthall2c@intel.com', 'Venture Capital', '09/05/2021', 'China', 85);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Lajo', 'hsweetzer2d@angelfire.com', 'Venture Capital', '18/12/2020', 'Czech Republic', 86);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Linkbridge', 'mchalfant2e@cafepress.com', 'Family Offices', '19/06/2021', 'Bosnia and Herzegovina', 87);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Avaveo', 'jhalpeine2f@geocities.com', 'Family Offices', '29/07/2021', 'Poland', 88);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Thoughtworks', 'lquidenham2g@wired.com', 'Venture Capital', '22/05/2021', 'China', 89);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Zoomzone', 'cgirardy2h@globo.com', 'Family Offices', '18/07/2021', 'Cameroon', 90);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Youopia', 'awaight2i@jugem.jp', 'Venture Capital', '05/12/2020', 'Panama', 91);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Trupe', 'hfries2j@salon.com', 'Venture Capital', '24/11/2020', 'Tanzania', 92);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Kwinu', 'dwiburn2k@bbc.co.uk', 'Venture Capital', '25/11/2020', 'United Kingdom', 93);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Ooba', 'amungan2l@washington.edu', 'Family Offices', '29/04/2021', 'China', 94);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Rhynyx', 'gjantel2m@amazon.co.uk', 'Family Offices', '17/04/2021', 'Yemen', 95);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Innotype', 'bbonnett2n@ihg.com', 'Family Offices', '10/08/2021', 'Slovenia', 96);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Yacero', 'konthank2o@ocn.ne.jp', 'Family Offices', '25/12/2020', 'Peru', 97);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('LiveZ', 'wottam2p@lycos.com', 'Venture Capital', '03/07/2021', 'Japan', 98);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Zoomcast', 'jdulinty2q@sphinn.com', 'Family Offices', '30/07/2021', 'China', 99);
insert into investors ( inv_name, email, inv_type, registration, country, inv_id) values ('Gabcube', 'lgrahame2r@ibm.com', 'Venture Capital', '26/02/2021', 'United Arab Emirates', 100);
*/

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/*
INSERT INTO fundraised (inv_id, company_id, status, closed_amount, closed_date, series)
SELECT 
	i.inv_id, c.company_id,
  (ARRAY['Completed', 'Failed'])[round(random())+1], -- for status
  round(random()*1000000000), -- closed_amount
  NOW() + (random() * (NOW()+'90 days' - NOW())) + '30 days', -- closed_date
  (ARRAY['Angel-Investment Round', 'Series Funding Round','IPO'])[round(random())+2] -- for series
from investors i, company c TABLESAMPLE SYSTEM_ROWS(100) limit 1000;

*/


























