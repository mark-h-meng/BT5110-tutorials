/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* I created three tables, named "Customer", "Commodity" and "OrderInfo", 
to create a case that customers shop online to buy commodities (clothes in 
this case), each commodity has its own unique number.

There are 4 attributes in table "Customer", which stored customers' ID
(primary key), username, email and gender information. 4 attributes in 
table "Commodity" present their number(primary key), name, size and inventory 
level at the end of July respectively.

The table OrderInfo is designed to warehouse customers' order information, 
like a custiomer with a certain id and username bought a piece of S-size dress. 

The reason I designed "inventory" attribute is that we can group the 
"OrderInfo" table by commodity number and count how many pieces have been 
sold, so that we can calculate the inventory level at the end of Auguest 
accordingly(suppose no more replenishment).

After the codes in Question 1.e, we can use:
  select C.commodity_number, C.inventory_Jul, sales, (C.inventory_Jul-sales) as inventory_Aug
  from Commodity as C 
  left join (select commodity_number,count(*) as sales 
  from OrderInfo as O 
  group by O.commodity_number
  order by O.commodity_number)as SalesAug
  on C.commodity_number=SalesAug.commodity_number
  order by C.commodity_number;
  
to get a list of sales of each commodity and inventory at the end of Auguest.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
create table Customer (
	customer_id VARCHAR(50) primary key,
	username VARCHAR(50),
	email VARCHAR(50),
	gender VARCHAR(50)
);
create table Commodity (
	commodity_number VARCHAR(50) primary key,
	commodity_name VARCHAR(50),
	size VARCHAR(50),
	inventory_Jul INT
);
create table OrderInfo (
	customer_id VARCHAR(50),
	username VARCHAR(50),
	commodity_number VARCHAR(50),
	commodity_name VARCHAR(50),
	size VARCHAR(50),
	Foreign key (customer_id)  References Customer(customer_id),
	Foreign key (commodity_number)  References Commodity(commodity_number)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
insert into Customer (customer_id, username, email, gender) values ('43-2267860', 'cmuzzollo0', 'dchilde0@godaddy.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('96-9142313', 'rcheales1', 'lpetheridge1@soup.io', 'F');
insert into Customer (customer_id, username, email, gender) values ('51-3167457', 'acressey2', 'qgirdwood2@chicagotribune.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('90-2052436', 'kgiacopello3', 'eharvard3@facebook.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('68-9488761', 'cambridge4', 'cbillings4@sun.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('95-5750891', 'asimms5', 'ksnoad5@uol.com.br', 'M');
insert into Customer (customer_id, username, email, gender) values ('43-8709330', 'gwebley6', 'ebracchi6@nyu.edu', 'F');
insert into Customer (customer_id, username, email, gender) values ('46-9656156', 'mgorrick7', 'ckitchiner7@go.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('93-7036708', 'mbartelet8', 'rgillyett8@acquirethisname.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('28-5464185', 'vhanway9', 'lmcgee9@phoca.cz', 'F');
insert into Customer (customer_id, username, email, gender) values ('29-6657801', 'wlimeburna', 'cpetschelta@zimbio.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('38-9476642', 'pcrouchb', 'bquarlessb@cbsnews.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('47-2642924', 'lhirthc', 'jkentwellc@hostgator.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('86-4808805', 'abasinigazzid', 'ggrugerrd@xing.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('65-1522185', 'ratlaye', 'mconee@delicious.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('63-5939754', 'hmerdewf', 'episcopof@nps.gov', 'F');
insert into Customer (customer_id, username, email, gender) values ('57-3159375', 'kberthelg', 'sdurandg@furl.net', 'M');
insert into Customer (customer_id, username, email, gender) values ('52-9116229', 'bburbridgeh', 'hdundonh@scribd.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('52-9869854', 'dsydneyi', 'dmichaeli@alexa.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('08-7485383', 'evinerj', 'kyandellj@google.ru', 'M');
insert into Customer (customer_id, username, email, gender) values ('47-4297005', 'mheinsenk', 'ngniewoszk@wikimedia.org', 'M');
insert into Customer (customer_id, username, email, gender) values ('49-4399466', 'hdomaschkel', 'kdukesl@google.cn', 'M');
insert into Customer (customer_id, username, email, gender) values ('66-5019600', 'mbennetm', 'jtodorm@hud.gov', 'M');
insert into Customer (customer_id, username, email, gender) values ('36-5980362', 'vlangeleyn', 'cjindracekn@stanford.edu', 'M');
insert into Customer (customer_id, username, email, gender) values ('26-4631594', 'rbaptisteo', 'fconlaundo@tiny.cc', 'F');
insert into Customer (customer_id, username, email, gender) values ('81-2743848', 'emaylerp', 'mcanap@wunderground.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('51-4001572', 'mfendleyq', 'anovotniq@posterous.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('51-0853270', 'rstiver', 'wbillsr@cnet.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('74-2244040', 'njammets', 'tsimnetts@a8.net', 'F');
insert into Customer (customer_id, username, email, gender) values ('01-8851576', 'cplant', 'mmcguinesst@vkontakte.ru', 'F');
insert into Customer (customer_id, username, email, gender) values ('57-7320844', 'cgrouseu', 'cserotu@shareasale.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('82-9170912', 'osoutheyv', 'rsalternev@delicious.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('52-4223287', 'cpeascodw', 'espurierw@usda.gov', 'M');
insert into Customer (customer_id, username, email, gender) values ('29-4097273', 'rpatmanx', 'cmartuginx@yahoo.co.jp', 'F');
insert into Customer (customer_id, username, email, gender) values ('69-8235081', 'jpringery', 'kpainy@gmpg.org', 'F');
insert into Customer (customer_id, username, email, gender) values ('54-9858065', 'daaronz', 'akiehnltz@creativecommons.org', 'M');
insert into Customer (customer_id, username, email, gender) values ('65-9628990', 'mughi10', 'ssparham10@example.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('49-5850687', 'rstook11', 'irackstraw11@paginegialle.it', 'F');
insert into Customer (customer_id, username, email, gender) values ('13-5310987', 'lsmolan12', 'jdeaconson12@fda.gov', 'F');
insert into Customer (customer_id, username, email, gender) values ('94-2128057', 'msewter13', 'fhebbes13@jalbum.net', 'F');
insert into Customer (customer_id, username, email, gender) values ('65-2476309', 'tcarrel14', 'mson14@timesonline.co.uk', 'F');
insert into Customer (customer_id, username, email, gender) values ('63-1268195', 'elummasana15', 'mteasdalemarkie15@smh.com.au', 'M');
insert into Customer (customer_id, username, email, gender) values ('99-6319056', 'fperryman16', 'lbrinson16@cargocollective.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('98-4773774', 'abusk17', 'mmatteini17@blogspot.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('76-7207435', 'shollyer18', 'jpittet18@adobe.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('93-9535386', 'ccardenas19', 'fkaesmakers19@google.it', 'F');
insert into Customer (customer_id, username, email, gender) values ('78-7966587', 'mdevenny1a', 'crobbins1a@baidu.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('69-4900893', 'mgatiss1b', 'sbettles1b@goo.ne.jp', 'M');
insert into Customer (customer_id, username, email, gender) values ('10-1710794', 'kmckennan1c', 'smartinson1c@usgs.gov', 'F');
insert into Customer (customer_id, username, email, gender) values ('30-5275099', 'pashfold1d', 'klyster1d@globo.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('82-5017908', 'dsancto1e', 'lswoffer1e@mozilla.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('53-6095144', 'iworthington1f', 'dallgood1f@scribd.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('24-4317736', 'phaskur1g', 'mmankor1g@home.pl', 'F');
insert into Customer (customer_id, username, email, gender) values ('99-9079481', 'wbeltzner1h', 'asmall1h@earthlink.net', 'M');
insert into Customer (customer_id, username, email, gender) values ('91-0486324', 'kcabena1i', 'rogus1i@dion.ne.jp', 'M');
insert into Customer (customer_id, username, email, gender) values ('76-1685090', 'tbennion1j', 'kdeverell1j@cam.ac.uk', 'F');
insert into Customer (customer_id, username, email, gender) values ('17-4810884', 'lbarkhouse1k', 'tgrishelyov1k@nba.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('26-8267852', 'hsamwell1l', 'obineham1l@whitehouse.gov', 'M');
insert into Customer (customer_id, username, email, gender) values ('24-0607711', 'rwayne1m', 'htranter1m@unesco.org', 'F');
insert into Customer (customer_id, username, email, gender) values ('13-2395234', 'deasson1n', 'rmcinnery1n@geocities.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('95-8568279', 'mffoulkes1o', 'nmacfaul1o@npr.org', 'F');
insert into Customer (customer_id, username, email, gender) values ('53-2204057', 'fdowty1p', 'lrevel1p@g.co', 'F');
insert into Customer (customer_id, username, email, gender) values ('21-6321416', 'rdunstone1q', 'tbarrie1q@360.cn', 'F');
insert into Customer (customer_id, username, email, gender) values ('77-3991850', 'sdelbergue1r', 'dbaume1r@cam.ac.uk', 'M');
insert into Customer (customer_id, username, email, gender) values ('90-8095166', 'npaulton1s', 'terb1s@businesswire.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('53-4851939', 'ebooley1t', 'mfeasley1t@feedburner.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('68-3838515', 'ifines1u', 'mkristof1u@wikia.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('14-1700974', 'slowthian1v', 'hosbiston1v@jimdo.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('53-7237505', 'frivallant1w', 'bgooderridge1w@technorati.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('08-9525179', 'retteridge1x', 'gkay1x@accuweather.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('78-6717931', 'yharley1y', 'pcoling1y@gov.uk', 'M');
insert into Customer (customer_id, username, email, gender) values ('88-5951160', 'msavoury1z', 'mmallinson1z@woothemes.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('75-6172198', 'wduding20', 'aconniam20@hostgator.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('90-7730084', 'fgiercke21', 'iferenczy21@wp.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('14-8766928', 'cscheu22', 'rmillhouse22@w3.org', 'F');
insert into Customer (customer_id, username, email, gender) values ('84-6496910', 'kdeaconson23', 'fcraigmyle23@intel.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('71-1277275', 'cfereday24', 'hjuan24@chicagotribune.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('43-5721156', 'rdyer25', 'broggeman25@auda.org.au', 'M');
insert into Customer (customer_id, username, email, gender) values ('89-5734664', 'mmcmeekan26', 'mdance26@google.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('83-9259521', 'droose27', 'choldren27@edublogs.org', 'M');
insert into Customer (customer_id, username, email, gender) values ('57-7942257', 'akitcher28', 'thurrell28@aboutads.info', 'M');
insert into Customer (customer_id, username, email, gender) values ('45-5924018', 'lbosenworth29', 'wovey29@google.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('24-0034167', 'akristof2a', 'lleathlay2a@rambler.ru', 'F');
insert into Customer (customer_id, username, email, gender) values ('68-8163812', 'rsimoneau2b', 'etrelevan2b@ameblo.jp', 'M');
insert into Customer (customer_id, username, email, gender) values ('43-9623970', 'davarne2c', 'hskitt2c@about.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('01-2484966', 'acapstack2d', 'gtalloe2d@vistaprint.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('31-7886360', 'rglassard2e', 'smcnabb2e@bravesites.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('52-3714234', 'hkobisch2f', 'sfaloon2f@dailymail.co.uk', 'M');
insert into Customer (customer_id, username, email, gender) values ('79-1177329', 'clembrick2g', 'telwill2g@privacy.gov.au', 'M');
insert into Customer (customer_id, username, email, gender) values ('86-5165238', 'pboc2h', 'gdoxey2h@zimbio.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('91-3942294', 'athouless2i', 'rbeathem2i@adobe.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('51-0817634', 'rrogers2j', 'dcameli2j@artisteer.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('63-6629439', 'hlingfoot2k', 'mmatussov2k@buzzfeed.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('68-2226231', 'bminshaw2l', 'bcheese2l@github.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('76-8723709', 'achessel2m', 'pcummine2m@bandcamp.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('53-9313921', 'gworden2n', 'kfrays2n@issuu.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('88-9789894', 'callom2o', 'dgirardetti2o@privacy.gov.au', 'F');
insert into Customer (customer_id, username, email, gender) values ('50-3324463', 'sdady2p', 'dkenwrick2p@vimeo.com', 'M');
insert into Customer (customer_id, username, email, gender) values ('19-2300696', 'aliggett2q', 'jgreenhalgh2q@cnbc.com', 'F');
insert into Customer (customer_id, username, email, gender) values ('72-4890612', 'mbondesen2r', 'rwynrehame2r@yandex.ru', 'F');

insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('59-214-8994', 'Broadleaf Enchanter''s Nightshade', 'XS', 16);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('00-949-0247', 'Parasol Sedge', 'M', 62);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('73-370-9640', 'Trans-pecos False Clapdaisy', '2XL', 87);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('35-234-5432', 'Gray''s Cinquefoil', 'S', 87);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('58-261-2438', 'Neobrackenridge''s Spleenwort', '2XL', 74);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('31-841-3937', 'Watermelon Nightshade', 'L', 67);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('57-969-0496', 'Blue Mountain Beardtongue', 'S', 34);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('82-846-5079', 'Congo Coffee', 'M', 26);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('28-325-4935', 'Pineland Milkweed', '2XL', 15);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('85-535-9738', 'Narrow-leaf Peppermint Gum', '3XL', 26);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('42-750-8412', 'Cumberland Xanthoparmelia Lichen', '2XL', 88);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('77-304-1586', 'Common Yarrow', '3XL', 74);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('78-415-6352', 'San Benito Thorn-mint', 'S', 56);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('36-521-9657', 'California Eryngo', 'XS', 23);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('39-172-2487', 'Blood Iris', 'L', 54);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('02-167-7897', 'Scalloped Moonwort', 'XL', 91);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('02-483-0996', 'Panamint Beardtongue', 'S', 46);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('61-572-5834', 'Blackjack Oak', 'XS', 97);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('42-869-7432', 'Goutystalk Nettlespurge', '2XL', 92);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('71-545-9414', 'Oval-leaf Clustervine', 'M', 70);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('33-369-7631', 'Mexican Clammyweed', 'S', 78);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('18-215-1828', 'Cultivated Fenugreek', '2XL', 97);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('62-106-2126', 'Texas Sacahuista', 'L', 72);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('64-853-8767', 'Pinnate False Threadleaf', '2XL', 51);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('26-028-0559', 'Limprichtia Moss', 'XL', 53);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('65-338-4736', 'Western Catchfly', '2XL', 57);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('97-238-3412', 'Diamond-flowers', '2XL', 50);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('13-169-9294', 'Rimmed Lichen', 'M', 18);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('72-187-5799', 'Petiolate Beardtongue', '2XL', 75);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('53-996-4396', 'Pioneer Violet', 'XS', 50);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('75-061-5218', 'Santa Cruz Island Manzanita', 'M', 49);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('47-961-2487', 'Red Sierra Onion', 'M', 80);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('29-193-8913', 'Smallhead Aster', 'XL', 62);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('05-799-9217', 'Hetch Hetchy Monkeyflower', 'XL', 53);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('12-181-1779', 'Sevenyear Apple', '3XL', 96);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('35-073-6987', 'Hybrid Oak', 'S', 66);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('75-204-7191', 'Averrhoa', 'M', 100);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('95-889-3255', 'Juniper Polytrichum Moss', 'S', 71);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('80-731-0478', 'Greater Galangal', 'M', 31);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('17-190-7543', 'Southern Threecornerjack', 'S', 90);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('64-321-8591', 'Wand Mullein', 'L', 99);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('03-342-2895', 'Fewflower Blazing Star', '2XL', 88);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('22-558-2852', 'Scaleflower Dodder', '3XL', 48);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('20-618-0236', 'Howell''s Lousewort', 'M', 69);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('77-044-9007', 'Lecidea Lichen', 'S', 81);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('03-179-8503', 'Smooth Pricklypoppy', '3XL', 100);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('57-860-1097', 'Hall''s Fissidens Moss', 'XL', 45);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('96-802-5646', 'Small Coastal Germander', 'S', 41);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('56-774-4363', 'Neckeropsis Moss', 'XL', 70);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('14-000-1415', 'Wright''s Sensitive Pea', '2XL', 63);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('04-241-1445', 'Satintail', '3XL', 80);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('96-526-1214', 'Selby''s Rockcress', 'XL', 74);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('95-730-3553', 'Island Lacefern', 'L', 79);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('22-441-0849', 'Texas Rush', 'XS', 22);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('17-257-7726', 'Chewing''s Fescue', 'L', 29);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('99-638-0286', 'Tripleleaf Morning-glory', '3XL', 19);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('93-783-0599', 'Broad Halberd Fern', 'M', 84);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('83-719-9033', 'Metcalf Canyon Jewelflower', '3XL', 95);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('60-283-3733', 'Woolly Brome', 'S', 91);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('04-610-6373', 'Hartweg''s Doll''s-lily', 'L', 30);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('04-722-6926', 'Prostrate Mountain Phlox', '2XL', 72);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('53-398-6703', 'Acaulon Moss', 'XS', 94);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('04-815-5318', 'Kane County Twinpod', 'M', 48);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('33-102-7182', 'Zigzag Brake', '3XL', 22);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('71-244-4602', 'Florida Whitetop', '2XL', 90);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('72-468-1341', 'Bluebowls', 'M', 51);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('81-949-9058', 'Seminole Balsamo', '2XL', 76);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('09-605-7378', 'Pinto Peanut', 'S', 73);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('22-304-0378', 'Hypotrachyna Lichen', 'L', 91);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('91-236-8380', 'Alpine Meadow-rue', 'XS', 87);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('81-001-7333', 'Woodland Islandmint', 'S', 95);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('09-801-4324', 'Wright''s False Threadleaf', 'XL', 86);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('45-597-5061', 'Dirinaria Lichen', 'L', 84);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('25-654-7498', 'Alcove Rockdaisy', '2XL', 35);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('07-159-5078', 'Quayle''s Ragwort', '3XL', 46);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('31-847-0331', 'Tortula Moss', 'XL', 23);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('40-668-9576', 'Neobrackenridge''s Spleenwort', 'M', 36);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('84-526-8551', 'Tarweed', '3XL', 31);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('04-029-7632', 'Winterfat', 'XL', 32);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('46-712-8361', 'Oregon Rockcress', 'XL', 23);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('01-694-1791', 'Trinity Buckwheat', 'S', 50);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('88-440-5705', 'Bush''s Blackberry', '3XL', 34);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('96-974-7459', 'Woolly Paperflower', 'XS', 64);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('87-593-2937', 'Arrowhead Vine', 'XS', 22);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('39-310-1892', 'Largeflower Skeletonplant', 'M', 78);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('86-826-7172', 'Heartleaf Bittercress', 'XL', 41);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('82-016-5138', 'Woody Goldenrod', 'XL', 54);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('88-186-7112', 'Bolander Beach Pine', '2XL', 73);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('82-661-1236', 'Northern-rockcress', 'M', 35);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('92-669-8019', 'Del Norte Pea', '3XL', 47);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('19-712-1602', 'Colombian Bonnet Orchid', 'M', 95);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('24-427-0536', 'White Mountain Larkspur', 'S', 30);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('62-530-5236', 'Awapa Fleabane', 'XL', 28);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('89-120-4657', 'Chaparral Bellflower', 'S', 57);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('13-070-8101', 'California Topelia Lichen', 'S', 36);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('38-504-1431', 'Chiricahua Mountain Dock', 'XL', 56);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('76-133-7841', 'Fringed Orchid', 'L', 34);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('88-371-9107', 'Wisconsin Rim Lichen', 'XL', 34);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('26-122-1038', 'Clubmoss', 'M', 23);
insert into Commodity (commodity_number, commodity_name, size, inventory_Jul) values ('77-983-2934', 'Ixora', '2XL', 22);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/

insert into OrderInfo (customer_id, username,commodity_number,commodity_name, size ) 
select * from 
	(select customer_id,username,commodity_number,commodity_name, size 
	   from Customer cross join Commodity order by random() limit 1000) as random1000;

/* 
select C.commodity_number, C.inventory_Jul, sales, (C.inventory_Jul-sales) as inventory_Aug
  from Commodity as C 
  left join (select commodity_number,count(*) as sales 
  from OrderInfo as O 
  group by O.commodity_number
  order by O.commodity_number)as SalesAug
  on C.commodity_number=SalesAug.commodity_number
  order by C.commodity_number;
*/
