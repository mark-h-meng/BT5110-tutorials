/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The code is written for PostgreSQL
BT5110 Capital Management Ltd ('BCML') is an investment advisory firm. It has specially chosen 100 publicly listed companies listed on various stock exchanges for its 100 VIP clients to buy. 
The stocks table contains the 100 stocks that it has specially chosen, including the company name, its stock exchange ticker and exhcnage on which it is traded.
The clients table contains the names of the 100 VIP clients, their client ID, contact number and email address. 
The holdings table shows the relationship between the stocks and clients table. In particular, it shows which VIP client has bought which stock.  
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DROP TABLE IF EXISTS holdings;
DROP TABLE IF EXISTS stocks;
DROP TABLE IF EXISTS clients;

CREATE TABLE stocks(
	company_name VARCHAR(128) NOT NULL,
	ticker VARCHAR(8) PRIMARY KEY,
	exchange VARCHAR(32) NOT NULL,
	industry VARCHAR(128) NOT NULL);
	
CREATE TABLE clients(
	client_name VARCHAR(64) NOT NULL,
	client_id CHARACTER(6) PRIMARY KEY,
	contact NUMERIC UNIQUE NOT NULL,
	email VARCHAR(64) UNIQUE NOT NULL);
	
CREATE TABLE holdings(
	client_id VARCHAR(8) REFERENCES clients(client_id),
	ticker CHAR(9) REFERENCES stocks(ticker));
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into stocks (company_name, ticker, exchange, industry) values ('Versartis, Inc.', 'VSAR', 'NASDAQ', 'Major Pharmaceuticals');
insert into stocks (company_name, ticker, exchange, industry) values ('LifePoint Health, Inc.', 'LPNT', 'NASDAQ', 'Hospital/Nursing Management');
insert into stocks (company_name, ticker, exchange, industry) values ('Sun Hydraulics Corporation', 'SNHY', 'NASDAQ', 'Metal Fabrications');
insert into stocks (company_name, ticker, exchange, industry) values ('Gladstone Commercial Corporation', 'GOODM', 'NASDAQ', 'Real Estate');
insert into stocks (company_name, ticker, exchange, industry) values ('Kaiser Aluminum Corporation', 'KALU', 'NASDAQ', 'Metal Fabrications');
insert into stocks (company_name, ticker, exchange, industry) values ('Chimera Investment Corporation', 'CIM^B', 'NYSE', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('DDR Corp.', 'DDR', 'NYSE', 'Real Estate Investment Trusts');
insert into stocks (company_name, ticker, exchange, industry) values ('Lexington Realty Trust', 'LXP', 'NYSE', 'Real Estate Investment Trusts');
insert into stocks (company_name, ticker, exchange, industry) values ('Assured Guaranty Ltd.', 'AGO^F', 'NYSE', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('Spok Holdings, Inc.', 'SPOK', 'NASDAQ', 'Telecommunications Equipment');
insert into stocks (company_name, ticker, exchange, industry) values ('Deutsche Bank AG', 'DB', 'NYSE', 'Major Banks');
insert into stocks (company_name, ticker, exchange, industry) values ('China New Borun Corporation', 'BORN', 'NYSE', 'Beverages (Production/Distribution)');
insert into stocks (company_name, ticker, exchange, industry) values ('ILG, Inc', 'ILG', 'NASDAQ', 'Real Estate');
insert into stocks (company_name, ticker, exchange, industry) values ('AG Mortgage Investment Trust, Inc.', 'MITT^A', 'NYSE', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('Elmira Savings Bank NY (The)', 'ESBK', 'NASDAQ', 'Major Banks');
insert into stocks (company_name, ticker, exchange, industry) values ('Cincinnati Financial Corporation', 'CINF', 'NASDAQ', 'Property-Casualty Insurers');
insert into stocks (company_name, ticker, exchange, industry) values ('General Electric Capital Corporation', 'GEK', 'NYSE', 'Consumer Electronics/Appliances');
insert into stocks (company_name, ticker, exchange, industry) values ('Anthem, Inc.', 'ANTM', 'NYSE', 'Medical Specialities');
insert into stocks (company_name, ticker, exchange, industry) values ('Minerva Neurosciences, Inc', 'NERV', 'NASDAQ', 'Major Pharmaceuticals');
insert into stocks (company_name, ticker, exchange, industry) values ('Saratoga Investment Corp', 'SAR', 'NYSE', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('Radcom Ltd.', 'RDCM', 'NASDAQ', 'Computer peripheral equipment');
insert into stocks (company_name, ticker, exchange, industry) values ('Bay Bancorp, Inc.', 'BYBK', 'NASDAQ', 'Major Banks');
insert into stocks (company_name, ticker, exchange, industry) values ('Albany International Corporation', 'AIN', 'NYSE', 'Textiles');
insert into stocks (company_name, ticker, exchange, industry) values ('Investors Bancorp, Inc.', 'ISBC', 'NASDAQ', 'Major Banks');
insert into stocks (company_name, ticker, exchange, industry) values ('EP Energy Corporation', 'EPE', 'NYSE', 'Oil & Gas Production');
insert into stocks (company_name, ticker, exchange, industry) values ('Adamis Pharmaceuticals Corporation', 'ADMP', 'NASDAQ', 'Major Pharmaceuticals');
insert into stocks (company_name, ticker, exchange, industry) values ('Deutsch Bk Contingent Cap Tr V', 'DKT', 'NYSE', 'Major Banks');
insert into stocks (company_name, ticker, exchange, industry) values ('Gladstone Commercial Corporation', 'GOODO', 'NASDAQ', 'Real Estate');
insert into stocks (company_name, ticker, exchange, industry) values ('Kimco Realty Corporation', 'KIM^J', 'NYSE', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('Shineco, Inc.', 'TYHT', 'NASDAQ', 'Farming/Seeds/Milling');
insert into stocks (company_name, ticker, exchange, industry) values ('Western Asset Managed Municipals Fund, Inc.', 'MMU', 'NYSE', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('Nortel Inversora SA', 'NTL', 'NYSE', 'Telecommunications Equipment');
insert into stocks (company_name, ticker, exchange, industry) values ('Enable Midstream Partners, LP', 'ENBL', 'NYSE', 'Natural Gas Distribution');
insert into stocks (company_name, ticker, exchange, industry) values ('Ingersoll-Rand plc (Ireland)', 'IR', 'NYSE', 'Auto Parts:O.E.M.');
insert into stocks (company_name, ticker, exchange, industry) values ('Eli Lilly and Company', 'LLY', 'NYSE', 'Major Pharmaceuticals');
insert into stocks (company_name, ticker, exchange, industry) values ('ZAGG Inc', 'ZAGG', 'NASDAQ', 'Other Specialty Stores');
insert into stocks (company_name, ticker, exchange, industry) values ('Diversicare Healthcare Services Inc.', 'DVCR', 'NASDAQ', 'Hospital/Nursing Management');
insert into stocks (company_name, ticker, exchange, industry) values ('BB&T Corporation', 'BBT^H', 'NYSE', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('International Game Technology', 'IGT', 'NYSE', 'Services-Misc. Amusement & Recreation');
insert into stocks (company_name, ticker, exchange, industry) values ('VASCO Data Security International, Inc.', 'VDSI', 'NASDAQ', 'EDP Services');
insert into stocks (company_name, ticker, exchange, industry) values ('BSQUARE Corporation', 'BSQR', 'NASDAQ', 'Business Services');
insert into stocks (company_name, ticker, exchange, industry) values ('Popular, Inc.', 'BPOPN', 'NASDAQ', 'Major Banks');
insert into stocks (company_name, ticker, exchange, industry) values ('Nevro Corp.', 'NVRO', 'NYSE', 'Medical/Dental Instruments');
insert into stocks (company_name, ticker, exchange, industry) values ('CapStar Financial Holdings, Inc.', 'CSTR', 'NASDAQ', 'Major Banks');
insert into stocks (company_name, ticker, exchange, industry) values ('FMC Corporation', 'FMC', 'NYSE', 'Major Chemicals');
insert into stocks (company_name, ticker, exchange, industry) values ('Webster Financial Corporation', 'WBS', 'NYSE', 'Major Banks');
insert into stocks (company_name, ticker, exchange, industry) values ('Brinker International, Inc.', 'EAT', 'NYSE', 'Restaurants');
insert into stocks (company_name, ticker, exchange, industry) values ('Blue Bird Corporation', 'BLBD', 'NASDAQ', 'Construction/Ag Equipment/Trucks');
insert into stocks (company_name, ticker, exchange, industry) values ('Vivint Solar, Inc.', 'VSLR', 'NYSE', 'Building Products');
insert into stocks (company_name, ticker, exchange, industry) values ('Chemical Financial Corporation', 'CHFC', 'NASDAQ', 'Major Banks');
insert into stocks (company_name, ticker, exchange, industry) values ('Lloyds Banking Group Plc', 'LYG', 'NYSE', 'Commercial Banks');
insert into stocks (company_name, ticker, exchange, industry) values ('First Trust Large Cap Growth AlphaDEX Fund', 'FTC', 'NASDAQ', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('CVS Health Corporation', 'CVS', 'NYSE', 'Medical/Nursing Services');
insert into stocks (company_name, ticker, exchange, industry) values ('Nuveen NASDAQ 100 Dynamic Overwrite Fund', 'QQQX', 'NASDAQ', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('Pyxis Tankers Inc.', 'PXS', 'NASDAQ', 'Marine Transportation');
insert into stocks (company_name, ticker, exchange, industry) values ('Wright Medical Group N.V.', 'WMGIZ', 'NASDAQ', 'Industrial Specialties');
insert into stocks (company_name, ticker, exchange, industry) values ('Stag Industrial, Inc.', 'STAG^C', 'NYSE', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('KKR & Co. L.P.', 'KKR', 'NYSE', 'Investment Managers');
insert into stocks (company_name, ticker, exchange, industry) values ('Autohome Inc.', 'ATHM', 'NYSE', 'EDP Services');
insert into stocks (company_name, ticker, exchange, industry) values ('Acacia Research Corporation', 'ACTG', 'NASDAQ', 'Multi-Sector Companies');
insert into stocks (company_name, ticker, exchange, industry) values ('Connecture, Inc.', 'CNXR', 'NASDAQ', 'Computer Software: Prepackaged Software');
insert into stocks (company_name, ticker, exchange, industry) values ('Nord Anglia Education, Inc.', 'NORD', 'NYSE', 'Other Consumer Services');
insert into stocks (company_name, ticker, exchange, industry) values ('Sony Corp Ord', 'SNE', 'NYSE', 'Consumer Electronics/Appliances');
insert into stocks (company_name, ticker, exchange, industry) values ('Liberty Media Corporation', 'BATRK', 'NASDAQ', 'Broadcasting');
insert into stocks (company_name, ticker, exchange, industry) values ('On Assignment, Inc.', 'ASGN', 'NYSE', 'Professional Services');
insert into stocks (company_name, ticker, exchange, industry) values ('Blue Hills Bancorp, Inc.', 'BHBK', 'NASDAQ', 'Major Banks');
insert into stocks (company_name, ticker, exchange, industry) values ('Black Box Corporation', 'BBOX', 'NASDAQ', 'Computer Communications Equipment');
insert into stocks (company_name, ticker, exchange, industry) values ('Axar Acquisition Corp.', 'AXARU', 'NASDAQ', 'Business Services');
insert into stocks (company_name, ticker, exchange, industry) values ('Baker Hughes Incorporated', 'BHI', 'NYSE', 'Metal Fabrications');
insert into stocks (company_name, ticker, exchange, industry) values ('Calgon Carbon Corporation', 'CCC', 'NYSE', 'Major Chemicals');
insert into stocks (company_name, ticker, exchange, industry) values ('Pimco Corporate & Income Stategy Fund', 'PCN', 'NYSE', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('Tuesday Morning Corp.', 'TUES', 'NASDAQ', 'Department/Specialty Retail Stores');
insert into stocks (company_name, ticker, exchange, industry) values ('Global X SuperDividend REIT ETF', 'SRET', 'NASDAQ', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('Sportsman''s Warehouse Holdings, Inc.', 'SPWH', 'NASDAQ', 'Other Specialty Stores');
insert into stocks (company_name, ticker, exchange, industry) values ('Vishay Precision Group, Inc.', 'VPG', 'NYSE', 'Electrical Products');
insert into stocks (company_name, ticker, exchange, industry) values ('Global Partner Acquisition Corp.', 'GPACU', 'NASDAQ', 'Hospital/Nursing Management');
insert into stocks (company_name, ticker, exchange, industry) values ('Toro Company (The)', 'TTC', 'NYSE', 'Tools/Hardware');
insert into stocks (company_name, ticker, exchange, industry) values ('St. Joe Company (The)', 'JOE', 'NYSE', 'Homebuilding');
insert into stocks (company_name, ticker, exchange, industry) values ('Walgreens Boots Alliance, Inc.', 'WBA', 'NASDAQ', 'Medical/Nursing Services');
insert into stocks (company_name, ticker, exchange, industry) values ('Telecom Argentina Stet - France Telecom S.A.', 'TEO', 'NYSE', 'Telecommunications Equipment');
insert into stocks (company_name, ticker, exchange, industry) values ('Recon Technology, Ltd.', 'RCON', 'NASDAQ', 'Oilfield Services/Equipment');
insert into stocks (company_name, ticker, exchange, industry) values ('First Trust Mid Cap Growth AlphaDEX Fund', 'FNY', 'NASDAQ', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('Gabelli Dividend', 'GDV^A', 'NYSE', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('First Trust Brazil AlphaDEX Fund', 'FBZ', 'NASDAQ', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('Capital One Financial Corporation', 'COF^F', 'NYSE', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('Commercial Metals Company', 'CMC', 'NYSE', 'Steel/Iron Ore');
insert into stocks (company_name, ticker, exchange, industry) values ('Sandy Spring Bancorp, Inc.', 'SASR', 'NASDAQ', 'Major Banks');
insert into stocks (company_name, ticker, exchange, industry) values ('Firsthand Technology Value Fund, Inc.', 'SVVC', 'NASDAQ', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('AMC Entertainment Holdings, Inc.', 'AMC', 'NYSE', 'Movies/Entertainment');
insert into stocks (company_name, ticker, exchange, industry) values ('MAM Software Group, Inc.', 'MAMS', 'NASDAQ', 'Computer Software: Prepackaged Software');
insert into stocks (company_name, ticker, exchange, industry) values ('First Cash, Inc.', 'FCFS', 'NYSE', 'Other Specialty Stores');
insert into stocks (company_name, ticker, exchange, industry) values ('Tallgrass Energy Partners, LP', 'TEP', 'NYSE', 'Natural Gas Distribution');
insert into stocks (company_name, ticker, exchange, industry) values ('Western Digital Corporation', 'WDC', 'NASDAQ', 'Electronic Components');
insert into stocks (company_name, ticker, exchange, industry) values ('Orchid Island Capital, Inc.', 'ORC', 'NYSE', 'Real Estate Investment Trusts');
insert into stocks (company_name, ticker, exchange, industry) values ('Consolidated Water Co. Ltd.', 'CWCO', 'NASDAQ', 'Water Supply');
insert into stocks (company_name, ticker, exchange, industry) values ('Intevac, Inc.', 'IVAC', 'NASDAQ', 'Industrial Machinery/Components');
insert into stocks (company_name, ticker, exchange, industry) values ('Morgan Stanley Emerging Markets Fund, Inc.', 'MSF', 'NYSE', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('TCW Strategic Income Fund, Inc.', 'TSI', 'NYSE', 'n/a');
insert into stocks (company_name, ticker, exchange, industry) values ('NACCO Industries, Inc.', 'NC', 'NYSE', 'Consumer Electronics/Appliances');
insert into stocks (company_name, ticker, exchange, industry) values ('QEP Resources, Inc.', 'QEP', 'NYSE', 'Oil & Gas Production');

insert into clients (client_name, client_id, contact, email) values ('Belicia Comberbeach', 551783, 88815904, 'bcomberbeach0@alibaba.com');
insert into clients (client_name, client_id, contact, email) values ('Yoshiko Leeder', 717778, 80113486, 'yleeder1@goo.ne.jp');
insert into clients (client_name, client_id, contact, email) values ('Clarette Bysshe', 108174, 88540013, 'cbysshe2@shutterfly.com');
insert into clients (client_name, client_id, contact, email) values ('Gunilla Trebble', 683882, 80664446, 'gtrebble3@arstechnica.com');
insert into clients (client_name, client_id, contact, email) values ('Anallise McQuilty', 269261, 96148541, 'amcquilty4@archive.org');
insert into clients (client_name, client_id, contact, email) values ('Terrence Canadas', 609048, 99592967, 'tcanadas5@amazon.co.jp');
insert into clients (client_name, client_id, contact, email) values ('Kalil Kitchingman', 571193, 84945032, 'kkitchingman6@dedecms.com');
insert into clients (client_name, client_id, contact, email) values ('Noel Smithen', 393111, 95583266, 'nsmithen7@miibeian.gov.cn');
insert into clients (client_name, client_id, contact, email) values ('Douglas Tyzack', 515077, 89854592, 'dtyzack8@vinaora.com');
insert into clients (client_name, client_id, contact, email) values ('Steffen Ithell', 385572, 87048126, 'sithell9@pinterest.com');
insert into clients (client_name, client_id, contact, email) values ('Melli Camacho', 739170, 82560781, 'mcamachoa@phoca.cz');
insert into clients (client_name, client_id, contact, email) values ('Neddie Knellen', 495984, 84971348, 'nknellenb@pagesperso-orange.fr');
insert into clients (client_name, client_id, contact, email) values ('Antonia Folca', 951949, 86521855, 'afolcac@ow.ly');
insert into clients (client_name, client_id, contact, email) values ('Claudius Anlay', 703493, 89018415, 'canlayd@wikia.com');
insert into clients (client_name, client_id, contact, email) values ('Chandal Pate', 201910, 92358501, 'cpatee@ezinearticles.com');
insert into clients (client_name, client_id, contact, email) values ('Clyve Brizell', 221322, 90940403, 'cbrizellf@latimes.com');
insert into clients (client_name, client_id, contact, email) values ('William Trippitt', 154303, 80782874, 'wtrippittg@miibeian.gov.cn');
insert into clients (client_name, client_id, contact, email) values ('Tiffany McKimm', 586732, 88703908, 'tmckimmh@symantec.com');
insert into clients (client_name, client_id, contact, email) values ('Morly Aleavy', 265875, 87656918, 'maleavyi@google.it');
insert into clients (client_name, client_id, contact, email) values ('Morse Castiglioni', 613595, 84797011, 'mcastiglionij@mediafire.com');
insert into clients (client_name, client_id, contact, email) values ('Sloan Mortel', 434005, 96530238, 'smortelk@reverbnation.com');
insert into clients (client_name, client_id, contact, email) values ('Cello Shambroke', 650524, 84410761, 'cshambrokel@chicagotribune.com');
insert into clients (client_name, client_id, contact, email) values ('Brig Lassey', 208326, 92940539, 'blasseym@people.com.cn');
insert into clients (client_name, client_id, contact, email) values ('Bernadine Spennock', 311824, 81417754, 'bspennockn@surveymonkey.com');
insert into clients (client_name, client_id, contact, email) values ('Philly Bernade', 183048, 81259739, 'pbernadeo@intel.com');
insert into clients (client_name, client_id, contact, email) values ('Cristine Foottit', 645871, 86563612, 'cfoottitp@examiner.com');
insert into clients (client_name, client_id, contact, email) values ('Emmi Wildbore', 614171, 84653852, 'ewildboreq@nih.gov');
insert into clients (client_name, client_id, contact, email) values ('Anna Dobrowolny', 383928, 94916324, 'adobrowolnyr@abc.net.au');
insert into clients (client_name, client_id, contact, email) values ('Joshua Rosthorn', 624934, 89268640, 'jrosthorns@spiegel.de');
insert into clients (client_name, client_id, contact, email) values ('Whitney Widdop', 903686, 95855831, 'wwiddopt@skype.com');
insert into clients (client_name, client_id, contact, email) values ('Francis Edsell', 344018, 90411550, 'fedsellu@list-manage.com');
insert into clients (client_name, client_id, contact, email) values ('Thom Chafney', 585915, 92969764, 'tchafneyv@paypal.com');
insert into clients (client_name, client_id, contact, email) values ('Elle Gubbin', 439748, 88506011, 'egubbinw@blogs.com');
insert into clients (client_name, client_id, contact, email) values ('Arabella Berthel', 980415, 80589743, 'aberthelx@typepad.com');
insert into clients (client_name, client_id, contact, email) values ('Estele Cartmell', 637185, 93547704, 'ecartmelly@blinklist.com');
insert into clients (client_name, client_id, contact, email) values ('Scarlett Garraway', 933724, 94033686, 'sgarrawayz@npr.org');
insert into clients (client_name, client_id, contact, email) values ('Ginni McKechnie', 683835, 93276130, 'gmckechnie10@youtu.be');
insert into clients (client_name, client_id, contact, email) values ('Bayard Scullion', 942787, 81082125, 'bscullion11@newyorker.com');
insert into clients (client_name, client_id, contact, email) values ('Samuele Craggs', 530623, 84507705, 'scraggs12@cbslocal.com');
insert into clients (client_name, client_id, contact, email) values ('Concordia Junkinson', 437677, 94328311, 'cjunkinson13@psu.edu');
insert into clients (client_name, client_id, contact, email) values ('Fulton Bilbey', 495948, 84886991, 'fbilbey14@123-reg.co.uk');
insert into clients (client_name, client_id, contact, email) values ('Benedick Stoeck', 677389, 86443985, 'bstoeck15@cafepress.com');
insert into clients (client_name, client_id, contact, email) values ('Pat Baysting', 541039, 88269294, 'pbaysting16@ehow.com');
insert into clients (client_name, client_id, contact, email) values ('Munroe Cheine', 715405, 90356736, 'mcheine17@printfriendly.com');
insert into clients (client_name, client_id, contact, email) values ('Byron Caulkett', 952410, 82222506, 'bcaulkett18@buzzfeed.com');
insert into clients (client_name, client_id, contact, email) values ('Briggs Stille', 104839, 83084283, 'bstille19@wordpress.org');
insert into clients (client_name, client_id, contact, email) values ('Alwyn Chate', 472593, 85200860, 'achate1a@accuweather.com');
insert into clients (client_name, client_id, contact, email) values ('Renado Eldin', 945044, 87039797, 'reldin1b@unicef.org');
insert into clients (client_name, client_id, contact, email) values ('Tatum Birwhistle', 995638, 98317275, 'tbirwhistle1c@msu.edu');
insert into clients (client_name, client_id, contact, email) values ('Welsh Suatt', 996622, 83405459, 'wsuatt1d@state.gov');
insert into clients (client_name, client_id, contact, email) values ('Lorna Ledingham', 133483, 90491780, 'lledingham1e@soup.io');
insert into clients (client_name, client_id, contact, email) values ('Joel Haslam', 669542, 88969514, 'jhaslam1f@naver.com');
insert into clients (client_name, client_id, contact, email) values ('Bordy Maylin', 120669, 84930513, 'bmaylin1g@wufoo.com');
insert into clients (client_name, client_id, contact, email) values ('Alano Attrey', 332023, 83404272, 'aattrey1h@ed.gov');
insert into clients (client_name, client_id, contact, email) values ('Sherwynd Ogilvy', 232545, 95363885, 'sogilvy1i@bbc.co.uk');
insert into clients (client_name, client_id, contact, email) values ('Alic Rittmeier', 755406, 83864856, 'arittmeier1j@ftc.gov');
insert into clients (client_name, client_id, contact, email) values ('Bellina Stigell', 163791, 93318139, 'bstigell1k@is.gd');
insert into clients (client_name, client_id, contact, email) values ('Ailene Dedon', 350515, 81285614, 'adedon1l@mashable.com');
insert into clients (client_name, client_id, contact, email) values ('Roland Honsch', 469559, 96013836, 'rhonsch1m@tmall.com');
insert into clients (client_name, client_id, contact, email) values ('Ewell Clayton', 403010, 91569401, 'eclayton1n@aol.com');
insert into clients (client_name, client_id, contact, email) values ('Morganne Baldree', 144837, 88670148, 'mbaldree1o@abc.net.au');
insert into clients (client_name, client_id, contact, email) values ('Kellyann Wayman', 156675, 96104666, 'kwayman1p@virginia.edu');
insert into clients (client_name, client_id, contact, email) values ('Louisa Nutter', 429369, 89293427, 'lnutter1q@squarespace.com');
insert into clients (client_name, client_id, contact, email) values ('Anita Andreas', 221951, 86878110, 'aandreas1r@mlb.com');
insert into clients (client_name, client_id, contact, email) values ('Angelica Marchello', 428153, 80447024, 'amarchello1s@jugem.jp');
insert into clients (client_name, client_id, contact, email) values ('Monah Inman', 118425, 91255282, 'minman1t@cbslocal.com');
insert into clients (client_name, client_id, contact, email) values ('Corina Ilive', 860181, 90906157, 'cilive1u@howstuffworks.com');
insert into clients (client_name, client_id, contact, email) values ('Averyl Martignon', 886992, 90794976, 'amartignon1v@desdev.cn');
insert into clients (client_name, client_id, contact, email) values ('Winnie Kinzett', 452744, 93285887, 'wkinzett1w@businesswire.com');
insert into clients (client_name, client_id, contact, email) values ('Chicky Abrahami', 478383, 95845307, 'cabrahami1x@mit.edu');
insert into clients (client_name, client_id, contact, email) values ('Kevan Greatham', 789609, 91946752, 'kgreatham1y@slashdot.org');
insert into clients (client_name, client_id, contact, email) values ('Valry Werrilow', 897493, 98345654, 'vwerrilow1z@blogtalkradio.com');
insert into clients (client_name, client_id, contact, email) values ('Giacopo Chue', 229730, 90661881, 'gchue20@cocolog-nifty.com');
insert into clients (client_name, client_id, contact, email) values ('Clare MacCaull', 905085, 86454512, 'cmaccaull21@ask.com');
insert into clients (client_name, client_id, contact, email) values ('Ario Dows', 445316, 97092985, 'adows22@usnews.com');
insert into clients (client_name, client_id, contact, email) values ('Alric Najera', 927635, 98271382, 'anajera23@ovh.net');
insert into clients (client_name, client_id, contact, email) values ('Briano Ace', 857690, 98951561, 'bace24@ca.gov');
insert into clients (client_name, client_id, contact, email) values ('Sigfried Manshaw', 809182, 80224765, 'smanshaw25@wikispaces.com');
insert into clients (client_name, client_id, contact, email) values ('Yolane Abrahmovici', 787228, 83823265, 'yabrahmovici26@prweb.com');
insert into clients (client_name, client_id, contact, email) values ('Ebba Pippard', 536791, 91744998, 'epippard27@wufoo.com');
insert into clients (client_name, client_id, contact, email) values ('Harley Overal', 321224, 80374918, 'hoveral28@bbc.co.uk');
insert into clients (client_name, client_id, contact, email) values ('Simone Ort', 835466, 93265166, 'sort29@soup.io');
insert into clients (client_name, client_id, contact, email) values ('Giffie Beeho', 161141, 80895518, 'gbeeho2a@webnode.com');
insert into clients (client_name, client_id, contact, email) values ('Jeni Watchorn', 336302, 94648268, 'jwatchorn2b@twitpic.com');
insert into clients (client_name, client_id, contact, email) values ('Morrie Valois', 429013, 81947742, 'mvalois2c@amazon.co.uk');
insert into clients (client_name, client_id, contact, email) values ('Nicolette Angelo', 887012, 97496737, 'nangelo2d@ovh.net');
insert into clients (client_name, client_id, contact, email) values ('Loise Ambrogini', 204396, 85549959, 'lambrogini2e@hao123.com');
insert into clients (client_name, client_id, contact, email) values ('Irvine Dalgliesh', 659294, 98794693, 'idalgliesh2f@slashdot.org');
insert into clients (client_name, client_id, contact, email) values ('Gino Raymen', 949723, 90839411, 'graymen2g@cocolog-nifty.com');
insert into clients (client_name, client_id, contact, email) values ('Lorain Aistrop', 353632, 94480651, 'laistrop2h@nsw.gov.au');
insert into clients (client_name, client_id, contact, email) values ('Katha Hadgkiss', 769853, 80740501, 'khadgkiss2i@is.gd');
insert into clients (client_name, client_id, contact, email) values ('Bessie Cherry Holme', 266949, 90867933, 'bcherry2j@360.cn');
insert into clients (client_name, client_id, contact, email) values ('Brinna McGilvary', 776066, 94256157, 'bmcgilvary2k@rediff.com');
insert into clients (client_name, client_id, contact, email) values ('Isidore Newbold', 863803, 91219552, 'inewbold2l@twitter.com');
insert into clients (client_name, client_id, contact, email) values ('Allyson Sail', 523103, 84675066, 'asail2m@boston.com');
insert into clients (client_name, client_id, contact, email) values ('Berkly Jedrzejczyk', 371911, 86257673, 'bjedrzejczyk2n@g.co');
insert into clients (client_name, client_id, contact, email) values ('Blinni Leslie', 354499, 89369130, 'bleslie2o@last.fm');
insert into clients (client_name, client_id, contact, email) values ('Sara Echalier', 355747, 80382796, 'sechalier2p@eepurl.com');
insert into clients (client_name, client_id, contact, email) values ('Monroe Ewence', 904666, 89854676, 'mewence2q@who.int');
insert into clients (client_name, client_id, contact, email) values ('Tybi Stainsby', 834637, 85690329, 'tstainsby2r@uol.com.br');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO holdings (client_id, ticker)
SELECT c.client_id, s.ticker
FROM clients c, stocks s
ORDER BY RANDOM()
LIMIT 1000;