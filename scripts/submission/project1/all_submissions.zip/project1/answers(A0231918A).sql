/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL. */
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The database contains three tables: People, Creditcard and Own.
People and Creditcard are two entity sets, while Own is the relationship set.
People contains three basic attributes of every person (first name, last name, email), with email being the primary key.
Creditcard also contains three attributes of a credit card (card number, card type, currency type), with card number being the primary key.
Own associates the emails of people to the credit card numbers that they have.

The code is written for PostgreSQL.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE people (
	first_name VARCHAR(50),
	last_name VARCHAR(50),
	email VARCHAR(50) PRIMARY KEY
);
	
CREATE TABLE creditcard (
	credit_card_no VARCHAR(50) PRIMARY KEY,
	credit_card_type VARCHAR(50),
	currency VARCHAR(50)
);
	
CREATE TABLE own(
	email VARCHAR(50) REFERENCES people(email),
	credit_card_no VARCHAR(50) REFERENCES creditcard(credit_card_no)
);
	
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into creditcard (credit_card_no, credit_card_type, currency) values ('5336519348932487', 'mastercard', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('201471471336735', 'diners-club-enroute', 'Peso');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('675903410492897218', 'switch', 'Zloty');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5434006658488673', 'mastercard', 'Euro');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5100137459207526', 'mastercard', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5602225289592648', 'bankcard', 'Rial');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3532258246358332', 'jcb', 'Dollar');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3563697654425806', 'jcb', 'Real');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5524793355754140', 'mastercard', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3585410144185038', 'jcb', 'Shilling');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5602229189323393219', 'china-unionpay', 'Peso');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3564773585417334', 'jcb', 'Peso');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3533966340410150', 'jcb', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('30115656577921', 'diners-club-carte-blanche', 'Baht');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('676269255707380039', 'maestro', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3537373156056290', 'jcb', 'Shilling');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3563072933485809', 'jcb', 'Zloty');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3583863670432483', 'jcb', 'Shilling');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('4903630157456348', 'switch', 'Euro');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('4026725601835220', 'visa-electron', 'Quetzal');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('30091364142508', 'diners-club-carte-blanche', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('36288085085735', 'diners-club-international', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('374283480478130', 'americanexpress', 'Euro');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('6763501506238209487', 'maestro', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3538683954085500', 'jcb', 'Dollar');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('4913425483100068', 'visa-electron', 'Euro');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('337941608122502', 'americanexpress', 'Ruble');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3567112448579484', 'jcb', 'Krone');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3574898662149316', 'jcb', 'Euro');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5108750015704653', 'mastercard', 'Peso');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('201517672466174', 'diners-club-enroute', 'Sol');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3549730981927605', 'jcb', 'Ruble');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3535355512299666', 'jcb', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5602212571910736364', 'china-unionpay', 'Baht');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('675969062576705139', 'switch', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5406859635880857', 'mastercard', 'Ruble');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3550374308532297', 'jcb', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('4917575879541501', 'visa-electron', 'Euro');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('67628084192576911', 'maestro', 'Boliviano');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('36165183295293', 'diners-club-international', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5602241797964187', 'bankcard', 'Pula');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('63045830046431032', 'maestro', 'Dinar');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('374283035869643', 'americanexpress', 'Hryvnia');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3573346233678919', 'jcb', 'Sol');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3562762294536098', 'jcb', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('6374409005774805', 'instapayment', 'Real');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('4026534045004033', 'visa-electron', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5289955322665973', 'mastercard', 'Litas');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3586317074430582', 'jcb', 'Baht');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('4041595119488296', 'visa', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3542930739267935', 'jcb', 'Lek');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('374288690361851', 'americanexpress', 'Sol');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3548520691558050', 'jcb', 'Peso');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3576916552522166', 'jcb', 'Peso');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('676181071049959991', 'maestro', 'Euro');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('30579083732807', 'diners-club-carte-blanche', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5002354958559542', 'mastercard', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5602238562951456', 'china-unionpay', 'Euro');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5564554136088989', 'diners-club-us-ca', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3563688003311482', 'jcb', 'Kip');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3570722522181331', 'jcb', 'Peso');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('4041591583596', 'visa', 'Franc');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('4026713955177746', 'visa-electron', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3531898246932759', 'jcb', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3539999532740658', 'jcb', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3560326079347428', 'jcb', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5496740777204711', 'mastercard', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('56022203636197465', 'china-unionpay', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('493677116594037148', 'switch', 'Dollar');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3529143632009183', 'jcb', 'Hryvnia');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5602251009250036', 'bankcard', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('633349148195575274', 'switch', 'Krona');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5452266333769056', 'diners-club-us-ca', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('374622084769891', 'americanexpress', 'Dong');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('67621804064363214', 'maestro', 'Ruble');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('67614040273123565', 'maestro', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('4026729947562456', 'visa-electron', 'Peso');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3532578021639758', 'jcb', 'Peso');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('4609390427903747', 'visa', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3541115812275325', 'jcb', 'Krona');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5398096953655609', 'mastercard', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5210178189442014', 'mastercard', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3566314620253372', 'jcb', 'Ruble');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5048372416837447', 'mastercard', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3528342818914379', 'jcb', 'Real');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3530857262561307', 'jcb', 'Real');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3583149453446845', 'jcb', 'Euro');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('561057792938070849', 'china-unionpay', 'Euro');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3566594163688742', 'jcb', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3544408290828369', 'jcb', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('6381925520950811', 'instapayment', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('67098742815647655', 'laser', 'Zloty');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('4936351178105092', 'switch', 'Yuan Renminbi');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('4041591742872196', 'visa', 'Ariary');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('201713073913142', 'diners-club-enroute', 'Lev');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3580298823644952', 'jcb', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('3572855303420243', 'jcb', 'Rial');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5462145484591915', 'mastercard', 'Pula');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('374288700059446', 'americanexpress', 'Rupiah');
insert into creditcard (credit_card_no, credit_card_type, currency) values ('5893762209416791927', 'maestro', 'Litas');


insert into people (first_name, last_name, email) values ('Fran', 'Ebanks', 'febanks0@ezinearticles.com');
insert into people (first_name, last_name, email) values ('Sigismond', 'Dickins', 'sdickins1@slate.com');
insert into people (first_name, last_name, email) values ('Rance', 'Zoephel', 'rzoephel2@vinaora.com');
insert into people (first_name, last_name, email) values ('Rhiamon', 'Gayler', 'rgayler3@icio.us');
insert into people (first_name, last_name, email) values ('Cullan', 'Karslake', 'ckarslake4@thetimes.co.uk');
insert into people (first_name, last_name, email) values ('Kerri', 'Rens', 'krens5@examiner.com');
insert into people (first_name, last_name, email) values ('Ragnar', 'Scherme', 'rscherme6@hibu.com');
insert into people (first_name, last_name, email) values ('Franklin', 'Bonsey', 'fbonsey7@wordpress.org');
insert into people (first_name, last_name, email) values ('Jory', 'Polendine', 'jpolendine8@ox.ac.uk');
insert into people (first_name, last_name, email) values ('Cecilia', 'Adamec', 'cadamec9@ca.gov');
insert into people (first_name, last_name, email) values ('Ulrike', 'McCutcheon', 'umccutcheona@umich.edu');
insert into people (first_name, last_name, email) values ('Vanda', 'Fleming', 'vflemingb@senate.gov');
insert into people (first_name, last_name, email) values ('Phylis', 'Rennebeck', 'prennebeckc@irs.gov');
insert into people (first_name, last_name, email) values ('Carmina', 'Dowe', 'cdowed@ehow.com');
insert into people (first_name, last_name, email) values ('Denni', 'Grundle', 'dgrundlee@wikimedia.org');
insert into people (first_name, last_name, email) values ('Gui', 'MacFadzan', 'gmacfadzanf@ucla.edu');
insert into people (first_name, last_name, email) values ('Nicolle', 'Tregien', 'ntregieng@upenn.edu');
insert into people (first_name, last_name, email) values ('Alfie', 'Kubanek', 'akubanekh@apache.org');
insert into people (first_name, last_name, email) values ('Meyer', 'Redsall', 'mredsalli@gmpg.org');
insert into people (first_name, last_name, email) values ('Randi', 'Mocher', 'rmocherj@deviantart.com');
insert into people (first_name, last_name, email) values ('Lamont', 'Proger', 'lprogerk@discuz.net');
insert into people (first_name, last_name, email) values ('Deedee', 'Youens', 'dyouensl@tripod.com');
insert into people (first_name, last_name, email) values ('Gerrie', 'Milland', 'gmillandm@discovery.com');
insert into people (first_name, last_name, email) values ('Rafaellle', 'Garlant', 'rgarlantn@wordpress.com');
insert into people (first_name, last_name, email) values ('Dalton', 'Jervoise', 'djervoiseo@google.co.uk');
insert into people (first_name, last_name, email) values ('Denys', 'Andrivot', 'dandrivotp@hp.com');
insert into people (first_name, last_name, email) values ('Euell', 'Lunck', 'elunckq@ucsd.edu');
insert into people (first_name, last_name, email) values ('Nesta', 'Fagence', 'nfagencer@cam.ac.uk');
insert into people (first_name, last_name, email) values ('Porter', 'Lottrington', 'plottringtons@mayoclinic.com');
insert into people (first_name, last_name, email) values ('Jsandye', 'Gratten', 'jgrattent@t.co');
insert into people (first_name, last_name, email) values ('Norma', 'Forsdyke', 'nforsdykeu@census.gov');
insert into people (first_name, last_name, email) values ('Don', 'Grinnov', 'dgrinnovv@reference.com');
insert into people (first_name, last_name, email) values ('Cleavland', 'Greatbach', 'cgreatbachw@smugmug.com');
insert into people (first_name, last_name, email) values ('Andras', 'Gallelli', 'agallellix@google.es');
insert into people (first_name, last_name, email) values ('Nathalie', 'Bahde', 'nbahdey@disqus.com');
insert into people (first_name, last_name, email) values ('Modesty', 'Ussher', 'mussherz@patch.com');
insert into people (first_name, last_name, email) values ('Ursola', 'Ginnaly', 'uginnaly10@drupal.org');
insert into people (first_name, last_name, email) values ('Ibbie', 'Goudge', 'igoudge11@vinaora.com');
insert into people (first_name, last_name, email) values ('Brand', 'Lennie', 'blennie12@edublogs.org');
insert into people (first_name, last_name, email) values ('Jess', 'Dowtry', 'jdowtry13@123-reg.co.uk');
insert into people (first_name, last_name, email) values ('Alfred', 'Hemstead', 'ahemstead14@gmpg.org');
insert into people (first_name, last_name, email) values ('Hurley', 'Pavyer', 'hpavyer15@ucla.edu');
insert into people (first_name, last_name, email) values ('Franni', 'Conrard', 'fconrard16@github.io');
insert into people (first_name, last_name, email) values ('Merilyn', 'Murdoch', 'mmurdoch17@paginegialle.it');
insert into people (first_name, last_name, email) values ('Laughton', 'Kolushev', 'lkolushev18@yelp.com');
insert into people (first_name, last_name, email) values ('Agustin', 'Finan', 'afinan19@mtv.com');
insert into people (first_name, last_name, email) values ('Ariel', 'Vedeneev', 'avedeneev1a@is.gd');
insert into people (first_name, last_name, email) values ('Rikki', 'Pettyfar', 'rpettyfar1b@twitter.com');
insert into people (first_name, last_name, email) values ('Fairleigh', 'Chestnutt', 'fchestnutt1c@columbia.edu');
insert into people (first_name, last_name, email) values ('Lyndel', 'Fick', 'lfick1d@google.com');
insert into people (first_name, last_name, email) values ('Elvira', 'Banbrook', 'ebanbrook1e@go.com');
insert into people (first_name, last_name, email) values ('Prudi', 'Chainey', 'pchainey1f@friendfeed.com');
insert into people (first_name, last_name, email) values ('Sargent', 'Cahani', 'scahani1g@rakuten.co.jp');
insert into people (first_name, last_name, email) values ('Felita', 'Waldren', 'fwaldren1h@wordpress.org');
insert into people (first_name, last_name, email) values ('Fleurette', 'Crame', 'fcrame1i@dailymotion.com');
insert into people (first_name, last_name, email) values ('Cacilie', 'Bridge', 'cbridge1j@flavors.me');
insert into people (first_name, last_name, email) values ('Ike', 'Gerrit', 'igerrit1k@dion.ne.jp');
insert into people (first_name, last_name, email) values ('Tootsie', 'Boulton', 'tboulton1l@myspace.com');
insert into people (first_name, last_name, email) values ('Kearney', 'Warret', 'kwarret1m@cargocollective.com');
insert into people (first_name, last_name, email) values ('Chevy', 'Rizzardini', 'crizzardini1n@yellowpages.com');
insert into people (first_name, last_name, email) values ('Sandy', 'Carroll', 'scarroll1o@blog.com');
insert into people (first_name, last_name, email) values ('Hurleigh', 'Jeavon', 'hjeavon1p@weibo.com');
insert into people (first_name, last_name, email) values ('Shirlene', 'Walak', 'swalak1q@gizmodo.com');
insert into people (first_name, last_name, email) values ('Maximilianus', 'Christofol', 'mchristofol1r@alexa.com');
insert into people (first_name, last_name, email) values ('Caryl', 'Antonio', 'cantonio1s@wikimedia.org');
insert into people (first_name, last_name, email) values ('Mallissa', 'Rowntree', 'mrowntree1t@dailymail.co.uk');
insert into people (first_name, last_name, email) values ('Guido', 'Caines', 'gcaines1u@skyrock.com');
insert into people (first_name, last_name, email) values ('Lenka', 'Waylen', 'lwaylen1v@scientificamerican.com');
insert into people (first_name, last_name, email) values ('Perry', 'Dallaway', 'pdallaway1w@netvibes.com');
insert into people (first_name, last_name, email) values ('Harriot', 'Greenlies', 'hgreenlies1x@spiegel.de');
insert into people (first_name, last_name, email) values ('Allyson', 'Pakeman', 'apakeman1y@furl.net');
insert into people (first_name, last_name, email) values ('Benita', 'Arnold', 'barnold1z@mediafire.com');
insert into people (first_name, last_name, email) values ('Georgianna', 'Pritchett', 'gpritchett20@so-net.ne.jp');
insert into people (first_name, last_name, email) values ('Shandra', 'Balfe', 'sbalfe21@webnode.com');
insert into people (first_name, last_name, email) values ('Friedrich', 'Bownes', 'fbownes22@slashdot.org');
insert into people (first_name, last_name, email) values ('Jamesy', 'Joyson', 'jjoyson23@ask.com');
insert into people (first_name, last_name, email) values ('Helga', 'Owthwaite', 'howthwaite24@odnoklassniki.ru');
insert into people (first_name, last_name, email) values ('Waverley', 'Shirt', 'wshirt25@nature.com');
insert into people (first_name, last_name, email) values ('Tova', 'Proback', 'tproback26@senate.gov');
insert into people (first_name, last_name, email) values ('Ashli', 'Niece', 'aniece27@xinhuanet.com');
insert into people (first_name, last_name, email) values ('Deny', 'Blewitt', 'dblewitt28@canalblog.com');
insert into people (first_name, last_name, email) values ('Anya', 'Rochell', 'arochell29@163.com');
insert into people (first_name, last_name, email) values ('Hortensia', 'Pree', 'hpree2a@nydailynews.com');
insert into people (first_name, last_name, email) values ('Elicia', 'Keir', 'ekeir2b@bbc.co.uk');
insert into people (first_name, last_name, email) values ('Derk', 'Burtenshaw', 'dburtenshaw2c@diigo.com');
insert into people (first_name, last_name, email) values ('Fay', 'Bendik', 'fbendik2d@51.la');
insert into people (first_name, last_name, email) values ('Karine', 'Klein', 'kklein2e@sogou.com');
insert into people (first_name, last_name, email) values ('Tuesday', 'Youde', 'tyoude2f@alexa.com');
insert into people (first_name, last_name, email) values ('Rurik', 'Morewood', 'rmorewood2g@japanpost.jp');
insert into people (first_name, last_name, email) values ('Lane', 'Aizikovitch', 'laizikovitch2h@arizona.edu');
insert into people (first_name, last_name, email) values ('Hagen', 'Rockey', 'hrockey2i@sphinn.com');
insert into people (first_name, last_name, email) values ('Brigitta', 'Cancott', 'bcancott2j@archive.org');
insert into people (first_name, last_name, email) values ('Jessie', 'Hammerich', 'jhammerich2k@delicious.com');
insert into people (first_name, last_name, email) values ('Ofilia', 'MacFaul', 'omacfaul2l@ca.gov');
insert into people (first_name, last_name, email) values ('Meridith', 'Deplacido', 'mdeplacido2m@google.it');
insert into people (first_name, last_name, email) values ('Nonah', 'Seabrook', 'nseabrook2n@shinystat.com');
insert into people (first_name, last_name, email) values ('Rozanne', 'Tooher', 'rtooher2o@icio.us');
insert into people (first_name, last_name, email) values ('Kristoforo', 'Pleace', 'kpleace2p@com.com');
insert into people (first_name, last_name, email) values ('Roxine', 'Whiteoak', 'rwhiteoak2q@ox.ac.uk');
insert into people (first_name, last_name, email) values ('Claudio', 'Debow', 'cdebow2r@pcworld.com');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO own (email, credit_card_no)
SELECT email, credit_card_no FROM people, creditcard
ORDER BY random()
LIMIT 1000;