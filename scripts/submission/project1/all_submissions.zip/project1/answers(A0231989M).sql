/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*

It's 2030, and Singapore needs help as there appears to be more hackers identifying 
security flaws in companies in Singapore. These hackers in Singapore are no white hat hackers
as they typically find these flaws in order to steal bitcoin from the company. At this point, 
Singapore is entirely run on bitcoin, so the hackers are stealing and sending bitcoin to an address. 
We need to create a database for the Singapore government to help them organize the data effectively
to catch and punish the malicious hackers.

The entity set E1 will be 'hacker' which represents a table of bitcoin hackers in Singapore. This table
includes their personal information like first name, last name, email, bitcoin address,
and social security number. In this case, the social security number (SSN) of the hacker is the primary key
as it uniquely identifies each hacker.

Entity set E2 will be 'company' which is a table of companies in Singapore that have been hacked.
The attributes of this entity includes the company name and company ip address v4.
The ip address v4 is the primary key as each ip address for each company must be unique.

The relationship R will be named 'hacked' as the hackers stole bitcoin from companies. This
relationship will have SSN and domain name as the composite primary keys. This relationship
is a many-to-many relationship as a hacker could have hacked multiple companies, and a company
could be hacked by multiple hackers. There is one attribute for this relationship which
is the amount of money (BTC) stolen by the hacker.

I will be using PostgreSQL for my code. 

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS hacker (
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	email VARCHAR(64) NOT NULL UNIQUE,
	bitcoin_address VARCHAR(34) NOT NULL UNIQUE,
	ssn VARCHAR(11) PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS company (
	c_name VARCHAR(64) NOT NULL,
	ip_address VARCHAR(20) PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS hacked (
	ssn VARCHAR(11) REFERENCES hacker(ssn),
	ip_address VARCHAR(20) REFERENCES company(ip_address),
	btc DECIMAL (6,2) NOT NULL CHECK (btc > 0.0),
	PRIMARY KEY (ip_address,ssn)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Miller', 'Summerfield', 'msummerfield0@blogs.com', '12THidsTaJMC2Ghym5ysQWr3hfzvxdhPLZ', '487-80-2336');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Sandie', 'Chitham', 'schitham1@blinklist.com', '1NSnXsz2CTpuS8hA2EXAbRHhXFn8r3tfYi', '378-63-6010');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Sibeal', 'Bartoszinski', 'sbartoszinski2@blogtalkradio.com', '1DsthWt5XPoVmmx6NgWhxdxH4WcfxXieAs', '749-63-7616');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Lonee', 'Petigrew', 'lpetigrew3@shareasale.com', '1AgKhXBEGeMRxCKXWXgpMErv9eP4zaCcaK', '654-73-4322');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Roderich', 'Fiske', 'rfiske4@scientificamerican.com', '1Hq1rmjdwTUWjoNxn2aSjgSjC63urt9xV5', '555-09-2757');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Heida', 'Larmor', 'hlarmor5@sogou.com', '1FmBdtM9hjE9xxoopy6JZpwM454hrDn32s', '452-01-3261');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Lucienne', 'Gouge', 'lgouge6@nyu.edu', '1BYcqVKaSaUXg9D4tAWak592L713sQ1WfD', '257-49-1984');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Gage', 'McCorry', 'gmccorry7@illinois.edu', '1MhKapoAhovM1icMzwA8ryoqSfc6j8rNiV', '380-29-9839');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Mead', 'Coward', 'mcoward8@hhs.gov', '1MHWWhbwGzsxqUeQoVconYDKG9Ldacj5Sr', '135-79-5605');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Huey', 'Linfoot', 'hlinfoot9@theglobeandmail.com', '1BVjf9moGRoHcNTGsHPVn95TAtmqJWNVom', '120-18-1481');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Margarethe', 'Ninotti', 'mninottia@booking.com', '1FitdFyvXqytPsGTTdRmbv4ckHRG3XHjy', '136-80-4827');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Johny', 'Westpfel', 'jwestpfelb@nsw.gov.au', '1MLBK6Pd4U5zHhyjN7bZsHCx9Y5w2xsU29', '616-94-7181');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Nanci', 'Girardey', 'ngirardeyc@lycos.com', '1Kwn1HmXbNDyXD6BwAStvydVyj8xNAzmUY', '374-39-4820');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Kaitlin', 'Mackney', 'kmackneyd@t-online.de', '17eXaYDxo79QkDKpPmpaUopAPPFdebJmTM', '751-42-0045');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Rafe', 'Brito', 'rbritoe@walmart.com', '16pMeb1TQfrZgpUdCo3bF4BXCm6Fqr7PZA', '890-09-3255');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Alvie', 'Keelan', 'akeelanf@pbs.org', '1598B6hAwXhpxr76PnZJFvNpn6drDQFHgq', '516-04-1114');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Deborah', 'Lintin', 'dlinting@cam.ac.uk', '1MbghNMKebCQJKqoY3SWHeJCJinK8M5YvJ', '588-71-7136');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Lyle', 'Ostler', 'lostlerh@is.gd', '1KCPAmHBg4YvsXyd9QoxX2tcoB8pByQfp4', '343-75-3584');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Standford', 'Schoenleiter', 'sschoenleiteri@biglobe.ne.jp', '14mwWCYtvRTWP4iBb5ADTMZzzZ6j1ztVM4', '669-59-2903');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Beverly', 'Lodin', 'blodinj@prweb.com', '1wJkKMCsTEM5nrQKRA9NiZLg4Q1jmyUDp', '209-24-6511');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Malchy', 'Impson', 'mimpsonk@wisc.edu', '1Mch7kKyqYNVVPZ4mf81fS8Fi2DFJ5Gi6X', '810-17-5235');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Karalee', 'Mohan', 'kmohanl@utexas.edu', '1GNf1uMHTVqaPzvSjGN8uok9igU5tAHLed', '713-89-4981');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Jens', 'Merrgen', 'jmerrgenm@ovh.net', '126hxR5MBf5qT482QmLdzvbVTG4XXu3bcx', '885-26-8910');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Currey', 'Trasler', 'ctraslern@ucla.edu', '16sdT86rf2pAS2wzSVYEbGr9UwgMvTapTg', '262-85-0720');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Marianna', 'Fobidge', 'mfobidgeo@fotki.com', '16acr3EkyMPUawT3QJ5A4CnFG38MWzJcc2', '325-89-5236');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Ravid', 'Comberbach', 'rcomberbachp@nhs.uk', '1H3KcUo8S85B8pgQHXyFKbFhzYyacjEdvB', '325-29-2244');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Pennie', 'Etchell', 'petchellq@mediafire.com', '1HD9CS2JWqujP5HpMMi5CRDa2ybdGX92kx', '468-59-7777');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Dolores', 'Sunock', 'dsunockr@independent.co.uk', '1DQc7m2pbEAYonLmeqzeGiEKdkSS5SWirL', '510-97-8412');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Cathe', 'Banford', 'cbanfords@mediafire.com', '1G1rNbk4kp5YcbEm94BenppKQydRhgjdpJ', '272-68-9259');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Hortensia', 'Creelman', 'hcreelmant@technorati.com', '1D6ryqTQH5D4DcoGxy3b2nQdU6RqzWs5NU', '186-32-9391');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Trixy', 'Swindley', 'tswindleyu@mozilla.org', '136KQEpCsAxefhwFYWCSsn2mkMncL2qHbL', '228-21-0194');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Susi', 'Dicken', 'sdickenv@cnn.com', '1JJYtxcmHHAGaJqt54XWYDAV3EWYSjdVoS', '307-72-0106');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Brooks', 'Lapre', 'blaprew@sogou.com', '18k2WqiSZXqSqXWjNmVukUFb1crzZBwGN', '186-26-4013');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Iolanthe', 'McCoveney', 'imccoveneyx@biblegateway.com', '17tLShgBQ3S4jrVfA6uWXempfMkcoCCiy4', '354-49-4157');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Kerrie', 'Ipplett', 'kippletty@nytimes.com', '115t8b5tcWeSeHqxEc2Pkqia81g494g9rH', '370-91-1606');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Ellis', 'Lafoy', 'elafoyz@comsenz.com', '16s7ER3yGpZaY6b9d7CGF4in8y9UA3YFqp', '359-30-6453');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Matt', 'Aleksandrikin', 'maleksandrikin10@about.com', '1HWurHz4MBr5RU5EaEyW6AoBF9NyKgfCSm', '309-46-6303');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Gaylord', 'Puddephatt', 'gpuddephatt11@youtu.be', '1ruU2mS8yNcGh2h1L8NvtDUGBamjjEgpJ', '790-34-6673');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Genevra', 'Dobrovsky', 'gdobrovsky12@amazon.co.jp', '18PrNRRPjCJiGytTDLzwsUt9hzF28UbXWf', '853-68-9660');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Florie', 'Breazeall', 'fbreazeall13@devhub.com', '1EWhfWH2DuuTHnHpVt5HMAkeYv2SeTKkYx', '858-17-9684');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Link', 'Van der Brugge', 'lvanderbrugge14@mapquest.com', '172o8cHjGJvPvqpu8hWVifwxj7h69E9Uo2', '727-07-4157');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Rollie', 'Paternoster', 'rpaternoster15@plala.or.jp', '1EG2Nfo7uc4mD5YV1ffQFT7FG33AyE7KLe', '870-27-8872');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Guglielmo', 'MacConneely', 'gmacconneely16@smugmug.com', '1PLzMMKAQ8L6iZd5aXsPBNCGSeontnErfV', '370-77-8412');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Curr', 'Philpotts', 'cphilpotts17@usa.gov', '1K5sf6ajTPGYF22MhFqiL25ZqD3NNRKfv6', '795-07-9476');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Davidde', 'Hruska', 'dhruska18@psu.edu', '16M8PCjqxfKbcZrPvQWUesSvr6kZhj6yCf', '352-83-7022');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Antonius', 'Dutnell', 'adutnell19@gmpg.org', '1NYLdtPt3STcniwT8aG8erq1bHoJtjsvSH', '443-11-4248');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Wendall', 'Goulder', 'wgoulder1a@cbslocal.com', '14KwD8zpTbTv94WsUSJnoEw55VhAd5jPvs', '261-51-0061');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Trula', 'Dabney', 'tdabney1b@photobucket.com', '19V9X67x2xGLXHCZurBYoC8URKqUZHMu6f', '432-04-3371');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Avis', 'Wiz', 'awiz1c@sogou.com', '1HvvqgrdBmCUD7emejWNUp53azGKioTUNC', '419-24-5961');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Katee', 'Stainer', 'kstainer1d@trellian.com', '1DADaCjSWgxCbUTToCgq2KqKP4k4THSh2', '454-28-4110');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Neil', 'Briscam', 'nbriscam1e@unc.edu', '1EdQ2oqafVZA3YGVy2zEda9XE7JD7ox3xx', '249-75-3386');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Sid', 'Macellar', 'smacellar1f@netvibes.com', '1NcE9z55LxTuGVxF3PRYgcWuQrerZ5MisD', '136-87-9214');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Gustie', 'Gillebride', 'ggillebride1g@pagesperso-orange.fr', '17utZtxxFR5FkXCEUL4FJJRKVQegt87MUB', '821-21-9710');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Arty', 'Spinks', 'aspinks1h@sina.com.cn', '18SJMa3H8gP2t5s82jAra9UZtWXF2J4VZN', '778-17-9775');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Isabel', 'Rekes', 'irekes1i@pinterest.com', '15XSnoHcsHzijszY2vHAhniVSf5SEKCnio', '108-79-6101');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Veriee', 'Gerrard', 'vgerrard1j@shinystat.com', '1Bs5gjnLNH6y41GMyuBM1xQ8o1e1CH7JjJ', '463-34-9508');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Tedi', 'Duffill', 'tduffill1k@mlb.com', '1EvYa6kRAeZ8nvKgU8p4V9qEMBwJuuBFJm', '414-76-5232');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Jaquenetta', 'Casado', 'jcasado1l@japanpost.jp', '1F2cRJF3ANqHLHpTiHwhsya6G7wUwfK6Cd', '483-45-5677');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Prentice', 'Tuhy', 'ptuhy1m@youtube.com', '1nXgoYJciVxjhG48ZMPYSdRUELVp2dxyz', '425-28-6730');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Coop', 'Axleby', 'caxleby1n@networksolutions.com', '1Btc8iHBCyZw227yfcWqxFWCLZoLdYLD8j', '656-79-3458');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Wilbur', 'Birrell', 'wbirrell1o@addthis.com', '1Jwqq7AEEYspJdjV1DGVuYjrvdUJKzykHd', '217-01-7862');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Monique', 'Davall', 'mdavall1p@businessinsider.com', '1CqbMpiFabxkrcfb28fc7zwKobn33BieLF', '168-14-9964');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Coreen', 'Piggens', 'cpiggens1q@tinypic.com', '1JmNRyxMUuPaMZEV14ymqewtC3FyVGGKsh', '510-27-4738');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Karole', 'Vynoll', 'kvynoll1r@cam.ac.uk', '1EPXGGSnsJej4SiLc2yqB8vkMqy2EM3c1y', '378-02-1174');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Claiborn', 'Langelay', 'clangelay1s@ca.gov', '1CSS8NDnc5nQ1pKUGmXXnd6mAuSdi6GoxK', '375-27-2840');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Seamus', 'Button', 'sbutton1t@blogspot.com', '1CrKTJKMPKBcSUkTW2KfQZ9ezm2T615rQ', '587-39-1956');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Penelopa', 'Heazel', 'pheazel1u@mtv.com', '1Kzavbe9uVfERdacKMftiWnNULJ4Cy5JjY', '123-81-5146');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Berky', 'Dudley', 'bdudley1v@theglobeandmail.com', '1CTfP2Xnoa2Aw2NavDZsvEV57DyJXnQdDg', '347-07-7517');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Alvy', 'Raeburn', 'araeburn1w@psu.edu', '17E8FbPCPcNVT4fT1f8LPnCN7KiSH1HrdZ', '580-93-9125');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Inglebert', 'Longbottom', 'ilongbottom1x@wikipedia.org', '1KA3cZBoKhBcA3ihRFMMFVF6vDpz7Qayor', '118-68-6625');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Mariejeanne', 'O''Lochan', 'molochan1y@blog.com', '1r4u3m3ok8RdnBiZ56zRZ1TYmDuaBJNKm', '663-67-9128');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Jyoti', 'Carlozzi', 'jcarlozzi1z@taobao.com', '1MhRgTrDsgE3VEY78PMjryqsz5ndUAbnVQ', '779-21-4431');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Glen', 'Jansie', 'gjansie20@macromedia.com', '16QxwMbivEj7oUPm1rzF9TrtzftTZMuR6C', '462-41-0047');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Othilie', 'Marcoolyn', 'omarcoolyn21@cmu.edu', '1CJaifEwbEquYeEUqeryt7yNcp591MNVkz', '470-07-4467');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Genny', 'Pendlebery', 'gpendlebery22@1688.com', '1296ttjRh989uSNCg5hvv2AsMAKYWCkvm8', '649-22-3633');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Olly', 'Barthelmes', 'obarthelmes23@oaic.gov.au', '1NPeQ5h5pra6QTpBufKFUKLmPsK5o2VwBs', '101-85-5456');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Brod', 'Ingleson', 'bingleson24@furl.net', '1JhFAeSnbDd95Z1hdJnbgt5MYyn74MyipC', '513-70-8811');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Leonelle', 'Schulze', 'lschulze25@canalblog.com', '15GEG65JJbkrvKsoXugqikUsqz1KwJJpdT', '802-45-0942');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Dane', 'Gartell', 'dgartell26@yahoo.com', '1mkBCAfP1Wkv6wd9J1xKAPBH5rpyJ89sK', '106-99-5687');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Ranna', 'Beller', 'rbeller27@dell.com', '1JKndkPS34iukqMjVioiths29yRsDoAkDk', '294-48-7968');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Mignon', 'Braney', 'mbraney28@meetup.com', '1NLXLPHDi4FDjmoaFnFhaYHMNPUmXnMQm8', '457-14-4279');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Lenci', 'Rowledge', 'lrowledge29@oracle.com', '1E9yTdJ99rrWgUdosaHnUwkSYZwcZepn89', '852-36-9708');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Leona', 'Jarry', 'ljarry2a@umich.edu', '1P7HEkVur2rrdb3Mix8z4LL7uw2i6TiZ6F', '427-87-2507');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Othilie', 'Franzotto', 'ofranzotto2b@simplemachines.org', '1EKJ5jYvdzMzb16aDCL8Y1GLAhL2e3cPJd', '471-04-8143');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Albrecht', 'Alesin', 'aalesin2c@fema.gov', '1FSMY4dcQHy6cVjjsPW4xb2stR1F91bdf1', '552-61-1422');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Carissa', 'Packe', 'cpacke2d@tripadvisor.com', '1NR1j6BF1eyJpiBPJjk5FRKGN7NonbqUGM', '642-36-2714');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Tyler', 'Ronald', 'tronald2e@google.ru', '175WDU8LFvT5BcX37s5E1DSUpgwu4ueCN4', '487-97-7585');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Candis', 'Ricardou', 'cricardou2f@mail.ru', '1QCZgY9VekKBLw4sAiDWWqPw9J8btLD7kV', '478-23-8971');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Morgan', 'Saggers', 'msaggers2g@biglobe.ne.jp', '16WYzeAq1KqKJ92QroQqBP5xBZGmnnNXDc', '151-39-7131');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Saba', 'Guiness', 'sguiness2h@spotify.com', '1JSEDU92Bc4FWz77HkGCWifQ5zvHpK672R', '700-64-9084');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Drona', 'Blackbourn', 'dblackbourn2i@instagram.com', '1APTdetLuNzeaCinYq4P4p9t3TdpwGLYZk', '418-28-3261');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Gerda', 'Andrelli', 'gandrelli2j@cbsnews.com', '12f4ULJFsvxRBUjbaxoPCM4jfW53JmJNwj', '199-67-1247');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Yetta', 'Bartaloni', 'ybartaloni2k@nytimes.com', '19hLgttEMQdq2vEM1XUfE1jGryK9rqbkZr', '541-84-7754');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Amie', 'Fensome', 'afensome2l@ning.com', '1Ln2APfLYujxwZRYzdPaWojfvumjkTrJAb', '492-05-9207');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Raynard', 'Cauley', 'rcauley2m@ning.com', '121t6SCfpSvtXWgS5bJmdWqhz2DNGNJk54', '787-72-4923');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Winnie', 'Timby', 'wtimby2n@bbc.co.uk', '1DigYY9mLB7M3fxzZ6nPWXAAcPfGoRn1dz', '539-08-8681');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Clovis', 'Kinzett', 'ckinzett2o@nyu.edu', '1Nc5i87otjB4JLPcb5TxB2iwCCQm2yTB6S', '305-45-0969');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Geralda', 'Moreing', 'gmoreing2p@yelp.com', '1FUBDmNAyvu6fGkM8pgvwJv3Pq5jSU7afe', '793-64-1651');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Phip', 'Cargill', 'pcargill2q@dailymail.co.uk', '1DUQqUucEkbc8wvivvXconYxPuAnHpWTtr', '681-17-2559');
insert into hacker (first_name, last_name, email, bitcoin_address, ssn) values ('Corine', 'Stenning', 'cstenning2r@etsy.com', '1PcrvFrEHBb7BSaA6Qr94bcMVssEe9WT2q', '517-90-8751');

insert into company (c_name, ip_address) values ('Edgepulse', '246.46.83.135');
insert into company (c_name, ip_address) values ('Rhybox', '76.48.42.148');
insert into company (c_name, ip_address) values ('Mudo', '15.141.209.239');
insert into company (c_name, ip_address) values ('Kare', '137.153.135.171');
insert into company (c_name, ip_address) values ('Eimbee', '215.119.48.239');
insert into company (c_name, ip_address) values ('Chatterpoint', '93.98.92.236');
insert into company (c_name, ip_address) values ('Zazio', '72.82.215.82');
insert into company (c_name, ip_address) values ('Oba', '128.114.205.130');
insert into company (c_name, ip_address) values ('Livetube', '228.213.67.97');
insert into company (c_name, ip_address) values ('Tanoodle', '155.169.104.193');
insert into company (c_name, ip_address) values ('Oyonder', '154.96.80.117');
insert into company (c_name, ip_address) values ('Photofeed', '85.136.102.63');
insert into company (c_name, ip_address) values ('Brainverse', '224.225.136.121');
insert into company (c_name, ip_address) values ('Browseblab', '23.151.136.219');
insert into company (c_name, ip_address) values ('Mycat', '160.146.43.21');
insert into company (c_name, ip_address) values ('Demivee', '122.153.133.101');
insert into company (c_name, ip_address) values ('Dynabox', '136.120.127.212');
insert into company (c_name, ip_address) values ('Skinder', '149.244.45.131');
insert into company (c_name, ip_address) values ('Brainverse', '190.128.240.66');
insert into company (c_name, ip_address) values ('Avamba', '81.11.153.253');
insert into company (c_name, ip_address) values ('Buzzster', '234.65.44.77');
insert into company (c_name, ip_address) values ('Trupe', '8.235.166.105');
insert into company (c_name, ip_address) values ('Mycat', '196.190.89.60');
insert into company (c_name, ip_address) values ('Yakidoo', '150.166.25.28');
insert into company (c_name, ip_address) values ('Topiclounge', '142.249.194.213');
insert into company (c_name, ip_address) values ('Eire', '254.202.236.83');
insert into company (c_name, ip_address) values ('Topicware', '161.235.252.37');
insert into company (c_name, ip_address) values ('Innotype', '221.80.99.11');
insert into company (c_name, ip_address) values ('Tazz', '84.68.136.37');
insert into company (c_name, ip_address) values ('Lazz', '49.4.11.166');
insert into company (c_name, ip_address) values ('Realmix', '14.173.212.105');
insert into company (c_name, ip_address) values ('Skibox', '185.206.222.115');
insert into company (c_name, ip_address) values ('Centimia', '62.218.39.119');
insert into company (c_name, ip_address) values ('Thoughtsphere', '136.192.155.107');
insert into company (c_name, ip_address) values ('Riffpath', '55.63.169.215');
insert into company (c_name, ip_address) values ('Voonix', '150.214.23.222');
insert into company (c_name, ip_address) values ('Gevee', '206.99.3.169');
insert into company (c_name, ip_address) values ('Eire', '179.250.105.162');
insert into company (c_name, ip_address) values ('Kazu', '78.34.47.184');
insert into company (c_name, ip_address) values ('Brightbean', '220.225.168.156');
insert into company (c_name, ip_address) values ('Zoombox', '100.227.7.58');
insert into company (c_name, ip_address) values ('Yambee', '140.111.234.17');
insert into company (c_name, ip_address) values ('Gigabox', '30.236.247.147');
insert into company (c_name, ip_address) values ('Yotz', '21.38.31.40');
insert into company (c_name, ip_address) values ('Meeveo', '1.34.205.107');
insert into company (c_name, ip_address) values ('Mynte', '56.69.138.215');
insert into company (c_name, ip_address) values ('Shufflebeat', '67.197.155.166');
insert into company (c_name, ip_address) values ('Dynabox', '59.140.21.198');
insert into company (c_name, ip_address) values ('Myworks', '150.136.149.236');
insert into company (c_name, ip_address) values ('Skinder', '109.168.82.155');
insert into company (c_name, ip_address) values ('Yadel', '84.197.38.123');
insert into company (c_name, ip_address) values ('Thoughtbeat', '247.202.175.98');
insert into company (c_name, ip_address) values ('Leexo', '249.190.76.231');
insert into company (c_name, ip_address) values ('Skivee', '156.110.171.88');
insert into company (c_name, ip_address) values ('Youspan', '167.15.18.207');
insert into company (c_name, ip_address) values ('Skiba', '193.181.58.112');
insert into company (c_name, ip_address) values ('Yakidoo', '25.242.181.127');
insert into company (c_name, ip_address) values ('Tagopia', '93.154.118.77');
insert into company (c_name, ip_address) values ('Fliptune', '144.2.161.56');
insert into company (c_name, ip_address) values ('Trilith', '243.64.203.220');
insert into company (c_name, ip_address) values ('Roombo', '113.7.133.27');
insert into company (c_name, ip_address) values ('Riffpedia', '106.153.223.144');
insert into company (c_name, ip_address) values ('Feedspan', '62.103.165.203');
insert into company (c_name, ip_address) values ('Eire', '185.0.113.122');
insert into company (c_name, ip_address) values ('Dynava', '236.191.161.228');
insert into company (c_name, ip_address) values ('Yombu', '14.156.49.237');
insert into company (c_name, ip_address) values ('Brightdog', '195.77.98.75');
insert into company (c_name, ip_address) values ('Skalith', '184.8.75.138');
insert into company (c_name, ip_address) values ('Twimm', '227.161.120.248');
insert into company (c_name, ip_address) values ('Jaxworks', '161.179.93.42');
insert into company (c_name, ip_address) values ('Quimba', '112.95.198.163');
insert into company (c_name, ip_address) values ('Zoombox', '53.204.40.225');
insert into company (c_name, ip_address) values ('Oloo', '35.105.243.204');
insert into company (c_name, ip_address) values ('Fanoodle', '198.36.30.36');
insert into company (c_name, ip_address) values ('Devbug', '23.208.62.155');
insert into company (c_name, ip_address) values ('Eire', '109.0.81.158');
insert into company (c_name, ip_address) values ('Browsebug', '221.177.197.69');
insert into company (c_name, ip_address) values ('Zoomdog', '184.206.79.30');
insert into company (c_name, ip_address) values ('Devshare', '4.230.60.104');
insert into company (c_name, ip_address) values ('Mynte', '4.117.13.223');
insert into company (c_name, ip_address) values ('Fadeo', '211.136.205.202');
insert into company (c_name, ip_address) values ('Shufflester', '83.251.142.219');
insert into company (c_name, ip_address) values ('Tazz', '18.111.106.253');
insert into company (c_name, ip_address) values ('Twinte', '99.175.181.60');
insert into company (c_name, ip_address) values ('BlogXS', '57.161.65.44');
insert into company (c_name, ip_address) values ('Snaptags', '215.5.74.62');
insert into company (c_name, ip_address) values ('Yadel', '80.163.220.98');
insert into company (c_name, ip_address) values ('Tazzy', '181.32.36.66');
insert into company (c_name, ip_address) values ('Oloo', '234.88.188.99');
insert into company (c_name, ip_address) values ('Skinder', '177.232.94.134');
insert into company (c_name, ip_address) values ('Twitterbridge', '233.65.146.225');
insert into company (c_name, ip_address) values ('Browsedrive', '181.158.92.212');
insert into company (c_name, ip_address) values ('Wikibox', '14.123.72.68');
insert into company (c_name, ip_address) values ('Topiczoom', '164.111.58.162');
insert into company (c_name, ip_address) values ('Brainbox', '90.246.6.7');
insert into company (c_name, ip_address) values ('Kwinu', '209.24.254.186');
insert into company (c_name, ip_address) values ('DabZ', '34.168.0.164');
insert into company (c_name, ip_address) values ('Yacero', '116.36.13.1');
insert into company (c_name, ip_address) values ('Babbleblab', '191.158.134.14');
insert into company (c_name, ip_address) values ('Reallinks', '84.43.149.54');
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO hacked(ip_address,ssn,btc)
(SELECT ip_address, ssn, random()*(1000-1)+1
FROM company, hacker
ORDER BY random()
LIMIT 1000);
