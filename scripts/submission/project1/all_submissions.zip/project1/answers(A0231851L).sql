/************************************************************************/
/*               													    */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The first table is called Membership, used to record information of members of a club store such as Sam's Club. 
	It includes ID, name, phone, email, address, gender, dob, and reward points in total.

The second table is called Items, containing details of items in the store,
	including No, name, expiration date, price and reward points.

The third table is called Buy, giving information that someone bought something.
	This kind of table may be useful at the cashier.

Written for Postgre SQL 13


*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table membership (
	membership_id VARCHAR(50) PRIMARY KEY,
	first_name VARCHAR(50) NOT NULL,
	last_name VARCHAR(50) NOT NULL,
	gender VARCHAR(10),
	dob DATE NOT NULL,
	email VARCHAR(50),
	phone VARCHAR(50) NOT NULL,
	address VARCHAR(50),
	reward_points FLOAT DEFAULT 0 CHECK(Reward_Points>=0)
);

create table Items (
	Item_No VARCHAR(50) PRIMARY KEY,
	Item_Name VARCHAR(50) NOT NULL,
	Expiration_Date DATE NOT NULL,
	Price FLOAT NOT NULL CHECK(Price>0),
	Reward_Points FLOAT
);

create table Buy(
	someone VARCHAR(50) REFERENCES Membership(Membership_ID),
	something VARCHAR(50) REFERENCES Items(Item_No)
);
                                                  
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('021-769-041', 'Morrie', 'Gouch', 'Female', '1967-09-23', 'mgouch0@marriott.com', '(231) 6847130', '2747 Harbort Circle');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('669-899-343', 'Lorens', 'Novakovic', 'Female', '1970-11-26', 'lnovakovic1@blinklist.com', '(439) 7692121', '804 Beilfuss Parkway');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('514-131-834', 'Paulita', 'Brunsdon', 'Female', '1995-04-10', 'pbrunsdon2@weibo.com', '(247) 5638702', '33778 Susan Center');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('954-419-585', 'Ansley', 'Talby', 'Male', '1999-09-20', 'atalby3@chicagotribune.com', '(137) 6310241', '46 Sullivan Alley');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('760-809-536', 'Agnola', 'Jest', 'Female', '1965-09-03', 'ajest4@stanford.edu', '(993) 5420173', '02 Spenser Terrace');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('338-730-439', 'Darryl', 'Mouser', 'Female', '1964-12-15', 'dmouser5@youtube.com', '(813) 1404131', '4545 Eagle Crest Road');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('970-800-999', 'Kelsey', 'Jancik', 'Male', '2002-03-05', 'kjancik6@ibm.com', '(812) 4411293', '1291 Russell Junction');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('841-629-512', 'Catherin', 'Hilliam', 'Male', '1974-06-07', 'chilliam7@pinterest.com', '(688) 6150018', '46039 Service Trail');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('154-693-519', 'Allie', 'Goare', 'Male', '2002-11-17', 'agoare8@wikispaces.com', '(654) 4055443', '961 Village Hill');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('674-838-453', 'Ruttger', 'Wickardt', 'Female', '2003-03-04', 'rwickardt9@w3.org', '(399) 4524191', '85 Claremont Pass');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('920-403-458', 'Josiah', 'Holtom', 'Female', '1968-02-04', 'jholtoma@economist.com', '(259) 2626545', '67 Trailsway Road');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('502-117-019', 'Horten', 'Bilham', 'Female', '1990-09-10', 'hbilhamb@phoca.cz', '(798) 1018807', '9 Claremont Circle');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('794-804-919', 'Tory', 'Curless', 'Female', '1970-04-01', 'tcurlessc@noaa.gov', '(101) 9388017', '3323 Moose Terrace');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('522-972-869', 'Kurtis', 'Bollans', 'Male', '2003-06-19', 'kbollansd@ox.ac.uk', '(622) 5635125', '7 Oxford Terrace');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('871-365-704', 'Gregorio', 'Castanyer', 'Female', '1987-09-01', 'gcastanyere@tinypic.com', '(178) 8218341', '7636 New Castle Circle');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('333-190-645', 'Edie', 'Donnell', 'Female', '1979-05-23', 'edonnellf@nhs.uk', '(198) 3411414', '44531 Granby Parkway');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('628-207-193', 'Tamera', 'Donnell', 'Female', '1973-07-29', 'tdonnellg@epa.gov', '(120) 5101720', '7 Rusk Place');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('711-190-679', 'Tamqrah', 'Gerge', 'Female', '2001-08-12', 'tgergeh@techcrunch.com', '(297) 4023345', '186 Cottonwood Crossing');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('733-683-053', 'Gunter', 'Chatel', 'Female', '1988-05-14', 'gchateli@aboutads.info', '(660) 8626410', '694 Mosinee Crossing');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('180-648-346', 'Lindon', 'Heddy', 'Female', '1972-11-06', 'lheddyj@xinhuanet.com', '(629) 1405382', '89 Spaight Crossing');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('911-826-078', 'Kayley', 'McCome', 'Female', '1967-03-22', 'kmccomek@house.gov', '(744) 9685219', '770 Kensington Pass');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('983-466-963', 'Agnola', 'Pimme', 'Male', '2003-06-28', 'apimmel@forbes.com', '(983) 2657780', '696 Harbort Drive');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('397-717-753', 'Carlos', 'Borzoni', 'Female', '1991-12-20', 'cborzonim@nyu.edu', '(846) 6462730', '2234 Drewry Circle');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('334-843-302', 'Leonanie', 'Fairpo', 'Female', '1973-08-29', 'lfairpon@fda.gov', '(482) 1047839', '77 Warbler Lane');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('368-812-971', 'Tanner', 'Topes', 'Male', '1967-05-08', 'ttopeso@wunderground.com', '(581) 9502891', '511 Arapahoe Court');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('169-437-929', 'Beau', 'Tipler', 'Male', '1980-02-21', 'btiplerp@irs.gov', '(812) 4113644', '73 Sunfield Circle');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('949-348-184', 'Kris', 'Cocklin', 'Female', '1976-03-13', 'kcocklinq@oracle.com', '(590) 6999725', '19 Summit Way');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('774-563-071', 'Luella', 'Swoffer', 'Female', '1962-08-05', 'lswofferr@wikimedia.org', '(719) 5658059', '644 Walton Court');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('464-638-943', 'Jerrylee', 'Bickley', 'Male', '1994-06-09', 'jbickleys@dropbox.com', '(307) 5732681', '55543 Quincy Alley');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('299-537-417', 'Lennie', 'Staddon', 'Male', '1976-11-22', 'lstaddont@mediafire.com', '(810) 1382974', '7 Waxwing Hill');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('795-777-223', 'Margaux', 'Juett', 'Female', '1993-01-13', 'mjuettu@wsj.com', '(599) 7178513', '33 Cambridge Park');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('650-796-652', 'Eddi', 'Anneslie', 'Female', '1969-04-26', 'eannesliev@chicagotribune.com', '(824) 8775456', '9 Welch Road');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('669-186-634', 'Adler', 'Oleksinski', 'Male', '1962-08-15', 'aoleksinskiw@exblog.jp', '(749) 8162636', '13 Bobwhite Alley');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('816-614-701', 'Harmonie', 'Kettow', 'Female', '1988-05-28', 'hkettowx@mysql.com', '(563) 9994176', '3246 Lake View Center');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('962-957-267', 'Jobina', 'Rodson', 'Female', '1981-03-03', 'jrodsony@paginegialle.it', '(910) 7486235', '0 6th Park');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('465-966-661', 'Stephie', 'Haccleton', 'Male', '1964-05-25', 'shaccletonz@hexun.com', '(385) 4704032', '47932 Comanche Road');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('011-786-157', 'Bo', 'Yendall', 'Male', '1980-02-14', 'byendall10@usda.gov', '(325) 3928917', '34 Canary Circle');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('246-719-613', 'Julieta', 'Gratrix', 'Female', '1993-10-05', 'jgratrix11@jigsy.com', '(826) 3766832', '70 Straubel Lane');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('601-882-364', 'Bartram', 'Bulmer', 'Female', '1962-08-03', 'bbulmer12@npr.org', '(886) 3410702', '83694 Autumn Leaf Plaza');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('776-905-210', 'Padgett', 'O''Hara', 'Female', '1972-04-09', 'pohara13@squidoo.com', '(441) 3083354', '195 Service Alley');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('134-882-222', 'Reginauld', 'Gulley', 'Male', '1997-12-14', 'rgulley14@w3.org', '(634) 4148425', '72 Washington Alley');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('375-930-883', 'Geralda', 'Fleming', 'Male', '1991-08-16', 'gfleming15@latimes.com', '(778) 5480505', '1872 Mandrake Pass');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('199-688-351', 'Ulrikaumeko', 'Semeradova', 'Male', '1986-06-04', 'usemeradova16@symantec.com', '(485) 8432819', '3 Crescent Oaks Plaza');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('128-691-972', 'Elfie', 'Highton', 'Male', '1965-01-23', 'ehighton17@epa.gov', '(714) 3466047', '7 Mallard Plaza');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('772-975-534', 'Brandi', 'Loveday', 'Female', '1963-06-11', 'bloveday18@va.gov', '(690) 3937647', '2 Lerdahl Lane');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('099-026-317', 'Dehlia', 'Hayhurst', 'Male', '2002-06-23', 'dhayhurst19@ask.com', '(537) 6954543', '85 Holy Cross Avenue');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('126-851-345', 'Antoine', 'Kitchin', 'Male', '2001-04-30', 'akitchin1a@blog.com', '(223) 7212146', '6 Kensington Park');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('630-919-111', 'Hillyer', 'Karolowski', 'Male', '1966-02-04', 'hkarolowski1b@theglobeandmail.com', '(539) 8451121', '70 Mandrake Street');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('337-031-659', 'Corene', 'Aikman', 'Female', '1962-06-10', 'caikman1c@ucoz.com', '(948) 5273391', '9020 Mccormick Plaza');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('875-064-798', 'Cherry', 'Bertouloume', 'Male', '1966-03-20', 'cbertouloume1d@washingtonpost.com', '(842) 8801943', '38 Crescent Oaks Hill');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('498-825-769', 'Valene', 'Fist', 'Female', '1977-02-04', 'vfist1e@cpanel.net', '(722) 1296875', '4 Orin Center');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('703-807-709', 'Augustina', 'Sawney', 'Male', '1995-03-31', 'asawney1f@time.com', '(751) 3382916', '64 Sunbrook Way');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('799-056-233', 'Alister', 'Pirouet', 'Male', '1968-02-23', 'apirouet1g@state.tx.us', '(684) 3569843', '49615 Waxwing Center');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('429-547-942', 'Ronna', 'Daniellot', 'Male', '1989-02-24', 'rdaniellot1h@biglobe.ne.jp', '(310) 9886481', '86456 Morrow Crossing');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('524-286-752', 'Rosalie', 'McGuane', 'Male', '1972-11-28', 'rmcguane1i@bluehost.com', '(367) 2761693', '44971 Blue Bill Park Road');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('515-877-764', 'Rosalia', 'Petegree', 'Male', '2003-01-03', 'rpetegree1j@baidu.com', '(474) 3981244', '647 Carberry Point');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('268-082-992', 'Mathew', 'Millom', 'Male', '1997-02-02', 'mmillom1k@miitbeian.gov.cn', '(193) 4719405', '12066 West Road');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('060-733-460', 'Tobin', 'Wharfe', 'Female', '1980-02-27', 'twharfe1l@1688.com', '(661) 7584006', '80 Almo Parkway');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('426-918-007', 'Boone', 'Talboy', 'Male', '1979-12-01', 'btalboy1m@discovery.com', '(126) 9279855', '7504 Main Terrace');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('701-980-566', 'Harland', 'Mackley', 'Female', '1999-04-29', 'hmackley1n@networksolutions.com', '(611) 8169151', '0682 Glacier Hill Hill');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('051-864-666', 'Gwenni', 'McKissack', 'Female', '1980-02-25', 'gmckissack1o@state.gov', '(348) 2456167', '231 Kingsford Hill');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('579-991-619', 'Audrey', 'Worsalls', 'Female', '1977-03-21', 'aworsalls1p@hatena.ne.jp', '(493) 5746336', '1 Dottie Point');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('822-727-868', 'Eddi', 'Joicey', 'Female', '1996-10-08', 'ejoicey1q@de.vu', '(854) 5405005', '12401 Hauk Street');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('158-451-839', 'Olwen', 'Felten', 'Male', '1963-05-17', 'ofelten1r@trellian.com', '(404) 5855028', '10 Derek Way');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('781-970-416', 'Jada', 'Szach', 'Female', '1972-07-31', 'jszach1s@google.co.jp', '(903) 3188828', '655 Judy Place');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('043-678-494', 'Nissy', 'Possel', 'Female', '1998-07-08', 'npossel1t@cnbc.com', '(631) 9041700', '7 Corscot Pass');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('309-612-354', 'Bobbe', 'Heinreich', 'Male', '1984-02-12', 'bheinreich1u@umn.edu', '(614) 3828358', '94 Ramsey Way');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('754-943-132', 'Reagan', 'Burgett', 'Male', '1976-02-14', 'rburgett1v@naver.com', '(681) 7423133', '409 Transport Pass');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('167-745-346', 'Jerrilyn', 'Birkwood', 'Female', '1970-01-31', 'jbirkwood1w@mediafire.com', '(310) 2983242', '86 Jenna Way');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('136-974-651', 'Corey', 'Zisneros', 'Male', '1986-04-29', 'czisneros1x@google.com.br', '(770) 7076315', '5 Pleasure Road');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('959-390-642', 'Sandro', 'Gligori', 'Male', '2003-08-18', 'sgligori1y@theguardian.com', '(768) 2047430', '8440 Golden Leaf Avenue');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('419-442-885', 'Annette', 'Malim', 'Female', '1961-03-05', 'amalim1z@printfriendly.com', '(385) 8979914', '1 Sloan Terrace');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('308-192-153', 'Annabella', 'Krol', 'Male', '1975-03-13', 'akrol20@sakura.ne.jp', '(514) 9709045', '3200 Katie Trail');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('442-035-042', 'Genevra', 'Scroggins', 'Female', '1993-02-08', 'gscroggins21@mysql.com', '(813) 1345865', '7 Ronald Regan Junction');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('287-690-768', 'Vlad', 'Gannon', 'Female', '1982-05-09', 'vgannon22@prnewswire.com', '(713) 1808972', '86226 Hanover Pass');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('081-008-402', 'Hedwig', 'Calcutt', 'Female', '2000-11-24', 'hcalcutt23@theguardian.com', '(853) 1908931', '487 Comanche Place');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('934-192-427', 'Roldan', 'Poore', 'Male', '1974-05-25', 'rpoore24@toplist.cz', '(278) 3375693', '4 Elmside Way');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('551-594-942', 'Waly', 'Pinnell', 'Female', '1971-02-23', 'wpinnell25@elpais.com', '(353) 2372950', '67 Hintze Point');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('287-640-056', 'Nelly', 'Dobbins', 'Female', '1977-04-20', 'ndobbins26@arizona.edu', '(486) 5491222', '3 Swallow Place');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('994-510-196', 'Chrisy', 'Roan', 'Male', '1984-10-11', 'croan27@pagesperso-orange.fr', '(185) 6329185', '653 Menomonie Center');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('069-431-778', 'Rance', 'Pittford', 'Female', '1992-12-21', 'rpittford28@bravesites.com', '(253) 6214252', '30204 Swallow Parkway');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('544-264-784', 'Ava', 'Brankley', 'Male', '2002-05-09', 'abrankley29@etsy.com', '(588) 7648015', '9 4th Center');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('811-579-868', 'Meta', 'Lusted', 'Male', '1969-04-15', 'mlusted2a@alibaba.com', '(246) 7838040', '22623 Tennyson Plaza');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('245-977-637', 'Gunther', 'Gorringe', 'Female', '1971-10-06', 'ggorringe2b@digg.com', '(208) 2903056', '44692 Ruskin Circle');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('457-748-431', 'Heath', 'Jenner', 'Male', '1990-08-11', 'hjenner2c@usa.gov', '(984) 3451231', '6797 Farragut Parkway');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('299-765-002', 'Christophe', 'Cranna', 'Male', '1989-09-19', 'ccranna2d@friendfeed.com', '(207) 8361966', '900 Westport Park');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('969-726-672', 'Ellis', 'Vankov', 'Female', '1976-03-17', 'evankov2e@hibu.com', '(847) 6964799', '313 Oak Parkway');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('746-670-163', 'Elyssa', 'Margiotta', 'Female', '2000-11-09', 'emargiotta2f@networksolutions.com', '(202) 2164100', '5767 Bluestem Court');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('829-756-995', 'Jessika', 'Conerding', 'Female', '1979-09-23', 'jconerding2g@live.com', '(339) 8402453', '297 Manufacturers Court');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('275-606-884', 'Codee', 'Voelker', 'Male', '1994-03-25', 'cvoelker2h@skype.com', '(589) 9711856', '38 Portage Hill');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('595-468-116', 'Ansley', 'Moston', 'Female', '1964-05-03', 'amoston2i@blog.com', '(637) 9735283', '9 Main Lane');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('907-244-410', 'Charlean', 'Nelles', 'Female', '1984-08-02', 'cnelles2j@acquirethisname.com', '(719) 7843494', '4532 Westerfield Center');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('269-658-985', 'Noelyn', 'Blune', 'Female', '1981-10-08', 'nblune2k@opera.com', '(594) 5672198', '6 Pennsylvania Court');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('216-031-062', 'Hailey', 'Junkinson', 'Male', '1986-01-16', 'hjunkinson2l@pinterest.com', '(556) 9581245', '9718 Browning Alley');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('300-831-050', 'Carmita', 'Pickup', 'Female', '1971-11-12', 'cpickup2m@51.la', '(886) 4598618', '63 Lukken Road');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('242-086-913', 'Alfonso', 'Escalero', 'Male', '1981-07-31', 'aescalero2n@surveymonkey.com', '(300) 7483569', '40 Fuller Way');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('817-558-837', 'Julee', 'Levick', 'Female', '1975-10-18', 'jlevick2o@over-blog.com', '(634) 2386693', '498 Artisan Center');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('117-358-998', 'Richmond', 'Everard', 'Male', '1995-10-15', 'reverard2p@squidoo.com', '(134) 1742066', '5016 Debs Lane');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('241-326-823', 'Fawne', 'Coombe', 'Female', '1996-02-09', 'fcoombe2q@wunderground.com', '(249) 9415091', '90 Laurel Circle');
insert into Membership (membership_id, first_name, last_name, gender, dob, email, phone, address) values ('534-370-501', 'Babette', 'Birbeck', 'Female', '1986-10-12', 'bbirbeck2r@boston.com', '(136) 7317062', '93 Cambridge Trail');

insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('24-8646', 'Fork - Plastic', '2021-09-01', 4.4, 0.044);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('05-2660', 'Easy Off Oven Cleaner', '2021-09-13', 10.0, 0.1);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('18-6627', 'Mushroom - Portebello', '2021-08-25', 11.3, 0.113);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('19-2971', 'Wood Chips - Regular', '2021-09-12', 18.6, 0.186);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('50-1912', 'Beef - Roasted, Cooked', '2021-09-13', 3.7, 0.037);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('71-2100', 'Goat - Leg', '2021-09-10', 12.9, 0.129);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('59-7024', 'Muffin - Mix - Bran And Maple 15l', '2021-09-09', 16.4, 0.164);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('18-5836', 'Monkfish Fresh - Skin Off', '2021-09-07', 4.0, 0.04);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('22-4344', 'Cookie Dough - Chunky', '2021-09-19', 2.8, 0.028);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('87-8104', 'Basil - Dry, Rubbed', '2021-08-25', 16.4, 0.164);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('77-2207', 'Dish Towel', '2021-08-22', 18.0, 0.18);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('35-0031', 'Bread - Sour Batard', '2021-09-03', 8.9, 0.089);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('35-8327', 'Veal - Osso Bucco', '2021-09-20', 2.6, 0.026);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('51-5480', 'Thermometer Digital', '2021-09-18', 7.7, 0.077);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('33-5893', 'Beef - Top Sirloin', '2021-09-06', 1.2, 0.012);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('03-4653', 'Juice - Clam, 46 Oz', '2021-09-14', 7.6, 0.076);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('04-1630', 'Beef - Inside Round', '2021-09-04', 10.7, 0.107);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('85-8736', 'Propel Sport Drink', '2021-09-08', 19.0, 0.19);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('32-8750', 'Sour Puss - Tangerine', '2021-08-30', 7.4, 0.074);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('23-1459', 'Mushroom - Porcini Frozen', '2021-08-24', 19.3, 0.193);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('72-1291', 'Cucumber - Pickling Ontario', '2021-09-04', 2.8, 0.028);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('51-6246', 'Muskox - French Rack', '2021-09-05', 12.7, 0.127);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('91-4901', 'Scallop - St. Jaques', '2021-09-10', 17.4, 0.174);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('35-9185', 'Olives - Black, Pitted', '2021-09-04', 8.6, 0.086);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('20-7893', 'Wooden Mop Handle', '2021-08-26', 16.6, 0.166);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('64-7819', 'Nori Sea Weed - Gold Label', '2021-08-22', 7.8, 0.078);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('91-0694', 'Green Tea Refresher', '2021-08-31', 1.7, 0.017);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('71-7634', 'Wine - Rioja Campo Viejo', '2021-09-12', 12.6, 0.126);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('27-4547', 'Dried Cherries', '2021-08-22', 13.5, 0.135);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('72-7222', 'Oregano - Dry, Rubbed', '2021-08-22', 2.7, 0.027);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('21-7186', 'Rice - 7 Grain Blend', '2021-09-06', 18.2, 0.182);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('45-6787', 'Duck - Fat', '2021-09-13', 11.1, 0.111);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('29-0409', 'Juice - Pineapple, 48 Oz', '2021-09-21', 11.4, 0.114);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('14-1668', 'Venison - Denver Leg Boneless', '2021-08-23', 4.1, 0.041);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('62-0130', 'Apron', '2021-08-26', 16.4, 0.164);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('71-2374', 'Cheese - Parmesan Cubes', '2021-08-31', 4.3, 0.043);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('90-0469', 'Flax Seed', '2021-09-04', 7.5, 0.075);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('11-2038', 'Cabbage Roll', '2021-09-19', 10.8, 0.108);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('62-5024', 'Wine - Red, Antinori Santa', '2021-08-24', 7.5, 0.075);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('62-0234', 'Frangelico', '2021-08-22', 9.4, 0.094);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('44-1155', 'Rice - Aborio', '2021-09-16', 17.6, 0.176);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('84-7565', 'Butter Sweet', '2021-09-16', 4.5, 0.045);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('64-8589', 'Champagne - Brights, Dry', '2021-08-30', 9.1, 0.091);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('82-0586', 'Sauce - Alfredo', '2021-08-30', 1.9, 0.019);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('32-1205', 'Vinegar - Cider', '2021-08-28', 13.2, 0.132);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('22-5351', 'Bread - Sour Batard', '2021-09-18', 17.8, 0.178);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('83-1257', 'Ecolab - Solid Fusion', '2021-08-31', 12.0, 0.12);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('14-7732', 'Lotus Root', '2021-09-11', 11.7, 0.117);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('56-6390', 'Milk - 2% 250 Ml', '2021-09-09', 15.7, 0.157);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('22-9941', 'Pepper - Red, Finger Hot', '2021-09-11', 11.9, 0.119);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('72-8694', 'Oil - Sesame', '2021-09-17', 16.1, 0.161);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('22-1028', 'Pecan Raisin - Tarts', '2021-09-18', 8.3, 0.083);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('81-5838', 'Cleaner - Comet', '2021-09-05', 10.1, 0.101);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('57-0434', 'Bread - Olive Dinner Roll', '2021-09-11', 9.5, 0.095);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('66-6673', 'Shrimp - Black Tiger 26/30', '2021-09-03', 9.5, 0.095);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('67-7333', 'Beer - Molson Excel', '2021-09-15', 9.5, 0.095);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('12-2830', 'Syrup - Chocolate', '2021-09-15', 16.7, 0.167);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('26-0047', 'Table Cloth 53x69 White', '2021-09-09', 2.8, 0.028);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('74-5322', 'Shiro Miso', '2021-09-15', 2.0, 0.02);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('80-3326', 'Sobe - Liz Blizz', '2021-09-04', 17.4, 0.174);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('38-6504', 'Duck - Legs', '2021-09-19', 12.8, 0.128);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('68-3810', 'Sea Bass - Whole', '2021-09-02', 7.4, 0.074);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('24-7095', 'Langers - Mango Nectar', '2021-09-20', 12.5, 0.125);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('92-3359', 'Versatainer Nc - 9388', '2021-09-11', 1.8, 0.018);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('47-0021', 'Spinach - Spinach Leaf', '2021-09-11', 10.9, 0.109);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('63-4253', 'Shallots', '2021-08-29', 18.8, 0.188);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('41-6002', 'Cotton Wet Mop 16 Oz', '2021-09-18', 17.9, 0.179);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('09-5996', 'Ecolab - Hobart Upr Prewash Arm', '2021-09-19', 17.1, 0.171);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('98-1852', 'Chinese Lemon Pork', '2021-09-01', 11.1, 0.111);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('03-4209', 'Pasta - Ravioli', '2021-08-27', 3.2, 0.032);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('11-5462', 'Muffin - Bran Ind Wrpd', '2021-09-11', 11.8, 0.118);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('30-6504', 'Napkin Colour', '2021-09-17', 8.5, 0.085);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('86-2158', 'Bread - Sticks, Thin, Plain', '2021-08-30', 19.2, 0.192);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('22-4448', 'Wine - Baron De Rothschild', '2021-09-08', 14.0, 0.14);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('09-9288', 'Paste - Black Olive', '2021-08-24', 5.8, 0.058);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('41-9940', 'Longos - Chicken Wings', '2021-08-26', 9.9, 0.099);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('95-6170', 'Soup Campbells - Tomato Bisque', '2021-08-30', 11.8, 0.118);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('33-8125', 'Caviar - Salmon', '2021-09-15', 8.5, 0.085);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('63-2588', 'Wine - Riesling Dr. Pauly', '2021-09-05', 1.7, 0.017);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('32-7235', 'Onions - Red', '2021-09-01', 10.5, 0.105);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('75-1157', 'Bread - Petit Baguette', '2021-09-04', 10.1, 0.101);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('70-3265', 'Coffee - 10oz Cup 92961', '2021-09-17', 12.5, 0.125);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('42-6162', 'Pastry - Lemon Danish - Mini', '2021-09-18', 13.4, 0.134);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('35-9884', 'Lamb Shoulder Boneless Nz', '2021-09-16', 15.2, 0.152);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('63-5470', 'Hipnotiq Liquor', '2021-08-29', 6.7, 0.067);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('06-5581', 'Bread - Dark Rye, Loaf', '2021-09-02', 5.1, 0.051);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('14-2933', 'Ham - Cooked', '2021-09-14', 1.6, 0.016);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('08-0605', 'Mushroom Morel Fresh', '2021-09-21', 9.3, 0.093);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('42-9065', 'Whmis Spray Bottle Graduated', '2021-09-20', 13.9, 0.139);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('22-2549', 'Puree - Mocha', '2021-09-13', 5.8, 0.058);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('39-2453', 'Venison - Striploin', '2021-08-25', 15.4, 0.154);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('06-1143', 'Beets - Pickled', '2021-08-29', 9.4, 0.094);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('64-7935', 'Aspic - Clear', '2021-08-29', 5.2, 0.052);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('04-9330', 'Tea - Grapefruit Green Tea', '2021-09-09', 19.8, 0.198);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('02-0034', 'Tia Maria', '2021-09-03', 7.4, 0.074);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('39-9373', 'Beef Wellington', '2021-09-04', 7.4, 0.074);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('07-9162', 'Milk - Homo', '2021-08-26', 12.2, 0.122);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('07-1121', 'Beef - Tenderlion, Center Cut', '2021-09-02', 8.5, 0.085);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('37-1833', 'Clams - Bay', '2021-09-18', 18.5, 0.185);
insert into Items (item_no, item_name, expiration_date, price, reward_points) values ('02-8269', 'Orange Roughy 6/8 Oz', '2021-09-07', 18.4, 0.184);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create view view1 as select membership_id from membership;
create view view2 as select Item_No from Items;
insert into Buy(someone, something)
select * from view1 cross join view2 order by random() limit 1000;
select * from buy

/*I tried to add a function that everytime a member check out, his/her reward points changes accordingly. 
But I didn't figure out how to make it. So columns such as Reward Points may seem redundant.*/