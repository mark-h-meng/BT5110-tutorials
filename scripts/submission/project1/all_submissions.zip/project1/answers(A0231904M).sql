/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/* A0231904M                                                                     */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* 
There are 3 tables in this schema, alumni, car and own.
Entity 1
Table alumni contains 7 attibutes decribing the information of NUS's alumnus. 
I choose SSN as student_id, First name as first_name, Last name as last_name,
Email address as email address, Phone as phone_number, Gender(Binary) as gender,
Job title as job.
(using student_id as primary key)

Entity 2
Table car contains 4 attributes decribing the information of cars model.
I choose Car make as manufacturer, Car Model as model, 
Car Model Year as model_year, and Money as price.
(using composite of manufacture, model, model_year as primary key)

Relationship (many-to-many)
Table own describes the relationship between which alumni owns which model
of cars. Each alumni can owns more than 1 model of car, while each model
of cars can be owned by many alumnus.
(using composite of studentid, manufacture, model, model_year as primary key)
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS alumni (
	student_id VARCHAR(50) PRIMARY KEY,
	first_name VARCHAR(50) NOT NULL,
	last_name VARCHAR(50) NOT NULL,
	email VARCHAR(50) UNIQUE NOT NULL,
	phone_number VARCHAR(50) UNIQUE NOT NULL,
	gender VARCHAR(50) NOT NULL,
	job VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS car (
	manufacturer VARCHAR(50) NOT NULL,
	model VARCHAR(50) NOT NULL,
	model_year VARCHAR(50) NOT NULL,
	price VARCHAR(50) NOT NULL,
	PRIMARY KEY(manufacturer, model, model_year)
);

CREATE TABLE IF NOT EXISTS own(
	student_id VARCHAR(50) REFERENCES alumni(student_id)
	ON UPDATE CASCADE ON DELETE CASCADE
	DEFERRABLE INITIALLY DEFERRED,
	manufacturer VARCHAR(50),
	model VARCHAR(50),
	model_year VARCHAR(50),
	PRIMARY KEY (student_id , manufacturer, model, model_year),
	FOREIGN KEY (manufacturer, model, model_year) REFERENCES car(manufacturer, model, model_year)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('620-05-2809', 'Skip', 'Bonnier', 'sbonnier0@nba.com', '921-701-3018', 'Female', 'Senior Developer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('384-93-3541', 'Kissee', 'Ayscough', 'kayscough1@go.com', '465-922-9919', 'Male', 'Help Desk Operator');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('598-24-8470', 'Aime', 'Hasser', 'ahasser2@techcrunch.com', '254-347-6867', 'Male', 'Legal Assistant');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('702-60-2812', 'Nancy', 'Jeness', 'njeness3@aboutads.info', '341-458-0644', 'Female', 'General Manager');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('800-69-1580', 'Maxim', 'Sorbie', 'msorbie4@wisc.edu', '621-515-8893', 'Female', 'Nurse Practicioner');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('165-11-5365', 'Rodger', 'Brozek', 'rbrozek5@home.pl', '369-739-3685', 'Female', 'Chief Design Engineer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('312-87-6012', 'Ruby', 'Laugherane', 'rlaugherane6@timesonline.co.uk', '859-881-4547', 'Female', 'Junior Executive');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('381-30-9525', 'Janel', 'Kettlesting', 'jkettlesting7@google.cn', '461-276-7449', 'Female', 'Director of Sales');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('293-71-7506', 'Carlie', 'Felder', 'cfelder8@buzzfeed.com', '898-459-6651', 'Male', 'Safety Technician IV');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('125-09-3885', 'Shaylyn', 'Rogliero', 'srogliero9@hatena.ne.jp', '757-561-9285', 'Male', 'Environmental Specialist');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('333-23-5839', 'Catharina', 'Schofield', 'cschofielda@usa.gov', '711-243-4657', 'Male', 'Nurse Practicioner');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('381-61-0349', 'Killy', 'Mercer', 'kmercerb@devhub.com', '413-213-7398', 'Male', 'Environmental Tech');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('534-78-8844', 'Aubert', 'Doutch', 'adoutchc@dot.gov', '819-202-2488', 'Female', 'Assistant Professor');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('221-57-1520', 'Karissa', 'Steers', 'ksteersd@cnbc.com', '232-685-6989', 'Female', 'Speech Pathologist');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('792-33-8262', 'Evered', 'Yo', 'eyoe@walmart.com', '969-900-4754', 'Female', 'Account Representative I');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('201-55-9470', 'Denis', 'Paton', 'dpatonf@google.es', '496-620-6084', 'Male', 'Civil Engineer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('289-60-4198', 'Emelyne', 'Olivo', 'eolivog@discuz.net', '568-307-9709', 'Female', 'VP Product Management');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('167-32-8223', 'Reynolds', 'Hamsher', 'rhamsherh@rambler.ru', '946-815-4015', 'Male', 'Data Coordiator');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('213-16-2282', 'Abraham', 'Heales', 'ahealesi@spiegel.de', '832-279-7013', 'Female', 'Help Desk Operator');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('227-52-4309', 'Elnore', 'Hayles', 'ehaylesj@prweb.com', '283-508-8205', 'Male', 'Registered Nurse');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('702-76-3977', 'Friedrich', 'Lamps', 'flampsk@smugmug.com', '639-325-2810', 'Male', 'Statistician I');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('228-87-6764', 'Malchy', 'Maior', 'mmaiorl@prnewswire.com', '358-612-5312', 'Male', 'Environmental Tech');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('544-41-8471', 'Ardyce', 'Cuddon', 'acuddonm@dagondesign.com', '379-758-5784', 'Male', 'Associate Professor');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('472-27-9224', 'Isa', 'Van Arsdale', 'ivanarsdalen@theatlantic.com', '958-975-1024', 'Female', 'Cost Accountant');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('269-99-4421', 'Raimondo', 'Di Matteo', 'rdimatteoo@surveymonkey.com', '969-331-9725', 'Female', 'Payment Adjustment Coordinator');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('600-92-2238', 'Nixie', 'Bosworth', 'nbosworthp@prnewswire.com', '221-383-4709', 'Male', 'Account Coordinator');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('249-35-7273', 'Franky', 'Beazey', 'fbeazeyq@businessinsider.com', '384-156-7145', 'Female', 'Biostatistician I');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('603-47-3289', 'Lewes', 'Gimenez', 'lgimenezr@phoca.cz', '865-680-9912', 'Female', 'Recruiter');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('194-95-2451', 'Brantley', 'Guiu', 'bguius@ucsd.edu', '141-623-4333', 'Female', 'Occupational Therapist');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('606-42-5700', 'Rica', 'Jankowski', 'rjankowskit@amazon.co.uk', '475-198-1312', 'Female', 'Accounting Assistant III');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('227-99-9477', 'Moshe', 'Duester', 'mduesteru@godaddy.com', '586-191-6657', 'Female', 'Software Test Engineer I');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('883-16-0566', 'Gardner', 'Thewys', 'gthewysv@godaddy.com', '710-336-8110', 'Female', 'Director of Sales');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('486-46-5950', 'Coriss', 'Talkington', 'ctalkingtonw@wikispaces.com', '511-198-7563', 'Female', 'Analog Circuit Design manager');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('586-51-1282', 'Paxton', 'Kellart', 'pkellartx@chicagotribune.com', '443-807-9545', 'Female', 'Financial Advisor');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('762-08-5115', 'Towney', 'Jikovsky', 'tjikovskyy@illinois.edu', '954-496-6752', 'Female', 'Account Executive');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('349-18-6641', 'Kirsti', 'Dredge', 'kdredgez@odnoklassniki.ru', '150-355-3383', 'Male', 'Structural Engineer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('162-47-1427', 'Gwenette', 'Walsham', 'gwalsham10@oracle.com', '144-465-3712', 'Female', 'Senior Sales Associate');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('311-20-0839', 'Jordain', 'Gilbane', 'jgilbane11@hexun.com', '408-162-4050', 'Male', 'Software Engineer II');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('296-54-6905', 'Donovan', 'Stidson', 'dstidson12@census.gov', '532-180-3053', 'Female', 'VP Sales');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('887-75-6186', 'Maudie', 'Goudard', 'mgoudard13@globo.com', '485-450-9944', 'Female', 'Speech Pathologist');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('332-10-6644', 'Allis', 'Presidey', 'apresidey14@va.gov', '139-256-5528', 'Male', 'Electrical Engineer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('132-96-6529', 'Hillery', 'Doppler', 'hdoppler15@whitehouse.gov', '358-295-5719', 'Female', 'Occupational Therapist');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('456-88-7249', 'Carmelina', 'O''Shevlin', 'coshevlin16@marriott.com', '246-182-7112', 'Male', 'Health Coach II');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('533-18-5038', 'Fionnula', 'Dimitrescu', 'fdimitrescu17@va.gov', '333-720-0165', 'Male', 'Office Assistant II');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('753-53-0011', 'Rochester', 'Pacitti', 'rpacitti18@webs.com', '618-823-4588', 'Female', 'VP Sales');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('196-77-2211', 'Jodie', 'Lagen', 'jlagen19@bloglovin.com', '178-844-7376', 'Female', 'Chemical Engineer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('856-39-7304', 'Kennedy', 'Tribell', 'ktribell1a@indiegogo.com', '404-424-5393', 'Male', 'Administrative Assistant I');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('167-21-3528', 'Marc', 'Peacey', 'mpeacey1b@free.fr', '462-299-9303', 'Male', 'Tax Accountant');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('663-89-5736', 'Ardyce', 'Menary', 'amenary1c@1und1.de', '320-593-1466', 'Female', 'Senior Editor');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('854-24-9053', 'Josie', 'Wippermann', 'jwippermann1d@over-blog.com', '656-608-2922', 'Female', 'Administrative Officer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('890-94-2001', 'Beilul', 'Cavolini', 'bcavolini1e@wp.com', '134-159-3013', 'Female', 'Electrical Engineer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('406-52-1529', 'Stillman', 'Shiel', 'sshiel1f@washington.edu', '897-288-5089', 'Female', 'Chief Design Engineer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('541-56-6427', 'Blaine', 'Hatter', 'bhatter1g@theatlantic.com', '473-666-0545', 'Female', 'Clinical Specialist');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('295-86-0804', 'Byram', 'Stegel', 'bstegel1h@fastcompany.com', '632-581-9347', 'Male', 'Human Resources Manager');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('160-08-9929', 'Nico', 'Sancraft', 'nsancraft1i@reddit.com', '707-499-4476', 'Female', 'Staff Accountant III');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('730-11-5546', 'Livia', 'Malek', 'lmalek1j@slideshare.net', '854-252-1535', 'Female', 'Senior Financial Analyst');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('444-06-5917', 'Virgil', 'Billborough', 'vbillborough1k@bizjournals.com', '701-318-1934', 'Female', 'Safety Technician I');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('250-62-2811', 'Leanora', 'Janout', 'ljanout1l@ocn.ne.jp', '499-458-5002', 'Female', 'Operator');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('333-41-0457', 'Perkin', 'Angelo', 'pangelo1m@loc.gov', '170-839-3650', 'Male', 'Legal Assistant');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('693-29-5951', 'Teddi', 'Wodham', 'twodham1n@yolasite.com', '610-525-5359', 'Male', 'General Manager');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('588-97-9273', 'Mora', 'Densell', 'mdensell1o@joomla.org', '811-243-5296', 'Female', 'Geologist IV');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('548-49-9764', 'Levy', 'Sellars', 'lsellars1p@live.com', '602-154-1314', 'Male', 'Programmer Analyst II');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('661-38-3192', 'Raoul', 'Mawby', 'rmawby1q@barnesandnoble.com', '388-865-7544', 'Female', 'Analyst Programmer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('513-48-9898', 'Lenette', 'Lazar', 'llazar1r@walmart.com', '318-145-0036', 'Male', 'Structural Engineer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('651-60-7238', 'Idelle', 'Brussell', 'ibrussell1s@rambler.ru', '838-738-9867', 'Male', 'Senior Editor');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('396-30-5618', 'Yorke', 'Morfett', 'ymorfett1t@feedburner.com', '467-873-6261', 'Female', 'Information Systems Manager');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('244-11-0156', 'Marcella', 'Summersby', 'msummersby1u@cdbaby.com', '363-269-7997', 'Male', 'Help Desk Operator');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('603-49-8229', 'Freeland', 'Walkden', 'fwalkden1v@china.com.cn', '938-385-5605', 'Female', 'Sales Representative');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('339-87-9094', 'Giacinta', 'Forrestall', 'gforrestall1w@usnews.com', '551-910-6268', 'Male', 'Financial Advisor');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('214-62-6935', 'Eachelle', 'Guyon', 'eguyon1x@nydailynews.com', '644-459-5302', 'Female', 'Librarian');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('716-87-7553', 'Theressa', 'Embery', 'tembery1y@ucoz.com', '855-885-5091', 'Male', 'Junior Executive');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('410-25-8687', 'Beau', 'Gronaver', 'bgronaver1z@stumbleupon.com', '404-738-3977', 'Male', 'Director of Sales');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('774-86-9981', 'Darin', 'Hollebon', 'dhollebon20@yandex.ru', '625-228-1293', 'Female', 'Help Desk Operator');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('365-57-9512', 'Ansley', 'McInulty', 'amcinulty21@photobucket.com', '288-390-7451', 'Male', 'Marketing Manager');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('886-04-9741', 'Tore', 'Conelly', 'tconelly22@cbsnews.com', '373-438-7409', 'Male', 'Administrative Officer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('187-50-3227', 'Kris', 'Proughten', 'kproughten23@census.gov', '323-442-7079', 'Female', 'Civil Engineer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('291-98-9346', 'Ileane', 'Chittock', 'ichittock24@latimes.com', '374-964-3628', 'Female', 'Developer IV');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('337-17-3035', 'Mischa', 'Matuska', 'mmatuska25@ibm.com', '235-135-9456', 'Male', 'Human Resources Assistant III');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('691-03-5822', 'Isac', 'Romao', 'iromao26@instagram.com', '372-744-6314', 'Female', 'Budget/Accounting Analyst III');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('808-30-3558', 'Jefferson', 'Raoul', 'jraoul27@fda.gov', '143-751-6588', 'Female', 'Engineer III');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('148-24-2078', 'Katinka', 'Schneidau', 'kschneidau28@wikimedia.org', '311-866-3494', 'Female', 'Research Nurse');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('381-85-8420', 'Arel', 'Found', 'afound29@redcross.org', '359-894-1612', 'Male', 'Programmer III');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('607-67-1061', 'Selie', 'Jeanesson', 'sjeanesson2a@weebly.com', '445-428-3138', 'Female', 'Research Associate');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('606-24-3719', 'Vickie', 'Morit', 'vmorit2b@arizona.edu', '823-568-8730', 'Female', 'Marketing Manager');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('617-48-8357', 'Hildegarde', 'Childerhouse', 'hchilderhouse2c@bloglines.com', '752-934-0804', 'Male', 'Budget/Accounting Analyst IV');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('419-32-1923', 'Wandie', 'Keady', 'wkeady2d@instagram.com', '291-372-3702', 'Female', 'Librarian');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('374-61-3939', 'Nye', 'Yerrington', 'nyerrington2e@ted.com', '207-759-2624', 'Female', 'Executive Secretary');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('580-23-7339', 'Mandi', 'Cordrey', 'mcordrey2f@exblog.jp', '937-649-3555', 'Female', 'Operator');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('726-94-1643', 'Celia', 'Joanic', 'cjoanic2g@tinypic.com', '591-884-6830', 'Female', 'Data Coordiator');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('431-84-8211', 'Miquela', 'Donson', 'mdonson2h@gov.uk', '276-439-1367', 'Male', 'Dental Hygienist');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('361-79-0314', 'Steward', 'Kalvin', 'skalvin2i@behance.net', '135-555-0611', 'Male', 'Civil Engineer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('831-70-6924', 'Laura', 'Gallier', 'lgallier2j@angelfire.com', '943-750-5047', 'Male', 'Payment Adjustment Coordinator');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('422-52-9880', 'Marna', 'Morstatt', 'mmorstatt2k@ustream.tv', '568-779-2251', 'Male', 'Information Systems Manager');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('841-79-2524', 'Rora', 'Paoletto', 'rpaoletto2l@godaddy.com', '888-138-8315', 'Female', 'Staff Accountant III');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('220-13-6055', 'Heidie', 'Hucquart', 'hhucquart2m@ft.com', '333-880-6343', 'Female', 'Staff Scientist');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('724-09-4396', 'Timotheus', 'Bowdery', 'tbowdery2n@deviantart.com', '800-826-9650', 'Male', 'Internal Auditor');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('687-73-6342', 'Leora', 'Totterdill', 'ltotterdill2o@accuweather.com', '873-678-8094', 'Female', 'Web Designer II');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('462-85-7667', 'Dominique', 'Joly', 'djoly2p@ucsd.edu', '894-471-0179', 'Male', 'Mechanical Systems Engineer');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('744-80-8241', 'Danita', 'Vreede', 'dvreede2q@elpais.com', '686-205-3636', 'Male', 'Software Test Engineer I');
insert into alumni (student_id, first_name, last_name, email, phone_number, gender, job) values ('458-36-6622', 'Byrom', 'Rozzell', 'brozzell2r@telegraph.co.uk', '822-892-1167', 'Male', 'Director of Sales');
insert into car (manufacturer, model, model_year, price) values ('Infiniti', 'FX', 2004, '$112422.75');
insert into car (manufacturer, model, model_year, price) values ('Buick', 'Century', 1990, '$196647.96');
insert into car (manufacturer, model, model_year, price) values ('Mazda', 'B-Series', 2004, '$188054.16');
insert into car (manufacturer, model, model_year, price) values ('Toyota', '4Runner', 2011, '$168685.70');
insert into car (manufacturer, model, model_year, price) values ('Ford', 'Escape', 2007, '$142272.29');
insert into car (manufacturer, model, model_year, price) values ('Kia', 'Carens', 2008, '$191750.66');
insert into car (manufacturer, model, model_year, price) values ('Maybach', '57', 2006, '$132562.33');
insert into car (manufacturer, model, model_year, price) values ('Toyota', 'Celica', 1983, '$160214.18');
insert into car (manufacturer, model, model_year, price) values ('Audi', '100', 1991, '$107424.04');
insert into car (manufacturer, model, model_year, price) values ('Ford', 'Bronco', 1988, '$141653.75');
insert into car (manufacturer, model, model_year, price) values ('Honda', 'S2000', 2006, '$195859.39');
insert into car (manufacturer, model, model_year, price) values ('Lamborghini', 'Reventón', 2008, '$67687.11');
insert into car (manufacturer, model, model_year, price) values ('Maybach', '57S', 2005, '$129445.39');
insert into car (manufacturer, model, model_year, price) values ('Volvo', '960', 1993, '$186834.07');
insert into car (manufacturer, model, model_year, price) values ('Plymouth', 'Grand Voyager', 1995, '$38263.85');
insert into car (manufacturer, model, model_year, price) values ('GMC', 'Suburban 2500', 1997, '$70262.17');
insert into car (manufacturer, model, model_year, price) values ('Chevrolet', 'Silverado 1500', 2004, '$140567.71');
insert into car (manufacturer, model, model_year, price) values ('Toyota', 'MR2', 2005, '$71606.89');
insert into car (manufacturer, model, model_year, price) values ('Buick', 'Roadmaster', 1993, '$58761.44');
insert into car (manufacturer, model, model_year, price) values ('Hyundai', 'Elantra', 2004, '$108575.10');
insert into car (manufacturer, model, model_year, price) values ('Mazda', '929', 1993, '$152182.12');
insert into car (manufacturer, model, model_year, price) values ('Chevrolet', 'Malibu', 2006, '$90489.94');
insert into car (manufacturer, model, model_year, price) values ('Oldsmobile', 'Intrigue', 2002, '$73136.23');
insert into car (manufacturer, model, model_year, price) values ('Dodge', 'Ram 1500 Club', 1995, '$41381.61');
insert into car (manufacturer, model, model_year, price) values ('Suzuki', 'Grand Vitara', 2011, '$173449.65');
insert into car (manufacturer, model, model_year, price) values ('Panoz', 'Esperante', 2007, '$52812.78');
insert into car (manufacturer, model, model_year, price) values ('Mitsubishi', 'Mirage', 1999, '$37331.45');
insert into car (manufacturer, model, model_year, price) values ('Mercedes-Benz', 'SLK-Class', 2000, '$89705.29');
insert into car (manufacturer, model, model_year, price) values ('Suzuki', 'SJ', 1987, '$115615.94');
insert into car (manufacturer, model, model_year, price) values ('Lincoln', 'LS', 2001, '$75055.88');
insert into car (manufacturer, model, model_year, price) values ('Lincoln', 'Aviator', 2004, '$72422.86');
insert into car (manufacturer, model, model_year, price) values ('Nissan', 'Sentra', 2001, '$163563.35');
insert into car (manufacturer, model, model_year, price) values ('Mercury', 'Mariner', 2007, '$182328.11');
insert into car (manufacturer, model, model_year, price) values ('GMC', 'Sonoma Club Coupe', 1995, '$163808.55');
insert into car (manufacturer, model, model_year, price) values ('Volkswagen', 'Jetta', 1996, '$48741.54');
insert into car (manufacturer, model, model_year, price) values ('Ford', 'Taurus', 2000, '$115675.44');
insert into car (manufacturer, model, model_year, price) values ('Toyota', 'Tundra', 2012, '$69111.16');
insert into car (manufacturer, model, model_year, price) values ('Ford', 'Club Wagon', 1992, '$105368.90');
insert into car (manufacturer, model, model_year, price) values ('Mercury', 'Milan', 2006, '$37566.16');
insert into car (manufacturer, model, model_year, price) values ('Volvo', 'XC70', 2005, '$98231.03');
insert into car (manufacturer, model, model_year, price) values ('Cadillac', 'Escalade EXT', 2004, '$49731.38');
insert into car (manufacturer, model, model_year, price) values ('Pontiac', 'Grand Am', 1992, '$134044.09');
insert into car (manufacturer, model, model_year, price) values ('Mercury', 'Cougar', 1987, '$140787.89');
insert into car (manufacturer, model, model_year, price) values ('Volvo', 'V70', 2003, '$133642.19');
insert into car (manufacturer, model, model_year, price) values ('Mazda', 'MX-5', 2001, '$163040.74');
insert into car (manufacturer, model, model_year, price) values ('Dodge', 'Ram Van 2500', 1999, '$167300.94');
insert into car (manufacturer, model, model_year, price) values ('Lexus', 'HS', 2010, '$69526.42');
insert into car (manufacturer, model, model_year, price) values ('Land Rover', 'Range Rover Sport', 2010, '$127368.24');
insert into car (manufacturer, model, model_year, price) values ('Nissan', 'Sentra', 2008, '$63757.17');
insert into car (manufacturer, model, model_year, price) values ('Mercury', 'Grand Marquis', 1997, '$115190.04');
insert into car (manufacturer, model, model_year, price) values ('Toyota', 'Camry', 2004, '$131267.23');
insert into car (manufacturer, model, model_year, price) values ('Ford', 'Probe', 1992, '$127716.59');
insert into car (manufacturer, model, model_year, price) values ('Ford', 'F-Series', 2009, '$111358.85');
insert into car (manufacturer, model, model_year, price) values ('Audi', 'A6', 1998, '$154245.35');
insert into car (manufacturer, model, model_year, price) values ('Mitsubishi', 'Chariot', 1994, '$145498.89');
insert into car (manufacturer, model, model_year, price) values ('Chevrolet', 'Caprice Classic', 1993, '$111421.73');
insert into car (manufacturer, model, model_year, price) values ('Ferrari', 'F430', 2008, '$49494.30');
insert into car (manufacturer, model, model_year, price) values ('Land Rover', 'Range Rover Sport', 2011, '$93330.25');
insert into car (manufacturer, model, model_year, price) values ('Nissan', 'Rogue', 2011, '$32512.95');
insert into car (manufacturer, model, model_year, price) values ('Eagle', 'Vision', 1996, '$115940.58');
insert into car (manufacturer, model, model_year, price) values ('Lexus', 'LS', 2001, '$80774.62');
insert into car (manufacturer, model, model_year, price) values ('Chevrolet', 'Corvette', 1955, '$96840.72');
insert into car (manufacturer, model, model_year, price) values ('Buick', 'Park Avenue', 1991, '$66873.65');
insert into car (manufacturer, model, model_year, price) values ('Nissan', 'Pathfinder', 1994, '$191221.35');
insert into car (manufacturer, model, model_year, price) values ('Buick', 'Rendezvous', 2004, '$80398.56');
insert into car (manufacturer, model, model_year, price) values ('Porsche', 'Boxster', 2011, '$163524.33');
insert into car (manufacturer, model, model_year, price) values ('Chrysler', 'Town & Country', 1992, '$195019.53');
insert into car (manufacturer, model, model_year, price) values ('Land Rover', 'Discovery', 2007, '$197927.64');
insert into car (manufacturer, model, model_year, price) values ('Honda', 'Prelude', 1998, '$100294.78');
insert into car (manufacturer, model, model_year, price) values ('Acura', 'RDX', 2007, '$68288.11');
insert into car (manufacturer, model, model_year, price) values ('Ford', 'F350', 2012, '$45927.69');
insert into car (manufacturer, model, model_year, price) values ('GMC', 'Savana 2500', 2012, '$138924.94');
insert into car (manufacturer, model, model_year, price) values ('Land Rover', 'LR3', 2009, '$171629.76');
insert into car (manufacturer, model, model_year, price) values ('Cadillac', 'Escalade', 2006, '$96222.59');
insert into car (manufacturer, model, model_year, price) values ('Mercedes-Benz', 'M-Class', 2007, '$65710.54');
insert into car (manufacturer, model, model_year, price) values ('Chevrolet', 'Silverado 3500', 2006, '$105708.86');
insert into car (manufacturer, model, model_year, price) values ('Chevrolet', 'Monte Carlo', 2001, '$65358.29');
insert into car (manufacturer, model, model_year, price) values ('Mercedes-Benz', 'SL-Class', 2007, '$155172.17');
insert into car (manufacturer, model, model_year, price) values ('Pontiac', 'Vibe', 2010, '$36757.18');
insert into car (manufacturer, model, model_year, price) values ('BMW', 'X6', 2012, '$61112.58');
insert into car (manufacturer, model, model_year, price) values ('Toyota', 'Camry', 2003, '$136781.68');
insert into car (manufacturer, model, model_year, price) values ('Ford', 'E-Series', 2010, '$161586.78');
insert into car (manufacturer, model, model_year, price) values ('Buick', 'Electra', 1988, '$123986.65');
insert into car (manufacturer, model, model_year, price) values ('Audi', 'Allroad', 2003, '$162227.92');
insert into car (manufacturer, model, model_year, price) values ('Buick', 'Skylark', 1996, '$190211.99');
insert into car (manufacturer, model, model_year, price) values ('Buick', 'Reatta', 1990, '$122859.71');
insert into car (manufacturer, model, model_year, price) values ('Buick', 'LaCrosse', 2005, '$194362.61');
insert into car (manufacturer, model, model_year, price) values ('Volkswagen', 'Passat', 1987, '$44744.72');
insert into car (manufacturer, model, model_year, price) values ('Toyota', 'Land Cruiser', 2007, '$181658.61');
insert into car (manufacturer, model, model_year, price) values ('Mercury', 'Lynx', 1984, '$198168.58');
insert into car (manufacturer, model, model_year, price) values ('Chevrolet', 'Aveo', 2011, '$119040.47');
insert into car (manufacturer, model, model_year, price) values ('Daewoo', 'Nubira', 2000, '$131485.05');
insert into car (manufacturer, model, model_year, price) values ('GMC', 'Savana 3500', 2004, '$134947.19');
insert into car (manufacturer, model, model_year, price) values ('Mitsubishi', 'Eclipse', 1995, '$105043.33');
insert into car (manufacturer, model, model_year, price) values ('Ford', 'F150', 2003, '$47311.90');
insert into car (manufacturer, model, model_year, price) values ('Oldsmobile', '88', 1994, '$159306.61');
insert into car (manufacturer, model, model_year, price) values ('Honda', 'Ridgeline', 2008, '$30690.39');
insert into car (manufacturer, model, model_year, price) values ('Subaru', 'Legacy', 2011, '$78809.82');
insert into car (manufacturer, model, model_year, price) values ('Mercedes-Benz', 'E-Class', 1993, '$52834.71');
insert into car (manufacturer, model, model_year, price) values ('Ford', 'Bronco', 1985, '$144882.15');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO own
SELECT student_id, manufacturer, model, model_year
FROM alumni, car
ORDER BY RANDOM() 
LIMIT 1000;
