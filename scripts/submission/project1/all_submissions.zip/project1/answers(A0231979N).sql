/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data / STUDENT NUMBER : A0231979N                       */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
	The case is about what different bakers bake (many-to-many relationship). For instance it will help users know if the product wanted is available at a specific bakery shop
	Therefore, the entity set E1 is baker, R is defined as a many-to-many relationship 'bake'.
	The entity set E2 represents the different products  usually found in bakery.
	
	The first table (entity E1) will comprise an id, first name, family name, gender, country, address of the baker, postal code
	The second table (R relation) will comprise the id of the baker and the id of the product
	The third table (entity E2) will comprise the id, name of the product
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE bakers (
	baker_id serial PRIMARY KEY,
	first_name VARCHAR ( 50 )  NOT NULL,
	last_name VARCHAR ( 50 )  NOT NULL,
	gender VARCHAR ( 50 )  NOT NULL,
	country VARCHAR ( 255 )  NOT NULL,
	address VARCHAR ( 255 )  NOT NULL,
	postal_code VARCHAR(50) 
);

CREATE TABLE bake (
	baker_id serial NOT NULL,
	product_id serial NOT NULL,
	CONSTRAINT relation PRIMARY KEY (baker_id,product_id)
);

CREATE TABLE products (
	product_id serial PRIMARY KEY,
	product_name VARCHAR ( 255 )  NOT NULL
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (1, 'Gail', 'Varndell', 'Genderfluid', 'Nigeria', '30 Maryland Junction', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (2, 'Tiebold', 'Abrey', 'Non-binary', 'Serbia', '09 Dennis Court', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (3, 'Sharl', 'Poulett', 'Bigender', 'China', '38 Stephen Crossing', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (4, 'Decca', 'Poulton', 'Genderfluid', 'Libya', '80834 Knutson Drive', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (5, 'Winni', 'Caplan', 'Non-binary', 'Indonesia', '3403 Erie Court', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (6, 'Jeffrey', 'Eyckel', 'Genderqueer', 'China', '9277 Grayhawk Crossing', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (7, 'Dina', 'Clifton', 'Bigender', 'Russia', '9287 Bunker Hill Lane', '659607');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (8, 'Paulette', 'Lippi', 'Female', 'Canada', '3902 Thierer Center', 'E3G');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (9, 'Christy', 'Bagenal', 'Bigender', 'Colombia', '2 Parkside Street', '705039');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (10, 'Audrie', 'Saltsberger', 'Genderfluid', 'Benin', '551 Spohn Avenue', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (11, 'Melanie', 'Stainbridge', 'Genderfluid', 'China', '633 Armistice Avenue', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (12, 'Darbee', 'Strowlger', 'Agender', 'France', '5 Hallows Alley', '44265 CEDEX 2');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (13, 'Elysee', 'Tichner', 'Polygender', 'China', '2854 Sachtjen Way', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (14, 'Rubin', 'Scurlock', 'Genderfluid', 'Madagascar', '07 Mockingbird Park', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (15, 'Benetta', 'Denver', 'Non-binary', 'China', '46335 Toban Avenue', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (16, 'Hedi', 'Rupert', 'Genderqueer', 'Bosnia and Herzegovina', '8449 Anniversary Lane', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (17, 'Aurlie', 'McGerraghty', 'Non-binary', 'Japan', '258 Gulseth Terrace', '289-0313');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (18, 'Hedwig', 'Powis', 'Non-binary', 'Zimbabwe', '93483 Melody Street', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (19, 'Talbot', 'Yakebovich', 'Female', 'Botswana', '22 Homewood Hill', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (20, 'Barby', 'Hopkynson', 'Agender', 'China', '765 Moose Lane', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (21, 'Pamelina', 'Horsefield', 'Genderqueer', 'Colombia', '0 Bluejay Lane', '202058');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (22, 'Alwin', 'Blazevic', 'Male', 'Czech Republic', '64 Barnett Road', '350 02');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (23, 'Brandy', 'Feaster', 'Genderfluid', 'United States', '94 Hoepker Terrace', '66617');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (24, 'Robina', 'Thebe', 'Genderqueer', 'Comoros', '6783 Onsgard Street', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (25, 'Cad', 'Thicking', 'Bigender', 'Nicaragua', '3460 Spaight Circle', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (26, 'Virgilio', 'Skaif', 'Genderqueer', 'Spain', '2 Claremont Park', '38110');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (27, 'Jared', 'Badsworth', 'Bigender', 'Philippines', '04 Westend Pass', '1110');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (28, 'Jaquenette', 'Hyett', 'Agender', 'Indonesia', '73 Eagle Crest Pass', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (29, 'Fedora', 'Stainland', 'Agender', 'Indonesia', '70949 Luster Parkway', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (30, 'Daniel', 'Karlolak', 'Non-binary', 'Indonesia', '57250 Debra Terrace', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (31, 'Hope', 'Wetter', 'Female', 'China', '66446 Dunning Place', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (32, 'Barbara', 'Gilbane', 'Polygender', 'United States', '31 Debra Court', '81505');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (33, 'Courtnay', 'Palister', 'Male', 'Canada', '15 Thompson Lane', 'L2N');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (34, 'Abram', 'Anselmi', 'Non-binary', 'Sweden', '626 Fordem Court', '613 38');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (35, 'Jenifer', 'Deeble', 'Male', 'Panama', '362 Scott Avenue', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (36, 'Simonette', 'Mennear', 'Non-binary', 'Indonesia', '4 Monterey Road', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (37, 'Joshia', 'Tessington', 'Genderfluid', 'Estonia', '8 Montana Crossing', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (38, 'Loralee', 'Dakhno', 'Genderfluid', 'Namibia', '82222 Cordelia Trail', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (39, 'Rufus', 'Sor', 'Female', 'Mauritius', '18 Elgar Road', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (40, 'Chauncey', 'Hinksen', 'Male', 'Indonesia', '4 Tony Avenue', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (41, 'Herculie', 'Hemphrey', 'Genderqueer', 'Afghanistan', '2 Kenwood Point', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (42, 'Yanaton', 'Smeall', 'Non-binary', 'Madagascar', '70 Continental Drive', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (43, 'Bear', 'Commings', 'Genderqueer', 'Finland', '8440 Moulton Park', '47520');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (44, 'Aila', 'McKerlie', 'Genderfluid', 'China', '32254 Glacier Hill Pass', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (45, 'Sullivan', 'Abrahamsson', 'Non-binary', 'China', '4585 Logan Lane', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (46, 'Stace', 'Siddons', 'Genderfluid', 'Portugal', '3253 Westend Center', '4950-830');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (47, 'April', 'Durrell', 'Genderqueer', 'China', '9284 Graceland Trail', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (48, 'Korella', 'Dagon', 'Genderfluid', 'Philippines', '7486 Ramsey Avenue', '2566');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (49, 'Lyda', 'Austins', 'Agender', 'Portugal', '7523 Fairview Street', '4830-791');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (50, 'Pierette', 'Neaves', 'Polygender', 'China', '07119 Maple Wood Plaza', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (51, 'Berne', 'Nare', 'Bigender', 'Brazil', '928 Bowman Hill', '14620-000');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (52, 'Salvatore', 'Patshull', 'Genderfluid', 'Kosovo', '31 Ruskin Terrace', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (53, 'Cammy', 'Selly', 'Non-binary', 'Iran', '55 Waywood Road', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (54, 'Emmit', 'MacConnel', 'Bigender', 'China', '3 Sachtjen Lane', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (55, 'Camille', 'Ovesen', 'Bigender', 'China', '727 Gerald Terrace', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (56, 'Wynny', 'Gerretsen', 'Polygender', 'China', '0047 Shasta Terrace', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (57, 'Les', 'O''Gaven', 'Agender', 'China', '29 Forest Dale Point', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (58, 'Coraline', 'Hollyman', 'Female', 'Argentina', '4751 Tony Alley', '8316');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (59, 'Hadley', 'Pykett', 'Bigender', 'China', '0 Jenifer Hill', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (60, 'Bron', 'Arnout', 'Bigender', 'China', '7404 Tony Court', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (61, 'Rupert', 'Pietzner', 'Bigender', 'Venezuela', '6588 Dwight Parkway', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (62, 'Darice', 'Copins', 'Agender', 'France', '3 Hauk Drive', '92885 CEDEX 9');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (63, 'Anneliese', 'Beamont', 'Bigender', 'Philippines', '7 2nd Way', '4023');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (64, 'Ernst', 'Chicco', 'Male', 'Poland', '9 Hallows Pass', '46-320');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (65, 'Annamarie', 'Scardifeild', 'Agender', 'Poland', '5 Sutherland Park', '66-008');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (66, 'Beverley', 'Wesley', 'Agender', 'South Africa', '0 Norway Maple Road', '4492');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (67, 'Aubry', 'Dallicoat', 'Genderfluid', 'Philippines', '4021 Ronald Regan Way', '2305');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (68, 'Alisander', 'O''Hartigan', 'Male', 'Philippines', '5694 Truax Street', '1255');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (69, 'Gwenni', 'Moens', 'Female', 'Botswana', '67 Golden Leaf Terrace', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (70, 'Gustie', 'Hardie', 'Agender', 'Philippines', '73 8th Place', '1380');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (71, 'Gustave', 'Paaso', 'Female', 'Russia', '5999 Helena Court', '186806');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (72, 'Mychal', 'Goose', 'Female', 'Japan', '12722 Shasta Avenue', '861-0133');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (73, 'Alaster', 'Colton', 'Polygender', 'Russia', '867 Melody Plaza', '150501');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (74, 'Lavena', 'Jelf', 'Agender', 'Indonesia', '29469 Dayton Terrace', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (75, 'Ursola', 'Colcomb', 'Non-binary', 'Serbia', '2173 Cody Pass', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (76, 'Carolan', 'Francescozzi', 'Bigender', 'Lithuania', '18622 Canary Road', '41062');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (77, 'Antin', 'Deveral', 'Male', 'China', '5206 Old Shore Hill', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (78, 'Lotte', 'O''Shevlin', 'Female', 'Russia', '1 Golf Park', '394077');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (79, 'Susette', 'Deane', 'Bigender', 'France', '20893 Goodland Point', '93591 CEDEX');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (80, 'Marnia', 'Pretsell', 'Bigender', 'China', '5 Norway Maple Place', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (81, 'Moss', 'Kisar', 'Male', 'Bulgaria', '3129 Forest Dale Drive', '2680');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (82, 'Christen', 'Milmore', 'Female', 'Philippines', '2203 Northport Pass', '6820');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (83, 'Ruthe', 'Oldknowe', 'Bigender', 'Poland', '3169 Debs Point', '96-130');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (84, 'Daile', 'Meo', 'Bigender', 'China', '0 Packers Road', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (85, 'Muffin', 'Adolfson', 'Agender', 'Iraq', '36 Troy Park', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (86, 'Horatius', 'Basili', 'Agender', 'Indonesia', '12177 Dixon Circle', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (87, 'Neddie', 'Vedikhov', 'Bigender', 'China', '69 Meadow Valley Drive', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (88, 'Leigh', 'Morton', 'Female', 'China', '41534 Towne Pass', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (89, 'Dynah', 'Flye', 'Male', 'China', '09270 Mayer Plaza', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (90, 'Israel', 'Jacquemard', 'Agender', 'Pakistan', '42067 Burning Wood Park', '58031');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (91, 'Federico', 'Peepall', 'Polygender', 'Peru', '97690 Aberg Circle', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (92, 'Ebenezer', 'Jelleman', 'Agender', 'Syria', '66013 Bobwhite Parkway', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (93, 'Finn', 'Linklet', 'Male', 'China', '3409 Nancy Street', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (94, 'Dael', 'Litchmore', 'Female', 'Saudi Arabia', '12992 Magdeline Trail', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (95, 'Holly', 'Ernke', 'Bigender', 'Indonesia', '600 Canary Alley', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (96, 'Anjela', 'Gaule', 'Bigender', 'China', '160 Reindahl Alley', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (97, 'Juli', 'Oughtright', 'Non-binary', 'China', '0517 Esch Junction', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (98, 'Ivory', 'Pankhurst.', 'Bigender', 'Libya', '84 Mendota Court', null);
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (99, 'Dewitt', 'Di Ruggero', 'Female', 'Malaysia', '12878 Delaware Terrace', '79503');
insert into bakers (baker_id, first_name, last_name, gender, country, address, postal_code) values (100, 'Concordia', 'Beddis', 'Polygender', 'Japan', '8892 Gulseth Avenue', '904-0116');

insert into products (product_id, product_name) values (1, 'Scandinavian');
insert into products (product_id, product_name) values (2, 'Hot chocolate');
insert into products (product_id, product_name) values (3, 'Jam');
insert into products (product_id, product_name) values (4, 'Cookies');
insert into products (product_id, product_name) values (5, 'Muffin');
insert into products (product_id, product_name) values (6, 'Coffee');
insert into products (product_id, product_name) values (7, 'Pastry');
insert into products (product_id, product_name) values (8, 'Medialuna');
insert into products (product_id, product_name) values (9, 'Tea');
insert into products (product_id, product_name) values (10, 'NONE');
insert into products (product_id, product_name) values (11, 'Tartine');
insert into products (product_id, product_name) values (12, 'Basket');
insert into products (product_id, product_name) values (13, 'Mineral water');
insert into products (product_id, product_name) values (14, 'Farm House');
insert into products (product_id, product_name) values (15, 'Fudge');
insert into products (product_id, product_name) values (16, 'Juice');
insert into products (product_id, product_name) values (17, 'Ellas Kitchen Pouches');
insert into products (product_id, product_name) values (18, 'Victorian Sponge');
insert into products (product_id, product_name) values (19, 'Frittata');
insert into products (product_id, product_name) values (20, 'Hearty & Seasonal');
insert into products (product_id, product_name) values (21, 'Soup');
insert into products (product_id, product_name) values (22, 'Pick and Mix Bowls');
insert into products (product_id, product_name) values (23, 'Smoothies');
insert into products (product_id, product_name) values (24, 'Cake');
insert into products (product_id, product_name) values (25, 'Mighty Protein');
insert into products (product_id, product_name) values (26, 'Chicken sand');
insert into products (product_id, product_name) values (27, 'Coke');
insert into products (product_id, product_name) values (28, 'My-5 Fruit Shoot');
insert into products (product_id, product_name) values (29, 'Focaccia');
insert into products (product_id, product_name) values (30, 'Sandwich');
insert into products (product_id, product_name) values (31, 'Alfajores');
insert into products (product_id, product_name) values (32, 'Eggs');
insert into products (product_id, product_name) values (33, 'Brownie');
insert into products (product_id, product_name) values (34, 'Dulce de Leche');
insert into products (product_id, product_name) values (35, 'Honey');
insert into products (product_id, product_name) values (36, 'The BART');
insert into products (product_id, product_name) values (37, 'Granola');
insert into products (product_id, product_name) values (38, 'Fairy Doors');
insert into products (product_id, product_name) values (39, 'Empanadas');
insert into products (product_id, product_name) values (40, 'Keeping It Local');
insert into products (product_id, product_name) values (41, 'Art Tray');
insert into products (product_id, product_name) values (42, 'Bowl Nic Pitt');
insert into products (product_id, product_name) values (43, 'Bread Pudding');
insert into products (product_id, product_name) values (44, 'Adjustment');
insert into products (product_id, product_name) values (45, 'Truffles');
insert into products (product_id, product_name) values (46, 'Chimichurri Oil');
insert into products (product_id, product_name) values (47, 'Bacon');
insert into products (product_id, product_name) values (48, 'Spread');
insert into products (product_id, product_name) values (49, 'Kids biscuit');
insert into products (product_id, product_name) values (50, 'Siblings');
insert into products (product_id, product_name) values (51, 'Caramel bites');
insert into products (product_id, product_name) values (52, 'Jammie Dodgers');
insert into products (product_id, product_name) values (53, 'Tiffin');
insert into products (product_id, product_name) values (54, 'Olum & polenta');
insert into products (product_id, product_name) values (55, 'Polenta');
insert into products (product_id, product_name) values (56, 'The Nomad');
insert into products (product_id, product_name) values (57, 'Hack the stack');
insert into products (product_id, product_name) values (58, 'Bakewell');
insert into products (product_id, product_name) values (59, 'Lemon and coconut');
insert into products (product_id, product_name) values (60, 'Toast');
insert into products (product_id, product_name) values (61, 'Scone');
insert into products (product_id, product_name) values (62, 'Crepes');
insert into products (product_id, product_name) values (63, 'Vegan mincepie');
insert into products (product_id, product_name) values (64, 'Bare Popcorn');
insert into products (product_id, product_name) values (65, 'Muesli');
insert into products (product_id, product_name) values (66, 'Crisps');
insert into products (product_id, product_name) values (67, 'Pintxos');
insert into products (product_id, product_name) values (68, 'Gingerbread syrup');
insert into products (product_id, product_name) values (69, 'Panatone');
insert into products (product_id, product_name) values (70, 'Brioche and salami');
insert into products (product_id, product_name) values (71, 'Afternoon with the baker');
insert into products (product_id, product_name) values (72, 'Salad');
insert into products (product_id, product_name) values (73, 'Chicken Stew');
insert into products (product_id, product_name) values (74, 'Spanish Brunch');
insert into products (product_id, product_name) values (75, 'Raspberry shortbread sandwich');
insert into products (product_id, product_name) values (76, 'Extra Salami or Feta');
insert into products (product_id, product_name) values (77, 'Duck egg');
insert into products (product_id, product_name) values (78, 'Baguette');
insert into products (product_id, product_name) values (79, 'Valentines card');
insert into products (product_id, product_name) values (80, 'Tshirt');
insert into products (product_id, product_name) values (81, 'Vegan Feast');
insert into products (product_id, product_name) values (82, 'Postcard');
insert into products (product_id, product_name) values (83, 'Bread');
insert into products (product_id, product_name) values (84, 'Chocolates');
insert into products (product_id, product_name) values (85, 'Coffee granules');
insert into products (product_id, product_name) values (86, 'Drinking chocolate spoons');
insert into products (product_id, product_name) values (87, 'Christmas common');
insert into products (product_id, product_name) values (88, 'Argentina Night');
insert into products (product_id, product_name) values (89, 'Half slice Monster');
insert into products (product_id, product_name) values (90, 'Gift voucher');
insert into products (product_id, product_name) values (91, 'Cherry me Dried fruit');
insert into products (product_id, product_name) values (92, 'Mortimer');
insert into products (product_id, product_name) values (93, 'Raw bars');
insert into products (product_id, product_name) values (94, 'Tacos/Fajita');
insert into products (product_id, product_name) values (95, 'Opera Cake');
insert into products (product_id, product_name) values (96, 'Banana');
insert into products (product_id, product_name) values (97, 'Croissant');
insert into products (product_id, product_name) values (98, 'Apple Pie');
insert into products (product_id, product_name) values (99, 'Strawberry Pie');
insert into products (product_id, product_name) values (100, 'Almond Pie');



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into bake (baker_id, product_id) 
SELECT DISTINCT round(1+random()*99), round(1+random()*99) from generate_series(1,1000);