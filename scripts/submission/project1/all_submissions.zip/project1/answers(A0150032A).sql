/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The  chosen example simulates the database used to monitor the Illegal Wildlife Trade.

It is contains information regarding:
(i) status of Wildlife - the conservation status of the animal
(ii) trafficking suspects - the details of suspected traffickers
(iii) trafficking transactions - the illegal transactions that have been traced

It contains 3 tables: 
(i) Species Watchlist 
- this describes the list of animal species under surveillance for Wildlife Trade
Attribute 1: [Conservation Status] Conservation Status of an animal e.g. "Vulnerable", "Endangered"
Attribute 2: [Common Name] Common name of the animal e.g. "Indian Leopard", "American badger"
Attribute 3: [Scientific Name] Scientific name of the animal e.g. "Aquila chrysaetos", "Taxidea taxus"
Attribute 4: [Image] URL containing images of a given animal e.g. "http://dummyimage.com/231x114.png/5fa2dd/ffffff"

(ii) Suspect Watchlist
- this describes the watchlist of suspects involved in the Illegal Wildlife Trafficking
Attribute 1: [Track_Id] Unique Tracking Id to tag each suspect e.g. "03-1350731"
Attribute 2: [First Name] The first name of the suspect e.g. "Océane"
Attribute 3: [Last Name] The last name of the suspect e.g. "Fardell"
Attribute 4: [Gender] The gender of the suspect e.g. "M", "F"
Attribute 5: [Country of Residence] The country of residence of the suspect e.g. "CN", "ID", "FR"
Attribute 6: [Traced Account] The banking account of the suspect associated with the illegal transaction e.g. "DK90 3505 5586 3656 13"
Attribute 7: [Investigation Status] The investigation status on the suspect e.g. "Open", "In-Progress", "Closed"

(iii) Trafficking Transactions
- this describes the transaction undertaken by a suspect
Attribute 1: [Transaction_Id] Unique Transaction Id to tag each transaction e.g. "1473"
Attribute 2: [Trafficked_Species] Common name of the animal trafficked e.g. "Indian Leopard", "American badger"
Attribute 3: [Seller_Account] The banking account of the suspect associated with the illegal transaction e.g. "DK90 3505 5586 3656 13"
Attribute 4: [Currency] The currency of the transaction e.g. "AUD", "USD"
Attribute 5: [Transaction_Date] The date of the transaction e.g. 2021-08-20
Measure 1: [Transaction_Value] Monetary Value of the transaction e.g. 34, 100

An animal or A suspect may be involved in multiple transactions.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

create table Species_Watchlist (
	Conservation_Status VARCHAR(21) NOT NULL,
	Common_Name VARCHAR(50) PRIMARY KEY,
	Scientific_Name VARCHAR(50) NOT NULL,
	Image VARCHAR(50) NOT NULL
);

create table Suspect_Watchlist (
	Track_Id VARCHAR(50) PRIMARY KEY,
	First_Name VARCHAR(50),
	Last_Name VARCHAR(50),
	Gender VARCHAR(50),
	Residence_Country VARCHAR(50),
	Traced_Account VARCHAR(50) UNIQUE NOT NULL,
	Investigation_Status VARCHAR(11) NOT NULL
);

create table Trafficking_Transaction (
	Transaction_Id VARCHAR(50) PRIMARY KEY,
	Trafficked_Species VARCHAR(50) NOT NULL,
	Seller_Account VARCHAR(50) NOT NULL,
	Currency VARCHAR(50) NOT NULL,
	Transaction_Value INT CHECK (Transaction_Value >= 0),
	Transaction_Date DATE CHECK (Transaction_Date > '1999-12-31'),
	FOREIGN KEY (Trafficked_Species) REFERENCES species_watchlist(Common_Name),
	FOREIGN KEY (Seller_Account) REFERENCES suspect_watchlist(Traced_Account)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* Insert into Species Watchlist Table */
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Laughing kookaburra', 'Dacelo novaeguineae', 'http://dummyimage.com/245x236.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Indian leopard', 'Panthera pardus', 'http://dummyimage.com/142x143.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Adouri (unidentified)', 'unavailable', 'http://dummyimage.com/220x212.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Gulls (unidentified)', 'Larus sp.', 'http://dummyimage.com/158x147.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Goliath heron', 'Ardea golieth', 'http://dummyimage.com/209x203.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Jackal, asiatic', 'Canis aureus', 'http://dummyimage.com/170x220.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Lion, african', 'Panthera leo', 'http://dummyimage.com/193x217.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Long-crested hawk eagle', 'Lophoaetus occipitalis', 'http://dummyimage.com/135x241.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Brush-tailed phascogale', 'Phascogale tapoatafa', 'http://dummyimage.com/155x137.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Aardwolf', 'Proteles cristatus', 'http://dummyimage.com/114x192.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Heron, grey', 'Ardea cinerea', 'http://dummyimage.com/169x216.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Beaver, american', 'Castor canadensis', 'http://dummyimage.com/153x112.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Red-capped cardinal', 'Paroaria gularis', 'http://dummyimage.com/175x224.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Tern, white-winged', 'Chlidonias leucopterus', 'http://dummyimage.com/113x228.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Duiker, gray', 'Sylvicapra grimma', 'http://dummyimage.com/121x247.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Sloth, pale-throated three-toed', 'Bradypus tridactylus', 'http://dummyimage.com/140x102.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Rat, white-faced tree', 'Echimys chrysurus', 'http://dummyimage.com/231x169.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Long-tailed skua', 'Stercorarius longicausus', 'http://dummyimage.com/148x225.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Heron, black-crowned night', 'Nycticorax nycticorax', 'http://dummyimage.com/166x152.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Coqui partridge', 'Francolinus coqui', 'http://dummyimage.com/215x121.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Wapiti, elk,', 'Cervus canadensis', 'http://dummyimage.com/154x201.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Bear, polar', 'Ursus maritimus', 'http://dummyimage.com/197x174.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Moorhen, purple', 'Porphyrio porphyrio', 'http://dummyimage.com/227x143.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Malay squirrel (unidentified)', 'unavailable', 'http://dummyimage.com/228x174.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Wambenger, red-tailed', 'Phascogale calura', 'http://dummyimage.com/235x238.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Ring-tailed lemur', 'Lemur catta', 'http://dummyimage.com/166x248.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Hottentot teal', 'Anas punctata', 'http://dummyimage.com/166x150.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Vulture, white-headed', 'Aegypius occipitalis', 'http://dummyimage.com/164x239.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Flicker, field', 'Colaptes campestroides', 'http://dummyimage.com/175x233.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'European stork', 'Ciconia ciconia', 'http://dummyimage.com/168x104.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Striated heron', 'Butorides striatus', 'http://dummyimage.com/231x120.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Crab-eating raccoon', 'Procyon cancrivorus', 'http://dummyimage.com/237x184.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Stanley crane', 'Anthropoides paradisea', 'http://dummyimage.com/249x200.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Hawk-headed parrot', 'Deroptyus accipitrinus', 'http://dummyimage.com/138x199.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Cape clawless otter', 'Aonyx capensis', 'http://dummyimage.com/199x164.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Guanaco', 'Lama guanicoe', 'http://dummyimage.com/174x107.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Vulture, king', 'Sarcorhamphus papa', 'http://dummyimage.com/108x146.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Seal, northern elephant', 'Mirounga angustirostris', 'http://dummyimage.com/106x137.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Asian elephant', 'Elephas maximus bengalensis', 'http://dummyimage.com/175x109.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Bear, grizzly', 'Ursus arctos', 'http://dummyimage.com/175x152.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Southern brown bandicoot', 'Isoodon obesulus', 'http://dummyimage.com/131x125.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Gerenuk', 'Litrocranius walleri', 'http://dummyimage.com/142x104.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Civet (unidentified)', 'unavailable', 'http://dummyimage.com/242x240.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Cormorant, large', 'Phalacrocorax carbo', 'http://dummyimage.com/246x192.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Red-tailed wambenger', 'Phascogale calura', 'http://dummyimage.com/183x194.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Steenbok', 'Raphicerus campestris', 'http://dummyimage.com/141x213.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Black-tailed deer', 'Odocoileus hemionus', 'http://dummyimage.com/117x192.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'White-necked stork', 'Ciconia episcopus', 'http://dummyimage.com/247x154.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Black-winged stilt', 'Himantopus himantopus', 'http://dummyimage.com/169x164.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Kongoni', 'Alcelaphus buselaphus cokii', 'http://dummyimage.com/184x138.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Crane, brolga', 'Grus rubicundus', 'http://dummyimage.com/140x169.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Hoopoe, eurasian', 'Upupa epops', 'http://dummyimage.com/108x151.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Badger, honey', 'Mellivora capensis', 'http://dummyimage.com/156x249.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Roseat flamingo', 'Phoenicopterus ruber', 'http://dummyimage.com/196x182.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Hyena, striped', 'Hyaena hyaena', 'http://dummyimage.com/164x116.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Nine-banded armadillo', 'Dasypus novemcinctus', 'http://dummyimage.com/194x127.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Koala', 'Phascolarctos cinereus', 'http://dummyimage.com/166x159.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Water moccasin', 'Agkistrodon piscivorus', 'http://dummyimage.com/124x207.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Great horned owl', 'Bubo virginianus', 'http://dummyimage.com/217x208.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Opossum, american virginia', 'Didelphis virginiana', 'http://dummyimage.com/135x129.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Gazer, sun', 'Cordylus giganteus', 'http://dummyimage.com/238x231.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Slender-billed cockatoo', 'Cacatua tenuirostris', 'http://dummyimage.com/131x152.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Great white pelican', 'Pelecans onocratalus', 'http://dummyimage.com/139x250.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Tarantula', 'Lasiodora parahybana', 'http://dummyimage.com/119x121.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'American badger', 'Taxidea taxus', 'http://dummyimage.com/231x108.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Purple moorhen', 'Porphyrio porphyrio', 'http://dummyimage.com/168x151.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Little grebe', 'Tachybaptus ruficollis', 'http://dummyimage.com/184x231.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Coatimundi, white-nosed', 'Nasua narica', 'http://dummyimage.com/227x139.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Lynx, african', 'Felis caracal', 'http://dummyimage.com/222x245.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Turkey, wild', 'Meleagris gallopavo', 'http://dummyimage.com/101x199.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Fox, arctic', 'Alopex lagopus', 'http://dummyimage.com/217x123.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Stork, greater adjutant', 'Leptoptilus dubius', 'http://dummyimage.com/203x129.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Eagle, golden', 'Aquila chrysaetos', 'http://dummyimage.com/231x114.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Little blue penguin', 'Eudyptula minor', 'http://dummyimage.com/114x188.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Rufous tree pie', 'Dendrocitta vagabunda', 'http://dummyimage.com/250x148.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Nilgai', 'Boselaphus tragocamelus', 'http://dummyimage.com/200x108.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Sheep, american bighorn', 'Ovis canadensis', 'http://dummyimage.com/179x117.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Pigeon, feral rock', 'Columba livia', 'http://dummyimage.com/116x104.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Boa, cook''s tree', 'Corallus hortulanus cooki', 'http://dummyimage.com/186x249.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Red-tailed phascogale', 'Phascogale calura', 'http://dummyimage.com/217x210.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Extinct in Wild', 'Gray rhea', 'Rhea americana', 'http://dummyimage.com/172x107.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Emu', 'Dromaeus novaehollandiae', 'http://dummyimage.com/208x112.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Saddle-billed stork', 'Ephipplorhynchus senegalensis', 'http://dummyimage.com/163x184.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Emerald-spotted wood dove', 'Turtur chalcospilos', 'http://dummyimage.com/233x171.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Sparrow, house', 'Passer domesticus', 'http://dummyimage.com/143x125.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Macaw, red and blue', 'Ara chloroptera', 'http://dummyimage.com/202x188.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Onager', 'Equus hemionus', 'http://dummyimage.com/193x126.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Cockatoo, sulfur-crested', 'Cacatua galerita', 'http://dummyimage.com/119x115.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Lesser double-collared sunbird', 'Nectarinia chalybea', 'http://dummyimage.com/137x207.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Nyala', 'Tragelaphus angasi', 'http://dummyimage.com/214x205.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'King cormorant', 'Phalacrocorax albiventer', 'http://dummyimage.com/199x242.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Boa, columbian rainbow', 'Epicrates cenchria maurus', 'http://dummyimage.com/222x135.png/cc0000/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Springbok', 'Antidorcas marsupialis', 'http://dummyimage.com/152x143.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Critically Endangered', 'Penguin, magellanic', 'Spheniscus magellanicus', 'http://dummyimage.com/104x247.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Eastern cottontail rabbit', 'Sylvilagus floridanus', 'http://dummyimage.com/126x158.png/5fa2dd/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Elephant, asian', 'Elephas maximus bengalensis', 'http://dummyimage.com/114x246.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Desert tortoise', 'Gopherus agassizii', 'http://dummyimage.com/248x230.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Vulnerable', 'Meerkat', 'Suricata suricatta', 'http://dummyimage.com/129x211.png/ff4444/ffffff');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Cockatoo, long-billed', 'Cacatua tenuirostris', 'http://dummyimage.com/153x115.png/dddddd/000000');
insert into Species_Watchlist (Conservation_Status, Common_Name, Scientific_Name, Image) values ('Endangered', 'Vulture, black', 'Aegypius tracheliotus', 'http://dummyimage.com/126x233.png/5fa2dd/ffffff');

/* Insert into Suspect Watchlist Table */
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('83-5942032', 'Örjan', 'Verbeke', 'F', 'CD', 'FR98 0190 2326 58SU RCSR QYML 945', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('11-1658937', 'Thérèsa', 'Bonaire', 'M', 'ID', 'HU32 4949 2753 0467 4825 3001 5695', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('40-1191371', 'Laurène', 'Bruntjen', 'F', 'CN', 'HU02 1200 8659 7253 1544 6268 3246', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('49-1531586', 'Magdalène', 'Medcalf', 'F', 'SE', 'GE75 BD12 1601 9155 1962 06', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('23-7638917', 'Stévina', 'Gooder', 'F', 'AR', 'CY97 5121 5700 UUI7 H6UD EL5Y V44D', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('94-9659630', 'Liè', 'Fores', 'M', 'US', 'LB97 1692 YPJO KHNX USKO WAYF KISS', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('76-4603975', 'Gösta', 'Ganiclef', 'F', 'BR', 'IL49 9101 4818 7227 6033 544', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('36-5045984', 'Danièle', 'Kleinhausen', 'M', 'ID', 'MD13 MQ7U RCFA ND6O IUK9 GQZC', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('24-4758075', 'Stéphanie', 'Piatkow', 'F', 'CN', 'IL61 8874 2455 0466 7138 584', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('62-8967750', 'Léonore', 'Snufflebottom', 'F', 'ID', 'BH05 ZEKR NCKF NSVT FS50 TG', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('68-0752111', 'Estève', 'Gisbey', 'F', 'FR', 'FR08 5808 2947 72CL OOLP OYKW F49', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('35-6526006', 'Lyséa', 'Kleinberer', 'F', 'BR', 'FR68 4194 7019 99DR JNYB TGUB V20', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('17-4000310', 'Méng', 'Scriven', 'F', 'ID', 'CY74 6333 6981 GT9Y AAJC OPG0 GFPL', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('31-9919777', 'Chloé', 'Seabrocke', 'F', 'TH', 'AL67 5394 3894 8AEI 0YHQ CLYO UXDQ', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('73-8156860', 'Eliès', 'Taborre', 'F', 'ID', 'IE02 VTEZ 1220 6312 6740 25', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('80-0970605', 'Lén', 'Sydry', 'F', 'AL', 'KZ80 162G ZAUD IORQ DCCQ', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('21-4483303', 'Véronique', 'Maurice', 'F', 'PH', 'AZ35 MXJD DKMX GYBE LRKC UHLP LLL5', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('16-8433751', 'Noémie', 'Strase', 'F', 'PT', 'LV21 RNDM H4KV XVD9 EHIB J', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('15-8334959', 'Magdalène', 'Riccardelli', 'F', 'SE', 'MU20 ENZJ 0466 4667 8109 1637 105R ZH', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('25-7981032', 'Réservés', 'Dyet', 'M', 'TH', 'DO93 W7EL 8462 7677 5523 0160 7843', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('83-8426279', 'Miléna', 'Murra', 'F', 'CN', 'SE67 2179 2951 2185 4621 2518', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('36-0287144', 'Rachèle', 'Stother', 'F', 'CN', 'EE57 0725 7059 6543 1844', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('70-3804640', 'Océane', 'Bakhrushkin', 'F', 'CN', 'IL44 8045 2791 5894 2687 114', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('03-1350731', 'Pò', 'Mowsdale', 'F', 'CN', 'DK90 3505 5586 3656 13', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('45-1684944', 'Léana', 'Monger', 'F', 'FR', 'LB84 1994 XKHH INPR FBT7 BNVY BEFO', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('69-0127179', 'Mégane', 'Beavors', 'M', 'CN', 'FR46 1571 9552 40HD LTTJ TSUQ C50', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('37-7962857', 'Réservés', 'Gibbetts', 'M', 'CN', 'PS72 FRIC 91EE YHKI KQHL NVHM YJFG Z', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('10-8197987', 'Ophélie', 'Henzley', 'F', 'IR', 'FR85 5127 5798 92SY GE2M OK1B 922', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('07-6030137', 'Mélodie', 'Gloy', 'M', 'CN', 'SA31 630Q XBYD ZGBJ NROQ SFPN', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('92-4427967', 'Måns', 'Derington', 'M', 'CN', 'FR84 5382 9444 63SD Z2KB TJIC V70', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('11-5646988', 'Yóu', 'Ganniclifft', 'F', 'SI', 'SM10 S381 2370 304R FL18 JRCW XQG', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('80-8713004', 'Dù', 'Fardell', 'M', 'MM', 'MR68 3619 9203 8668 7738 2280 910', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('57-4162106', 'Maëly', 'MacAloren', 'M', 'RU', 'GT51 QR6T JFL6 XA6Z E6WZ WQUY EFAB', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('56-3577133', 'Marie-noël', 'Agostini', 'M', 'MX', 'SK28 7760 2413 4233 5374 2996', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('94-3970647', 'Desirée', 'Verdie', 'F', 'BR', 'IE44 LNXM 8569 8886 0831 34', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('32-5503366', 'Gaïa', 'Boarleyson', 'F', 'RU', 'MC94 1005 7020 506Q TSOB F6WN D96', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('68-2101411', 'Magdalène', 'Trenbay', 'M', 'CN', 'AZ91 XKRP CV2L 8N1I 4YFY 6ENY MBBX', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('78-2302640', 'Åsa', 'Ball', 'M', 'AR', 'DO63 BXLZ 4653 3876 8633 6737 9170', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('29-5334078', 'Méng', 'Ranby', 'F', 'PT', 'LV28 FBOH B2SK RGJO QQRM Q', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('40-9568712', 'Daphnée', 'Davidovicz', 'M', 'RU', 'MU28 VZEZ 8167 5316 8218 4004 288J VO', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('13-8533780', 'Clémence', 'Basnett', 'F', 'ID', 'FR06 5431 2293 13ID LNCG UNSK W78', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('93-8934161', 'Anaïs', 'Chadbourne', 'M', 'PH', 'SK03 3847 7368 9884 7544 6623', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('29-1471801', 'Léonie', 'Serjent', 'F', 'BY', 'FR04 4875 7199 04GP K4KX HOLQ U05', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('82-6386397', 'Ophélie', 'Trusty', 'F', 'TZ', 'NO23 1441 2580 502', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('83-3734124', 'Michèle', 'Petracci', 'M', 'ID', 'GB47 SJKP 6072 2970 5241 56', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('27-6320447', 'Marie-ève', 'Levings', 'M', 'PH', 'RO04 FFKY ULDP SVTG JK8E RFSL', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('99-7701551', 'Frédérique', 'Broader', 'F', 'ID', 'LT16 6742 7862 0721 8892', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('91-1443036', 'Annotés', 'Ivantsov', 'M', 'MX', 'SI36 5449 2339 6254 873', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('06-1046080', 'Maïly', 'Boman', 'M', 'PH', 'BR76 0564 7442 2110 5556 4273 580K J', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('54-3735526', 'Yáo', 'Gullyes', 'M', 'CN', 'AE62 8358 3506 1443 9294 680', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('11-3806615', 'Mahélie', 'Heningham', 'F', 'CN', 'GT46 03WB XNGI 15L4 63TB MPD0 H0AD', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('72-3138005', 'Maëlyss', 'Joinson', 'F', 'TW', 'FR42 7288 6512 011V G63T MRCD G23', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('89-8070548', 'Torbjörn', 'Beddows', 'F', 'CO', 'AL04 7893 6501 GJHR NJZY YDF6 MN7B', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('33-5606533', 'Dorothée', 'Lynagh', 'M', 'CZ', 'KZ73 196S TB1I HAHH JVRT', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('36-7852903', 'Adèle', 'Fairbourn', 'M', 'MU', 'IS92 2880 6710 8254 8108 8319 97', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('66-5037260', 'Bécassine', 'McCarter', 'M', 'CN', 'VG54 HEIH 8980 2002 5134 8167', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('32-1152552', 'Léonie', 'Edgars', 'M', 'DO', 'NL08 BPWW 3269 0991 65', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('23-1105511', 'Lài', 'Ingrem', 'F', 'PH', 'RS50 3149 5897 8605 0932 69', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('47-3878642', 'Naéva', 'Jeffers', 'F', 'SE', 'LV04 KTJV MKGO 1GO5 BT9F 9', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('82-8755558', 'Rachèle', 'Brookes', 'F', 'FI', 'MC88 9297 7864 17BT XDEO PROX D59', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('46-3228382', 'Mélina', 'Lundbech', 'F', 'BR', 'CY17 8593 8990 KFJW DCQN MMTW ALFZ', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('85-8372302', 'Torbjörn', 'Thurnham', 'M', 'PL', 'SI61 1648 4976 2303 790', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('16-5564367', 'Torbjörn', 'Ayrton', 'M', 'CN', 'IE16 XOIN 7573 0781 4021 14', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('77-3782959', 'Océane', 'Meagher', 'M', 'AR', 'LI28 8216 6KBN AQMY W0RQ U', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('05-5036562', 'Kuí', 'Andrelli', 'M', 'GY', 'DE21 7151 2244 0412 4363 34', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('89-1058175', 'Françoise', 'Emnoney', 'M', 'PT', 'SA14 95BK BICM NTYF 4EED CWQI', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('99-9019118', 'Naéva', 'Aitkin', 'M', 'SE', 'CY94 9065 9115 LXOL ADJT CDQ0 JJYS', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('21-5003482', 'Garçon', 'Tubritt', 'F', 'PT', 'FR85 1230 0364 34LB ECEZ FIVR P45', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('07-4741917', 'Cléopatre', 'Ensley', 'F', 'CN', 'PS91 VGWM I17P FIGT 3HX0 ZJXU ASLB K', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('33-9156718', 'Lài', 'Reilingen', 'M', 'AR', 'DO86 R8AC 7840 2362 9916 3895 9038', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('56-8352232', 'Laïla', 'Paeckmeyer', 'M', 'GU', 'CR31 3636 7494 4377 2698 5', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('62-6167275', 'Ruò', 'Cothey', 'F', 'CN', 'PS23 VTLC D5PF 84MT 532J DBZY FHOE M', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('95-5191962', 'Publicité', 'Erwin', 'M', 'SE', 'SA73 00HY JIEJ 25XX LWRZ 6CWL', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('36-1836802', 'Publicité', 'Noulton', 'F', 'AL', 'GE27 AR33 3643 0791 8878 16', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('75-2973252', 'Lóng', 'Bartoloma', 'M', 'RU', 'MD30 H6KF IRHT K7GL JQWG T8YY', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('86-8770150', 'Mélia', 'Howatt', 'M', 'ME', 'AZ12 KWPF JAWV J2CI NOGU LP0K 6DEN', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('24-2035442', 'Andrée', 'Pandya', 'F', 'RU', 'AE62 1616 3139 8941 2263 531', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('39-5085067', 'Aurélie', 'Descroix', 'M', 'CN', 'FR39 0541 5284 74S0 ZXTL CF2U H05', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('17-1572544', 'Marie-noël', 'McGrae', 'M', 'TH', 'GE31 YG03 3173 2613 9130 29', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('98-9927522', 'Mélia', 'McKague', 'M', 'PH', 'BH69 XRQU 4OKC WL98 JSZU UN', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('91-0593809', 'Valérie', 'MacLeod', 'F', 'PL', 'RS69 7243 0224 2171 8024 55', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('56-8043882', 'Amélie', 'McGebenay', 'M', 'RS', 'ES70 0391 5803 0199 2466 0785', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('71-2851314', 'Ruò', 'Huckerby', 'F', 'CN', 'MC42 7319 4584 682J VI3J XBNZ F63', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('95-7863203', 'Mélinda', 'Ornelas', 'M', 'RU', 'FR02 5606 5231 74YK XLME ZA70 392', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('62-3433082', 'Yú', 'Leggis', 'M', 'LV', 'GR24 9279 4025 RLSN 8R2H MN3A YVZ', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('85-5192399', 'Lài', 'Bumfrey', 'F', 'VN', 'FR30 5493 9928 98CD QDMW ZZ3Y S80', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('75-8266731', 'Naëlle', 'Devonport', 'M', 'MN', 'CY56 8382 7230 K9LU 2UCI 47J8 98Q5', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('66-6848805', 'Maïly', 'Abell', 'M', 'ID', 'MD22 IADK T4SZ GRSZ NH1N DWQ6', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('98-8947455', 'Solène', 'O''Sharkey', 'F', 'KN', 'FR70 7282 5028 52Q6 FNBP 9E4L R10', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('81-1831446', 'Ráo', 'Dolle', 'F', 'ID', 'BH74 PJPY OWGY THRC JCM0 BS', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('47-0030586', 'Audréanne', 'Panchen', 'F', 'CN', 'AT33 0121 9161 9354 3302', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('51-9146848', 'Célestine', 'Mangion', 'F', 'BR', 'HR76 3885 7052 6883 0870 7', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('13-4721169', 'Andréa', 'Carbery', 'F', 'NG', 'MT97 WHOD 3899 2YBL UEHG KLGS 7CSY 6E0', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('61-1197929', 'Cinéma', 'Boule', 'F', 'CU', 'CZ35 2734 4559 7031 1141 2672', 'Open');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('98-3310048', 'Mårten', 'McGinlay', 'F', 'AT', 'FR33 2481 1229 247R P3RK Y4SL V28', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('65-7797386', 'Anaïs', 'Creer', 'F', 'PT', 'BE77 7297 7959 8138', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('87-2048712', 'Annotée', 'Busek', 'M', 'CN', 'FR98 3096 6151 08C9 PL7G KEVK H56', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('93-3872285', 'Chloé', 'Brede', 'M', 'PH', 'CR49 6309 6880 7519 7357 1', 'In-Progress');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('10-7768190', 'Cléa', 'Bax', 'M', 'SE', 'MR62 1672 7854 3669 6262 4984 523', 'Closed');
insert into Suspect_Watchlist (Track_Id, First_Name, Last_Name, Gender, Residence_Country, Traced_Account, Investigation_Status) values ('07-9854524', 'Daphnée', 'Bremmer', 'F', 'MX', 'SK27 8261 7374 1340 5400 6113', 'In-Progress');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO Trafficking_Transaction
SELECT
ROW_NUMBER() OVER (ORDER BY 1) as Transaction_Id,
common_name as Trafficked_Species, 
Traced_Account as Seller_Account,
(array['AUD', 'GBP', 'JPY', 'USD', 'CHF'])[floor(random()*4)+1] as Currency,
floor(random()*10000)+10 as Transaction_Value,
NOW() - (random() * (interval '120 days')) as Transaction_Date
FROM species_watchlist
CROSS JOIN suspect_watchlist
WHERE RANDOM() < 0.15
ORDER BY RANDOM()
LIMIT 1000;