/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                     */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The following case will be about customers purchasing items. The entity set E1 is "customers",
entity set E2 is "drugs", and the many-to-many relationship R would be "orders" which describes the relationship of customer buying drugs.
The codes are written for PostgresSQL.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/* 
*/
/************************************************************************/
/* Write your answer in SQL below: */

DROP TABLE customers CASCADE;
CREATE TABLE IF NOT EXISTS customers (
	name VARCHAR(64) NOT NULL,
	email VARCHAR(64) PRIMARY KEY,
	race VARCHAR NOT NULL,
	medical_allergies BOOLEAN NOT NULL);

DROP table drugs CASCADE;
CREATE TABLE IF NOT EXISTS drugs(
	name VARCHAR NOT NULL,
	drug_id VARCHAR(32) PRIMARY KEY,
	price DECIMAL (5,2) NOT NULL CHECK (price>0),
	potential_allergies BOOLEAN NOT NULL);

DROP TABLE orders CASCADE;
CREATE TABLE IF NOT EXISTS orders(
	customer_email VARCHAR(64) REFERENCES customers(email),
	drug_id VARCHAR(32) REFERENCES drugs(drug_id));


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into customers (name, email, race, medical_allergies) values ('Mara McNirlin', 'mmcnirlin0@gizmodo.com', 'Paiute', true);
insert into customers (name, email, race, medical_allergies) values ('Lula McHale', 'lmchale1@usa.gov', 'Iroquois', true);
insert into customers (name, email, race, medical_allergies) values ('Sande Duhig', 'sduhig2@rakuten.co.jp', 'White', true);
insert into customers (name, email, race, medical_allergies) values ('Bryn Grimmolby', 'bgrimmolby3@live.com', 'Crow', false);
insert into customers (name, email, race, medical_allergies) values ('Lara Dight', 'ldight4@ucla.edu', 'Chamorro', true);
insert into customers (name, email, race, medical_allergies) values ('Alene Igglesden', 'aigglesden5@devhub.com', 'Cree', false);
insert into customers (name, email, race, medical_allergies) values ('Abby Wogan', 'awogan6@rambler.ru', 'Peruvian', true);
insert into customers (name, email, race, medical_allergies) values ('Dan Insley', 'dinsley7@taobao.com', 'Choctaw', true);
insert into customers (name, email, race, medical_allergies) values ('Oliver Hiseman', 'ohiseman8@lulu.com', 'Iroquois', true);
insert into customers (name, email, race, medical_allergies) values ('Stevena Langworthy', 'slangworthy9@youku.com', 'Asian Indian', false);
insert into customers (name, email, race, medical_allergies) values ('Gerrilee Czajkowski', 'gczajkowskia@163.com', 'Black or African American', true);
insert into customers (name, email, race, medical_allergies) values ('Briggs Michieli', 'bmichielib@weather.com', 'Cambodian', true);
insert into customers (name, email, race, medical_allergies) values ('Jennee Straniero', 'jstranieroc@nhs.uk', 'Argentinian', false);
insert into customers (name, email, race, medical_allergies) values ('Leia L'' Estrange', 'lld@slate.com', 'Thai', false);
insert into customers (name, email, race, medical_allergies) values ('Shay Rubinfajn', 'srubinfajne@homestead.com', 'Colville', false);
insert into customers (name, email, race, medical_allergies) values ('Betteanne Burnapp', 'bburnappf@ca.gov', 'Honduran', true);
insert into customers (name, email, race, medical_allergies) values ('Davita Forsyth', 'dforsythg@springer.com', 'Tlingit-Haida', false);
insert into customers (name, email, race, medical_allergies) values ('Carolina Mulcock', 'cmulcockh@bravesites.com', 'Tongan', true);
insert into customers (name, email, race, medical_allergies) values ('Tabby Plank', 'tplanki@mayoclinic.com', 'American Indian and Alaska Native (AIAN)', false);
insert into customers (name, email, race, medical_allergies) values ('Cullin Scapelhorn', 'cscapelhornj@tripadvisor.com', 'Colombian', true);
insert into customers (name, email, race, medical_allergies) values ('Vanessa Goshawk', 'vgoshawkk@plala.or.jp', 'Cherokee', true);
insert into customers (name, email, race, medical_allergies) values ('Uri Catcheside', 'ucatchesidel@mlb.com', 'Mexican', true);
insert into customers (name, email, race, medical_allergies) values ('Ottilie Braine', 'obrainem@boston.com', 'Ecuadorian', false);
insert into customers (name, email, race, medical_allergies) values ('Tremaine Duckett', 'tduckettn@nytimes.com', 'American Indian', true);
insert into customers (name, email, race, medical_allergies) values ('Cally Baistow', 'cbaistowo@sina.com.cn', 'Pima', true);
insert into customers (name, email, race, medical_allergies) values ('Ernesto Burgiss', 'eburgissp@soup.io', 'Uruguayan', true);
insert into customers (name, email, race, medical_allergies) values ('Ali Schulkins', 'aschulkinsq@marriott.com', 'Colville', true);
insert into customers (name, email, race, medical_allergies) values ('Skipp Ricco', 'sriccor@dailymail.co.uk', 'Native Hawaiian', false);
insert into customers (name, email, race, medical_allergies) values ('Cecilio Godehard.sf', 'cgodehardsfs@pcworld.com', 'Japanese', true);
insert into customers (name, email, race, medical_allergies) values ('Madelon Aingel', 'maingelt@walmart.com', 'Lumbee', false);
insert into customers (name, email, race, medical_allergies) values ('Costanza Gabbett', 'cgabbettu@mit.edu', 'Bolivian', true);
insert into customers (name, email, race, medical_allergies) values ('Patsy Trodler', 'ptrodlerv@hugedomains.com', 'Chamorro', false);
insert into customers (name, email, race, medical_allergies) values ('Cordelia Skpsey', 'cskpseyw@youku.com', 'Delaware', true);
insert into customers (name, email, race, medical_allergies) values ('Pieter Gresch', 'pgreschx@vimeo.com', 'Argentinian', true);
insert into customers (name, email, race, medical_allergies) values ('Hogan Deyes', 'hdeyesy@google.fr', 'Paiute', true);
insert into customers (name, email, race, medical_allergies) values ('Lorri Simonassi', 'lsimonassiz@prlog.org', 'Central American', true);
insert into customers (name, email, race, medical_allergies) values ('Teresita Rubinovitsch', 'trubinovitsch10@sohu.com', 'Seminole', true);
insert into customers (name, email, race, medical_allergies) values ('Barnabas Savin', 'bsavin11@constantcontact.com', 'Japanese', true);
insert into customers (name, email, race, medical_allergies) values ('Jo-ann Kapelhoff', 'jkapelhoff12@weibo.com', 'Spaniard', true);
insert into customers (name, email, race, medical_allergies) values ('Innis O''Dogherty', 'iodogherty13@wix.com', 'Houma', true);
insert into customers (name, email, race, medical_allergies) values ('Tonya Caghy', 'tcaghy14@bravesites.com', 'Tlingit-Haida', true);
insert into customers (name, email, race, medical_allergies) values ('Aylmer Macbeth', 'amacbeth15@prnewswire.com', 'Argentinian', true);
insert into customers (name, email, race, medical_allergies) values ('Tomlin Singers', 'tsingers16@vimeo.com', 'Laotian', false);
insert into customers (name, email, race, medical_allergies) values ('Hernando Ansell', 'hansell17@lycos.com', 'Vietnamese', false);
insert into customers (name, email, race, medical_allergies) values ('Idell Bedow', 'ibedow18@canalblog.com', 'Menominee', false);
insert into customers (name, email, race, medical_allergies) values ('Berty Dikels', 'bdikels19@vkontakte.ru', 'Sioux', false);
insert into customers (name, email, race, medical_allergies) values ('Chester Adanez', 'cadanez1a@angelfire.com', 'Sri Lankan', false);
insert into customers (name, email, race, medical_allergies) values ('Merilee Fucher', 'mfucher1b@archive.org', 'Salvadoran', true);
insert into customers (name, email, race, medical_allergies) values ('Veronika Bendixen', 'vbendixen1c@vkontakte.ru', 'Menominee', true);
insert into customers (name, email, race, medical_allergies) values ('Berty Plaice', 'bplaice1d@amazon.com', 'Creek', false);
insert into customers (name, email, race, medical_allergies) values ('Vivia Wrathall', 'vwrathall1e@elpais.com', 'Cuban', true);
insert into customers (name, email, race, medical_allergies) values ('Lissi Frankish', 'lfrankish1f@sitemeter.com', 'Potawatomi', false);
insert into customers (name, email, race, medical_allergies) values ('Vikky Yurov', 'vyurov1g@squidoo.com', 'Kiowa', true);
insert into customers (name, email, race, medical_allergies) values ('Brook Valenta', 'bvalenta1h@archive.org', 'Polynesian', true);
insert into customers (name, email, race, medical_allergies) values ('Tamma Flatte', 'tflatte1i@jigsy.com', 'Salvadoran', false);
insert into customers (name, email, race, medical_allergies) values ('Panchito Gonnin', 'pgonnin1j@ft.com', 'Paiute', false);
insert into customers (name, email, race, medical_allergies) values ('Asa Daniell', 'adaniell1k@digg.com', 'Hmong', true);
insert into customers (name, email, race, medical_allergies) values ('Carole Serfati', 'cserfati1l@hhs.gov', 'Puerto Rican', false);
insert into customers (name, email, race, medical_allergies) values ('Joyous Franciotti', 'jfranciotti1m@telegraph.co.uk', 'Bolivian', false);
insert into customers (name, email, race, medical_allergies) values ('Stafford Swaffield', 'sswaffield1n@yahoo.co.jp', 'Native Hawaiian and Other Pacific Islander (NHPI)', false);
insert into customers (name, email, race, medical_allergies) values ('Ingrim Amsden', 'iamsden1o@wix.com', 'Bangladeshi', false);
insert into customers (name, email, race, medical_allergies) values ('Stacie Spargo', 'sspargo1p@a8.net', 'Alaskan Athabascan', true);
insert into customers (name, email, race, medical_allergies) values ('Clari Craw', 'ccraw1q@blogs.com', 'Alaska Native', false);
insert into customers (name, email, race, medical_allergies) values ('Ignatius Halden', 'ihalden1r@is.gd', 'Uruguayan', false);
insert into customers (name, email, race, medical_allergies) values ('Shaylah Roseveare', 'sroseveare1s@e-recht24.de', 'Indonesian', false);
insert into customers (name, email, race, medical_allergies) values ('Thain Lampet', 'tlampet1t@nytimes.com', 'Ecuadorian', false);
insert into customers (name, email, race, medical_allergies) values ('Deb Huyge', 'dhuyge1u@ucla.edu', 'Chickasaw', true);
insert into customers (name, email, race, medical_allergies) values ('Damon Baskeyfield', 'dbaskeyfield1v@edublogs.org', 'Yaqui', true);
insert into customers (name, email, race, medical_allergies) values ('Dorita Clacey', 'dclacey1w@tinyurl.com', 'Bolivian', false);
insert into customers (name, email, race, medical_allergies) values ('Elbertina Uttridge', 'euttridge1x@bravesites.com', 'Alaska Native', false);
insert into customers (name, email, race, medical_allergies) values ('Alexio Pooly', 'apooly1y@wunderground.com', 'Tohono O''Odham', false);
insert into customers (name, email, race, medical_allergies) values ('Francene Ketteringham', 'fketteringham1z@latimes.com', 'Thai', false);
insert into customers (name, email, race, medical_allergies) values ('Darla Matelaitis', 'dmatelaitis20@bing.com', 'Pueblo', false);
insert into customers (name, email, race, medical_allergies) values ('Royal Titherington', 'rtitherington21@amazon.co.jp', 'Bangladeshi', false);
insert into customers (name, email, race, medical_allergies) values ('Caro Kopisch', 'ckopisch22@i2i.jp', 'Guatemalan', true);
insert into customers (name, email, race, medical_allergies) values ('Victor Oldrey', 'voldrey23@nydailynews.com', 'Paiute', false);
insert into customers (name, email, race, medical_allergies) values ('Jaime Finnan', 'jfinnan24@linkedin.com', 'Samoan', true);
insert into customers (name, email, race, medical_allergies) values ('Audry Annear', 'aannear25@mysql.com', 'Eskimo', true);
insert into customers (name, email, race, medical_allergies) values ('Darbee Risdall', 'drisdall26@microsoft.com', 'Alaska Native', true);
insert into customers (name, email, race, medical_allergies) values ('Daron Dillinger', 'ddillinger27@nba.com', 'Tlingit-Haida', false);
insert into customers (name, email, race, medical_allergies) values ('Juli Gage', 'jgage28@wix.com', 'Argentinian', true);
insert into customers (name, email, race, medical_allergies) values ('Bil Widocks', 'bwidocks29@ycombinator.com', 'Ottawa', false);
insert into customers (name, email, race, medical_allergies) values ('Clarine Sorrell', 'csorrell2a@msn.com', 'Chamorro', false);
insert into customers (name, email, race, medical_allergies) values ('Alberik Goacher', 'agoacher2b@usa.gov', 'Paiute', false);
insert into customers (name, email, race, medical_allergies) values ('Hamel Olwen', 'holwen2c@over-blog.com', 'Korean', false);
insert into customers (name, email, race, medical_allergies) values ('Maximilien Davoren', 'mdavoren2d@census.gov', 'Thai', false);
insert into customers (name, email, race, medical_allergies) values ('Westbrook McFade', 'wmcfade2e@alibaba.com', 'Malaysian', true);
insert into customers (name, email, race, medical_allergies) values ('Bianca Cash', 'bcash2f@aol.com', 'Creek', false);
insert into customers (name, email, race, medical_allergies) values ('Corbet MacChaell', 'cmacchaell2g@fema.gov', 'Puerto Rican', true);
insert into customers (name, email, race, medical_allergies) values ('Shirl Epilet', 'sepilet2h@yale.edu', 'Crow', false);
insert into customers (name, email, race, medical_allergies) values ('Angeli Huriche', 'ahuriche2i@loc.gov', 'Tohono O''Odham', false);
insert into customers (name, email, race, medical_allergies) values ('Cece Shepherdson', 'cshepherdson2j@phpbb.com', 'Iroquois', true);
insert into customers (name, email, race, medical_allergies) values ('Paulita Parfrey', 'pparfrey2k@oakley.com', 'Melanesian', true);
insert into customers (name, email, race, medical_allergies) values ('Miltie Ewbanks', 'mewbanks2l@g.co', 'Ecuadorian', false);
insert into customers (name, email, race, medical_allergies) values ('Zollie Andreasen', 'zandreasen2m@ft.com', 'Ute', true);
insert into customers (name, email, race, medical_allergies) values ('Truman Spear', 'tspear2n@altervista.org', 'Creek', false);
insert into customers (name, email, race, medical_allergies) values ('Cathleen Usherwood', 'cusherwood2o@washington.edu', 'Cambodian', false);
insert into customers (name, email, race, medical_allergies) values ('Francesca Cleal', 'fcleal2p@blogspot.com', 'Peruvian', false);
insert into customers (name, email, race, medical_allergies) values ('Tait Bryden', 'tbryden2q@photobucket.com', 'Paraguayan', true);
insert into customers (name, email, race, medical_allergies) values ('Krissie Matkovic', 'kmatkovic2r@epa.gov', 'Malaysian', false);


insert into drugs (name, drug_id, price, potential_allergies) values ('Acetaminophen', '676479919', 11.13, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Dextromethorphan HBr and Guaifenesin', '650853380', 129.39, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('TITANIUM DIOXIDE', '840172378', 131.51, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Salicylic Acid', '721279571', 188.1, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('tanacetum cinerariifolium flower', '640628045', 153.08, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Terazosin', '519897608', 15.61, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Valerian Root, Passiflora, Magnesium Carbonate', '167152986', 33.29, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Fluorescein Sodium', '560294035', 187.93, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Helium Oxygen Mix', '137913911', 83.64, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('pazopanib hydrochloride', '044077179', 150.53, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('famotidine', '758915182', 90.03, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Minocycline Hydrochloride', '728650246', 140.84, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Isoniazid', '814079136', 87.52, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Antihemophilic Factor/von Willebrand Factor Complex (Human)', '520327084', 61.64, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Benzalkonium Chloride', '736006372', 151.4, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Carisoprodol and Aspirin', '736544840', 199.42, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Octinoxate and Avobenzone', '612199750', 42.4, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Tramadol Hydrochloride', '108432476', 91.16, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Ginger', '993486448', 108.71, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('zolpidem tartrate', '564400661', 178.96, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('prednisolone sodium phosphate', '628675127', 171.68, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Tolnaftate', '378303982', 88.01, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Allium sativum, Aluminium metallicum, Arg. met., Aur. met., Baryta carb., Beryllium metallicum, Bismuthum metallicum, Cadmium metallicum, Calc. fluor., Carbo veg., Chelidonium majus, Cinchona, Cobaltum met., Cuprum met., Glycyrrhiza glabra, Hydrofluoricum acidum, Iris versicolor, Manganum metallicum, Merc. viv., Niccolum metallicum, Osmium metallicum, Platinum met., Plumb. met., Stannum met., Strontium carb., Thallium metallicum, Titanium metallicum, Carduus mar., Taraxacum', '790534116', 190.05, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Wart Remover Strips', '075510411', 126.69, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Verapamil Hydrochloride', '709857297', 127.49, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('eucalyptol, menthol, methyl salicylate, thymol', '740671674', 134.46, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('PECTIN', '701031721', 47.46, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Technetium Tc-99m Generator', '844868035', 66.52, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('OCTINOXATE, AVOBENZONE', '054693710', 131.66, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('benazepril hydrochloride', '722569477', 177.4, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('chlorine', '663952600', 40.97, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Veratrum Chamomilla', '279166075', 170.11, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Omeprazole', '107380293', 174.83, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Glyburide', '146633133', 199.88, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('OCTINOXATE, OXYBENZONE, OCTISALATE', '585467885', 122.79, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('LIDOCAINE HYDROCHLORIDE, MENTHOL', '137825815', 26.93, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Felodipine', '090825327', 154.29, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Povidone Iodine', '526896215', 24.68, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('bacillus cereus', '303446361', 189.85, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('AZITHROMYCIN', '676417936', 16.52, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('OCTINOXATE and TITANIUM DIOXIDE', '284228274', 91.75, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Benzoyl Peroxide', '401801861', 189.52, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('calcipotriene 0.005% and betamethasone dipropionate 0.064%', '797751912', 88.05, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('ACETAMINOPHEN, CHLORPHENIRAMINE MALEATE, DEXTROMETHORPHAN HYDROBROMIDE, PHENYLEPHRINE HYDROCHLORIDE', '189329218', 85.83, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('TITANIUM DIOXIDE', '391129865', 159.05, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Arnica Montana, Bryonia Alba Root, Quinine Sulfate, Anamirta Cocculus Seed, Conium Maculatum Flowering Top, Strychnos Ignatii Seed, Ipecac, Potassium Carbonate, Strychnos Nux-Vomica Seed, Sepia Officinalis Juice, Tobacco Leaf, Veratrum Album Root', '407070266', 123.6, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Midodrine Hydrochloride', '768487185', 100.41, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Diphenhydramine Hydrochloride', '395612891', 87.46, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Montelukast Sodium', '308139521', 128.09, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Reticuloendothelial system 8 Special Order', '033054130', 120.79, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Benzalkonium Chloride', '008399529', 156.39, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('ETHYL ALCOHOL', '103172669', 43.09, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('tapentadol hydrochloride', '902487746', 101.65, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('rufinamide', '775781775', 60.39, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Nicotine Polacrilex', '002019671', 88.42, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Clobetasol Propionate', '763755650', 195.46, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Hydrocodone Bitartrate and Acetaminophen', '549942541', 93.22, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('CAMPHOR (NATURAL), MENTHOL', '765229883', 111.46, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Oxycodone and Acetaminophen', '310005779', 21.9, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Ketotifen', '565123000', 101.67, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Mirtazapine', '517547744', 158.33, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Miconazole nitrate', '108289628', 40.24, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Water Hemp', '098892806', 42.4, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Olanzapine', '649555742', 81.79, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Acetaminophen', '651605042', 130.66, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Camphor (Synthetic) and Menthol', '464679137', 133.12, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Acetaminophen', '598902261', 153.35, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Bacitracin Zinc and Polymyxin B Sulfate', '924385530', 10.46, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Carvedilol', '519673008', 118.34, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Furosemide', '642626674', 183.32, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Losartan potassium and hydrochlorothiazide tablets', '881869968', 42.21, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Mezereum Comp.', '170529444', 171.88, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Cephalexin', '622785515', 61.31, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('amlodipine besylate and atorvastatin calcium', '141234385', 160.16, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Chamomilla, Mag phos', '537141979', 157.38, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('ALCOHOL', '454896195', 46.6, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Brompheniramine Maleate, Dextromethorphan Hydrobromide and Phenylephrine Hydrochloride', '496108174', 109.3, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Cladosporium cladosporioides', '529676533', 39.06, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('oxybutynin chloride', '021475506', 198.46, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Benzalkonium Chloride', '085796866', 58.26, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Arsenicum alb., Baptisia, Berber. aqui., Calc. fluor., Capsicum, Cinchona, Iodium, Kali carb., Lachesis, Mag. carb., Merc.viv., Nat. carb., Nat. mur., Natrum sulphuricum, Phosphorus, Phytolacca, Secale, Thymus serpyllum, Thuja occ., Thyroidinum, Verbascum, Carduus mar., Echinacea, Solidago, Taraxacum', '924971737', 36.48, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Benzocaine', '598702070', 181.23, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('amlodipine besylate and benazepril hydrochloride', '829082070', 13.26, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Tolnaftate', '863181771', 130.41, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Cloves', '754925325', 128.46, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Calendula Officinalis, Arnica Montana, Symphytum Officinale, Hypericum Perforatum, Bellis Perennis, Carbo Vegetabilis', '252677756', 144.5, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Influenzinum, Tellurium metallicum, Apis mel, Arsenicum alb., Belladonna, Bryonia, Capsicum, Causticum, Cinchona, Conium, Dulcamara, Ferrum phosphoricum, Hepar sulph. calc., Kali sulph., Lycopodium, Merc. viv., Mezereum, Phosphorus, Plantago, Pulsatilla, Silicea, Verbascum, Echinacea, Hydrastis', '358332435', 139.36, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('ibandronate sodium', '184259346', 31.15, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('montelukast sodium', '407143940', 195.51, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Folic Acid', '864197595', 163.16, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Aconitum napellus, Dulcamara, Gelsemium sempervirens', '447681699', 49.84, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Aurum 5', '978804925', 192.5, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('nicotine polacrilex', '839333296', 70.76, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('CHLOROXYLENOL', '453907142', 141.62, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Warfarin Sodium', '515247141', 94.62, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('Progesterone', '695333446', 57.72, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('oxymorphone hydrochloride', '052307502', 172.14, true);
insert into drugs (name, drug_id, price, potential_allergies) values ('furosemide', '109965002', 136.2, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Oxygen', '388337313', 175.9, false);
insert into drugs (name, drug_id, price, potential_allergies) values ('Bethanechol Chloride', '464558430', 111.52, false);


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO orders(customer_email, drug_id)
	SELECT email, drug_id
	FROM customers, drugs
	ORDER BY RANDOM()
	LIMIT 1000;

