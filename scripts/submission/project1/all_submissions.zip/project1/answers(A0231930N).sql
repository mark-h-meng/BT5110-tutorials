/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/* Name: Xhoni Shollaj
   Student Number: A0231930N						*/
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/* The following code is written and tested for PostgreSQL                                                                 */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* In this example, we have generated a relational database for a pharmaceutical
company, which consists of three tables:
a) drugs (E1)
Which includes data regarding the drug name,company, price, diagnoses code
We create this table by running drugs.sql on PostgresSQL
b) purchases (R)
Which includes data regarding the drug name,customer name, price, purchase date
We create this table by running purchase.sql on PostgresSQL
c) patient (E2)
Which includes data regarding the customer name, gender, location, drug name, diagnoses code
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

create table IF NOT EXISTS drugs (
	drugs_id INT NOT NULL PRIMARY KEY,
	drug_company VARCHAR(100) NOT NULL,
	drug_name VARCHAR(100) NOT NULL,
	drug_price NUMERIC(10) NOT NULL CHECK(drug_price>0),
	diagnosis_code VARCHAR(50) NOT NULL
);

create table IF NOT EXISTS patient (
	customer_id INT NOT NULL PRIMARY KEY,
	customer_name VARCHAR (50) NOT NULL,
	customer_gender VARCHAR(5) NOT NULL,
	customer_location VARCHAR(100) NOT NULL
);


create table IF NOT EXISTS purchases (
	purchases_id INT NOT NULL PRIMARY KEY,
	drug_name VARCHAR(100) NOT NULL,
	drug_price NUMERIC(100) NOT NULL CHECK (drug_price>0),
	customer_name VARCHAR(50) NOT NULL,
	drugs_id INT NOT NULL REFERENCES drugs (drugs_id),
	customer_id INT NOT NULL REFERENCES patient (customer_id)
);

drop table patient
drop table purchases
drop table drugs
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Inserting data on a) drugs (E1) */

insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (1, 'Torrent Pharmaceuticals Limited', 'OLANZAPINE', 867.31, 'T63031A');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (2, 'DIRECT RX', 'LORATADINE', 759.63, 'T83090');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (3, 'F&CO Co., Ltd.', 'IT RADIANT MULTIPLE CC FOR MAN', 974.68, 'B967');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (4, 'Legacy Pharmaceutical Packaging', 'Amlodipine Besylate', 717.52, 'S82453H');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (5, 'Qualitest Pharmaceuticals', 'Promethazine Hydrochloride', 115.37, 'T82338S');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (6, 'Mylan Pharmaceuticals Inc.', 'Ibandronate Sodium', 283.85, 'Y3889');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (7, 'Supervalu Inc', 'Equaline Tussin Mucus and Chest Congestion', 953.93, 'O30191');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (8, 'Dolgencorp, LLC', 'Rexall Pain Relief', 843.20, 'S50849S');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (9, 'Apollo Health and Beauty Care', 'CVS PHARMACY', 76.56, 'W90');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (10, 'Contract Pharmacy Services-PA', 'Ibuprofen', 281.60, 'M5114');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (11, 'VistaPharm, Inc.', 'Ibuprofen', 711.12, 'S30870');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (12, 'Sun Products Corporation', 'Home Sense Ultra Green Apple Scent', 561.38, 'S43422');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (13, 'BEYOND TECHNOLOGY CORP.', 'Beyond Antiseptic Mouthwash', 679.75, 'M4856XA');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (14, 'Mylan Pharmaceuticals Inc.', 'Topiramate', 896.59, 'V85');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (15, 'SJ Creations, Inc.', 'Spooky Sugar Cookie Antibacterial', 80.38, 'S3750');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (16, 'DIRECT RX', 'HYDROCODONE BITARTRATE', 568.77, 'S79929');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (17, 'Publix Supermarkets, Inc.', 'Headache Relief', 7.48, 'S46201S');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (18, 'Greenstone LLC', 'Torsemide', 520.26, 'G4300');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (19, 'NCS HealthCare of KY, Inc dba Vangard Labs', 'Folbic', 721.87, 'T44904A');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (20, 'Prasco Laboratories', 'Olanzapine', 150.30, 'H4479');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (21, 'PD-Rx Pharmaceuticals, Inc.', 'Phendimetrazine Tartrate', 442.46, 'O2491');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (22, 'SHISEIDO AMERICAS CORPORATION', 'CLE DE PEAU BEAUTE RADIANT FLUID FOUNDATION', 261.03, 'V0021');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (23, 'Clinical Solutions Wholesale', 'Losartan Potassium', 292.57, 'O0380');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (24, 'REMEDYREPACK INC.', 'FLUPHENAZINE HYDROCHLORIDE', 829.30, 'S58022D');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (25, 'Procter & Gamble Manufacturing Co.', 'Head and Shoulders', 606.35, 'T481X6A');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (26, 'Kareway Product, Inc.', 'Sport Sunblock', 519.39, 'T540X2');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (27, 'Ventura Corporation LTD', 'ESIKA Extreme Moisturizing SPF 16', 828.22, 'M00131');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (28, 'Wal-Mart Stores, Inc', 'citroma', 912.51, 'S82033N');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (29, 'MEGASOL COSMETIC GMBH', 'EROS EXTENDED LOVE GLIDE', 402.34, 'S62012G');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (30, 'Beiersdorf Inc', 'Nivea For Men Age Defying Face Moisturizer', 9.49, 'S32615B');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (31, 'Mylan Pharmaceuticals Inc.', 'Telmisartan and Hydrochlorothiazide', 227.32, 'T85625D');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (32, 'Newton Laboratories, Inc.', 'Hyperactivity - Mental Focus', 673.43, 'P611');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (33, 'SHISEIDO AMERICA INC.', 'SHISEIDO THE SKINCARE TINTED MOISTURE', 367.69, 'J40');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (34, 'Bryant Ranch Prepack', 'HYZAAR', 279.67, 'I6924');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (35, 'Johnson & Johnson Consumer, Division of Johnson & Johnson Consumers, Inc.', 'BENADRYL Extra Strength Itch Cooling', 525.33, 'S92592S');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (36, 'Navajo Manufacturing Company Inc.', 'Refresh Tears Lubricant', 987.35, 'S72309B');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (37, 'Rugby Laboratories', 'Hydro Skin', 69.28, 'S65309D');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (38, 'Uriel Pharmacy Inc.', 'Dioscorea batata Special Order', 434.90, 'S93526D');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (39, 'Cardinal Health', 'Diphenhydramine Hydrochloride', 512.46, 'S3339XS');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (40, 'Cardinal Health', 'Sodium Chloride', 62.57, 'L711');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (41, 'SHELBY PROFESSIONAL, INC.', 'BOOST REGROWTH FOR WOMEN', 224.29, 'V133XXD');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (42, 'Reckitt Benckiser, Inc.', 'Delsym Night Time Cough and Cold', 550.04, 'T447X6S');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (43, 'Major Pharmaceuticals', 'Simvastatin', 515.46, 'O09813');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (44, 'Rebel Distributors Corp', 'Fluconazole', 33.66, 'C7A019');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (45, 'CVS Pharmacy', 'milk of magnesia', 468.71, 'S42319D');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (46, 'MD Formulation', 'Total Protector 30', 22.23, 'T25021S');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (47, 'ALK-Abello, Inc.', 'CENTER-AL - AMBROSIA ACANTHICARPA POLLEN', 551.41, 'S0550');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (48, 'Golden Sunshine International, Inc.', 'Golden Sunshine Far Infrared HOT Herbal', 156.80, 'S50852A');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (49, 'Rite Aid Corporation', 'cool heat', 993.75, 'M84473A');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (50, 'REMEDYREPACK INC.', 'Prednisone', 620.89, 'S68511S');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (51, 'Universal holdings I Smith Brothers Company', 'PharmaRight Extra Strength Antacid PEPPEr', 384.92, 'S42036P');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (52, 'Antigen Laboratories, Inc.', 'B Mold Mixture', 816.53, 'V9227');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (53, 'Uriel Pharmacy Inc.', 'Chrysosplenium Chamomilla', 669.90, 'O36822');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (54, 'Chattem, Inc.', 'BullFrog Quik Gel Sport', 348.15, 'Y36521D');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (55, 'Amerisource Bergen', 'Loratadine and Pseudoephedrine', 102.99, 'S93502A');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (56, 'Cintas First Aid & Safety', 'Isopropyl Alcohol', 744.96, 'M4156');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (57, 'Valeant Pharmaceuticals North America LLC', 'CeraVe', 82.47, 'M1A442');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (58, 'Mylan Institutional LLC', 'Rocuronium Bromide', 34.93, 'S56992A');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (59, 'Geri-Care Pharmaceuticals, Corp', 'GAVIS-CARE ANTACID', 236.43, 'S62209A');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (60, 'Mylan Institutional Inc.', 'Phenytoin', 615.33, 'F16950');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (61, 'Nelco Laboratories, Inc.', 'Red Oak', 425.07, 'T871X');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (62, 'Geri-Care Pharmaceuticals, Corp', 'MUCUS RELIEF', 248.54, 'F1195');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (63, 'Aplicare, Inc.', 'Aplicare Povidone Iodine', 729.55, 'V0009XS');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (64, 'Teral, Inc.', 'Oticin', 923.86, 'V0501XD');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (65, 'Teva Pharmaceuticals USA Inc', 'Diflunisal', 661.18, 'S61409');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (66, 'Jubilant HollisterStier LLC', 'Pollens - Weeds, Mugwort Artemisia vulgaris', 413.75, 'B004');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (67, 'Mylan Institutional LLC', 'Dexamethasone sodium phosphate', 149.91, 'S3021XS');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (68, 'Bausch & Lomb Incorporated', 'Soothe Night Time', 990.32, 'M978XXS');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (69, 'Walgreen Company', 'Multi Antibiotic with Pain Relief', 698.05, 'W378');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (70, 'Native Remedies, LLC', 'Anal Itch Assist', 977.98, 'S62145P');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (71, 'Mckesson (Sunmark)', 'Sleep Aid', 682.30, 'P59');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (72, 'GlaxoSmithKline LLC', 'TIMENTIN', 528.21, 'S70921D');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (73, 'Ventura International LTD.', 'LBEL COULEUR LUXE AMPLIFIER XP', 882.15, 'B0601');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (74, 'Bryant Ranch Prepack', 'FENTANYL', 996.48, 'V9081XS');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (75, 'Bryant Ranch Prepack', 'Lisinopril', 111.06, 'S52045P');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (76, 'Merle Norman Cosmetics, Inc', 'Deep Tan  Makeup Broad Spectrum SPF 25', 816.20, 'T434X2D');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (77, 'Roxane Laboratories, Inc', 'Codeine sulfate', 391.88, 'S82431N');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (78, 'Ethex Corporation', 'dextroamphetamine sulfate', 810.19, 'M1008');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (79, 'Western Family Foods Inc', 'Naproxen Sodium', 529.52, 'O8909');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (80, 'Actavis Pharma, Inc.', 'Hydrocodone Bitartrate and Acetaminophen', 645.14, 'S86111A');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (81, 'Jubilant HollisterStier LLC', 'Food - Plant Source, Orange Citrus sinensis', 65.91, 'S35222S');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (82, 'Sagent Pharmaceuticals', 'Vecuronium', 45.11, 'I70638');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (83, 'PD-Rx Pharmaceuticals, Inc.', 'OxyContin', 996.45, 'Y387X1');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (84, 'NCS HealthCare of KY, Inc dba Vangard Labs', 'Donepezil Hydrochloride', 895.12, 'S59049');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (85, 'Virtus Pharmaceuticals', 'L-Methyl-B6-B12', 168.62, 'C240');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (86, 'Uriel Pharmacy Inc.', 'Chrysolith Retina', 128.61, 'T871');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (87, 'Publix Super Markets Inc', 'Publix Sunscreen', 527.40, 'S1090XA');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (88, 'Lornamead', 'Lornamead', 533.43, 'T2104');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (89, 'Physicians Total Care, Inc.', 'PAROXETINE', 698.88, 'N069');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (90, 'Cardinal Health', 'Primidone', 294.54, 'I70249');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (91, 'Sungwon Pharmaceutical Co., Ltd.', 'Anti E-Sirin', 29.72, 'S8492XA');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (92, 'EKR Therapeutics, Inc.', 'Cardene I.V.', 840.87, 'S92536S');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (93, 'AAA Pharmaceutical, Inc.', 'Acetaminophen, Guaifenesin, Hydrochloride', 888.23, 'F1292');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (94, 'NCS HealthCare of KY, Inc dba Vangard Labs', 'Pravastatin Sodium', 470.23, 'S63223S');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (95, 'AvKARE, Inc.', 'HYDROXYUREA', 606.81, 'S91123D');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (96, 'Chattem, Inc.', 'Gold Bond Ultimate Healing Concentrated Therapy', 557.10, 'T533X3D');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (97, 'Silarx Pharmaceuticals, Inc', 'Diabetic Siltussin DM DAS-Na', 982.87, 'S8253XJ');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (98, 'Ross Healthcare Inc.', 'PCXX ONE MINTE GEL LUSCIOUS LIME', 240.38, 'L817');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (99, 'Direct Rx', 'BUSPIRONE HYDROCHLORIDE', 541.42, 'E0910');
insert into drugs (drugs_id, drug_company, drug_name, drug_price, diagnosis_code) values (100, 'HOMEOLAB USA INC', 'FIBROMYALGIA', 685.56, 'X940XXS');

/* Inserting data on b) patient (E2) */
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (1, 'Eustacia Brettoner', 'F', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (2, 'Gertie Mussen',  'F', 'Sweden');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (3, 'Penelopa Burchfield',  'F', 'Montenegro');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (4, 'Linnell Cranke', 'F', 'Guatemala');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (5, 'Jobi Matuska', 'F', 'Afghanistan');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (6, 'Marquita Fortye',  'F', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (7, 'Barr Davydochkin',  'M', 'Greece');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (8, 'Nefen Bradfield', 'M', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (9, 'Jameson Jeffries', 'M', 'Ecuador');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (10, 'Greg Meffen', 'M', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (11, 'Tad Elwood', 'M', 'Indonesia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (12, 'Ysabel Aaronson',  'F', 'Portugal');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (13, 'Patty Frickey',  'F', 'Bangladesh');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (14, 'Roderic Fairholme', 'M', 'Thailand');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (15, 'Carolin Makeswell', 'F', 'Philippines');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (16, 'Dix Swadling',  'F', 'Colombia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (17, 'Sean Pickavance',  'F', 'Argentina');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (18, 'Reinhold Canby',  'M', 'Brazil');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (19, 'Mordy Skough', 'M', 'Indonesia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (20, 'Barb Enrich',  'F', 'Armenia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (21, 'Maury Pelz',  'M', 'Norway');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (22, 'Chanda Rizzone',  'F', 'Panama');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (23, 'Myrlene Le Fevre',  'F', 'Chile');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (24, 'Ray Cristofvao', 'M', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (25, 'Graehme Wrintmore', 'M', 'Indonesia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (26, 'Byron Giorio',  'M', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (27, 'Bradley Hanshaw',  'M', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (28, 'Mimi Reims', 'F', 'Portugal');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (29, 'Therine Bangle',  'F', 'Armenia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (30, 'Georgia Desbrow', 'F', 'United States');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (31, 'Breanne Belding', 'F', 'Uganda');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (32, 'Sherlocke Nortcliffe', 'M', 'Philippines');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (33, 'Kathie Nuton',  'F', 'Philippines');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (34, 'Brittaney MacMoyer',  'F', 'United States');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (35, 'Ransom Edgeler', 'M', 'Indonesia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (36, 'Christal Leghorn',  'F', 'Colombia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (37, 'Mirabella Garratt',  'F', 'Sweden');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (38, 'Claudio Gossling',  'M', 'Philippines');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (39, 'Katy Carver',  'F', 'Brazil');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (40, 'Parry Noulton', 'M', 'Japan');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (41, 'Freddie Vasentsov', 'F', 'Brazil');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (42, 'Christian Deakes', 'M', 'Canada');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (43, 'Betsey Sokell', 'F', 'Poland');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (44, 'Effie Everix',  'F', 'Yemen');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (45, 'Myrtle Seath',  'F', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (46, 'Marti Lehr',  'F', 'Ukraine');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (47, 'Ibrahim Ferrero',  'M', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (48, 'Shelby Blaxlande',  'F', 'Russia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (49, 'Menard Ort',  'M', 'Portugal');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (50, 'Celene Roberts', 'F', 'France');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (51, 'Malynda Busfield', 'F', 'Uganda');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (52, 'Christabella Leedes',  'F', 'Japan');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (53, 'Megen Mathissen', 'F', 'Canada');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (54, 'Winfield Backwell', 'M', 'France');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (55, 'Angelia Gouth',  'F', 'Tanzania');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (56, 'Susanetta Studholme',  'F', 'Czech Republic');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (57, 'Myca Scouse',  'M', 'Indonesia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (58, 'Riley Casaroli',  'M', 'Russia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (59, 'Emmy Gollard',  'F', 'Indonesia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (60, 'Lorelle Philpots',  'F', 'Haiti');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (61, 'Ashbey Kincla',  'M', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (62, 'Mia Bullivent',  'F', 'Philippines');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (63, 'Mersey Benito','F', 'Vietnam');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (64, 'Georgetta Perutto', 'F', 'Colombia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (65, 'Trenton Dyerson',  'M', 'Paraguay');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (66, 'Von Colborn',  'M', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (67, 'Tommi Matous',  'F', 'Indonesia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (68, 'Franciska Hrynczyk',  'F', 'Indonesia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (69, 'Shaun Theunissen', 'F', 'Thailand');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (70, 'Rockie Lebrun',  'M', 'Madagascar');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (71, 'Chrysler Flawn',  'F', 'Russia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (72, 'Myrah Guiden',  'F', 'Macedonia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (73, 'Almeria Ingliss', 'F', 'Philippines');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (74, 'Krishna Melross', 'M', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (75, 'Rosamond Gaucher',  'F', 'Vietnam');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (76, 'Annmaria Pheasant', 'F', 'Dominican Republic');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (77, 'Tiebold Okroy', 'M', 'Portugal');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (78, 'Lorilee Bims',  'F', 'Indonesia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (79, 'Barbee Ranger', 'F', 'Peru');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (80, 'Gaven Stanner',  'M', 'Thailand');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (81, 'Haskel Ledram',  'M', 'Uganda');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (82, 'Cybil Lawrance',  'F', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (83, 'Jasun Glacken',  'M', 'Georgia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (84, 'Chrysa Cockshott',  'F', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (85, 'Donnie Wythill',  'M', 'French Polynesia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (86, 'Elora Dewfall',  'F', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (87, 'Wilmar McCorry', 'M', 'Philippines');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (88, 'Angelika Bartolommeo', 'F', 'Ivory Coast');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (89, 'Dave Bartolomivis','M', 'Ukraine');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (90, 'Tierney Cork',  'F', 'Benin');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (91, 'Esma Sawl',  'F', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (92, 'Corilla MacCracken',  'F', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (93, 'Royce Guppie',  'M', 'Israel');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (94, 'Hendrik Kubasiewicz',  'M', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (95, 'Carlene Cohen',  'F', 'Indonesia');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (96, 'Chadd Petticrew',  'M', 'China');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (97, 'Alistair Stanbury',  'M', 'Philippines');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (98, 'Decca Gonzales', 'M', 'Canada');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (99, 'Dorette Frankling',  'F', 'Iran');
insert into patient (customer_id, customer_name, customer_gender, customer_location) values (100, 'Greg Branton',  'M', 'Macedonia');




/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT * FROM drugs, patient
ORDER BY RANDOM() LIMIT 1000;


