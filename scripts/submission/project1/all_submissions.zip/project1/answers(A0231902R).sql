/************************************************************************/
/*                                                                      */ Student ID : A0231902R
/* Project Generating Fake but Realistic Data                           */  
/*                                                                      */ Student Name : Canjie Shen
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for SQLite */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* 
 Based on real-life purchasing situations, this project is about to build a database of "Car Market", in terms of the "Buyer" table, the "Car" table and the "Purchase" table. Buyer table will contain the data of car-buyers, Car table will contain the data of all available cars, and Purchase table will contain the records of people purchasing cars.
 
 In the "Buyer" table, I will use "buyer_id", "first_name", "last_name", "email" and "gender" to characterize the buyers. In the "Car" table, the database will record information about the "car_id", "car_model", "car_make" and "car_color". In the "Purchasing" table, "buyer_id" will reference to the "Buyer" table, and "car_id" will reference to the "Car" table. Besides, there is also information about the number of cars purchased for each record and the price of the cars purchased.

I will build my database in SQLite3.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS Buyer (
 buyer_id VARCHAR(16) PRIMARY KEY,
 first_name VARCHAR(64) NOT NULL,
 last_name VARCHAR(64) NOT NULL,
 email VARCHAR(64) UNIQUE NOT NULL,
 gender VARCHAR(16) NOT NULL);

CREATE TABLE IF NOT EXISTS Car(
 car_id VARCHAR(16) PRIMARY KEY,
 car_model VARCHAR(64) NOT NULL,
 car_make VARCHAR(64) NOT NULL,
 car_color VARCHAR(16) NOT NULL);

CREATE TABLE IF NOT EXISTS Purchase(
 buyer_id VARCHAR(16) REFERENCES Buyer(buyer_id),
 car_id VARCHAR(16) REFERENCES Car(car_id),
 num NUMERIC NOT NULL,
 price NUMERIC NOT NULL);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Insert into Buyer Table*/

insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10001, 'Darcie', 'Andryszczak', 'dandryszczak0@admin.ch', 'Male');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10002, 'Denny', 'Puffett', 'dpuffett1@geocities.com', 'Non-binary');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10003, 'Lenora', 'Ruggs', 'lruggs2@reuters.com', 'Bigender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10004, 'Cobby', 'Noad', 'cnoad3@cam.ac.uk', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10005, 'Clio', 'Lovart', 'clovart4@devhub.com', 'Male');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10006, 'Marylee', 'Pick', 'mpick5@is.gd', 'Male');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10007, 'Maryanne', 'Romayne', 'mromayne6@oakley.com', 'Genderfluid');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10008, 'Shaina', 'Fazakerley', 'sfazakerley7@barnesandnoble.com', 'Female');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10009, 'Caesar', 'Provis', 'cprovis8@diigo.com', 'Female');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10010, 'Elnore', 'Nono', 'enono9@pinterest.com', 'Female');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10011, 'Neale', 'Cottesford', 'ncottesforda@arstechnica.com', 'Polygender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10012, 'Chrysa', 'Quigg', 'cquiggb@cafepress.com', 'Male');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10013, 'Prentiss', 'Wilbud', 'pwilbudc@nytimes.com', 'Male');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10014, 'Eldon', 'Flattman', 'eflattmand@wordpress.com', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10015, 'Stacy', 'Leabeater', 'sleabeatere@amazon.de', 'Polygender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10016, 'Dagmar', 'Creaney', 'dcreaneyf@sfgate.com', 'Bigender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10017, 'Tanner', 'Yarham', 'tyarhamg@amazon.com', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10018, 'Betty', 'Dowderswell', 'bdowderswellh@stumbleupon.com', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10019, 'Florencia', 'Leeves', 'fleevesi@exblog.jp', 'Polygender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10020, 'Cass', 'Dawtry', 'cdawtryj@photobucket.com', 'Male');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10021, 'Terrye', 'Gero', 'tgerok@pen.io', 'Male');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10022, 'Danya', 'Mushett', 'dmushettl@mapquest.com', 'Male');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10023, 'Vivie', 'Doding', 'vdodingm@ning.com', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10024, 'Dall', 'Antonioni', 'dantonionin@timesonline.co.uk', 'Bigender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10025, 'Rosalie', 'Graffham', 'rgraffhamo@geocities.jp', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10026, 'Cully', 'Tooze', 'ctoozep@cmu.edu', 'Bigender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10027, 'Beaufort', 'Figge', 'bfiggeq@theguardian.com', 'Male');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10028, 'Aubree', 'Ayer', 'aayerr@cpanel.net', 'Male');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10029, 'Boycey', 'Klawi', 'bklawis@army.mil', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10030, 'Francklin', 'Piccard', 'fpiccardt@ustream.tv', 'Female');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10031, 'Audrey', 'Faraker', 'afarakeru@about.com', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10032, 'Reba', 'Hoggins', 'rhogginsv@freewebs.com', 'Polygender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10033, 'Almeria', 'Dominetti', 'adominettiw@wordpress.org', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10034, 'Waldo', 'Kiendl', 'wkiendlx@webnode.com', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10035, 'Marcella', 'Kryszka', 'mkryszkay@auda.org.au', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10036, 'Silvia', 'Orr', 'sorrz@toplist.cz', 'Female');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10037, 'Tatiania', 'Rennebach', 'trennebach10@nps.gov', 'Non-binary');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10038, 'Vernor', 'Minchinton', 'vminchinton11@ehow.com', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10039, 'Angil', 'Traylen', 'atraylen12@abc.net.au', 'Bigender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10040, 'Paulie', 'Elsmor', 'pelsmor13@wix.com', 'Female');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10041, 'Lindsey', 'Katzmann', 'lkatzmann14@google.de', 'Polygender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10042, 'Dolly', 'Hrynczyk', 'dhrynczyk15@kickstarter.com', 'Genderfluid');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10043, 'Josepha', 'Motte', 'jmotte16@nbcnews.com', 'Genderfluid');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10044, 'Spencer', 'Jack', 'sjack17@merriam-webster.com', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10045, 'Madelaine', 'Keysel', 'mkeysel18@gmpg.org', 'Female');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10046, 'Rem', 'Ruseworth', 'rruseworth19@omniture.com', 'Bigender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10047, 'Kendrick', 'Gyver', 'kgyver1a@princeton.edu', 'Polygender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10048, 'Orrin', 'Pestell', 'opestell1b@sitemeter.com', 'Bigender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10049, 'Clyde', 'Yeoland', 'cyeoland1c@state.gov', 'Genderfluid');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10050, 'Artemas', 'Posthill', 'aposthill1d@craigslist.org', 'Polygender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10051, 'Karmen', 'Davall', 'kdavall1e@youtube.com', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10052, 'Sioux', 'Rowbrey', 'srowbrey1f@netlog.com', 'Non-binary');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10053, 'Pascale', 'Stelfox', 'pstelfox1g@google.ca', 'Genderfluid');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10054, 'Ric', 'Frow', 'rfrow1h@dyndns.org', 'Male');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10055, 'Charin', 'Trayling', 'ctrayling1i@dedecms.com', 'Bigender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10056, 'Pet', 'McGirl', 'pmcgirl1j@apple.com', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10057, 'Dora', 'Ainger', 'dainger1k@quantcast.com', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10058, 'Emmanuel', 'Berntsson', 'eberntsson1l@hao123.com', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10059, 'Nikolia', 'Potzold', 'npotzold1m@t-online.de', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10060, 'Gwyneth', 'Jeannaud', 'gjeannaud1n@meetup.com', 'Genderfluid');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10061, 'Giacomo', 'Mishow', 'gmishow1o@webnode.com', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10062, 'Rodolph', 'Berks', 'rberks1p@dell.com', 'Polygender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10063, 'Clemence', 'Burgne', 'cburgne1q@disqus.com', 'Polygender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10064, 'Basilius', 'Axup', 'baxup1r@live.com', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10065, 'Kendal', 'Cawley', 'kcawley1s@a8.net', 'Genderfluid');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10066, 'Dorolice', 'Tams', 'dtams1t@uiuc.edu', 'Genderfluid');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10067, 'Orly', 'Munton', 'omunton1u@meetup.com', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10068, 'Marge', 'Sprules', 'msprules1v@soup.io', 'Female');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10069, 'Lizabeth', 'Baptist', 'lbaptist1w@vistaprint.com', 'Genderfluid');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10070, 'Janis', 'Josh', 'jjosh1x@google.com', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10071, 'Candi', 'Leynton', 'cleynton1y@t.co', 'Bigender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10072, 'Evonne', 'Glowacki', 'eglowacki1z@networkadvertising.org', 'Female');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10073, 'Jacky', 'Boobier', 'jboobier20@hud.gov', 'Female');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10074, 'Dougie', 'Longfield', 'dlongfield21@tamu.edu', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10075, 'Wendye', 'Schutt', 'wschutt22@imageshack.us', 'Female');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10076, 'Concordia', 'Denerley', 'cdenerley23@irs.gov', 'Female');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10077, 'Cinderella', 'MacAllister', 'cmacallister24@google.fr', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10078, 'Andras', 'Wornham', 'awornham25@pcworld.com', 'Polygender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10079, 'Kellia', 'Drinnan', 'kdrinnan26@hud.gov', 'Non-binary');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10080, 'Hale', 'Mirfield', 'hmirfield27@pen.io', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10081, 'Ibbie', 'Grimes', 'igrimes28@state.tx.us', 'Female');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10082, 'Rania', 'Seiller', 'rseiller29@stumbleupon.com', 'Male');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10083, 'Moshe', 'Frounks', 'mfrounks2a@amazon.co.uk', 'Genderfluid');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10084, 'Minette', 'Jelly', 'mjelly2b@wordpress.org', 'Female');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10085, 'Peta', 'Lenglet', 'plenglet2c@apache.org', 'Genderfluid');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10086, 'Gwendolen', 'Yves', 'gyves2d@flavors.me', 'Male');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10087, 'Robert', 'Hearns', 'rhearns2e@seattletimes.com', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10088, 'Basilio', 'Camp', 'bcamp2f@nbcnews.com', 'Genderfluid');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10089, 'Bride', 'Chritchley', 'bchritchley2g@bloglines.com', 'Genderfluid');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10090, 'Dell', 'Marshal', 'dmarshal2h@mtv.com', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10091, 'Edouard', 'Collington', 'ecollington2i@usgs.gov', 'Bigender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10092, 'Robena', 'Gaukrodge', 'rgaukrodge2j@e-recht24.de', 'Genderfluid');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10093, 'Lilian', 'Arnson', 'larnson2k@wp.com', 'Polygender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10094, 'Cheryl', 'Keeling', 'ckeeling2l@salon.com', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10095, 'Sherline', 'Bau', 'sbau2m@quantcast.com', 'Male');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10096, 'Molli', 'Durnford', 'mdurnford2n@chicagotribune.com', 'Polygender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10097, 'Ripley', 'Enochsson', 'renochsson2o@skyrock.com', 'Polygender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10098, 'Margarethe', 'Corhard', 'mcorhard2p@virginia.edu', 'Genderqueer');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10099, 'Joanie', 'Hothersall', 'jhothersall2q@army.mil', 'Agender');
insert into Buyer (buyer_id, first_name, last_name, email, gender) values (10100, 'Rourke', 'Clubbe', 'rclubbe2r@wikia.com', 'Male');


/* Insert into Car Table: */

insert into Car (car_id, car_model, car_make, car_color) values (30001, 'Silverado 3500', 'Chevrolet', 'Purple');
insert into Car (car_id, car_model, car_make, car_color) values (30002, '911', 'Porsche', 'Maroon');
insert into Car (car_id, car_model, car_make, car_color) values (30003, 'Camaro', 'Chevrolet', 'Khaki');
insert into Car (car_id, car_model, car_make, car_color) values (30004, 'Vibe', 'Pontiac', 'Mauv');
insert into Car (car_id, car_model, car_make, car_color) values (30005, 'S80', 'Volvo', 'Aquamarine');
insert into Car (car_id, car_model, car_make, car_color) values (30006, 'VehiCROSS', 'Isuzu', 'Khaki');
insert into Car (car_id, car_model, car_make, car_color) values (30007, 'CL', 'Acura', 'Indigo');
insert into Car (car_id, car_model, car_make, car_color) values (30008, 'rio', 'Volkswagen', 'Purple');
insert into Car (car_id, car_model, car_make, car_color) values (30009, 'Tercel', 'Toyota', 'Green');
insert into Car (car_id, car_model, car_make, car_color) values (30010, 'Frontier', 'Nissan', 'Khaki');
insert into Car (car_id, car_model, car_make, car_color) values (30011, 'Integra', 'Acura', 'Fuscia');
insert into Car (car_id, car_model, car_make, car_color) values (30012, 'Colorado', 'Chevrolet', 'Teal');
insert into Car (car_id, car_model, car_make, car_color) values (30013, 'C70', 'Volvo', 'Mauv');
insert into Car (car_id, car_model, car_make, car_color) values (30014, 'GTI', 'Volkswagen', 'Teal');
insert into Car (car_id, car_model, car_make, car_color) values (30015, 'Torrent', 'Pontiac', 'Maroon');
insert into Car (car_id, car_model, car_make, car_color) values (30016, 'Endeavor', 'Mitsubishi', 'Pink');
insert into Car (car_id, car_model, car_make, car_color) values (30017, 'Golf', 'Volkswagen', 'Pink');
insert into Car (car_id, car_model, car_make, car_color) values (30018, 'New Beetle', 'Volkswagen', 'Puce');
insert into Car (car_id, car_model, car_make, car_color) values (30019, 'Endeavor', 'Mitsubishi', 'Maroon');
insert into Car (car_id, car_model, car_make, car_color) values (30020, 'Spyder', 'Maserati', 'Pink');
insert into Car (car_id, car_model, car_make, car_color) values (30021, '300ZX', 'Nissan', 'Goldenrod');
insert into Car (car_id, car_model, car_make, car_color) values (30022, 'Rally Wagon 3500', 'GMC', 'Fuscia');
insert into Car (car_id, car_model, car_make, car_color) values (30023, 'Explorer Sport Trac', 'Ford', 'Crimson');
insert into Car (car_id, car_model, car_make, car_color) values (30024, 'Mighty Max', 'Mitsubishi', 'Mauv');
insert into Car (car_id, car_model, car_make, car_color) values (30025, 'MKX', 'Lincoln', 'Indigo');
insert into Car (car_id, car_model, car_make, car_color) values (30026, 'Thunderbird', 'Ford', 'Mauv');
insert into Car (car_id, car_model, car_make, car_color) values (30027, 'Boxster', 'Porsche', 'Fuscia');
insert into Car (car_id, car_model, car_make, car_color) values (30028, 'Maxima', 'Nissan', 'Yellow');
insert into Car (car_id, car_model, car_make, car_color) values (30029, 'Pajero', 'Mitsubishi', 'Yellow');
insert into Car (car_id, car_model, car_make, car_color) values (30030, 'XK', 'Jaguar', 'Pink');
insert into Car (car_id, car_model, car_make, car_color) values (30031, 'Land Cruiser', 'Toyota', 'Blue');
insert into Car (car_id, car_model, car_make, car_color) values (30032, '8 Series', 'BMW', 'Goldenrod');
insert into Car (car_id, car_model, car_make, car_color) values (30033, 'Discovery Series II', 'Land Rover', 'Blue');
insert into Car (car_id, car_model, car_make, car_color) values (30034, 'Savana 1500', 'GMC', 'Red');
insert into Car (car_id, car_model, car_make, car_color) values (30035, '6000', 'Pontiac', 'Aquamarine');
insert into Car (car_id, car_model, car_make, car_color) values (30036, 'GTO', 'Mitsubishi', 'Pink');
insert into Car (car_id, car_model, car_make, car_color) values (30037, 'Firebird', 'Pontiac', 'Turquoise');
insert into Car (car_id, car_model, car_make, car_color) values (30038, 'Silverado 3500', 'Chevrolet', 'Khaki');
insert into Car (car_id, car_model, car_make, car_color) values (30039, 'Tiburon', 'Hyundai', 'Green');
insert into Car (car_id, car_model, car_make, car_color) values (30040, '500E', 'Mercedes-Benz', 'Fuscia');
insert into Car (car_id, car_model, car_make, car_color) values (30041, 'Justy', 'Subaru', 'Crimson');
insert into Car (car_id, car_model, car_make, car_color) values (30042, 'Golf', 'Volkswagen', 'Green');
insert into Car (car_id, car_model, car_make, car_color) values (30043, '7 Series', 'BMW', 'Aquamarine');
insert into Car (car_id, car_model, car_make, car_color) values (30044, 'Integra', 'Acura', 'Aquamarine');
insert into Car (car_id, car_model, car_make, car_color) values (30045, 'Outback', 'Subaru', 'Red');
insert into Car (car_id, car_model, car_make, car_color) values (30046, 'Esprit', 'Lotus', 'Aquamarine');
insert into Car (car_id, car_model, car_make, car_color) values (30047, 'Swift', 'Suzuki', 'Crimson');
insert into Car (car_id, car_model, car_make, car_color) values (30048, 'Cutlass Cruiser', 'Oldsmobile', 'Indigo');
insert into Car (car_id, car_model, car_make, car_color) values (30049, '911', 'Porsche', 'Aquamarine');
insert into Car (car_id, car_model, car_make, car_color) values (30050, 'Xterra', 'Nissan', 'Maroon');
insert into Car (car_id, car_model, car_make, car_color) values (30051, 'Sonoma', 'GMC', 'Crimson');
insert into Car (car_id, car_model, car_make, car_color) values (30052, 'Stratus', 'Dodge', 'Mauv');
insert into Car (car_id, car_model, car_make, car_color) values (30053, '6000', 'Pontiac', 'Puce');
insert into Car (car_id, car_model, car_make, car_color) values (30054, 'E-Series', 'Ford', 'Fuscia');
insert into Car (car_id, car_model, car_make, car_color) values (30055, 'M5', 'BMW', 'Green');
insert into Car (car_id, car_model, car_make, car_color) values (30056, 'J', 'Infiniti', 'Yellow');
insert into Car (car_id, car_model, car_make, car_color) values (30057, 'CR-V', 'Honda', 'Red');
insert into Car (car_id, car_model, car_make, car_color) values (30058, 'Suburban', 'Chevrolet', 'Goldenrod');
insert into Car (car_id, car_model, car_make, car_color) values (30059, 'XL7', 'Suzuki', 'Fuscia');
insert into Car (car_id, car_model, car_make, car_color) values (30060, 'Continental', 'Bentley', 'Puce');
insert into Car (car_id, car_model, car_make, car_color) values (30061, 'SLR McLaren', 'Mercedes-Benz', 'Indigo');
insert into Car (car_id, car_model, car_make, car_color) values (30062, 'xB', 'Scion', 'Purple');
insert into Car (car_id, car_model, car_make, car_color) values (30063, 'G6', 'Pontiac', 'Teal');
insert into Car (car_id, car_model, car_make, car_color) values (30064, '911', 'Porsche', 'Green');
insert into Car (car_id, car_model, car_make, car_color) values (30065, 'Uplander', 'Chevrolet', 'Crimson');
insert into Car (car_id, car_model, car_make, car_color) values (30066, 'Sable', 'Mercury', 'Turquoise');
insert into Car (car_id, car_model, car_make, car_color) values (30067, 'Sephia', 'Kia', 'Mauv');
insert into Car (car_id, car_model, car_make, car_color) values (30068, 'Sonata', 'Hyundai', 'Khaki');
insert into Car (car_id, car_model, car_make, car_color) values (30069, 'SL-Class', 'Mercedes-Benz', 'Blue');
insert into Car (car_id, car_model, car_make, car_color) values (30070, 'Thunderbird', 'Ford', 'Aquamarine');
insert into Car (car_id, car_model, car_make, car_color) values (30071, 'Ram 2500', 'Dodge', 'Yellow');
insert into Car (car_id, car_model, car_make, car_color) values (30072, 'TL', 'Acura', 'Turquoise');
insert into Car (car_id, car_model, car_make, car_color) values (30073, 'Regal', 'Buick', 'Crimson');
insert into Car (car_id, car_model, car_make, car_color) values (30074, 'Mark VIII', 'Lincoln', 'Teal');
insert into Car (car_id, car_model, car_make, car_color) values (30075, 'Sierra 1500', 'GMC', 'Crimson');
insert into Car (car_id, car_model, car_make, car_color) values (30076, 'CLK-Class', 'Mercedes-Benz', 'Pink');
insert into Car (car_id, car_model, car_make, car_color) values (30077, 'GTI', 'Volkswagen', 'Yellow');
insert into Car (car_id, car_model, car_make, car_color) values (30078, 'Civic', 'Honda', 'Goldenrod');
insert into Car (car_id, car_model, car_make, car_color) values (30079, 'Prius', 'Toyota', 'Maroon');
insert into Car (car_id, car_model, car_make, car_color) values (30080, 'Tiburon', 'Hyundai', 'Orange');
insert into Car (car_id, car_model, car_make, car_color) values (30081, 'Grand Prix', 'Pontiac', 'Goldenrod');
insert into Car (car_id, car_model, car_make, car_color) values (30082, 'X5 M', 'BMW', 'Teal');
insert into Car (car_id, car_model, car_make, car_color) values (30083, 'Prowler', 'Plymouth', 'Maroon');
insert into Car (car_id, car_model, car_make, car_color) values (30084, 'Ram 3500', 'Dodge', 'Turquoise');
insert into Car (car_id, car_model, car_make, car_color) values (30085, 'S6', 'Audi', 'Fuscia');
insert into Car (car_id, car_model, car_make, car_color) values (30086, 'E-Series', 'Ford', 'Pink');
insert into Car (car_id, car_model, car_make, car_color) values (30087, 'Corvette', 'Chevrolet', 'Turquoise');
insert into Car (car_id, car_model, car_make, car_color) values (30088, 'Neon', 'Plymouth', 'Turquoise');
insert into Car (car_id, car_model, car_make, car_color) values (30089, 'New Beetle', 'Volkswagen', 'Red');
insert into Car (car_id, car_model, car_make, car_color) values (30090, 'CR-V', 'Honda', 'Crimson');
insert into Car (car_id, car_model, car_make, car_color) values (30091, 'Cayenne', 'Porsche', 'Maroon');
insert into Car (car_id, car_model, car_make, car_color) values (30092, 'Miata MX-5', 'Mazda', 'Fuscia');
insert into Car (car_id, car_model, car_make, car_color) values (30093, 'SVX', 'Subaru', 'Red');
insert into Car (car_id, car_model, car_make, car_color) values (30094, 'Laser', 'Ford', 'Crimson');
insert into Car (car_id, car_model, car_make, car_color) values (30095, 'Wrangler', 'Jeep', 'Khaki');
insert into Car (car_id, car_model, car_make, car_color) values (30096, 'Century', 'Buick', 'Orange');
insert into Car (car_id, car_model, car_make, car_color) values (30097, 'Tacoma', 'Toyota', 'Yellow');
insert into Car (car_id, car_model, car_make, car_color) values (30098, 'Sierra 2500', 'GMC', 'Red');
insert into Car (car_id, car_model, car_make, car_color) values (30099, 'Econoline E250', 'Ford', 'Green');
insert into Car (car_id, car_model, car_make, car_color) values (30100, 'Elise', 'Lotus', 'Crimson');


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO Purchase
SELECT buyer_id, car_id, FLOOR(1+(RANDOM()+9223372036854775808)/2.0/9223372036854775808 * 44) AS num, FLOOR(100000+(RANDOM()+9223372036854775808)/2.0/9223372036854775808 * 200000) AS price
FROM
(SELECT FLOOR(1+(RANDOM()+9223372036854775808)/2.0/9223372036854775808 * 10) AS RndNum, buyer_id FROM Buyer) b, 
(SELECT FLOOR(1+(RANDOM()+9223372036854775808)/2.0/9223372036854775808 * 10) AS RndNum, car_id FROM Car) c
WHERE b.RndNum = c.RndNum;

SELECT * from Purchase ORDER BY RANDOM() LIMIT(10);



