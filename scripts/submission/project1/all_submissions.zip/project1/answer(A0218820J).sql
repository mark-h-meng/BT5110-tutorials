/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*  Student: Yu Zhe    Student_id: A0218820J                                                                     */
/************************************************************************/

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */

/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */

/*There are three  tables in this answer sheet, including two entities tables named customer and grocery,                   */
/*  and one relationship table named purchase:                                                                              */
  
/*customer table: indicates the basic customer info, including customer id, full name and the country of the customer lived. */
/* Table schema: customer (customer_id, customer, full_name, country)   */                                                    
/*PRIMARY KEY: customer_id                                              */

/*grocery table: indicates the grocery products info, including their id, name, country of origin and price.    */
/*Table schema: grocery(product_id, product_name, country_of_origin, price)                                     */
/*PRIMARY KEY: product_id                                                                                       */

/*purchase table: indicates the purchases that associate customers with the products they purchased. */
/*                This table also records the transaction time and quantity as extra attributes.    */
/*Table schema:                                                                                     */
/*CREATE TABLE purchase(customer_id, product_id, payment_time, quantity)                           */
/*PRIMARY KEY(ustomer_id, product_id, payment_time)                                                */                                                              
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DROP TABLE if EXISTS customer, grocery, purchase;

CREATE TABLE customer 
(customer_id int PRIMARY KEY, 
full_name varchar, 
country varchar);

CREATE TABLE grocery 
(product_id int PRIMARY KEY,
 product_name varchar, 
 country_of_origin varchar NOT NULL,
 price DECIMAL(3,1) NOT NULL CHECK (price >0));

CREATE TABLE purchase 
(customer_id int REFERENCES  customer (customer_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED, 
 product_id int REFERENCES  grocery (product_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED, 
 payment_time time,
 quantity int NOT NULL CHECK (quantity>0),
 PRIMARY KEY (customer_id,product_id,payment_time));
 
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into grocery (Product_id, Product_name, country_of_origin, price) values (1, 'Tomato - Plum With Basil', 'Portugal', 4.7);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (2, 'Cheese - Cottage Cheese', 'Macedonia', 17.1);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (3, 'Jolt Cola', 'France', 13.2);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (4, 'Persimmons', 'Burundi', 14.0);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (5, 'Eggplant - Asian', 'Grenada', 5.0);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (6, 'Wine - Prem Select Charddonany', 'France', 15.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (7, 'Cranberries - Frozen', 'United States', 5.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (8, 'Icecream - Dstk Super Cone', 'United States', 6.3);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (9, 'Wine - White, Chardonnay', 'Russia', 8.4);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (10, 'Towel Multifold', 'Morocco', 5.0);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (11, 'Bread - English Muffin', 'Indonesia', 6.0);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (12, 'Venison - Ground', 'Thailand', 12.7);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (13, 'Salmon - Whole, 4 - 6 Pounds', 'Philippines', 4.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (14, 'Monkfish - Fresh', 'Philippines', 3.8);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (15, 'Spoon - Soup, Plastic', 'China', 2.6);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (16, 'Truffle Cups - Brown', 'Japan', 4.1);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (17, 'Crab - Soft Shell', 'Russia', 9.8);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (18, 'Nantucket - Orange Mango Cktl', 'Indonesia', 8.7);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (19, 'Mikes Hard Lemonade', 'Indonesia', 10.8);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (20, 'Wine - Chianti Classica Docg', 'Thailand', 13.4);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (21, 'Cabbage - Red', 'Japan', 7.4);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (22, 'Plaintain', 'Brazil', 10.4);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (23, 'Cherries - Frozen', 'Seychelles', 6.3);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (24, 'Lettuce - Baby Salad Greens', 'Poland', 11.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (25, 'Truffle - Peelings', 'Central African Republic', 18.6);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (26, 'Bread - Pumpernickle, Rounds', 'Botswana', 11.0);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (27, 'Fish - Soup Base, Bouillon', 'China', 19.3);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (28, 'Cheese - Pied De Vents', 'China', 15.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (29, 'Puff Pastry - Slab', 'China', 13.8);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (30, 'Beans - Black Bean, Preserved', 'United States', 1.6);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (31, 'Wine - Periguita Fonseca', 'France', 13.7);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (32, 'Rum - Light, Captain Morgan', 'Colombia', 18.4);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (33, 'Beets', 'Japan', 4.8);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (34, 'Wine - White, Concha Y Toro', 'Russia', 13.0);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (35, 'Pork - Side Ribs', 'Greece', 15.6);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (36, 'Wine - Vineland Estate Semi - Dry', 'Indonesia', 5.2);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (37, 'Pork Loin Bine - In Frenched', 'China', 2.4);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (38, 'Wine - Magnotta - Cab Franc', 'Mexico', 15.6);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (39, 'Bread - Burger', 'Uganda', 15.6);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (40, 'Steel Wool', 'Saudi Arabia', 7.1);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (41, 'Mushroom - White Button', 'Russia', 6.7);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (42, 'Bagel - Everything', 'Philippines', 3.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (43, 'Sauce - Vodka Blush', 'China', 1.6);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (44, 'Pear - Asian', 'Russia', 10.0);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (45, 'Soup - Campbells, Creamy', 'China', 17.2);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (46, 'Tart Shells - Sweet, 2', 'Sweden', 17.2);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (47, 'Pie Filling - Cherry', 'Finland', 8.2);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (48, 'Lemonade - Island Tea, 591 Ml', 'Argentina', 8.9);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (49, 'Frangelico', 'Indonesia', 1.2);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (50, 'Crackers - Graham', 'France', 9.6);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (51, 'Silicone Parch. 16.3x24.3', 'Armenia', 16.3);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (52, 'Nut - Pumpkin Seeds', 'Indonesia', 9.6);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (53, 'Okra', 'Brazil', 6.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (54, 'Hersey Shakes', 'France', 16.9);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (55, 'Truffle Cups - Red', 'Peru', 7.0);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (56, 'Apple - Custard', 'Russia', 2.4);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (57, 'Truffle Shells - White Chocolate', 'Poland', 5.9);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (58, 'Rice - Jasmine Sented', 'China', 9.9);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (59, 'Smoked Tongue', 'China', 14.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (60, 'Cleaner - Bleach', 'China', 9.9);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (61, 'Veal - Bones', 'China', 16.1);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (62, 'Mushroom - Portebello', 'Brazil', 13.3);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (63, 'Bar Mix - Pina Colada, 355 Ml', 'France', 18.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (64, 'Pate - Liver', 'Slovenia', 10.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (65, 'Chocolate Bar - Reese Pieces', 'China', 2.4);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (66, 'Island Oasis - Strawberry', 'Chile', 12.9);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (67, 'Godiva White Chocolate', 'Colombia', 19.6);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (68, 'Flour - Semolina', 'France', 10.3);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (69, 'Bread - Olive Dinner Roll', 'Finland', 16.7);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (70, 'Chicken - Leg / Back Attach', 'Brazil', 11.7);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (71, 'Mix - Cocktail Strawberry Daiquiri', 'Mongolia', 8.6);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (72, 'Bread - Kimel Stick Poly', 'Greece', 13.7);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (73, 'Sour Puss Sour Apple', 'Venezuela', 4.0);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (74, 'Pate - Peppercorn', 'France', 4.7);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (75, 'Chocolate - Liqueur Cups With Foil', 'Dominica', 5.4);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (76, 'Tea - Jasmin Green', 'Greece', 3.7);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (77, 'Cake - Mini Cheesecake', 'Sweden', 16.1);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (78, 'The Pop Shoppe - Cream Soda', 'Brazil', 8.4);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (79, 'Mushroom - Chanterelle Frozen', 'Russia', 11.4);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (80, 'Wine - Alicanca Vinho Verde', 'Turkmenistan', 16.7);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (81, 'Steampan - Foil', 'China', 3.0);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (82, 'Bols Melon Liqueur', 'Sweden', 19.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (83, 'Beef - Short Ribs', 'Poland', 13.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (84, 'Milk - Skim', 'Poland', 5.6);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (85, 'Beans - Butter Lrg Lima', 'Indonesia', 3.7);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (86, 'Pastry - Trippleberry Muffin - Mini', 'Philippines', 9.4);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (87, 'Lettuce Romaine Chopped', 'Czech Republic', 2.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (88, 'Flower - Daisies', 'China', 1.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (89, 'Salmon - Whole, 4 - 6 Pounds', 'Argentina', 9.0);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (90, 'Chicken - White Meat With Tender', 'France', 16.3);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (91, 'Eel Fresh', 'Indonesia', 13.2);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (92, 'Beans - Long, Chinese', 'Indonesia', 10.2);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (93, 'Red Currant Jelly', 'China', 10.4);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (94, 'Chocolate - Milk, Callets', 'Indonesia', 13.5);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (95, 'Marzipan 50/50', 'Macedonia', 15.7);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (96, 'Glass - Wine, Plastic, Clear 5 Oz', 'Indonesia', 5.6);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (97, 'Muffin Mix - Oatmeal', 'China', 11.1);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (98, 'Cheese - Blue', 'Indonesia', 14.8);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (99, 'Jolt Cola', 'China', 11.0);
insert into grocery (Product_id, Product_name, country_of_origin, price) values (100, 'Ecolab - Mikroklene 4/4 L', 'Honduras', 11.2);



insert into customer (customer_id, full_name, country) values (1, 'Claiborne Leppington', 'Malta');
insert into customer (customer_id, full_name, country) values (2, 'Ede Birkenshaw', 'China');
insert into customer (customer_id, full_name, country) values (3, 'Afton Pinilla', 'China');
insert into customer (customer_id, full_name, country) values (4, 'Maryann Terrans', 'Macedonia');
insert into customer (customer_id, full_name, country) values (5, 'Barbara-anne Kennham', 'Togo');
insert into customer (customer_id, full_name, country) values (6, 'Jackie Shovelton', 'Russia');
insert into customer (customer_id, full_name, country) values (7, 'Mychal Parrett', 'China');
insert into customer (customer_id, full_name, country) values (8, 'Mariann Cunrado', 'Indonesia');
insert into customer (customer_id, full_name, country) values (9, 'Glory Sayes', 'Portugal');
insert into customer (customer_id, full_name, country) values (10, 'Corilla Hould', 'China');
insert into customer (customer_id, full_name, country) values (11, 'Tasha Baulcombe', 'Brazil');
insert into customer (customer_id, full_name, country) values (12, 'Frances MacDowall', 'Russia');
insert into customer (customer_id, full_name, country) values (13, 'Tricia Playden', 'Bangladesh');
insert into customer (customer_id, full_name, country) values (14, 'Yoko Hiscocks', 'Uzbekistan');
insert into customer (customer_id, full_name, country) values (15, 'Tammy Caughtry', 'Indonesia');
insert into customer (customer_id, full_name, country) values (16, 'Oralle Potkins', 'Brazil');
insert into customer (customer_id, full_name, country) values (17, 'Benito Pautot', 'Israel');
insert into customer (customer_id, full_name, country) values (18, 'Dwain Matthews', 'Bosnia and Herzegovina');
insert into customer (customer_id, full_name, country) values (19, 'Tessi Voak', 'Brazil');
insert into customer (customer_id, full_name, country) values (20, 'Nanette Mawby', 'Indonesia');
insert into customer (customer_id, full_name, country) values (21, 'Giles Muldowney', 'Pakistan');
insert into customer (customer_id, full_name, country) values (22, 'Abagail Andrivel', 'Indonesia');
insert into customer (customer_id, full_name, country) values (23, 'Davis Sambles', 'Afghanistan');
insert into customer (customer_id, full_name, country) values (24, 'Nedda Schroter', 'Armenia');
insert into customer (customer_id, full_name, country) values (25, 'Caddric Gawkroge', 'Luxembourg');
insert into customer (customer_id, full_name, country) values (26, 'Libbie Vials', 'China');
insert into customer (customer_id, full_name, country) values (27, 'Todd Ladbury', 'Indonesia');
insert into customer (customer_id, full_name, country) values (28, 'Marje Peetermann', 'China');
insert into customer (customer_id, full_name, country) values (29, 'Ulrich McIan', 'Portugal');
insert into customer (customer_id, full_name, country) values (30, 'Augustin Glaisner', 'China');
insert into customer (customer_id, full_name, country) values (31, 'Parnell Kundert', 'Japan');
insert into customer (customer_id, full_name, country) values (32, 'Maryjane Chidwick', 'Poland');
insert into customer (customer_id, full_name, country) values (33, 'Patrica Cattenach', 'Gambia');
insert into customer (customer_id, full_name, country) values (34, 'Flor Garralts', 'Canada');
insert into customer (customer_id, full_name, country) values (35, 'Shel Higford', 'China');
insert into customer (customer_id, full_name, country) values (36, 'Georgine Speake', 'China');
insert into customer (customer_id, full_name, country) values (37, 'Lorrie Brimfield', 'Czech Republic');
insert into customer (customer_id, full_name, country) values (38, 'Reggis Wildbore', 'Czech Republic');
insert into customer (customer_id, full_name, country) values (39, 'Mellisent Manketell', 'Portugal');
insert into customer (customer_id, full_name, country) values (40, 'Chancey Kaysor', 'Argentina');
insert into customer (customer_id, full_name, country) values (41, 'Humfrey Loudiane', 'Poland');
insert into customer (customer_id, full_name, country) values (42, 'Desiri Hulcoop', 'Vietnam');
insert into customer (customer_id, full_name, country) values (43, 'Elroy Paffitt', 'Ireland');
insert into customer (customer_id, full_name, country) values (44, 'Doug Rodger', 'Sweden');
insert into customer (customer_id, full_name, country) values (45, 'Demeter Dahlman', 'Chile');
insert into customer (customer_id, full_name, country) values (46, 'Al Borwick', 'China');
insert into customer (customer_id, full_name, country) values (47, 'Carolyn Warner', 'Portugal');
insert into customer (customer_id, full_name, country) values (48, 'Bab Coats', 'Finland');
insert into customer (customer_id, full_name, country) values (49, 'Budd Lodin', 'Russia');
insert into customer (customer_id, full_name, country) values (50, 'Gonzales Quinevan', 'Vietnam');
insert into customer (customer_id, full_name, country) values (51, 'Frederique Ouslem', 'China');
insert into customer (customer_id, full_name, country) values (52, 'Truman Franzman', 'China');
insert into customer (customer_id, full_name, country) values (53, 'Sarah Baggot', 'Japan');
insert into customer (customer_id, full_name, country) values (54, 'Conant Jemmett', 'Azerbaijan');
insert into customer (customer_id, full_name, country) values (55, 'Alva Scarr', 'United States');
insert into customer (customer_id, full_name, country) values (56, 'Doretta Beveredge', 'Sweden');
insert into customer (customer_id, full_name, country) values (57, 'Rosalyn Fockes', 'Russia');
insert into customer (customer_id, full_name, country) values (58, 'Christabella Ship', 'Indonesia');
insert into customer (customer_id, full_name, country) values (59, 'Bendite Lillegard', 'Brazil');
insert into customer (customer_id, full_name, country) values (60, 'Eyde Cappel', 'Ukraine');
insert into customer (customer_id, full_name, country) values (61, 'Arvy Golightly', 'Uruguay');
insert into customer (customer_id, full_name, country) values (62, 'Eloisa Cockroft', 'China');
insert into customer (customer_id, full_name, country) values (63, 'Shelbi Herche', 'Indonesia');
insert into customer (customer_id, full_name, country) values (64, 'Reyna Finessy', 'Paraguay');
insert into customer (customer_id, full_name, country) values (65, 'Donica Duchesne', 'Japan');
insert into customer (customer_id, full_name, country) values (66, 'Edita Spadoni', 'China');
insert into customer (customer_id, full_name, country) values (67, 'Terencio Langdon', 'Albania');
insert into customer (customer_id, full_name, country) values (68, 'Kamilah Reinbech', 'United States');
insert into customer (customer_id, full_name, country) values (69, 'Clarice Stokell', 'Canada');
insert into customer (customer_id, full_name, country) values (70, 'Frazier Poynton', 'Czech Republic');
insert into customer (customer_id, full_name, country) values (71, 'Rusty Sackler', 'Vanuatu');
insert into customer (customer_id, full_name, country) values (72, 'Wash Southard', 'China');
insert into customer (customer_id, full_name, country) values (73, 'Wilden Scotchmore', 'Peru');
insert into customer (customer_id, full_name, country) values (74, 'Herve Juan', 'Russia');
insert into customer (customer_id, full_name, country) values (75, 'Jilli Greenhalf', 'Cameroon');
insert into customer (customer_id, full_name, country) values (76, 'Jordana Reymers', 'Indonesia');
insert into customer (customer_id, full_name, country) values (77, 'Penrod Henzley', 'Philippines');
insert into customer (customer_id, full_name, country) values (78, 'Loni Foxwell', 'United States');
insert into customer (customer_id, full_name, country) values (79, 'Husein Shalcras', 'Brazil');
insert into customer (customer_id, full_name, country) values (80, 'Eric Borrie', 'Thailand');
insert into customer (customer_id, full_name, country) values (81, 'Hilliary Ratchford', 'Thailand');
insert into customer (customer_id, full_name, country) values (82, 'Vally Rennard', 'Portugal');
insert into customer (customer_id, full_name, country) values (83, 'Dreddy Coldbathe', 'Sweden');
insert into customer (customer_id, full_name, country) values (84, 'Heida Boots', 'Peru');
insert into customer (customer_id, full_name, country) values (85, 'Robb Jossum', 'Ireland');
insert into customer (customer_id, full_name, country) values (86, 'Marijn Branston', 'Finland');
insert into customer (customer_id, full_name, country) values (87, 'Garrott Faithorn', 'Switzerland');
insert into customer (customer_id, full_name, country) values (88, 'Nadeen Shepcutt', 'Peru');
insert into customer (customer_id, full_name, country) values (89, 'Aubrie Torbard', 'Mexico');
insert into customer (customer_id, full_name, country) values (90, 'Brien Stanbrooke', 'Dominican Republic');
insert into customer (customer_id, full_name, country) values (91, 'Bobine Haighton', 'China');
insert into customer (customer_id, full_name, country) values (92, 'West Hammerman', 'Indonesia');
insert into customer (customer_id, full_name, country) values (93, 'Mariquilla Wistance', 'China');
insert into customer (customer_id, full_name, country) values (94, 'Cindra Saltern', 'Poland');
insert into customer (customer_id, full_name, country) values (95, 'Nelie Dews', 'Vietnam');
insert into customer (customer_id, full_name, country) values (96, 'Gaby Bratt', 'China');
insert into customer (customer_id, full_name, country) values (97, 'Ulrika Newell', 'Indonesia');
insert into customer (customer_id, full_name, country) values (98, 'Davida Killshaw', 'Tunisia');
insert into customer (customer_id, full_name, country) values (99, 'Domenic Bragger', 'Mexico');
insert into customer (customer_id, full_name, country) values (100, 'Bari Baumann', 'Colombia');
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO purchase(customer_id, product_id, quantity,payment_time)
(SELECT c.customer_id, 
        g.product_id, 
        FLOOR(RANDOM()*10+1), 
		timestamp '2021-01-10' +random() * (timestamp '2021-01-01' -timestamp '2021-8-20')           
FROM customer c, grocery g
ORDER BY 1
LIMIT 1000)
ON CONFLICT DO NOTHING;




