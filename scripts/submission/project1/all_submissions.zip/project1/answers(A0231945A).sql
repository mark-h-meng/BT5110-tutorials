/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
There tables are created to simulate stock trading database, recording the trading data, only the investment part.We don't take stock redemption into account。
First, create a table 'investors' for investor set.
Table 'investors' has four attributes:credit_card_id,first_name, last_name and person_stock_market.
Credit_card_id is also the primary key to identify the investors.

Second, create a table 'stocks' for stock set.
Table 'stocks' has four attributes:stock_symbol, stock_name,stock_market_cap and stock_market.
The stock symbol is chosen to be the primary key to identify the stocks.

Third, create a table investment associating investor's credit card number to stock symbol.
Table 'investment' has five attributes: credit_card_id, stock_symbol, stock_market, invest_date, invest_dollar.
'invest_dollar' is to record the amount of money invested by the investors(unit:dollar) and invest_date is to record the investment date.
This investment relationship constaints that investors only invest in the stock market they aim at, like NASDAQ.
(credit_card_id, stock_symbol, invest_date) was set as the primary key.

Table 'investors' and table 'stocks' are filled with 100 rows.
Table 'investment' provides 1000 rows of all the possible investment data, chosen randomly.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DROP TABLE investors CASCADE;;
DROP TABLE stocks CASCADE;;
DROP TABLE investment;
 
CREATE TABLE IF NOT EXISTS investors(
	credit_card BIGINT PRIMARY KEY,
	first_name  CHAR(50)   NOT NULL,
	last_name   CHAR(50)   NOT NULL,
	person_stock_market CHAR(10) NOT NULL CONSTRAINT format 
	CHECK(person_stock_market = 'NASDAQ' OR person_stock_market ='NYSE')
);

CREATE TABLE IF NOT EXISTS stocks(
	stock_symbol CHAR(100) PRIMARY KEY,
	stock_name  CHAR(100) NOT NULL,
	stock_market_cap CHAR(100) NOT NULL,
	stock_market CHAR(10) NOT NULL
);

CREATE TABLE IF NOT EXISTS investment(
	credit_card_id   BIGINT,
	stock_symbol CHAR(100) NOT NULL,
	stock_market CHAR(10) NOT NULL,
	invest_date DATE NOT NULL,
	invest_dollar INT NOT NULL,	
	FOREIGN KEY (credit_card_id) REFERENCES investors(credit_card)
	ON UPDATE CASCADE ON DELETE CASCADE
	DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY (stock_symbol) REFERENCES stocks(stock_symbol)
	ON UPDATE CASCADE ON DELETE CASCADE
	DEFERRABLE INITIALLY DEFERRED,
	PRIMARY KEY (credit_card_id, stock_symbol,invest_date)
);



/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('372301893209769', 'Matthaeus', 'Balffye', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('490523761034289577', 'Matthew', 'Thying', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('630421212805200629', 'Nicola', 'Bridell', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('337941567120414', 'Langsdon', 'Argontt', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3554300241674892', 'Terri', 'Slowgrave', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5602232608969648', 'Stacee', 'Bosley', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5602254391617994', 'Nowell', 'Isac', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('50181586407604994', 'Anna-maria', 'Odd', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('30437028114765', 'Luise', 'Cawtheray', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('4844896398427750', 'Alisun', 'Tal', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3558533994901767', 'Catlee', 'Bellord', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5251575351664145', 'Isak', 'Lidgertwood', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5470105524977870', 'Greggory', 'Jemmison', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5038982790449563785', 'Verge', 'Elgram', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3550928299239632', 'Maxie', 'McNess', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5563281056008406', 'Vivianne', 'Basten', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5100175845203999', 'Powell', 'Pretorius', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3571812530104927', 'Caryn', 'Ferrulli', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5395014026062698', 'Kanya', 'Pere', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3561707443094367', 'Torin', 'Ginnelly', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3585984256045834', 'Gipsy', 'Craw', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('372301386923140', 'Lek', 'Sadat', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('560223198147716217', 'Carlen', 'Valeri', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('67065311404610398', 'Hazlett', 'Kop', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5602233609437742', 'Carlee', 'Caldes', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('67093556325893715', 'Matias', 'Bisseker', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3586358663086856', 'Kasey', 'Galletly', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('201730563567493', 'Arly', 'Piser', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('4723058553358397', 'Drusi', 'Sagg', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3542145771056662', 'Shelby', 'Tregea', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('67628514395790497', 'Annelise', 'Bolden', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('4041595377607', 'Lorrie', 'McGlashan', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3549868320125067', 'Rowen', 'Terrey', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('4405334396755064', 'Agace', 'MacGebenay', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3535871525281707', 'Burlie', 'Millan', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3539906704069907', 'Essie', 'Gyse', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3579995358619530', 'Essie', 'Loosley', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3563534052346393', 'Even', 'Weaver', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3549730807434463', 'Thornie', 'Marrington', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('560222352775520992', 'Adoree', 'Allanby', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('6767101716464504', 'Cornela', 'Colten', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3554419780144081', 'Bridgette', 'Gullan', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('374283923389290', 'Dot', 'Colvin', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5002351046075242', 'Leonard', 'Pailin', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('36807992498374', 'Zahara', 'McKennan', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3582318306415924', 'Yule', 'Tomasini', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3583677969198252', 'Herbie', 'Pinchbeck', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3580142567667961', 'Dasi', 'Sweedland', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3571894565683439', 'Carolynn', 'Rosbrough', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5602223653988831', 'Nollie', 'McAlees', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3541972672082633', 'Maximilian', 'Baysting', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3583783158187112', 'Essie', 'Blanko', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('4508454474032248', 'Jarrid', 'Fogel', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3572531730754674', 'Adaline', 'Winsbury', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('6334951907395386', 'Clemmie', 'Coate', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3569313843272471', 'Jean', 'Slatten', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('6771128824621760', 'Allistir', 'Kier', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3565104816877329', 'Amalita', 'Segoe', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5893353896108095875', 'Eveleen', 'Dalinder', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('374288126407161', 'Teresa', 'Leadstone', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3577861584023537', 'Rosy', 'Terese', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5893587914259911531', 'Mia', 'Lydon', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('503815291435248235', 'Elisa', 'Chasier', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('6334425470869536325', 'Marne', 'Bostick', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3541538723496740', 'Thorn', 'Brunning', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5167506729255244', 'Lona', 'Parkman', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5602222495022304', 'Adore', 'Pauler', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('4844151703118557', 'Karisa', 'Krammer', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3528409894492057', 'Jessee', 'Cooke', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3531916157884635', 'Westbrook', 'Kearton', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3572245937735978', 'Evelin', 'Draude', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('36945883879664', 'Theodore', 'Bramah', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3576338610188130', 'Amara', 'Spanton', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3550310815658159', 'Camala', 'Hirjak', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('6304007762277213', 'Tan', 'Shillam', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('374288607357729', 'Rosene', 'Brittian', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('30094061442668', 'Nari', 'Cramphorn', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3579208912539479', 'Nollie', 'Bloxsum', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3575014274251461', 'Timothea', 'Salack', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('6333348515140703', 'Iggy', 'Langstrath', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3552744387072019', 'Saraann', 'Fackney', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('201472707922454', 'Alma', 'Drakes', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('6398813965489415', 'Kerstin', 'Endrici', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5018133379326085136', 'Aubrey', 'Yarrell', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('201529050203525', 'Dulcea', 'Lyal', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5602214357025228', 'Cobby', 'Geeraert', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5459901481636201', 'Lorraine', 'Andrick', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3581760036391423', 'Candis', 'Pallin', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('30183061613335', 'Carrie', 'Roose', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3576319935927824', 'Pandora', 'Main', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('374622135614443', 'Fidel', 'Barton', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5602224482979173', 'Ronica', 'Gisbourn', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3554828931997215', 'Vincenty', 'Harnell', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('4913560032260227', 'Camel', 'Deboo', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3557281729598232', 'Bart', 'Ritelli', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3556753592177675', 'Camile', 'Laslett', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3565341205627085', 'Herculie', 'Olenchenko', 'NASDAQ');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('5100149803041097', 'Romola', 'Cheer', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('3564272038903461', 'Dania', 'Hawtrey', 'NYSE');
insert into investors (credit_card, first_name, last_name, person_stock_market) values ('6709201763263488793', 'Ricard', 'Veryard', 'NASDAQ');

insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('National CineMedia, Inc.', '$493.54M', 'NASDAQ', 'NCMI');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Trinseo S.A.', '$2.86B', 'NYSE', 'TSE');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('National Research Corporation', '$672.9M', 'NASDAQ', 'NRCIA');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Reading International Inc', '$404.69M', 'NASDAQ', 'RDIB');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Xcel Energy Inc.', '$24.27B', 'NYSE', 'XEL');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Western Alliance Bancorporation', 'n/a', 'NYSE', 'WALA');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Realogy Holdings Corp.', '$4.14B', 'NYSE', 'RLGY');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Qwest Corporation', 'n/a', 'NYSE', 'CTU');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Matlin & Partners Acquisition Corporation', '$393.25M', 'NASDAQ', 'MPAC');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Davis Select U.S. Equity ETF', 'n/a', 'NASDAQ', 'DUSA');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Black Hills Corporation', '$3.84B', 'NYSE', 'BKH');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Boston Beer Company, Inc. (The)', '$1.64B', 'NYSE', 'SAM');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Avenue Therapeutics, Inc.', 'n/a', 'NASDAQ', 'ATXI');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('AllianzGI Diversified Income & Convertible Fund', '$214.54M', 'NYSE', 'ACV');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('First Trust SSI Strategic Convertible Securities ETF', '$38.77M', 'NASDAQ', 'FCVT');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Healthcare Trust of America, Inc.', '$6.36B', 'NYSE', 'HTA');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Key Tronic Corporation', '$73.17M', 'NASDAQ', 'KTCC');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Rayonier Advanced Materials Inc.', 'n/a', 'NYSE', 'RYAM^A');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('M III Acquisition Corp.', 'n/a', 'NASDAQ', 'MIIIU');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('InnerWorkings, Inc.', '$583.72M', 'NASDAQ', 'INWK');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('United States Lime & Minerals, Inc.', '$432.95M', 'NASDAQ', 'USLM');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Schlumberger N.V.', '$95.29B', 'NYSE', 'SLB');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Star Bulk Carriers Corp.', '$516.53M', 'NASDAQ', 'SBLK');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Highway Holdings Limited', '$12.9M', 'NASDAQ', 'HIHO');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Newell Brands Inc.', '$26.5B', 'NYSE', 'NWL');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Tsakos Energy Navigation Ltd', 'n/a', 'NYSE', 'TNP^E');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Pernix Therapeutics Holdings, Inc.', '$44.57M', 'NASDAQ', 'PTX');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Campbell Soup Company', '$16.68B', 'NYSE', 'CPB');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('NovoCure Limited', '$1.3B', 'NASDAQ', 'NVCR');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('E.W. Scripps Company (The)', '$1.53B', 'NYSE', 'SSP');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Western Gas Partners, LP', '$8.39B', 'NYSE', 'WES');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Atkore International Group Inc.', '$1.39B', 'NYSE', 'ATKR');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Hasbro, Inc.', '$13.71B', 'NASDAQ', 'HAS');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Fluidigm Corporation', '$107.22M', 'NASDAQ', 'FLDM');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Fibrocell Science Inc', '$45.41M', 'NASDAQ', 'FCSC');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('New York Mortgage Trust, Inc.', 'n/a', 'NASDAQ', 'NYMTP');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Soligenix, Inc.', 'n/a', 'NASDAQ', 'SNGXW');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Sensus Healthcare, Inc.', '$52.75M', 'NASDAQ', 'SRTS');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('ProShares UltraShort Nasdaq Biotechnology', '$52.03M', 'NASDAQ', 'BIS');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Skechers U.S.A., Inc.', '$4.35B', 'NYSE', 'SKX');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Nike, Inc.', '$84.35B', 'NYSE', 'NKE');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Basic Energy Services, Inc.', '$595.41M', 'NYSE', 'BAS');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Reis, Inc', '$237.79M', 'NASDAQ', 'REIS');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Monmouth Real Estate Investment Corporation', '$1.1B', 'NYSE', 'MNR');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Oxbridge Re Holdings Limited', '$34.73M', 'NASDAQ', 'OXBR');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Magyar Bancorp, Inc.', '$71.3M', 'NASDAQ', 'MGYR');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Vector Group Ltd.', '$2.79B', 'NYSE', 'VGR');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Banco Santander, S.A.', 'n/a', 'NYSE', 'SAN^I');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Fifth Street Senior Floating Rate Corp.', '$219.23M', 'NASDAQ', 'FSFR');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('PowerShares FTSE RAFI US 1500 Small-Mid Portfolio', '$1.62B', 'NASDAQ', 'PRFZ');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Shire plc', '$49.84B', 'NASDAQ', 'SHPG');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('FutureFuel Corp.', '$644.87M', 'NYSE', 'FF');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Automatic Data Processing, Inc.', '$46.3B', 'NASDAQ', 'ADP');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Sucampo Pharmaceuticals, Inc.', '$448.39M', 'NASDAQ', 'SCMP');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Cavium, Inc.', '$4.48B', 'NASDAQ', 'CAVM');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Columbia Property Trust, Inc.', '$2.67B', 'NYSE', 'CXP');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Blackrock MuniYield Investment QualityFund', '$120.08M', 'NYSE', 'MFT');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Avis Budget Group, Inc.', '$1.84B', 'NASDAQ', 'CAR');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Group 1 Automotive, Inc.', '$1.28B', 'NYSE', 'GPI');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Verso Corporation', '$130.34M', 'NYSE', 'VRS');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('John B. Sanfilippo & Son, Inc.', '$696.39M', 'NASDAQ', 'JBSS');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Lions Gate Entertainment Corporation', 'n/a', 'NYSE', 'LGF.A');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Four Corners Property Trust, Inc.', '$1.53B', 'NYSE', 'FCPT');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Era Group, Inc.', '$187.18M', 'NYSE', 'ERA');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Bel Fuse Inc.', '$312.96M', 'NASDAQ', 'BELFB');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('PS Business Parks, Inc.', 'n/a', 'NYSE', 'PSB^W');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Transglobe Energy Corp', '$92.42M', 'NASDAQ', 'TGA');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Tactile Systems Technology, Inc.', '$445.86M', 'NASDAQ', 'TCMD');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('BGC Partners, Inc.', 'n/a', 'NYSE', 'BGCA');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('HealthEquity, Inc.', '$3.07B', 'NASDAQ', 'HQY');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Bank of America Corporation', 'n/a', 'NYSE', 'BAC^A');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Anadarko Petroleum Corporation', '$26.36B', 'NYSE', 'APC');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Albany Molecular Research, Inc.', '$929.63M', 'NASDAQ', 'AMRI');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Zions Bancorporation', 'n/a', 'NYSE', 'ZB^A');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Shoe Carnival, Inc.', '$345.67M', 'NASDAQ', 'SCVL');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('China XD Plastics Company Limited', '$235.18M', 'NASDAQ', 'CXDC');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Robert Half International Inc.', '$6.07B', 'NYSE', 'RHI');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Synacor, Inc.', '$129.26M', 'NASDAQ', 'SYNC');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Chesapeake Lodging Trust', 'n/a', 'NYSE', 'CHSP^A.CL');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('DMC Global Inc.', '$200.99M', 'NASDAQ', 'BOOM');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Piedmont Office Realty Trust, Inc.', '$3.1B', 'NYSE', 'PDM');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Drive Shack Inc.', 'n/a', 'NYSE', 'DS^C');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('REV Group, Inc.', '$1.92B', 'NYSE', 'REVG');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('PowerShares DWA NASDAQ Momentum Portfolio', '$35.54M', 'NASDAQ', 'DWAQ');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('First Trust Developed Markets ex-US Small Cap AlphaDEX Fund', '$7.7M', 'NASDAQ', 'FDTS');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Cumulus Media Inc.', '$14.07M', 'NASDAQ', 'CMLS');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Amerco', '$6.88B', 'NASDAQ', 'UHAL');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('United Microelectronics Corporation', '$4.95B', 'NYSE', 'UMC');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Facebook, Inc.', '$436.58B', 'NASDAQ', 'FB');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Eaton Vance NextShares Trust', 'n/a', 'NASDAQ', 'EVGBC');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('China Auto Logistics Inc.', '$8.19M', 'NASDAQ', 'CALI');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Regal Beloit Corporation', '$3.65B', 'NYSE', 'RBC');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('TransAlta Corporation', '$1.69B', 'NYSE', 'TAC');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Big 5 Sporting Goods Corporation', '$316.8M', 'NASDAQ', 'BGFV');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('ContraVir Pharmaceuticals Inc', '$47.48M', 'NASDAQ', 'CTRV');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Colony NorthStar, Inc.', 'n/a', 'NYSE', 'CLNS^F.CL');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Camtek Ltd.', '$197.24M', 'NASDAQ', 'CAMT');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Macatawa Bank Corporation', '$321.8M', 'NASDAQ', 'MCBC');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Anthera Pharmaceuticals, Inc.', '$2.31M', 'NASDAQ', 'ANTH');
insert into stocks (stock_name, stock_market_cap, stock_market, stock_symbol) values ('Silver Spring Networks, Inc.', '$559.9M', 'NYSE', 'SSNI');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*  invest_date DATE NOT NULL,                                                       */
/************************************************************************/
/* Write your answer in SQL below: */
insert into investment(credit_card_id, stock_symbol, stock_market, invest_date, invest_dollar) 
SELECT investors.credit_card, stocks.stock_symbol, stocks.stock_market, 
(NOW() - '1 year'::INTERVAL * ROUND(RANDOM() * 100))::DATE , (random()*1000 +1000)
FROM investors,stocks
WHERE investors.person_stock_market = stocks.stock_market
ORDER BY random() 
LIMIT 1000;

SELECT * FROM investment


