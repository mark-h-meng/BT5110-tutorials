/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data  
   Student ID: A0231919B; NUSNET ID: E0709174                          */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* My original example is used to record the feedback of (MSBA)students' performance 
from cooperated companies after the capstone projects. specifically, the companies must rate
the related students, one company might rate many students from different cohorts.

--1st table is Capstone_companies, description of the attributes are as follows:
name: the official name of the company; 
industry: the industry it belongs;
(name, industry): the composite key is the PK. According to the company law, 
companies in the same industry cannot have the same name, so it's unique;
since: the date when the company start to cooperate with MSBA program;
active: Boolean data. TRUE means the company is still maintaining a relationship with us, FALSE means it quits;

--2nd table is MSBA_students, description of the attributes are as follows:
first_name: the student's first name;
last_name: the student's last name;
email: the student's email address;
gender: M means male, F means female;
cohort: which cohort the student belongs, e.g. 2018;
dob: date of birth;
industry: the industry which the student most interested in;
student_id: the unique nusstu_id (use EIN as a substitute when generating fake data);

--3rd table is rating, description of the attributes are as follows:
name/industry: FK from Capstone_companies table
student_id: FK from MSBA_students table
(student_id, name, industry): PK, can uniquely define a rating record because 
one student can only participate one project for one time, and the company rates him/her only once;
score: specific rating (ranging from 0-10) from the company, invalid when less than 0; 

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE Capstone_companies (
	name VARCHAR(64),
	industry VARCHAR(64),
	since DATE NOT NULL,
	active CHAR(5) NOT NULL,
	PRIMARY KEY (name, industry));
	
CREATE TABLE MSBA_students (
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	email VARCHAR(64) UNIQUE NOT NULL,
	gender CHAR(1) NOT NULL,
	cohort INT NOT NULL,
	dob DATE NOT NULL,
	industry VARCHAR(64) NOT NULL,
	student_id VARCHAR(32) PRIMARY KEY);

CREATE TABLE Rating(
	student_id VARCHAR(32) REFERENCES MSBA_students(student_id),
	name VARCHAR(64),
	industry VARCHAR(64),
	FOREIGN KEY (name, industry) REFERENCES Capstone_companies(name, industry),
	PRIMARY KEY(student_id, name, industry),
	score int NOT NULL CHECK (score >= 0));

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into Capstone_companies (name, industry, since, active) values ('Photolist', 'Office Equipment/Supplies/Services', '2018-05-01', true);
insert into Capstone_companies (name, industry, since, active) values ('Wordpedia', 'Industrial Machinery/Components', '2018-09-23', false);
insert into Capstone_companies (name, industry, since, active) values ('Devcast', 'Telecommunications Equipment', '2018-02-21', true);
insert into Capstone_companies (name, industry, since, active) values ('Eazzy', 'Shoe Manufacturing', '2019-01-09', false);
insert into Capstone_companies (name, industry, since, active) values ('Centizu', 'Commercial Banks', '2018-07-08', false);
insert into Capstone_companies (name, industry, since, active) values ('Oyope', 'n/a', '2016-10-02', true);
insert into Capstone_companies (name, industry, since, active) values ('Vimbo', 'Computer Manufacturing', '2021-07-31', true);
insert into Capstone_companies (name, industry, since, active) values ('Trunyx', 'Major Pharmaceuticals', '2020-08-18', true);
insert into Capstone_companies (name, industry, since, active) values ('Wikivu', 'n/a', '2017-02-28', false);
insert into Capstone_companies (name, industry, since, active) values ('Viva', 'Real Estate Investment Trusts', '2018-11-02', true);
insert into Capstone_companies (name, industry, since, active) values ('Vipe', 'EDP Services', '2017-02-04', false);
insert into Capstone_companies (name, industry, since, active) values ('Oloo', 'Oilfield Services/Equipment', '2017-01-27', true);
insert into Capstone_companies (name, industry, since, active) values ('Tagfeed', 'Apparel', '2016-12-11', true);
insert into Capstone_companies (name, industry, since, active) values ('Feedspan', 'Property-Casualty Insurers', '2020-02-07', true);
insert into Capstone_companies (name, industry, since, active) values ('Brainverse', 'Property-Casualty Insurers', '2019-08-01', false);
insert into Capstone_companies (name, industry, since, active) values ('Oyonder', 'Major Chemicals', '2017-07-12', true);
insert into Capstone_companies (name, industry, since, active) values ('Yodoo', 'Catalog/Specialty Distribution', '2019-07-10', true);
insert into Capstone_companies (name, industry, since, active) values ('Feedspan', 'n/a', '2020-04-29', true);
insert into Capstone_companies (name, industry, since, active) values ('Photobug', 'Telecommunications Equipment', '2020-03-30', false);
insert into Capstone_companies (name, industry, since, active) values ('Youfeed', 'Auto Manufacturing', '2020-10-31', true);
insert into Capstone_companies (name, industry, since, active) values ('Leenti', 'n/a', '2019-05-29', true);
insert into Capstone_companies (name, industry, since, active) values ('Twitterlist', 'Office Equipment/Supplies/Services', '2016-09-10', true);
insert into Capstone_companies (name, industry, since, active) values ('Trilia', 'Business Services', '2020-10-26', false);
insert into Capstone_companies (name, industry, since, active) values ('Twimbo', 'Electric Utilities: Central', '2018-06-11', false);
insert into Capstone_companies (name, industry, since, active) values ('Buzzster', 'Industrial Machinery/Components', '2020-07-08', false);
insert into Capstone_companies (name, industry, since, active) values ('Skipfire', 'Medical/Dental Instruments', '2021-04-02', false);
insert into Capstone_companies (name, industry, since, active) values ('Feedfish', 'Pollution Control Equipment', '2018-12-14', false);
insert into Capstone_companies (name, industry, since, active) values ('Skippad', 'Electrical Products', '2017-02-08', true);
insert into Capstone_companies (name, industry, since, active) values ('Meejo', 'Agricultural Chemicals', '2019-08-04', true);
insert into Capstone_companies (name, industry, since, active) values ('Tagtune', 'Natural Gas Distribution', '2019-07-03', false);
insert into Capstone_companies (name, industry, since, active) values ('Youspan', 'Finance: Consumer Services', '2016-12-03', true);
insert into Capstone_companies (name, industry, since, active) values ('Skippad', 'Telecommunications Equipment', '2016-10-06', false);
insert into Capstone_companies (name, industry, since, active) values ('Meetz', 'Computer Software: Prepackaged Software', '2021-05-25', true);
insert into Capstone_companies (name, industry, since, active) values ('Meetz', 'n/a', '2019-12-09', true);
insert into Capstone_companies (name, industry, since, active) values ('Youfeed', 'n/a', '2018-03-21', false);
insert into Capstone_companies (name, industry, since, active) values ('Oyope', 'Business Services', '2021-08-08', true);
insert into Capstone_companies (name, industry, since, active) values ('Chatterbridge', 'Industrial Machinery/Components', '2018-04-25', true);
insert into Capstone_companies (name, industry, since, active) values ('Jabbersphere', 'Apparel', '2018-05-31', true);
insert into Capstone_companies (name, industry, since, active) values ('Livefish', 'Major Banks', '2017-11-30', false);
insert into Capstone_companies (name, industry, since, active) values ('Twimm', 'Broadcasting', '2019-12-20', true);
insert into Capstone_companies (name, industry, since, active) values ('Tagpad', 'Oil & Gas Production', '2020-09-24', false);
insert into Capstone_companies (name, industry, since, active) values ('Aibox', 'Television Services', '2021-05-24', false);
insert into Capstone_companies (name, industry, since, active) values ('Teklist', 'Property-Casualty Insurers', '2018-03-31', false);
insert into Capstone_companies (name, industry, since, active) values ('Rhycero', 'n/a', '2016-10-19', true);
insert into Capstone_companies (name, industry, since, active) values ('Flashdog', 'Semiconductors', '2018-09-12', false);
insert into Capstone_companies (name, industry, since, active) values ('Photobug', 'Major Banks', '2018-09-19', false);
insert into Capstone_companies (name, industry, since, active) values ('Kwimbee', 'Agricultural Chemicals', '2020-06-25', true);
insert into Capstone_companies (name, industry, since, active) values ('Skidoo', 'Consumer Electronics/Appliances', '2018-04-16', false);
insert into Capstone_companies (name, industry, since, active) values ('Lajo', 'Major Pharmaceuticals', '2017-10-05', false);
insert into Capstone_companies (name, industry, since, active) values ('Omba', 'Catalog/Specialty Distribution', '2019-06-06', false);
insert into Capstone_companies (name, industry, since, active) values ('Zoomlounge', 'Finance: Consumer Services', '2019-12-08', true);
insert into Capstone_companies (name, industry, since, active) values ('Oodoo', 'n/a', '2017-07-23', true);
insert into Capstone_companies (name, industry, since, active) values ('Wikido', 'Electrical Products', '2017-12-12', false);
insert into Capstone_companies (name, industry, since, active) values ('Brainlounge', 'Investment Bankers/Brokers/Service', '2016-09-26', false);
insert into Capstone_companies (name, industry, since, active) values ('Shuffledrive', 'Major Banks', '2019-05-21', true);
insert into Capstone_companies (name, industry, since, active) values ('Shufflebeat', 'Building Products', '2016-12-27', false);
insert into Capstone_companies (name, industry, since, active) values ('Lazz', 'Oil Refining/Marketing', '2020-04-02', true);
insert into Capstone_companies (name, industry, since, active) values ('Wordpedia', 'n/a', '2018-08-17', true);
insert into Capstone_companies (name, industry, since, active) values ('Cogilith', 'Industrial Machinery/Components', '2017-02-21', true);
insert into Capstone_companies (name, industry, since, active) values ('Jabbersphere', 'n/a', '2019-10-04', true);
insert into Capstone_companies (name, industry, since, active) values ('Mybuzz', 'n/a', '2020-02-02', true);
insert into Capstone_companies (name, industry, since, active) values ('Demivee', 'Real Estate', '2021-03-02', false);
insert into Capstone_companies (name, industry, since, active) values ('Edgeclub', 'n/a', '2017-08-30', true);
insert into Capstone_companies (name, industry, since, active) values ('Riffpedia', 'Air Freight/Delivery Services', '2016-12-10', false);
insert into Capstone_companies (name, industry, since, active) values ('Buzzster', 'Oil & Gas Production', '2016-11-09', true);
insert into Capstone_companies (name, industry, since, active) values ('Avavee', 'n/a', '2021-08-22', true);
insert into Capstone_companies (name, industry, since, active) values ('Topdrive', 'Marine Transportation', '2018-09-14', true);
insert into Capstone_companies (name, industry, since, active) values ('Innotype', 'Motor Vehicles', '2017-04-09', false);
insert into Capstone_companies (name, industry, since, active) values ('Oyondu', 'Restaurants', '2016-11-06', true);
insert into Capstone_companies (name, industry, since, active) values ('Trilith', 'Major Banks', '2018-05-10', true);
insert into Capstone_companies (name, industry, since, active) values ('Wikivu', 'Apparel', '2019-12-16', false);
insert into Capstone_companies (name, industry, since, active) values ('Skyble', 'Real Estate Investment Trusts', '2017-10-02', true);
insert into Capstone_companies (name, industry, since, active) values ('Ooba', 'n/a', '2016-12-10', true);
insert into Capstone_companies (name, industry, since, active) values ('Divavu', 'Multi-Sector Companies', '2017-02-25', false);
insert into Capstone_companies (name, industry, since, active) values ('Twitterbeat', 'n/a', '2018-03-09', true);
insert into Capstone_companies (name, industry, since, active) values ('Browseblab', 'n/a', '2017-11-11', false);
insert into Capstone_companies (name, industry, since, active) values ('Kanoodle', 'n/a', '2020-07-05', true);
insert into Capstone_companies (name, industry, since, active) values ('Twinder', 'Business Services', '2018-11-14', true);
insert into Capstone_companies (name, industry, since, active) values ('Katz', 'Major Banks', '2020-05-31', false);
insert into Capstone_companies (name, industry, since, active) values ('Meejo', 'n/a', '2019-01-05', true);
insert into Capstone_companies (name, industry, since, active) values ('Chatterbridge', 'Apparel', '2018-10-02', true);
insert into Capstone_companies (name, industry, since, active) values ('Bluejam', 'Biotechnology: Biological Products (No Diagnostic Substances)', '2020-01-14', true);
insert into Capstone_companies (name, industry, since, active) values ('Browsezoom', 'n/a', '2018-09-07', true);
insert into Capstone_companies (name, industry, since, active) values ('Skajo', 'Telecommunications Equipment', '2020-12-21', false);
insert into Capstone_companies (name, industry, since, active) values ('Topiczoom', 'Major Pharmaceuticals', '2018-05-02', false);
insert into Capstone_companies (name, industry, since, active) values ('Skilith', 'Major Pharmaceuticals', '2016-12-30', true);
insert into Capstone_companies (name, industry, since, active) values ('Jetpulse', 'Homebuilding', '2020-11-23', true);
insert into Capstone_companies (name, industry, since, active) values ('Dabfeed', 'Water Supply', '2018-09-07', false);
insert into Capstone_companies (name, industry, since, active) values ('Eazzy', 'Apparel', '2017-12-04', true);
insert into Capstone_companies (name, industry, since, active) values ('Centidel', 'Oil & Gas Production', '2020-03-19', true);
insert into Capstone_companies (name, industry, since, active) values ('Jabbersphere', 'Industrial Machinery/Components', '2021-02-03', false);
insert into Capstone_companies (name, industry, since, active) values ('Zooxo', 'Clothing/Shoe/Accessory Stores', '2016-09-07', false);
insert into Capstone_companies (name, industry, since, active) values ('Chatterbridge', 'n/a', '2021-03-10', false);
insert into Capstone_companies (name, industry, since, active) values ('Wordware', 'Packaged Foods', '2018-06-17', false);
insert into Capstone_companies (name, industry, since, active) values ('Dabshots', 'Oil & Gas Production', '2019-07-27', false);
insert into Capstone_companies (name, industry, since, active) values ('Skimia', 'n/a', '2021-08-13', false);
insert into Capstone_companies (name, industry, since, active) values ('Brainbox', 'n/a', '2017-10-09', false);
insert into Capstone_companies (name, industry, since, active) values ('Shufflester', 'Consumer Electronics/Appliances', '2020-11-04', false);
insert into Capstone_companies (name, industry, since, active) values ('Leenti', 'General Bldg Contractors - Nonresidential Bldgs', '2019-04-28', false);
insert into Capstone_companies (name, industry, since, active) values ('Thoughtstorm', 'n/a', '2017-11-13', true);


insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('30-6342202', 'Codie', 'Tinsley', 'ctinsley0@theatlantic.com', 'M', 2007, '1999-04-16', 'Business Services');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('91-6083552', 'Kalvin', 'Emmison', 'kemmison1@typepad.com', 'M', 1995, '1999-02-23', 'Services-Misc. Amusement & Recreation');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('67-6217275', 'Merill', 'Godmer', 'mgodmer2@tinyurl.com', 'M', 2010, '1995-07-25', 'Major Pharmaceuticals');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('99-0997938', 'Karolina', 'Buddock', 'kbuddock3@walmart.com', 'F', 2004, '1998-07-10', 'Industrial Specialties');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('18-7226434', 'Cherilynn', 'Warde', 'cwarde4@lycos.com', 'F', 1997, '1997-12-15', 'Electrical Products');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('33-6270949', 'Waite', 'Colebourne', 'wcolebourne5@hugedomains.com', 'M', 2009, '1994-12-15', 'Specialty Insurers');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('30-9829275', 'Helene', 'Dionisii', 'hdionisii6@hhs.gov', 'F', 2002, '2000-09-29', 'Hotels/Resorts');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('71-7044360', 'Clare', 'Patman', 'cpatman7@mapy.cz', 'F', 2004, '1999-07-20', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('01-2675400', 'Bo', 'Deamer', 'bdeamer8@mysql.com', 'M', 2012, '1997-01-06', 'Investment Bankers/Brokers/Service');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('77-2362557', 'Kerby', 'Kinsley', 'kkinsley9@sina.com.cn', 'M', 2003, '1996-11-22', 'EDP Services');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('92-7526723', 'Nicol', 'Timny', 'ntimnya@sphinn.com', 'M', 2002, '2000-11-15', 'Containers/Packaging');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('73-5388854', 'Zollie', 'Siegertsz', 'zsiegertszb@slashdot.org', 'M', 1994, '1999-07-30', 'Industrial Machinery/Components');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('82-0938204', 'Germayne', 'Kilpatrick', 'gkilpatrickc@ebay.co.uk', 'M', 1986, '1996-05-04', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('35-6170036', 'Geri', 'Defew', 'gdefewd@joomla.org', 'M', 2004, '1996-02-03', 'Professional Services');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('94-2172400', 'Reinold', 'Foister', 'rfoistere@addtoany.com', 'M', 2003, '1997-01-01', 'Real Estate Investment Trusts');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('47-8613648', 'Dwain', 'Zylbermann', 'dzylbermannf@umn.edu', 'M', 1994, '1999-05-08', 'Catalog/Specialty Distribution');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('22-3530517', 'Obidiah', 'Yockley', 'oyockleyg@ycombinator.com', 'M', 1990, '1996-01-19', 'Industrial Machinery/Components');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('38-3386117', 'Kellie', 'Kuhnel', 'kkuhnelh@over-blog.com', 'F', 1995, '1999-07-25', 'Medical/Nursing Services');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('57-3509269', 'Dominick', 'Crowley', 'dcrowleyi@netlog.com', 'M', 2011, '1995-06-21', 'Major Pharmaceuticals');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('01-0396572', 'Ola', 'Scarrisbrick', 'oscarrisbrickj@mashable.com', 'F', 2005, '1996-03-21', 'Paper');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('94-9263817', 'Misty', 'Cowton', 'mcowtonk@mayoclinic.com', 'F', 2011, '1998-11-17', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('83-7352175', 'Frankie', 'Antonchik', 'fantonchikl@linkedin.com', 'M', 2012, '1996-06-07', 'Major Banks');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('48-8498881', 'Kalil', 'Hynde', 'khyndem@europa.eu', 'M', 2004, '1999-01-05', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('79-2743212', 'Bevvy', 'Fidge', 'bfidgen@toplist.cz', 'F', 2005, '1997-08-26', 'Diversified Commercial Services');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('87-6818574', 'Phillis', 'Foxen', 'pfoxeno@boston.com', 'F', 2007, '1998-01-29', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('51-3537172', 'Selie', 'Matissoff', 'smatissoffp@printfriendly.com', 'F', 2011, '1995-05-11', 'Real Estate');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('88-1067078', 'Andrus', 'Cawt', 'acawtq@gov.uk', 'M', 2006, '1994-12-13', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('55-2547263', 'Keenan', 'Oates', 'koatesr@telegraph.co.uk', 'M', 2010, '1994-12-19', 'Savings Institutions');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('51-9204655', 'Millie', 'Dawtry', 'mdawtrys@unblog.fr', 'F', 1992, '2000-12-13', 'Major Chemicals');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('69-7233776', 'Alisha', 'Heynen', 'aheynent@wiley.com', 'F', 1985, '1996-08-17', 'Industrial Specialties');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('18-9330238', 'Ange', 'Malmar', 'amalmaru@etsy.com', 'M', 1998, '1995-04-21', 'Industrial Machinery/Components');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('00-0171736', 'Bentlee', 'Elrick', 'belrickv@discovery.com', 'M', 2004, '1998-09-11', 'Hotels/Resorts');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('64-9327398', 'Wyndham', 'Bucknall', 'wbucknallw@blinklist.com', 'M', 2008, '1996-09-21', 'Industrial Specialties');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('04-8397116', 'Chevy', 'McGaughey', 'cmcgaugheyx@prlog.org', 'M', 2002, '1995-03-31', 'Business Services');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('12-3264563', 'Emmye', 'Minogue', 'eminoguey@comcast.net', 'F', 2009, '2000-02-24', 'Major Pharmaceuticals');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('23-2257734', 'Albertina', 'Fidell', 'afidellz@com.com', 'F', 2004, '1998-12-26', 'Major Pharmaceuticals');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('73-0770284', 'Trula', 'Drakeford', 'tdrakeford10@furl.net', 'F', 2002, '1999-12-07', 'Major Pharmaceuticals');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('04-2527895', 'Hirsch', 'Haslock', 'hhaslock11@ehow.com', 'M', 1974, '1996-09-21', 'Oil & Gas Production');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('24-6878327', 'Murry', 'Emanueli', 'memanueli12@phoca.cz', 'M', 2007, '1999-03-23', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('79-9854942', 'Constancy', 'Ottewill', 'cottewill13@npr.org', 'F', 1994, '1996-04-19', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('59-8077953', 'Starla', 'Crudge', 'scrudge14@shinystat.com', 'F', 1995, '1999-10-04', 'Major Pharmaceuticals');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('54-2206694', 'Lorene', 'Tamblyn', 'ltamblyn15@hubpages.com', 'F', 2002, '1997-01-24', 'Savings Institutions');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('99-3704100', 'Zared', 'Verralls', 'zverralls16@goodreads.com', 'M', 2004, '1999-11-02', 'Semiconductors');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('79-3480656', 'Noll', 'Brum', 'nbrum17@spiegel.de', 'M', 2001, '1997-02-19', 'Radio And Television Broadcasting And Communications Equipment');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('18-4313995', 'Xymenes', 'Blything', 'xblything18@nsw.gov.au', 'M', 1993, '1997-08-24', 'Major Pharmaceuticals');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('66-5981057', 'Stanton', 'Ruffell', 'sruffell19@shutterfly.com', 'M', 1998, '1999-08-15', 'Precious Metals');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('15-6536648', 'Cynthia', 'Chettle', 'cchettle1a@digg.com', 'F', 2009, '1995-05-03', 'Marine Transportation');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('89-0699905', 'Del', 'Bratch', 'dbratch1b@icq.com', 'M', 1991, '1995-02-11', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('30-2320029', 'Karyl', 'Laise', 'klaise1c@wunderground.com', 'F', 1990, '1999-02-26', 'Major Banks');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('25-5004704', 'Carmelita', 'McClurg', 'cmcclurg1d@ovh.net', 'F', 1965, '1995-08-01', 'Savings Institutions');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('27-1154043', 'Rodrick', 'Brotherhead', 'rbrotherhead1e@mail.ru', 'M', 2010, '2000-06-26', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('21-0682266', 'Avery', 'Casale', 'acasale1f@slideshare.net', 'M', 1997, '1996-10-26', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('26-9597007', 'Andrew', 'Dregan', 'adregan1g@state.tx.us', 'M', 1996, '1995-12-09', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('21-9028261', 'Ricoriki', 'Idell', 'ridell1h@mac.com', 'M', 2003, '1999-03-26', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('48-8652597', 'Walsh', 'Gimson', 'wgimson1i@economist.com', 'M', 2008, '1996-01-12', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('52-5930135', 'Nannie', 'Wildes', 'nwildes1j@prnewswire.com', 'F', 1993, '1996-11-22', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('60-4953544', 'Gilda', 'Neilands', 'gneilands1k@hibu.com', 'F', 2000, '1999-02-28', 'Oil Refining/Marketing');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('68-5610421', 'Kellsie', 'Liddall', 'kliddall1l@acquirethisname.com', 'F', 2012, '1995-04-14', 'Computer Software: Prepackaged Software');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('57-5163224', 'Gaby', 'Rudolf', 'grudolf1m@hhs.gov', 'M', 2005, '1998-03-08', 'Specialty Chemicals');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('64-5578759', 'Dane', 'Petit', 'dpetit1n@si.edu', 'M', 2006, '1996-09-08', 'Semiconductors');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('92-6205788', 'Reed', 'Martyntsev', 'rmartyntsev1o@adobe.com', 'M', 2005, '1998-06-10', 'Steel/Iron Ore');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('72-2569654', 'Carmelina', 'Ram', 'cram1p@mlb.com', 'F', 1984, '1999-07-26', 'Major Banks');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('90-3176710', 'Kamila', 'Colbert', 'kcolbert1q@amazon.de', 'F', 2006, '2000-09-11', 'Real Estate Investment Trusts');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('10-0825772', 'Abel', 'Ruskin', 'aruskin1r@vk.com', 'M', 1997, '1998-08-20', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('18-9684009', 'Elladine', 'Keoghane', 'ekeoghane1s@auda.org.au', 'F', 1995, '2000-10-23', 'Investment Managers');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('82-1494458', 'Wenona', 'Barnewelle', 'wbarnewelle1t@eventbrite.com', 'F', 1993, '1999-03-31', 'Property-Casualty Insurers');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('67-7854726', 'Casey', 'Kiehne', 'ckiehne1u@illinois.edu', 'M', 2003, '2000-11-13', 'Major Pharmaceuticals');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('15-1990769', 'Aura', 'Demeza', 'ademeza1v@goo.gl', 'F', 2002, '1996-12-23', 'Medical/Dental Instruments');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('67-9347986', 'Killy', 'Kurdani', 'kkurdani1w@elegantthemes.com', 'M', 2004, '1996-12-24', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('99-0214145', 'Ewell', 'Cluer', 'ecluer1x@cargocollective.com', 'M', 2004, '1996-03-28', 'Diversified Commercial Services');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('28-7607658', 'Laurene', 'McDonnell', 'lmcdonnell1y@dedecms.com', 'F', 2009, '2000-08-22', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('45-0625274', 'Lisa', 'Peplay', 'lpeplay1z@goo.gl', 'F', 2010, '2000-01-06', 'Catalog/Specialty Distribution');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('65-6399994', 'Shae', 'Coatman', 'scoatman20@mail.ru', 'F', 1985, '1996-10-07', 'Home Furnishings');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('76-6555589', 'Carola', 'Ervin', 'cervin21@eepurl.com', 'F', 2007, '1997-11-08', 'Integrated oil Companies');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('47-6003198', 'Georgia', 'Chellam', 'gchellam22@devhub.com', 'F', 2002, '1999-04-20', 'Professional Services');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('12-6578454', 'Leandra', 'Dubber', 'ldubber23@stumbleupon.com', 'F', 1999, '1999-05-04', 'EDP Services');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('05-0128497', 'Grover', 'Sambedge', 'gsambedge24@goodreads.com', 'M', 2000, '1998-09-14', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('96-1823508', 'Alexi', 'Barrie', 'abarrie25@geocities.jp', 'F', 2008, '1997-04-23', 'Major Pharmaceuticals');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('02-9040541', 'Durante', 'Labrone', 'dlabrone26@tripadvisor.com', 'M', 2011, '2000-12-25', 'Industrial Machinery/Components');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('49-7626151', 'Horace', 'Buffham', 'hbuffham27@whitehouse.gov', 'M', 2000, '1999-12-02', 'Major Banks');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('41-9813010', 'Kris', 'Janosevic', 'kjanosevic28@dropbox.com', 'M', 2009, '1995-12-12', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('90-4212674', 'Vanya', 'Hardy', 'vhardy29@fastcompany.com', 'F', 2005, '1997-06-15', 'Computer Software: Prepackaged Software');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('19-5842533', 'Erroll', 'Sibbs', 'esibbs2a@java.com', 'M', 1997, '2000-01-25', 'Natural Gas Distribution');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('01-6378049', 'Felicity', 'Noods', 'fnoods2b@bluehost.com', 'F', 1997, '1998-06-01', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('06-3908930', 'Cullie', 'McGiffie', 'cmcgiffie2c@apache.org', 'M', 1969, '1999-10-09', 'Industrial Machinery/Components');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('02-0217859', 'Albrecht', 'Testro', 'atestro2d@infoseek.co.jp', 'M', 1993, '1998-10-19', 'Business Services');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('72-1435066', 'Carl', 'MacSharry', 'cmacsharry2e@amazon.co.uk', 'M', 1999, '1998-01-23', 'Real Estate Investment Trusts');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('43-3293257', 'Milli', 'Shakesbye', 'mshakesbye2f@spiegel.de', 'F', 2007, '1996-03-14', 'Major Banks');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('09-5770446', 'Jacintha', 'Reimer', 'jreimer2g@tinypic.com', 'F', 1989, '1998-12-16', 'Television Services');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('99-0918615', 'Zaria', 'Swanston', 'zswanston2h@samsung.com', 'F', 2003, '1997-10-12', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('54-6619592', 'Wylie', 'Dowyer', 'wdowyer2i@ycombinator.com', 'M', 2006, '1997-11-22', 'Packaged Foods');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('85-5453983', 'Gwenni', 'Crisford', 'gcrisford2j@hostgator.com', 'F', 2005, '1995-07-31', 'Telecommunications Equipment');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('11-8123085', 'Susie', 'Matussov', 'smatussov2k@admin.ch', 'F', 2005, '1999-03-03', 'Major Chemicals');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('17-0824453', 'Jareb', 'Gail', 'jgail2l@java.com', 'M', 1993, '2000-11-14', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('86-1609121', 'Mikkel', 'Endacott', 'mendacott2m@patch.com', 'M', 2010, '1999-12-23', 'Oil & Gas Production');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('77-9363433', 'Jacques', 'Roberti', 'jroberti2n@time.com', 'M', 2010, '1997-03-06', 'Beverages (Production/Distribution)');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('24-6569504', 'Fernandina', 'O''Dooghaine', 'fodooghaine2o@yellowbook.com', 'F', 2001, '1998-08-12', 'Electric Utilities: Central');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('98-4971551', 'Andie', 'Bohling', 'abohling2p@dagondesign.com', 'F', 2000, '1996-03-19', 'n/a');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('38-1805239', 'Verge', 'Bruyns', 'vbruyns2q@europa.eu', 'M', 1990, '1996-11-24', 'Homebuilding');
insert into MSBA_students (student_id, first_name, last_name, email, gender, cohort, dob, industry) values ('73-5054038', 'Marietta', 'Olivelli', 'molivelli2r@illinois.edu', 'M', 1990, '1999-09-30', 'Diversified Commercial Services');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO Rating (student_id, name, industry, score) (
	SELECT s.student_id, c.name, c.industry, s.cohort FROM MSBA_students AS s, Capstone_companies AS c
	ORDER BY random() LIMIT 1000);
	
UPDATE Rating SET score = round(random()*10) 
FROM (SELECT round(random()*10) FROM generate_series(1,1000)) AS s;
/*since it's hard to directly insert the attribute score which is not in the two entities,
I choose to fill the domain using the attributecohort first(also int to follow the constraint),
and then update the column by generating a random data series ranging from 0-10 as the score */