/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */

/* The code is written for SQLite */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* This database records prescriptions a docter writes to patients.
Table patient: info of patients with NHS number, name, email, gender, age and past medical history;
Table drug:	info of drugs with drug id, name, producer and price
Table prescription: prescrptions combine patients with drugs and also calculate the payment of each prescription
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE patient(
	NHS_number VARCHAR(16) PRIMARY KEY,
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	gender VARCHAR(2) NOT NULL,
	age INT(2) NOT NULL,
	email VARCHAR(64) UNIQUE NOT NULL,
	past_medical_history VARCHAR(100)
);
CREATE TABLE drug(
	drug_id VARCHAR(16) UNIQUE,
	drug_name VARCHAR(64) NOT NULL,
	producer VARCHAR(64) NOT NULL,
	price NUMERIC(16) NOT NULL CHECK(price>0),
	PRIMARY KEY(drug_name, producer)
);
CREATE TABLE prescription(
	prescription_id INTEGER PRIMARY KEY AUTOINCREMENT,
	NHS_number VARCHAR(16) NOT NULL,
	drug_name VARCHAR(64)NOT NULL,
	producer VARCHAR(64)NOT NULL,
	price NUMERIC(16) NOT NULL,
	quantity NUMERIC(16) DEFAULT 1 NOT NULL,
	total_payment AS (price * quantity),
	FOREIGN KEY(drug_name, producer) REFERENCES drug(drug_name, producer) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
	FOREIGN KEY(NHS_number) REFERENCES patient(NHS_number) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('2226309241', 'Romola', 'Rigts', 'F', 36, 'rrigts0@xrea.com', 'Toxic effect of pesticides, intentional self-harm, sequela');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('3625603438', 'Mal', 'Maginn', 'M', 71, 'mmaginn1@shop-pro.jp', 'Maternal care for (suspected) cnsl malform in fetus, fetus 3');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('0912114339', 'Rodge', 'Nabarro', 'M', 32, 'rnabarro2@sohu.com', 'Other specified crystal arthropathies, ankle and foot');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('0034253076', 'Patsy', 'Drohan', 'F', 3, 'pdrohan3@examiner.com', 'Unsp inj msl/fasc/tnd post grp at thi lev, unsp thigh, sqla');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('7138921691', 'Nicol', 'Vaggers', 'M', 2, 'nvaggers4@goodreads.com', 'Other acute nonsuppurative otitis media, left ear');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('1267667176', 'Holly-anne', 'Antoniat', 'F', 34, 'hantoniat5@squidoo.com', 'Spontaneous rupture of extensor tendons, multiple sites');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('3639574737', 'Phaidra', 'Bourdel', 'F', 81, 'pbourdel6@delicious.com', 'Corros 1st deg mult sites of shldr/up lmb, ex wrs/hnd, sqla');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('2874397253', 'Emory', 'Furley', 'M', 97, 'efurley7@ucoz.ru', 'Pasngr in pk-up/van inj in clsn w rail trn/veh nontraf, subs');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('8332271622', 'Juline', 'Juanes', 'F', 29, 'jjuanes8@flickr.com', 'Poisoning by alpha-adrenocpt antagonists, assault, sequela');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('9497564171', 'Elysha', 'Grindrod', 'F', 61, 'egrindrod9@nih.gov', 'Inferior dislocation of unsp acromioclav jt, sequela');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('8601871321', 'Aldridge', 'Dunhill', 'M', 64, 'adunhilla@samsung.com', 'Laceration without foreign body of scrotum and testes');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('5406851063', 'Putnem', 'Tortoise', 'M', 60, 'ptortoiseb@typepad.com', 'Insect bite (nonvenomous), left foot, subsequent encounter');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('0827213905', 'Sonia', 'Roseby', 'F', 90, 'srosebyc@wisc.edu', 'Oth injury due to oth accident to oth powered wtrcrft, init');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('1681080249', 'Dean', 'Maxwale', 'M', 83, 'dmaxwaled@elegantthemes.com', 'Gingival enlargement');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('0760076944', 'Jonell', 'Noot', 'F', 58, 'jnoote@businessinsider.com', 'Unsp inj blood vessels at hip and thi lev, right leg, sqla');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('2095372522', 'Aluin', 'Falloon', 'M', 19, 'afalloonf@opera.com', 'Encounter for screening for cardiovascular disorders');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('5767982902', 'Yorgo', 'Vallender', 'M', 50, 'yvallenderg@unblog.fr', 'Corros 3rd deg mu left fingers (nail), including thumb, subs');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('2678191001', 'Daisy', 'Loynton', 'F', 8, 'dloyntonh@hugedomains.com', 'Superficial foreign body of left little finger, init encntr');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('0340981121', 'Angeli', 'Burberye', 'M', 83, 'aburberyei@pagesperso-orange.fr', 'Disp fx of shaft of 5th MC bone, r hand, 7thK');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('2751935702', 'Agatha', 'Woodard', 'F', 70, 'awoodardj@cbsnews.com', 'Hemorrhage in optic nerve sheath, left eye');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('2517578443', 'Ariadne', 'Yegorshin', 'F', 10, 'ayegorshink@merriam-webster.com', 'Other miliary tuberculosis');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('0437592146', 'Nike', 'Czapla', 'F', 41, 'nczaplal@hubpages.com', 'Subluxation of MCP joint of left index finger, init');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('0435573985', 'Garwin', 'Skyner', 'M', 4, 'gskynerm@jimdo.com', 'Osteitis condensans, left upper arm');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('1818739836', 'Adelle', 'Pringley', 'F', 64, 'apringleyn@opera.com', 'Other local lupus erythematosus');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('5416928263', 'Shalna', 'Barling', 'F', 32, 'sbarlingo@sbwire.com', 'Calcium deposit in bursa, left elbow');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('0633907456', 'Iosep', 'Lathee', 'M', 43, 'ilatheep@arizona.edu', 'Other specified osteochondropathies of thigh');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('2870566239', 'Klement', 'Volonte', 'M', 78, 'kvolonteq@oracle.com', 'Cerebral infarction due to embolism of precerebral arteries');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('1077296762', 'Jess', 'Tomaselli', 'F', 72, 'jtomasellir@jugem.jp', 'Hallucinogen use, unsp w oth hallucinogen-induced disorder');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('9063098472', 'Kellby', 'Summerside', 'M', 67, 'ksummersides@about.me', 'Unsp fracture of upper end of unsp radius, init for clos fx');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('7412601628', 'Layla', 'Darlaston', 'F', 65, 'ldarlastont@typepad.com', 'Posterior reversible encephalopathy syndrome');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('7996863873', 'Lothaire', 'Derricoat', 'M', 45, 'lderricoatu@dot.gov', 'Noninfective gastroenteritis and colitis, unspecified');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('7045751028', 'Carney', 'Hallums', 'M', 57, 'challumsv@constantcontact.com', 'Unsp opn wnd unsp external genital organs, male, sequela');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('5599483819', 'Prudy', 'Tait', 'F', 56, 'ptaitw@eventbrite.com', 'Car passenger injured in collision w pedl cyc in traf, init');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('7659203258', 'Yettie', 'Loomis', 'F', 99, 'yloomisx@berkeley.edu', 'Nondisplaced spiral fracture of shaft of left fibula, init');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('4399944277', 'Winthrop', 'Cosby', 'M', 24, 'wcosbyy@exblog.jp', 'Accidental twist by another person, initial encounter');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('7099790714', 'Juanita', 'Rime', 'F', 65, 'jrimez@shutterfly.com', 'Unsp inj unsp musc/fasc/tend at shldr/up arm, unsp arm, sqla');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('1739090543', 'Alon', 'Attrey', 'M', 40, 'aattrey10@sitemeter.com', 'Explosion of blasting material, initial encounter');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('6039838108', 'Germaine', 'Harvett', 'F', 83, 'gharvett11@de.vu', 'Oth fracture of shaft of right fibula, init for clos fx');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('5118373824', 'Shena', 'Stood', 'F', 97, 'sstood12@squarespace.com', 'Contracture of muscle, unspecified lower leg');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('7253195736', 'Mia', 'Morillas', 'F', 5, 'mmorillas13@independent.co.uk', 'Ocular lac w/o prolaps/loss of intraoc tissue, l eye, subs');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('8284295857', 'Drona', 'Huckel', 'F', 83, 'dhuckel14@qq.com', 'Alcohol dependence with alcohol-induced psychotic disorder');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('9486813000', 'Erena', 'Brislen', 'F', 92, 'ebrislen15@google.com.au', 'Fx condylar process of mandible, unspecified side, sequela');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('6915604553', 'Electra', 'Winton', 'F', 90, 'ewinton16@multiply.com', 'Injury of musculocutaneous nerve, left arm, init encntr');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('6551294197', 'Babbie', 'Plaschke', 'F', 63, 'bplaschke17@pinterest.com', 'Unsp injury of musc/fasc/tend at wrs/hnd lv, r hand, subs');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('3192944536', 'Emmanuel', 'Durn', 'M', 16, 'edurn18@livejournal.com', 'Displ seg fx shaft of unsp tibia, 7thD');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('6904138912', 'Cecilla', 'Cullerne', 'F', 5, 'ccullerne19@sitemeter.com', 'Milt op involving unarmed hand to hand combat, milt, init');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('0392880970', 'Anderson', 'Nodes', 'M', 46, 'anodes1a@nyu.edu', 'Nondisp osteochon fx l patella, subs for clos fx w malunion');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('5768089284', 'Violet', 'Mouton', 'F', 36, 'vmouton1b@umich.edu', 'Glaucoma sec to oth eye disord, unsp eye, moderate stage');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('1708751777', 'Kelila', 'Fisbey', 'F', 76, 'kfisbey1c@wikispaces.com', 'Oth injuries of left wrist, hand and finger(s), init encntr');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('9861649328', 'Baryram', 'Smithers', 'M', 80, 'bsmithers1d@about.me', 'Laceration w/o foreign body of left upper arm, init encntr');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('4214652460', 'Vania', 'Daintith', 'F', 42, 'vdaintith1e@youtu.be', 'Corros w resulting rupture and dest of unsp eyeball, sequela');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('2953650121', 'Harley', 'Goodrich', 'M', 32, 'hgoodrich1f@comsenz.com', 'Disp fx of greater trochanter of r femr, 7thM');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('9493604012', 'Nicolais', 'Hiland', 'M', 38, 'nhiland1g@google.com', 'War op w intentl restrict of air/airwy, milt, sequela');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('7298020188', 'Kendra', 'Rawnsley', 'F', 90, 'krawnsley1h@mail.ru', 'Carcinoma in situ of hard palate');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('4078805205', 'Micheil', 'Stigell', 'M', 37, 'mstigell1i@springer.com', 'Unsp fx shaft of r femr, 7thR');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('0224489488', 'Melisande', 'Eady', 'F', 77, 'meady1j@ifeng.com', 'Laceration without foreign body of toe with damage to nail');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('6854744504', 'Brier', 'Manser', 'F', 31, 'bmanser1k@census.gov', 'Intermittent hydrarthrosis');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('0818300558', 'Haskel', 'Winram', 'M', 38, 'hwinram1l@dailymail.co.uk', 'Retinal detachment with retinal dialysis');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('9546111228', 'Pia', 'Dingley', 'F', 80, 'pdingley1m@hao123.com', 'Ulcerative (chronic) rectosigmoiditis w unsp complications');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('2248347715', 'Gussy', 'Gillivrie', 'F', 1, 'ggillivrie1n@salon.com', 'Nondisp suprcndl fx w intrcndl extn low end unsp femr, 7thD');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('5073793110', 'Aile', 'Sillars', 'F', 10, 'asillars1o@sphinn.com', 'Disp fx of fifth metatarsal bone, left foot, init');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('1018029508', 'Silvano', 'Bignold', 'M', 94, 'sbignold1p@usgs.gov', 'Alcohol abuse w alcoh-induce psychotic disorder w delusions');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('7236413488', 'Dyana', 'Cheson', 'F', 61, 'dcheson1q@123-reg.co.uk', 'Chronic gout due to renal impairment, unsp knee, w/o tophus');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('8351374741', 'Marlowe', 'Liver', 'M', 37, 'mliver1r@google.co.uk', 'Subluxation of distal interphalangeal joint of thmb, sequela');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('5723640585', 'Broddy', 'Esposi', 'M', 28, 'besposi1s@spiegel.de', 'Ped on sktbrd injured pick-up truck, pk-up/van nontraf, subs');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('2632634652', 'Ax', 'McCullough', 'M', 44, 'amccullough1t@earthlink.net', 'Other contact with orca, sequela');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('3166481222', 'Webb', 'Slowly', 'M', 68, 'wslowly1u@yellowbook.com', 'Ring staphyloma, bilateral');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('9185468835', 'Britte', 'Stubbin', 'F', 90, 'bstubbin1v@cbslocal.com', 'Varicos vn of l low extrem w ulc of unsp site and inflam');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('5250576834', 'Bearnard', 'Woodger', 'M', 2, 'bwoodger1w@ox.ac.uk', 'Toxic effect of contact w sea anemone, intentional self-harm');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('8998873176', 'Charisse', 'Anthoine', 'F', 4, 'canthoine1x@vk.com', 'Stupor');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('6454365115', 'Tris', 'De Minico', 'M', 80, 'tdeminico1y@flickr.com', 'Malignant neoplasm of undescended right testis');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('4548721037', 'Korry', 'Arthurs', 'F', 9, 'karthurs1z@accuweather.com', 'Toxic effect of unsp alcohol, undetermined, subs encntr');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('7006755336', 'Barbra', 'Cargon', 'F', 66, 'bcargon20@sogou.com', 'Inj msl/tnd lng extn muscle of toe at ank/ft level, r foot');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('2027613056', 'Daven', 'Lorking', 'M', 7, 'dlorking21@eepurl.com', 'Unsp opn wnd abd wall, left lower q w penet perit cav, init');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('0545882761', 'Gonzales', 'De Witt', 'M', 83, 'gdewitt22@smh.com.au', 'Burn of first deg mult sites of unsp wrist and hand, sequela');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('4581017904', 'Northrup', 'Wynter', 'M', 14, 'nwynter23@abc.net.au', 'Partial loss of teeth due to periodontal diseases');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('2682107117', 'My', 'Marshman', 'M', 11, 'mmarshman24@smugmug.com', 'Fx rad/ulna fol insrt ortho implnt/prosth/bone plt, unsp arm');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('8802717184', 'Boigie', 'Iacivelli', 'M', 7, 'biacivelli25@mysql.com', 'Medial sublux of proximal end of tibia, right knee, subs');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('1439567514', 'Herta', 'Palfreman', 'F', 9, 'hpalfreman26@1und1.de', 'Other complications of gastric band procedure');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('9183111867', 'Katee', 'Leyman', 'F', 29, 'kleyman27@sun.com', 'Galeazzi''s fx left rad, subs for opn fx type I/2 w malunion');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('9771885022', 'Lia', 'Ofield', 'F', 94, 'lofield28@ocn.ne.jp', 'Burn of unspecified degree of left ear');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('2583804081', 'Fan', 'Brewitt', 'F', 46, 'fbrewitt29@bigcartel.com', 'Unsp fx shaft of right ulna, subs for clos fx w routn heal');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('3630210023', 'Olivier', 'Fransinelli', 'M', 78, 'ofransinelli2a@trellian.com', 'Mech compl of coronary artery bypass graft, sequela');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('0787525820', 'Belia', 'Rosenfield', 'F', 89, 'brosenfield2b@twitpic.com', 'Strain extn musc/fasc/tend r little fngr at wrs/hnd lv, init');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('2296573649', 'Juan', 'Stang-Gjertsen', 'M', 70, 'jstanggjertsen2c@w3.org', 'Cont preg aft uterin dth of one fetus or more, 2nd tri, fts3');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('7285977861', 'Kissie', 'Westwood', 'F', 95, 'kwestwood2d@quantcast.com', 'Poisoning by pyrazolone derivatives, accidental, subs');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('5210390497', 'Perle', 'Humberston', 'F', 42, 'phumberston2e@163.com', 'Periprosth fx around internal prosth l shoulder jt, init');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('9683861075', 'Jolynn', 'McCarle', 'F', 85, 'jmccarle2f@google.cn', 'Poisoning by antiallergic and antiemetic drugs, assault');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('3713712328', 'Andonis', 'Rickhuss', 'M', 89, 'arickhuss2g@dedecms.com', 'Unsp disp fx of surgical neck of left humerus, sequela');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('8568943764', 'Buck', 'Kitley', 'M', 10, 'bkitley2h@discuz.net', 'Striking against other object with subsequent fall, sequela');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('3480382118', 'Elsy', 'Box', 'F', 95, 'ebox2i@ezinearticles.com', 'Collapsed vert, NEC, thor region, subs for fx w routn heal');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('7249348558', 'Yorgos', 'Noen', 'M', 40, 'ynoen2j@nasa.gov', 'Displacement of cystostomy catheter, sequela');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('3746671876', 'Mortie', 'Craise', 'M', 9, 'mcraise2k@oaic.gov.au', 'Injury of ulnar nerve at upper arm level, left arm, subs');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('4432277416', 'Averil', 'Fitzpayn', 'M', 41, 'afitzpayn2l@youtu.be', 'Other specified injury of blood vessel of left index finger');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('1066374031', 'Cassie', 'Corradengo', 'M', 48, 'ccorradengo2m@imageshack.us', 'Unsp fx low end r femr, subs for opn fx type I/2 w malunion');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('6831544363', 'Rheta', 'Ravenhills', 'F', 24, 'rravenhills2n@jalbum.net', 'Person outsd 3-whl mv inj in clsn w pedl cyc nontraf, sqla');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('9547126024', 'Mignonne', 'Vale', 'F', 28, 'mvale2o@discovery.com', 'Posterior dislocation of left radial head');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('1959533495', 'Melitta', 'Mulliss', 'F', 82, 'mmulliss2p@mapquest.com', 'Superficial foreign body, left great toe, subs encntr');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('4005789064', 'Emlyn', 'Bluschke', 'M', 100, 'ebluschke2q@dyndns.org', 'Oth traum nondisp spondylolysis of sixth cervcal vert, 7thK');
insert into patient (NHS_number, first_name, last_name, gender, age, email, past_medical_history) values ('5790889794', 'Arni', 'Gambles', 'M', 41, 'agambles2r@com.com', 'Burn of unspecified degree of unspecified thigh, init encntr');
insert into drug (drug_id, drug_name, producer, price) values ('35356-744', 'Alprazolam', 'Lake Erie Medical & Surgical Supply DBA Quality Care Products LLC', 74.36);
insert into drug (drug_id, drug_name, producer, price) values ('43353-942', 'Metoprolol Tartrate', 'Aphena Pharma Solutions - Tennessee, LLC', 66.44);
insert into drug (drug_id, drug_name, producer, price) values ('44206-310', 'AlbuRx', 'CSL Behring AG', 44.21);
insert into drug (drug_id, drug_name, producer, price) values ('68788-9934', 'Dicyclomine', 'Preferred Pharmaceuticals, Inc', 40.62);
insert into drug (drug_id, drug_name, producer, price) values ('58789-500', 'Air', 'Airgas Northern California and Nevada, Inc.', 94.23);
insert into drug (drug_id, drug_name, producer, price) values ('49999-074', 'Piroxicam', 'Lake Erie Medical DBA Quality Care Products LLC', 33.74);
insert into drug (drug_id, drug_name, producer, price) values ('75862-005', 'HAND SANITIZING', 'GANZ U.S.A., LLC', 82.8);
insert into drug (drug_id, drug_name, producer, price) values ('67143-3102', 'Dermasil Sensitive', 'Rise International Group LLC', 49.17);
insert into drug (drug_id, drug_name, producer, price) values ('50382-011', 'zinc oxide', 'Galentic Pharma (India) Private Limited', 96.15);
insert into drug (drug_id, drug_name, producer, price) values ('36987-2678', 'White Hickory', 'Nelco Laboratories, Inc.', 92.95);
insert into drug (drug_id, drug_name, producer, price) values ('41250-035', 'MEIJER', 'Meijer Distribution Inc', 45.44);
insert into drug (drug_id, drug_name, producer, price) values ('10144-604', 'Zanaflex', 'Acorda Therapeutics, Inc.', 65.45);
insert into drug (drug_id, drug_name, producer, price) values ('0268-0268', 'Cat Pelt, Standardized', 'ALK-Abello, Inc.', 56.76);
insert into drug (drug_id, drug_name, producer, price) values ('0904-6296', 'Naproxen', 'Major Pharmaceuticals', 96.34);
insert into drug (drug_id, drug_name, producer, price) values ('65597-115', 'Tribenzor', 'Daiichi Sankyo, Inc.', 23.85);
insert into drug (drug_id, drug_name, producer, price) values ('49999-984', 'ADVAIR', 'Lake Erie Medical & Surgical Supply DBA Quality Care Products LLC', 90.74);
insert into drug (drug_id, drug_name, producer, price) values ('24987-260', 'LANOXIN', 'Covis Pharmaceuticals Inc', 92.19);
insert into drug (drug_id, drug_name, producer, price) values ('0363-1263', 'Childrens Ibuprofen', 'Walgreen Company', 58.97);
insert into drug (drug_id, drug_name, producer, price) values ('42192-138', 'Sodium Sulfacetamide 10 Sulfur 5', 'Acella Pharmaceuticals, LLC', 48.19);
insert into drug (drug_id, drug_name, producer, price) values ('36987-3064', 'Black Walnut', 'Nelco Laboratories, Inc.', 5.33);
insert into drug (drug_id, drug_name, producer, price) values ('11673-015', 'Healing', 'Target Corporation', 56.35);
insert into drug (drug_id, drug_name, producer, price) values ('43742-0089', 'Virus', 'Deseret Biologicals, Inc.', 10.23);
insert into drug (drug_id, drug_name, producer, price) values ('0713-0631', 'Fluticasone Propionate', 'G & W LABORATORIES, INC.', 71.72);
insert into drug (drug_id, drug_name, producer, price) values ('36987-1038', 'Goose Feathers', 'Nelco Laboratories, Inc.', 14.57);
insert into drug (drug_id, drug_name, producer, price) values ('10370-219', 'Potassium Chloride', 'Par Pharmaceutical, Inc.', 3.22);
insert into drug (drug_id, drug_name, producer, price) values ('0536-1810', 'PINK BISMUTH', 'Rugby Laboratories, Inc.', 55.2);
insert into drug (drug_id, drug_name, producer, price) values ('36000-007', 'Fluconazole', 'Claris Lifesciences Inc.', 67.49);
insert into drug (drug_id, drug_name, producer, price) values ('76237-307', 'Lisinopril 5mg', 'Mckesson Contract Packaging', 9.46);
insert into drug (drug_id, drug_name, producer, price) values ('36987-2360', 'Quack Grass', 'Nelco Laboratories, Inc.', 29.09);
insert into drug (drug_id, drug_name, producer, price) values ('59630-762', 'METHYLIN', 'SHIONOGI INC.', 27.77);
insert into drug (drug_id, drug_name, producer, price) values ('0555-1883', 'Benzonatate', 'Barr Laboratories Inc.', 4.83);
insert into drug (drug_id, drug_name, producer, price) values ('0228-3659', 'Ropinirole', 'Actavis Elizabeh LLC', 76.6);
insert into drug (drug_id, drug_name, producer, price) values ('49349-345', 'Tamsulosin Hydrochloride', 'REMEDYREPACK INC.', 23.18);
insert into drug (drug_id, drug_name, producer, price) values ('68400-351', 'Gelato Topical Anesthetic', 'Mycone Dental Supply Co., Inc DBA Keystone Industries and Deepak Products Inc', 66.44);
insert into drug (drug_id, drug_name, producer, price) values ('55526-0005', 'NAVI Black and C-Clinic', 'EQ Maxon Corp.', 90.35);
insert into drug (drug_id, drug_name, producer, price) values ('50988-253', 'Antibacterial Hand Towelettes', 'Jets, Sets, & Elephants Beauty Corp.', 27.28);
insert into drug (drug_id, drug_name, producer, price) values ('64613-5700', 'Tempra', 'Bristol-Myers Squibb de Mexico, S. de R.L. de C.V.', 66.94);
insert into drug (drug_id, drug_name, producer, price) values ('48951-9001', 'Testes Apis', 'Uriel Pharmacy Inc.', 86.83);
insert into drug (drug_id, drug_name, producer, price) values ('54868-4991', 'ACETAMINOPHEN', 'Physicians Total Care, Inc.', 83.8);
insert into drug (drug_id, drug_name, producer, price) values ('64893-801', 'DR.Fresh Kids Pediatric', 'Dr. Fresh, Inc.', 2.83);
insert into drug (drug_id, drug_name, producer, price) values ('37000-830', 'Crest Complete Multi-Benefit', 'Procter & Gamble Manufacturing Company', 18.24);
insert into drug (drug_id, drug_name, producer, price) values ('44087-0004', 'Serostim', 'EMD Serono, Inc.', 31.89);
insert into drug (drug_id, drug_name, producer, price) values ('0338-1115', 'CLINIMIX E', 'Baxter Healthcare Corporation', 81.5);
insert into drug (drug_id, drug_name, producer, price) values ('0904-6183', 'Guanfacine Hydrochloride', 'Major Pharmaceuticals', 17.6);
insert into drug (drug_id, drug_name, producer, price) values ('13537-330', 'ESIKA', 'Ventura Corporation (San Juan, P.R)', 32.96);
insert into drug (drug_id, drug_name, producer, price) values ('68788-9880', 'Nortriptyline Hydrochloride', 'Preferred Pharmaceuticals, Inc', 36.64);
insert into drug (drug_id, drug_name, producer, price) values ('22100-001', 'Healing Waters White Tea Pear Hand Sanitizer', 'Ningbo Meiduo General Products Co., Ltd', 13.76);
insert into drug (drug_id, drug_name, producer, price) values ('50845-0124', 'Appetite Increase', 'Liddell Laboratories, Inc.', 18.87);
insert into drug (drug_id, drug_name, producer, price) values ('49643-420', 'Cocklebur Pollen', 'Allermed Laboratories, Inc.', 40.8);
insert into drug (drug_id, drug_name, producer, price) values ('0409-1560', 'Marcaine', 'Hospira, Inc.', 87.15);
insert into drug (drug_id, drug_name, producer, price) values ('54868-0235', 'Kenalog-40', 'Physicians Total Care, Inc.', 58.09);
insert into drug (drug_id, drug_name, producer, price) values ('59667-0093', 'Bronchitis', 'Home Sweet Homeopathics', 57.57);
insert into drug (drug_id, drug_name, producer, price) values ('53208-534', 'OHUI White Extreme Illuminating Pact No.10', 'LG Household and Healthcare, Inc.', 56.51);
insert into drug (drug_id, drug_name, producer, price) values ('43857-0117', 'Bio Cherry Plum', 'BioActive Nutritional, Inc.', 77.16);
insert into drug (drug_id, drug_name, producer, price) values ('16477-620', 'Neo DM DROPS', 'Laser Pharmaceuticals, LLC', 75.02);
insert into drug (drug_id, drug_name, producer, price) values ('58232-6001', 'Bengay Ultra Strength', 'JJohnson & Johnson Consumer Products Company, Division of Johnson & Johnson Consumer Companies, Inc.', 92.62);
insert into drug (drug_id, drug_name, producer, price) values ('49999-447', 'AcipHex', 'Lake Erie Medical & Surgical Supplies DBA Quality Care Products LLC', 74.66);
insert into drug (drug_id, drug_name, producer, price) values ('49349-270', 'Bupropion Hydrochloride', 'REMEDYREPACK INC.', 35.32);
insert into drug (drug_id, drug_name, producer, price) values ('63629-2679', 'Benazepril Hydrochloride', 'Bryant Ranch Prepack', 26.15);
insert into drug (drug_id, drug_name, producer, price) values ('49999-381', 'Bupropion Hydrochloride', 'Lake Erie Medical DBA Quality Care Products LLC', 80.61);
insert into drug (drug_id, drug_name, producer, price) values ('43853-0100', 'HGH Plus', 'ProBLEN', 8.65);
insert into drug (drug_id, drug_name, producer, price) values ('68180-237', 'Perindopril Erbumine', 'Lupin Pharmaceuticals, Inc', 60.54);
insert into drug (drug_id, drug_name, producer, price) values ('21695-103', 'Paroxetine', 'Rebel Distributors Corp', 35.05);
insert into drug (drug_id, drug_name, producer, price) values ('64536-7873', 'Soft Care Neutra Germ Fragrance Free Antibacterial', 'Diversey, Inc.', 76.07);
insert into drug (drug_id, drug_name, producer, price) values ('0498-7500', 'Cedaprin', 'North Safety Products LLC', 4.76);
insert into drug (drug_id, drug_name, producer, price) values ('49884-259', 'Metaproterenol Sulfate', 'Par Pharmaceutical Inc', 97.72);
insert into drug (drug_id, drug_name, producer, price) values ('63481-623', 'PERCOCET', 'Endo Pharmaceuticals', 74.29);
insert into drug (drug_id, drug_name, producer, price) values ('52125-082', 'TAPAZOLE', 'REMEDYREPACK INC.', 21.15);
insert into drug (drug_id, drug_name, producer, price) values ('53489-146', 'Sulfamethoxazole and Trimethoprim', 'Mutual Pharmaceutical Company, Inc.', 12.34);
insert into drug (drug_id, drug_name, producer, price) values ('63824-160', 'Delsym', 'Reckitt Benckiser LLC', 27.88);
insert into drug (drug_id, drug_name, producer, price) values ('0115-0522', 'Fenofibrate', 'Global Pharmaceuticals, Division of Impax Laboratories Inc.', 95.42);
insert into drug (drug_id, drug_name, producer, price) values ('0268-0807', 'ALTERNARIA TENUIS', 'ALK-Abello, Inc.', 13.54);
insert into drug (drug_id, drug_name, producer, price) values ('60193-100', 'Woodwards Mycocide Clinical NS', 'Pacific Word Corporation', 8.43);
insert into drug (drug_id, drug_name, producer, price) values ('49483-381', 'Low Dose Aspirin', 'Time-Cap Labs, Inc', 0.38);
insert into drug (drug_id, drug_name, producer, price) values ('49349-916', 'Baclofen', 'REMEDYREPACK INC.', 92.62);
insert into drug (drug_id, drug_name, producer, price) values ('55154-4957', 'Ramipril', 'Cardinal Health', 66.56);
insert into drug (drug_id, drug_name, producer, price) values ('58411-156', 'CLE DE PEAU BEAUTE SILKY FOUNDATION I', 'SHISEIDO AMERICAS CORPORATION', 20.4);
insert into drug (drug_id, drug_name, producer, price) values ('0049-3450', 'Diflucan', 'Roerig', 76.46);
insert into drug (drug_id, drug_name, producer, price) values ('50967-126', 'IROSPAN 24/6', 'WOMENS CHOICE PHARMACEUTICALS LLC', 48.35);
insert into drug (drug_id, drug_name, producer, price) values ('67510-0156', 'Multi Sympton Cold Day Night', 'Kareway Product, Inc.', 93.67);
insert into drug (drug_id, drug_name, producer, price) values ('60512-6537', 'BAPTISIA TINCTORIA', 'HOMEOLAB USA INC.', 90.81);
insert into drug (drug_id, drug_name, producer, price) values ('55312-153', 'Everyday Clean Dandruff', 'Western Family Foods, Inc', 80.16);
insert into drug (drug_id, drug_name, producer, price) values ('49580-0434', 'Tussin Sugar Free Cough', 'Aaron Industries, Inc.', 16.93);
insert into drug (drug_id, drug_name, producer, price) values ('59746-127', 'Hydrochlorothiazide', 'JUBILANT CADISTA PHARMACEUTICALS, INC.', 68.92);
insert into drug (drug_id, drug_name, producer, price) values ('0258-3687', 'diltiazem hydrochloride', 'Forest Laboratories', 80.0);
insert into drug (drug_id, drug_name, producer, price) values ('10337-476', 'Tyzine', 'PharmaDerm A division of Fougera Pharmaceuticals Inc.', 64.45);
insert into drug (drug_id, drug_name, producer, price) values ('64725-2434', 'Benztropine Mesylate', 'TYA Pharmaceuticals', 42.87);
insert into drug (drug_id, drug_name, producer, price) values ('0093-7287', 'Levetiracetam', 'Teva Pharmaceuticals USA Inc', 71.06);
insert into drug (drug_id, drug_name, producer, price) values ('41163-949', 'equaline milk of magnesia', 'Supervalu Inc', 19.17);
insert into drug (drug_id, drug_name, producer, price) values ('69164-1001', 'Colloidal Iodine', 'JCI INSTITUTE OF MEDICAL SCIENCE', 49.96);
insert into drug (drug_id, drug_name, producer, price) values ('24208-545', 'Levobunolol Hydrochloride', 'Bausch & Lomb Incorporated', 41.43);
insert into drug (drug_id, drug_name, producer, price) values ('52380-0025', 'Aplicare Povidone-iodine Scrub', 'Aplicare, Inc.', 88.11);
insert into drug (drug_id, drug_name, producer, price) values ('76282-251', 'Escitalopram oxalate', 'Exelan Pharmaceuticals Inc.', 46.61);
insert into drug (drug_id, drug_name, producer, price) values ('0641-6022', 'Famotidine', 'West-ward Pharmaceutical Corp.', 13.57);
insert into drug (drug_id, drug_name, producer, price) values ('37000-055', 'Head and Shoulders 2in1', 'Procter & Gamble Manufacturing Co.', 42.83);
insert into drug (drug_id, drug_name, producer, price) values ('59886-308', 'UltrasolSunscreen', 'Fischer Pharmaceuticals Ltd', 21.59);
insert into drug (drug_id, drug_name, producer, price) values ('0056-0176', 'COUMADIN', 'Bristol-Myers Squibb Pharma Company', 36.63);
insert into drug (drug_id, drug_name, producer, price) values ('54632-003', 'AIR, COMPRESSED', 'U.S. Oxygen and Supply, LLC', 73.76);
insert into drug (drug_id, drug_name, producer, price) values ('76038-089', 'MEDITOWEL', 'MICRO CONNECTION ENTERPRISES INC', 28.89);
insert into drug (drug_id, drug_name, producer, price) values ('10893-150', 'Naturasil', 'Nature''s Innovation, Inc.', 77.29);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO prescription(NHS_number, drug_name, producer,price)
	SELECT NHS_number, drug_name, producer,price
	FROM patient, drug 
	ORDER BY RANDOM() LIMIT 1000;
UPDATE prescription
	SET quantity = ABS(RANDOM()) % (100 - 1) + 1 /* assume quantity is between 1 to 100*/
	WHERE prescription_id IS NOT NULL;
