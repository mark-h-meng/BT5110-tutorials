/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
Table city_country contains a list of cities and which country each city belongs to
Table movie contains a list of movie titles, the genre of the movies, and the language the movies are in.
Table movie_city contains a list of movie titles and relates to the cities they were made in
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
*/

drop table if exists movie_city;
drop table if exists movie;
drop table if exists city_country;

create table city_country (
	city VARCHAR(50) PRIMARY KEY,
	country VARCHAR(50)
	
);

create table movie (
	movie_title VARCHAR(100) PRIMARY KEY,
	genre VARCHAR(50),
	lang VARCHAR(50)
);

create table movie_city (
	
	movie_title VARCHAR(100) references movie (movie_title)
		on update cascade on delete cascade
		deferrable initially deferred,
	city VARCHAR(50) references city_country (city)
		on update cascade on delete cascade
		deferrable initially deferred,
	primary key (movie_title, city)
	
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


insert into city_country (city, country) values ('Xiamazhuang', 'China');
insert into city_country (city, country) values ('Ni’ao', 'China');
insert into city_country (city, country) values ('Sarvaš', 'Croatia');
insert into city_country (city, country) values ('Bor', 'Serbia');
insert into city_country (city, country) values ('Krasnoye', 'Russia');
insert into city_country (city, country) values ('Zhambyl', 'Kazakhstan');
insert into city_country (city, country) values ('Santiago dos Velhos', 'Portugal');
insert into city_country (city, country) values ('Liulin', 'China');
insert into city_country (city, country) values ('Estoi', 'Portugal');
insert into city_country (city, country) values ('Kariaí', 'Greece');
insert into city_country (city, country) values ('Xinzhai', 'China');
insert into city_country (city, country) values ('Billa', 'Indonesia');
insert into city_country (city, country) values ('Oinófyta', 'Greece');
insert into city_country (city, country) values ('Vista Hermosa', 'Mexico');
insert into city_country (city, country) values ('Nyíregyháza', 'Hungary');
insert into city_country (city, country) values ('Frederiksberg', 'Denmark');
insert into city_country (city, country) values ('Changcun', 'China');
insert into city_country (city, country) values ('Keroak', 'Indonesia');
insert into city_country (city, country) values ('San Isidro', 'Philippines');
insert into city_country (city, country) values ('Xinxing', 'China');
insert into city_country (city, country) values ('Hernández', 'Argentina');
insert into city_country (city, country) values ('Uummannaq', 'Greenland');
insert into city_country (city, country) values ('Nanzhao', 'China');
insert into city_country (city, country) values ('Nansan', 'China');
insert into city_country (city, country) values ('El Fasher', 'Sudan');
insert into city_country (city, country) values ('Gaya', 'Nigeria');
insert into city_country (city, country) values ('Żórawina', 'Poland');
insert into city_country (city, country) values ('Maketu', 'New Zealand');
insert into city_country (city, country) values ('Adrasmon', 'Tajikistan');
insert into city_country (city, country) values ('Panenggoede', 'Indonesia');
insert into city_country (city, country) values ('Pavino', 'Russia');
insert into city_country (city, country) values ('Garagoa', 'Colombia');
insert into city_country (city, country) values ('Taroudant', 'Morocco');
insert into city_country (city, country) values ('Perelyub', 'Russia');
insert into city_country (city, country) values ('Sujitan', 'China');
insert into city_country (city, country) values ('Talas', 'Kyrgyzstan');
insert into city_country (city, country) values ('Kavār', 'Iran');
insert into city_country (city, country) values ('Naranjo', 'Costa Rica');
insert into city_country (city, country) values ('Mogapi', 'Botswana');
insert into city_country (city, country) values ('Pak Phanang', 'Thailand');
insert into city_country (city, country) values ('Xuanzhou', 'China');
insert into city_country (city, country) values ('Gejiu', 'China');
insert into city_country (city, country) values ('Ribamar', 'Portugal');
insert into city_country (city, country) values ('Doksy', 'Czech Republic');
insert into city_country (city, country) values ('Matsubase', 'Japan');
insert into city_country (city, country) values ('Mongo', 'Chad');
insert into city_country (city, country) values ('Tottori', 'Japan');
insert into city_country (city, country) values ('Kabale', 'Uganda');
insert into city_country (city, country) values ('Opi', 'Nigeria');
insert into city_country (city, country) values ('Hankazi', 'China');
insert into city_country (city, country) values ('Kediri', 'Indonesia');
insert into city_country (city, country) values ('Talaibon', 'Philippines');
insert into city_country (city, country) values ('Alikalia', 'Sierra Leone');
insert into city_country (city, country) values ('Flórina', 'Greece');
insert into city_country (city, country) values ('Quezon City', 'Philippines');
insert into city_country (city, country) values ('Thị Trấn Phong Thổ', 'Vietnam');
insert into city_country (city, country) values ('Castelo', 'Portugal');
insert into city_country (city, country) values ('Lancar', 'Indonesia');
insert into city_country (city, country) values ('Savelugu', 'Ghana');
insert into city_country (city, country) values ('Santa Ana', 'Philippines');
insert into city_country (city, country) values ('Barra do Piraí', 'Brazil');
insert into city_country (city, country) values ('Saidpur', 'Bangladesh');
insert into city_country (city, country) values ('Kill', 'Ireland');
insert into city_country (city, country) values ('Ngembul', 'Indonesia');
insert into city_country (city, country) values ('Santa María Ixhuatán', 'Guatemala');
insert into city_country (city, country) values ('Alasmalang', 'Indonesia');
insert into city_country (city, country) values ('Puyan', 'China');
insert into city_country (city, country) values ('Mników', 'Poland');
insert into city_country (city, country) values ('Kalininskiy', 'Russia');
insert into city_country (city, country) values ('Waimangura', 'Indonesia');
insert into city_country (city, country) values ('Bojonggaling', 'Indonesia');
insert into city_country (city, country) values ('Zarichchya', 'Ukraine');
insert into city_country (city, country) values ('Ghormach', 'Afghanistan');
insert into city_country (city, country) values ('Outeirô', 'Portugal');
insert into city_country (city, country) values ('Timoulilt', 'Morocco');
insert into city_country (city, country) values ('Thạnh Hóa', 'Vietnam');
insert into city_country (city, country) values ('Aviúges', 'Portugal');
insert into city_country (city, country) values ('Áyios Nikólaos', 'Greece');
insert into city_country (city, country) values ('Saint John’s', 'Antigua and Barbuda');
insert into city_country (city, country) values ('Progreso', 'Peru');
insert into city_country (city, country) values ('Santo Domingo', 'Philippines');
insert into city_country (city, country) values ('Auch', 'France');
insert into city_country (city, country) values ('Detik Satu', 'Indonesia');
insert into city_country (city, country) values ('Santana do Livramento', 'Brazil');
insert into city_country (city, country) values ('Igrim', 'Russia');
insert into city_country (city, country) values ('Fangfan', 'China');
insert into city_country (city, country) values ('Dangcalan', 'Philippines');
insert into city_country (city, country) values ('Coxim', 'Brazil');
insert into city_country (city, country) values ('Tegalsari', 'Indonesia');
insert into city_country (city, country) values ('Marabá', 'Brazil');
insert into city_country (city, country) values ('Nossa Senhora da Glória', 'Brazil');
insert into city_country (city, country) values ('Pandan', 'Philippines');
insert into city_country (city, country) values ('Avellaneda', 'Argentina');
insert into city_country (city, country) values ('Gandorhun', 'Sierra Leone');
insert into city_country (city, country) values ('Shilong', 'China');
insert into city_country (city, country) values ('Karabas', 'Kazakhstan');
insert into city_country (city, country) values ('Pereira', 'Portugal');
insert into city_country (city, country) values ('Bilajer', 'Azerbaijan');
insert into city_country (city, country) values ('Songjianghe', 'China');
insert into city_country (city, country) values ('Auas', 'Honduras');


insert into movie (movie_title, genre, lang) values ('Battle of China, The (Why We Fight, 6)', 'Documentary|War', 'Zulu');
insert into movie (movie_title, genre, lang) values ('Ghost Rider: Spirit of Vengeance', 'Action|Fantasy|Thriller', 'Maltese');
insert into movie (movie_title, genre, lang) values ('...tick... tick... tick...', 'Action|Drama', 'Croatian');
insert into movie (movie_title, genre, lang) values ('Bad Words', 'Comedy', 'Malayalam');
insert into movie (movie_title, genre, lang) values ('The Man Who Shook the Hand of Vicente Fernandez', 'Comedy|Drama|Western', 'Finnish');
insert into movie (movie_title, genre, lang) values ('Faat Kiné', 'Comedy|Drama', 'Afrikaans');
insert into movie (movie_title, genre, lang) values ('Summer''s Tale, A (Conte d''été)', 'Comedy|Drama|Romance', 'Belarusian');
insert into movie (movie_title, genre, lang) values ('Castle of Sand, The (Suna no utsuwa)', 'Crime|Mystery|Thriller', 'Tetum');
insert into movie (movie_title, genre, lang) values ('Jason Becker: Not Dead Yet', 'Documentary', 'Gagauz');
insert into movie (movie_title, genre, lang) values ('Tillbaka till Bromma', 'Comedy', 'Hiri Motu');
insert into movie (movie_title, genre, lang) values ('Devil at 4 O''Clock, The', 'Drama', 'Belarusian');
insert into movie (movie_title, genre, lang) values ('Betty', 'Drama', 'Aymara');
insert into movie (movie_title, genre, lang) values ('Vince Vaughn''s Wild West Comedy Show: 30 Days & 30 Nights - Hollywood to the Heartland', 'Comedy|Documentary', 'Japanese');
insert into movie (movie_title, genre, lang) values ('Return to Salem''s Lot, A', 'Horror', 'Lao');
insert into movie (movie_title, genre, lang) values ('2 ou 3 choses que je sais d''elle (2 or 3 Things I Know About Her)', 'Drama', 'Hiri Motu');
insert into movie (movie_title, genre, lang) values ('Monster in the Closet', 'Comedy|Horror', 'Punjabi');
insert into movie (movie_title, genre, lang) values ('Altered States', 'Drama|Sci-Fi', 'Norwegian');
insert into movie (movie_title, genre, lang) values ('Clean, Shaven', 'Crime|Drama', 'Pashto');
insert into movie (movie_title, genre, lang) values ('I Am Comic', 'Documentary', 'Marathi');
insert into movie (movie_title, genre, lang) values ('Incident at Oglala', 'Documentary', 'Macedonian');
insert into movie (movie_title, genre, lang) values ('Shadow Conspiracy', 'Thriller', 'Khmer');
insert into movie (movie_title, genre, lang) values ('Nowhere to Run', 'Action|Romance', 'Telugu');
insert into movie (movie_title, genre, lang) values ('Das Leben ist nichts für Feiglinge', 'Drama', 'Pashto');
insert into movie (movie_title, genre, lang) values ('Abe Lincoln in Illinois', 'Drama', 'Macedonian');
insert into movie (movie_title, genre, lang) values ('Kiss Me (Kyss Mig)', 'Drama|Romance', 'Kazakh');
insert into movie (movie_title, genre, lang) values ('Wild Seven', 'Crime|Drama', 'Danish');
insert into movie (movie_title, genre, lang) values ('Mikra Anglia', 'Drama|Romance', 'Macedonian');
insert into movie (movie_title, genre, lang) values ('Flight Command', 'Drama|War', 'Romanian');
insert into movie (movie_title, genre, lang) values ('Queen Sized', 'Comedy|Drama', 'Greek');
insert into movie (movie_title, genre, lang) values ('It Felt Like Love', 'Drama', 'German');
insert into movie (movie_title, genre, lang) values ('Blonde and Blonder', 'Comedy|Crime', 'Quechua');
insert into movie (movie_title, genre, lang) values ('Son of Godzilla (Kaijûtô no kessen: Gojira no musuko)', 'Sci-Fi', 'English');
insert into movie (movie_title, genre, lang) values ('Hotel Rwanda', 'Drama|War', 'Luxembourgish');
insert into movie (movie_title, genre, lang) values ('Tyler Perry''s A Madea Christmas', 'Comedy', 'Kashmiri');
insert into movie (movie_title, genre, lang) values ('Corky Romano', 'Comedy|Crime', 'Bislama');
insert into movie (movie_title, genre, lang) values ('Smart People', 'Comedy|Drama|Romance', 'Chinese');
insert into movie (movie_title, genre, lang) values ('Mein Kampf', 'Comedy|Drama', 'Belarusian');
insert into movie (movie_title, genre, lang) values ('American Psycho II: All American Girl', 'Comedy|Crime|Horror|Mystery|Thriller', 'Haitian Creole');
insert into movie (movie_title, genre, lang) values ('Happythankyoumoreplease', 'Comedy|Drama', 'Japanese');
insert into movie (movie_title, genre, lang) values ('Kid Millions', 'Comedy|Musical', 'Czech');
insert into movie (movie_title, genre, lang) values ('Faces of Death', 'Documentary|Horror', 'Romanian');
insert into movie (movie_title, genre, lang) values ('Unbeatable (Ji zhan)', 'Action|Drama', 'Armenian');
insert into movie (movie_title, genre, lang) values ('No Looking Back', 'Drama|Romance', 'Hindi');
insert into movie (movie_title, genre, lang) values ('Benjamin Blümchen - Seine schönsten Abenteuer', '(no genres listed)', 'Dari');
insert into movie (movie_title, genre, lang) values ('Hondo', 'Western', 'Maltese');
insert into movie (movie_title, genre, lang) values ('Starship Troopers 3: Marauder', 'Action|Sci-Fi|War', 'Finnish');
insert into movie (movie_title, genre, lang) values ('Dance with a Stranger', 'Crime|Drama|Thriller', 'Malay');
insert into movie (movie_title, genre, lang) values ('Proud and the Beautiful, The (Orgueilleux, Les) (Proud Ones, The)', 'Drama', 'English');
insert into movie (movie_title, genre, lang) values ('Sexy Beast', 'Comedy|Crime|Drama', 'Greek');
insert into movie (movie_title, genre, lang) values ('Terminator Salvation', 'Action|Adventure|Sci-Fi|Thriller', 'Polish');
insert into movie (movie_title, genre, lang) values ('Seconds', 'Mystery|Sci-Fi|Thriller', 'Romanian');
insert into movie (movie_title, genre, lang) values ('Revenge of the Nerds IV: Nerds in Love', 'Comedy|Romance', 'Telugu');
insert into movie (movie_title, genre, lang) values ('On the Edge', 'Drama', 'Bislama');
insert into movie (movie_title, genre, lang) values ('Faust', 'Drama', 'New Zealand Sign Language');
insert into movie (movie_title, genre, lang) values ('Who''s Your Caddy?', 'Comedy', 'Somali');
insert into movie (movie_title, genre, lang) values ('Dog Run', 'Drama', 'English');
insert into movie (movie_title, genre, lang) values ('Den enskilde medborgaren', 'Comedy', 'Tswana');
insert into movie (movie_title, genre, lang) values ('Men Cry Bullets', 'Comedy|Drama', 'English');
insert into movie (movie_title, genre, lang) values ('My Son the Fanatic', 'Comedy|Drama|Romance', 'Hungarian');
insert into movie (movie_title, genre, lang) values ('Gomorrah (Gomorra)', 'Crime|Drama', 'Filipino');
insert into movie (movie_title, genre, lang) values ('Pancho, the Millionaire Dog', 'Children|Comedy', 'Lao');
insert into movie (movie_title, genre, lang) values ('Spanish Apartment, The (L''auberge espagnole)', 'Comedy|Drama|Romance', 'Guaraní');
insert into movie (movie_title, genre, lang) values ('Fighting Elegy (Kenka erejii)', 'Action|Comedy', 'New Zealand Sign Language');
insert into movie (movie_title, genre, lang) values ('588 Rue Paradis (Mother)', 'Drama', 'Tswana');
insert into movie (movie_title, genre, lang) values ('Seven Days to Noon', 'Drama|Thriller', 'Swedish');
insert into movie (movie_title, genre, lang) values ('Shock Treatment', 'Comedy|Musical|Sci-Fi', 'Hindi');
insert into movie (movie_title, genre, lang) values ('Miffo', 'Comedy|Drama|Romance', 'Croatian');
insert into movie (movie_title, genre, lang) values ('De-Lovely', 'Drama|Musical', 'Gujarati');
insert into movie (movie_title, genre, lang) values ('Care Bears Movie, The', 'Animation|Children|Fantasy', 'Tajik');
insert into movie (movie_title, genre, lang) values ('Don''t Be a Menace to South Central While Drinking Your Juice in the Hood', 'Comedy|Crime', 'Pashto');
insert into movie (movie_title, genre, lang) values ('The Suspicious Death of a Minor', 'Comedy|Crime|Thriller', 'Malayalam');
insert into movie (movie_title, genre, lang) values ('Snow Walker, The', 'Adventure|Drama', 'Portuguese');
insert into movie (movie_title, genre, lang) values ('Shanghai Noon', 'Action|Adventure|Comedy|Western', 'Bislama');
insert into movie (movie_title, genre, lang) values ('Human Trafficking', 'Crime|Drama|Mystery|Thriller', 'Malay');
insert into movie (movie_title, genre, lang) values ('Chamber, The', 'Drama', 'Latvian');
insert into movie (movie_title, genre, lang) values ('Play it to the Bone', 'Comedy|Drama', 'Georgian');
insert into movie (movie_title, genre, lang) values ('Asterix and the Gauls (Astérix le Gaulois)', 'Action|Adventure|Animation|Children|Comedy', 'Pashto');
insert into movie (movie_title, genre, lang) values ('Finding Fela!', 'Documentary', 'Hiri Motu');
insert into movie (movie_title, genre, lang) values ('Rosie', 'Drama', 'Māori');
insert into movie (movie_title, genre, lang) values ('Show Boat', 'Comedy|Drama|Musical|Romance', 'Bengali');
insert into movie (movie_title, genre, lang) values ('Home Sweet Hell', 'Comedy|Drama', 'Bislama');
insert into movie (movie_title, genre, lang) values ('It Happened One Night', 'Comedy|Romance', 'Swati');
insert into movie (movie_title, genre, lang) values ('Caught', 'Drama', 'Hiri Motu');
insert into movie (movie_title, genre, lang) values ('Frozen', 'Drama', 'West Frisian');
insert into movie (movie_title, genre, lang) values ('U.S. vs. John Lennon, The', 'Documentary', 'Belarusian');
insert into movie (movie_title, genre, lang) values ('It! The Terror from Beyond Space', 'Horror|Sci-Fi|Thriller', 'Luxembourgish');
insert into movie (movie_title, genre, lang) values ('King Sized', 'Comedy|Drama', 'Nepali');
insert into movie (movie_title, genre, lang) values ('Inserts', 'Comedy|Drama', 'Spanish');
insert into movie (movie_title, genre, lang) values ('3 Days to Kill', 'Action|Crime|Drama', 'Italian');
insert into movie (movie_title, genre, lang) values ('Zero Charisma', 'Comedy|Drama', 'Dhivehi');
insert into movie (movie_title, genre, lang) values ('Les modèles de ''Pickpocket''', 'Documentary', 'Burmese');
insert into movie (movie_title, genre, lang) values ('Glass Web, The', 'Crime|Drama|Film-Noir', 'Kannada');
insert into movie (movie_title, genre, lang) values ('Debt, The', 'Thriller', 'German');
insert into movie (movie_title, genre, lang) values ('Bogowie', 'Drama', 'Chinese');
insert into movie (movie_title, genre, lang) values ('Rammbock', 'Drama|Horror', 'Telugu');
insert into movie (movie_title, genre, lang) values ('This is Martin Bonner', 'Drama', 'Swahili');
insert into movie (movie_title, genre, lang) values ('Carman: The Champion', 'Action|Drama', 'Montenegrin');
insert into movie (movie_title, genre, lang) values ('Cazuza - O Tempo Não Pára', 'Drama', 'Bengali');
insert into movie (movie_title, genre, lang) values ('Topper Takes a Trip', 'Comedy|Fantasy|Romance', 'Spanish');
insert into movie (movie_title, genre, lang) values ('Cosmic Psychos: Blokes You Can Trust', 'Documentary|Musical', 'Hiri Motu');


/*
SELECT * 
FROM city_country;
SELECT * 
FROM movie;
*/
 
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


insert into movie_city(movie_title, city)
select movie.movie_title, city_country.city
from movie, city_country
ORDER BY RANDOM()
limit 1000;

SELECT *
FROM movie_city
Order by movie_title, city;