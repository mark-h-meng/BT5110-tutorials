/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/

/* Student number: A0231847B */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */

/* Company A is an online survey company based in Singapore, specializing in conducting online surveys
with physicians in Singapore for its clients including pharmaceutical and medical device companies, etc.

Company A has an online panel with physicians who have signed up to the panel previously. Also company A keeps 
records of all the surveys it has completed or is still ongoing.
Company A wants to manage its physician and survey data more efficiently, and also hopes to analyse physicians'
participation in the surveys. Thus, the followings have been developed:

Entity set E1 is set as physicians. Table E1 contains all the important information about physicians such as first name,
last name, physicianID, specialty, sector, organization name, email, years of experience.

Entity set E2 is set as surveys. Table E2 consists of information such as survey name, wave number (i.e. default is 1. 
When a survey is repeated for 2nd time, wave # would be assigned as 2), client name, therapy area, revenue, project 
status (i.e. ongoing, completed).

Relation set R is set as participation.Table R captures information about physicians' participation in surveys by 
associating physicianID with survey name & wave number. This helps us to track the participation rate of individual 
physician in the panel. */


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS physicians (
  first_name VARCHAR(64) NOT NULL, 
  last_name VARCHAR(64) NOT NULL, 
  physicianID VARCHAR(16) PRIMARY KEY, 
  specialty VARCHAR(64) NOT NULL, 
  sector VARCHAR (16) NOT NULL, 
  email VARCHAR(64) UNIQUE NOT NULL, 
  organization VARCHAR(64) NOT NULL, 
  experience_since DATE NOT NULL
);
CREATE TABLE IF NOT EXISTS surveys (
  survey_name VARCHAR(64) NOT NULL, 
  wave INT NOT NULL CHECK (wave > 0), 
  client_name VARCHAR(128) NOT NULL, 
  therapy_area VARCHAR (64) NOT NULL, 
  revenue NUMERIC NOT NULL CHECK (revenue > 0), 
  status VARCHAR (10) CONSTRAINT status CHECK (
    status = 'ongoing' 
    OR status = 'completed'
  ), 
  PRIMARY KEY (survey_name, wave)
);
CREATE TABLE participation(
  physicianID VARCHAR(16) REFERENCES physicians(physicianID) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED, 
  survey_name VARCHAR(64), 
  wave INT, 
  PRIMARY KEY (physicianID, survey_name, wave), 
  FOREIGN KEY (survey_name, wave) REFERENCES surveys(survey_name, wave) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/***************************

  Populate the physicians table

****************************/

insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Natassia', 'Stuckford', 'nstuckford0', 'Radiologist', 'Private', 'Koss LLC hospital', 'nstuckford0@fc2.com', '2008/11/10');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Warner', 'O''Brollachain', 'wobrollachain1', 'Dermatologist', 'Public', 'Langworth LLC hospital', 'wobrollachain1@4shared.com', '1994/10/06');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Lorie', 'Stitfall', 'lstitfall2', 'Family physician/General practioner', 'Public', 'Breitenberg, Murray and Quitzon hospital', 'lstitfall2@accuweather.com', '2009/08/31');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Sax', 'Debenham', 'sdebenham3', 'Ophthalmologist', 'Private', 'Frami, Senger and Rempel hospital', 'sdebenham3@hp.com', '2001/08/01');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Kellen', 'Giocannoni', 'kgiocannoni4', 'Anesthesiologist', 'Public', 'Schaefer Inc hospital', 'kgiocannoni4@toplist.cz', '1999/12/30');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Daisi', 'Londesborough', 'dlondesborough5', 'Gastroenterologist', 'Public', 'Ledner Group hospital', 'dlondesborough5@example.com', '2011/06/23');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Anastasie', 'Afonso', 'aafonso6', 'Oncologist', 'Private', 'Rolfson, Hartmann and West hospital', 'aafonso6@ca.gov', '2004/11/09');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Joelle', 'Ferrucci', 'jferrucci7', 'Anesthesiologist', 'Private', 'Volkman-Berge hospital', 'jferrucci7@dedecms.com', '1999/03/16');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Jobyna', 'Perot', 'jperot8', 'Gastroenterologist', 'Private', 'Lind-Hartmann hospital', 'jperot8@cnn.com', '2006/08/24');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Obie', 'Keeton', 'okeeton9', 'Neurologist', 'Public', 'Dickinson LLC hospital', 'okeeton9@joomla.org', '2003/01/17');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Carlyn', 'Roofe', 'croofea', 'Neurologist', 'Public', 'Turcotte, Pfannerstill and Botsford hospital', 'croofea@bloglovin.com', '1992/02/04');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Boyce', 'Bound', 'bboundb', 'Gynecologist', 'Public', 'Kassulke LLC hospital', 'bboundb@google.com', '2010/07/01');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Nikki', 'Cluney', 'ncluneyc', 'Endocrinologist', 'Public', 'Brown and Sons hospital', 'ncluneyc@tamu.edu', '1994/09/18');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Jeremie', 'Burdus', 'jburdusd', 'Anesthesiologist', 'Private', 'Pagac-Armstrong hospital', 'jburdusd@bbc.co.uk', '2007/03/16');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Angelo', 'Cubbino', 'acubbinoe', 'Family physician/General practioner', 'Public', 'Schaden, Raynor and Funk hospital', 'acubbinoe@chronoengine.com', '1993/12/04');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Ariel', 'Hassewell', 'ahassewellf', 'Anesthesiologist', 'Public', 'Batz-Bosco hospital', 'ahassewellf@hhs.gov', '2010/10/29');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Clementius', 'Faulds', 'cfauldsg', 'Oncologist', 'Private', 'Price Inc hospital', 'cfauldsg@cbsnews.com', '2014/06/04');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Porty', 'Marczyk', 'pmarczykh', 'Endocrinologist', 'Public', 'Littel-Purdy hospital', 'pmarczykh@cnbc.com', '2015/06/14');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Christi', 'Izakson', 'cizaksoni', 'Endocrinologist', 'Public', 'Jenkins and Sons hospital', 'cizaksoni@nytimes.com', '1992/10/30');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Fraze', 'Fautley', 'ffautleyj', 'Nephrologist', 'Private', 'Cronin Inc hospital', 'ffautleyj@acquirethisname.com', '2006/08/29');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Gail', 'McCorry', 'gmccorryk', 'Gastroenterologist', 'Public', 'Miller, Kulas and Zulauf hospital', 'gmccorryk@hud.gov', '2005/07/08');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Leshia', 'Olenikov', 'lolenikovl', 'Neurologist', 'Private', 'Mayert, Medhurst and Heathcote hospital', 'lolenikovl@yellowbook.com', '2016/02/24');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Hermine', 'Rubinfajn', 'hrubinfajnm', 'Infectious disease physician', 'Public', 'Reilly LLC hospital', 'hrubinfajnm@simplemachines.org', '2012/08/18');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Vincents', 'Farrears', 'vfarrearsn', 'Gynecologist', 'Public', 'Koss Group hospital', 'vfarrearsn@ibm.com', '2018/10/07');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Aeriell', 'Bartosinski', 'abartosinskio', 'Family physician/General practioner', 'Private', 'Wisoky, Lockman and Hoeger hospital', 'abartosinskio@independent.co.uk', '1995/09/23');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Gregorio', 'Bernolet', 'gbernoletp', 'Ophthalmologist', 'Public', 'Lang-Stamm hospital', 'gbernoletp@angelfire.com', '2016/03/12');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Cassie', 'Cleen', 'ccleenq', 'Neurologist', 'Private', 'Flatley LLC hospital', 'ccleenq@slideshare.net', '2012/09/08');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Sophey', 'Unstead', 'sunsteadr', 'Psychiatrist', 'Private', 'Adams and Sons hospital', 'sunsteadr@edublogs.org', '2006/10/22');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Maridel', 'Mordey', 'mmordeys', 'Oncologist', 'Public', 'Wolf, Fahey and Schoen hospital', 'mmordeys@hatena.ne.jp', '1999/02/26');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Katha', 'Padrick', 'kpadrickt', 'Nephrologist', 'Private', 'Kris, Ullrich and Beer hospital', 'kpadrickt@flickr.com', '1990/02/05');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Corrine', 'Pankethman', 'cpankethmanu', 'Neurologist', 'Public', 'MacGyver, Orn and Larson hospital', 'cpankethmanu@posterous.com', '2015/10/01');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Corney', 'Clewer', 'cclewerv', 'Neurologist', 'Public', 'Bergstrom, Botsford and Collier hospital', 'cclewerv@a8.net', '2013/08/29');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Kathryn', 'Mulvenna', 'kmulvennaw', 'Nephrologist', 'Private', 'Champlin-Wunsch hospital', 'kmulvennaw@blogspot.com', '1999/06/26');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Caroline', 'Quilkin', 'cquilkinx', 'Family physician/General practioner', 'Public', 'Kuphal Group hospital', 'cquilkinx@tamu.edu', '1993/09/17');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Dunn', 'Baudino', 'dbaudinoy', 'Cardiologist', 'Private', 'Gottlieb LLC hospital', 'dbaudinoy@ftc.gov', '2015/02/25');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Chrissie', 'Ruslin', 'cruslinz', 'Ophthalmologist', 'Private', 'Schuster Group hospital', 'cruslinz@diigo.com', '2008/12/19');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Griffy', 'Picot', 'gpicot10', 'Gastroenterologist', 'Private', 'Schmidt-Lakin hospital', 'gpicot10@engadget.com', '1995/01/06');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Zilvia', 'Egerton', 'zegerton11', 'Oncologist', 'Private', 'Kozey LLC hospital', 'zegerton11@hostgator.com', '2008/08/17');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Louise', 'Krammer', 'lkrammer12', 'Oncologist', 'Private', 'Rogahn, Walter and Hintz hospital', 'lkrammer12@huffingtonpost.com', '1998/06/20');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Hattie', 'Jorcke', 'hjorcke13', 'Infectious disease physician', 'Private', 'Lebsack-Jacobson hospital', 'hjorcke13@phoca.cz', '2006/08/22');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Joni', 'Bloxland', 'jbloxland14', 'Cardiologist', 'Public', 'Schoen and Sons hospital', 'jbloxland14@dailymotion.com', '2016/03/13');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Gorden', 'Lehemann', 'glehemann15', 'Infectious disease physician', 'Private', 'Parisian-Block hospital', 'glehemann15@tamu.edu', '2016/02/27');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Silvia', 'Mendel', 'smendel16', 'Nephrologist', 'Public', 'O''Hara-Watsica hospital', 'smendel16@4shared.com', '2000/01/13');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Krissie', 'Iacomo', 'kiacomo17', 'Nephrologist', 'Private', 'O''Connell-Roberts hospital', 'kiacomo17@washington.edu', '2010/12/11');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Bonnee', 'Ourry', 'bourry18', 'Dermatologist', 'Public', 'Runolfsson, Toy and Pfannerstill hospital', 'bourry18@com.com', '1997/09/05');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Cybil', 'Hessing', 'chessing19', 'Internal medicine', 'Private', 'Bruen, Crooks and Cronin hospital', 'chessing19@shop-pro.jp', '2004/05/28');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Armand', 'Mazin', 'amazin1a', 'Neurologist', 'Private', 'Pacocha-Kub hospital', 'amazin1a@wordpress.com', '1991/10/21');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Mort', 'Faragher', 'mfaragher1b', 'Internal medicine', 'Private', 'Rutherford LLC hospital', 'mfaragher1b@npr.org', '1998/10/12');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Shane', 'Kocher', 'skocher1c', 'Neurologist', 'Public', 'Schaefer Group hospital', 'skocher1c@yandex.ru', '1995/06/30');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Eb', 'Hellmer', 'ehellmer1d', 'Nephrologist', 'Public', 'Lehner-Rippin hospital', 'ehellmer1d@mac.com', '2018/06/07');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Kendall', 'Broome', 'kbroome1e', 'Pulmonologist', 'Public', 'Welch-Rath hospital', 'kbroome1e@about.me', '1996/10/01');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Meredithe', 'Crippell', 'mcrippell1f', 'Gastroenterologist', 'Public', 'Hartmann-Grant hospital', 'mcrippell1f@squidoo.com', '2018/06/12');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Shell', 'Mouse', 'smouse1g', 'Radiologist', 'Public', 'Gusikowski, Abshire and Lubowitz hospital', 'smouse1g@creativecommons.org', '1998/10/14');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Pippy', 'Lettley', 'plettley1h', 'Anesthesiologist', 'Public', 'Kub and Sons hospital', 'plettley1h@shop-pro.jp', '2010/04/28');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Palm', 'Waghorne', 'pwaghorne1i', 'Nephrologist', 'Public', 'Larson-Streich hospital', 'pwaghorne1i@marketwatch.com', '2017/04/02');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Kelcie', 'Cavolini', 'kcavolini1j', 'Radiologist', 'Private', 'Dibbert-Heidenreich hospital', 'kcavolini1j@yolasite.com', '1995/02/09');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Andra', 'Carter', 'acarter1k', 'Neurologist', 'Public', 'Blanda-Dooley hospital', 'acarter1k@mozilla.com', '1997/10/07');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Cleopatra', 'Klimushev', 'cklimushev1l', 'Cardiologist', 'Private', 'Towne, Hudson and Altenwerth hospital', 'cklimushev1l@hhs.gov', '2013/10/12');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Celestine', 'Pillans', 'cpillans1m', 'Psychiatrist', 'Public', 'Halvorson, Blanda and Haley hospital', 'cpillans1m@google.com.au', '2008/08/22');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Jon', 'Norville', 'jnorville1n', 'Endocrinologist', 'Private', 'Kuvalis-Reynolds hospital', 'jnorville1n@washington.edu', '2012/09/28');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Frederica', 'Fosten', 'ffosten1o', 'Family physician/General practioner', 'Private', 'Ledner Inc hospital', 'ffosten1o@moonfruit.com', '1995/11/03');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Ninnette', 'McKeag', 'nmckeag1p', 'Gynecologist', 'Public', 'Grady Inc hospital', 'nmckeag1p@ebay.com', '1997/11/27');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Berget', 'Dany', 'bdany1q', 'Oncologist', 'Public', 'Osinski, Kub and Gleichner hospital', 'bdany1q@technorati.com', '2017/06/23');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Emily', 'Cholton', 'echolton1r', 'Gastroenterologist', 'Private', 'DuBuque, Stehr and Lockman hospital', 'echolton1r@bing.com', '2009/09/06');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Aretha', 'Gutsell', 'agutsell1s', 'Internal medicine', 'Public', 'Jast and Sons hospital', 'agutsell1s@storify.com', '1995/04/26');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Carlynn', 'McClosh', 'cmcclosh1t', 'Gastroenterologist', 'Private', 'Willms, Konopelski and Heller hospital', 'cmcclosh1t@google.com.hk', '1993/04/28');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Ada', 'Gauch', 'agauch1u', 'Psychiatrist', 'Public', 'Kuhic, Kunde and Oberbrunner hospital', 'agauch1u@infoseek.co.jp', '1991/01/19');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Maritsa', 'Tomblett', 'mtomblett1v', 'Nephrologist', 'Public', 'Collier, Macejkovic and Gusikowski hospital', 'mtomblett1v@army.mil', '2015/02/04');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Jethro', 'Papes', 'jpapes1w', 'Nephrologist', 'Public', 'Lockman, Dickens and Weissnat hospital', 'jpapes1w@scribd.com', '2016/05/18');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Juliana', 'Cockill', 'jcockill1x', 'Internal medicine', 'Private', 'Wiza Inc hospital', 'jcockill1x@tinypic.com', '1995/11/29');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Shaylah', 'Acreman', 'sacreman1y', 'Endocrinologist', 'Private', 'Kshlerin-Hudson hospital', 'sacreman1y@angelfire.com', '1996/03/10');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Arleta', 'MacDwyer', 'amacdwyer1z', 'Cardiologist', 'Public', 'Bailey-Murphy hospital', 'amacdwyer1z@arstechnica.com', '2008/01/26');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Olympe', 'Offell', 'ooffell20', 'Psychiatrist', 'Public', 'Russel, Cronin and Lesch hospital', 'ooffell20@wordpress.com', '2010/07/29');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Fabe', 'Elvins', 'felvins21', 'Internal medicine', 'Public', 'Thompson, Dach and Keebler hospital', 'felvins21@deviantart.com', '2003/12/24');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Ros', 'Campanelli', 'rcampanelli22', 'Infectious disease physician', 'Private', 'Breitenberg Inc hospital', 'rcampanelli22@sfgate.com', '2018/02/21');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Jamima', 'Stoffels', 'jstoffels23', 'Anesthesiologist', 'Private', 'Gorczany-Swaniawski hospital', 'jstoffels23@google.ru', '2007/05/08');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Birgitta', 'Drowsfield', 'bdrowsfield24', 'Family physician/General practioner', 'Public', 'Murray and Sons hospital', 'bdrowsfield24@1und1.de', '1990/07/02');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Deny', 'Muge', 'dmuge25', 'Endocrinologist', 'Public', 'Hills, Nikolaus and Keebler hospital', 'dmuge25@pbs.org', '2018/02/02');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Saundra', 'Salter', 'ssalter26', 'Dermatologist', 'Public', 'Rohan Inc hospital', 'ssalter26@rakuten.co.jp', '2007/07/19');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Amata', 'Brownscombe', 'abrownscombe27', 'Gastroenterologist', 'Public', 'Treutel-Stokes hospital', 'abrownscombe27@over-blog.com', '1993/07/15');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Hy', 'Keuning', 'hkeuning28', 'Radiologist', 'Private', 'Russel, Kessler and Rutherford hospital', 'hkeuning28@ameblo.jp', '1995/02/01');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Madella', 'Kearton', 'mkearton29', 'Neurologist', 'Private', 'Corwin LLC hospital', 'mkearton29@facebook.com', '1997/10/16');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Jojo', 'Marieton', 'jmarieton2a', 'Pulmonologist', 'Private', 'Spencer Inc hospital', 'jmarieton2a@ifeng.com', '2000/07/04');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Stanislaus', 'Senter', 'ssenter2b', 'Cardiologist', 'Private', 'Sanford, Zboncak and Rutherford hospital', 'ssenter2b@yahoo.co.jp', '2017/04/13');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Tybi', 'Sidden', 'tsidden2c', 'Oncologist', 'Public', 'Spinka, Kerluke and Smith hospital', 'tsidden2c@arizona.edu', '2009/02/22');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Denis', 'Livezley', 'dlivezley2d', 'Internal medicine', 'Private', 'Leffler-Skiles hospital', 'dlivezley2d@over-blog.com', '2005/11/17');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Aubert', 'Carde', 'acarde2e', 'Neurologist', 'Private', 'Labadie Inc hospital', 'acarde2e@indiatimes.com', '2016/12/02');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Lyssa', 'Pitcher', 'lpitcher2f', 'Dermatologist', 'Public', 'Turcotte-Luettgen hospital', 'lpitcher2f@archive.org', '2008/03/23');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Colver', 'Fenech', 'cfenech2g', 'Dermatologist', 'Private', 'Price-Breitenberg hospital', 'cfenech2g@networksolutions.com', '1990/12/05');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Gale', 'Bigmore', 'gbigmore2h', 'Nephrologist', 'Private', 'Labadie, Windler and Olson hospital', 'gbigmore2h@elegantthemes.com', '2008/11/06');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Marne', 'Stockin', 'mstockin2i', 'Ophthalmologist', 'Public', 'Price and Sons hospital', 'mstockin2i@dot.gov', '2010/03/24');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Trenna', 'Itzcak', 'titzcak2j', 'Ophthalmologist', 'Public', 'Prohaska, Gutmann and Gorczany hospital', 'titzcak2j@skyrock.com', '2006/12/25');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Rosamund', 'O'' Neligan', 'roneligan2k', 'Endocrinologist', 'Public', 'Schmidt, Langworth and Hills hospital', 'roneligan2k@123-reg.co.uk', '2011/05/15');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Kalie', 'Frankum', 'kfrankum2l', 'Endocrinologist', 'Public', 'West-Bednar hospital', 'kfrankum2l@youtube.com', '2015/07/14');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Huntington', 'Hirjak', 'hhirjak2m', 'Cardiologist', 'Public', 'Gulgowski-Prohaska hospital', 'hhirjak2m@oakley.com', '2000/07/03');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Pacorro', 'Rahlof', 'prahlof2n', 'Cardiologist', 'Public', 'Aufderhar Inc hospital', 'prahlof2n@intel.com', '2018/07/31');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Mort', 'Dore', 'mdore2o', 'Dermatologist', 'Private', 'Douglas, Leannon and Hauck hospital', 'mdore2o@is.gd', '2013/01/05');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Jordana', 'Butterworth', 'jbutterworth2p', 'Dermatologist', 'Private', 'West-Stehr hospital', 'jbutterworth2p@eventbrite.com', '2017/07/27');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Whitaker', 'Kenrat', 'wkenrat2q', 'Gynecologist', 'Private', 'Schoen, Wisozk and Collier hospital', 'wkenrat2q@hibu.com', '1990/08/07');
insert into physicians (first_name, last_name, physicianID, specialty, sector, organization, email, experience_since) values ('Hurlee', 'Stonhewer', 'hstonhewer2r', 'Radiologist', 'Private', 'Legros Group hospital', 'hstonhewer2r@qq.com', '2007/04/09');

/***************************

  Populate the surveys table

****************************/

insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Tampflex study', 19, 'Gilead Sciences, Inc.', 'Hematology', 360369.95, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Pannier study', 4, 'Preferred Pharmaceuticals, Inc', 'Rheumatology', 360932.22, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Vagram study', 10, 'Insight Pharmaceuticals', 'Rheumatology', 297936.52, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Vagram study', 12, 'Astrum Pharma', 'Infectious Diseases', 126003.63, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Konklab study', 2, 'Reckitt Benckiser LLC', 'Respirology', 136449.02, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Lotstring study', 1, 'Owen Biosciences, Inc.', 'Respirology', 486633.75, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Ventosanzap study', 3, 'Pacific Word Corporation', 'Ophthalmology', 146290.18, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Stim study', 3, 'MSD Consumer Care, Inc.', 'Oncology', 180914.23, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Bitchip study', 12, 'Major Pharmaceuticals', 'Cardiology', 365212.21, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Wrapsafe study', 12, 'Amneal Pharmaceuticals, LLC', 'Gastroenterology', 189992.89, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Tresom study', 19, 'PD-Rx Pharmaceuticals, Inc.', 'Immunology', 144381.61, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Home Ing study', 19, 'UCB, Inc.', 'Cardiology', 314467.98, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Toughjoyfax study', 13, 'Nelco Laboratories, Inc.', 'Cardiology', 107560.89, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Andalax study', 16, 'TYA Pharmaceuticals', 'Orthopedics', 138250.34, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Tresom study', 14, 'Gurwitch Products, L.L.C.', 'Metabolism and Endocrinology', 37737.22, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Span study', 3, 'Evonik Stockhausen, LLC', 'Cardiology', 396921.93, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('It study', 9, 'Antigen Laboratories, Inc.', 'Respirology', 126991.76, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Matsoft study', 20, 'Antigen Laboratories, Inc.', 'Respirology', 181236.73, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Fat San study', 20, 'REMEDYREPACK INC.', 'Oncology', 477493.0, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Subin study', 5, 'Aurobindo Pharma Limited', 'Gastroenterology', 30693.25, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Quo Lux study', 10, 'Dispensing Solutions, Inc.', 'Oncology', 469912.0, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Vagram study', 9, 'McNeil Consumer Healthcare Div McNeil-PPC, Inc', 'Orthopedics', 445908.62, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Tampflex study', 14, 'Meijer Distribution Inc', 'Gastroenterology', 45605.43, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Konklux study', 10, 'REMEDYREPACK INC.', 'Dermatology', 496496.86, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Regrant study', 8, 'Hyland''s', 'Cardiology', 151747.21, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Veribet study', 8, 'WOCKHARDT USA LLC.', 'Psychiatry', 491052.75, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Cookley study', 2, 'JHP Pharmaceuticals LLC', 'Infectious Diseases', 205350.42, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Daltfresh study', 2, 'Pharmacia and Upjohn Company', 'Urology', 495822.94, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Sonair study', 12, 'Allergy Laboratories, Inc.', 'Immunology', 173492.48, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Daltfresh study', 6, 'Micro Labs Limited', 'Ophthalmology', 115369.84, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Opela study', 15, 'Cardinal Health', 'Infectious Diseases', 421843.51, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Fix San study', 15, 'JHP Pharmaceuticals, LLC.', 'Oncology', 355077.02, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Prodder study', 15, 'REMEDYREPACK INC.', 'Respirology', 449626.03, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Tampflex study', 11, 'WALGREEN CO.', 'Urology', 372319.16, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Gembucket study', 13, 'ALK-Abello, Inc.', 'Cardiology', 494966.79, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Job study', 12, 'Crown Laboratories', 'Rheumatology', 213102.65, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Zathin study', 14, 'Roche Products Inc', 'Ophthalmology', 326931.85, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Redhold study', 6, 'Teva Parenteral Medicines, Inc.', 'Hematology', 376317.09, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Y-find study', 4, 'Dabur India Limited', 'Orthopedics', 283596.58, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Namfix study', 13, 'Aphena Pharma Solutions - Tennessee, LLC', 'Respirology', 456666.41, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Subin study', 4, 'Upsher-Smith Laboratories, Inc.', 'Psychiatry', 200944.4, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Span study', 19, 'Tahitian Noni International', 'Immunology', 456719.98, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Sonair study', 7, 'DIRECT RX', 'Neurology', 42343.1, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Tin study', 20, 'ZION SYNTHETIC FIBER CO., LTD.', 'Oncology', 355977.16, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Bitwolf study', 12, 'Johnson & Johnson Consumer Products Company, Division of Johnson & Johnson Consumer Companies, Inc.', 'Ophthalmology', 103834.89, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Veribet study', 13, 'Apotheca Company', 'Psychiatry', 388368.2, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Voyatouch study', 17, 'Skinfix, Inc.', 'Infectious Diseases', 108815.96, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Bitchip study', 14, 'US WorldMeds, LLC', 'Ophthalmology', 382438.64, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Fixflex study', 4, 'Teva Pharmaceuticals USA Inc', 'Ophthalmology', 13563.5, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Fix San study', 11, 'Bristol-Myers Squibb Company', 'Infectious Diseases', 219204.05, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Wrapsafe study', 5, 'AbbVie Inc.', 'Urology', 37974.74, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Redhold study', 13, 'Johnson & Johnson Consumer Products Company, Division of Johnson & Johnson Consumer Companies, Inc.', 'Psychiatry', 332402.02, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Overhold study', 18, 'Kremers Urban Pharmaceuticals Inc.', 'Oncology', 492877.4, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Bigtax study', 6, 'Cardinal Health', 'Urology', 394780.43, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Y-find study', 11, 'Energizer Personal Care LLC', 'Oncology', 444669.45, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Alpha study', 13, 'RCS Management Corporation', 'Oncology', 289676.03, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Greenlam study', 12, 'My Habitat Brands LLC', 'Ophthalmology', 385918.83, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Overhold study', 9, 'Nelson Bach USA, Ltd.', 'Orthopedics', 233003.03, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Zathin study', 1, 'Cardinal Health', 'Gastroenterology', 413088.11, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Gembucket study', 17, 'Clinical Solutions Wholesale', 'Psychiatry', 426766.0, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Konklab study', 7, 'Deseret Biologicals', 'Gastroenterology', 267690.41, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Aerified study', 11, 'McKesson', 'Infectious Diseases', 123818.75, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('It study', 7, 'Stephen L. LaFrance Pharmacy, Inc.', 'Gastroenterology', 74243.78, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Solarbreeze study', 13, 'Alva-Amco Pharmacal Companies, Inc.', 'Oncology', 118257.38, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Cardify study', 17, 'Hospira, Inc.', 'Rheumatology', 147116.75, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Regrant study', 6, 'Bath & Body Works, Inc.', 'Oncology', 437817.98, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Span study', 20, 'Laboratoires Boiron', 'Rheumatology', 336225.52, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Namfix study', 16, 'Nelco Laboratories, Inc.', 'Neurology', 18790.25, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Rank study', 10, 'Zermat Internacional S.A. de C.V.', 'Rheumatology', 141410.79, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Redhold study', 8, 'Newton Laboratories, Inc.', 'Hematology', 432744.68, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Regrant study', 19, 'Apotex Corp.', 'Rheumatology', 330502.92, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Sonair study', 2, 'AvKARE, Inc.', 'Urology', 163229.24, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Redhold study', 2, 'Aidarex Pharmaceuticals LLC', 'Cardiology', 394155.71, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Aerified study', 1, 'RedPharm Drug Inc.', 'Ophthalmology', 223572.41, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Otcom study', 18, 'NeoStrata Company Inc.', 'Psychiatry', 293830.18, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Home Ing study', 11, 'Aphena Pharma Solutions - Tennessee, LLC', 'Immunology', 489550.38, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Matsoft study', 18, 'Cardinal Health', 'Gastroenterology', 189964.59, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Opela study', 16, 'InfaLab,Inc', 'Orthopedics', 442138.36, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Ventosanzap study', 17, 'NorthStar Rx LLC', 'Immunology', 292802.8, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Zoolab study', 11, 'PD-Rx Pharmaceuticals, Inc.', 'Oncology', 381346.13, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Stim study', 16, 'L Perrigo Company', 'Neurology', 373910.72, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Solarbreeze study', 5, 'Cephalon, Inc.', 'Metabolism and Endocrinology', 58801.15, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Gembucket study', 18, 'Physicians Total Care, Inc.', 'Urology', 303589.18, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Sub-Ex study', 12, 'Target Corporation', 'Gastroenterology', 232410.14, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Matsoft study', 12, 'Guna spa', 'Dermatology', 93611.3, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Solarbreeze study', 14, 'Walgreen Co', 'Hematology', 127642.76, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Zamit study', 9, 'Boy Butter Lubes', 'Infectious Diseases', 120768.84, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Cardguard study', 5, 'Johnson & Johnson Consumer Products Company, Division of Johnson & Johnson Consumer Companies, Inc.', 'Psychiatry', 424480.12, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Rank study', 11, 'Matrixx Initiatives, Inc.', 'Oncology', 173064.63, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Pannier study', 11, 'Mylan Institutional Inc.', 'Hematology', 477703.34, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Overhold study', 10, 'Homeocare Laboratories', 'Neurology', 393496.36, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Fixflex study', 17, 'Supervalu Inc', 'Orthopedics', 125364.28, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Namfix study', 20, 'Dispensing Solutions, Inc.', 'Hematology', 416941.58, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Voltsillam study', 9, 'Seyer Pharmatec, Inc.', 'Psychiatry', 289379.02, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Matsoft study', 13, 'Physicians Total Care, inc.', 'Hematology', 71861.86, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Quo Lux study', 2, 'Aaron Industries Inc.', 'Hematology', 472346.94, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Zamit study', 13, 'REMEDYREPACK INC.', 'Infectious Diseases', 358348.93, 'ongoing');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Span study', 9, 'Physicians Total Care, Inc.', 'Oncology', 272080.43, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Stringtough study', 16, 'HEALTHPOINT, LTD', 'Gastroenterology', 167313.72, 'completed');
insert into surveys (survey_name, wave, client_name, therapy_area, revenue, status) values ('Konklab study', 20, 'Valu Merchandisers Company (Best Choice)', 'Respirology', 311033.27, 'completed');


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO participation
SELECT physicianID, survey_name, wave FROM physicians, surveys ORDER BY RANDOM() LIMIT 1000;



