/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
My example is about Grab/GoJerk Taxi application, which consist of three entity sets
1. customer, has customer_id, first_name, last_name, UNIQUE account_email, contact_number and payment
2. trip, has order_id, customer_id, driver_id
3. driver, has the driver_id, UNIQUE car_vin, car_model, first_name and last_name
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

DROP DATABASE IF EXISTS project_1;
CREATE database project_1;
\c project_1;

DROP TABLE IF EXISTS trip;
DROP TABLE IF EXISTS customer;
DROP TABLE IF EXISTS driver;

CREATE TABLE IF NOT EXISTS customer (
  customer_id INT PRIMARY KEY,
  first_name VARCHAR(32) NOT NULL,
  last_name VARCHAR(32) NOT NULL,
  account_email VARCHAR(256) NOT NULL UNIQUE,
  contact_number VARCHAR(256) NOT NULL UNIQUE,
  payment VARCHAR(32)
);
CREATE TABLE IF NOT EXISTS driver (
  driver_id INT PRIMARY KEY,
  car_vin VARCHAR(256) NOT NULL UNIQUE,
  car_model VARCHAR(32) NOT NULL,
  first_name VARCHAR(32) NOT NULL,
  last_name VARCHAR(32) NOT NULL
);
CREATE TABLE IF NOT EXISTS trip (
  order_id INT,
  driver_id INT,
  customer_id INT,
  PRIMARY KEY (order_id, driver_id, customer_id),
  FOREIGN KEY (driver_id) REFERENCES driver(driver_id)
    ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
  FOREIGN KEY  (customer_id) REFERENCES customer(customer_id)
    ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* CUSTOMER */
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (1, 'Cristie', 'Ferriman', 'cferriman0@ed.gov', '(516) 3791658', 'switch');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (2, 'Ritchie', 'Guiraud', 'rguiraud1@wired.com', '(656) 5044696', 'maestro');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (3, 'Gale', 'Ferrier', 'gferrier2@canalblog.com', '(627) 6836642', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (4, 'Diego', 'Milius', 'dmilius3@bbc.co.uk', '(666) 5523021', 'maestro');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (5, 'Derrek', 'Allibone', 'dallibone4@slate.com', '(725) 6304176', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (6, 'Marvin', 'Gaffey', 'mgaffey5@blogtalkradio.com', '(748) 6213324', 'china-unionpay');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (7, 'Abramo', 'Antusch', 'aantusch6@ycombinator.com', '(311) 5688544', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (8, 'Ruperta', 'Arnauduc', 'rarnauduc7@sitemeter.com', '(837) 9236008', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (9, 'Roxy', 'Massimo', 'rmassimo8@360.cn', '(251) 4165714', 'mastercard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (10, 'Cinnamon', 'Teek', 'cteek9@youtu.be', '(455) 9269419', 'switch');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (11, 'Rafaelita', 'Burleigh', 'rburleigha@furl.net', '(125) 5594988', 'instapayment');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (12, 'Babita', 'Sprowson', 'bsprowsonb@google.cn', '(349) 4100521', 'visa-electron');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (13, 'Brad', 'Tuffey', 'btuffeyc@ibm.com', '(966) 1950762', 'diners-club-enroute');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (14, 'Nev', 'Chinery', 'nchineryd@dyndns.org', '(262) 9008193', 'bankcard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (15, 'Thomasa', 'Janjusevic', 'tjanjusevice@issuu.com', '(472) 3524009', 'maestro');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (16, 'Venita', 'Robertot', 'vrobertotf@liveinternet.ru', '(307) 7262767', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (17, 'Paulette', 'Basketter', 'pbasketterg@theatlantic.com', '(879) 7027131', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (18, 'Lin', 'Bonick', 'lbonickh@ning.com', '(736) 8053648', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (19, 'Rachele', 'Camble', 'rcamblei@reference.com', '(646) 5646059', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (20, 'Salaidh', 'Sackler', 'ssacklerj@nasa.gov', '(411) 6857396', 'americanexpress');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (21, 'Cassi', 'Szubert', 'cszubertk@reference.com', '(773) 3395354', 'diners-club-carte-blanche');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (22, 'Giavani', 'Salan', 'gsalanl@wikipedia.org', '(855) 5867363', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (23, 'Rex', 'Wandrey', 'rwandreym@netscape.com', '(982) 9847097', 'laser');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (24, 'Jard', 'Binnion', 'jbinnionn@columbia.edu', '(327) 4003156', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (25, 'Livy', 'Corkel', 'lcorkelo@eventbrite.com', '(503) 1421968', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (26, 'Laina', 'Glanister', 'lglanisterp@washington.edu', '(113) 1178881', 'diners-club-carte-blanche');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (27, 'Claudia', 'Budd', 'cbuddq@wordpress.com', '(557) 8924989', 'diners-club-enroute');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (28, 'Georgine', 'Kepp', 'gkeppr@constantcontact.com', '(914) 1610605', 'diners-club-us-ca');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (29, 'Garik', 'Tedstone', 'gtedstones@creativecommons.org', '(576) 5734068', 'solo');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (30, 'Saul', 'McMurray', 'smcmurrayt@mediafire.com', '(244) 2116592', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (31, 'Herculie', 'Wasling', 'hwaslingu@baidu.com', '(373) 3237955', 'maestro');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (32, 'Torie', 'Beviss', 'tbevissv@facebook.com', '(801) 3476339', 'laser');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (33, 'Mikaela', 'Mattiessen', 'mmattiessenw@bizjournals.com', '(840) 7246925', 'laser');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (34, 'Domenico', 'Kase', 'dkasex@bloomberg.com', '(204) 8730128', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (35, 'Olivette', 'Bilverstone', 'obilverstoney@boston.com', '(215) 5731258', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (36, 'Marge', 'Parham', 'mparhamz@craigslist.org', '(823) 5549141', 'maestro');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (37, 'Tadd', 'Whistance', 'twhistance10@xinhuanet.com', '(334) 5370920', 'maestro');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (38, 'Amaleta', 'Godsmark', 'agodsmark11@marriott.com', '(595) 6892074', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (39, 'Merilee', 'Jobes', 'mjobes12@clickbank.net', '(233) 6453478', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (40, 'Andres', 'Stickel', 'astickel13@sciencedirect.com', '(185) 8123035', 'mastercard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (41, 'Ingra', 'Babcock', 'ibabcock14@ocn.ne.jp', '(810) 4620970', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (42, 'Blinny', 'Murdy', 'bmurdy15@nydailynews.com', '(414) 1965506', 'visa-electron');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (43, 'Kerk', 'Petracci', 'kpetracci16@yale.edu', '(590) 9781308', 'diners-club-enroute');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (44, 'Parry', 'Humfrey', 'phumfrey17@purevolume.com', '(222) 3604667', 'diners-club-us-ca');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (45, 'Francis', 'Manuaud', 'fmanuaud18@flavors.me', '(634) 4894328', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (46, 'Garrett', 'Bordessa', 'gbordessa19@statcounter.com', '(947) 7608373', 'diners-club-carte-blanche');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (47, 'Barri', 'Rivlin', 'brivlin1a@cargocollective.com', '(777) 9737532', 'solo');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (48, 'Elene', 'Bretland', 'ebretland1b@about.me', '(336) 9309520', 'mastercard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (49, 'Chrotoem', 'Biddy', 'cbiddy1c@simplemachines.org', '(257) 5122400', 'switch');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (50, 'Astrid', 'Borsnall', 'aborsnall1d@bloglines.com', '(576) 8988905', 'mastercard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (51, 'Starla', 'McCloud', 'smccloud1e@go.com', '(921) 2620988', 'maestro');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (52, 'Leland', 'Philipet', 'lphilipet1f@examiner.com', '(728) 8955255', 'bankcard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (53, 'Andrei', 'Siehard', 'asiehard1g@jalbum.net', '(240) 5483519', 'mastercard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (54, 'Korrie', 'Knowlson', 'kknowlson1h@soup.io', '(246) 1179947', 'americanexpress');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (55, 'Benoite', 'Crotty', 'bcrotty1i@hp.com', '(294) 8734226', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (56, 'Hermina', 'Dysart', 'hdysart1j@wordpress.com', '(181) 1838066', 'bankcard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (57, 'Tammie', 'Mangeon', 'tmangeon1k@addthis.com', '(171) 2913838', 'laser');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (58, 'Anastasia', 'Hodges', 'ahodges1l@live.com', '(645) 9346903', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (59, 'Maxwell', 'Selwood', 'mselwood1m@ed.gov', '(439) 1016258', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (60, 'Tamiko', 'Puddefoot', 'tpuddefoot1n@4shared.com', '(715) 5699874', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (61, 'Charmion', 'Lewsley', 'clewsley1o@latimes.com', '(219) 2606701', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (62, 'Brandy', 'Dominy', 'bdominy1p@kickstarter.com', '(516) 2573834', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (63, 'Zachery', 'Attridge', 'zattridge1q@tmall.com', '(601) 2757948', 'visa');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (64, 'Agnola', 'Kubyszek', 'akubyszek1r@yale.edu', '(501) 2275673', 'switch');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (65, 'Heinrik', 'Buret', 'hburet1s@prlog.org', '(741) 2729553', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (66, 'Elisha', 'Walduck', 'ewalduck1t@wiley.com', '(164) 3223458', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (67, 'Eberto', 'Dottrell', 'edottrell1u@webmd.com', '(739) 3704848', 'diners-club-enroute');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (68, 'Tremayne', 'Tynemouth', 'ttynemouth1v@tamu.edu', '(923) 8114775', 'china-unionpay');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (69, 'Aldus', 'Crosher', 'acrosher1w@discovery.com', '(977) 5169510', 'mastercard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (70, 'Loren', 'Craigg', 'lcraigg1x@constantcontact.com', '(232) 2613773', 'instapayment');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (71, 'Jocelin', 'Tant', 'jtant1y@statcounter.com', '(968) 2616723', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (72, 'Neile', 'Cropp', 'ncropp1z@sogou.com', '(299) 3008345', 'bankcard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (73, 'Guillermo', 'Ratter', 'gratter20@tmall.com', '(974) 1550618', 'diners-club-carte-blanche');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (74, 'Brandais', 'Kingswold', 'bkingswold21@zimbio.com', '(567) 6079381', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (75, 'Terrie', 'Rookeby', 'trookeby22@smh.com.au', '(393) 5919180', 'mastercard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (76, 'Philipa', 'Valentelli', 'pvalentelli23@histats.com', '(512) 5975300', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (77, 'Davis', 'Ollcott', 'dollcott24@dyndns.org', '(679) 9712810', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (78, 'Fonz', 'Karpychev', 'fkarpychev25@time.com', '(241) 5465997', 'diners-club-enroute');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (79, 'Teddi', 'McIlhagga', 'tmcilhagga26@shareasale.com', '(854) 6257967', 'visa');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (80, 'Gregorius', 'Dillimore', 'gdillimore27@cbsnews.com', '(527) 1081309', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (81, 'Hobey', 'Ianilli', 'hianilli28@about.com', '(184) 2057091', 'visa-electron');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (82, 'Rheba', 'Entreis', 'rentreis29@businessinsider.com', '(863) 4049650', 'instapayment');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (83, 'Mayor', 'Paulo', 'mpaulo2a@reddit.com', '(195) 1779212', 'bankcard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (84, 'Hew', 'Quillinane', 'hquillinane2b@clickbank.net', '(723) 8802352', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (85, 'Nichole', 'Dwerryhouse', 'ndwerryhouse2c@columbia.edu', '(689) 8955901', 'bankcard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (86, 'Camille', 'Haddow', 'chaddow2d@mayoclinic.com', '(117) 7482809', 'mastercard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (87, 'Kalle', 'Ferrarotti', 'kferrarotti2e@hhs.gov', '(517) 1514298', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (88, 'Cicily', 'Lepard', 'clepard2f@home.pl', '(584) 9652650', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (89, 'Hedy', 'Hek', 'hhek2g@feedburner.com', '(135) 3032827', 'laser');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (90, 'Pammi', 'Sussex', 'psussex2h@diigo.com', '(314) 3916495', 'mastercard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (91, 'Tracie', 'McKerron', 'tmckerron2i@uol.com.br', '(601) 8826311', 'diners-club-enroute');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (92, 'Caty', 'Fuggles', 'cfuggles2j@com.com', '(936) 6461815', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (93, 'Alis', 'Beswetherick', 'abeswetherick2k@ed.gov', '(644) 8709108', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (94, 'Barty', 'Hanhart', 'bhanhart2l@google.ru', '(478) 5901926', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (95, 'Britt', 'Bool', 'bbool2m@stanford.edu', '(317) 2612863', 'mastercard');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (96, 'Rudiger', 'de Tocqueville', 'rdetocqueville2n@jalbum.net', '(100) 1009012', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (97, 'Genevieve', 'McGuiness', 'gmcguiness2o@loc.gov', '(834) 5716582', 'americanexpress');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (98, 'Myrna', 'Volleth', 'mvolleth2p@sciencedirect.com', '(558) 8111541', 'maestro');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (99, 'Giorgio', 'Brackstone', 'gbrackstone2q@forbes.com', '(230) 9395732', 'jcb');
insert into customer (customer_id, first_name, last_name, account_email, contact_number, payment) values (100, 'Harold', 'Hardisty', 'hhardisty2r@scientificamerican.com', '(809) 1134712', 'jcb');

/* DRIVER */
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (1, 'KMHHT6KD5BU900932', 'Mustang', 'Joel', 'Micah');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (2, '1D7RV1GP1BS777740', 'Cherokee', 'Georgeanne', 'Hardaker');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (3, 'KL4CJESB5EB032860', 'Eclipse', 'Samson', 'Haslegrave');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (4, 'JN1AZ4EHXFM206382', 'Avenger', 'Cindelyn', 'Evitt');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (5, '1GYS4SKJ7FR335284', 'Sonata', 'Lita', 'Paddie');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (6, '5UXKR2C52F0673719', 'V8 Vantage', 'Vikki', 'Veracruysse');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (7, '1FMJK1G50AE833350', 'SJ', 'Prissie', 'Djekic');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (8, 'W04GV5EVXB1810082', 'MPV', 'Mirabelle', 'Lattin');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (9, 'JN1CV6EK8EM316048', 'Pilot', 'Lars', 'Sieghard');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (10, '19UUA755X8A031064', 'EV1', 'Saw', 'Jozef');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (11, '3GYFNAEY8BS918634', 'Jetta', 'Frants', 'Philipet');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (12, '3C6TD5KT1CG904663', 'Ram 1500', 'Remington', 'Cullity');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (13, 'JN8AS5MT8DW268611', 'GTI', 'Rutherford', 'Keeble');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (14, '3D7TT2HT7BG336487', 'Expedition', 'Shayla', 'Ashenhurst');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (15, '2C3CDXDT3DH548028', 'Envoy XL', 'Lanette', 'Hambelton');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (16, '2C3CCAST3CH492402', 'Envoy', 'Karl', 'Sammonds');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (17, '2G61V5S83E9245994', 'Terraza', 'Herbert', 'Verey');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (18, 'WAUEH98E78A693994', 'Econoline E250', 'Fayette', 'Ilieve');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (19, '1VWAH7A39EC497681', 'Mazdaspeed 3', 'Filmer', 'Sponder');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (20, 'WAUWGAFB5BN761095', 'Frontier', 'Rosalinda', 'Pinwell');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (21, 'SCBLC47J87C345105', 'Grand Cherokee', 'Grier', 'Ferronier');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (22, 'WAUDFAFL4DA693028', 'Chevette', 'Evanne', 'Bigland');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (23, 'SCFAD22383K139279', 'MPV', 'Ahmad', 'Hacquoil');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (24, '3LNDL2L38CR846967', 'PT Cruiser', 'Coop', 'Brigg');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (25, '1N6AF0KY4EN237281', 'E-Series', 'Natalina', 'Lafee');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (26, 'SCFFDCCD5AG142305', 'Familia', 'Ailbert', 'Pettinger');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (27, '5BZBF0AA6EN700680', 'Relay', 'Farley', 'Brezlaw');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (28, 'WAUEG98E16A085310', 'Catera', 'Vasilis', 'Fideler');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (29, 'KNADH5A36B6503058', 'Swift', 'Karlie', 'Brunn');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (30, 'WAUVFAFR9CA123890', 'Golf', 'Clemmie', 'Dowglass');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (31, 'WBAAN37401N622423', 'XL-7', 'Geoffrey', 'Christian');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (32, 'JH4DC44551S438880', 'Swift', 'Flor', 'Klosges');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (33, '4JGDF2EE7FA480939', 'Millenia', 'Cybil', 'Rasell');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (34, '3N1CE2CP6FL464573', 'Trans Sport', 'Craggie', 'Aven');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (35, '2B3CK5CT6AH022593', 'Dakota Club', 'Vanna', 'Arnao');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (36, 'SCFFDCBD6AG632110', 'Classic', 'Ricca', 'Malec');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (37, '1C4RJEAG0FC441180', 'Neon', 'Mireille', 'Hyndley');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (38, '1FTMF1CW4AK312024', 'Avalanche', 'Moises', 'Sivier');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (39, '4T1BF1FK1CU451887', 'Cutlass', 'Yale', 'Childerhouse');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (40, '1N6AA0CC4AN318342', 'Accent', 'Jareb', 'Heikkinen');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (41, '3VWML7AJ6DM726549', 'TL', 'Sydney', 'Richmont');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (42, 'WBA3K5C51FK065493', 'Colorado', 'Herold', 'Heaker');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (43, 'JN1BY1AP1DM708634', 'Quest', 'Sheena', 'Daniely');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (44, 'WBAWB3C5XAP378507', 'Navajo', 'Edgar', 'Ivanichev');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (45, 'WDDHF0EB1FB707896', 'Villager', 'Konstance', 'Cassey');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (46, 'WBA3B3C59FF176550', 'R-Class', 'Marillin', 'Dybald');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (47, 'WAULD54B84N433307', '1500', 'Judie', 'Frisdick');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (48, 'WAULC58E65A771854', 'Accord', 'Merissa', 'Graddell');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (49, '1HGCP2F30BA677151', 'Insight', 'Kalila', 'Fierro');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (50, 'WAUAFAFH6EN755313', 'ES', 'Kimberley', 'Guite');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (51, '1N6BF0KM3FN101176', 'Electra', 'Elfie', 'Goodlett');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (52, 'WDBSK7AA0CF385014', 'Grand Prix', 'Steffane', 'Eads');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (53, '5TFAW5F18EX069520', 'Tacoma Xtra', 'Shela', 'Rowcliffe');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (54, '1N4AL3AP6EC412802', 'Park Avenue', 'Meryl', 'Bourton');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (55, '2T1BPRHE9FC313040', 'Optima', 'Izak', 'MacGeaney');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (56, '3VW4A7AT0DM004906', '928', 'Guthrey', 'Mailey');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (57, '5GAKVCKD8DJ000034', 'Raider', 'Ferd', 'Kynnd');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (58, '1G4GC5EC3BF477863', 'SC', 'Marina', 'Buckenham');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (59, 'WA1VFBFL5DA000202', 'H1', 'Nancie', 'Pietersen');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (60, '1G6DZ67A380955981', 'Sonata', 'Colette', 'Kernan');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (61, 'JTEBU5JR2D5810273', 'Crown Victoria', 'Cass', 'Wilkerson');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (62, '5N1AN0NU7EN053270', 'S5', 'Ferdie', 'Meriton');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (63, 'WAUSH78E28A455350', '7 Series', 'Holmes', 'Romayne');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (64, '2GKALMEK0E6376438', 'Yukon', 'Violet', 'Di Matteo');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (65, 'WAUAFAFL5DA715198', 'Silhouette', 'Erena', 'Cleve');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (66, '1FTEW1CM1BK462340', 'SX4', 'Paulina', 'Bentinck');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (67, 'JN8AZ2KR6DT719604', 'Impreza', 'Abby', 'Armitt');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (68, 'WBALW7C54CD225656', 'Passat', 'Damaris', 'Rhubottom');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (69, 'WAUWFAFH3DN100238', 'E-Class', 'Maryellen', 'Bleesing');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (70, '1FTEW1CMXDF643349', 'Catera', 'Gertruda', 'Wickersham');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (71, 'WBALZ5C51CD996409', 'Durango', 'Hewet', 'Cremin');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (72, '1D7RV1GP8BS745237', 'Taurus', 'Augy', 'Smorthit');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (73, '5FRYD3H85FB662006', 'Esprit', 'Kaia', 'Foch');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (74, 'JN8AZ2KRXAT304054', 'Mulsanne', 'Knox', 'Bebbell');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (75, 'SAJWA6AT0F8696616', 'M5', 'Demetri', 'Wimbush');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (76, '5FRYD4H98GB111830', 'Camry', 'Tybalt', 'Gowman');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (77, '3N1CN7AP0EL121739', 'V8 Vantage', 'Audrey', 'Robuchon');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (78, 'WBAKF9C59CE107359', 'Viper', 'Martin', 'Morley');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (79, '1FTMF1CW2AF935327', 'Endeavor', 'Colver', 'Mouget');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (80, 'WA1EY74L78D229429', 'Sierra 3500', 'Duane', 'Kemm');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (81, '3C63DPML2CG452022', 'Yukon XL 1500', 'Dominic', 'Garfath');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (82, 'WAUDF78E16A389952', 'Elantra', 'Sadye', 'Francomb');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (83, 'WAUDT48H24K480818', 'Cooper', 'Zachery', 'Garret');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (84, '3VW517AT4FM424515', 'XK Series', 'Billy', 'Perrins');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (85, '1G6KS54Y22U301755', 'Park Avenue', 'Melly', 'Harroway');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (86, '3C63DRKL7CG541258', '4Runner', 'Clyde', 'Lared');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (87, 'WA1CGCFE3BD964014', 'Mustang', 'Ynes', 'Meany');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (88, 'WBA6B4C55DD643412', 'Carens', 'Jarrod', 'Titmarsh');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (89, '1FTWW3A50AE142547', 'GX', 'Cassie', 'McCromley');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (90, '5GADX33L15D496819', 'Continental', 'Tracie', 'Caulwell');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (91, '1G6KD57Y32U467983', 'Fox', 'Johnny', 'Loney');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (92, 'WBA3C3C58FK567239', 'Express 2500', 'Deloria', 'Whipp');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (93, 'TRUTX28N521330255', '98', 'Halsey', 'Duell');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (94, 'WBA4A7C59FG784576', 'Envoy', 'Paton', 'Habbes');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (95, 'WBA3N9C55EF262902', 'RX-7', 'Krystyna', 'Branch');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (96, 'WAUVVAFR7AA505142', 'Sunbird', 'Jasun', 'Lambrick');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (97, '1LNHL9DR4BG434645', 'Caravan', 'Ingemar', 'Widocks');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (98, '1G6DJ577080689616', 'TT', 'Myrtle', 'Bedinham');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (99, '1FMEU6FE4AU552426', 'Aura', 'Kerstin', 'Peddar');
insert into driver (driver_id, car_vin, car_model, first_name, last_name) values (100, '1D4PU6GX5BW759125', 'CX-7', 'Nessa', 'Keble');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* I used the row_number to generate the distinct value of order_id since the combination of customer_id and driver_id
may have duplicate. */

INSERT INTO trip
SELECT  ROW_NUMBER() OVER (ORDER BY c.customer_id) AS order_id, c.customer_id, d.driver_id
FROM customer c
CROSS JOIN driver d
WHERE random() <= 0.1 LIMIT 1000;
