/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */
/

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
Introduction: these three tables are an example in Postgresql of how a database could be structured, containing the personal medical information of the patients and the drugs available in the market as a treatment.

Table 1 (med_report): is a table that contains the medical reports issued in a given red of hospitals.
Attribute 1 (e_med_report): The primary key is an encrypted identification number that allows for tracking the different reports associated with a given patient
Attribute 2 (code_illness): Diagnosed illness code. This column allows us to identify the illness every patient was diagnosed with.
Attribute 3: (death_risk (Boolean)): this attribute reports if a given illness may have a death risk.
Attribute 4: City of diagnosis (city): reports the town where a given patient was diagnosed
Attribute 5: Address of the hospital (hosp_address): provides the address of the hospital that issued the report
Primary key (e_med_report, code_illness): Given that any patient could have many diagnoses, this primary key combine the illness code and the encrypted identification number of the patient

Table 2: (drug_diagnosed): contains the description of the drug diagnosed in a red of hospitals.
Attribute 1: (drug_name): This column contains the name of the drug diagnosed
Attribute 2: (cost_drug_USD):  Reports the cost for each drug in USD
Attribute 3: (freq): this attribute details the frequency for each treatment.
Attribute 4: (drug_comp): this attribute reports the company that produced the drug      
Attribute 5: (stock_symbol): this attribute shows the stock symbol of each company that makes a given drug
Attribute 6: (plant_used): this column identifies the plant used as a central component for the medicine
Primary key (drug_name, plant_used):  Since a plant could produce many drugs, the primary key specifies the drug name and the plant.

Table 3: drug_diagnosed: contains 10% of the possible combinations of illness diagnosed for a specific patient and drugs made of a given plant.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE med_report(
  e_med_report VARCHAR(64), 
  code_illness VARCHAR(64) NOT NULL, 
  death_risk BOOL NOT NULL, 
  city VARCHAR(64) NOT NULL, 
  hosp_address VARCHAR(64) NOT NULL, 
  PRIMARY KEY (e_med_report, code_illness)
);
CREATE TABLE drug_diagnosed(
  drug_name VARCHAR(300), 
  cost_drug_USD INT NOT NULL CHECK(cost_drug_USD > 0), 
  freq VARCHAR(300) NOT NULL, 
  drug_comp VARCHAR(200) NOT NULL, 
  stock_symbol VARCHAR(200) NOT NULL, 
  plant_used VARCHAR(200) NOT NULL, 
  PRIMARY KEY(drug_name, plant_used)
);
CREATE TABLE diagnosis_treatment(
  drug_name VARCHAR(300), 
  plant_used VARCHAR(100), 
  FOREIGN KEY (drug_name, plant_used) REFERENCES drug_diagnosed(drug_name, plant_used) ON UPDATE CASCADE ON DELETE CASCADE, 
  e_med_report VARCHAR(64), 
  code_illness VARCHAR(64), 
  FOREIGN KEY (e_med_report, code_illness) REFERENCES med_report(e_med_report, code_illness) ON UPDATE CASCADE ON DELETE CASCADE
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Benzocaine', 895, 'Yearly', 'Bauch, Hagenes and Armstrong', 
    'SAIC', 'Schistostega pennata (Hedw.) F. Weber & D. Mohr.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'fluocinonide', 143, 'Often', 'McGlynn-Shanahan', 
    'LTXB', 'Verbesina alternifolia (L.) Britton ex Kearney'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Magnesium Oxide', 711, 'Seldom', 
    'Dooley, Hirthe and Johns', 'JSYNR', 
    'Helianthus praetermissus E.E. Watson'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Aluminum Zirconium Tetrachlorhydrex GLY', 
    752, 'Never', 'Hayes and Sons', 'BHK', 
    'Allium shevockii McNeal'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'fluocinonide', 758, 'Yearly', 'Ratke Inc', 
    'DSKEW', 'Physcia crispa Nyl.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Acetaminophen, Dextromethorphan HBr, Guaifenesin, Phenylephrine HCl', 
    515, 'Yearly', 'Stracke, Wisozk and Bauch', 
    'FMBH', 'Carex glaucescens Elliott'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'ACETAMINOPHEN, DIPHENHYDRAMINE HYDROCHLORIDE', 
    709, 'Daily', 'Kunde, Reynolds and Altenwerth', 
    'ESG', 'Calochortus tolmiei Hook. & Arn.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Octinoxate, Avobenzone, Oxybenzone, Titanium Dioxide', 
    933, 'Often', 'Huel-Murphy', 'DECK', 
    'Sphaeralcea ambigua A. Gray ssp. ambigua'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'fexofenadine hydrochloride', 800, 
    'Seldom', 'Rau Inc', 'FTEO', 'Chiodecton Ach.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Escitalopram Oxalate', 429, 'Daily', 
    'Rath, Waters and Corkery', 'OSB', 
    'Ceanothus palmeri Trel.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Alcohol', 552, 'Yearly', 'Cassin, Kulas and Hickle', 
    'LPL', 'Pseudostellaria jamesiana (Torr.) W.A. Weber & R.L. Hartm.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'risedronate sodium', 825, 'Seldom', 
    'Bayer and Sons', 'TUTT', 'Psychotria garberiana Christoph.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Menthol', 263, 'Seldom', 'Murazik LLC', 
    'EZT', 'Melicope ovata (H. St. John & Hume) T.G. Hartley & B.C. Stone'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Camphor, Menthol, Methyl Salicylate', 
    678, 'Often', 'Sporer-Hirthe', 'NEE^G', 
    'Inga nobilis Willd.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Methadone Hydrochloride', 435, 'Daily', 
    'Wyman Inc', 'LTRX', 'Symphyotrichum tenuifolium (L.) G.L. Nesom'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Glimepiride', 226, 'Often', 'Flatley, Lynch and Green', 
    'MDWD', 'Lastarriaea coriacea (Goodman) Hoover'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Amlodipine besylate and Atorvastatin calcium', 
    770, 'Monthly', 'Koelpin Inc', 'CFBK', 
    'Corydalis incisa (Thunb.) Pers.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Dextromethorphan Hydrobromide, GUAIFENESIN', 
    540, 'Monthly', 'Monahan-Dickens', 
    'PML', 'Phylliscum Nyl.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'OCTINOXATE, OCTISALATE, TITANIUM DIOXIDE', 
    792, 'Never', 'Braun LLC', 'OFLX', 
    'Dactylina Nyl.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Omeprazole', 965, 'Never', 'Bergnaum, Ernser and Zemlak', 
    'WAYN', 'Horkelia fusca Lindl. ssp. parviflora (Nutt. ex Torr. & A. Gray) D.D. Keck'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'ISOPROPYL ALCOHOL', 432, 'Never', 
    'Schmeler LLC', 'ETX           ', 
    'Chenopodium album L. var. album'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Bupropion Hydrochloride', 617, 'Seldom', 
    'Okuneva Inc', 'MT', 'Triteleia hendersonii Greene'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'POLYQUATERNIUM-10 (400 CPS AT 2%)', 
    686, 'Once', 'Rau, Jacobs and Dare', 
    'BKS', 'Erigeron pulchellus Michx. var. brauniae Fernald'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'PRUNUS SPINOSA FLOWER BUD and NITROGLYCERIN and SELENICEREUS GRANDIFLORUS STEM and POTASSIUM CARBONATE and SPIGELIA ANTHELMIA', 
    940, 'Often', 'Aufderhar-Tillman', 
    'RADA', 'Rhizocarpon saanaense Rasanen'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Baclofen', 566, 'Never', 'Kessler LLC', 
    'EV', 'Spermacoce sintenisii (Urb.) Alain'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Post Oak', 720, 'Seldom', 'Wilderman-Balistreri', 
    'GNCMA', 'Selaginella mutica D.C. Eaton ex Underw.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Loratadine and Pseudoephedrine Sulfate', 
    158, 'Daily', 'Schuppe, Gusikowski and Renner', 
    'AMED', 'Gaylussacia brachycera (Michx.) A. Gray'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Ifosfamide', 447, 'Daily', 'Ledner-Nicolas', 
    'REX', 'Rudbeckia fulgida Aiton var. fulgida'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Penicillin V Potassium', 942, 'Monthly', 
    'Cronin, Hintz and Morar', 'SSNI', 
    'Oenothera rhombipetala Nutt. ex Torr. & A. Gray'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'BENZALKONIUM CHLORIDE, BENZOCAINE, SD ALCOHOL, BACITRACIN ZINC, NEOMYCIN SULFATE, POLYMYXIN B', 
    487, 'Seldom', 'Witting-Kilback', 
    'PEGI', 'Eriocaulon lineare Small'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Aspirin', 822, 'Yearly', 'Murray Inc', 
    'XBKS', 'Potentilla atrosanguinea Lodd. ex D. Don'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Alcohol', 241, 'Daily', 'Murphy LLC', 
    'NCLH', 'Elaphoglossum erinaceum (Fée) T. Moore'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'MINERAL OIL,PETROLATUM,PHENYLEPHRINE,SHARK LIVER OIL', 
    314, 'Never', 'Morar, Sanford and Pollich', 
    'FOXF', 'Pappophorum pappiferum (Lam.) Kuntze'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Granisetron Hydrochloride', 621, 
    'Monthly', 'Bernhard Group', 'QUAD', 
    'Horkelia californica Cham. & Schltdl. ssp. dissita (Crum) Ertter'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'AVOBENZONE, HOMOSALATE, OCTISALATE, OCTOCRYLENE', 
    713, 'Never', 'Wuckert, Haley and Koss', 
    'NTC', 'Trembleya phlogiformis DC.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'ALLANTOIN, COLLOIDAL OATMEAL', 
    260, 'Monthly', 'Rutherford, Johns and Marks', 
    'HBK', 'Lomatium howellii (S. Watson) Jeps.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Diphenhydramine Hydrochloride', 
    192, 'Seldom', 'Pollich-Abernathy', 
    'KTWO', 'Allium abramsii (Ownbey & Aase) McNeal'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'SELENIUM SULFIDE', 718, 'Once', 'Feest-Davis', 
    'GIM', 'Chamaesyce parishii (Greene) Millsp. ex Parish'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Caffeine', 858, 'Never', 'Padberg, Heaney and Hirthe', 
    'DS', 'Euonymus fortunei (Turcz.) Hand.-Maz.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'ENALAPRIL MALEATE', 235, 'Once', 
    'Langworth and Sons', 'BLPH', 'Grimmia torngakiana Brass. & Hedderson'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Miconazole nitrate', 259, 'Monthly', 
    'Runolfsdottir, Breitenberg and Keeling', 
    'RBC', 'Drymaria molluginea (Lag.) Didr.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'sertraline hydrochloride', 365, 
    'Daily', 'Hermiston-Homenick', 'CSCO', 
    'Cyrtandra ×malacophylla C.B. Clarke (pro sp.)'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'TITANIUM DIOXIDE', 457, 'Never', 
    'Hessel and Sons', 'EFR', 'Dyschoriste crenulata Kobuski'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'SPONGIA TOSTA', 468, 'Weekly', 'Smitham Group', 
    'GSOL', 'Russelia equisetiformis Schltdl. & Cham.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Octinoxate, Octisalate, Avobenzone', 
    818, 'Yearly', 'McKenzie LLC', 'MTP', 
    'Bouteloua radicosa (Fourn.) Griffiths'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Avobenzone, Octisalate, Octocrylene', 
    882, 'Yearly', 'Johns Group', 'EOG', 
    'Chloris truncata R. Br.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'MAGNESIUM SULFATE HEPTAHYDRATE', 
    893, 'Never', 'Durgan, Labadie and Mraz', 
    'SOL', 'Delphinium scopulorum A. Gray'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Alprazolam', 294, 'Monthly', 'Grady, Balistreri and Schowalter', 
    'GAIA', 'Simarouba Aubl.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Titanium Dioxide, Zinc Oxide', 
    483, 'Yearly', 'Lesch, Koepp and Mraz', 
    'FBK', 'Ranunculus marginatus d''Urv. var. trachycarpus (Fisch. & C.A. Mey.) Arn.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'prednicarbate', 215, 'Monthly', 'Schultz-Volkman', 
    'CSPI', 'Mimulus breweri (Greene) Coville'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Bayberry', 378, 'Seldom', 'Rice, Bruen and Klein', 
    'CLF', 'Sedum stoloniferum S.G. Gmel.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Triclosan', 881, 'Never', 'Lindgren Group', 
    'FRED', 'Lysimachia kalalauensis Skottsb.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Sertraline Hydrochloride', 712, 
    'Yearly', 'Lemke-Schowalter', 'GRPN', 
    'Pilosocereus polygonus (Lam.) Byles & Rowley'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Bupropion Hydrochloride', 965, 'Yearly', 
    'Okuneva-Kovacek', 'DCOM', 'Correa Andrews, nom. cons.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'MENTHOL', 526, 'Often', 'Bins, Carter and Rowe', 
    'SYK', 'Corydalis curvisiliqua Engelm. ssp. curvisiliqua'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Doxycycline Hyclate', 283, 'Monthly', 
    'Strosin and Sons', 'SOFO', 'Lecanora caesiorubella Ach. ssp. prolifera (Fink) R.C. Harris'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Nadolol', 155, 'Seldom', 'Kihn, Emmerich and McGlynn', 
    'MTCH', 'Crataegus ×websteri Sarg.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Levothyroxine Sodium', 591, 'Monthly', 
    'Hackett and Sons', 'IRET^B', 'Synthyris reniformis (Douglas ex Benth.) Benth. var. reniformis'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Avobenzone, Octinoxate, Octisalate, Oxybenzone', 
    533, 'Often', 'Blick, Bahringer and Ward', 
    'NVS', 'Symphoricarpos albus (L.) S.F. Blake var. albus'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Buspirone hydrochloride', 111, 'Weekly', 
    'Farrell-Gulgowski', 'LPNT', 'Dichanthelium acuminatum (Sw.) Gould & C.A. Clark var. fasciculatum (Torr.) Freckmann'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Nicotine Polacrilex', 536, 'Often', 
    'Raynor LLC', 'ABB', 'Lobelia appendiculata A. DC. var. gattingeri (A. Gray) McVaugh'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'AMIODARONE HYDROCHLORIDE', 610, 
    'Seldom', 'Stoltenberg, O''Reilly and Lockman', 
    'EXFO', 'Chamaesyce fendleri (Torr. & A. Gray) Small'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'HYDROCHLOROTHIAZIDE', 792, 'Yearly', 
    'Crona-Konopelski', 'VLRX', 'Cirsium fontinale (Greene) Jeps. var. fontinale'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Alcohol', 731, 'Weekly', 'Bayer, Oberbrunner and Kris', 
    'PKY', 'Acacia rigidula Benth.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'ATORVASTATIN CALCIUM', 730, 'Seldom', 
    'Gleichner, Kirlin and Hahn', 'SHIP', 
    'Usnea strigosa (Ach.) Eaton ssp. major (Michx.) I. Tav.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'trihexyphenidyl hydrochloride', 
    454, 'Never', 'Runolfsson Group', 
    'FFKT', 'Epilobium mirabile Trel. ex Piper'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Adrenocorticotrophin, Agnus Castus, Baryta Castus, Baryta Carbonica, Calcarea Carbonica, Iodium, Lac Caninum,', 
    538, 'Seldom', 'Nolan and Sons', 
    'MSLI', 'Commelina rufipes Seubert'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Anacardium orientale 6X, Argentum nitricum 6X, Arsenicum album 6X, Belladonna 4X, Carbo vegetabilis 8X, Chamomilla 2X, Chelidonium majus, radix 3X, Lycopodium clavatum 5X, Nux vomica 4X, Scrophularia nodosa 1X', 
    279, 'Often', 'Mertz Inc', 'GTIM', 
    'Lonicera albiflora Torr. & A. Gray'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'warfarin sodium', 342, 'Weekly', 
    'Heller-Schimmel', 'TAX', 'Penstemon moffatii Eastw. ssp. moffatii'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'diphenhydramine hydrochloride', 
    819, 'Once', 'Spinka-Mitchell', 'FMNB', 
    'Dalbergia latifolia Roxb.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Lidocaine Hydrochloride', 850, 'Monthly', 
    'Kutch-Herman', 'CYTX', 'Linaria bipartita (Vent.) Willd.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Acetazolamide', 435, 'Yearly', 'White, Runolfsdottir and Maggio', 
    'MTCH', 'Salvia greggii A. Gray'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Prednisolone Sodium Phosphate', 
    828, 'Daily', 'Hessel-Friesen', 'SLG', 
    'Amblystegium varium (Hedw.) Lindb.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'BENZALKONIUM CHLORIDE', 825, 'Never', 
    'Jaskolski-Dickinson', 'SPLK', 'Elymus L.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Ibuprofen', 152, 'Daily', 'O''Connell, Stroman and Hammes', 
    'CMRE^B', 'Dioscoreophyllum cumminsii (Stapf) Diels'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Salicylic Acid', 685, 'Weekly', 'Barrows-Dibbert', 
    'UL', 'Perityle bisetosa (Torr. ex A. Gray) Shinners'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Methocarbamol', 630, 'Weekly', 'Runte, Lubowitz and Fadel', 
    'ENOC', 'Ranunculus pygmaeus Wahlenb.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Guaifenesin', 671, 'Often', 'Gleason and Sons', 
    'FMNB', 'Erigeron elatior (A. Gray) Greene'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Antiperspirant and Deodorant', 
    692, 'Never', 'D''Amore, Glover and Heaney', 
    'ENS', 'Paspalum pleostachyum Döll'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Sennosides', 797, 'Once', 'Grady LLC', 
    'CRTO', 'Graphis Adans.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Pyrithione Zinc', 977, 'Daily', 'Padberg Group', 
    'TKC', 'Ceanothus jepsonii Greene var. albiflorus J.T. Howell'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'TITANIUM DIOXIDE', 715, 'Monthly', 
    'Konopelski, Jakubowski and Yundt', 
    'AIC', 'Flourensia pringlei (A. Gray) S.F. Blake'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'clonazepam', 629, 'Often', 'O''Kon Inc', 
    'UONE', 'Theobroma bicolor Humb. & Bonpl.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Miconazole nitrate', 820, 'Never', 
    'McGlynn, Brakus and Balistreri', 
    'TSM', 'Allium vineale L. ssp. compactum (Thuill.) Coss. & Germ.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Calendula officinalis and natrum muriaticum', 
    969, 'Monthly', 'Stark, Jones and Fadel', 
    'LINC', 'Melica aristata Thurb. ex Bol.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Sulfur', 265, 'Monthly', 'Predovic-Boyer', 
    'GM', 'Calopogon tuberosus (L.) Britton, Sterns & Poggenb. var. tuberosus'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Cimicifuga Racemosa Root, Bryonia Alba Root', 
    153, 'Daily', 'Quitzon and Sons', 
    'WBMD', 'Calamagrostis hillebrandii (Munro ex Hillebr.) Hitchc.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Candida albicans, Pulsatilla, Sepia, Thuja occidentalis', 
    557, 'Once', 'Casper, Kemmer and Goyette', 
    'TCBK', 'Aeginetia indica L.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Plantain English', 752, 'Seldom', 
    'Frami LLC', 'BMO', 'Paspalum pubiflorum Rupr. ex Fourn.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'silver sulfadiazine', 362, 'Often', 
    'Tillman-Frami', 'WWW', 'Pseudoroegneria (Nevski) Á. Löve'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'acetaminophen', 790, 'Weekly', 'Frami, Senger and Muller', 
    'VPV', 'Apium graveolens L.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Acetaminophen, Dextromethorphan HBr, Phenylephrine HCI', 
    305, 'Often', 'O''Connell LLC', 'LIND', 
    'Festuca washingtonica Alexeev'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'sulfamethoxazole and Trimethoprim', 
    188, 'Often', 'Wuckert, Mills and Lang', 
    'RNG', 'Plateilema (A. Gray) Cockerell'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Etodolac', 899, 'Seldom', 'Bashirian-Prosacco', 
    'NEE^G', 'Physalis arenicola Kearney'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Acetaminophen, Doxylamine succinate, Phenylephrine HCl', 
    813, 'Weekly', 'Murphy, Bashirian and Wuckert', 
    'AGN', 'Gossypium hirsutum L. var. marie-galante (Watt) Hutch.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Lactulose', 138, 'Yearly', 'Lueilwitz-Bartell', 
    'LPX', 'Eryngium heterophyllum Engelm.'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'OCTINOXATE', 724, 'Yearly', 'Greenfelder-Herzog', 
    'UAA', 'Hecastocleis shockleyi A. Gray'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Ceftriaxone', 470, 'Yearly', 'Borer Inc', 
    'AVXS', 'Eurhynchium pulchellum (Hedw.) Jenn. var. pulchellum'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Alcohol', 441, 'Daily', 'Hirthe, Torphy and Kirlin', 
    'MMP', 'Picris hieracioides L. ssp. hieracioides'
  );
insert into drug_diagnosed (
  drug_name, cost_drug_USD, freq, drug_comp, 
  stock_symbol, plant_used
) 
values 
  (
    'Octinoxate', 203, 'Weekly', 'Kuphal Inc', 
    'RBS^F', 'Rubus missouricus L.H. Bailey'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S72345J', true, 'Bromma', '472 Graedel Center'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'C8474', true, 'Blatnica', '49429 Sunfield Street'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'M89229', true, 'Hamburg', '69226 6th Pass'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'R87811', false, 'Kranggan', '75 Stone Corner Hill'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'Y36820A', true, 'Wuppertal', '3435 Mcguire Way'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'E069', true, 'Sumberkrajan', '73 Oak Valley Terrace'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'M50821', false, 'Miguel Pereira', 
    '4 Birchwood Parkway'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'Y36121A', false, 'Jamundí', '0 Rigney Drive'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'Y93D', true, 'San Rafael Arriba', 
    '76 Muir Point'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'H73893', false, 'Ponta do Sol', 
    '492 Center Place'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'T22249S', false, 'Manolo Fortich', 
    '4694 Michigan Crossing'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'R489', true, 'Zala', '5 Sunnyside Center'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S82454F', true, 'Yelets', '284 Debra Place'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S11032D', false, 'Zliten', '240 Rieder Crossing'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S00459D', true, 'Tulle', '7780 Portage Park'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'V0600XA', true, 'Szeged', '1437 High Crossing Street'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'J129', false, 'Sŭedinenie', '11 Glendale Park'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'V80929A', true, 'Tierimu', '764 Everett Junction'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'T22799S', false, 'Warungawi', '8 Macpherson Crossing'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'Z316', true, 'Abade de Neiva', '36549 Bluestem Park'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S82453C', false, 'Osias', '9 Bellgrove Trail'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S72421J', false, 'Jasugih Selatan', 
    '34 Mesta Crossing'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'Y37441D', true, 'Sim', '02 Red Cloud Junction'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S00401', true, 'Palagao Norte', 
    '8969 Helena Road'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S43203', true, 'Itapevi', '069 Melrose Road'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S90521D', false, 'Talacogon', '6588 Spenser Center'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'H47631', true, 'Wajir', '90 Stoughton Center'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S72445N', true, 'Tayasan', '754 Brown Alley'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'H7580', false, 'El Dividive', '1699 Hollow Ridge Road'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'T2101XA', false, 'Volgo-Kaspiyskiy', 
    '13 Holmberg Road'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S68613', false, 'Sritanjung', '9546 Hallows Center'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S79129A', false, 'Santa Cruz Muluá', 
    '07295 Marquette Junction'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S82865F', false, 'Ya’ngan', '5936 Clarendon Place'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'T84619', false, 'Onguday', '26 Morrow Terrace'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'C113', false, 'Santo Domingo', '726 Service Street'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'T84498D', true, '‘Ūrīf', '402 Fuller Terrace'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'M0765', false, 'Strunino', '38 Blaine Terrace'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'I676', true, 'Lumbatan', '6 Rieder Lane'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S86819D', true, 'Āshtīān', '7 Prairieview Court'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'T82529D', false, 'Shahre Jadide Andisheh', 
    '8348 Melvin Place'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S060X0S', true, 'Nancy', '272 Morning Park'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S43101', false, 'Duifang', '679 Bartillon Alley'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'V452XXS', true, 'Sandia', '13 Grim Center'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S56407', false, 'Cikabuyutan Barat', 
    '78674 Heath Circle'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'M21339', true, 'Матејче', 
    '04413 Cardinal Circle'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'T369', false, 'Chitose', '60357 Trailsway Court'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'T23779', true, 'Donnycarney', '83772 Jana Way'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'J430', false, 'Acacías', '61 Bunker Hill Alley'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S83229A', false, 'Villasis', '5620 Mcbride Lane'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'T82599', true, 'Ryki', '4161 Arkansas Terrace'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S43083D', false, 'Lyalichi', '14783 Erie Center'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'Q972', false, 'Huadian', '365 Raven Lane'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S42434A', false, 'Bandar Pusat Jengka', 
    '80619 Glendale Drive'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S62606K', true, 'Rio Covo', '4 Butterfield Center'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'V787XXD', false, 'Linggou', '976 Forest Dale Court'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S90812A', true, 'Bridgetown', '13 Blue Bill Park Road'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'F908', false, 'Santo Domingo', '04 Mandrake Point'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S6331', true, 'Banī Khallād', 
    '79758 Northwestern Court'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'T2079XD', true, 'Pensacola', '566 Columbus Pass'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'F16950', true, 'Dijon', '05617 Graceland Pass'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'T8859', false, 'Nanterre', '537 Del Mar Lane'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S61121S', false, 'Tehrān', '05 Emmet Parkway'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'H0451', false, 'Nabari', '91362 Talmadge Pass'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'Y92020', false, 'Vol’no-Nadezhdinskoye', 
    '33352 Surrey Lane'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'H1822', true, 'Siao', '646 Delladonna Crossing'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'O99335', false, 'Corbeil-Essonnes', 
    '10950 Clyde Gallagher Trail'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'V586', true, 'Wilkes Barre', '57 Oakridge Hill'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'V80918D', true, 'Milove', '1472 Manley Hill'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S92332K', true, 'Irecê', '0 Stoughton Circle'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S52569K', true, 'Nizhnekamsk', '539 Forest Run Way'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S36509A', false, 'Campo Maior', 
    '835 Macpherson Circle'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'M23259', true, 'Belogorskīy', '95231 Sunbrook Park'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'D141', true, 'Rutul', '872 Veith Court'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'H8103', false, 'Phu Luang', '392 Brickson Park Lane'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'V0190XA', false, 'Stockholm', '266 Autumn Leaf Street'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'Y383X2D', true, 'Veldhoven', '096 Sauthoff Trail'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'M02359', false, 'Tobilolong', '90 Fremont Place'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'G312', true, 'Minami-rinkan', '2123 Bluejay Lane'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S20141', false, 'Dongji', '9630 Heffernan Avenue'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'H59331', true, 'Hisya', '87680 Dunning Road'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S8781XS', true, 'Pucara', '3 Havey Crossing'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S50369D', false, 'Kabala', '4 Redwing Road'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'R402333', true, 'Fengzhou', '44 Milwaukee Park'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'M80842', false, 'Vinica', '7032 Colorado Pass'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S82431M', true, 'Sanjiang', '8 Schmedeman Point'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'W558', true, 'Pira', '6 Menomonie Alley'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'O328XX1', false, 'Karlshamn', '3165 Miller Trail'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S51801D', false, 'Chenfang', '6 Eagle Crest Lane'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S82433N', true, 'Ra’s Bayrūt', 
    '2 Jackson Alley'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'R108', false, 'Monterrey', '0155 Burrows Lane'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S1125XD', true, 'Vitebsk', '35552 Hanson Road'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S8002XD', false, 'Nevyts’ke', 
    '6314 Schlimgen Point'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S72334K', true, 'Paradyż', '35 Old Shore Point'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'V9200', true, 'Luoping', '6 Dapin Court'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S53195S', true, 'Kendalngupuk', 
    '69013 Dixon Circle'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S72022K', false, 'Cempaka', '3584 Hermina Crossing'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S49141A', false, 'Québec', '2670 Kinsman Alley'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'S14114A', false, 'Strömsnäsbruk', 
    '4104 Morrow Street'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'M0526', false, 'Aqsū', '54133 Magdeline Road'
  );
insert into med_report (
  e_med_report, code_illness, death_risk, 
  city, hosp_address
) 
values 
  (
    '9a50e4b182ac0ed27955b9643e27a4216e7bbed5', 
    'Y783', false, 'Lanta Timur', '5067 Laurel Park'
  );
insert into diagnosis_treatment (
  drug_name, plant_used, e_med_report, 
  code_illness
) 
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SELECT 
  drug_diagnosed.drug_name, 
  drug_diagnosed.plant_used, 
  med_report.e_med_report, 
  med_report.code_illness 
FROM 
  drug_diagnosed, 
  med_report 
ORDER BY 
  random() 
LIMIT 
  1000;
