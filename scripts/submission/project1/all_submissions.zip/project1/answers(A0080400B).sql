/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/* Student No: A0080400B                                                */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* 
Setting: hospital outpatient
Table 1 (patients): 
Patients' data consisting of NRIC, first & last name,gender, birthdate, 
phone number, email and address.

Table 2 (doctors) : 
A list of doctors working in the hospital detailing MCR (doctor's registration number), 
first and last name, department, gender, email and phone number.

Table 3 follow_up: 
Listed patients who need to follow up on their conditions with their corresponding doctors.
A patient may have several medical conditions and need to follow up with several doctors.
A doctor may have many patients under his/her care.
The table helps doctors to keep track of their patients and the department will also be able
to easily keep track of their doctors' outpatient load.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS patients (
  NRIC CHAR(9) PRIMARY KEY, 
  first_name VARCHAR(64) NOT NULL, 
  last_name VARCHAR(64), 
  birthdate DATE, 
  gender CHAR(1) CONSTRAINT gender CHECK(
    gender = 'M' 
    OR gender = 'F'
  ), 
  phone_no VARCHAR(32) NOT NULL, 
  address text
);

CREATE TABLE IF NOT EXISTS doctors (
  MCR CHAR(7) PRIMARY KEY, 
  first_name VARCHAR(64) NOT NULL, 
  last_name VARCHAR(64), 
  department VARCHAR(64) CONSTRAINT department CHECK(
    department IN (
      'Others', 'Emergency', 'ICU', 'Cardiology', 
      'Renal', 'Pediatric', 'Oncology', 
      'Gynecology', 'Surgery'
    )
  ), 
  gender VARCHAR(16) CONSTRAINT gender CHECK(
    gender IN ('F', 'M')
  ), 
  email VARCHAR(256) NOT NULL, 
  phone_no VARCHAR(32) NOT NULL
);

CREATE TABLE IF NOT EXISTS follow_up (
  NRIC CHAR(9) REFERENCES patients(NRIC) ON UPDATE CASCADE DEFERRABLE, 
  MCR CHAR(7) REFERENCES doctors(MCR) ON UPDATE CASCADE DEFERRABLE, 
  PRIMARY KEY(NRIC, MCR)
);
/************************************************************************/

/*                                                                      */

/* Question 1.d                                                         */

/*                                                                      */

/************************************************************************/

/* Write your answer in SQL below: */

insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T6281520D', 'Keriann', 'Riediger', 
    '2003-12-14', 'F', '1908037887', 
    '33484 Reindahl Alley'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F2134071U', 'Ban', 'Yurlov', '1972-07-11', 
    'M', '6965742591', '79 Mifflin Alley'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T3337460J', 'Kim', 'Mudie', '2019-04-10', 
    'F', '1022415899', '77 Debra Lane'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T8104864W', 'Eden', 'Hiscoke', '2002-10-26', 
    'F', '9824622514', '22 Village Green Drive'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S8753552U', 'Genvieve', 'McAmish', 
    '1959-11-12', 'F', '7308960724', 
    '7433 Killdeer Trail'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F9123554U', 'Torrin', 'Vankeev', 
    '1991-02-28', 'M', '1537532045', 
    '1 Upham Junction'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F5546134Q', 'Linea', 'Beckett', '1984-01-08', 
    'F', '1418815202', '8142 Reindahl Way'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S3869791E', 'Tabbatha', 'Oneile', 
    '1970-05-07', 'F', '3847322417', 
    '0776 Myrtle Avenue'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S6713789J', 'Roberto', 'Churn', '1984-01-04', 
    'M', '3369794919', '6 Kennedy Drive'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T9554192M', 'Katuscha', 'Bryden', 
    '1963-11-30', 'F', '7743146675', 
    '74 Erie Trail'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G1075734U', 'Rheta', 'Segrave', '1959-04-27', 
    'F', '8024809727', '3645 Delladonna Plaza'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T9570689U', 'Rollie', 'Kingdon', 
    '2018-12-31', 'M', '9284168193', 
    '191 Blue Bill Park Park'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S6850057V', 'Tim', 'Cockerell', '2010-10-01', 
    'F', '7283289139', '13222 Crest Line Park'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G9102977R', 'Keven', 'Ormshaw', '2006-02-23', 
    'M', '7881503464', '001 Sunnyside Trail'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S5713162P', 'Terencio', 'Petrakov', 
    '1979-05-12', 'M', '9293101289', 
    '31794 Del Sol Court'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T5720951U', 'Roderic', 'Skoof', '2004-01-02', 
    'M', '5615169109', '43092 Manufacturers Center'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S2317056V', 'Rani', 'Nelthropp', 
    '1956-01-22', 'F', '2958035268', 
    '17391 Sullivan Avenue'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F1694932B', 'Doralynne', 'Busfield', 
    '2003-02-21', 'F', '5863679387', 
    '93843 Muir Park'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G9005057V', 'Agata', 'Deans', '1988-03-24', 
    'F', '3514595938', '48220 Farmco Hill'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F6183824G', 'Shaine', 'Whapples', 
    '1991-02-16', 'M', '9012484296', 
    '50513 Roth Center'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F7136701M', 'George', 'Di Franceshci', 
    '1995-11-06', 'F', '9321521308', 
    '562 Blue Bill Park Way'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F7634456Q', 'Man', 'Pursey', '1955-05-25', 
    'M', '3194278850', '32959 Golden Leaf Way'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G4795514X', 'Katey', 'Keuneke', '2016-06-09', 
    'F', '5962809404', '67 Commercial Terrace'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G2164273L', 'Christabel', 'Hanfrey', 
    '1968-01-19', 'F', '8371991724', 
    '059 Judy Drive'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G1639245C', 'Aurthur', 'O''Loghlen', 
    '2008-02-08', 'M', '7279183328', 
    '83433 Mitchell Avenue'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G2992783B', 'Shurwood', 'Linzee', 
    '1995-11-02', 'M', '1182681658', 
    '011 Fieldstone Junction'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G8824245K', 'Kaitlynn', 'Jarrold', 
    '1979-11-04', 'F', '7773296125', 
    '741 Oak Valley Terrace'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T2436666N', 'Karlotta', 'Tilio', 
    '1981-07-20', 'F', '2027138749', 
    '1 Kinsman Street'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F4278810X', 'Juli', 'Culbard', '2019-04-21', 
    'F', '3984475861', '823 Prairieview Parkway'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T3423770I', 'Zabrina', 'Danielski', 
    '2010-01-01', 'F', '9507446998', 
    '80 Dapin Road'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G5085247E', 'Elwood', 'Mateo', '1950-11-15', 
    'M', '8602442471', '13 Anderson Plaza'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F6907791R', 'Deloria', 'Netherclift', 
    '2008-07-22', 'F', '8023641056', 
    '8 Judy Avenue'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T6263093K', 'Emlyn', 'Farron', '1964-01-11', 
    'M', '6865319641', '87964 Grayhawk Trail'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F2258202F', 'Tomasine', 'Ronald', 
    '1981-07-10', 'F', '3307483946', 
    '3 David Center'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S3664922P', 'Nolly', 'Beebee', '2000-01-30', 
    'M', '9243551549', '04941 Harbort Place'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F9068555B', 'Neille', 'Grieswood', 
    '2012-02-15', 'F', '9472803910', 
    '22323 Sunnyside Trail'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S7891582U', 'Shermie', 'Luttgert', 
    '2016-09-01', 'M', '2175229294', 
    '25692 East Drive'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G6538728W', 'Gherardo', 'Ledgley', 
    '2009-08-17', 'M', '6283144150', 
    '36369 Steensland Road'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G3915704T', 'Rosa', 'Gabbat', '2008-01-03', 
    'F', '8106374550', '9511 Beilfuss Terrace'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T4724647X', 'Anabella', 'Dubble', 
    '2009-01-14', 'F', '3218093502', 
    '69702 Moose Terrace'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G2126168P', 'Persis', 'Hensmans', 
    '1994-12-14', 'F', '9769415737', 
    '30238 Memorial Alley'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S4736333U', 'Ealasaid', 'Gladtbach', 
    '2010-02-08', 'F', '9075523680', 
    '62621 Lakewood Gardens Street'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S4501860V', 'Ranique', 'Bastard', 
    '1964-08-28', 'F', '9556744895', 
    '65 Veith Drive'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T8887918T', 'Orson', 'Hynes', '1986-03-19', 
    'M', '8345460407', '87 Lotheville Lane'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T4740111Z', 'Brnaba', 'Godbald', 
    '1978-05-31', 'M', '4101324949', 
    '18590 Prairieview Junction'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S4063582T', 'Norah', 'Luigi', '1970-03-25', 
    'F', '7972186805', '58319 Stuart Avenue'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G6595256B', 'Bartholomeus', 'Hush', 
    '2018-10-22', 'M', '3393535899', 
    '29124 Blue Bill Park Drive'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G4508265T', 'Trixi', 'Semper', '2003-09-27', 
    'F', '9111687656', '2 Village Green Parkway'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S3358765E', 'Shadow', 'Jales', '1982-12-02', 
    'M', '4825515138', '94 Ludington Junction'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F3800404Z', 'Janel', 'Wallas', '2018-06-01', 
    'F', '3202515637', '5 Muir Plaza'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T2218869K', 'Matteo', 'Kelle', '1969-04-11', 
    'M', '8986957458', '2 Hoard Street'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S6310507Y', 'Alejandrina', 'Clulee', 
    '1997-12-14', 'F', '6429777533', 
    '0 Fair Oaks Crossing'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S9693892X', 'Barrie', 'Pollicatt', 
    '2003-11-09', 'M', '3046839687', 
    '4 Tennessee Way'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T4601110G', 'Gaylene', 'Storrie', 
    '2016-07-04', 'F', '1848292975', 
    '5613 Karstens Hill'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G8204260P', 'Ky', 'Bensusan', '1999-11-23', 
    'M', '9759002096', '098 Warner Road'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T5686315L', 'Nester', 'De Benedictis', 
    '2015-11-08', 'M', '2022261522', 
    '60435 Charing Cross Plaza'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F4121883D', 'Bird', 'Espin', '1958-05-28', 
    'F', '5374468722', '318 Oakridge Hill'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T1971692F', 'Beltran', 'Brimming', 
    '2014-07-10', 'M', '5352482826', 
    '668 Fallview Terrace'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G8157358R', 'Thia', 'Brayshay', '1974-11-29', 
    'F', '5465146386', '1782 Vidon Street'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G4428998P', 'Zelig', 'Plott', '1957-06-02', 
    'M', '4286852014', '69 Stephen Hill'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G7001490F', 'Wainwright', 'Pencott', 
    '1984-06-12', 'M', '4885345551', 
    '2684 Harbort Way'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F6224186H', 'Shem', 'Oliveto', '1976-02-09', 
    'M', '6858239340', '30 Veith Crossing'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G5497196R', 'Barb', 'Torbard', '1951-02-09', 
    'F', '4914252312', '4 Village Point'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F8858473U', 'Fanechka', 'Zamorrano', 
    '1988-04-30', 'F', '2436962103', 
    '0132 Evergreen Parkway'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F4698273T', 'Sophey', 'Dillon', '1970-02-13', 
    'F', '6851896349', '4 American Ash Junction'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S1110575D', 'Robinson', 'Adamovitz', 
    '1971-08-24', 'M', '9765617921', 
    '9 Fuller Terrace'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T4697362O', 'Nelson', 'Bofield', 
    '1987-05-10', 'M', '6018401167', 
    '84 Elgar Road'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T7188371E', 'Mollie', 'Persicke', 
    '1961-05-25', 'F', '1286967434', 
    '3 Park Meadow Place'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F8959231N', 'Araldo', 'Toner', '1997-08-14', 
    'M', '5487399998', '40 Nobel Center'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T9436626Q', 'Garfield', 'MacCafferky', 
    '1996-01-05', 'M', '3911198080', 
    '28 4th Hill'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F2883930F', 'Britney', 'Scedall', 
    '1971-06-05', 'F', '2441897428', 
    '413 Merry Hill'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F8386699N', 'Berny', 'Bellringer', 
    '1995-11-18', 'M', '5545334115', 
    '75 Mockingbird Trail'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G3365672Y', 'Tildy', 'Ames', '2001-01-18', 
    'F', '2949704327', '813 Lerdahl Plaza'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S9094009B', 'Gaylor', 'Ogilvie', 
    '1987-08-17', 'M', '7046829052', 
    '03 Menomonie Parkway'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T6313106R', 'Marybelle', 'Weaver', 
    '1998-06-07', 'F', '3551905364', 
    '40973 Service Street'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S6937066N', 'Franciskus', 'Norval', 
    '1983-08-15', 'M', '7503798311', 
    '82 Surrey Lane'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T5401413I', 'Milena', 'Berrington', 
    '1987-02-16', 'F', '3818557334', 
    '9023 Artisan Crossing'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T2945045T', 'Darrel', 'Girodon', 
    '1968-01-04', 'M', '6494468840', 
    '244 Del Mar Court'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G5386374P', 'Rourke', 'Mulgrew', 
    '1998-04-20', 'M', '5567798043', 
    '06560 Brown Alley'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S1044431R', 'Noach', 'Karlowicz', 
    '1977-12-05', 'M', '6876627046', 
    '0 Almo Road'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S1159299B', 'Joshua', 'Rolf', '1983-03-25', 
    'M', '4241260911', '3165 Blackbird Street'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T4576104T', 'Brander', 'Du Pre', 
    '1970-10-21', 'M', '2187211834', 
    '381 Victoria Court'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F3495798H', 'Nobie', 'Owtram', '1989-01-18', 
    'M', '1447042002', '0297 Buell Junction'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G3588429F', 'Ynes', 'Ishak', '1989-06-17', 
    'F', '2541594626', '7424 Mccormick Avenue'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F1327987K', 'Sophi', 'Grenshields', 
    '2005-10-01', 'F', '7838155876', 
    '27832 Delaware Alley'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G2764944F', 'Lorita', 'Thatcham', 
    '1994-07-03', 'F', '1294307707', 
    '00 Brickson Park Street'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G8607871U', 'Slade', 'Tippin', '2007-05-13', 
    'M', '5067730957', '33 Lakewood Pass'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G8658640M', 'Colver', 'Zavattiero', 
    '2009-08-31', 'M', '5685657977', 
    '4 South Plaza'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G3958119G', 'Bank', 'Crocumbe', '1966-08-27', 
    'M', '7697574781', '71 Eggendart Park'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T5068171X', 'Delbert', 'Goulden', 
    '1989-06-02', 'M', '8797814009', 
    '98 Carberry Avenue'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T9475980H', 'Dennet', 'Jopson', '1958-08-10', 
    'M', '1541934816', '9481 Moulton Trail'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T6370963O', 'Lay', 'Garrod', '2005-05-22', 
    'M', '9548600235', '0 Fuller Parkway'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S1815171K', 'Baryram', 'Norcop', 
    '1978-12-27', 'M', '7097270707', 
    '8635 Eastlawn Avenue'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F9103254D', 'Fiann', 'Vidloc', '2020-05-06', 
    'F', '1074776653', '818 High Crossing Street'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S4310633U', 'Erastus', 'Flaherty', 
    '1966-01-13', 'M', '7675752171', 
    '8205 Lukken Parkway'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'G1046227P', 'Edita', 'Junkin', '1977-03-22', 
    'F', '5505686753', '1 Packers Lane'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'S4119434G', 'Tab', 'Berrane', '1961-02-17', 
    'M', '1789378689', '4 Dovetail Pass'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T4716608N', 'Blythe', 'Burnhill', 
    '1959-01-11', 'F', '5553380713', 
    '70 Jenifer Road'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'T1830836J', 'Normie', 'Jeanequin', 
    '2014-12-02', 'M', '2563874327', 
    '170 Washington Parkway'
  );
insert into patients (
  NRIC, first_name, last_name, birthdate, 
  gender, phone_no, address
) 
values 
  (
    'F3970569P', 'Halsy', 'Feather', '1985-10-14', 
    'M', '6952738905', '32 Eastlawn Park'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M25200A', 'Arlen', 'Soreau', 'Emergency', 
    'M', 'asoreau0@walmart.com', '8746634281'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M65759J', 'Robena', 'Moat', 'Emergency', 
    'F', 'rmoat1@nbcnews.com', '5505041997'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M47657A', 'Bernice', 'Wixey', 'Gynecology', 
    'F', 'bwixey2@abc.net.au', '3335600949'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M60561V', 'Craggy', 'Muge', 'Oncology', 
    'M', 'cmuge3@amazon.com', '8949796271'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M65088Y', 'Donetta', 'Stalley', 'Gynecology', 
    'F', 'dstalley4@opensource.org', 
    '2257556251'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M34235E', 'Ginnifer', 'Olennikov', 
    'Pediatric', 'F', 'golennikov5@nasa.gov', 
    '8356613195'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M13613V', 'Pierette', 'Hibbart', 
    'ICU', 'F', 'phibbart6@dell.com', 
    '9235163535'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M62703F', 'Kandy', 'Slayton', 'Renal', 
    'F', 'kslayton7@blogspot.com', '6526637527'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M53913H', 'Dev', 'Drioli', 'Gynecology', 
    'M', 'ddrioli8@examiner.com', '5112814748'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M60369U', 'Manolo', 'Litherland', 
    'Emergency', 'M', 'mlitherland9@eventbrite.com', 
    '6771896098'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M40935U', 'Zorah', 'Hainey', 'Emergency', 
    'F', 'zhaineya@archive.org', '7672462101'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M60066E', 'Licha', 'Harpham', 'Gynecology', 
    'F', 'lharphamb@cdbaby.com', '6934438014'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M54308X', 'Margo', 'Headech', 'ICU', 
    'F', 'mheadechc@hp.com', '4752012608'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M64962G', 'Aldis', 'Harwood', 'ICU', 
    'M', 'aharwoodd@infoseek.co.jp', 
    '1037120688'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M27624W', 'Phoebe', 'Brundall', 'Oncology', 
    'F', 'pbrundalle@amazonaws.com', 
    '9454668594'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M32853J', 'Tailor', 'Silkston', 'Emergency', 
    'M', 'tsilkstonf@epa.gov', '7269218030'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M59663O', 'Emilia', 'Rolland', 'Oncology', 
    'F', 'erollandg@unblog.fr', '2102772169'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M58669W', 'Kippie', 'Bramley', 'Oncology', 
    'F', 'kbramleyh@smh.com.au', '2793477569'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M20839P', 'Leland', 'Pleass', 'Cardiology', 
    'M', 'lpleassi@independent.co.uk', 
    '3022923257'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M66862E', 'Edita', 'Ketcher', 'ICU', 
    'F', 'eketcherj@sohu.com', '1912334083'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M16921A', 'Sharline', 'Twopenny', 
    'ICU', 'F', 'stwopennyk@washington.edu', 
    '2733560967'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M49755Y', 'Jon', 'Brewitt', 'Pediatric', 
    'M', 'jbrewittl@gmpg.org', '7275198000'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M69920W', 'Bran', 'Jonah', 'Cardiology', 
    'M', 'bjonahm@imageshack.us', '5166261875'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M60272B', 'Heloise', 'Ferrige', 'Pediatric', 
    'F', 'hferrigen@yandex.ru', '8655911393'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M39419Z', 'Mariann', 'Kernermann', 
    'ICU', 'F', 'mkernermanno@example.com', 
    '1698400214'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M13409B', 'Crysta', 'St. Aubyn', 
    'Surgery', 'F', 'cstaubynp@163.com', 
    '4826864107'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M45470A', 'Cheslie', 'Spring', 'Oncology', 
    'F', 'cspringq@illinois.edu', '5741972899'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M41849U', 'Lauren', 'Tye', 'Cardiology', 
    'M', 'ltyer@hp.com', '9949674508'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M15166Z', 'Bourke', 'Hainge', 'Oncology', 
    'M', 'bhainges@scientificamerican.com', 
    '9763009069'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M21926T', 'Elvyn', 'Jeays', 'ICU', 
    'M', 'ejeayst@google.ru', '6252415353'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M77747K', 'Pru', 'Tiler', 'Surgery', 
    'F', 'ptileru@acquirethisname.com', 
    '8173673716'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M68450S', 'Ellerey', 'Ipwell', 'Emergency', 
    'M', 'eipwellv@amazonaws.com', '3119017058'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M18138F', 'Tome', 'Stiegers', 'Oncology', 
    'M', 'tstiegersw@prnewswire.com', 
    '3345428023'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M74332T', 'Rourke', 'Matokhnin', 
    'Gynecology', 'M', 'rmatokhninx@xrea.com', 
    '4483039225'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M63029G', 'Roth', 'Anand', 'Gynecology', 
    'M', 'ranandy@devhub.com', '2192404487'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M22424L', 'Zea', 'Haylett', 'Surgery', 
    'F', 'zhaylettz@businesswire.com', 
    '3743601633'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M45593Y', 'Lyndell', 'Roubert', 'Oncology', 
    'F', 'lroubert10@netscape.com', 
    '2916393226'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M64707H', 'Merwyn', 'Carrell', 'Emergency', 
    'M', 'mcarrell11@gov.uk', '1562860996'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M10948R', 'Bennie', 'Labes', 'ICU', 
    'M', 'blabes12@wisc.edu', '3528687367'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M43760J', 'Maxie', 'Overill', 'Surgery', 
    'M', 'moverill13@nps.gov', '9332391512'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M48162N', 'Milena', 'Ghidoli', 'ICU', 
    'F', 'mghidoli14@bbb.org', '9495324770'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M21646E', 'Elton', 'Staries', 'ICU', 
    'M', 'estaries15@live.com', '9131881036'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M71434M', 'Kearney', 'Teck', 'Gynecology', 
    'M', 'kteck16@edublogs.org', '8953337877'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M46463K', 'Bogart', 'Markwick', 'Cardiology', 
    'M', 'bmarkwick17@ocn.ne.jp', '1843050704'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M72562O', 'Sutherlan', 'Prescott', 
    'Renal', 'M', 'sprescott18@quantcast.com', 
    '4997458961'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M76283U', 'Oralle', 'Merrigans', 
    'Oncology', 'F', 'omerrigans19@un.org', 
    '9497885370'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M12943I', 'Rance', 'Oldacres', 'Renal', 
    'M', 'roldacres1a@php.net', '5628383221'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M28828A', 'Tandy', 'Arent', 'Renal', 
    'F', 'tarent1b@prweb.com', '8598892373'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M71894H', 'Giraldo', 'Trainer', 'Oncology', 
    'M', 'gtrainer1c@wunderground.com', 
    '6652920696'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M57185K', 'Bartie', 'Mulvenna', 'Surgery', 
    'M', 'bmulvenna1d@unblog.fr', '6016788105'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M70397O', 'Jarret', 'Hoodless', 'Cardiology', 
    'M', 'jhoodless1e@seattletimes.com', 
    '6575862250'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M70186W', 'Denyse', 'Hanshawe', 'Oncology', 
    'F', 'dhanshawe1f@myspace.com', 
    '8822766967'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M20037F', 'Woodrow', 'Ripsher', 'ICU', 
    'M', 'wripsher1g@alibaba.com', '6235786782'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M59492R', 'Cull', 'Etherson', 'Emergency', 
    'M', 'cetherson1h@weibo.com', '4611603241'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M44329A', 'Jeanne', 'Stanesby', 'Cardiology', 
    'F', 'jstanesby1i@opensource.org', 
    '8656906590'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M12486V', 'Cindra', 'Daish', 'ICU', 
    'F', 'cdaish1j@forbes.com', '9817499078'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M42688A', 'Cad', 'Smaile', 'ICU', 
    'M', 'csmaile1k@dailymail.co.uk', 
    '3389463207'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M17198M', 'Dru', 'Woollam', 'Oncology', 
    'M', 'dwoollam1l@digg.com', '8397054794'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M68112W', 'Pooh', 'Scohier', 'Emergency', 
    'F', 'pscohier1m@hatena.ne.jp', 
    '5866170593'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M59411D', 'Temp', 'Stockin', 'Pediatric', 
    'M', 'tstockin1n@odnoklassniki.ru', 
    '2484586520'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M34213P', 'Bendite', 'Corking', 'Oncology', 
    'F', 'bcorking1o@home.pl', '3701255907'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M37844H', 'Jasun', 'Dowers', 'Renal', 
    'M', 'jdowers1p@wired.com', '6012937889'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M69702T', 'Alasdair', 'Banks', 'Pediatric', 
    'M', 'abanks1q@ocn.ne.jp', '9995724233'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M30570Y', 'Redd', 'D''Elia', 'ICU', 
    'M', 'rdelia1r@comcast.net', '4997746463'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M64940C', 'Arther', 'Klosterman', 
    'Cardiology', 'M', 'aklosterman1s@nymag.com', 
    '5714493363'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M14957I', 'Dunc', 'Siebart', 'Renal', 
    'M', 'dsiebart1t@un.org', '3764381864'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M25043O', 'Leonardo', 'Syers', 'Surgery', 
    'M', 'lsyers1u@arstechnica.com', 
    '6251231568'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M59236N', 'Kassie', 'Wickerson', 
    'Renal', 'F', 'kwickerson1v@gravatar.com', 
    '4797975339'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M45335Z', 'Lydon', 'Cowderay', 'Cardiology', 
    'M', 'lcowderay1w@wiley.com', '8041837670'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M64621G', 'Quint', 'Maylin', 'Oncology', 
    'M', 'qmaylin1x@cornell.edu', '8858800264'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M22455N', 'Any', 'Pybus', 'Gynecology', 
    'M', 'apybus1y@npr.org', '8164833229'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M63808H', 'Rafi', 'Frampton', 'Oncology', 
    'M', 'rframpton1z@time.com', '6877935005'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M71635M', 'Marion', 'Earlam', 'Gynecology', 
    'M', 'mearlam20@1und1.de', '1096242070'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M11161W', 'Grannie', 'Janota', 'Gynecology', 
    'M', 'gjanota21@cdc.gov', '6584352384'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M71540J', 'Nannie', 'Ludye', 'Gynecology', 
    'F', 'nludye22@zdnet.com', '6375795056'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M30063Y', 'Katherina', 'Brockhurst', 
    'Cardiology', 'F', 'kbrockhurst23@comsenz.com', 
    '1263087692'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M12344A', 'Sidnee', 'Cund', 'Gynecology', 
    'M', 'scund24@nasa.gov', '3418205828'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M10281Z', 'Loren', 'Mew', 'Emergency', 
    'F', 'lmew25@sciencedirect.com', 
    '9732215787'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M18469A', 'Byram', 'Wigfield', 'Cardiology', 
    'M', 'bwigfield26@bigcartel.com', 
    '1987775472'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M68539R', 'Clyve', 'Stickells', 'Oncology', 
    'M', 'cstickells27@techcrunch.com', 
    '5157947573'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M22918K', 'North', 'Haggleton', 'Cardiology', 
    'M', 'nhaggleton28@alibaba.com', 
    '9985451237'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M62052I', 'Gerhardt', 'Fulle', 'Pediatric', 
    'M', 'gfulle29@cyberchimps.com', 
    '5464193213'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M28372L', 'Orin', 'Boays', 'Cardiology', 
    'M', 'oboays2a@lycos.com', '8329605494'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M13613Z', 'Lexy', 'Hunnywell', 'Surgery', 
    'F', 'lhunnywell2b@vimeo.com', '5668604203'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M28970B', 'Antone', 'Bold', 'Renal', 
    'M', 'abold2c@usatoday.com', '4317317952'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M10129E', 'Duffy', 'Aiskrigg', 'Renal', 
    'M', 'daiskrigg2d@etsy.com', '5576305367'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M13046L', 'Maible', 'Margrett', 'Renal', 
    'F', 'mmargrett2e@fastcompany.com', 
    '2385168092'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M31371Q', 'Godiva', 'Silber', 'Emergency', 
    'F', 'gsilber2f@desdev.cn', '6251487856'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M16695D', 'Joel', 'Reichardt', 'Pediatric', 
    'M', 'jreichardt2g@amazonaws.com', 
    '6701514581'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M35528I', 'Vincent', 'Giraudou', 
    'Emergency', 'M', 'vgiraudou2h@dmoz.org', 
    '6492844083'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M32872W', 'Averyl', 'Ell', 'Renal', 
    'F', 'aell2i@vistaprint.com', '4595838652'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M72660L', 'Ferdinand', 'Enric', 'Surgery', 
    'M', 'fenric2j@army.mil', '5741981518'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M74806I', 'Marlow', 'McClune', 'Gynecology', 
    'M', 'mmcclune2k@creativecommons.org', 
    '3022168524'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M21876T', 'Margarette', 'Willshee', 
    'Surgery', 'F', 'mwillshee2l@tamu.edu', 
    '6946314283'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M67610K', 'Harwell', 'Humphrys', 
    'Pediatric', 'M', 'hhumphrys2m@e-recht24.de', 
    '7619152807'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M45261E', 'Mick', 'Oldroyde', 'Pediatric', 
    'M', 'moldroyde2n@whitehouse.gov', 
    '7054555510'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M20706J', 'Elora', 'Belle', 'Oncology', 
    'F', 'ebelle2o@acquirethisname.com', 
    '5925871285'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M73421C', 'Roddy', 'Elphey', 'Surgery', 
    'M', 'relphey2p@nytimes.com', '2458742002'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M21952G', 'Afton', 'Kamienski', 'ICU', 
    'F', 'akamienski2q@illinois.edu', 
    '1021669137'
  );
insert into doctors (
  MCR, first_name, last_name, department, 
  gender, email, phone_no
) 
values 
  (
    'M36721M', 'Padraic', 'Mila', 'ICU', 
    'M', 'pmila2r@opensource.org', '3015580833'
  );
/************************************************************************/

/*                                                                      */

/* Question 1.e                                                         */

/*                                                                      */

/************************************************************************/

/* Write your answer in SQL below: */
INSERT INTO follow_up(NRIC, MCR) 
SELECT 
  NRIC, 
  MCR 
FROM 
  patients, 
  doctors 
ORDER BY 
  random() 
LIMIT 
  1000;
