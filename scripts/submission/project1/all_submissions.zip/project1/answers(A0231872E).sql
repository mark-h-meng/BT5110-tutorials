/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The three tables are named customers,drug and buyer respetively.Customers table contains first_name,last_name, customer_ip. Drug table contains drug_name, drug_company and drug_generic. Buyer indicates which customers ( by referencing ip_address )  bought what kind of drug (by referencing drug_company and drug_brand).
The code is written for PostgreSQL 
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table if not exists customers(
first_name varchar(64) not null,
last_name varchar(64) not null,
customer_ip varchar(64) primary key);

create table if not exists drug(
drug_company VARCHAR(64) not null,
drug_name varchar(128) not null,
drug_generic VARCHAR(512) not null,
primary key(drug_company,drug_name));

create table buyer (
customer_ip varchar(64) references customers(customer_ip)
on update cascade on delete cascade
deferrable initially deferred,
drug_company VARCHAR(64),
drug_name varchar(128),
primary key(customer_ip,drug_company,drug_name),
foreign key(drug_company,drug_name) references drug(drug_company,drug_name)
on update cascade on delete cascade
deferrable initially deferred
);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
delete from drug;
delete from customers;
insert into drug (drug_company, drug_name, drug_generic) values ('American Health Packaging', 'Gabapentin', 'Gabapentin');
insert into drug (drug_company, drug_name, drug_generic) values ('Shanghai Kejing Cleaning Products Co., Ltd', 'Sunscreen SPF 30', 'Octinoxate, Octisalate, Oxybenzone, Titanium Dioxide');
insert into drug (drug_company, drug_name, drug_generic) values ('Avon Products, Inc.', 'Clearskin', 'Salicylic Acid');
insert into drug (drug_company, drug_name, drug_generic) values ('Supervalu Inc', 'Equaline Nicotine', 'Nicotine Polacrilex');
insert into drug (drug_company, drug_name, drug_generic) values ('Cantrell Drug Company', 'Fentanyl Citrate', 'Fentanyl Citrate');
insert into drug (drug_company, drug_name, drug_generic) values ('Van Tibolli Beauty Corp.', 'GKhair Anti-Dandruff', 'Pyrithione Zinc');
insert into drug (drug_company, drug_name, drug_generic) values ('THE KROGER CO', 'KROGER SPF 15', 'AVOBENZONE, HOMOSALATE, OCTISALATE, OCTOCRYLENE');
insert into drug (drug_company, drug_name, drug_generic) values ('Sandoz Inc', 'Temazepam', 'Temazepam');
insert into drug (drug_company, drug_name, drug_generic) values ('Rite Aid Corporation', 'infants fever reducer and pain reliever', 'acetaminophen');
insert into drug (drug_company, drug_name, drug_generic) values ('Allermed Laboratories, Inc.', 'Canary Grass Pollen', 'Phalaris arundinaceae');
insert into drug (drug_company, drug_name, drug_generic) values ('REMEDYREPACK INC.', 'Warfarina Sodium', 'Warfarin Sodium');
insert into drug (drug_company, drug_name, drug_generic) values ('Topco Associates LLC', 'TopCare', 'Neomycin Sulfate, Polymyxin B Sulfate, and Pramoxine Hydrochloride');
insert into drug (drug_company, drug_name, drug_generic) values ('Walgreen Company', 'Cold and Flu', 'Acetaminophen, Dextromethorphan HBr, Doxylamine succinate');
insert into drug (drug_company, drug_name, drug_generic) values ('L''Oreal USA Products Inc', 'Lancome Paris Absolue Precious Cells Sunscreen Repairing and Recovering Day', 'Avobenzone, Octisalate and Octocrylene');
insert into drug (drug_company, drug_name, drug_generic) values ('EMD Serono, Inc.', 'Gonal-f', 'follitropin alfa');
insert into drug (drug_company, drug_name, drug_generic) values ('Reese Pharmaceutical Co', 'Refenesen Chest Congestion Relief', 'Guaifenesin/phenylephrine');
insert into drug (drug_company, drug_name, drug_generic) values ('Greenbrier International, Inc.', 'Assured Instant Hand Sanitizer', 'Alcohol');
insert into drug (drug_company, drug_name, drug_generic) values ('Blossom Pharmaceticals', 'Blossom Pharmaceuticals Antifungal', 'antifungal');
insert into drug (drug_company, drug_name, drug_generic) values ('CVS Pharmacy', 'Daytime Nighttime Cold Flu Relief', 'Acetaminophen, Dextromethorphan HBr, Doxylamine succinate, Phenylephrine HCl');
insert into drug (drug_company, drug_name, drug_generic) values ('Mylan Pharmaceuticals Inc.', 'Risperidone', 'risperidone');
insert into drug (drug_company, drug_name, drug_generic) values ('Uriel Pharmacy Inc.', 'Pulmo Tartarus 6/8', 'Pulmo Tartarus 6/8');
insert into drug (drug_company, drug_name, drug_generic) values ('TRIGEN Laboratories, Inc.', 'Triveen-PRx', 'Folic Acid, Ascorbic Acid, Tribasic Calcium Phosphate, Iron, Cholecalciferol, Alpha-Tocopherol, Pyridoxine Hydrochloride, Doconexent, and Docusate Sodium');
insert into drug (drug_company, drug_name, drug_generic) values ('VVF Illinois Services', 'Soft and Dri Dri Gel', 'Aluminum Zirconium Octochlorohydrex');
insert into drug (drug_company, drug_name, drug_generic) values ('Cardinal Health', 'Enoxaparin Sodium', 'Enoxaparin Sodium');
insert into drug (drug_company, drug_name, drug_generic) values ('Cantrell Drug Company', 'Hydromorphone HCl', 'Hydromorphone HCl');
insert into drug (drug_company, drug_name, drug_generic) values ('REMEDYREPACK INC.', 'SSD Cream', 'Silver Sulfadiazine');
insert into drug (drug_company, drug_name, drug_generic) values ('Par Pharmaceutical Inc.', 'Dexmethylphenidate Hydrochloride Extended-Release', 'dexmethylphenidate hydrochloride');
insert into drug (drug_company, drug_name, drug_generic) values ('State of Florida DOH Central Pharmacy', 'Lisinopril', 'Lisinopril');
insert into drug (drug_company, drug_name, drug_generic) values ('Physicians Total Care, Inc.', 'Atovaquone and Proguanil Hydrochloride', 'Atovaquone and Proguanil Hydrochloride');
insert into drug (drug_company, drug_name, drug_generic) values ('Nelco Laboratories, Inc.', 'Standardized Bermuda Grass Pollen', 'Standardized Bermuda Grass Pollen');
insert into drug (drug_company, drug_name, drug_generic) values ('Babor Cosmetics America, Corp', 'High Protection Sun SPF 30', 'Titanium Dioxide');
insert into drug (drug_company, drug_name, drug_generic) values ('Sanum Kehlbeck GmbH & Co. KG', 'Pleo Ut S', 'mycobacterium phlei');
insert into drug (drug_company, drug_name, drug_generic) values ('Uriel Pharmacy Inc.', 'Adonis Crataegus', 'Adonis Crataegus');
insert into drug (drug_company, drug_name, drug_generic) values ('Vanda Pharmaceuticals Inc.', 'Fanapt', 'iloperidone');
insert into drug (drug_company, drug_name, drug_generic) values ('Mylan Pharmaceuticals Inc.', 'Thiothixene', 'thiothixene');
insert into drug (drug_company, drug_name, drug_generic) values ('Donovan Industries, Inc', 'DawnMist Deodorant Bar No. 5', 'TRICLOSAN');
insert into drug (drug_company, drug_name, drug_generic) values ('WOCKHARDT USA LLC.', 'AMLODIPINE BESYLATE', 'AMLODIPINE BESYLATE');
insert into drug (drug_company, drug_name, drug_generic) values ('Wockhardt USA LLC.', 'Bupropion Hydrochloride', 'Bupropion Hydrochloride');
insert into drug (drug_company, drug_name, drug_generic) values ('Blossom Pharmaceuticals', 'Zinc Oxide', 'Zinc Oxide');
insert into drug (drug_company, drug_name, drug_generic) values ('St Marys Medical Park Pharmacy', 'GLIMEPIRIDE', 'GLIMEPIRIDE');
insert into drug (drug_company, drug_name, drug_generic) values ('BioActive Nutritional, Inc.', 'Allerforce', 'Chondrus Crispus, Glycyrrhiza Glabra, Sarsaparilla, Zingiber Officinale, Adrenalinum, Allium Cepa, Aralia Racemosa');
insert into drug (drug_company, drug_name, drug_generic) values ('BioChemics, Inc', 'Bio-Scriptives Lidum', 'Lidocaine');
insert into drug (drug_company, drug_name, drug_generic) values ('Dispensing Solutions, Inc.', 'Anastrozole', 'Anastrozole');
insert into drug (drug_company, drug_name, drug_generic) values ('Proficient Rx LP', 'promethazine hydrochloride', 'promethazine hydrochloride');
insert into drug (drug_company, drug_name, drug_generic) values ('GlaxoSmithKline LLC', 'IMITREX', 'sumatriptan succinate');
insert into drug (drug_company, drug_name, drug_generic) values ('Morgan Gallacher Inc.', 'MG DermaSan', 'N/A');
insert into drug (drug_company, drug_name, drug_generic) values ('Guna spa', 'GUNA-IL 6', 'INTERLEUKIN-6');
insert into drug (drug_company, drug_name, drug_generic) values ('Good Sense', 'Acid Reducer', 'Ranitidine');
insert into drug (drug_company, drug_name, drug_generic) values ('WALGREEN COMPANY', 'STUDIO 35', 'BENZALKONIUM CHLORIDE');
insert into drug (drug_company, drug_name, drug_generic) values ('Upsher-Smith Laboratories, Inc.', 'Morphine Sulfate', 'Morphine Sulfate');
insert into drug (drug_company, drug_name, drug_generic) values ('Zydus Pharmaceuticals (USA) Inc.', 'Haloperidol', 'Haloperidol');
insert into drug (drug_company, drug_name, drug_generic) values ('McKesson (Health Mart)', 'All Day Allergy', 'Cetirizine HCl');
insert into drug (drug_company, drug_name, drug_generic) values ('AIRSENSE INC', 'OXYGEN', 'OXYGEN');
insert into drug (drug_company, drug_name, drug_generic) values ('Heritage Pharmaceuticals Inc.', 'Propranolol Hydrochloride', 'Propranolol Hydrochloride');
insert into drug (drug_company, drug_name, drug_generic) values ('Teva Pharmaceuticals USA Inc', 'Clozapine', 'Clozapine');
insert into drug (drug_company, drug_name, drug_generic) values ('Target Corporation', 'Up and Up childrens all day allergy relief', 'cetirizine Hydrochloride');
insert into drug (drug_company, drug_name, drug_generic) values ('NASH-FINCH COMPANY', 'Gentle Laxative', 'Bisacodyl');
insert into drug (drug_company, drug_name, drug_generic) values ('Sandoz Inc', 'Olanzapine', 'Olanzapine');
insert into drug (drug_company, drug_name, drug_generic) values ('Antigen Laboratories, Inc.', 'Mucor Mixture', 'Mucor Mixture');
insert into drug (drug_company, drug_name, drug_generic) values ('Hydrox Laboratories', 'Instant Hand Sanitizer Unscented', 'Alcohol');
insert into drug (drug_company, drug_name, drug_generic) values ('L. Perrigo Company', 'good sense aspirin', 'Aspirin');
insert into drug (drug_company, drug_name, drug_generic) values ('International Beauty Exchange', 'African Formula Skin Lightening', 'HYDROQUINONE');
insert into drug (drug_company, drug_name, drug_generic) values ('Home Sweet Homeopathics', 'Nagging Cough', 'Carbo Veg 30c, Cuprum Metalicum 30c, Mercurius Sol 30c, Phosphorous 30c, Pulsatilla 30c, Stannum Met 30c, Veratrum Album 30c');
insert into drug (drug_company, drug_name, drug_generic) values ('DOLGENCORP, LLC', 'Nasal Decongestant PE', 'Phenylephrine HCl');
insert into drug (drug_company, drug_name, drug_generic) values ('TYA Pharmaceuticals', 'Cephalexin', 'Cephalexin');
insert into drug (drug_company, drug_name, drug_generic) values ('Galloping Hill Surgical Corp. dba Allcare Medical', 'OXYGEN', 'OXYGEN');
insert into drug (drug_company, drug_name, drug_generic) values ('Physicians Total Care, Inc.', 'Citrate of Magnesium', 'Citrate of Magnesium');
insert into drug (drug_company, drug_name, drug_generic) values ('CVS Pharmacy', 'Pain Relief', 'Acetaminophen');
insert into drug (drug_company, drug_name, drug_generic) values ('Brookstone Pharmaceuticals, Inc.', 'Entre-S', 'Dextromethorphan Hydrobromide, Pseudoephedrine Hydrochloride and Chlorpheniramine Maleate');
insert into drug (drug_company, drug_name, drug_generic) values ('Amerisource Bergen', 'Acetaminophen', 'Acetaminophen');
insert into drug (drug_company, drug_name, drug_generic) values ('Aretsia Medical Supply', 'Oxygen', 'Oxygen');
insert into drug (drug_company, drug_name, drug_generic) values ('Teva Pharmaceuticals USA Inc', 'Cimetidine', 'Cimetidine');
insert into drug (drug_company, drug_name, drug_generic) values ('L''Oreal USA Products Inc', 'Kiehls Since 1851 Dermatologist Solutions', 'Avobenzone Homosalate Octisalate Octocrylene Oxybenzone');
insert into drug (drug_company, drug_name, drug_generic) values ('Physicians Total Care, Inc.', 'Aspirin', 'aspirin');
insert into drug (drug_company, drug_name, drug_generic) values ('Galderma Laboratories, L.P.', 'Vectical', 'calcitriol');
insert into drug (drug_company, drug_name, drug_generic) values ('CHANEL PARFUMS BEAUTE', 'VITALUMIERE', 'OCTINOXATE');
insert into drug (drug_company, drug_name, drug_generic) values ('Kimberly-Clark Corporation', 'KLEENEX Antimicrobial Skin Cleanser', 'Benzalkonium Chloride');
insert into drug (drug_company, drug_name, drug_generic) values ('Home Sweet Homeopathics', 'Severe Back Pain', 'Arsenicum 30c, Belladonna 30c, Bryonia 30c, Carbo Animalis 30c, Cinchona 30c, Cina 30c, Colocynthis 30c, Graphites 30c, Ignatia 30c, Lycopodium 30c, Nat Mur 30c, Nitricum Acidum 30c, Rhus Tox');
insert into drug (drug_company, drug_name, drug_generic) values ('Neutrogena Corporation', 'Neutrogena Triple Age Repair Moisturizer', 'Avobenzone, Homosalate, Octisalate, and Octocrylene');
insert into drug (drug_company, drug_name, drug_generic) values ('REMEDYREPACK INC.', 'Warfarin Sodium', 'Warfarin Sodium');
insert into drug (drug_company, drug_name, drug_generic) values ('Physicians Total Care, Inc.', 'Lorazepam', 'Lorazepam');
insert into drug (drug_company, drug_name, drug_generic) values ('McNEIL-PPC, Inc.', 'Tucks Internal Soothers', 'STARCH, CORN');
insert into drug (drug_company, drug_name, drug_generic) values ('LACLEDE, INC.', 'LUVENA FEMININE WIPES', 'Pramoxine Hydrochloride');
insert into drug (drug_company, drug_name, drug_generic) values ('Ionx Holdings d/b/a HelloLife Inc.', 'Goutinex', 'Actaea Spicata, Ammonium Phosphoricum, Belladonna, Colchicum Autumnale, Formicum Acidum, Fraxinus Excelsior, Ledum Palustre, Natrum Carbonicum, Nux Vomica, Phytolacca Decandra, Rhododendron Chrysanthum, Salicylicum Acidum, Urtica Urens');
insert into drug (drug_company, drug_name, drug_generic) values ('Nelco Laboratories, Inc.', 'Burr Oak', 'Burr Oak');
insert into drug (drug_company, drug_name, drug_generic) values ('Kroger Company', 'nighttime sleep aid', 'Diphenhydramine Hydrochloride');
insert into drug (drug_company, drug_name, drug_generic) values ('Nelco Laboratories, Inc.', 'Oregon Ash', 'Oregon Ash');
insert into drug (drug_company, drug_name, drug_generic) values ('BCM Cosmetique SAS', 'No7 Lift and Luminate Foundation Sunscreen Broad Spectrum SPF 15 Toffee', 'Octinoxate');
insert into drug (drug_company, drug_name, drug_generic) values ('SJ Creations, Inc.', 'Kiwi Strawberry Foaming Hand Wash', 'Triclosan');
insert into drug (drug_company, drug_name, drug_generic) values ('Qualitest Pharmaceuticals', 'Tri-Vit with Fluoride Drops', 'ascorbic acid and cholecalciferol and sodium fluoride and vitamin A palmitate');
insert into drug (drug_company, drug_name, drug_generic) values ('Morton Grove Pharmaceuticals, Inc.', 'Nystatin', 'Nystatin');
insert into drug (drug_company, drug_name, drug_generic) values ('Aphena Pharma Solutions - Tennessee, LLC', 'Carvedilol', 'Carvedilol');
insert into drug (drug_company, drug_name, drug_generic) values ('Par Pharmaceutical, Inc.', 'Propafenone Hydrochloride', 'propafenone hydrochloride');
insert into drug (drug_company, drug_name, drug_generic) values ('King Bio Inc.', 'Egotistical', 'Ferrum metallicum, Gratiola officinalis, Hamamelis virginiana, Helianthus annuus, Hottonia palustris, flos, Lachesis mutus, Lilium tigrinum, Lycopodium clavatum, Moschus, Palladium metallicum, Platinum metallicum, Staphysagria, Sulphur, Rhus toxicodendron, Veratrum album, Viola odorata');
insert into drug (drug_company, drug_name, drug_generic) values ('Vertical Pharmaceuticals, Inc.', 'Lorzone', 'chlorzoxazone');
insert into drug (drug_company, drug_name, drug_generic) values ('Procter & Gamble Manufacturing Company', 'Crest Complete Multi-Benefit', 'Sodium Fluoride');
insert into drug (drug_company, drug_name, drug_generic) values ('Chain Drug Marketing Association Inc.', 'Acetaminophen', 'Acetaminophen');
insert into drug (drug_company, drug_name, drug_generic) values ('Mylan Pharmaceuticals Inc.', 'Metoprolol Tartrate', 'metoprolol tartrate');
insert into drug (drug_company, drug_name, drug_generic) values ('Amneal Pharmaceuticals', 'Cetirizine Hydrochloride', 'Cetirizine');
insert into drug (drug_company, drug_name, drug_generic) values ('The Pharma Network LLC', 'Thermazene', 'Silver Sulfadiazine');
insert into customers (first_name, last_name, customer_ip) values ('Ellette', 'McCreedy', '243.226.20.240/22');
insert into customers (first_name, last_name, customer_ip) values ('Ardelle', 'Dripp', '96.194.248.91/24');
insert into customers (first_name, last_name, customer_ip) values ('Faber', 'Ellams', '3.56.48.9/29');
insert into customers (first_name, last_name, customer_ip) values ('Wolfie', 'Pacht', '234.205.149.115/28');
insert into customers (first_name, last_name, customer_ip) values ('Wells', 'Cristou', '143.182.240.159/18');
insert into customers (first_name, last_name, customer_ip) values ('Bennett', 'Purdon', '217.243.217.251/25');
insert into customers (first_name, last_name, customer_ip) values ('Percival', 'Astie', '212.37.59.200/18');
insert into customers (first_name, last_name, customer_ip) values ('Clarissa', 'Hearon', '183.138.47.68/25');
insert into customers (first_name, last_name, customer_ip) values ('Malanie', 'Jessup', '41.112.62.151/10');
insert into customers (first_name, last_name, customer_ip) values ('Darcey', 'Boatman', '2.244.159.70/8');
insert into customers (first_name, last_name, customer_ip) values ('Westleigh', 'Ochterlony', '106.133.220.99/4');
insert into customers (first_name, last_name, customer_ip) values ('Barbabra', 'Sherburn', '128.106.227.95/1');
insert into customers (first_name, last_name, customer_ip) values ('Berny', 'Risebrow', '149.159.132.209/13');
insert into customers (first_name, last_name, customer_ip) values ('Abie', 'Bramah', '141.169.244.121/3');
insert into customers (first_name, last_name, customer_ip) values ('Annabel', 'Shipley', '237.117.15.65/31');
insert into customers (first_name, last_name, customer_ip) values ('Marilin', 'Tarbox', '248.147.97.229/13');
insert into customers (first_name, last_name, customer_ip) values ('Mab', 'Candlish', '79.128.166.228/21');
insert into customers (first_name, last_name, customer_ip) values ('Ethan', 'Tiddy', '120.140.64.4/25');
insert into customers (first_name, last_name, customer_ip) values ('Chevy', 'Spendlove', '175.200.104.155/7');
insert into customers (first_name, last_name, customer_ip) values ('Fiona', 'Milligan', '247.67.55.190/31');
insert into customers (first_name, last_name, customer_ip) values ('Heindrick', 'Rhoddie', '97.231.149.32/7');
insert into customers (first_name, last_name, customer_ip) values ('Kippie', 'Grafton', '160.202.9.232/4');
insert into customers (first_name, last_name, customer_ip) values ('Itch', 'Corrin', '12.194.201.177/14');
insert into customers (first_name, last_name, customer_ip) values ('Chariot', 'Burnitt', '173.199.178.85/19');
insert into customers (first_name, last_name, customer_ip) values ('Hube', 'Shoosmith', '198.202.156.44/2');
insert into customers (first_name, last_name, customer_ip) values ('Fabien', 'Evill', '176.210.100.243/1');
insert into customers (first_name, last_name, customer_ip) values ('Lothaire', 'Somerled', '201.211.88.215/15');
insert into customers (first_name, last_name, customer_ip) values ('Burlie', 'Janks', '88.242.6.65/4');
insert into customers (first_name, last_name, customer_ip) values ('Inessa', 'Loadwick', '239.48.164.138/26');
insert into customers (first_name, last_name, customer_ip) values ('Isabeau', 'Delwater', '233.4.114.254/17');
insert into customers (first_name, last_name, customer_ip) values ('Blondy', 'Jasper', '208.133.196.133/4');
insert into customers (first_name, last_name, customer_ip) values ('Tedd', 'Guille', '213.49.137.16/17');
insert into customers (first_name, last_name, customer_ip) values ('Tiffie', 'Lacotte', '61.213.124.92/10');
insert into customers (first_name, last_name, customer_ip) values ('Darsey', 'Smalley', '188.178.131.4/21');
insert into customers (first_name, last_name, customer_ip) values ('Anna', 'Blount', '216.206.102.41/10');
insert into customers (first_name, last_name, customer_ip) values ('Elmore', 'Shenfish', '5.76.222.81/7');
insert into customers (first_name, last_name, customer_ip) values ('Ludwig', 'Alberts', '164.199.247.114/30');
insert into customers (first_name, last_name, customer_ip) values ('Yardley', 'Girkin', '14.242.118.169/20');
insert into customers (first_name, last_name, customer_ip) values ('Federico', 'Pedden', '121.84.101.247/30');
insert into customers (first_name, last_name, customer_ip) values ('Raymund', 'Taggerty', '192.23.197.62/31');
insert into customers (first_name, last_name, customer_ip) values ('Tamarra', 'Guillem', '209.173.33.80/10');
insert into customers (first_name, last_name, customer_ip) values ('Joana', 'Murby', '57.223.18.33/24');
insert into customers (first_name, last_name, customer_ip) values ('Chandal', 'Pesik', '233.190.159.253/23');
insert into customers (first_name, last_name, customer_ip) values ('Shelli', 'Mozzini', '31.0.217.30/9');
insert into customers (first_name, last_name, customer_ip) values ('Candra', 'Ciccarello', '98.58.112.150/26');
insert into customers (first_name, last_name, customer_ip) values ('Shaw', 'Adshede', '109.4.234.91/22');
insert into customers (first_name, last_name, customer_ip) values ('Cam', 'Houlahan', '171.85.24.171/28');
insert into customers (first_name, last_name, customer_ip) values ('Shalom', 'Wheater', '151.225.141.213/29');
insert into customers (first_name, last_name, customer_ip) values ('Brook', 'Issett', '196.188.169.115/17');
insert into customers (first_name, last_name, customer_ip) values ('Grissel', 'Norville', '64.132.248.50/8');
insert into customers (first_name, last_name, customer_ip) values ('Serena', 'Leon', '19.223.70.133/20');
insert into customers (first_name, last_name, customer_ip) values ('Patsy', 'Veillard', '129.217.241.194/8');
insert into customers (first_name, last_name, customer_ip) values ('Gweneth', 'Fellgatt', '27.30.180.237/8');
insert into customers (first_name, last_name, customer_ip) values ('Gretel', 'Botterill', '187.135.54.213/20');
insert into customers (first_name, last_name, customer_ip) values ('Heddie', 'Ffoulkes', '190.175.232.243/28');
insert into customers (first_name, last_name, customer_ip) values ('Lambert', 'Rothera', '255.52.76.138/1');
insert into customers (first_name, last_name, customer_ip) values ('Nicko', 'Paullin', '183.120.50.39/12');
insert into customers (first_name, last_name, customer_ip) values ('Gae', 'Kynder', '74.48.94.60/31');
insert into customers (first_name, last_name, customer_ip) values ('Sena', 'O'' Dooley', '185.41.150.199/2');
insert into customers (first_name, last_name, customer_ip) values ('Bernardine', 'Croley', '3.4.32.175/28');
insert into customers (first_name, last_name, customer_ip) values ('Tresa', 'Tungate', '184.167.26.21/8');
insert into customers (first_name, last_name, customer_ip) values ('Gene', 'Carlow', '18.109.243.62/18');
insert into customers (first_name, last_name, customer_ip) values ('Hilly', 'Tremmil', '108.106.225.222/23');
insert into customers (first_name, last_name, customer_ip) values ('Lynette', 'Batkin', '35.175.38.35/10');
insert into customers (first_name, last_name, customer_ip) values ('Denice', 'Simeonov', '73.220.32.129/2');
insert into customers (first_name, last_name, customer_ip) values ('Johanna', 'Moston', '218.177.57.97/17');
insert into customers (first_name, last_name, customer_ip) values ('Tally', 'Cuphus', '229.240.77.213/24');
insert into customers (first_name, last_name, customer_ip) values ('Trudy', 'Florey', '240.93.63.176/3');
insert into customers (first_name, last_name, customer_ip) values ('Logan', 'MacFadden', '208.224.136.33/27');
insert into customers (first_name, last_name, customer_ip) values ('Norah', 'Loftie', '69.191.39.97/8');
insert into customers (first_name, last_name, customer_ip) values ('Latashia', 'Gosnold', '213.13.0.5/20');
insert into customers (first_name, last_name, customer_ip) values ('Chico', 'Champkin', '174.151.230.201/3');
insert into customers (first_name, last_name, customer_ip) values ('Hyacinth', 'Ashmole', '175.60.50.104/30');
insert into customers (first_name, last_name, customer_ip) values ('Rosa', 'Wigley', '227.137.134.79/17');
insert into customers (first_name, last_name, customer_ip) values ('Chancey', 'Timblett', '87.60.178.196/6');
insert into customers (first_name, last_name, customer_ip) values ('Starr', 'Gentner', '40.183.122.247/1');
insert into customers (first_name, last_name, customer_ip) values ('Lainey', 'Stuther', '72.229.242.124/7');
insert into customers (first_name, last_name, customer_ip) values ('Alva', 'Burwin', '37.130.1.116/29');
insert into customers (first_name, last_name, customer_ip) values ('Fax', 'Pautot', '169.25.254.146/20');
insert into customers (first_name, last_name, customer_ip) values ('Anthiathia', 'Martill', '222.153.197.80/1');
insert into customers (first_name, last_name, customer_ip) values ('Kennett', 'Janeczek', '95.102.180.70/12');
insert into customers (first_name, last_name, customer_ip) values ('Ber', 'Troillet', '248.17.148.141/13');
insert into customers (first_name, last_name, customer_ip) values ('Claudelle', 'Stoneham', '164.15.212.111/25');
insert into customers (first_name, last_name, customer_ip) values ('Sallie', 'Lempertz', '237.124.222.187/7');
insert into customers (first_name, last_name, customer_ip) values ('Emmeline', 'Denis', '98.226.173.62/19');
insert into customers (first_name, last_name, customer_ip) values ('Inger', 'Whitby', '3.95.12.151/19');
insert into customers (first_name, last_name, customer_ip) values ('Curtis', 'Tudgay', '233.240.7.156/25');
insert into customers (first_name, last_name, customer_ip) values ('Lucine', 'Doswell', '31.48.209.233/1');
insert into customers (first_name, last_name, customer_ip) values ('Lizbeth', 'Hassan', '223.152.54.93/12');
insert into customers (first_name, last_name, customer_ip) values ('Ailyn', 'Jendrassik', '128.241.39.247/23');
insert into customers (first_name, last_name, customer_ip) values ('Beau', 'O''Dulchonta', '54.33.133.81/27');
insert into customers (first_name, last_name, customer_ip) values ('Jo', 'Krahl', '53.253.161.6/3');
insert into customers (first_name, last_name, customer_ip) values ('Payton', 'Sapp', '197.106.70.147/20');
insert into customers (first_name, last_name, customer_ip) values ('Tallia', 'Denley', '165.58.76.119/11');
insert into customers (first_name, last_name, customer_ip) values ('Rosabelle', 'Hillock', '113.244.242.36/8');
insert into customers (first_name, last_name, customer_ip) values ('Balduin', 'Buffin', '30.133.242.39/20');
insert into customers (first_name, last_name, customer_ip) values ('Ervin', 'Masser', '20.72.232.173/9');
insert into customers (first_name, last_name, customer_ip) values ('Ursula', 'Mc Dermid', '242.3.153.237/25');
insert into customers (first_name, last_name, customer_ip) values ('Ursuline', 'Corgenvin', '183.216.248.26/20');
insert into customers (first_name, last_name, customer_ip) values ('Frederik', 'Spellacey', '165.141.23.37/2');
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into buyer
select c.customer_ip, d.drug_company,d.drug_name
from customers c, drug d
order by random()
limit 1000;






