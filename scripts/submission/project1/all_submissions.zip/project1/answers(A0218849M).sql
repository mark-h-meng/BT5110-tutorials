/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* 
COVID-19 clusters had emerged in hundreds of small companies across Sydney in late July 2021. As Lyft, a private-hire driver 
platform, the task is to identify the private-hire drivers who had picked up passengers from the affected companies during 
a 2 week window in early August 2021 and to suspend the drivers' Lyft account as a precaution.
The 'driver' table contains the details of the affected Lyft's drivers in Sydney like name, gender, date of birth and 
employee-id.
The 'affected_companies' table contains the details of companies with active COVID-19 clusters. The table contain the 
company name, uen, the latitude and longitude coordinates of their office where the cluster is active, and the date where the
COVID-19 cluster was first identified.
The 'contact_tracing' table shows the employee-id of the drivers who had picked up passengers from the affected companies.

Code is written for PostgreSQL.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/*** Create schema ***/
DROP TABLE IF EXISTS contact_tracing;
DROP TABLE IF EXISTS driver;
DROP TABLE IF EXISTS affected_companies;


CREATE TABLE IF NOT EXISTS driver (
first_name VARCHAR(64) NOT NULL,
last_name VARCHAR(64) NOT NULL,
gender CHAR(1) NOT NULL CONSTRAINT gender CHECK(gender = 'M' OR gender='F'),
employee_id CHAR(10) PRIMARY KEY,
dob DATE NOT NULL
);	

CREATE TABLE IF NOT EXISTS affected_companies (
company VARCHAR(64) NOT NULL,
uen CHAR(11) PRIMARY KEY,
latitude CHAR(12) NOT NULL,
longitude CHAR(12) NOT NULL,
cluster_startdate DATE NOT NULL
);	


CREATE TABLE IF NOT EXISTS contact_tracing (
employee_id CHAR(10) REFERENCES driver(employee_id) ON UPDATE CASCADE ON DELETE CASCADE, 
uen CHAR(11) REFERENCES affected_companies(uen) ON UPDATE CASCADE ON DELETE CASCADE	
);


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO driver VALUES ('Octavia', 'Penhalurick', 'F', '89-7629059', '09/07/1987');
INSERT INTO driver VALUES ('Hildegaard', 'Bampford', 'F', '64-3373794', '26/01/1989');
INSERT INTO driver VALUES ('Barnett', 'McNirlan', 'M', '42-2827108', '12/07/1964');
INSERT INTO driver VALUES ('Isador', 'Caunter', 'M', '86-5951032', '18/04/1986');
INSERT INTO driver VALUES ('Morty', 'Kilmaster', 'M', '46-4067122', '27/06/1982');
INSERT INTO driver VALUES ('Maryjane', 'Ricarde', 'F', '02-4360076', '18/05/1983');
INSERT INTO driver VALUES ('Meriel', 'Winckles', 'F', '05-1323406', '02/05/1975');
INSERT INTO driver VALUES ('Robert', 'Leggis', 'M', '38-0429916', '29/09/1994');
INSERT INTO driver VALUES ('Ford', 'Boal', 'M', '26-7002896', '10/08/1991');
INSERT INTO driver VALUES ('Dore', 'Enston', 'M', '82-6465750', '11/12/1963');
INSERT INTO driver VALUES ('Karlyn', 'Magrane', 'F', '20-2807536', '06/12/1971');
INSERT INTO driver VALUES ('Udale', 'Vazquez', 'M', '23-0861861', '01/04/1998');
INSERT INTO driver VALUES ('Leola', 'Arrowsmith', 'F', '20-4225207', '23/12/1982');
INSERT INTO driver VALUES ('Paxon', 'Beare', 'M', '64-4767580', '15/10/1976');
INSERT INTO driver VALUES ('Rice', 'Cleyburn', 'M', '38-2981390', '18/11/1991');
INSERT INTO driver VALUES ('Tailor', 'Clows', 'M', '17-1069101', '29/06/1996');
INSERT INTO driver VALUES ('Pebrook', 'MacRierie', 'M', '61-4731179', '17/02/1984');
INSERT INTO driver VALUES ('Brennen', 'Ducaen', 'M', '00-2226511', '22/07/1998');
INSERT INTO driver VALUES ('Cybill', 'Payn', 'F', '22-5006824', '10/04/1976');
INSERT INTO driver VALUES ('Laural', 'Harragin', 'F', '80-8685498', '26/11/1985');
INSERT INTO driver VALUES ('Emanuele', 'Lumpkin', 'M', '13-6924090', '25/11/1970');
INSERT INTO driver VALUES ('Kellina', 'Adanet', 'F', '52-7801815', '20/05/1999');
INSERT INTO driver VALUES ('Jimmy', 'Bagniuk', 'M', '85-5736488', '28/06/1986');
INSERT INTO driver VALUES ('Linell', 'Futter', 'F', '17-2290343', '09/02/1977');
INSERT INTO driver VALUES ('Norina', 'Elflain', 'F', '49-1839092', '13/02/1982');
INSERT INTO driver VALUES ('Fulvia', 'Graalmans', 'F', '19-5626371', '03/08/1990');
INSERT INTO driver VALUES ('Crystal', 'Torvey', 'F', '67-9183149', '12/02/1967');
INSERT INTO driver VALUES ('Nilson', 'Goodbarne', 'M', '45-8951447', '22/08/1968');
INSERT INTO driver VALUES ('Etienne', 'Doeg', 'M', '26-2948493', '03/10/1972');
INSERT INTO driver VALUES ('Rosalia', 'Humby', 'F', '30-2943437', '03/07/1983');
INSERT INTO driver VALUES ('Trix', 'Bussell', 'F', '40-6810092', '20/06/1970');
INSERT INTO driver VALUES ('Daveen', 'Goring', 'F', '16-2324714', '25/12/1971');
INSERT INTO driver VALUES ('Guntar', 'Foucher', 'M', '26-3356883', '18/03/1996');
INSERT INTO driver VALUES ('Kayne', 'Cobson', 'M', '78-5828182', '01/02/1989');
INSERT INTO driver VALUES ('Wolfy', 'Forlonge', 'M', '62-2521281', '19/03/1989');
INSERT INTO driver VALUES ('Ugo', 'Piscopo', 'M', '67-5897257', '22/07/1978');
INSERT INTO driver VALUES ('Aveline', 'Hallihan', 'F', '36-7864728', '18/10/1994');
INSERT INTO driver VALUES ('Giulio', 'Grieveson', 'M', '57-9565033', '12/08/1977');
INSERT INTO driver VALUES ('Ryun', 'Penburton', 'M', '12-3401305', '28/05/1975');
INSERT INTO driver VALUES ('Elisha', 'Coil', 'M', '91-5875753', '06/07/1973');
INSERT INTO driver VALUES ('Alyson', 'Kiledal', 'F', '10-4859508', '27/05/1977');
INSERT INTO driver VALUES ('Tremayne', 'Baudone', 'M', '38-0232041', '02/04/1970');
INSERT INTO driver VALUES ('Gelya', 'Philbrook', 'F', '94-0220602', '02/12/1988');
INSERT INTO driver VALUES ('Elena', 'Buddles', 'F', '11-7857550', '21/04/1977');
INSERT INTO driver VALUES ('Peadar', 'Rubes', 'M', '86-2678611', '11/09/1975');
INSERT INTO driver VALUES ('Arlena', 'Cristoforetti', 'F', '67-5432091', '23/07/1990');
INSERT INTO driver VALUES ('Linus', 'Lesper', 'M', '23-8048620', '23/07/1961');
INSERT INTO driver VALUES ('Emelita', 'Bourhill', 'F', '06-3781767', '07/03/1968');
INSERT INTO driver VALUES ('Tove', 'Egdale', 'F', '52-9430833', '27/04/1990');
INSERT INTO driver VALUES ('Annette', 'Gawn', 'F', '29-1847821', '11/09/1996');
INSERT INTO driver VALUES ('Pammi', 'Skunes', 'F', '62-2040427', '19/09/1962');
INSERT INTO driver VALUES ('Carlyn', 'Petrak', 'F', '38-4294640', '10/02/1960');
INSERT INTO driver VALUES ('Case', 'Grinley', 'M', '59-5935635', '15/03/1993');
INSERT INTO driver VALUES ('Kerrill', 'Buffery', 'F', '24-4533730', '02/03/1983');
INSERT INTO driver VALUES ('Jacinthe', 'Keemar', 'F', '16-9680383', '05/01/1974');
INSERT INTO driver VALUES ('Lauritz', 'Geipel', 'M', '73-9372775', '23/07/1991');
INSERT INTO driver VALUES ('Holly-anne', 'Louche', 'F', '67-0101425', '20/09/1991');
INSERT INTO driver VALUES ('Karlotta', 'Hollebon', 'F', '09-5958691', '14/07/1972');
INSERT INTO driver VALUES ('Morley', 'Grishinov', 'M', '20-1009049', '25/12/1990');
INSERT INTO driver VALUES ('Dacy', 'Lowis', 'F', '33-6815519', '03/08/1993');
INSERT INTO driver VALUES ('Darrell', 'Wavish', 'M', '63-9535111', '18/08/1975');
INSERT INTO driver VALUES ('Ransom', 'Gerber', 'M', '69-0068637', '19/10/1992');
INSERT INTO driver VALUES ('Marya', 'Fenkel', 'F', '75-2604683', '08/03/1980');
INSERT INTO driver VALUES ('Michail', 'De Rechter', 'M', '23-9906178', '09/10/1970');
INSERT INTO driver VALUES ('Beth', 'Stenbridge', 'F', '01-3116290', '13/11/1996');
INSERT INTO driver VALUES ('Maggee', 'Povey', 'F', '03-6707139', '18/05/1971');
INSERT INTO driver VALUES ('Somerset', 'Johnsee', 'M', '48-2472785', '01/01/1992');
INSERT INTO driver VALUES ('Cecilla', 'Harradine', 'F', '53-7432293', '16/06/1977');
INSERT INTO driver VALUES ('Levy', 'Dabourne', 'M', '03-1653013', '29/03/1996');
INSERT INTO driver VALUES ('Bary', 'Collopy', 'M', '89-1885359', '08/03/1992');
INSERT INTO driver VALUES ('Alleen', 'Redon', 'F', '64-8371854', '30/01/1990');
INSERT INTO driver VALUES ('Xena', 'Reagan', 'F', '74-9602153', '06/07/1974');
INSERT INTO driver VALUES ('Becka', 'Sanbrooke', 'F', '04-9401780', '01/12/1964');
INSERT INTO driver VALUES ('Ericha', 'Adame', 'F', '37-3042897', '04/07/1961');
INSERT INTO driver VALUES ('Papageno', 'McKew', 'M', '56-8950886', '22/04/1974');
INSERT INTO driver VALUES ('Arlen', 'Rickardes', 'M', '04-8467363', '10/08/1991');
INSERT INTO driver VALUES ('Benn', 'Maling', 'M', '89-0395286', '22/12/1967');
INSERT INTO driver VALUES ('Muriel', 'Denney', 'F', '73-7109542', '07/03/1979');
INSERT INTO driver VALUES ('Nelia', 'Lambregts', 'F', '97-0945022', '12/12/1991');
INSERT INTO driver VALUES ('Alexandr', 'Vitler', 'M', '52-9092895', '25/06/1999');
INSERT INTO driver VALUES ('Harland', 'Veel', 'M', '98-6672672', '09/07/1986');
INSERT INTO driver VALUES ('Alfredo', 'Garnul', 'M', '24-2129293', '18/04/1996');
INSERT INTO driver VALUES ('Lucine', 'Lyard', 'F', '60-4354324', '15/09/1991');
INSERT INTO driver VALUES ('Johannes', 'Siely', 'M', '44-1868206', '20/11/1992');
INSERT INTO driver VALUES ('Ashton', 'Dallon', 'M', '35-2961454', '16/07/1960');
INSERT INTO driver VALUES ('Gordan', 'Oertzen', 'M', '50-2561673', '22/02/1996');
INSERT INTO driver VALUES ('Rory', 'Eacott', 'F', '00-6208580', '19/01/1991');
INSERT INTO driver VALUES ('Essy', 'Kennon', 'F', '05-0217768', '27/01/1976');
INSERT INTO driver VALUES ('Sunny', 'Dybald', 'F', '51-1139661', '23/09/1982');
INSERT INTO driver VALUES ('Pedro', 'Rake', 'M', '90-2667706', '29/11/1977');
INSERT INTO driver VALUES ('Prescott', 'Tinton', 'M', '44-6141840', '30/10/1972');
INSERT INTO driver VALUES ('Sheffie', 'Yurinov', 'M', '88-2472753', '01/06/1975');
INSERT INTO driver VALUES ('Lilas', 'Humble', 'F', '69-6779957', '13/04/1999');
INSERT INTO driver VALUES ('Demetri', 'Alenov', 'M', '75-0426568', '01/03/1974');
INSERT INTO driver VALUES ('Debor', 'Caws', 'F', '82-9705795', '11/11/1977');
INSERT INTO driver VALUES ('Audy', 'Chesswas', 'F', '76-8891380', '24/10/1996');
INSERT INTO driver VALUES ('Rosaline', 'Seamer', 'F', '13-3844165', '29/04/1986');
INSERT INTO driver VALUES ('Emera', 'Bubbear', 'F', '79-2700282', '19/10/1994');
INSERT INTO driver VALUES ('Cliff', 'Reboul', 'M', '63-5232071', '26/01/1996');
INSERT INTO driver VALUES ('Germana', 'Stickley', 'F', '30-8724059', '19/08/1988');
INSERT INTO driver VALUES ('Rhiamon', 'Sporgeon', 'F', '16-6882422', '28/08/1993');
INSERT INTO driver VALUES ('Lois', 'Tumility', 'F', '30-8007667', '26/09/1977');



INSERT INTO affected_companies VALUES ('Hoppe-Harris', '366-46-3199',-0.031303,110.120499, '07/08/2021');
INSERT INTO affected_companies VALUES ('Kutch and Sons', '100-56-5943',31.790235,34.759291, '06/08/2021');
INSERT INTO affected_companies VALUES ('Cole and Sons', '366-26-8931',38.7952662,-9.4665149, '07/08/2021');
INSERT INTO affected_companies VALUES ('Gorczany Inc', '475-64-2054',-24.7023134,-48.0076188, '06/08/2021');
INSERT INTO affected_companies VALUES ('Herzog-Ritchie', '799-40-1082',16.1091703,120.0885626, '10/08/2021');
INSERT INTO affected_companies VALUES ('Stroman-Lang', '367-49-3171',47.3774041,8.5113801, '07/08/2021');
INSERT INTO affected_companies VALUES ('Friesen-Swift', '318-50-9082',46.7530428,-71.2196569, '06/08/2021');
INSERT INTO affected_companies VALUES ('Frami LLC', '561-27-7864',60.0410708,18.6130609, '11/08/2021');
INSERT INTO affected_companies VALUES ('Goyette-Dooley', '515-88-3224',24.937517,114.455815, '10/08/2021');
INSERT INTO affected_companies VALUES ('Jacobs-Gaylord', '495-16-3545',49.9466816,18.8244645, '07/08/2021');
INSERT INTO affected_companies VALUES ('Donnelly and Sons', '340-19-0473',14.637422,-91.141982, '09/08/2021');
INSERT INTO affected_companies VALUES ('Bosco-O''Keefe', '135-60-2547',27.456658,112.175245, '08/08/2021');
INSERT INTO affected_companies VALUES ('Bergnaum Group', '551-67-1957',44.7739151,34.5968895, '09/08/2021');
INSERT INTO affected_companies VALUES ('Russel-Larkin', '851-33-5467',12.9953534,15.7321831, '06/08/2021');
INSERT INTO affected_companies VALUES ('Hintz Inc', '156-20-8139',40.4655049,-8.7183737, '10/08/2021');
INSERT INTO affected_companies VALUES ('Cole-Hand', '540-73-3624',14.1060399,101.3470213, '10/08/2021');
INSERT INTO affected_companies VALUES ('Mraz-Marquardt', '414-37-2946',15.2401348,120.857473, '09/08/2021');
INSERT INTO affected_companies VALUES ('Feil-Bogisich', '536-61-4511',13.2606549,123.3710571, '11/08/2021');
INSERT INTO affected_companies VALUES ('Schmitt and Sons', '277-23-6998',4.024168,-67.683823, '06/08/2021');
INSERT INTO affected_companies VALUES ('Crooks Inc', '648-28-6620',-6.8783,106.3166, '07/08/2021');
INSERT INTO affected_companies VALUES ('Prosacco-Marks', '350-96-6541',50.4333399,16.2304168, '06/08/2021');
INSERT INTO affected_companies VALUES ('Reichert-Beahan', '787-56-7197',31.779618,119.974991, '08/08/2021');
INSERT INTO affected_companies VALUES ('Armstrong-Emard', '450-57-9518',-4.0308713,-44.4654609, '11/08/2021');
INSERT INTO affected_companies VALUES ('Ritchie-Lebsack', '748-66-0949',18.4895862,-69.8639751, '06/08/2021');
INSERT INTO affected_companies VALUES ('Langworth-Runte', '611-12-3903',51.7567459,22.7817467, '09/08/2021');
INSERT INTO affected_companies VALUES ('Schowalter-Macejkovic', '434-44-3875',7.0762776,122.2124068, '11/08/2021');
INSERT INTO affected_companies VALUES ('Shanahan-Bednar', '285-20-1522',11.4222249,122.055373, '09/08/2021');
INSERT INTO affected_companies VALUES ('Mann-Bogisich', '585-35-2584',45.4560254,9.1257661, '09/08/2021');
INSERT INTO affected_companies VALUES ('Friesen Inc', '583-09-3310',30.948905,108.574058, '07/08/2021');
INSERT INTO affected_companies VALUES ('Windler-Hilpert', '253-46-4205',19.9059121,105.4771084, '11/08/2021');
INSERT INTO affected_companies VALUES ('Bechtelar-Hermann', '498-76-0655',35.5334785,135.2486671, '10/08/2021');
INSERT INTO affected_companies VALUES ('O''Connell-West', '360-85-8333',13.9047039,-61.0667869, '08/08/2021');
INSERT INTO affected_companies VALUES ('Block-Spencer', '572-68-8324',15.8785099,120.3186429, '08/08/2021');
INSERT INTO affected_companies VALUES ('Sauer and Sons', '157-01-3299',13.1984059,-88.0534236, '11/08/2021');
INSERT INTO affected_companies VALUES ('Rice and Sons', '341-49-2498',14.6355044,121.016279, '07/08/2021');
INSERT INTO affected_companies VALUES ('Bergnaum-Rodriguez', '238-96-6239',38.7087189,-9.2280364, '06/08/2021');
INSERT INTO affected_companies VALUES ('Mosciski Group', '808-17-6393',14.7536759,-92.0269227, '11/08/2021');
INSERT INTO affected_companies VALUES ('Torp LLC', '437-98-8976',57.3299614,61.9066841, '07/08/2021');
INSERT INTO affected_companies VALUES ('Hodkiewicz-Schmidt', '200-41-9075',37.3716902,-7.5934261, '09/08/2021');
INSERT INTO affected_companies VALUES ('Balistreri Inc', '504-49-9020',38.520089,102.188043, '10/08/2021');
INSERT INTO affected_companies VALUES ('Graham-Morissette', '800-47-3622',38.2020764,140.0905156, '07/08/2021');
INSERT INTO affected_companies VALUES ('Kirlin Inc', '105-26-6087',50.99206,121.05843, '08/08/2021');
INSERT INTO affected_companies VALUES ('Watsica Group', '464-32-7864',-22.602558,-43.9055155, '11/08/2021');
INSERT INTO affected_companies VALUES ('Senger-Cummerata', '641-14-1576',31.0978583,77.2678137, '10/08/2021');
INSERT INTO affected_companies VALUES ('Skiles-Sauer', '758-58-5674',47.3591366,2.8002946, '08/08/2021');
INSERT INTO affected_companies VALUES ('Lehner Group', '610-50-6008',8.047281,-69.3339418, '06/08/2021');
INSERT INTO affected_companies VALUES ('Fadel LLC', '639-50-6995',46.6313635,38.6705832, '06/08/2021');
INSERT INTO affected_companies VALUES ('Morissette-Beahan', '877-86-8831',25.1276033,121.7391833, '09/08/2021');
INSERT INTO affected_companies VALUES ('Emmerich-Nikolaus', '433-98-0134',56.1114024,94.571633, '10/08/2021');
INSERT INTO affected_companies VALUES ('Gusikowski-Gulgowski', '595-57-8194',41.8822489,-87.7221872, '10/08/2021');
INSERT INTO affected_companies VALUES ('Kemmer and Sons', '531-15-0232',39.4643574,21.6928339, '11/08/2021');
INSERT INTO affected_companies VALUES ('Powlowski-Braun', '276-10-2753',48.9933836,16.6802413, '11/08/2021');
INSERT INTO affected_companies VALUES ('Fahey-Gaylord', '488-13-8578',41.1245616,-7.9287227, '11/08/2021');
INSERT INTO affected_companies VALUES ('Bradtke-Borer', '898-58-5759',26.1656051,50.5523828, '11/08/2021');
INSERT INTO affected_companies VALUES ('Stiedemann-Balistreri', '374-99-6279',59.2669111,17.8885705, '08/08/2021');
INSERT INTO affected_companies VALUES ('Mosciski-Lowe', '331-08-9431',-8.3893,115.2605, '10/08/2021');
INSERT INTO affected_companies VALUES ('Jones-Satterfield', '409-95-2455',18.5382815,-72.5293562, '06/08/2021');
INSERT INTO affected_companies VALUES ('Hane-Fisher', '890-86-4865',57.7051896,11.9006932, '06/08/2021');
INSERT INTO affected_companies VALUES ('Goldner Inc', '571-42-1651',34.0506434,109.3781809, '11/08/2021');
INSERT INTO affected_companies VALUES ('Ankunding Group', '613-13-0372',32.7925057,-116.93933, '10/08/2021');
INSERT INTO affected_companies VALUES ('Skiles Group', '659-11-6858',35.8886106,140.0636977, '07/08/2021');
INSERT INTO affected_companies VALUES ('Abshire-Marvin', '326-70-7592',-2.6896767,141.2998457, '10/08/2021');
INSERT INTO affected_companies VALUES ('Schneider-Towne', '165-67-6691',24.364134,114.562955, '11/08/2021');
INSERT INTO affected_companies VALUES ('Rowe Inc', '720-55-8969',7.37823,-72.6503369, '08/08/2021');
INSERT INTO affected_companies VALUES ('Lehner and Sons', '121-34-5979',28.821772,90.047034, '08/08/2021');
INSERT INTO affected_companies VALUES ('Aufderhar-Kirlin', '351-63-9562',30.238152,118.148217, '10/08/2021');
INSERT INTO affected_companies VALUES ('Hermann-Gleichner', '139-17-4816',3.1377116,-76.5929658, '08/08/2021');
INSERT INTO affected_companies VALUES ('Lynch Inc', '312-64-2033',29.972084,106.27613, '09/08/2021');
INSERT INTO affected_companies VALUES ('Hand-Hilll', '425-21-5530',11.9781075,18.2110626, '10/08/2021');
INSERT INTO affected_companies VALUES ('Veum LLC', '894-48-7957',48.66667,116.83333, '07/08/2021');
INSERT INTO affected_companies VALUES ('Witting and Sons', '341-63-1931',52.2163528,61.2809373, '08/08/2021');
INSERT INTO affected_companies VALUES ('Williamson-Satterfield', '247-31-1737',-3.3200228,114.9991464, '06/08/2021');
INSERT INTO affected_companies VALUES ('Ebert Inc', '238-71-0077',36.74,-119.8, '06/08/2021');
INSERT INTO affected_companies VALUES ('Kshlerin-Carter', '396-24-0574',17.7127202,121.4424473, '10/08/2021');
INSERT INTO affected_companies VALUES ('Koss-Crist', '576-72-9961',3.1140502,43.651925, '08/08/2021');
INSERT INTO affected_companies VALUES ('Stehr LLC', '482-97-2234',-8.2017686,113.5936818, '06/08/2021');
INSERT INTO affected_companies VALUES ('Goodwin-Fay', '356-98-1596',44.000497,89.180437, '06/08/2021');
INSERT INTO affected_companies VALUES ('Grady-Feest', '173-64-6903',52.6889085,15.0706674, '11/08/2021');
INSERT INTO affected_companies VALUES ('Funk Inc', '583-99-0696',13.7946714,5.2527741, '08/08/2021');
INSERT INTO affected_companies VALUES ('Champlin-Reynolds', '522-02-5435',-8.1264039,111.7018452, '11/08/2021');
INSERT INTO affected_companies VALUES ('Herzog-Mosciski', '460-39-0234',5.1227373,9.9520961, '09/08/2021');
INSERT INTO affected_companies VALUES ('Koch Inc', '315-38-9494',-8.1264039,111.7018452, '07/08/2021');
INSERT INTO affected_companies VALUES ('Parisian and Sons', '623-44-3246',35.761829,115.029215, '09/08/2021');
INSERT INTO affected_companies VALUES ('Corwin and Sons', '440-82-2569',59.943312,30.3512378, '06/08/2021');
INSERT INTO affected_companies VALUES ('Krajcik LLC', '275-90-9782',-6.5096059,108.4543113, '08/08/2021');
INSERT INTO affected_companies VALUES ('Hauck-Langworth', '367-15-8333',-7.0587981,108.6620986, '11/08/2021');
INSERT INTO affected_companies VALUES ('Windler and Sons', '891-58-9602',-9.916667,-75.783333, '11/08/2021');
INSERT INTO affected_companies VALUES ('Beier-Hermiston', '201-35-3226',41.7429283,-87.7123355, '09/08/2021');
INSERT INTO affected_companies VALUES ('Swift Inc', '501-90-8103',7.8231145,6.0732146, '06/08/2021');
INSERT INTO affected_companies VALUES ('Crooks Inc', '346-05-8554',49.2815819,-122.7535881, '06/08/2021');
INSERT INTO affected_companies VALUES ('Schneider Inc', '756-57-9204',-15.24014,-69.527634, '10/08/2021');
INSERT INTO affected_companies VALUES ('McLaughlin LLC', '767-28-3225',-43.6151881,172.2990584, '08/08/2021');
INSERT INTO affected_companies VALUES ('Stark Group', '795-04-8202',29.16113,112.683016, '08/08/2021');
INSERT INTO affected_companies VALUES ('Hermann-Kuhlman', '726-94-8275',-21.1041295,55.2484176, '09/08/2021');
INSERT INTO affected_companies VALUES ('Wolff Inc', '755-68-3002',-17.8546259,-40.3322956, '06/08/2021');
INSERT INTO affected_companies VALUES ('Strosin LLC', '536-44-8015',22.9702067,-82.3858672, '08/08/2021');
INSERT INTO affected_companies VALUES ('Rutherford LLC', '531-14-4561',53.0155306,21.3375451, '09/08/2021');
INSERT INTO affected_companies VALUES ('Wehner and Sons', '241-58-1683',-8.4589273,118.5155901, '09/08/2021');
INSERT INTO affected_companies VALUES ('Ritchie-Ryan', '368-12-0851',10.103645,123.6419711, '08/08/2021');
INSERT INTO affected_companies VALUES ('Jacobson-Abshire', '771-80-8449',14.514787,-87.3996765, '06/08/2021');
INSERT INTO affected_companies VALUES ('Denesik-Schmeler', '791-08-9469',15.6941944,121.1004925, '06/08/2021');
INSERT INTO affected_companies VALUES ('Treutel-Johnson', '888-91-7369',14.8751623,-86.1828047, '11/08/2021');





/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO contact_tracing (employee_id, uen)
SELECT driver.employee_id, affected_companies.uen FROM driver CROSS JOIN affected_companies
ORDER BY
RANDOM()
LIMIT 1000;

