/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*  KANG Yifan  A0231994W                                                                    */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*In this case, university students are choosing sessions of modules 
for the new semester. So here we get “student” and “modulesession” 
 with the relationship of “moduleselection”.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE student(
	studentid VARCHAR(32) PRIMARY KEY,
	stufirstname VARCHAR(32),
	stulastname VARCHAR(32),
	major VARCHAR(32)
);

CREATE TABLE modulesession(
	modulename VARCHAR(64) UNIQUE,
	belongeddepartment VARCHAR(64),
	sessionid VARCHAR(32),
	PRIMARY KEY(belongeddepartment, sessionid),
	proffirstname VARCHAR(32),
	proflastname VARCHAR(32),
	profemail VARCHAR(64) UNIQUE
);

CREATE TABLE moduleselection(
	studentid VARCHAR(32) REFERENCES student(studentid)
		ON UPDATE CASCADE
		ON DELETE CASCADE,
	belongeddepartment VARCHAR(64),
	sessionid VARCHAR(32),
	PRIMARY KEY (studentid,belongeddepartment,sessionid),
	FOREIGN KEY(belongeddepartment, sessionid) REFERENCES modulesession(belongeddepartment, sessionid)
		ON UPDATE CASCADE
		ON DELETE CASCADE
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

COPY student(studentid,stufirstname,stulastname,major) 
FROM '/Users/abby/Desktop/StudentInfo.csv' 
DELIMITER ',';

COPY modulesession(modulename,belongeddepartment,sessionid,
				   proffirstname,proflastname,profemail) 
FROM '/Users/abby/Desktop/ModulesessionInfo.csv' 
DELIMITER ',';


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO moduleselection SELECT studentid,belongeddepartment,sessionid
FROM student, modulesession ORDER BY RANDOM() LIMIT 100 ;
