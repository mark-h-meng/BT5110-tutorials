/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/*  The code is written for PostgreSQL  */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The FBI has recently managed to monitor the action of some bitcoin accounts which
are suspected to be owned by drug dealers.

The 'Bitcoin Addresses' table contains those in total 108 suspicious bitcoin accounts
and their usernames, their MAC addresses and also IP addresses lately used. The 'Location'
table contains the city names and street numbers where those accounts used to be active.

The relationship table 'Transactions' records which account address used to make transaction
in which city and on which street. 

The fowllowing code is written for PostgreSQL.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS bitcoin_addresses(
bitcoin_address VARCHAR(64) PRIMARY KEY,
device VARCHAR(32) UNIQUE NOT NULL,
last_ip VARCHAR(32) NOT NULL,
bitcoin_username VARCHAR(32) NOT NULL);

CREATE TABLE IF NOT EXISTS locations(
city VARCHAR(32) UNIQUE NOT NULL,
street_number VARCHAR(32) NOT NULL,
PRIMARY KEY(city, street_number));

CREATE TABLE IF NOT EXISTS transactions(
bitcoin_address VARCHAR(64) REFERENCES bitcoin_addresses(bitcoin_address) 
	ON UPDATE CASCADE ON DELETE CASCADE
	DEFERRABLE INITIALLY DEFERRED,
city VARCHAR(32),
street_number VARCHAR(32),
PRIMARY KEY (bitcoin_address, city, street_number),
FOREIGN KEY (city, street_number) REFERENCES locations(city, street_number));

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1Ld1F4ws2FFgUQgm5LhsSQgBTBMEvCjcdP', '10-11-5A-A5-9C-C8', '239.113.223.158', 'tavory0');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1g9Gnh1rYMZnVFktXgkF8sbWDZogxC46h', '60-17-18-63-8F-AA', '241.255.178.85', 'rdixey1');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1CCfiEGSwXyjWdMwC2X5i9zP8axFGpkpJA', '8D-24-E3-17-A7-28', '217.232.83.116', 'iannes2');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('139opSVmjtEZ8mSFLz8Q7ePLPAW6dzMt5n', '7D-74-89-8D-C6-72', '183.121.200.162', 'kbenedite3');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('17owwvEwcRKtpyhZE9xr8AuGTmTsTgbesH', 'F1-7B-F6-7C-B0-A0', '78.29.33.96', 'smaharg4');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('19FGaaUfv9LwWk8xdTYJhDeSd8wVfPNHrs', '98-FD-C9-F8-3F-39', '66.157.220.28', 'alehrle5');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1MbPJgj8nzjL5zkcJKRrkGy5eXX8j3Xv4N', 'A3-BE-A4-3A-E6-18', '170.75.112.56', 'chuddles6');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1D39zvHfRwmkvbMsP8G2DtgSaESdaEj9xp', 'A6-D6-23-65-CA-97', '233.192.223.86', 'wbawdon7');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('17tFM4irYwafuezUE5CZAirXssybn83uPF', 'B5-0C-72-42-54-76', '173.69.175.156', 'iabrahm8');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1NdaYAU5o8dbsmWcpNRAAqkEfyeuEfC4Ft', '8F-11-8E-36-A7-9D', '75.0.145.146', 'rcollyns9');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1PSWYCg4B3uvc2HLe9miC6pFEamfx5wCV1', 'B1-C6-87-0D-D7-BC', '227.152.26.198', 'wficka');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1HAJFrCcPyRaT4gJLBxwyvF4Nwxvy3pEw', 'ED-87-A1-55-10-35', '46.23.236.140', 'ahafnerb');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1FveMQW1pT9eamVbBCDd9XkGWBqz5zYnqm', '13-2A-9D-CA-1B-15', '46.127.63.140', 'nmasoc');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('17UwLjbwZAjkuNJqyKTvP1wYyUqm7DbKm8', '42-BF-50-86-F9-ED', '196.38.154.173', 'omarlerd');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1F3sE6PWehPJyFjUCLrnaphLYe3Q3cwFmZ', 'EC-41-A4-20-C5-C0', '212.26.118.117', 'khindese');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1LZeem32bEFWjFWzWpaEMd4187rcrvxETr', 'DA-F7-C6-FA-CF-C7', '95.143.11.40', 'pspradef');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1Hu3mRG6PWRJCjVqj16x7Lf7NfD3H82WHD', '0A-82-BB-8B-46-B9', '73.182.212.47', 'agebbyg');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1Q5gQ2rmBoTRxMtizLU8JQgbamGxp5cbUs', 'B6-17-B7-EF-1B-DB', '161.165.178.203', 'kmaccartairh');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1Ea4VcdtGXKhTa25mNkRxscsqdsfzJNzba', '8C-E5-81-9A-4E-2F', '1.58.180.229', 'jmunkleyi');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1MnXTw6D9nwYVjfwGHX11w17G3FdF6EUL1', '51-0E-A1-79-F2-77', '73.40.234.83', 'vkenneyj');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1LaM4Mnb1UeV5pfpUjMGawMgVWXWYxh8yz', 'D1-30-F8-3D-73-3B', '98.177.182.171', 'abournek');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1BsccGYTzmavecuLUmD7xShf5EMje37fuc', 'A2-2A-8E-C4-C2-EA', '207.161.36.222', 'wgeaterl');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1PX7HboayBKHrjmo5QHpXu9pRRsdRRFHXn', '2B-33-32-DB-CE-D7', '162.108.125.23', 'ecrasswellerm');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1PsNftNssgVwYQTRDoNz85o4RcnpKVs9Jv', '75-1E-2B-8B-4F-F3', '107.108.42.172', 'asemainen');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1Ccrs8nn8AcHmPPTP2ef6TTsf4PJak8zXc', '2C-2A-E5-19-31-3C', '212.14.98.59', 'lmacterrellyo');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('168Zcdgg9Gq99QS81q4svrNCCW4djMSiMZ', '3E-69-AB-CE-E2-C6', '44.46.255.242', 'rbigadikep');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1Cw6BQvt5JgmH6zESyBHSufdbxAvZzV85D', '3B-6E-40-5E-4F-AF', '175.208.43.129', 'xbairdq');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('15ets9KKpWmujuh2spCbwRJVy7re4eSEAj', 'BA-B4-7F-B3-79-2F', '219.207.157.98', 'lknudsenr');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1LC4Mp3QYxA8ZveKvK7WMCFtGsLoDvenyT', '38-7D-43-D6-F2-62', '102.178.30.49', 'lhakeworths');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('15Q3vj8wYkD2ZP6egAyV3Uw27GdAcp2hv2', '9E-A6-8D-8E-9A-3F', '158.184.158.168', 'abenleyt');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('171TrLjmPoXkjK39noj3TyNY2QioQCebZ2', '90-2D-E5-C8-12-BB', '224.156.240.51', 'kshearsbyu');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('12gfHsWGtKcLW5nbELxy93TJGZgJA6Rn5G', 'EC-D6-C1-7B-30-31', '8.234.159.190', 'tbadderv');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1HPpCdT8bwMj24BhBnRPoRUPmCLdtny2hH', '10-A5-7D-01-E5-DA', '180.87.5.146', 'jmcmurrughw');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('13udjCKPr93vaETHvWdkAgGpMT3dRBxN4P', '68-9F-15-C1-A6-0C', '140.214.199.144', 'hdrysdellx');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1NHonBcAa9MxZPr9HEWt5iPg2BG5CdGKGV', 'CC-CE-E7-84-AD-3F', '132.74.13.33', 'ctysony');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('13scHyKpv734JkK96JETwCgiGMD1MCWG2Q', 'EE-2D-81-46-17-79', '81.87.144.35', 'rvanleeuwenz');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1GpaSxnahHjkcA413KkZ9ogFyH99c9RvSc', '1A-8A-42-0E-05-BF', '2.16.80.155', 'ksheryne10');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1K1D6dm2HHd8uMLLoLT9BjE19ydboVQC9w', 'B3-73-60-B5-E6-76', '63.167.182.30', 'gbourget11');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1DteSyBdsXSxyC1U4GtgyJEYZeBSKjbLji', 'A0-16-30-AC-2A-EA', '14.185.190.114', 'gtarplee12');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1BXunRrmJMThnRQzZgpNZ5XVModovwLRi9', '71-76-2F-71-DB-79', '188.15.225.192', 'awestmancoat13');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('12LttF2tLwnJiMPQ92WeYW4mYZMRfDVFcz', '8C-0C-F8-B8-F8-F4', '225.111.231.101', 'rhatwells14');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('198f3PFQn2AqxcGyc6XmZGdqjTgHnW8B9m', '04-02-BF-C7-00-BD', '28.100.246.71', 'aattack15');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('12gZMR64dphSmJ8AQ36i7UHACtS5VAXYUU', '57-CD-7E-CA-59-46', '74.243.200.57', 'ctowell16');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1CWyg1TFAMqZ8Ne2bShxdULibTv2x964EQ', 'B3-E7-4B-46-CB-99', '20.118.89.21', 'cbrymham17');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1LZvoipKAookw8dx2KUL3zMD9F36qfaByb', 'CF-74-C5-17-90-8D', '204.196.157.54', 'dragless18');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1BoaGQffj74kfzGvDq78cCUwAsHZ64Yioq', '3A-EF-10-18-F0-BD', '154.79.239.211', 'apietrasik19');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1B2T6vNgivpscKkHuWwEp4jtevikckmFB6', '49-B2-6B-BF-EA-C5', '132.126.87.188', 'gfolcarelli1a');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1BebNPgxjF8MoJvhCkYRub9mkfFDj3adqz', 'C3-97-F9-C4-0B-AF', '86.220.166.153', 'pbraddick1b');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1ALbAPupMohK9PBpCXFANa8PtbJPdDc4ki', 'E1-3E-3C-04-63-6A', '58.142.237.202', 'adurtnall1c');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('194qMPBHdtKEtqekmGSQBVwmUdzXZv5EkU', 'C8-9D-91-24-A7-5E', '252.131.56.45', 'csmedley1d');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('15WXgfbXZfJ8bfdah2AFuBJkB4xMsgjNNE', '2A-D5-0D-E0-8C-D1', '60.158.87.227', 'pkiernan1e');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1EwQHMvP5GBwpz4N1zYuPQ8BiS3XMYTfkE', '83-3E-E1-4C-DE-3D', '105.185.250.155', 'awarne1f');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1LwKsSWwDpA1yqKKJ1AUzsWraMU2dX4aQM', 'FF-15-87-32-87-87', '71.43.242.26', 'pyukhnin1g');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1PVkvbbL2UMGhZzhKguLkJzt3bPrNQNWYa', 'D5-6C-81-E8-E1-D4', '161.88.131.26', 'hteasell1h');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('12aLcaqkTESNTxo6G5Grn5ATyB8QkG3619', '0F-D5-E6-80-67-27', '52.180.9.114', 'tswitsur1i');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('18fES4UGEXw4xnvDTo478uZmNFHYb6qwYB', '0B-71-CF-B0-48-F0', '37.204.219.254', 'vmacclinton1j');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('17SaikW9zq9nToEXXwdiV1A9ZpZQR87THr', '6E-CD-22-A7-24-47', '5.208.78.61', 'aohollegan1k');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('16HRd59wWQG2xiPu5nqBxR95RMNnv2c6zc', '5C-87-40-7C-8D-1E', '182.145.114.76', 'nrodbourne1l');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1PV9CYYE7yAEQ7g5ukrbJz2bxspm1k76Xw', 'CF-2F-4C-A1-2E-39', '7.25.149.213', 'cizen1m');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('15pNWSYzi43nJmnKPRjJFSeQgUUdPvhvrn', '73-58-BB-25-74-48', '127.151.205.210', 'cbruhn1n');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1FYgoXY6H7wddhTustrpUJDghrZTzWkoN4', 'F2-95-64-FC-B5-35', '175.157.102.102', 'rzannini1o');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('18ZfkiMauc3JxX9AJZredneceb4kajVtdN', 'A6-7B-32-E4-7D-BE', '94.194.222.47', 'bgodden1p');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('17V2A59N448vbc1Z4vu7e7r7o4KVtM4eqT', 'DC-AA-EF-02-31-EE', '31.172.249.236', 'cparkhouse1q');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1LwCkwahVRoobJ5iLoxZgjtDm5w11wBcWY', '59-18-0A-02-2E-A5', '145.5.5.43', 'pdreini1r');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('17PXq8p1BGidkgEj3VKK8sjSmkt1PAHE82', '29-A2-23-02-49-65', '111.123.232.40', 'lflukes1s');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1LoueTSq5rdFCDhCJZxYSezEtyjtzjD96R', '6E-A9-6F-8B-BA-CC', '189.197.226.90', 'scruft1t');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1LqmYnZANkT3hMrGgHd5Rta6u6KQHyy5jb', 'F2-0D-C2-FB-BB-7E', '154.178.97.18', 'pedgington1u');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1CLBgjxEmQeK1bZqeXDbEZ6zfJw3QDsghJ', '5F-DE-F1-C2-4A-A0', '224.234.224.30', 'galton1v');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1GPwitzc2rWSFRDkTzpZXo9wbPSTsbLuGG', '8F-5B-E5-10-EC-C3', '64.165.198.17', 'kdivver1w');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1Pq6wfuDpiKbETsJbMpiaNW3jpshjDnoLf', '5E-77-7E-E6-CD-33', '91.218.203.14', 'rnorcliff1x');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('15NQPr6Yu8EnkGsEwgVffBXgZ5QP33Ph4H', '87-33-3A-7F-D9-B0', '73.143.228.23', 'dlillegard1y');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('19YF9deWdR48E22Ar6haAqtnZxq4snQ3YG', 'FD-DB-20-9F-EA-08', '26.39.235.189', 'dborges1z');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1998wpgQWWfXJyXMcUVwrWJhRZyRdQXp1q', '9C-4F-5D-44-89-A3', '129.127.27.128', 'callans20');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('18YDyzki1ctpnAuDMKzc2js9yrM1MpFNTN', '56-68-4B-E7-20-DB', '75.250.127.100', 'kclowsley21');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('17AfcXVgjFiUQnjtcmQQWFCSKNg4RTy76w', '71-3F-19-7D-96-F2', '38.167.176.70', 'dpitney22');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1BDsE7Z2WztzrWkKt2ZGa5B7sBDvBD2Us9', '56-5A-7F-41-07-F9', '85.129.106.243', 'melvy23');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('18WySUM9TpBcFbEihJoQswarujFLFnS1Kr', '37-6F-6A-CD-FF-AD', '78.218.105.4', 'dspoole24');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1KoSG6yL9oX9TCdxW6siwbmE5EMSm68zXp', 'A2-27-3C-B8-E9-DA', '238.214.175.43', 'dpohling25');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1L3tzTmqim6doGxH9iKaDAgwDwzrRd8Pz5', '76-0C-47-26-77-6B', '247.221.130.180', 'espring26');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1PQSinmnZqx6vMbgnrv11X1zJx3wtjGX1S', 'EB-08-73-FD-B0-9C', '204.46.39.48', 'lfynn27');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('18WPWpQh3huKN5f3VerdrP9wn8RTKEKrVD', '82-2A-71-3F-4F-38', '87.248.44.60', 'gstell28');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1C8iBF6eTLZYm8PpBPyzeAzTmtVCzzCws4', 'F1-17-EC-10-E7-8B', '50.221.112.202', 'kschwanden29');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1KpNGyC3abPC2te8tbPm8mHSPHzjCTr3VH', '1C-B1-07-A0-8F-1C', '62.120.189.33', 'sham2a');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1BW5WH5Tx5etutKqVws8DrERSWPrLrRPdh', '42-78-04-C8-1C-17', '50.175.158.98', 'mlambis2b');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1NA2p6M9RYmNX9EFFHFUQEWfmMJrmLUpqq', '46-27-D2-02-BF-39', '212.212.111.120', 'tdeely2c');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1JxNooDorJTA4xHuJ3pcEeBy1peMiXk7gT', '02-BE-01-8D-83-A1', '38.82.89.221', 'shaton2d');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1N5jaa9VXPfBBnRDwqzUgzUdL8Lhc1DYHG', '6B-65-A3-83-E7-4C', '102.186.225.233', 'hbottjer2e');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1Q8eXHzEWZ4hE3oYykGNsCfHUxeWy6QaVk', '25-4A-BF-C9-A2-53', '40.61.189.195', 'sbartoletti2f');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('18LcWNQDezU7Y9h4HxYjLi1cpYpFjcw8Le', 'EC-34-08-92-CD-0E', '181.239.2.216', 'ccreer2g');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('16J2oGB8DoLCNHwz9d3RJhzEKenAP7KF3a', '26-E8-43-60-90-EE', '23.27.246.11', 'mhubbert2h');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1PJvtiDVNdaCDsusjZkuw7mHV6Jto1yKCt', '11-08-2B-49-25-6D', '157.53.13.176', 'afairbard2i');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1JvxumZmweErNi8GaUckxNo1fjQgq6H4o9', '62-E9-D5-D4-EC-ED', '152.157.67.128', 'jwitchell2j');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('14mM9stPeqtsbKtPdJtujWoEG3K5nB6sqG', '97-A1-29-B2-FC-81', '69.194.24.152', 'gdaulby2k');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('18NzRYSsWnyS9R48QHeVN1MmX5P9Esd5Rf', '54-DC-38-CE-AB-FB', '255.140.108.250', 'fpaddy2l');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1FnqUFUB1QqCoQGKdNuUzrbvspBCjoLYf7', '10-5C-D9-08-5A-B7', '214.119.83.59', 'jirlam2m');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1PY7h7auVK8yScVYNm5Gno46uzsR4JZTpM', '2E-0E-AA-C0-79-34', '100.52.132.236', 'chaulkham2n');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1P92e1vvM4VVcocyPCPNz8W8CtvZaUabcn', 'D9-0F-85-9D-41-C6', '7.215.65.35', 'kstendall2o');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('113hL3mKxjnyK1bQWFzWRRudYaBXekLeFM', '1D-65-77-82-D9-C0', '222.214.119.82', 'jgilyott2p');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('17gf33zcsAicfoM4mC5cgXAcHWkgYN4tPd', '9D-E0-A3-CE-3C-50', '251.7.244.43', 'tboatwright2q');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1r3Lv1kmWgZ5FyYUz1c6TfnYvMcaKXD1A', '5B-56-D0-45-D8-C9', '57.201.48.244', 'rtonnesen2r');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('19GK44RE5zYtys9W5u3PRiLtHyhsoYNgTJ', '5D-0B-34-89-58-73', '75.25.240.124', 'swillmer2s');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1n3R6GrJX834EWzxXnSui8VpLeNzyUr9F', '3C-6F-FF-7B-08-9F', '238.69.79.40', 'nwitson2t');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1GQFnHJGMAcwtvFUPuxKeMPTZmKbfPPnJb', '28-A9-85-5B-58-90', '82.95.39.164', 'jmatiebe2u');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1NWXBsKRp7Mkd37sxAvBYJ8uWodLZou99N', 'BE-F3-45-56-15-66', '117.32.209.195', 'dmablestone2v');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1FaQKSyeLZfG1wVEt1yarvkh6SVvDg5eVG', '38-32-C4-BD-3E-B6', '93.163.65.77', 'dhairsnape2w');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('19cG5MiK8TUdkD1N6Hpw7JTMhmKPjZrj5N', '8F-2D-DE-10-F5-BA', '250.7.152.77', 'dmccheyne2x');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('1Bd5R936qVyfquge37RZ2JFMCM2UYwzJCS', '7D-C4-C2-98-C4-D1', '111.72.125.143', 'tburkert2y');
insert into bitcoin_addresses (bitcoin_address, device, last_ip, bitcoin_username) values ('14jgzZCcK35hf9HKFqRzXsNtgC3dWX96fY', 'B7-0C-7A-FF-FB-5E', '228.110.5.235', 'meseler2z');

insert into locations (city, street_number) values ('Ya’erya', '72759');
insert into locations (city, street_number) values ('Zhengmo', '1624');
insert into locations (city, street_number) values ('Vales', '4630');
insert into locations (city, street_number) values ('Liangting', '056');
insert into locations (city, street_number) values ('Wanglinkou', '088');
insert into locations (city, street_number) values ('Września', '468');
insert into locations (city, street_number) values ('Shouzhan', '24924');
insert into locations (city, street_number) values ('Nanhu', '3');
insert into locations (city, street_number) values ('Xintang', '3847');
insert into locations (city, street_number) values ('Kharovsk', '17');
insert into locations (city, street_number) values ('Pengxing', '83690');
insert into locations (city, street_number) values ('Uherské Hradiště', '683');
insert into locations (city, street_number) values ('Lile', '0079');
insert into locations (city, street_number) values ('Kekeran', '65');
insert into locations (city, street_number) values ('Patenongan', '23');
insert into locations (city, street_number) values ('Białobrzegi', '15');
insert into locations (city, street_number) values ('Batasan', '24');
insert into locations (city, street_number) values ('La Huerta', '7380');
insert into locations (city, street_number) values ('Doubravice nad Svitavou', '2');
insert into locations (city, street_number) values ('Dasongshu', '79');
insert into locations (city, street_number) values ('Cibitung', '26795');
insert into locations (city, street_number) values ('Watthana Nakhon', '85437');
insert into locations (city, street_number) values ('Passo Fundo', '031');
insert into locations (city, street_number) values ('Tabor', '9071');
insert into locations (city, street_number) values ('Mieścisko', '7');
insert into locations (city, street_number) values ('Aquin', '95');
insert into locations (city, street_number) values ('Maungatapere', '5480');
insert into locations (city, street_number) values ('Dayuanhuizu', '101');
insert into locations (city, street_number) values ('Duotian', '12');
insert into locations (city, street_number) values ('Ashmūn', '4');
insert into locations (city, street_number) values ('Chicago', '5');
insert into locations (city, street_number) values ('Kpalimé', '0806');
insert into locations (city, street_number) values ('Tawangrejo', '2');
insert into locations (city, street_number) values ('Agía Varvára', '5');
insert into locations (city, street_number) values ('Hita', '2');
insert into locations (city, street_number) values ('Ostroměř', '1');
insert into locations (city, street_number) values ('Firmat', '3');
insert into locations (city, street_number) values ('Zhongben', '655');
insert into locations (city, street_number) values ('Geser', '50');
insert into locations (city, street_number) values ('Santa Clara', '66');
insert into locations (city, street_number) values ('Lashma', '800');
insert into locations (city, street_number) values ('Cumedak', '31491');
insert into locations (city, street_number) values ('Białogard', '36');
insert into locations (city, street_number) values ('Bambari', '488');
insert into locations (city, street_number) values ('Łomża', '5');
insert into locations (city, street_number) values ('Reisjärvi', '3852');
insert into locations (city, street_number) values ('Numata', '347');
insert into locations (city, street_number) values ('Banjar Jagasatru', '64673');
insert into locations (city, street_number) values ('Moñitos', '91533');
insert into locations (city, street_number) values ('Non Narai', '8');
insert into locations (city, street_number) values ('San Jerónimo', '70341');
insert into locations (city, street_number) values ('Shuangjiang', '57');
insert into locations (city, street_number) values ('Vřesina', '868');
insert into locations (city, street_number) values ('Kertasari', '95');
insert into locations (city, street_number) values ('Ichnya', '7');
insert into locations (city, street_number) values ('Tlogoagung', '43351');
insert into locations (city, street_number) values ('Shiojiri', '185');
insert into locations (city, street_number) values ('Khōshāmand', '03401');
insert into locations (city, street_number) values ('Kembé', '83588');
insert into locations (city, street_number) values ('Salto', '6');
insert into locations (city, street_number) values ('Hujiaying', '5893');
insert into locations (city, street_number) values ('Weiyuan', '5347');
insert into locations (city, street_number) values ('Penisihan', '92416');
insert into locations (city, street_number) values ('Kanye', '6963');
insert into locations (city, street_number) values ('Baranoa', '4266');
insert into locations (city, street_number) values ('Cabatuan', '6915');
insert into locations (city, street_number) values ('Oekefan', '96094');
insert into locations (city, street_number) values ('Santa Rosa', '634');
insert into locations (city, street_number) values ('Ijuw', '63590');
insert into locations (city, street_number) values ('Weixin', '604');
insert into locations (city, street_number) values ('Mabai', '16461');
insert into locations (city, street_number) values ('Hexia', '56463');
insert into locations (city, street_number) values ('Zhongshanlu', '104');
insert into locations (city, street_number) values ('Turija', '625');
insert into locations (city, street_number) values ('Duas Igrejas', '985');
insert into locations (city, street_number) values ('Huata', '505');
insert into locations (city, street_number) values ('Camatagua', '67');
insert into locations (city, street_number) values ('Sula', '34164');
insert into locations (city, street_number) values ('Nakhchivan', '43619');
insert into locations (city, street_number) values ('Hagondange', '541');
insert into locations (city, street_number) values ('San Juan del Cesar', '0');
insert into locations (city, street_number) values ('Jiexiu', '484');
insert into locations (city, street_number) values ('Birnin Kebbi', '8');
insert into locations (city, street_number) values ('Sampaloc', '4');
insert into locations (city, street_number) values ('Tenggong', '93');
insert into locations (city, street_number) values ('Lieyu', '1366');
insert into locations (city, street_number) values ('Остров Пасхи', '04');
insert into locations (city, street_number) values ('Viškovci', '0');
insert into locations (city, street_number) values ('Panyindangan', '172');
insert into locations (city, street_number) values ('Alzamay', '97');
insert into locations (city, street_number) values ('Machico', '9506');
insert into locations (city, street_number) values ('Praimarada', '45');
insert into locations (city, street_number) values ('Neni', '03228');
insert into locations (city, street_number) values ('Beaumont', '16054');
insert into locations (city, street_number) values ('Yiánnouli', '5');
insert into locations (city, street_number) values ('Narew', '6');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO transactions(bitcoin_address, city, street_number)
SELECT bitcoin_address, city, street_number FROM bitcoin_addresses,locations
ORDER BY RANDOM() LIMIT 1000;
