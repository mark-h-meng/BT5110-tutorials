/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/* Student Name: Donghwan Kim                                           */
/* Student ID: A0231887U                                                */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL. */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*

First of all, the code is written for PostgreSQL, and let me introduce my case.

My application case is about 'Jobs and Applicants'. 
So topic can be categorized into 'Human Resoure Management' or 'Recruiting', 
which is also my professional interest. 
Data Analytics in HR(so-called People Analytics or HR Analytics) deserves to be valued better!

In this case, applicants can apply to many different positions,
and I have presented this case with 2 entities named 'applicant' and 'position' 
along with 1 relation named 'apply'.

So we have 3 tables named 'applicant', 'position' and 'apply', 
and simple table descriptioins for each table are like below.
(FORMAT: column_name / type / description)

Table.1(Entity.1): 'applicant' 
 - applicant_id / integer / Represents applicant's unique id. Each applicant has unique applicant_id.
 - full_name / varchar(32) / Represents the name of the applicant.
 - gender / varchar(8) / Represents the gender and has 2 levels, 'Male' and 'Female'.
 - email / varchar(32) / Represents the email address of applicant.
 - country / varchar(32) / Represents the country which the applicant came from.

Table.2(Entity.2): 'position'
 - position_id / varchar(8) / Represents the unique id of each job title.
 - job_title / varchar(64) / Represents the name of the job.
 - main_skill / varchar(64) / Represents the skill that is required the most for the job.
 - avg_salary / integer / Represents the average salary of the job position.
 
Table.3(Relation): 'apply'
 - applicant_id / integer / Foreign key from the 'applicant' table
 - position_id / varchar(8) / Foreign key from the 'position' table

*/


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

-- Create Table.1(Entity.1): 'applicant' 
create table if not exists applicant (
	applicant_id integer primary key,  
	full_name varchar(32),	
	gender varchar(8),		
	email varchar(32),		
	country varchar(32)		
);

-- Create Table.2(Entity.2): 'position'
create table if not exists position (
	position_id varchar(8) primary key,
	job_title varchar(64),
	main_skill varchar(64),
	avg_salary integer
);

-- Create Table.3(Relation): 'apply'
create table if not exists apply (
	applicant_id integer not null, 
	position_id varchar(8) not null, 
	primary key (applicant_id, position_id),
	foreign key (applicant_id)
		references applicant (applicant_id),
	foreign key (position_id)
		references position(position_id)
);


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

-- Insert values into Table.1(Entity.1): 'applicant' 
INSERT INTO applicant (applicant_id,full_name,gender,email,country) VALUES 
	(2817,'Bronson Simnett','Female','bsimnett0@go.com','Nicaragua'),
	(7339,'Wendie Gabbott','Female','wgabbott1@yahoo.com','China'),
	(3193,'Germain Matushevich','Female','gmatushevich2@hp.com','Russia'),
	(9209,'Marcia Erickssen','Female','merickssen3@amazon.co.jp','Moldova'),
	(4639,'Misha Luetkemeyer','Female','mluetkemeyer4@odnoklassniki.ru','Pakistan'),
	(0009,'Lenard Seldon','Male','lseldon5@mashable.com','Argentina'),
	(6531,'Fletcher Isson','Female','fisson6@sohu.com','China'),
	(2393,'Kaia Bourgaize','Female','kbourgaize7@barnesandnoble.com','Japan'),
	(6116,'Avram Huggens','Male','ahuggens8@samsung.com','China'),
	(0181,'Boyce Pallatina','Male','bpallatina9@ftc.gov','Brazil'),
	(4465,'Brooke Blown','Female','bblowna@amazonaws.com','France'),
	(5740,'Cristionna Valiant','Female','cvaliantb@taobao.com','Poland'),
	(4718,'Betsey Froschauer','Female','bfroschauerc@uiuc.edu','Russia'),
	(2805,'Eimile Ondrusek','Male','eondrusekd@vinaora.com','Russia'),
	(3992,'Noe Stonard','Female','nstonarde@spiegel.de','Portugal'),
	(6440,'Margery Fray','Male','mfrayf@go.com','Ukraine'),
	(5705,'Tarrance Reihm','Male','treihmg@unesco.org','China'),
	(2086,'Alick Stobbes','Male','astobbesh@bizjournals.com','China'),
	(5056,'Horacio Pottinger','Female','hpottingeri@etsy.com','Russia'),
	(2400,'Ingamar Anyon','Female','ianyonj@artisteer.com','China'),
	(7033,'Tobey Sansam','Male','tsansamk@creativecommons.org','Cuba'),
	(6011,'Putnem Marchelli','Female','pmarchellil@sciencedaily.com','Argentina'),
	(5720,'Addy Skelbeck','Male','askelbeckm@privacy.gov.au','China'),
	(2659,'Eleonore Peirpoint','Female','epeirpointn@narod.ru','Poland'),
	(8548,'Fleurette Cheves','Male','fcheveso@devhub.com','Brazil'),
	(8632,'Samuel Worgen','Female','sworgenp@pinterest.com','Liberia'),
	(5826,'Corrinne Wessel','Female','cwesselq@rambler.ru','Colombia'),
	(2203,'Rik Barnes','Male','rbarnesr@microsoft.com','Indonesia'),
	(0598,'Ronny Celli','Male','rcellis@joomla.org','Poland'),
	(7174,'Fey Shaddick','Female','fshaddickt@fc2.com','Brazil'),
	(7123,'Ruben Durrance','Male','rdurranceu@merriamwebster.com','China'),
	(5723,'Ashli Snazel','Female','asnazelv@uol.com.br','China'),
	(3624,'Isahella St. Hill','Female','istw@soup.io','Mexico'),
	(6422,'Thorsten Purslow','Male','tpurslowx@newyorker.com','China'),
	(2076,'Aldous Gethins','Female','agethinsy@cbsnews.com','Philippines'),
	(5912,'Bryna Stolte','Male','bstoltez@g.co','Philippines'),
	(1846,'Percy Merrell','Female','pmerrell10@scribd.com','China'),
	(5563,'Prince Bainton','Female','pbainton11@blogs.com','Japan'),
	(9801,'Rhodie Drinkwater','Female','rdrinkwater12@multiply.com','Poland'),
	(8711,'Kari Buggs','Male','kbuggs13@sakura.ne.jp','Finland'),
	(7476,'Renard Kilpin','Male','rkilpin14@theguardian.com','Yemen'),
	(5680,'Arri Jansey','Male','ajansey15@homestead.com','Tonga'),
	(5281,'Lydon Pigott','Female','lpigott16@webs.com','Yemen'),
	(9102,'Josepha Brammer','Male','jbrammer17@php.net','Colombia'),
	(0078,'Fawn Barstock','Male','fbarstock18@cnn.com','Armenia'),
	(5177,'Nichol Dodding','Male','ndodding19@army.mil','China'),
	(3223,'Marsh Honeyghan','Male','mhoneyghan1a@w3.org','Russia'),
	(5777,'Eden Haselhurst','Female','ehaselhurst1b@uiuc.edu','Luxembourg'),
	(7601,'Mathias Anthon','Male','manthon1c@parallels.com','Indonesia'),
	(4786,'Carlin Carillo','Female','ccarillo1d@nydailynews.com','Philippines'),
	(1334,'Ailey Roy','Male','aroy1e@state.tx.us','Argentina'),
	(4197,'Cob Casale','Male','ccasale1f@mediafire.com','China'),
	(2915,'Abeu De Giovanni','Male','ade1g@hhs.gov','France'),
	(5775,'Annalee Lafranconi','Male','alafranconi1h@ca.gov','Vietnam'),
	(2705,'Silvanus Jillings','Female','sjillings1i@youku.com','China'),
	(0204,'Clarke Lober','Male','clober1j@discovery.com','Brazil'),
	(8613,'Coriss Lewington','Male','clewington1k@flavors.me','China'),
	(6064,'Mordecai Christophersen','Male','mchristophersen1l@storify.com','Poland'),
	(2992,'Stearn Madill','Male','smadill1m@privacy.gov.au','Indonesia'),
	(9043,'Eldin Akister','Male','eakister1n@bbc.co.uk','Serbia'),
	(2706,'Almeta Juares','Female','ajuares1o@google.com','Brazil'),
	(4134,'Lisbeth Grosvenor','Female','lgrosvenor1p@edublogs.org','Russia'),
	(6855,'Peyton Bly','Male','pbly1q@alibaba.com','Croatia'),
	(6834,'Irene Corck','Male','icorck1r@ucoz.com','Indonesia'),
	(6188,'Wesley Lillico','Male','wlillico1s@deviantart.com','Belarus'),
	(6871,'Simeon Tointon','Female','stointon1t@dell.com','Indonesia'),
	(5906,'Willdon Bowen','Male','wbowen1u@odnoklassniki.ru','Slovakia'),
	(6055,'Gradeigh Astbery','Male','gastbery1v@washington.edu','Indonesia'),
	(9324,'Kimbra Kimberly','Male','kkimberly1w@abc.net.au','United States'),
	(4472,'Ariela Pinching','Female','apinching1x@state.tx.us','Canada'),
	(4689,'Dante Rakestraw','Male','drakestraw1y@slideshare.net','Indonesia'),
	(7512,'Marilin Gretton','Female','mgretton1z@vimeo.com','China'),
	(4135,'Merle Duffie','Female','mduffie20@wsj.com','Brazil'),
	(5546,'Geralda Sibary','Female','gsibary21@fotki.com','Namibia'),
	(6776,'Ada Heather','Male','aheather22@deliciousdays.com','Russia'),
	(2991,'Raquel Bowle','Female','rbowle23@last.fm','Vietnam'),
	(4245,'Carole Scuse','Male','cscuse24@google.cn','China'),
	(3933,'Lebbie Winson','Male','lwinson25@e-recht24.de','China'),
	(7325,'Stanford Rassmann','Male','srassmann26@stumbleupon.com','Colombia'),
	(1365,'Sioux Ratley','Female','sratley27@spiegel.de','France'),
	(8797,'Malina Durston','Female','mdurston28@overblog.com','Kazakhstan'),
	(6213,'Kimberlee Menci','Male','kmenci29@addtoany.com','Sweden'),
	(7889,'Gasper Siemantel','Male','gsiemantel2a@yahoo.com','Poland'),
	(9059,'Brewster Rawlison','Male','brawlison2b@cnn.com','Philippines'),
	(5794,'Arda Kelledy','Female','akelledy2c@time.com','Argentina'),
	(2010,'Manya Windram','Male','mwindram2d@google.cn','South Sudan'),
	(5847,'Alfy Shovel','Male','ashovel2e@theguardian.com','Russia'),
	(8950,'Jaimie Undrell','Female','jundrell2f@columbia.edu','Russia'),
	(1344,'Griff Conlaund','Female','gconlaund2g@google.com.au','Bosnia and Herzegovina'),
	(4803,'Cindi Antoniazzi','Male','cantoniazzi2h@utexas.edu','China'),
	(9539,'Terri-jo Norvell','Male','tnorvell2i@deviantart.com','Philippines'),
	(8842,'Gail Karslake','Male','gkarslake2j@goodreads.com','United States'),
	(5551,'Leandra Lodo','Female','llodo2k@eepurl.com','Colombia'),
	(2428,'Octavia Mustill','Female','omustill2l@paginegialle.it','Sweden'),
	(7485,'Claude Wyatt','Female','cwyatt2m@tamu.edu','Syria'),
	(7318,'Phyllis Culross','Female','pculross2n@de.vu','Kenya'),
	(9243,'Alameda Akast','Male','aakast2o@t-online.de','Guatemala'),
	(3964,'Karin Pryor','Female','kpryor2p@desdev.cn','Peru'),
	(7059,'Indira Bautiste','Male','ibautiste2q@fema.gov','China'),
	(4359,'Micheil Brando','Female','mbrando2r@bandcamp.com','Malta')
;

-- Insert values into Table.2(Entity.2): 'position' 
INSERT INTO position (position_id,job_title,main_skill,avg_salary) VALUES 
	('iy22','Geological Engineer','Overseas Production',8751.40),
	('zw87','Health Coach II','Appeals',9973.20),
	('gi23','Office Assistant III','Active Directory',8435.22),
	('ff06','Account Representative II','Keyboards',10371.08),
	('hf02','Financial Analyst','RBAC',10149.73),
	('ox23','Office Assistant II','Qlogic',9465.05),
	('hl24','Tax Accountant','Aeroelasticity',17694.84),
	('ub43','Food Chemist','Oligonucleotides',7230.22),
	('lk61','Accountant IV','EHS',17997.62),
	('jg50','Senior Financial Analyst','RF Engineering',12742.07),
	('ta35','Legal Assistant','Volunteer Management',9052.44),
	('ri72','Director of Sales','Solvency II',13862.83),
	('di91','Accounting Assistant III','NIMS',16724.82),
	('oj24','Developer I','FFA',9796.48),
	('wj17','Senior Editor','JTAPI',17811.89),
	('rx71','VP Accounting','DSLAM',12247.57),
	('oi15','Administrative Officer','HTML Help Workshop',19386.76),
	('ct41','Analog Circuit Design manager','FP',10406.73),
	('kz43','Research Nurse','FI-AA',17721.14),
	('gg86','Business Systems Development Analyst','European Computer Driving Licence',16016.64),
	('cn83','Senior Cost Accountant','HAZOP Study',15309.74),
	('vr69','Internal Auditor','xPON',7708.40),
	('kv84','Payment Adjustment Coordinator','Art Direction',9195.72),
	('tm75','Software Consultant','SFP',12378.03),
	('vm75','Environmental Tech','Blood Pressure',16897.10),
	('sy08','Engineer III','NX-OS',19206.06),
	('pc04','Civil Engineer','Utility Construction',19384.58),
	('br35','Speech Pathologist','NX-OS',19325.51),
	('mx11','Physical Therapy Assistant','Dynamic Positioning',10973.93),
	('et28','Occupational Therapist','Asset Management',18192.25),
	('nb82','Financial Analyst','Insurance',15141.15),
	('td83','Physical Therapy Assistant','Young Adult Literature',18552.82),
	('en15','Nurse','XSI',7341.65),
	('iu56','Software Engineer I','Competitive Analysis',9307.65),
	('ty70','Community Outreach Specialist','FCNSP',16032.25),
	('qm51','Social Worker','VCI',8212.16),
	('zo79','Database Administrator III','RCMS',9776.32),
	('dj48','Financial Analyst','DNS Management',7341.35),
	('cu14','Librarian','ZBrush',14500.22),
	('to97','Social Worker','DMVPN',9598.63),
	('qq05','Speech Pathologist','Laptops',18095.49),
	('ep66','Account Coordinator','Zend Framework',14547.59),
	('sm32','Editor','Directing Others',19609.21),
	('ug77','Senior Financial Analyst','Whole House Renovations',18370.50),
	('yu73','Financial Advisor','Occupational Therapists',12972.87),
	('aq38','Financial Advisor','Back Office',17333.65),
	('sn65','Dental Hygienist','vCenter Server',12953.89),
	('af67','Assistant Media Planner','GCCS',8315.96),
	('kc93','Registered Nurse','Museum Collections',7037.35),
	('my11','Internal Auditor','Adult Education',16757.70),
	('vj13','Technical Writer','Call Centers',9249.26),
	('ho02','Geological Engineer','Functional Verification',17995.81),
	('ln01','Programmer I','CQ',8805.80),
	('fc98','Chief Design Engineer','DDM',19720.21),
	('wh41','VP Accounting','Tubing',12127.09),
	('pj87','Nuclear Power Engineer','Upstream',14148.06),
	('ae23','Project Manager','UB04',12545.40),
	('sn73','Statistician II','SAP BI',15807.07),
	('mo49','Teacher','Ductwork',19704.66),
	('au39','Chief Design Engineer','Athletic Administration',10569.65),
	('zq88','Business Systems Development Analyst','CQC',14116.06),
	('ju24','Recruiting Manager','Oil &amp; Gas Industry',9618.78),
	('tz71','Quality Control Specialist','Valuation',7669.70),
	('zd42','Tax Accountant','FCAPS',17915.97),
	('bv77','Geological Engineer','Employer Branding',8377.44),
	('fm94','Developer I','BBP',19279.26),
	('th73','Project Manager','Kronos',12649.31),
	('oh61','Administrative Officer','WSGI',15138.84),
	('qm95','Teacher','Live Events',11940.72),
	('yf11','Executive Secretary','Git',10421.36),
	('vo65','Programmer IV','Manual Therapy',7356.92),
	('ki64','Executive Secretary','MC2',7641.43),
	('mh92','Nurse','Payments',15027.12),
	('mx34','Staff Scientist','Tutoring',16773.59),
	('nu97','Software Test Engineer III','UHF',19374.65),
	('wy52','Web Developer I','FFP',12907.84),
	('gl99','Executive Secretary','eBanking',17911.58),
	('ji73','Junior Executive','NMLS',14089.40),
	('re73','Editor','MPEG',11197.99),
	('cb52','Nuclear Power Engineer','Phase II Subsurface Investigations',13716.93),
	('nw64','Account Coordinator','Film Festivals',10599.39),
	('lm90','General Manager','Alternative Energy',10350.31),
	('zv33','Sales Associate','Presentation Skills',12564.96),
	('jg41','Junior Executive','Microsoft Project',17162.84),
	('mn17','Automation Specialist II','Operational Efficiency',11284.73),
	('pm19','VP Product Management','Dogs',14164.69),
	('ke13','Information Systems Manager','Professional Ethics',14809.25),
	('ab97','Senior Financial Analyst','PDMS Draft',7145.99),
	('tb10','Staff Scientist','System Deployment',16068.13),
	('rq40','Internal Auditor','Yardi Enterprise',17094.66),
	('ly86','Assistant Professor','CFOs',9350.76),
	('um64','Web Designer III','TWIC Card',15059.07),
	('ah34','Health Coach III','Python',11190.98),
	('rh14','Dental Hygienist','TMMi',7039.23),
	('rw76','Accounting Assistant III','DDE',9852.53),
	('fy55','Account Representative IV','Abstract Paintings',9091.63),
	('xb39','Environmental Tech','Employee Benefits',8888.93),
	('jd69','Research Nurse','DNA replication',18544.12),
	('pl60','Accounting Assistant III','Zen',13764.43),
	('gn60','Electrical Engineer','JCO',8253.40),
	('zo05','Research Assistant II','Creative Direction',15335.48),
	('dz07','Biostatistician III','Educational Leadership',7413.28),
	('jv67','Junior Executive','Knee',8516.09),
	('ho90','GIS Technical Architect','Group Policy',11775.55),
	('ui83','Occupational Therapist','Typo3',14739.62),
	('yi86','Senior Developer','International Economics',10421.96),
	('nm08','Chemical Engineer','Yacht Racing',7096.08),
	('ue63','Payment Adjustment Coordinator','Awesomeness',11631.66),
	('zv43','Geological Engineer','Medical Writing',17646.34),
	('sq07','Dental Hygienist','Amadeus',12937.65)
;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

-- Insert values into Table.3(Relation): 'apply' 
insert into apply (
	applicant_id,
	position_id
)
select a.applicant_id as applicant_id
     , b.position_id as position_id
from applicant as a
cross join position as b
where 1=1
limit (select FLOOR(RANDOM()*10)+1000)
;


