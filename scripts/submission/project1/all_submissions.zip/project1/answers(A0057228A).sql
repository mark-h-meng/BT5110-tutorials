/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* The example chosen is about patients who have seen a physician at a hospital within the year 2020. 
The first table (E1) 'patients' has 5 attributes - patient ID, first name, last name, age and gender, which provides details of each patient. The second table (E2) 'hospitals' has 3 attributes - physician ID, hospital name and admission date which provides details of the doctor visit. The relationship table (R) 'visits' associates patients to their physicians through the linking of patient ID to physician ID. The relationship is a many-to-many relationship as patients may visit multiple physicians at various hospitals in a year and a physician at any hospital reviews many patients in a year. */
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/* 								    */                                                              	    
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE patients(
patient_id VARCHAR(50) NOT NULL PRIMARY KEY, 
first_name VARCHAR(50) NOT NULL, 
last_name VARCHAR(50) NOT NULL, 
age INT NOT NULL,
gender VARCHAR(10) NOT NULL,
visit_date DATE NOT NULL
);
CREATE TABLE hospitals(
physician_id VARCHAR(10) NOT NULL PRIMARY KEY, 
hospital_name VARCHAR(30) NOT NULL
);
CREATE TABLE visits(
patient_id VARCHAR(50) NOT NULL, 
physician_id VARCHAR(10) NOT NULL, 
CONSTRAINT fk_patient 
FOREIGN KEY (patient_id) 
REFERENCES patients(patient_id),
CONSTRAINT fk_hospital 
FOREIGN KEY (physician_id)
REFERENCES hospitals(physician_id)
);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('N0752704M', 'Clayborn', 'De Mattei', 30, 'Male', '12/30/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('Y4880166B', 'Nadean', 'Gurry', 81, 'Male', '6/20/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('Z9555645E', 'Kelli', 'Brando', 43, 'Male', '2/14/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('M8645022M', 'Kurt', 'Imlock', 50, 'Male', '11/7/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('W8232422W', 'Dwight', 'Cutridge', 80, 'Female', '4/22/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('M0721367D', 'Jehanna', 'Buney', 63, 'Female', '10/12/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('P9215834Z', 'Lester', 'Melesk', 99, 'Male', '9/11/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('V1329082F', 'Ondrea', 'Rowntree', 24, 'Male', '8/15/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('Y4071710U', 'Orrin', 'Danilchik', 33, 'Male', '1/12/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('A3769387P', 'Carolann', 'Ilyunin', 93, 'Male', '2/21/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('V8029211X', 'Say', 'Safont', 59, 'Female', '8/27/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('I4491492E', 'Mareah', 'Gange', 67, 'Male', '1/5/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('Y4924499Y', 'Sutton', 'Panter', 80, 'Male', '9/18/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('E9808072U', 'Raychel', 'Coatham', 98, 'Female', '8/22/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('M7340095N', 'Giustino', 'Luddy', 90, 'Female', '10/29/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('R5608150S', 'Gaye', 'MacColgan', 65, 'Female', '6/10/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('M2825883D', 'Marlena', 'Alben', 31, 'Male', '8/13/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('W9778977U', 'Lydon', 'Sterricker', 57, 'Female', '10/29/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('M5348924F', 'Rhoda', 'Ponsford', 38, 'Male', '2/20/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('U9414598G', 'Pebrook', 'Ossulton', 47, 'Female', '7/4/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('H5875232X', 'Kip', 'Greenham', 44, 'Female', '5/28/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('M0820066W', 'Darya', 'Pardy', 100, 'Male', '6/26/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('H6747437A', 'Gretta', 'Trevain', 28, 'Female', '10/30/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('M8899543H', 'Kakalina', 'Gorman', 70, 'Female', '3/2/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('A2214366E', 'Joy', 'Lowy', 38, 'Female', '1/11/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('D1232222S', 'Gustave', 'Dafter', 99, 'Female', '12/24/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('C4023513W', 'Levon', 'Skurm', 94, 'Female', '6/14/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('W3153640H', 'Sidoney', 'Leadbetter', 36, 'Female', '11/14/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('G8866863D', 'Romeo', 'Carstairs', 39, 'Female', '4/9/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('M6910379A', 'Marylou', 'Erickson', 67, 'Female', '11/24/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('U1523626G', 'Marylinda', 'Gert', 58, 'Male', '11/28/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('Z6588587X', 'Harmonie', 'Pooley', 92, 'Female', '1/20/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('F3921228X', 'Catlin', 'Chitham', 19, 'Male', '3/23/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('I6961612I', 'Iorgos', 'Chettle', 38, 'Female', '9/23/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('H2757413F', 'Nikolai', 'Dakers', 96, 'Male', '12/20/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('B6244649Y', 'Hayley', 'Pietruszewicz', 80, 'Female', '5/10/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('U3620395C', 'Romona', 'Wardle', 89, 'Male', '4/29/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('O2532808K', 'Caesar', 'Le Surf', 21, 'Male', '3/30/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('F7921566W', 'Shirleen', 'Crabbe', 76, 'Male', '9/11/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('U5726966Y', 'Doll', 'Rowler', 26, 'Female', '7/7/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('A8493577D', 'Holden', 'Chicotti', 99, 'Female', '6/27/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('Y2028779K', 'Adrienne', 'Tite', 26, 'Male', '3/11/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('H3584066C', 'Shea', 'Meale', 56, 'Male', '6/28/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('C8952869C', 'Maurizio', 'Isworth', 35, 'Female', '6/7/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('M7785518M', 'Sephira', 'Jaye', 74, 'Male', '10/20/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('S4649233F', 'Redford', 'Fradson', 66, 'Male', '8/29/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('I1454125S', 'Vivyan', 'Everingham', 92, 'Female', '8/8/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('Q1862651H', 'Sawyer', 'Insall', 97, 'Female', '2/18/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('Q0580367M', 'Marcelia', 'Abbiss', 23, 'Female', '7/21/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('Y9367310D', 'Terrijo', 'Flory', 47, 'Male', '1/18/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('I5187978B', 'Emalee', 'Fleming', 55, 'Female', '7/17/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('F7982012E', 'Ernst', 'O'' Dornan', 59, 'Male', '10/9/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('N6239331U', 'Terrence', 'Yurkin', 87, 'Female', '1/19/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('U8443324B', 'Benoit', 'Duffet', 49, 'Male', '12/6/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('H5852641X', 'Frank', 'Lewson', 92, 'Male', '8/13/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('L2094280B', 'Dugald', 'Fuke', 47, 'Male', '3/15/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('W3550427F', 'Walsh', 'Laxston', 52, 'Female', '6/10/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('P0442244I', 'Kattie', 'Corbin', 48, 'Female', '7/8/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('D7171546Z', 'Etan', 'Parradye', 35, 'Male', '5/6/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('W5588950R', 'Batholomew', 'Furphy', 34, 'Male', '1/31/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('S0994778Y', 'Kerby', 'Oylett', 100, 'Female', '9/30/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('U6096335D', 'Garwin', 'Duly', 82, 'Female', '5/18/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('B8719028Z', 'Giacomo', 'Turnell', 72, 'Male', '5/17/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('G0088685C', 'Randal', 'Draycott', 61, 'Male', '8/8/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('O6490560J', 'Alvie', 'Elward', 21, 'Female', '1/23/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('A6447802U', 'Anatola', 'Tresvina', 62, 'Male', '6/28/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('B0025301K', 'Alick', 'Thompkins', 65, 'Male', '6/17/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('P7775508J', 'Lari', 'Harrowing', 60, 'Male', '8/6/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('K2268305R', 'Sharity', 'Stetlye', 25, 'Female', '6/23/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('J4657518G', 'Hube', 'Elies', 40, 'Female', '5/23/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('T4836259P', 'Carleton', 'Charrette', 82, 'Female', '6/29/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('Y5976361H', 'Alina', 'Tassell', 79, 'Male', '4/17/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('N5475264P', 'Keeley', 'Brazel', 80, 'Male', '6/10/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('Q7471738N', 'Gerri', 'Yashin', 92, 'Male', '3/19/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('Z9054802J', 'Madel', 'Creswell', 23, 'Male', '7/16/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('Z9490852C', 'Finlay', 'Piggens', 97, 'Female', '4/21/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('D6790142D', 'Jessi', 'Brasier', 92, 'Female', '7/26/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('W2050016Q', 'Selle', 'O''Dyvoie', 19, 'Male', '9/5/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('L2346425X', 'Ronda', 'Puig', 25, 'Male', '4/5/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('C7884394R', 'Rochester', 'Duffit', 89, 'Male', '6/12/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('J0034297F', 'Chev', 'Chavez', 57, 'Male', '4/11/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('O5126354T', 'Audy', 'Chevins', 26, 'Male', '7/2/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('G8332289D', 'Quinton', 'Riccio', 19, 'Male', '2/9/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('C9091895S', 'Gerhardt', 'Fermin', 38, 'Male', '11/2/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('O5624476V', 'Roosevelt', 'Kenchington', 80, 'Male', '3/9/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('A2214609J', 'Sabra', 'Butcher', 93, 'Male', '5/4/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('F5458937S', 'Fielding', 'Plummer', 68, 'Male', '2/8/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('M3313844V', 'Vic', 'Seargeant', 40, 'Male', '12/23/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('L9936840U', 'Tiffy', 'Pavier', 100, 'Female', '4/8/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('J7718787C', 'Lorne', 'Bircher', 83, 'Female', '5/24/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('T0152361X', 'Tessie', 'Scard', 49, 'Male', '10/10/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('I4875507H', 'Shara', 'Buxcey', 65, 'Female', '11/26/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('C8679631L', 'Currey', 'Wellard', 39, 'Female', '10/30/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('E6251895U', 'Sonya', 'Petit', 88, 'Female', '9/13/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('R7945360Y', 'Kristen', 'Swithenby', 89, 'Female', '2/6/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('I2515867P', 'Benton', 'Van Brug', 77, 'Male', '10/17/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('C2575357I', 'Goldarina', 'Jozwicki', 19, 'Male', '11/26/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('K6606115W', 'Tabbitha', 'Mudd', 32, 'Female', '10/17/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('U7696848F', 'Gabe', 'Cockrell', 92, 'Male', '9/12/2020');
insert into patients (patient_id, first_name, last_name, age, gender, visit_date) values ('U7414155E', 'Moina', 'Jenicke', 54, 'Male', '6/4/2020');
insert into hospitals (physician_id, hospital_name) values ('M63246W', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M52740W', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M46735V', 'Ng Teng Fong General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M50196J', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M59171I', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M94463A', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M80002L', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M66251J', 'Ng Teng Fong General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M01985M', 'Khoo Teck Puat Hospital');
insert into hospitals (physician_id, hospital_name) values ('M54375V', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M37084L', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M89933U', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M49415K', 'Changi General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M44847A', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M64210L', 'Changi General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M84259Y', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M08367P', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M67244B', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M92697T', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M91909P', 'National University Hospital');
insert into hospitals (physician_id, hospital_name) values ('M09838Q', 'National University Hospital');
insert into hospitals (physician_id, hospital_name) values ('M52297A', 'Changi General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M56518Z', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M79746S', 'National University Hospital');
insert into hospitals (physician_id, hospital_name) values ('M54791C', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M22241X', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M54306W', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M75599U', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M79449D', 'Ng Teng Fong General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M54640Z', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M16749M', 'National University Hospital');
insert into hospitals (physician_id, hospital_name) values ('M53368A', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M24617M', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M18408Q', 'National University Hospital');
insert into hospitals (physician_id, hospital_name) values ('M96369X', 'National University Hospital');
insert into hospitals (physician_id, hospital_name) values ('M05914S', 'Ng Teng Fong General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M31976T', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M61133G', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M99878Q', 'Khoo Teck Puat Hospital');
insert into hospitals (physician_id, hospital_name) values ('M42243E', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M07169A', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M65077E', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M75024V', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M48579Y', 'Ng Teng Fong General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M06752O', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M95993Q', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M98217C', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M89945X', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M27961T', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M45677N', 'National University Hospital');
insert into hospitals (physician_id, hospital_name) values ('M60808K', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M62638N', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M07131G', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M94443B', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M91042K', 'Changi General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M50697S', 'Khoo Teck Puat Hospital');
insert into hospitals (physician_id, hospital_name) values ('M03918Z', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M63455A', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M40072E', 'Ng Teng Fong General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M45336V', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M70307C', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M33568K', 'Changi General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M79489M', 'Khoo Teck Puat Hospital');
insert into hospitals (physician_id, hospital_name) values ('M43910Q', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M71439B', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M99592R', 'Khoo Teck Puat Hospital');
insert into hospitals (physician_id, hospital_name) values ('M25815Y', 'Khoo Teck Puat Hospital');
insert into hospitals (physician_id, hospital_name) values ('M38977X', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M65913S', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M17099C', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M50257R', 'National University Hospital');
insert into hospitals (physician_id, hospital_name) values ('M03531U', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M42258V', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M69202Z', 'National University Hospital');
insert into hospitals (physician_id, hospital_name) values ('M00848H', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M94895W', 'Ng Teng Fong General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M86375K', 'National University Hospital');
insert into hospitals (physician_id, hospital_name) values ('M34611H', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M89957U', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M47462K', 'Ng Teng Fong General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M34968K', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M44662J', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M96789L', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M66651R', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M45067Y', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M29535G', 'Khoo Teck Puat Hospital');
insert into hospitals (physician_id, hospital_name) values ('M56976A', 'Khoo Teck Puat Hospital');
insert into hospitals (physician_id, hospital_name) values ('M35949R', 'Khoo Teck Puat Hospital');
insert into hospitals (physician_id, hospital_name) values ('M04285W', 'Ng Teng Fong General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M80493C', 'Changi General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M04881H', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M74200X', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M62248T', 'Tan Tock Seng Hospital');
insert into hospitals (physician_id, hospital_name) values ('M74009V', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M85624J', 'Ng Teng Fong General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M05913F', 'Changi General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M29235Y', 'Sengkang General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M72625Y', 'National University Hospital');
insert into hospitals (physician_id, hospital_name) values ('M43135E', 'Singapore General Hospital');
insert into hospitals (physician_id, hospital_name) values ('M31363V', 'Sengkang General Hospital');
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO visits
SELECT patient_id, physician_id FROM patients CROSS JOIN hospitals
ORDER BY random()
LIMIT 1000;
