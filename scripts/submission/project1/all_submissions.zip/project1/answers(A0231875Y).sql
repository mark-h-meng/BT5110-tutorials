

/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* The first entity E1 is the customers table which contains the information that customers provide to make online transaction purchases.
   It has attributes like first name and last name of the customer, the type of credit card that the customer used, the credit card name, the currency of the purchase and the amount spent during the transaction. 
   The credit card number is an unique identifier tied to the cardholder name and hence it forms the primary key for the customer table. 
   
   The second entity E2 is the retail table which contains the information that a retail company (eg. Target) has about their customers. 
   It has attributes like the customer identification number, gender of the customer, country that the customer is located and the type of retail that the customer indicates interests. 
   The customer identification number created by the retail company is unique to each customer and hence it forms the primary key for the retail table. 
   
   The relationship set R is a transactions table which contain the information that the card associations (eg. Visa) have since card associations are between customer and retail store. 
   This transactions table can associate for example, the credit card number to customer identification number in the retail company (eg. Target). 
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/*To create a new database,*/
CREATE DATABASE assignmentone; 

/*To create the entity, E1*/
CREATE TABLE IF NOT EXISTS customers (
first_name VARCHAR(64) NOT NULL, 
last_name VARCHAR(64) NOT NULL,
credit_card_type VARCHAR(64) NOT NULL, 
credit_card_no VARCHAR(64) PRIMARY KEY,
currency VARCHAR(64) NOT NULL, 
amount_spent NUMERIC NOT NULL);

/*To create the entity, E2*/
CREATE TABLE IF NOT EXISTS retail (
customerid VARCHAR(16) NOT NULL,
gender VARCHAR(16) NOT NULL, 
country VARCHAR(64) NOT NULL,
retail_type VARCHAR(64) NOT NULL, 
PRIMARY KEY (customerid));

/*To create the relation, R*/
CREATE TABLE transactions (
credit_card_no VARCHAR(64) REFERENCES customers(credit_card_no)
	ON UPDATE CASCADE ON DELETE CASCADE
	DEFERRABLE INITIALLY DEFERRED,
customerid VARCHAR(16),
PRIMARY KEY (credit_card_no, customerid), 
FOREIGN KEY (customerid) REFERENCES retail(customerid)
	ON UPDATE CASCADE ON DELETE CASCADE
	DEFERRABLE INITIALLY DEFERRED); 

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/*To insert 100 rows of data for the customers table */
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Kylynn', 'Attenbarrow', 'jcb', '3533519825742249', 'Real', '94537.37');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Alberta', 'Bayly', 'visa-electron', '4508800587461551', 'Denar', '78375.67');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Dorris', 'Pawling', 'jcb', '3564791101551428', 'Yuan Renminbi', '46517.10');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Larina', 'Sammons', 'china-unionpay', '560223537656352320', 'Dirham', '33015.54');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Sky', 'Hannigan', 'mastercard', '5100133242940499', 'Euro', '36417.85');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Adelaida', 'Olanda', 'diners-club-enroute', '201795543742631', 'Dollar', '54682.67');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Alma', 'Kringe', 'jcb', '3581118261462346', 'Euro', '72227.64');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Kristoforo', 'Battisson', 'maestro', '6304214136010987', 'Guarani', '44443.12');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Miof mela', 'Mathias', 'jcb', '3588287588255619', 'Dollar', '54322.70');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Erma', 'Bramble', 'jcb', '3573852568521194', 'Franc', '88010.27');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Neall', 'Farraway', 'jcb', '3555881350884157', 'Sol', '58665.93');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Janean', 'Dysart', 'mastercard', '5156779495794687', 'Sol', '4092.49');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Jocelin', 'Romi', 'jcb', '3528013845260439', 'Euro', '96088.16');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Kathleen', 'Goricke', 'jcb', '3572011408598224', 'Rupiah', '91965.78');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Damon', 'Gaspard', 'americanexpress', '348528657978699', 'Dinar', '90864.09');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Alex', 'Advani', 'jcb', '3535065379033625', 'Euro', '13974.85');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Felicio', 'Burt', 'mastercard', '5010123598291935', 'Euro', '23827.86');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Maddy', 'Van der Brug', 'visa', '4042605035882636', 'Euro', '73208.82');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Curt', 'Prynne', 'diners-club-enroute', '201453532860838', 'Krona', '9901.97');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Vallie', 'Kemston', 'jcb', '3557885194323361', 'Yen', '39463.34');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Konstanze', 'Manthroppe', 'instapayment', '6380824971519681', 'Rupiah', '44710.64');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Leanora', 'Maseyk', 'diners-club-international', '36642677974237', 'Yen', '12967.06');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Reine', 'Borrington', 'jcb', '3540209846899274', 'Dollar', '86539.99');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Nicolais', 'Blunt', 'jcb', '3548639410158040', 'Euro', '967.76');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('L;urette', 'Padillo', 'mastercard', '5007663008586049', 'Yuan Renminbi', '65145.13');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Jen', 'Cabrer', 'jcb', '3561495535452889', 'Yen', '10613.64');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Marianne', 'Haythorne', 'switch', '6759766116238900123', 'Yuan Renminbi', '23432.49');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Dillie', 'Dekeyser', 'mastercard', '5100141118943091', 'Dalasi', '42261.73');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Essie', 'Syddie', 'diners-club-enroute', '201416706878217', 'Yuan Renminbi', '13685.16');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Del', 'Lytton', 'jcb', '3568259477040851', 'Rupiah', '21319.69');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Camey', 'Lanon', 'jcb', '3552904903324795', 'Euro', '38722.56');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Ernestine', 'Meale', 'jcb', '3542129190104287', 'Yuan Renminbi', '23776.25');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Uriel', 'Gawn', 'visa-electron', '4026344885324222', 'Ruble', '44650.76');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Jeannie', 'Gravell', 'americanexpress', '374622942395517', 'Peso', '81124.82');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Giorgia', 'Brookwood', 'jcb', '3547540634517535', 'Denar', '815.59');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Terrance', 'Gordon-Giles', 'switch', '4911415831026206822', 'Krona', '85074.05');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Jaime', 'Studholme', 'maestro', '060493680720183422', 'Yuan Renminbi', '44849.33');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Esdras', 'Oylett', 'diners-club-enroute', '201636081272666', 'Dram', '45061.71');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Willyt', 'Royston', 'jcb', '3560018841538018', 'Euro', '80220.91');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Tristan', 'Baynon', 'visa', '4041591347136211', 'Dirham', '54193.54');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Loy', 'Jerred', 'maestro', '6762048655683187', 'Yuan Renminbi', '68649.72');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Linell', 'Dunne', 'jcb', '3531006612576180', 'Euro', '88434.02');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Brucie', 'Grigg', 'jcb', '3542588443553444', 'Peso', '73412.54');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Sharla', 'Swayland', 'china-unionpay', '5602250290651407', 'Zloty', '69976.97');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Valaria', 'Engley', 'mastercard', '5200173807970597', 'Rial', '2654.14');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Caddric', 'Pace', 'jcb', '3528011244197442', 'Euro', '38522.39');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Aldis', 'Polamontayne', 'bankcard', '5602224652740652', 'Euro', '36751.78');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Nelson', 'Fry', 'maestro', '675962942100883451', 'Real', '29355.99');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Kipp', 'Bartholat', 'bankcard', '5602244529098118', 'Rupiah', '74639.69');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Lane', 'Mouatt', 'china-unionpay', '560221988875338545', 'Euro', '32333.17');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Ody', 'Castello', 'americanexpress', '374622143327657', 'Peso', '32520.20');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Alley', 'Jestico', 'bankcard', '5602251421481409', 'Yuan Renminbi', '67585.77');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Loraine', 'Scorah', 'china-unionpay', '5610342261528308', 'Krona', '6104.19');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Ethelda', 'Scrogges', 'laser', '67064173278069072', 'Pound', '13691.65');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Loralee', 'Beacham', 'mastercard', '5571446071963865', 'Peso', '53180.52');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Silvie', 'Geroldo', 'china-unionpay', '56022321275442966', 'Peso', '8170.35');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Nicoline', 'Trigwell', 'solo', '676758208692673544', 'Real', '63668.92');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Luca', 'McCorry', 'maestro', '060470513573614622', 'Yuan Renminbi', '91048.19');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Garth', 'Reglar', 'jcb', '3568868966928903', 'Dollar', '79013.60');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Darrelle', 'Duffus', 'jcb', '3560486630690797', 'Shilling', '77520.58');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Whitney', 'Ransley', 'maestro', '630469681648848211', 'Tenge', '52014.16');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Malcolm', 'McConaghy', 'americanexpress', '374283222164295', 'Ruble', '82594.13');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Rosanne', 'Skelding', 'jcb', '3581847291106867', 'Euro', '97770.53');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Dyanne', 'Sline', 'jcb', '3570618422754625', 'Euro', '92321.96');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Gipsy', 'Kristof', 'laser', '6304927583931500', 'Yuan Renminbi', '37605.84');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Paulo', 'Sherebrook', 'diners-club-carte-blanche', '30476095261869', 'Yen', '73918.41');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Halette', 'Siggins', 'diners-club-carte-blanche', '30553346058581', 'Hryvnia', '77866.28');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Dennie', 'Beese', 'laser', '630425425297908238', 'Peso', '5151.27');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Quintin', 'Thornborrow', 'switch', '4903063486319542', 'Hryvnia', '38213.48');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Emilee', 'Hawgood', 'visa', '4041596423370832', 'Yuan Renminbi', '63999.02');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Candida', 'Katt', 'jcb', '3543377492985023', 'Euro', '98025.58');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Gertie', 'Cottier', 'laser', '630485302829274081', 'Krona', '81810.70');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Sigmund', 'Trevna', 'diners-club-enroute', '201670947119175', 'Boliviano', '47630.05');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Roth', 'Allbut', 'visa', '4041372628210177', 'Yuan Renminbi', '38378.33');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Elaine', 'Grundon', 'jcb', '3576235062664966', 'Lek', '98517.60');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Kelby', 'Fearnsides', 'instapayment', '6374635664740063', 'Euro', '53363.59');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Sheridan', 'Yglesia', 'jcb', '3531670970911097', 'Euro', '23313.86');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Gennie', 'Faire', 'jcb', '3568259261570675', 'Peso', '53777.41');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Florette', 'Rampton', 'jcb', '3538885723146543', 'Rupiah', '91340.25');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Denis', 'Fairholme', 'diners-club-enroute', '201954264252086', 'Yen', '65291.45');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Rurik', 'Bottini', 'jcb', '3565994792514544', 'Yuan Renminbi', '84486.57');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Ashla', 'Greenin', 'jcb', '3584210171844304', 'Real', '25767.54');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Shadow', 'Windham', 'maestro', '5020976606045289045', 'Ruble', '4990.75');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Fernande', 'Crozier', 'jcb', '3578880700944698', 'Franc', '69244.51');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Patrice', 'Guard', 'jcb', '3561343426895248', 'Euro', '6283.08');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Deva', 'Walework', 'maestro', '630447777076500386', 'Yuan Renminbi', '74457.15');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Neala', 'Lyal', 'jcb', '3587206812833976', 'Shekel', '12124.51');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Letta', 'Wasmer', 'jcb', '3535724914464915', 'Naira', '1349.62');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Orrin', 'Grigorini', 'jcb', '3552071621182986', 'Yuan Renminbi', '99404.22');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Marcelo', 'Drayton', 'maestro', '5893148184132583', 'Peso', '378.02');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Thibaut', 'Oxnam', 'maestro', '503848535890557857', 'Som', '34606.41');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Malorie', 'Felten', 'visa-electron', '4913201518763034', 'Rupiah', '70562.64');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Alethea', 'Hegges', 'jcb', '3551434344828833', 'Ruble', '8320.68');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Binni', 'Clogg', 'jcb', '3565246531665222', 'Ruble', '25696.14');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Muriel', 'Aberkirder', 'americanexpress', '372301398708273', 'Peso', '54249.36');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Reid', 'Veltmann', 'laser', '6771027442296407789', 'Euro', '83343.92');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Dalton', 'Crabb', 'visa', '4017950806034', 'Sol', '34943.84');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Lissi', 'Benedicte', 'visa-electron', '4026242882386394', 'Krona', '42180.15');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Vivien', 'Greiser', 'jcb', '3528703201265259', 'Pound', '78470.81');
insert into customers (first_name, last_name, credit_card_type, credit_card_no, currency, amount_spent) values ('Faustine', 'Marchenko', 'jcb', '3529275820982803', 'Euro', '19108.39');

/*To insert 100 rows of data for the retail table */
insert into retail (customerid, gender, country, retail_type) values (1, 'Female', 'South Korea', 'Kids');
insert into retail (customerid, gender, country, retail_type) values (2, 'Female', 'Burundi', 'Computers');
insert into retail (customerid, gender, country, retail_type) values (3, 'Female', 'Brazil', 'Games');
insert into retail (customerid, gender, country, retail_type) values (4, 'Female', 'China', 'Electronics');
insert into retail (customerid, gender, country, retail_type) values (5, 'Male', 'Philippines', 'Industrial');
insert into retail (customerid, gender, country, retail_type) values (6, 'Male', 'Greece', 'Grocery');
insert into retail (customerid, gender, country, retail_type) values (7, 'Male', 'China', 'Electronics');
insert into retail (customerid, gender, country, retail_type) values (8, 'Female', 'China', 'Music');
insert into retail (customerid, gender, country, retail_type) values (9, 'Female', 'China', 'Clothing');
insert into retail (customerid, gender, country, retail_type) values (10, 'Female', 'France', 'Movies');
insert into retail (customerid, gender, country, retail_type) values (11, 'Female', 'China', 'Games');
insert into retail (customerid, gender, country, retail_type) values (12, 'Male', 'China', 'Grocery');
insert into retail (customerid, gender, country, retail_type) values (13, 'Female', 'Portugal', 'Tools');
insert into retail (customerid, gender, country, retail_type) values (14, 'Female', 'Ukraine', 'Electronics');
insert into retail (customerid, gender, country, retail_type) values (15, 'Male', 'China', 'Movies');
insert into retail (customerid, gender, country, retail_type) values (16, 'Male', 'Philippines', 'Kids');
insert into retail (customerid, gender, country, retail_type) values (17, 'Male', 'Russia', 'Computers');
insert into retail (customerid, gender, country, retail_type) values (18, 'Male', 'Indonesia', 'Games');
insert into retail (customerid, gender, country, retail_type) values (19, 'Female', 'Portugal', 'Games');
insert into retail (customerid, gender, country, retail_type) values (20, 'Male', 'China', 'Books');
insert into retail (customerid, gender, country, retail_type) values (21, 'Female', 'Brazil', 'Toys');
insert into retail (customerid, gender, country, retail_type) values (22, 'Male', 'Sri Lanka', 'Music');
insert into retail (customerid, gender, country, retail_type) values (23, 'Female', 'Ukraine', 'Industrial');
insert into retail (customerid, gender, country, retail_type) values (24, 'Female', 'China', 'Garden');
insert into retail (customerid, gender, country, retail_type) values (25, 'Male', 'Vietnam', 'Electronics');
insert into retail (customerid, gender, country, retail_type) values (26, 'Female', 'Indonesia', 'Sports');
insert into retail (customerid, gender, country, retail_type) values (27, 'Female', 'Portugal', 'Garden');
insert into retail (customerid, gender, country, retail_type) values (28, 'Female', 'Netherlands', 'Baby');
insert into retail (customerid, gender, country, retail_type) values (29, 'Female', 'China', 'Home');
insert into retail (customerid, gender, country, retail_type) values (30, 'Male', 'Madagascar', 'Electronics');
insert into retail (customerid, gender, country, retail_type) values (31, 'Male', 'Malaysia', 'Kids');
insert into retail (customerid, gender, country, retail_type) values (32, 'Female', 'China', 'Jewelry');
insert into retail (customerid, gender, country, retail_type) values (33, 'Male', 'Ukraine', 'Sports');
insert into retail (customerid, gender, country, retail_type) values (34, 'Female', 'Colombia', 'Home');
insert into retail (customerid, gender, country, retail_type) values (35, 'Male', 'Ukraine', 'Computers');
insert into retail (customerid, gender, country, retail_type) values (36, 'Male', 'China', 'Shoes');
insert into retail (customerid, gender, country, retail_type) values (37, 'Female', 'Peru', 'Health');
insert into retail (customerid, gender, country, retail_type) values (38, 'Male', 'Brazil', 'Kids');
insert into retail (customerid, gender, country, retail_type) values (39, 'Male', 'China', 'Garden');
insert into retail (customerid, gender, country, retail_type) values (40, 'Male', 'Peru', 'Jewelry');
insert into retail (customerid, gender, country, retail_type) values (41, 'Male', 'Poland', 'Outdoors');
insert into retail (customerid, gender, country, retail_type) values (42, 'Male', 'Chad', 'Music');
insert into retail (customerid, gender, country, retail_type) values (43, 'Female', 'China', 'Outdoors');
insert into retail (customerid, gender, country, retail_type) values (44, 'Male', 'Morocco', 'Home');
insert into retail (customerid, gender, country, retail_type) values (45, 'Male', 'Serbia', 'Music');
insert into retail (customerid, gender, country, retail_type) values (46, 'Male', 'Russia', 'Shoes');
insert into retail (customerid, gender, country, retail_type) values (47, 'Male', 'China', 'Music');
insert into retail (customerid, gender, country, retail_type) values (48, 'Male', 'Indonesia', 'Electronics');
insert into retail (customerid, gender, country, retail_type) values (49, 'Male', 'Russia', 'Garden');
insert into retail (customerid, gender, country, retail_type) values (50, 'Female', 'Japan', 'Tools');
insert into retail (customerid, gender, country, retail_type) values (51, 'Male', 'China', 'Tools');
insert into retail (customerid, gender, country, retail_type) values (52, 'Male', 'Ukraine', 'Electronics');
insert into retail (customerid, gender, country, retail_type) values (53, 'Female', 'Morocco', 'Computers');
insert into retail (customerid, gender, country, retail_type) values (54, 'Female', 'Brazil', 'Automotive');
insert into retail (customerid, gender, country, retail_type) values (55, 'Male', 'Brazil', 'Beauty');
insert into retail (customerid, gender, country, retail_type) values (56, 'Female', 'Brazil', 'Automotive');
insert into retail (customerid, gender, country, retail_type) values (57, 'Female', 'Poland', 'Kids');
insert into retail (customerid, gender, country, retail_type) values (58, 'Male', 'Sweden', 'Games');
insert into retail (customerid, gender, country, retail_type) values (59, 'Female', 'Bhutan', 'Toys');
insert into retail (customerid, gender, country, retail_type) values (60, 'Male', 'Indonesia', 'Music');
insert into retail (customerid, gender, country, retail_type) values (61, 'Male', 'Micronesia', 'Health');
insert into retail (customerid, gender, country, retail_type) values (62, 'Female', 'Thailand', 'Outdoors');
insert into retail (customerid, gender, country, retail_type) values (63, 'Female', 'Philippines', 'Movies');
insert into retail (customerid, gender, country, retail_type) values (64, 'Male', 'Sweden', 'Health');
insert into retail (customerid, gender, country, retail_type) values (65, 'Male', 'Costa Rica', 'Beauty');
insert into retail (customerid, gender, country, retail_type) values (66, 'Female', 'Bosnia and Herzegovina', 'Health');
insert into retail (customerid, gender, country, retail_type) values (67, 'Female', 'Serbia', 'Home');
insert into retail (customerid, gender, country, retail_type) values (68, 'Male', 'China', 'Toys');
insert into retail (customerid, gender, country, retail_type) values (69, 'Male', 'Iran', 'Music');
insert into retail (customerid, gender, country, retail_type) values (70, 'Male', 'Brazil', 'Toys');
insert into retail (customerid, gender, country, retail_type) values (71, 'Female', 'China', 'Sports');
insert into retail (customerid, gender, country, retail_type) values (72, 'Female', 'China', 'Music');
insert into retail (customerid, gender, country, retail_type) values (73, 'Female', 'China', 'Health');
insert into retail (customerid, gender, country, retail_type) values (74, 'Female', 'Macedonia', 'Automotive');
insert into retail (customerid, gender, country, retail_type) values (75, 'Female', 'Serbia', 'Music');
insert into retail (customerid, gender, country, retail_type) values (76, 'Male', 'Macedonia', 'Outdoors');
insert into retail (customerid, gender, country, retail_type) values (77, 'Female', 'China', 'Books');
insert into retail (customerid, gender, country, retail_type) values (78, 'Female', 'Norway', 'Garden');
insert into retail (customerid, gender, country, retail_type) values (79, 'Female', 'Canada', 'Books');
insert into retail (customerid, gender, country, retail_type) values (80, 'Female', 'Portugal', 'Health');
insert into retail (customerid, gender, country, retail_type) values (81, 'Female', 'Philippines', 'Electronics');
insert into retail (customerid, gender, country, retail_type) values (82, 'Male', 'Finland', 'Jewelry');
insert into retail (customerid, gender, country, retail_type) values (83, 'Male', 'China', 'Toys');
insert into retail (customerid, gender, country, retail_type) values (84, 'Female', 'Peru', 'Tools');
insert into retail (customerid, gender, country, retail_type) values (85, 'Male', 'Russia', 'Automotive');
insert into retail (customerid, gender, country, retail_type) values (86, 'Female', 'France', 'Baby');
insert into retail (customerid, gender, country, retail_type) values (87, 'Female', 'Indonesia', 'Toys');
insert into retail (customerid, gender, country, retail_type) values (88, 'Female', 'Montenegro', 'Books');
insert into retail (customerid, gender, country, retail_type) values (89, 'Female', 'Serbia', 'Kids');
insert into retail (customerid, gender, country, retail_type) values (90, 'Female', 'China', 'Jewelry');
insert into retail (customerid, gender, country, retail_type) values (91, 'Male', 'Mexico', 'Grocery');
insert into retail (customerid, gender, country, retail_type) values (92, 'Female', 'China', 'Outdoors');
insert into retail (customerid, gender, country, retail_type) values (93, 'Female', 'Honduras', 'Outdoors');
insert into retail (customerid, gender, country, retail_type) values (94, 'Female', 'China', 'Health');
insert into retail (customerid, gender, country, retail_type) values (95, 'Female', 'Sweden', 'Shoes');
insert into retail (customerid, gender, country, retail_type) values (96, 'Male', 'Malaysia', 'Kids');
insert into retail (customerid, gender, country, retail_type) values (97, 'Male', 'Colombia', 'Automotive');
insert into retail (customerid, gender, country, retail_type) values (98, 'Female', 'Russia', 'Music');
insert into retail (customerid, gender, country, retail_type) values (99, 'Male', 'United States', 'Grocery');
insert into retail (customerid, gender, country, retail_type) values (100, 'Female', 'Slovenia', 'Shoes');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/*To cross join the customers table and the retail table and store in a table called temporary 
  Then randomly select 1000 rows out of 10,000 rows of the credit card and customer identification information from the temporary table and insert them into the transaction table. */ 
  
INSERT INTO transactions
SELECT credit_card_no, customerid 
FROM 
	(SELECT c.credit_card_no, r.customerid
	FROM customers AS c 
	CROSS JOIN retail AS r) AS temporary
ORDER BY RANDOM ()
LIMIT 1000; 


