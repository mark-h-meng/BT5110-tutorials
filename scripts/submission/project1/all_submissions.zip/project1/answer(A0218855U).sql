/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/

/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*

With evolving variants of the viruses, COVID-19 situation is still severe in most of the regions. 
Therefore, prompt identification of close contacts is critical to control the virus spread and potential outbreak. 
Many countries have established the sophisticated contact tracing system including Singapore using TraceTogether. 
In this project, I would like to simulate a small portion of the database that might be used in the contact tracing process.

Entity set 1 is defined as ‘personal’, which contains the personal particulars such as nric_id, first_name, last_name, gender, contact_number, and vacination_status. 
‘nric_id’ is set PRIMARY KEY as it is the unique identifier of a person. 
Take note due to Mockaroo data generation constraints, the format of the nric_id and contact_number is not the same as what they are like in reality.

Entity set 2 is defined as ‘loc’, which includes the list of locations that confirmed cases have visited containing attributes like place, date, time, no_of_confirmed_case, no_of_quarantined_case. 
Combining with date info, we will be able to identify which area and time period have risk exposure. 
The info on how many confirmed cases and how many quarantined cases for each location is also counted. 
Combination of ‘place’ and ‘date’ is the PRIMARY KEY for this table. 
For simplicity, I did not specify the timing though in reality we should have more detailed timing of each visitor to narrow the tracking. 

Relationship table ‘visit’ will link each person to the location and date with risk exposure. 
In practice, when we compare this table with individual TraceTogether history, we will be able to alert the individuals if there is any risk exposure to them. 
In this case, there are no other attributes in the relationship table. 


*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

create table personal (
	nric_id VARCHAR(50) PRIMARY KEY,
	first_name VARCHAR(50),
	last_name VARCHAR(50),
	gender VARCHAR(50),
	contact_number VARCHAR(50),
	vacination_status VARCHAR(50));

create table loc (
	place VARCHAR(50),
	date DATE,
	no_of_confirmed_case INT,
	no_of_quarantined_case INT,
	PRIMARY KEY (place, date));

create table visit (
	nric_id VARCHAR(50) REFERENCES personal (nric_id),
	place VARCHAR(50),
	date DATE,	
	FOREIGN KEY (place, date) REFERENCES loc (place, date));

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* Insert 100 enties for table personal*/
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('09-0600269', 'Meghann', 'Baynham', 'Genderfluid', '(362) 1657025', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('48-5325276', 'Marnia', 'Filyakov', 'Genderfluid', '(463) 7351439', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('51-2191296', 'Anthe', 'Batha', 'Non-binary', '(521) 1297378', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('77-5712352', 'Milton', 'Berre', 'Male', '(323) 9738833', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('31-7528279', 'Wilbert', 'Handrock', 'Genderqueer', '(311) 2863228', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('05-5344399', 'Leonanie', 'Stratiff', 'Genderfluid', '(695) 6848834', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('96-8570391', 'Mariann', 'Danovich', 'Bigender', '(649) 6121063', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('42-1951384', 'Afton', 'Sherer', 'Bigender', '(370) 6657197', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('74-9114029', 'Vinny', 'Keir', 'Female', '(276) 3818805', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('93-5386783', 'Herold', 'Pentecust', 'Genderfluid', '(455) 4113477', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('63-9823432', 'Cecilia', 'Grassi', 'Genderfluid', '(467) 7577285', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('53-3450258', 'Mitch', 'Strettle', 'Female', '(320) 8636531', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('34-8811869', 'Cameron', 'Gosden', 'Female', '(978) 6772393', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('86-5448746', 'Jobye', 'Arthan', 'Male', '(690) 9556718', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('92-6545323', 'Babs', 'Slott', 'Genderqueer', '(125) 3712758', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('69-8905430', 'Coop', 'Gomes', 'Non-binary', '(186) 6773782', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('97-9944917', 'Gaspar', 'Brownsworth', 'Genderqueer', '(917) 6703444', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('01-3263810', 'Torin', 'Stealy', 'Agender', '(839) 3621845', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('64-7018991', 'Joceline', 'Dagnan', 'Polygender', '(554) 4417391', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('14-0480790', 'Amity', 'Stiger', 'Genderqueer', '(402) 5886673', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('27-8494391', 'Aigneis', 'Lough', 'Polygender', '(562) 5186272', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('09-4003906', 'Emelia', 'MacKimmie', 'Genderqueer', '(109) 7190230', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('35-5981235', 'Larry', 'Elmhurst', 'Female', '(811) 9715619', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('86-7341404', 'Bell', 'Boss', 'Genderqueer', '(736) 2608848', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('58-2439689', 'Cyril', 'Drawmer', 'Non-binary', '(102) 4450523', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('81-5996658', 'Pinchas', 'Hollyland', 'Polygender', '(774) 3860326', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('35-3679656', 'Cher', 'Lockhurst', 'Non-binary', '(432) 2494333', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('92-7796452', 'Adelheid', 'Kestell', 'Non-binary', '(241) 4628648', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('46-5377192', 'Roxanne', 'Fanti', 'Female', '(556) 8223191', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('36-0791265', 'Emilee', 'Janowicz', 'Bigender', '(578) 7948873', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('46-5157926', 'Victoria', 'Birkhead', 'Genderfluid', '(279) 3764258', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('30-6733836', 'Gothart', 'MacAdam', 'Agender', '(503) 1596091', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('74-5240219', 'Zolly', 'Morforth', 'Genderqueer', '(427) 8494227', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('21-2328511', 'Stanly', 'Dow', 'Non-binary', '(837) 5133825', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('23-8045989', 'Pammi', 'Scading', 'Agender', '(546) 7284792', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('07-5503115', 'Joni', 'Chiswell', 'Male', '(973) 5527026', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('14-9975648', 'Brandon', 'Millott', 'Non-binary', '(517) 6779228', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('28-4649800', 'Collie', 'Forsdike', 'Non-binary', '(218) 8138529', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('80-6254043', 'Grady', 'Pybus', 'Male', '(983) 5726400', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('29-9901379', 'Reeba', 'Overel', 'Bigender', '(882) 4088680', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('11-7310173', 'Kylie', 'Neeve', 'Female', '(733) 8808903', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('03-2562798', 'Deana', 'Mottershead', 'Male', '(857) 3057825', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('14-2602342', 'Jermayne', 'Widdowfield', 'Genderfluid', '(162) 1251028', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('68-5988574', 'Berky', 'Buckley', 'Genderqueer', '(142) 4611889', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('62-6249791', 'Kaiser', 'Rushford', 'Female', '(349) 5922370', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('43-2714061', 'Jamal', 'Hornung', 'Non-binary', '(446) 9724442', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('51-4145304', 'Friedrich', 'Zealander', 'Genderqueer', '(661) 6415710', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('43-7083352', 'Waly', 'Capnerhurst', 'Genderfluid', '(561) 9715344', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('45-6176227', 'Antoine', 'Prudham', 'Female', '(149) 6971111', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('59-3511280', 'Toddy', 'Yarnton', 'Non-binary', '(424) 7410989', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('42-4339698', 'Danyelle', 'Oulet', 'Male', '(191) 9952894', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('11-1754518', 'Miguelita', 'Ellerby', 'Non-binary', '(420) 1057848', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('67-5875800', 'Alix', 'Paviour', 'Bigender', '(308) 5349087', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('37-8696026', 'Eugenius', 'Soggee', 'Genderfluid', '(249) 3210577', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('34-0346868', 'Hester', 'Wyman', 'Non-binary', '(275) 9041281', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('94-7364720', 'Westley', 'Philimore', 'Male', '(848) 2978331', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('25-5305394', 'Renee', 'Pusey', 'Agender', '(476) 9658344', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('55-7546685', 'Iseabal', 'Fulger', 'Polygender', '(479) 1564633', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('87-5938296', 'Norry', 'Wabe', 'Agender', '(697) 7913703', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('46-6093731', 'Obadiah', 'Tolossi', 'Non-binary', '(391) 9442898', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('47-5215491', 'Hewe', 'Behr', 'Agender', '(169) 5304032', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('41-3520868', 'Annabella', 'Phizakarley', 'Female', '(638) 2360179', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('48-1136895', 'Stevena', 'Worstall', 'Male', '(963) 4988762', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('15-0917885', 'Dacia', 'Gregoletti', 'Genderqueer', '(711) 2343568', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('85-1693815', 'Odetta', 'Mayward', 'Bigender', '(937) 3661717', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('23-1564840', 'Janeva', 'Francesconi', 'Agender', '(854) 6672092', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('55-1551535', 'Florette', 'Hallas', 'Agender', '(991) 5593285', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('03-6842543', 'Denna', 'Burris', 'Polygender', '(134) 6046364', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('10-1972495', 'Andrus', 'Neylan', 'Male', '(908) 5314199', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('76-4946367', 'Benjamen', 'Warrior', 'Genderqueer', '(500) 5324580', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('56-8749622', 'Shirline', 'Kettoe', 'Bigender', '(678) 5766816', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('37-8902807', 'Marin', 'Warbey', 'Female', '(315) 2383047', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('07-0505346', 'Antoinette', 'Zucker', 'Genderfluid', '(850) 9871479', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('55-6854609', 'Christina', 'Coverley', 'Female', '(690) 5654875', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('11-0435851', 'Winnie', 'Ruddick', 'Male', '(764) 5890945', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('30-9234125', 'Gus', 'Finch', 'Female', '(767) 5947074', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('84-5387516', 'Veradis', 'Shackel', 'Genderfluid', '(931) 2034484', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('27-8503713', 'Trista', 'Staddon', 'Genderfluid', '(525) 9663761', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('80-1764493', 'Barney', 'Langford', 'Female', '(984) 6616964', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('99-8665640', 'Whitman', 'Formie', 'Non-binary', '(576) 9573527', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('71-7747427', 'Silvanus', 'Calway', 'Polygender', '(502) 8472243', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('22-1376015', 'Rog', 'Denyukhin', 'Genderfluid', '(640) 3420323', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('37-3633613', 'Cathee', 'Pyett', 'Genderqueer', '(182) 5597431', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('87-2789568', 'Marcelo', 'Goldson', 'Agender', '(675) 4281478', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('35-7568506', 'Fifine', 'Wiz', 'Genderfluid', '(431) 3216585', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('68-8739040', 'Tiler', 'Stiggers', 'Genderfluid', '(912) 9011032', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('13-7424744', 'Clayton', 'Cheevers', 'Genderqueer', '(627) 1241812', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('47-6825154', 'Bathsheba', 'Pulsford', 'Bigender', '(750) 4318111', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('14-6053598', 'Katine', 'Dwelley', 'Agender', '(805) 6241987', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('56-9933221', 'Ashby', 'Eidelman', 'Female', '(413) 9790439', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('39-2371458', 'Dennie', 'Tompion', 'Male', '(130) 3010756', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('80-2414969', 'Verena', 'Yarn', 'Female', '(823) 9468196', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('30-2941459', 'Ambrosio', 'Elsmere', 'Agender', '(989) 5692946', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('41-1944675', 'Rhett', 'Wanjek', 'Genderfluid', '(783) 3931035', true);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('67-2682605', 'Tiffanie', 'Weigh', 'Non-binary', '(866) 1135691', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('31-9958384', 'Lyndy', 'Roakes', 'Genderqueer', '(723) 8075974', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('62-7883857', 'Mufi', 'Spawton', 'Bigender', '(638) 9551149', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('41-5837886', 'Demetra', 'Coe', 'Genderfluid', '(889) 1366062', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('60-1756926', 'Corissa', 'Shew', 'Male', '(312) 3833378', false);
insert into personal (nric_id, first_name, last_name, gender, contact_number, vacination_status) values ('59-3003141', 'Giustina', 'Sothern', 'Non-binary', '(535) 4337052', true);

select * from personal;

/* Insert 100 enties for table loc*/
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('857 Hooker Junction', '2021-08-13', 2, 37);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('04226 Oriole Trail', '2021-08-14', 3, 3);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('9 Swallow Hill', '2021-08-16', 1, 20);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('08730 Calypso Point', '2021-08-16', 4, 37);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('820 Browning Point', '2021-08-17', 3, 16);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('01 Spenser Park', '2021-08-15', 2, 45);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('80087 Utah Road', '2021-08-14', 4, 38);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('74 Dixon Drive', '2021-08-20', 1, 6);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('276 Macpherson Avenue', '2021-08-15', 1, 27);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('8 Roxbury Pass', '2021-08-12', 1, 41);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('69352 Mandrake Parkway', '2021-08-16', 5, 21);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('45942 Jay Center', '2021-08-17', 5, 29);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('5508 Heath Road', '2021-08-16', 4, 50);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('7 Anderson Road', '2021-08-21', 2, 3);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('668 Erie Place', '2021-08-10', 1, 21);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('6138 Lakeland Park', '2021-08-15', 1, 47);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('4553 Shelley Way', '2021-08-14', 4, 37);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('72130 Anderson Road', '2021-08-16', 2, 25);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('10 Norway Maple Place', '2021-08-19', 4, 35);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('25036 Dorton Way', '2021-08-13', 1, 6);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('1933 Donald Drive', '2021-08-15', 5, 27);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('64 Express Trail', '2021-08-21', 1, 22);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('02 Talisman Park', '2021-08-14', 1, 15);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('9 Rutledge Court', '2021-08-12', 2, 23);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('9287 Havey Circle', '2021-08-09', 3, 48);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('4 Eliot Road', '2021-08-18', 4, 43);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('565 Comanche Point', '2021-08-18', 5, 22);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('7208 Lillian Crossing', '2021-08-15', 4, 45);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('21892 Dawn Terrace', '2021-08-16', 2, 33);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('59 Westerfield Place', '2021-08-15', 3, 46);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('46261 Emmet Pass', '2021-08-13', 5, 27);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('19641 Oak Valley Lane', '2021-08-16', 2, 32);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('32241 Sugar Road', '2021-08-17', 1, 37);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('6 Fairfield Parkway', '2021-08-11', 2, 30);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('084 Buena Vista Center', '2021-08-19', 5, 2);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('00513 Hazelcrest Road', '2021-08-10', 5, 45);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('36 Ridgeview Terrace', '2021-08-17', 5, 2);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('6094 Milwaukee Park', '2021-08-21', 1, 5);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('4239 Raven Hill', '2021-08-14', 5, 31);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('36643 Myrtle Point', '2021-08-16', 5, 29);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('91477 Westerfield Pass', '2021-08-09', 2, 17);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('8309 Sloan Trail', '2021-08-20', 1, 34);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('3 Mockingbird Court', '2021-08-09', 5, 27);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('24 Gina Place', '2021-08-11', 5, 13);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('29 Pepper Wood Pass', '2021-08-16', 2, 45);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('0051 Elmside Drive', '2021-08-20', 5, 3);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('5 Express Road', '2021-08-10', 4, 24);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('318 Eggendart Trail', '2021-08-17', 3, 23);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('49367 David Pass', '2021-08-15', 4, 11);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('4229 Bultman Alley', '2021-08-16', 2, 41);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('2778 Oak Valley Lane', '2021-08-19', 1, 35);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('17 Mockingbird Avenue', '2021-08-20', 1, 8);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('0220 Browning Crossing', '2021-08-13', 3, 50);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('89 Aberg Center', '2021-08-15', 2, 42);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('388 Jenna Alley', '2021-08-11', 3, 40);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('5 Mallory Pass', '2021-08-18', 1, 8);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('2 Hudson Park', '2021-08-16', 4, 39);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('843 Oriole Place', '2021-08-11', 4, 37);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('355 Fuller Drive', '2021-08-21', 4, 11);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('56483 Glacier Hill Center', '2021-08-09', 5, 12);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('45 Gateway Place', '2021-08-16', 1, 42);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('4 Dennis Drive', '2021-08-12', 2, 32);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('188 Mendota Crossing', '2021-08-21', 5, 24);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('63712 Kensington Drive', '2021-08-19', 3, 43);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('813 Bowman Point', '2021-08-21', 5, 20);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('44167 Farmco Trail', '2021-08-17', 1, 44);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('8789 Summer Ridge Pass', '2021-08-09', 3, 45);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('1829 Florence Park', '2021-08-13', 4, 3);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('4 Ridgeview Lane', '2021-08-11', 1, 47);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('6230 Twin Pines Pass', '2021-08-20', 3, 29);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('04 Pepper Wood Trail', '2021-08-13', 4, 3);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('9666 Loomis Alley', '2021-08-18', 3, 3);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('1281 Anniversary Circle', '2021-08-13', 4, 15);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('63014 Lighthouse Bay Place', '2021-08-13', 4, 9);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('968 John Wall Point', '2021-08-19', 2, 36);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('312 Blackbird Place', '2021-08-20', 1, 43);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('825 Sunfield Avenue', '2021-08-16', 4, 24);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('658 Claremont Place', '2021-08-11', 1, 37);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('04 Riverside Alley', '2021-08-10', 3, 39);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('70315 Anhalt Avenue', '2021-08-15', 1, 14);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('0852 Jenna Street', '2021-08-20', 2, 17);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('73 Carey Place', '2021-08-16', 1, 32);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('94 Arapahoe Crossing', '2021-08-14', 4, 22);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('14 Shopko Trail', '2021-08-12', 2, 32);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('6301 Graedel Court', '2021-08-17', 5, 35);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('98014 Brickson Park Place', '2021-08-13', 5, 7);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('00 Emmet Place', '2021-08-21', 5, 15);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('8463 Marquette Place', '2021-08-11', 2, 25);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('307 6th Center', '2021-08-18', 4, 17);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('6240 Huxley Road', '2021-08-20', 2, 7);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('57 Paget Point', '2021-08-13', 2, 33);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('5726 Novick Terrace', '2021-08-11', 5, 23);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('06 Oxford Trail', '2021-08-14', 5, 19);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('9 Algoma Point', '2021-08-14', 1, 2);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('3127 Clove Center', '2021-08-15', 5, 1);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('58647 Reinke Avenue', '2021-08-15', 5, 11);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('2 Elgar Way', '2021-08-20', 1, 22);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('34 Redwing Center', '2021-08-13', 2, 9);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('69371 Sage Park', '2021-08-14', 4, 50);
insert into loc (place, date, no_of_confirmed_case, no_of_quarantined_case) values ('60455 Summer Ridge Terrace', '2021-08-20', 2, 35);

select * from loc;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into visit
select
	p.nric_id,
	l.place,
	l.date
from personal p cross join loc l
where random() <= 0.1 
LIMIT 1000;

select * from visit;

