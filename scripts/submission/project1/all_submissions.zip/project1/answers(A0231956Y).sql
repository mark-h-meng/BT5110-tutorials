/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/* Name: GINO MARTELLI TIU
   Student#: A0231956Y                                                  */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
	The use case is for a resource request platform for change projects in our imaginary 
	firm, Digibank. It consists of three tables: 
	
	... The'resource' table contains particulars of change mgt personnel, specifically:
		1.1. first_name
		1.2. last_name
		1.3. job_func (PM for proj mgr, BA for biz analyst, DEV for developer)
		1.4. employee_number
		1.5. email (fixed domain digibank.com using formula)
	
	... Table 'project', on the other hand, contains business owner and billing details: 
		2.1. project_id (randomized for security purposes)
		2.2. lob (line of business - e.g RBWM for retail and wealth, MKTS for markets, etc.)
		2.3. cost_center (includes the lob ticker as prefix)
		
	... Table 'alloc_req' shows skill type and staff requests for each project, in particular:
		3.1 project_id
		3.2 role_need (specific skill set required)
		3.3 resource_req (email of specific staff requested)	
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS resource(
	first_name VARCHAR(60) NOT NULL,
	last_name VARCHAR(60) NOT NULL,
	job_func VARCHAR(10) NOT NULL CHECK(job_func='PM'OR job_func='BA'OR job_func='DEV'),
	employee_number VARCHAR(13) PRIMARY KEY,
	email VARCHAR(100) NOT NULL UNIQUE);

CREATE TABLE IF NOT EXISTS project(
	project_id VARCHAR(16) PRIMARY KEY,
	lob VARCHAR(64) NOT NULL, CHECK(lob='RBWM' OR lob='COMMB'OR lob='MKTS' OR lob='DIGITAL' OR lob='REG'),
	cost_center VARCHAR(16) NOT NULL);

CREATE TABLE IF NOT EXISTS alloc_req(
	project_id VARCHAR(16) REFERENCES project(project_id),
	role_need VARCHAR(10) NOT NULL CHECK(role_need='PM' OR role_need='BA'OR role_need='DEV'),
	resource_req VARCHAR(100) REFERENCES resource(email),
	PRIMARY KEY(project_id,role_need,resource_req));

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* Populate resource table*/
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Roberto', 'Bartolini', 'DEV', '348-6112-37-1', 'roberto.bartolini@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Con', 'Lincey', 'DEV', '710-4819-27-7', 'con.lincey@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Morgan', 'Polglaze', 'DEV', '419-1897-06-6', 'morgan.polglaze@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Yehudi', 'Fletcher', 'DEV', '320-2006-08-8', 'yehudi.fletcher@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Nancie', 'Beardow', 'PM', '257-2960-39-2', 'nancie.beardow@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Kikelia', 'Clem', 'BA', '442-6971-76-8', 'kikelia.clem@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Dora', 'O''Donoghue', 'BA', '706-2475-54-1', 'dora.o''donoghue@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Tresa', 'Scotchbourouge', 'BA', '387-8282-64-7', 'tresa.scotchbourouge@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Loleta', 'Lobb', 'PM', '769-3166-02-2', 'loleta.lobb@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Oran', 'Noonan', 'BA', '693-3519-62-5', 'oran.noonan@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Jere', 'Vela', 'BA', '040-4229-29-6', 'jere.vela@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Doug', 'Maclaine', 'BA', '641-4844-47-3', 'doug.maclaine@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Vin', 'Szepe', 'DEV', '367-2514-73-3', 'vin.szepe@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Brunhilda', 'Mahomet', 'PM', '588-5269-79-3', 'brunhilda.mahomet@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Sonja', 'Struthers', 'DEV', '310-8516-83-4', 'sonja.struthers@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Bone', 'Sutliff', 'PM', '300-5560-34-5', 'bone.sutliff@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Stanton', 'Baddeley', 'DEV', '332-0251-64-3', 'stanton.baddeley@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Chrysa', 'Meeke', 'DEV', '431-4197-05-5', 'chrysa.meeke@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Marge', 'Purshouse', 'BA', '338-7453-97-6', 'marge.purshouse@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Harri', 'Pinson', 'BA', '681-2942-24-1', 'harri.pinson@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Bryn', 'Spottiswood', 'DEV', '328-7255-46-9', 'bryn.spottiswood@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Jimmie', 'Nowick', 'BA', '904-8660-03-8', 'jimmie.nowick@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Davidson', 'Riccetti', 'BA', '792-8178-39-7', 'davidson.riccetti@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Sherri', 'Wiltshier', 'PM', '937-4325-62-6', 'sherri.wiltshier@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Si', 'Hann', 'PM', '725-4085-83-9', 'si.hann@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Karla', 'Martinek', 'PM', '719-0651-29-9', 'karla.martinek@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Sunny', 'Kybird', 'DEV', '581-3222-48-4', 'sunny.kybird@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Happy', 'Von Welldun', 'DEV', '994-5208-29-5', 'happy.von welldun@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Tait', 'McInteer', 'PM', '201-9211-42-3', 'tait.mcinteer@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Casi', 'Thackeray', 'BA', '035-7596-67-3', 'casi.thackeray@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Juana', 'Parffrey', 'BA', '445-8195-26-6', 'juana.parffrey@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Merrill', 'Ida', 'BA', '351-3580-21-0', 'merrill.ida@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Andonis', 'Kidde', 'PM', '626-7377-13-9', 'andonis.kidde@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Larina', 'Sofe', 'BA', '486-3058-10-6', 'larina.sofe@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Amandi', 'Melia', 'BA', '279-2390-64-1', 'amandi.melia@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Dilly', 'Gregorio', 'PM', '716-5621-00-7', 'dilly.gregorio@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Alica', 'Kienzle', 'DEV', '608-5531-47-2', 'alica.kienzle@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Rod', 'Whiteland', 'DEV', '914-5579-12-6', 'rod.whiteland@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Nolie', 'Perazzo', 'PM', '976-7168-99-5', 'nolie.perazzo@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Moss', 'De Bernardis', 'BA', '004-0143-12-1', 'moss.de bernardis@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Allx', 'Thunderman', 'PM', '162-9874-97-3', 'allx.thunderman@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Jermain', 'Barabich', 'BA', '471-1462-19-4', 'jermain.barabich@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Dana', 'Bebis', 'PM', '246-1961-83-7', 'dana.bebis@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Ottilie', 'Ogelsby', 'PM', '678-9291-85-8', 'ottilie.ogelsby@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Lind', 'Backhouse', 'BA', '755-8675-81-3', 'lind.backhouse@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Talia', 'Chittenden', 'BA', '821-4581-51-9', 'talia.chittenden@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Clarke', 'Jerrans', 'PM', '374-6613-83-2', 'clarke.jerrans@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Kath', 'Rawsen', 'DEV', '085-5109-15-0', 'kath.rawsen@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Alexi', 'Mustoo', 'PM', '841-1833-31-3', 'alexi.mustoo@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Chadwick', 'Blankau', 'DEV', '303-9971-86-8', 'chadwick.blankau@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Adrea', 'Popham', 'DEV', '929-0864-18-8', 'adrea.popham@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Jere', 'Whear', 'PM', '135-7847-98-2', 'jere.whear@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Mauricio', 'Everil', 'BA', '164-6515-42-8', 'mauricio.everil@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Melantha', 'McBay', 'PM', '589-9977-71-1', 'melantha.mcbay@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Caritta', 'Apple', 'DEV', '449-4753-67-8', 'caritta.apple@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Atlante', 'Britner', 'BA', '123-3543-63-4', 'atlante.britner@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Ham', 'Vanin', 'BA', '673-9023-87-3', 'ham.vanin@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Adamo', 'Petry', 'PM', '106-5735-49-3', 'adamo.petry@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Selma', 'Sayes', 'BA', '894-8291-12-1', 'selma.sayes@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Gale', 'Murcutt', 'BA', '126-2746-27-1', 'gale.murcutt@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Saul', 'Fairlie', 'BA', '948-3148-26-3', 'saul.fairlie@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Maddy', 'Melody', 'BA', '057-1170-27-3', 'maddy.melody@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Christoforo', 'MacAlpyne', 'DEV', '415-5345-49-4', 'christoforo.macalpyne@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Clemens', 'Hallowes', 'BA', '876-8231-72-1', 'clemens.hallowes@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Kalli', 'Shinner', 'DEV', '724-4342-50-2', 'kalli.shinner@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Andriana', 'Padberry', 'DEV', '817-0379-14-5', 'andriana.padberry@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Harri', 'Marchant', 'DEV', '475-3014-21-8', 'harri.marchant@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Berta', 'Bessant', 'BA', '126-6791-71-3', 'berta.bessant@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Keelby', 'Dell Casa', 'DEV', '340-6214-64-2', 'keelby.dell casa@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Halimeda', 'Guitte', 'BA', '290-7744-10-8', 'halimeda.guitte@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Rozele', 'Olerenshaw', 'DEV', '562-2928-25-3', 'rozele.olerenshaw@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Heywood', 'Legon', 'DEV', '513-6227-22-7', 'heywood.legon@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Cort', 'Scothorne', 'DEV', '170-6685-71-7', 'cort.scothorne@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Celestina', 'Drinnan', 'PM', '926-2366-06-1', 'celestina.drinnan@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Julissa', 'Hugland', 'DEV', '997-9283-65-7', 'julissa.hugland@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Traci', 'Rosell', 'BA', '951-2422-53-3', 'traci.rosell@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Andie', 'Ashall', 'DEV', '588-7569-12-0', 'andie.ashall@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Calypso', 'Cunniam', 'PM', '515-8395-26-5', 'calypso.cunniam@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Ardine', 'Cauthra', 'DEV', '876-9122-03-3', 'ardine.cauthra@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Montgomery', 'Biaggioli', 'BA', '569-8526-31-8', 'montgomery.biaggioli@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Carny', 'Szymanek', 'PM', '938-9875-69-6', 'carny.szymanek@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Nixie', 'Windham', 'PM', '184-0305-17-5', 'nixie.windham@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Juanita', 'Westnage', 'DEV', '139-7579-23-9', 'juanita.westnage@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Dorree', 'Karpman', 'PM', '214-4836-43-5', 'dorree.karpman@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Nichole', 'Pughe', 'PM', '906-6896-54-8', 'nichole.pughe@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Fred', 'Caley', 'DEV', '146-1391-13-2', 'fred.caley@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Ernestus', 'Jillett', 'PM', '493-8865-08-6', 'ernestus.jillett@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Marysa', 'Riguard', 'DEV', '340-5967-58-3', 'marysa.riguard@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Darryl', 'Southern', 'BA', '200-5331-21-0', 'darryl.southern@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Adora', 'Rebanks', 'DEV', '585-1972-69-0', 'adora.rebanks@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Carlita', 'Benham', 'PM', '037-4481-19-4', 'carlita.benham@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Emeline', 'Bamfield', 'DEV', '419-9890-82-5', 'emeline.bamfield@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Deerdre', 'Willan', 'PM', '649-6465-09-8', 'deerdre.willan@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Margot', 'Griniov', 'BA', '199-7348-44-4', 'margot.griniov@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Johannah', 'Hyndson', 'PM', '316-8243-35-9', 'johannah.hyndson@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Joye', 'Josefson', 'BA', '154-5132-10-4', 'joye.josefson@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Britt', 'McFarlane', 'PM', '730-6229-83-7', 'britt.mcfarlane@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Powell', 'Stabler', 'BA', '218-3758-43-0', 'powell.stabler@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Lilian', 'Deyes', 'PM', '745-2511-92-0', 'lilian.deyes@digibank.com');
insert into resource (first_name, last_name, job_func, employee_number, email) values ('Victoria', 'Isakov', 'BA', '701-1472-37-0', 'victoria.isakov@digibank.com');

/* Populate project table*/

insert into project (project_id, lob, cost_center) values ('059-936e-11-6', 'DIGITAL', 'DIGITAL-1284-J6');
insert into project (project_id, lob, cost_center) values ('678-27En-70-7', 'REG', 'REG-6305-X1');
insert into project (project_id, lob, cost_center) values ('826-13Wr-36-1', 'MKTS', 'MKTS-6697-W9');
insert into project (project_id, lob, cost_center) values ('716-645p-62-7', 'RBWM', 'RBWM-8425-B6');
insert into project (project_id, lob, cost_center) values ('242-47Ne-17-7', 'REG', 'REG-1160-O7');
insert into project (project_id, lob, cost_center) values ('297-987t-20-9', 'DIGITAL', 'DIGITAL-0690-T1');
insert into project (project_id, lob, cost_center) values ('358-065r-08-6', 'RBWM', 'RBWM-7317-I7');
insert into project (project_id, lob, cost_center) values ('053-46Xe-83-8', 'MKTS', 'MKTS-4558-M2');
insert into project (project_id, lob, cost_center) values ('156-51My-62-3', 'COMMB', 'COMMB-6864-X6');
insert into project (project_id, lob, cost_center) values ('231-24Ok-56-0', 'DIGITAL', 'DIGITAL-7731-X5');
insert into project (project_id, lob, cost_center) values ('156-161w-24-1', 'COMMB', 'COMMB-8012-O1');
insert into project (project_id, lob, cost_center) values ('833-79Ox-73-6', 'DIGITAL', 'DIGITAL-3066-S3');
insert into project (project_id, lob, cost_center) values ('488-18Kf-36-6', 'MKTS', 'MKTS-0478-Q5');
insert into project (project_id, lob, cost_center) values ('140-99Ob-57-1', 'RBWM', 'RBWM-4614-A0');
insert into project (project_id, lob, cost_center) values ('226-94Yu-07-6', 'RBWM', 'RBWM-0827-C3');
insert into project (project_id, lob, cost_center) values ('062-91Eo-62-4', 'RBWM', 'RBWM-7512-L0');
insert into project (project_id, lob, cost_center) values ('460-22Dv-56-0', 'REG', 'REG-5625-L4');
insert into project (project_id, lob, cost_center) values ('312-99Id-06-4', 'RBWM', 'RBWM-0796-Y2');
insert into project (project_id, lob, cost_center) values ('707-85Kv-55-4', 'REG', 'REG-5869-P3');
insert into project (project_id, lob, cost_center) values ('868-500t-86-2', 'MKTS', 'MKTS-3269-I5');
insert into project (project_id, lob, cost_center) values ('287-620v-00-5', 'REG', 'REG-0591-G4');
insert into project (project_id, lob, cost_center) values ('588-40Zs-88-4', 'RBWM', 'RBWM-8364-B8');
insert into project (project_id, lob, cost_center) values ('754-09Bd-29-7', 'COMMB', 'COMMB-9554-I7');
insert into project (project_id, lob, cost_center) values ('599-27Uv-93-8', 'REG', 'REG-6253-C6');
insert into project (project_id, lob, cost_center) values ('149-78Zr-04-5', 'DIGITAL', 'DIGITAL-1563-L2');
insert into project (project_id, lob, cost_center) values ('319-36Bm-61-4', 'COMMB', 'COMMB-7009-V1');
insert into project (project_id, lob, cost_center) values ('679-09Yj-38-0', 'DIGITAL', 'DIGITAL-4724-Z4');
insert into project (project_id, lob, cost_center) values ('345-856z-20-2', 'COMMB', 'COMMB-3125-E2');
insert into project (project_id, lob, cost_center) values ('712-16Gf-14-5', 'MKTS', 'MKTS-2756-F1');
insert into project (project_id, lob, cost_center) values ('614-29Tj-83-6', 'REG', 'REG-2326-A1');
insert into project (project_id, lob, cost_center) values ('607-099n-76-1', 'COMMB', 'COMMB-7613-P6');
insert into project (project_id, lob, cost_center) values ('229-67Tk-41-8', 'REG', 'REG-1921-R1');
insert into project (project_id, lob, cost_center) values ('154-94Rg-22-0', 'DIGITAL', 'DIGITAL-9661-X3');
insert into project (project_id, lob, cost_center) values ('951-48Ak-15-9', 'MKTS', 'MKTS-8780-Z8');
insert into project (project_id, lob, cost_center) values ('952-72Rg-48-6', 'RBWM', 'RBWM-6149-D5');
insert into project (project_id, lob, cost_center) values ('853-36Fh-38-9', 'RBWM', 'RBWM-6268-U7');
insert into project (project_id, lob, cost_center) values ('093-25Ud-41-7', 'MKTS', 'MKTS-6086-L2');
insert into project (project_id, lob, cost_center) values ('873-24Og-62-3', 'RBWM', 'RBWM-9698-Y7');
insert into project (project_id, lob, cost_center) values ('932-512r-35-9', 'RBWM', 'RBWM-1314-M3');
insert into project (project_id, lob, cost_center) values ('902-10Yo-69-1', 'RBWM', 'RBWM-3039-T7');
insert into project (project_id, lob, cost_center) values ('840-79Cl-94-7', 'DIGITAL', 'DIGITAL-6100-T9');
insert into project (project_id, lob, cost_center) values ('751-52Tc-85-8', 'MKTS', 'MKTS-2072-Z0');
insert into project (project_id, lob, cost_center) values ('469-26Ga-79-7', 'MKTS', 'MKTS-6230-C3');
insert into project (project_id, lob, cost_center) values ('791-91Kn-13-6', 'COMMB', 'COMMB-3519-E9');
insert into project (project_id, lob, cost_center) values ('217-38Dr-57-3', 'MKTS', 'MKTS-5962-S1');
insert into project (project_id, lob, cost_center) values ('049-009u-72-6', 'MKTS', 'MKTS-4738-V2');
insert into project (project_id, lob, cost_center) values ('740-11Cr-39-7', 'RBWM', 'RBWM-7061-I8');
insert into project (project_id, lob, cost_center) values ('132-78Hg-47-2', 'COMMB', 'COMMB-9480-J8');
insert into project (project_id, lob, cost_center) values ('069-79Wf-10-1', 'REG', 'REG-5837-B3');
insert into project (project_id, lob, cost_center) values ('089-13Kp-71-6', 'DIGITAL', 'DIGITAL-4404-O7');
insert into project (project_id, lob, cost_center) values ('105-33Ua-71-3', 'RBWM', 'RBWM-1789-O9');
insert into project (project_id, lob, cost_center) values ('159-65Ci-39-4', 'COMMB', 'COMMB-5838-B3');
insert into project (project_id, lob, cost_center) values ('627-05Wr-98-2', 'COMMB', 'COMMB-1082-P4');
insert into project (project_id, lob, cost_center) values ('390-04Wz-94-5', 'REG', 'REG-3490-I8');
insert into project (project_id, lob, cost_center) values ('845-19Yv-68-5', 'MKTS', 'MKTS-0010-J8');
insert into project (project_id, lob, cost_center) values ('660-53Pa-71-3', 'REG', 'REG-0280-Y4');
insert into project (project_id, lob, cost_center) values ('582-26Qm-60-0', 'DIGITAL', 'DIGITAL-7546-X9');
insert into project (project_id, lob, cost_center) values ('279-49Gj-16-9', 'MKTS', 'MKTS-9403-O8');
insert into project (project_id, lob, cost_center) values ('935-87Ic-96-1', 'REG', 'REG-0195-V1');
insert into project (project_id, lob, cost_center) values ('770-53Wj-06-1', 'RBWM', 'RBWM-0432-T7');
insert into project (project_id, lob, cost_center) values ('492-39Wi-58-3', 'RBWM', 'RBWM-1593-I0');
insert into project (project_id, lob, cost_center) values ('487-40Ts-06-1', 'REG', 'REG-9489-Y1');
insert into project (project_id, lob, cost_center) values ('037-36Ju-35-8', 'REG', 'REG-4502-Y1');
insert into project (project_id, lob, cost_center) values ('098-09Nf-57-9', 'MKTS', 'MKTS-2623-D6');
insert into project (project_id, lob, cost_center) values ('194-89Ye-35-3', 'DIGITAL', 'DIGITAL-2650-E5');
insert into project (project_id, lob, cost_center) values ('881-57Fu-91-3', 'DIGITAL', 'DIGITAL-6867-Y9');
insert into project (project_id, lob, cost_center) values ('479-29Jr-90-2', 'RBWM', 'RBWM-2449-M1');
insert into project (project_id, lob, cost_center) values ('714-868u-91-3', 'MKTS', 'MKTS-8169-F3');
insert into project (project_id, lob, cost_center) values ('658-54Js-17-1', 'REG', 'REG-6875-F3');
insert into project (project_id, lob, cost_center) values ('358-51Mn-77-3', 'COMMB', 'COMMB-3918-D4');
insert into project (project_id, lob, cost_center) values ('031-35Ft-54-6', 'MKTS', 'MKTS-5733-T1');
insert into project (project_id, lob, cost_center) values ('731-76Ar-14-8', 'RBWM', 'RBWM-6961-E1');
insert into project (project_id, lob, cost_center) values ('247-30Uo-03-7', 'RBWM', 'RBWM-4861-A1');
insert into project (project_id, lob, cost_center) values ('201-40Pb-26-1', 'DIGITAL', 'DIGITAL-2830-F9');
insert into project (project_id, lob, cost_center) values ('218-223u-29-7', 'DIGITAL', 'DIGITAL-6483-L5');
insert into project (project_id, lob, cost_center) values ('580-49Wg-84-1', 'MKTS', 'MKTS-0003-L2');
insert into project (project_id, lob, cost_center) values ('820-775a-60-4', 'COMMB', 'COMMB-9836-Z2');
insert into project (project_id, lob, cost_center) values ('179-982s-42-1', 'COMMB', 'COMMB-3008-D1');
insert into project (project_id, lob, cost_center) values ('759-54Ne-67-5', 'MKTS', 'MKTS-9385-B2');
insert into project (project_id, lob, cost_center) values ('409-82Df-39-4', 'RBWM', 'RBWM-4978-M8');
insert into project (project_id, lob, cost_center) values ('253-01Wg-20-7', 'REG', 'REG-4303-K7');
insert into project (project_id, lob, cost_center) values ('310-516n-98-5', 'REG', 'REG-5978-H0');
insert into project (project_id, lob, cost_center) values ('357-15Ir-33-4', 'COMMB', 'COMMB-8902-J9');
insert into project (project_id, lob, cost_center) values ('928-32Jz-87-2', 'MKTS', 'MKTS-0663-O3');
insert into project (project_id, lob, cost_center) values ('969-84Qh-90-6', 'MKTS', 'MKTS-8348-O3');
insert into project (project_id, lob, cost_center) values ('196-40Pg-96-9', 'MKTS', 'MKTS-5249-R1');
insert into project (project_id, lob, cost_center) values ('902-26Cz-69-7', 'RBWM', 'RBWM-4456-M2');
insert into project (project_id, lob, cost_center) values ('047-204t-79-2', 'RBWM', 'RBWM-3040-H4');
insert into project (project_id, lob, cost_center) values ('418-44Sg-82-2', 'RBWM', 'RBWM-3317-H3');
insert into project (project_id, lob, cost_center) values ('735-412h-92-9', 'DIGITAL', 'DIGITAL-1457-Z0');
insert into project (project_id, lob, cost_center) values ('634-246h-99-9', 'RBWM', 'RBWM-3129-K9');
insert into project (project_id, lob, cost_center) values ('278-27Lj-77-9', 'REG', 'REG-4424-K8');
insert into project (project_id, lob, cost_center) values ('714-418a-96-5', 'MKTS', 'MKTS-0068-R5');
insert into project (project_id, lob, cost_center) values ('172-76Wd-18-8', 'DIGITAL', 'DIGITAL-5389-R0');
insert into project (project_id, lob, cost_center) values ('784-37Bn-93-2', 'MKTS', 'MKTS-4528-Q3');
insert into project (project_id, lob, cost_center) values ('850-96Ng-59-7', 'RBWM', 'RBWM-0101-Z2');
insert into project (project_id, lob, cost_center) values ('711-99Du-13-3', 'COMMB', 'COMMB-1941-K9');
insert into project (project_id, lob, cost_center) values ('902-225f-28-3', 'COMMB', 'COMMB-3905-R6');
insert into project (project_id, lob, cost_center) values ('327-09Yn-99-1', 'DIGITAL', 'DIGITAL-2589-O3');
insert into project (project_id, lob, cost_center) values ('571-673g-16-2', 'DIGITAL', 'DIGITAL-0756-V7');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO alloc_req (project_id,role_need,resource_req)
SELECT project.project_id,
		resource.job_func,
		resource.email 
FROM project,resource
ORDER BY RANDOM()
LIMIT 1000;
