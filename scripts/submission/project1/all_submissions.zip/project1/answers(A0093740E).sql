/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*

I'm creating a many-to-many relationship between actors and movies. 
One actor can appear in many movies, and one movie can have many actors.
Entity Set E1 is the actors table.
Entity Set E2 is the movies table.
Relationship Set R is movies_actors table.

actors table contains information of "actor_id (primary key), first_name, last_name, gender, and date_of_birth of the actor".
movies table contains information of "movie_id (primary key), movie_name, movie_language, and release_date of the movie".
movies_actors table contains information of "movie_id (referenced column), actor_id (referenced column), and the primary key is (movie_id plus actor_id)". 

My answers are written for PostgreSQL.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


/*Drop the following tables if they exist
DROP TABLE movies_actors;
DROP TABLE actors;
DROP TABLE movies;*/

/*Create Entity Set E1 to be the actors table*/

CREATE TABLE IF NOT EXISTS actors (
	actor_id INT PRIMARY KEY,
	first_name VARCHAR(30) NOT NULL,
	last_name VARCHAR(30) NOT NULL,
	gender CHAR(1) NOT NULL,
	date_of_birth DATE NOT NULL
);

/*Create Entity Set E2 to be the movies table*/ 

CREATE TABLE IF NOT EXISTS movies (
	movie_id INT PRIMARY KEY,
	movie_name VARCHAR(100) NOT NULL, 
	movie_language VARCHAR(50) NOT NULL,
	release_date DATE NOT NULL
);


/*Create the Relationship Set R to be movies_actors */ 

CREATE TABLE IF NOT EXISTS movies_actors (
	movie_id INT REFERENCES movies (movie_id)
	ON UPDATE CASCADE ON DELETE CASCADE
	DEFERRABLE INITIALLY DEFERRED,
	actor_id INT REFERENCES actors (actor_id)
	ON UPDATE CASCADE ON DELETE CASCADE
	DEFERRABLE INITIALLY DEFERRED,
	PRIMARY KEY (movie_id, actor_id)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/*Insert 100 data to actors table*/

insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (1, 'Esdras', 'MacKniely', 'M', '1999-01-26');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (2, 'Hans', 'Kerfoot', 'M', '2001-11-08');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (3, 'Marybeth', 'Youde', 'F', '2002-08-13');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (4, 'Chelsae', 'Gredden', 'F', '1990-10-01');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (5, 'Neall', 'Clothier', 'M', '1980-04-27');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (6, 'Kathi', 'Bruhnicke', 'F', '1996-04-24');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (7, 'Gerick', 'Northcliffe', 'M', '1987-02-20');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (8, 'Ethe', 'Tweed', 'M', '1981-07-19');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (9, 'Allayne', 'Markos', 'M', '2000-05-07');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (10, 'Loralee', 'Ebbings', 'F', '1991-01-17');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (11, 'Deidre', 'Towll', 'F', '1980-09-06');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (12, 'Jory', 'Errowe', 'M', '2005-12-13');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (13, 'Victor', 'Abbotts', 'M', '2015-08-06');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (14, 'Charlean', 'Quenby', 'F', '1993-03-15');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (15, 'Shermie', 'Charlet', 'M', '2017-11-03');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (16, 'Chery', 'Gasnoll', 'F', '2014-11-20');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (17, 'Libbi', 'Yusupov', 'F', '1995-05-11');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (18, 'Rufe', 'Harnes', 'M', '2002-02-15');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (19, 'Vito', 'Dawbery', 'M', '2012-07-10');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (20, 'Denni', 'Oen', 'F', '1997-10-23');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (21, 'Maury', 'Westraw', 'M', '1982-12-30');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (22, 'Gene', 'Dwerryhouse', 'F', '1994-01-05');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (23, 'Chryste', 'Carlone', 'F', '1992-02-04');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (24, 'Rosmunda', 'Venneur', 'F', '2001-09-05');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (25, 'Gweneth', 'Paye', 'F', '2013-12-30');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (26, 'Lane', 'Briiginshaw', 'F', '2014-01-19');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (27, 'Hertha', 'Wakeman', 'F', '1985-04-23');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (28, 'Carolyn', 'Vasilenko', 'F', '2017-04-13');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (29, 'Gleda', 'Conybear', 'F', '1998-08-07');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (30, 'Abbie', 'Sponder', 'M', '2011-09-11');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (31, 'Marco', 'Bills', 'M', '1982-12-20');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (32, 'Shoshanna', 'Giorgietto', 'F', '1980-03-03');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (33, 'Henrietta', 'Whimper', 'F', '2007-04-22');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (34, 'Hilton', 'Iffe', 'M', '1999-12-03');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (35, 'Paxon', 'Garden', 'M', '2006-06-12');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (36, 'Bridgette', 'Rizon', 'F', '2013-08-27');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (37, 'Sebastiano', 'Furley', 'M', '2015-03-07');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (38, 'Gibb', 'Noraway', 'M', '1996-03-19');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (39, 'Allys', 'Haynesford', 'F', '1991-08-05');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (40, 'Hamlen', 'Reeve', 'M', '1995-04-23');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (41, 'Shell', 'Treace', 'F', '1990-01-07');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (42, 'Julio', 'O''Driscoll', 'M', '1981-07-15');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (43, 'Heath', 'Odlin', 'M', '1981-11-17');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (44, 'Morgun', 'Joyes', 'M', '2007-01-08');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (45, 'Tabb', 'Cathro', 'M', '1997-06-29');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (46, 'Nickie', 'Simms', 'M', '1999-11-27');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (47, 'Kassia', 'Abrahamsohn', 'F', '1995-06-04');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (48, 'Jareb', 'Olivo', 'M', '1996-08-09');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (49, 'Doyle', 'Whitechurch', 'M', '1996-04-28');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (50, 'Lindsey', 'Forryan', 'M', '1987-12-18');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (51, 'Mariel', 'Clementi', 'F', '2009-05-03');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (52, 'Sam', 'Anton', 'F', '1989-10-24');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (53, 'Livia', 'Kilfoyle', 'F', '1981-12-08');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (54, 'Bord', 'Fenelon', 'M', '2004-08-24');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (55, 'Rafael', 'Tefft', 'M', '1996-01-26');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (56, 'Orly', 'Worling', 'F', '2009-03-06');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (57, 'Velvet', 'Border', 'F', '2016-10-08');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (58, 'Jyoti', 'Schoenrock', 'F', '2009-02-10');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (59, 'Viki', 'Yeo', 'F', '2019-09-09');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (60, 'Dyana', 'Tripet', 'F', '2000-11-27');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (61, 'Darrick', 'Negri', 'M', '1998-09-15');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (62, 'Roz', 'Easterby', 'F', '2010-07-25');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (63, 'Bianca', 'McTear', 'F', '2014-03-07');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (64, 'Harley', 'Lemmen', 'M', '2007-10-04');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (65, 'Osmund', 'Ribey', 'M', '1996-10-31');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (66, 'Francyne', 'Craiker', 'F', '1983-12-06');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (67, 'Andras', 'Trump', 'M', '1998-04-11');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (68, 'Shirlee', 'Morrill', 'F', '1986-09-13');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (69, 'Elden', 'Halburton', 'M', '2004-01-07');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (70, 'Torrey', 'Stolte', 'M', '2016-03-16');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (71, 'Dorette', 'Moorhead', 'F', '2014-07-31');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (72, 'Pacorro', 'Dumphries', 'M', '2004-02-08');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (73, 'Kirby', 'Brickwood', 'M', '2012-07-02');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (74, 'Esteban', 'Tredinnick', 'M', '1986-06-15');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (75, 'Jervis', 'Laboune', 'M', '2010-05-18');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (76, 'Sydney', 'Yitzowitz', 'M', '1995-11-09');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (77, 'Margo', 'Pollicatt', 'F', '1980-10-08');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (78, 'Florian', 'Scoyles', 'M', '2017-05-13');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (79, 'Eda', 'Rae', 'F', '1984-04-30');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (80, 'Pacorro', 'Shieldon', 'M', '2019-10-14');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (81, 'Udale', 'Stops', 'M', '2006-02-21');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (82, 'Allyn', 'Gershom', 'M', '1986-10-22');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (83, 'George', 'Pitcock', 'M', '1987-08-13');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (84, 'Talya', 'Triggs', 'F', '1981-03-13');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (85, 'Kimbra', 'McNay', 'F', '1997-06-13');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (86, 'Shirley', 'Girod', 'F', '2012-08-24');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (87, 'Rose', 'Orpin', 'F', '2013-04-04');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (88, 'Gabi', 'Beadle', 'F', '2011-12-09');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (89, 'Jeremias', 'Bradford', 'M', '2009-05-09');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (90, 'Millisent', 'Kobierzycki', 'F', '2013-06-16');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (91, 'Norby', 'Meaking', 'M', '1998-11-22');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (92, 'Claire', 'Storey', 'F', '1997-07-23');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (93, 'Duff', 'Fussey', 'M', '1984-12-23');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (94, 'Lammond', 'Tinsley', 'M', '2012-11-17');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (95, 'Rosemary', 'Pischel', 'F', '1996-08-18');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (96, 'Gregorio', 'Gwalter', 'M', '2019-11-24');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (97, 'Alard', 'Brockie', 'M', '2008-03-14');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (98, 'Horace', 'Note', 'M', '2013-09-19');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (99, 'Felecia', 'Wolfindale', 'F', '1987-02-11');
insert into actors (actor_id, first_name, last_name, gender, date_of_birth) values (100, 'Gabriella', 'Ilyunin', 'F', '1982-03-27');


/*Insert 100 data to movies table*/

insert into movies (movie_id, movie_name, movie_language, release_date) values (1, 'Hewitt', 'Pesek', '2012-08-03');
insert into movies (movie_id, movie_name, movie_language, release_date) values (2, 'Claudius', 'Sulley', '1995-12-02');
insert into movies (movie_id, movie_name, movie_language, release_date) values (3, 'Beale', 'O''Shirine', '2003-04-14');
insert into movies (movie_id, movie_name, movie_language, release_date) values (4, 'Joachim', 'Sauter', '2013-04-22');
insert into movies (movie_id, movie_name, movie_language, release_date) values (5, 'Mela', 'Bernard', '2014-08-24');
insert into movies (movie_id, movie_name, movie_language, release_date) values (6, 'Selina', 'Orpwood', '1992-08-08');
insert into movies (movie_id, movie_name, movie_language, release_date) values (7, 'Kessiah', 'Gee', '1992-04-17');
insert into movies (movie_id, movie_name, movie_language, release_date) values (8, 'Alie', 'Alessandrucci', '2003-02-08');
insert into movies (movie_id, movie_name, movie_language, release_date) values (9, 'Eudora', 'Knappitt', '1995-07-18');
insert into movies (movie_id, movie_name, movie_language, release_date) values (10, 'Neil', 'Fleeman', '2019-09-17');
insert into movies (movie_id, movie_name, movie_language, release_date) values (11, 'Gabriele', 'Gerbi', '1999-02-14');
insert into movies (movie_id, movie_name, movie_language, release_date) values (12, 'Elyn', 'Auger', '1992-01-27');
insert into movies (movie_id, movie_name, movie_language, release_date) values (13, 'Zeke', 'Raspel', '2018-07-11');
insert into movies (movie_id, movie_name, movie_language, release_date) values (14, 'Emelyne', 'Garrish', '1998-01-08');
insert into movies (movie_id, movie_name, movie_language, release_date) values (15, 'Darci', 'Winnister', '2005-03-09');
insert into movies (movie_id, movie_name, movie_language, release_date) values (16, 'Francoise', 'Krolle', '2000-09-24');
insert into movies (movie_id, movie_name, movie_language, release_date) values (17, 'Dyana', 'Creak', '1992-06-22');
insert into movies (movie_id, movie_name, movie_language, release_date) values (18, 'Jenifer', 'Antonnikov', '2001-08-06');
insert into movies (movie_id, movie_name, movie_language, release_date) values (19, 'Marlon', 'Gorner', '1999-02-08');
insert into movies (movie_id, movie_name, movie_language, release_date) values (20, 'Bianca', 'Panswick', '1998-03-20');
insert into movies (movie_id, movie_name, movie_language, release_date) values (21, 'Sharai', 'Mergue', '1991-06-16');
insert into movies (movie_id, movie_name, movie_language, release_date) values (22, 'Ilyssa', 'Grzegorczyk', '1995-05-14');
insert into movies (movie_id, movie_name, movie_language, release_date) values (23, 'Bari', 'Dullard', '2002-02-02');
insert into movies (movie_id, movie_name, movie_language, release_date) values (24, 'Dyanna', 'Walisiak', '1995-03-29');
insert into movies (movie_id, movie_name, movie_language, release_date) values (25, 'Grannie', 'Biasioni', '2008-06-05');
insert into movies (movie_id, movie_name, movie_language, release_date) values (26, 'Arvy', 'Girt', '1992-10-19');
insert into movies (movie_id, movie_name, movie_language, release_date) values (27, 'Barbe', 'Rubinov', '2015-07-30');
insert into movies (movie_id, movie_name, movie_language, release_date) values (28, 'Maren', 'Rankling', '2008-07-04');
insert into movies (movie_id, movie_name, movie_language, release_date) values (29, 'Sissie', 'Clemencet', '2017-09-14');
insert into movies (movie_id, movie_name, movie_language, release_date) values (30, 'Bertie', 'Rainsbury', '2003-10-25');
insert into movies (movie_id, movie_name, movie_language, release_date) values (31, 'Byrann', 'Outlaw', '1992-08-05');
insert into movies (movie_id, movie_name, movie_language, release_date) values (32, 'Ring', 'Robbins', '2001-09-01');
insert into movies (movie_id, movie_name, movie_language, release_date) values (33, 'Ileana', 'Brumhead', '2007-06-29');
insert into movies (movie_id, movie_name, movie_language, release_date) values (34, 'Nikita', 'Heitz', '2018-08-12');
insert into movies (movie_id, movie_name, movie_language, release_date) values (35, 'Vania', 'Stanyard', '1992-02-11');
insert into movies (movie_id, movie_name, movie_language, release_date) values (36, 'Blondelle', 'Le Fevre', '1997-01-19');
insert into movies (movie_id, movie_name, movie_language, release_date) values (37, 'Allyce', 'Cunnell', '1991-04-06');
insert into movies (movie_id, movie_name, movie_language, release_date) values (38, 'Ramon', 'Battie', '2007-09-17');
insert into movies (movie_id, movie_name, movie_language, release_date) values (39, 'Moll', 'Cardoe', '2003-10-14');
insert into movies (movie_id, movie_name, movie_language, release_date) values (40, 'Theresa', 'O''Cuddie', '2015-04-04');
insert into movies (movie_id, movie_name, movie_language, release_date) values (41, 'Teodoro', 'Schellig', '2010-09-04');
insert into movies (movie_id, movie_name, movie_language, release_date) values (42, 'Yurik', 'Albertson', '2016-06-02');
insert into movies (movie_id, movie_name, movie_language, release_date) values (43, 'Octavia', 'Karim', '2005-08-04');
insert into movies (movie_id, movie_name, movie_language, release_date) values (44, 'Erny', 'Forcade', '2009-06-14');
insert into movies (movie_id, movie_name, movie_language, release_date) values (45, 'Julienne', 'Hayes', '2000-03-05');
insert into movies (movie_id, movie_name, movie_language, release_date) values (46, 'Glenine', 'Laborda', '2015-09-04');
insert into movies (movie_id, movie_name, movie_language, release_date) values (47, 'Amandi', 'Trowill', '2005-02-20');
insert into movies (movie_id, movie_name, movie_language, release_date) values (48, 'Lavinie', 'Tiuit', '1998-05-15');
insert into movies (movie_id, movie_name, movie_language, release_date) values (49, 'Sylvan', 'Hartfield', '2000-12-24');
insert into movies (movie_id, movie_name, movie_language, release_date) values (50, 'Lorenza', 'Rosenau', '2000-10-31');
insert into movies (movie_id, movie_name, movie_language, release_date) values (51, 'Dallon', 'Cadney', '2013-07-17');
insert into movies (movie_id, movie_name, movie_language, release_date) values (52, 'Ilsa', 'Cobbald', '2008-07-26');
insert into movies (movie_id, movie_name, movie_language, release_date) values (53, 'Philipa', 'Tavener', '1998-04-03');
insert into movies (movie_id, movie_name, movie_language, release_date) values (54, 'Alphonse', 'Sarath', '2020-12-03');
insert into movies (movie_id, movie_name, movie_language, release_date) values (55, 'Shepperd', 'Frobisher', '1998-12-02');
insert into movies (movie_id, movie_name, movie_language, release_date) values (56, 'Marna', 'Gianulli', '2003-12-03');
insert into movies (movie_id, movie_name, movie_language, release_date) values (57, 'Ninette', 'Rudgley', '1994-03-31');
insert into movies (movie_id, movie_name, movie_language, release_date) values (58, 'Selia', 'Costain', '2017-04-03');
insert into movies (movie_id, movie_name, movie_language, release_date) values (59, 'Selma', 'Farmiloe', '2019-01-07');
insert into movies (movie_id, movie_name, movie_language, release_date) values (60, 'Carlee', 'Tucknott', '2008-06-13');
insert into movies (movie_id, movie_name, movie_language, release_date) values (61, 'Giffy', 'Ainge', '2009-08-20');
insert into movies (movie_id, movie_name, movie_language, release_date) values (62, 'Milzie', 'D''Arrigo', '2019-09-19');
insert into movies (movie_id, movie_name, movie_language, release_date) values (63, 'Jeramie', 'Connar', '2020-10-09');
insert into movies (movie_id, movie_name, movie_language, release_date) values (64, 'Jaine', 'Ellwood', '2001-07-06');
insert into movies (movie_id, movie_name, movie_language, release_date) values (65, 'Simona', 'Gillogley', '2012-09-07');
insert into movies (movie_id, movie_name, movie_language, release_date) values (66, 'Abdel', 'Eason', '2007-05-05');
insert into movies (movie_id, movie_name, movie_language, release_date) values (67, 'Bartolomeo', 'Synnot', '1995-03-17');
insert into movies (movie_id, movie_name, movie_language, release_date) values (68, 'Con', 'Whilder', '2018-08-31');
insert into movies (movie_id, movie_name, movie_language, release_date) values (69, 'Pate', 'Yepiskopov', '2017-06-12');
insert into movies (movie_id, movie_name, movie_language, release_date) values (70, 'Dante', 'Paaso', '2014-12-17');
insert into movies (movie_id, movie_name, movie_language, release_date) values (71, 'Osborne', 'Breeds', '2011-04-05');
insert into movies (movie_id, movie_name, movie_language, release_date) values (72, 'Ruggiero', 'Willcocks', '2015-03-14');
insert into movies (movie_id, movie_name, movie_language, release_date) values (73, 'Corrina', 'Pheasant', '2006-08-22');
insert into movies (movie_id, movie_name, movie_language, release_date) values (74, 'Tommie', 'Mattin', '1991-12-20');
insert into movies (movie_id, movie_name, movie_language, release_date) values (75, 'Hailey', 'Canham', '2014-11-09');
insert into movies (movie_id, movie_name, movie_language, release_date) values (76, 'Ardella', 'Tiller', '2002-09-14');
insert into movies (movie_id, movie_name, movie_language, release_date) values (77, 'Daniel', 'Gerner', '2013-10-10');
insert into movies (movie_id, movie_name, movie_language, release_date) values (78, 'Melita', 'Baddiley', '2007-05-08');
insert into movies (movie_id, movie_name, movie_language, release_date) values (79, 'Kitty', 'Munday', '2015-08-17');
insert into movies (movie_id, movie_name, movie_language, release_date) values (80, 'Lewes', 'Ibotson', '1999-12-11');
insert into movies (movie_id, movie_name, movie_language, release_date) values (81, 'Darya', 'Wilcott', '1991-03-06');
insert into movies (movie_id, movie_name, movie_language, release_date) values (82, 'Masha', 'Berick', '2019-07-01');
insert into movies (movie_id, movie_name, movie_language, release_date) values (83, 'Sibby', 'Leile', '2009-01-23');
insert into movies (movie_id, movie_name, movie_language, release_date) values (84, 'Nicola', 'Weymont', '2018-07-03');
insert into movies (movie_id, movie_name, movie_language, release_date) values (85, 'Joachim', 'Palethorpe', '2000-11-21');
insert into movies (movie_id, movie_name, movie_language, release_date) values (86, 'Raine', 'Andryunin', '2007-04-26');
insert into movies (movie_id, movie_name, movie_language, release_date) values (87, 'Karoly', 'Piecha', '2016-04-11');
insert into movies (movie_id, movie_name, movie_language, release_date) values (88, 'Lothaire', 'Behrendsen', '2018-01-31');
insert into movies (movie_id, movie_name, movie_language, release_date) values (89, 'Arvin', 'Billingsly', '2017-07-19');
insert into movies (movie_id, movie_name, movie_language, release_date) values (90, 'Bobby', 'Lyne', '2006-09-14');
insert into movies (movie_id, movie_name, movie_language, release_date) values (91, 'Shannah', 'Beamson', '1996-11-16');
insert into movies (movie_id, movie_name, movie_language, release_date) values (92, 'Pate', 'D''Ruel', '2020-02-24');
insert into movies (movie_id, movie_name, movie_language, release_date) values (93, 'Bradley', 'Whitebrook', '1994-03-28');
insert into movies (movie_id, movie_name, movie_language, release_date) values (94, 'Jerry', 'Saltsberger', '1996-08-06');
insert into movies (movie_id, movie_name, movie_language, release_date) values (95, 'Maudie', 'Oakeby', '2014-10-20');
insert into movies (movie_id, movie_name, movie_language, release_date) values (96, 'See', 'Ravens', '2011-10-14');
insert into movies (movie_id, movie_name, movie_language, release_date) values (97, 'Christian', 'Crumly', '2014-05-21');
insert into movies (movie_id, movie_name, movie_language, release_date) values (98, 'Mureil', 'Dikes', '2003-07-19');
insert into movies (movie_id, movie_name, movie_language, release_date) values (99, 'Gothart', 'Hatherill', '2008-06-07');
insert into movies (movie_id, movie_name, movie_language, release_date) values (100, 'Cathyleen', 'Toffolo', '2000-02-12');


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO movies_actors (SELECT actor_id, movie_id FROM actors,movies) ORDER BY RANDOM() LIMIT 1000;
SELECT * FROM movies_actors;

