/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
This is the relationship between students and University they went to. 
The Student Table has the following information of students: id, first name, last name and email.
student_id is primary key and email is unique.
The University Table has the name and location of the University.
university_name is primary key.
The Enrollment Table has the information of university of every student.
The code is written for PostgreSQL.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE Student (
	student_id VARCHAR(16) PRIMARY KEY,
	first_name VARCHAR(64),
	last_name VARCHAR(64),
	email VARCHAR(64) UNIQUE
);
CREATE TABLE University (
	university_name  VARCHAR(128) PRIMARY KEY,
	locations VARCHAR(128)
);
CREATE TABLE Enrollment (
	student_id VARCHAR(16) REFERENCES Student (student_id),
	university_name VARCHAR(128) REFERENCES University (university_name)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into Student (student_id, first_name, last_name, email) values (1, 'Jim', 'Philpot', 'jphilpot0@flickr.com');
insert into Student (student_id, first_name, last_name, email) values (2, 'Ardis', 'Eyam', 'aeyam1@marketwatch.com');
insert into Student (student_id, first_name, last_name, email) values (3, 'Aharon', 'Mothersole', 'amothersole2@clickbank.net');
insert into Student (student_id, first_name, last_name, email) values (4, 'Valentia', 'McMahon', 'vmcmahon3@woothemes.com');
insert into Student (student_id, first_name, last_name, email) values (5, 'Annice', 'Rankine', 'arankine4@edublogs.org');
insert into Student (student_id, first_name, last_name, email) values (6, 'Mildred', 'Elstone', 'melstone5@google.co.jp');
insert into Student (student_id, first_name, last_name, email) values (7, 'Iosep', 'Gimert', 'igimert6@g.co');
insert into Student (student_id, first_name, last_name, email) values (8, 'Constance', 'Pamment', 'cpamment7@miitbeian.gov.cn');
insert into Student (student_id, first_name, last_name, email) values (9, 'Tabbi', 'Sagg', 'tsagg8@sitemeter.com');
insert into Student (student_id, first_name, last_name, email) values (10, 'Lorrie', 'McAllen', 'lmcallen9@opensource.org');
insert into Student (student_id, first_name, last_name, email) values (11, 'Malchy', 'Boddington', 'mboddingtona@jimdo.com');
insert into Student (student_id, first_name, last_name, email) values (12, 'Chlo', 'Masselin', 'cmasselinb@bloomberg.com');
insert into Student (student_id, first_name, last_name, email) values (13, 'Leanora', 'Brazelton', 'lbrazeltonc@merriam-webster.com');
insert into Student (student_id, first_name, last_name, email) values (14, 'Katrinka', 'Inman', 'kinmand@wix.com');
insert into Student (student_id, first_name, last_name, email) values (15, 'Toma', 'Neilus', 'tneiluse@google.co.uk');
insert into Student (student_id, first_name, last_name, email) values (16, 'Jaime', 'Grzegorek', 'jgrzegorekf@senate.gov');
insert into Student (student_id, first_name, last_name, email) values (17, 'Tallie', 'Telling', 'ttellingg@example.com');
insert into Student (student_id, first_name, last_name, email) values (18, 'Tynan', 'O''Farrell', 'tofarrellh@stumbleupon.com');
insert into Student (student_id, first_name, last_name, email) values (19, 'Lynde', 'Huscroft', 'lhuscrofti@arizona.edu');
insert into Student (student_id, first_name, last_name, email) values (20, 'Carree', 'Haborn', 'chabornj@ask.com');
insert into Student (student_id, first_name, last_name, email) values (21, 'Bernette', 'Carnaman', 'bcarnamank@meetup.com');
insert into Student (student_id, first_name, last_name, email) values (22, 'Victoir', 'Auchterlony', 'vauchterlonyl@nih.gov');
insert into Student (student_id, first_name, last_name, email) values (23, 'Grata', 'Ciotto', 'gciottom@cisco.com');
insert into Student (student_id, first_name, last_name, email) values (24, 'Phylis', 'Luckwell', 'pluckwelln@abc.net.au');
insert into Student (student_id, first_name, last_name, email) values (25, 'Paulina', 'Creyke', 'pcreykeo@wix.com');
insert into Student (student_id, first_name, last_name, email) values (26, 'Janna', 'Dike', 'jdikep@wikia.com');
insert into Student (student_id, first_name, last_name, email) values (27, 'Em', 'Heibel', 'eheibelq@newyorker.com');
insert into Student (student_id, first_name, last_name, email) values (28, 'Elianora', 'Mayou', 'emayour@infoseek.co.jp');
insert into Student (student_id, first_name, last_name, email) values (29, 'Teodora', 'Tuison', 'ttuisons@sourceforge.net');
insert into Student (student_id, first_name, last_name, email) values (30, 'Dagny', 'Tomasi', 'dtomasit@simplemachines.org');
insert into Student (student_id, first_name, last_name, email) values (31, 'Hammad', 'Pittendreigh', 'hpittendreighu@arizona.edu');
insert into Student (student_id, first_name, last_name, email) values (32, 'Shantee', 'Neumann', 'sneumannv@ucoz.com');
insert into Student (student_id, first_name, last_name, email) values (33, 'Clio', 'Belhome', 'cbelhomew@google.co.uk');
insert into Student (student_id, first_name, last_name, email) values (34, 'Wildon', 'Crapper', 'wcrapperx@youtube.com');
insert into Student (student_id, first_name, last_name, email) values (35, 'Sanderson', 'Nares', 'snaresy@imgur.com');
insert into Student (student_id, first_name, last_name, email) values (36, 'Mandi', 'Purle', 'mpurlez@t-online.de');
insert into Student (student_id, first_name, last_name, email) values (37, 'Maxwell', 'Mullard', 'mmullard10@army.mil');
insert into Student (student_id, first_name, last_name, email) values (38, 'Blakelee', 'Ingrem', 'bingrem11@over-blog.com');
insert into Student (student_id, first_name, last_name, email) values (39, 'Joachim', 'Frood', 'jfrood12@is.gd');
insert into Student (student_id, first_name, last_name, email) values (40, 'Monique', 'Ridwood', 'mridwood13@aol.com');
insert into Student (student_id, first_name, last_name, email) values (41, 'Branden', 'Miche', 'bmiche14@rediff.com');
insert into Student (student_id, first_name, last_name, email) values (42, 'Eve', 'McCumskay', 'emccumskay15@printfriendly.com');
insert into Student (student_id, first_name, last_name, email) values (43, 'Brig', 'Robertelli', 'brobertelli16@sciencedaily.com');
insert into Student (student_id, first_name, last_name, email) values (44, 'Waldemar', 'Pyvis', 'wpyvis17@dedecms.com');
insert into Student (student_id, first_name, last_name, email) values (45, 'Bendix', 'Glasby', 'bglasby18@diigo.com');
insert into Student (student_id, first_name, last_name, email) values (46, 'Bartlet', 'Stepto', 'bstepto19@squidoo.com');
insert into Student (student_id, first_name, last_name, email) values (47, 'Denyse', 'McCloughlin', 'dmccloughlin1a@php.net');
insert into Student (student_id, first_name, last_name, email) values (48, 'Meridel', 'Simondson', 'msimondson1b@blogger.com');
insert into Student (student_id, first_name, last_name, email) values (49, 'Bathsheba', 'Lilleman', 'blilleman1c@bigcartel.com');
insert into Student (student_id, first_name, last_name, email) values (50, 'Lane', 'Perschke', 'lperschke1d@gravatar.com');
insert into Student (student_id, first_name, last_name, email) values (51, 'Reinald', 'Minear', 'rminear1e@cpanel.net');
insert into Student (student_id, first_name, last_name, email) values (52, 'Berty', 'Swinnard', 'bswinnard1f@topsy.com');
insert into Student (student_id, first_name, last_name, email) values (53, 'Hedda', 'McAw', 'hmcaw1g@webeden.co.uk');
insert into Student (student_id, first_name, last_name, email) values (54, 'Bernadine', 'Kirmond', 'bkirmond1h@ovh.net');
insert into Student (student_id, first_name, last_name, email) values (55, 'Dorian', 'Staveley', 'dstaveley1i@businessinsider.com');
insert into Student (student_id, first_name, last_name, email) values (56, 'Jeffrey', 'Whiles', 'jwhiles1j@booking.com');
insert into Student (student_id, first_name, last_name, email) values (57, 'Lanny', 'Messom', 'lmessom1k@homestead.com');
insert into Student (student_id, first_name, last_name, email) values (58, 'Wally', 'Messent', 'wmessent1l@intel.com');
insert into Student (student_id, first_name, last_name, email) values (59, 'Bale', 'Pass', 'bpass1m@pen.io');
insert into Student (student_id, first_name, last_name, email) values (60, 'Gabi', 'Kupec', 'gkupec1n@newyorker.com');
insert into Student (student_id, first_name, last_name, email) values (61, 'Cornelle', 'Tofanini', 'ctofanini1o@ask.com');
insert into Student (student_id, first_name, last_name, email) values (62, 'Keen', 'Bedwell', 'kbedwell1p@bloomberg.com');
insert into Student (student_id, first_name, last_name, email) values (63, 'Sutherlan', 'Athy', 'sathy1q@comsenz.com');
insert into Student (student_id, first_name, last_name, email) values (64, 'Kinna', 'Ellam', 'kellam1r@ifeng.com');
insert into Student (student_id, first_name, last_name, email) values (65, 'Micah', 'Emanuelli', 'memanuelli1s@paginegialle.it');
insert into Student (student_id, first_name, last_name, email) values (66, 'Davie', 'Linham', 'dlinham1t@howstuffworks.com');
insert into Student (student_id, first_name, last_name, email) values (67, 'Teri', 'Lamdin', 'tlamdin1u@nhs.uk');
insert into Student (student_id, first_name, last_name, email) values (68, 'Theodore', 'Torrance', 'ttorrance1v@csmonitor.com');
insert into Student (student_id, first_name, last_name, email) values (69, 'Belvia', 'Buttler', 'bbuttler1w@yellowbook.com');
insert into Student (student_id, first_name, last_name, email) values (70, 'Neall', 'Lissandre', 'nlissandre1x@opera.com');
insert into Student (student_id, first_name, last_name, email) values (71, 'Veronika', 'Penkman', 'vpenkman1y@hatena.ne.jp');
insert into Student (student_id, first_name, last_name, email) values (72, 'Launce', 'Verzey', 'lverzey1z@163.com');
insert into Student (student_id, first_name, last_name, email) values (73, 'Udale', 'Collishaw', 'ucollishaw20@shinystat.com');
insert into Student (student_id, first_name, last_name, email) values (74, 'Wheeler', 'Cockley', 'wcockley21@state.tx.us');
insert into Student (student_id, first_name, last_name, email) values (75, 'Gilberto', 'Jarrette', 'gjarrette22@mozilla.com');
insert into Student (student_id, first_name, last_name, email) values (76, 'Grover', 'Snowling', 'gsnowling23@amazon.com');
insert into Student (student_id, first_name, last_name, email) values (77, 'Kalil', 'Gittings', 'kgittings24@oracle.com');
insert into Student (student_id, first_name, last_name, email) values (78, 'Neely', 'Andriesse', 'nandriesse25@dell.com');
insert into Student (student_id, first_name, last_name, email) values (79, 'Cherin', 'McConigal', 'cmcconigal26@creativecommons.org');
insert into Student (student_id, first_name, last_name, email) values (80, 'Flemming', 'Hedling', 'fhedling27@hc360.com');
insert into Student (student_id, first_name, last_name, email) values (81, 'Doti', 'Cahan', 'dcahan28@tripadvisor.com');
insert into Student (student_id, first_name, last_name, email) values (82, 'Alexis', 'Shelsher', 'ashelsher29@netvibes.com');
insert into Student (student_id, first_name, last_name, email) values (83, 'Shelby', 'Fake', 'sfake2a@archive.org');
insert into Student (student_id, first_name, last_name, email) values (84, 'Claus', 'Pietroni', 'cpietroni2b@msn.com');
insert into Student (student_id, first_name, last_name, email) values (85, 'Chiarra', 'Biddulph', 'cbiddulph2c@feedburner.com');
insert into Student (student_id, first_name, last_name, email) values (86, 'Othilie', 'Dodding', 'ododding2d@smh.com.au');
insert into Student (student_id, first_name, last_name, email) values (87, 'Thorin', 'Batiste', 'tbatiste2e@squidoo.com');
insert into Student (student_id, first_name, last_name, email) values (88, 'Rob', 'Belward', 'rbelward2f@yolasite.com');
insert into Student (student_id, first_name, last_name, email) values (89, 'Gery', 'Lorenzini', 'glorenzini2g@oracle.com');
insert into Student (student_id, first_name, last_name, email) values (90, 'Kippie', 'Gewer', 'kgewer2h@drupal.org');
insert into Student (student_id, first_name, last_name, email) values (91, 'Winonah', 'Le Marquand', 'wlemarquand2i@accuweather.com');
insert into Student (student_id, first_name, last_name, email) values (92, 'Shermy', 'Dragon', 'sdragon2j@hatena.ne.jp');
insert into Student (student_id, first_name, last_name, email) values (93, 'Gusty', 'Fechnie', 'gfechnie2k@bloglovin.com');
insert into Student (student_id, first_name, last_name, email) values (94, 'Dieter', 'Forlonge', 'dforlonge2l@qq.com');
insert into Student (student_id, first_name, last_name, email) values (95, 'Rozella', 'Camps', 'rcamps2m@unesco.org');
insert into Student (student_id, first_name, last_name, email) values (96, 'Jada', 'Hammor', 'jhammor2n@wp.com');
insert into Student (student_id, first_name, last_name, email) values (97, 'Sephira', 'Brushfield', 'sbrushfield2o@slideshare.net');
insert into Student (student_id, first_name, last_name, email) values (98, 'Alonzo', 'Borrows', 'aborrows2p@tmall.com');
insert into Student (student_id, first_name, last_name, email) values (99, 'Nev', 'Doncom', 'ndoncom2q@nymag.com');
insert into Student (student_id, first_name, last_name, email) values (100, 'Stavros', 'Pikhno', 'spikhno2r@homestead.com');

insert into University (university_name, locations) values ('Ateneo de Naga University', 'Philippines');
insert into University (university_name, locations) values ('Instituto Mauá de Tecnologia', 'Brazil');
insert into University (university_name, locations) values ('Allegheny College', 'United States');
insert into University (university_name, locations) values ('University of Limpopo', 'South Africa');
insert into University (university_name, locations) values ('Syktyvkar State University', 'Western Sahara');
insert into University (university_name, locations) values ('Dunya Institute of Higher Education', 'Afghanistan');
insert into University (university_name, locations) values ('Universitas Pelita Harapan', 'Indonesia');
insert into University (university_name, locations) values ('Western Kazakhstan Agricultural University', 'Kazakhstan');
insert into University (university_name, locations) values ('Universidad Mexicana del Noreste', 'Mexico');
insert into University (university_name, locations) values ('Universidad Católica de Santiago del Estero', 'Argentina');
insert into University (university_name, locations) values ('Wuhan University', 'China');
insert into University (university_name, locations) values ('Universidad Nacional Abierta y a Distancia', 'Colombia');
insert into University (university_name, locations) values ('De La Salle University', 'Philippines');
insert into University (university_name, locations) values ('Central Academy of  Fine Art', 'China');
insert into University (university_name, locations) values ('Zabol University', 'Iran');
insert into University (university_name, locations) values ('Beijing New Asia University', 'China');
insert into University (university_name, locations) values ('Nanjing University of Posts and Telecommunications', 'China');
insert into University (university_name, locations) values ('Universidad Autónoma "Benito Juárez" de Oaxaca', 'Mexico');
insert into University (university_name, locations) values ('Technological Education Institute of Epiros', 'Greece');
insert into University (university_name, locations) values ('Sekolah Tinggi Akuntansi Negara (STAN)', 'Indonesia');
insert into University (university_name, locations) values ('Université de Bamako', 'Mali');
insert into University (university_name, locations) values ('Universidad Andina Simón Bolívar', 'Ecuador');
insert into University (university_name, locations) values ('Northwest A&F University', 'China');
insert into University (university_name, locations) values ('Universidade da Beira Interior', 'Portugal');
insert into University (university_name, locations) values ('University of Pardubice', 'Czech Republic');
insert into University (university_name, locations) values ('Institut de Recherche et d''Enseignement Supérieur aux Techniques de l''électronique', 'France');
insert into University (university_name, locations) values ('Philadelphia University', 'United States');
insert into University (university_name, locations) values ('University College Cork', 'Ireland');
insert into University (university_name, locations) values ('Burjat State University', 'Russia');
insert into University (university_name, locations) values ('University of Electronic Science and Technology of China', 'China');
insert into University (university_name, locations) values ('Hebei Agricultural University', 'China');
insert into University (university_name, locations) values ('Universitas Islam Jakarta', 'Indonesia');
insert into University (university_name, locations) values ('Our Lady of Fatima University', 'Philippines');
insert into University (university_name, locations) values ('Agricultural University of Lublin', 'Poland');
insert into University (university_name, locations) values ('University of the Philippines Visayas - Cebu High School', 'Philippines');
insert into University (university_name, locations) values ('Universidad Autónoma de Tamaulipas', 'Mexico');
insert into University (university_name, locations) values ('Universitas Negeri Surabaya', 'Indonesia');
insert into University (university_name, locations) values ('Espam Formation University', 'Benin');
insert into University (university_name, locations) values ('Huaihua Medical College', 'China');
insert into University (university_name, locations) values ('University of Thessaly', 'Greece');
insert into University (university_name, locations) values ('Université du Centre, Sousse', 'Tunisia');
insert into University (university_name, locations) values ('Hebei University of Technology', 'China');
insert into University (university_name, locations) values ('Jiangxi Agricultural University', 'China');
insert into University (university_name, locations) values ('Shantou University', 'China');
insert into University (university_name, locations) values ('Higher School o Business/National Louis University(WSB/NLU) in Nowy Sacz', 'Poland');
insert into University (university_name, locations) values ('Xi''an University of Electronic Science and Technology', 'Kosovo');
insert into University (university_name, locations) values ('Universitas Pattimura', 'Indonesia');
insert into University (university_name, locations) values ('Academy of Performing Arts, Film and TV Fakulty', 'Czech Republic');
insert into University (university_name, locations) values ('Universitas Nasional Pasim', 'Indonesia');
insert into University (university_name, locations) values ('Universitas Nusa Cendana', 'Indonesia');
insert into University (university_name, locations) values ('Volgograd State Pedagogical University', 'Russia');
insert into University (university_name, locations) values ('Technical University of Warsaw', 'Poland');
insert into University (university_name, locations) values ('Universitas Lambung Mangkurat', 'Indonesia');
insert into University (university_name, locations) values ('Science University of Tokyo in Yamaguchi', 'Japan');
insert into University (university_name, locations) values ('Gunma University', 'Japan');
insert into University (university_name, locations) values ('University of Science and Technology Beijing', 'China');
insert into University (university_name, locations) values ('Université de Ngaoundéré', 'Cameroon');
insert into University (university_name, locations) values ('Duke University', 'United States');
insert into University (university_name, locations) values ('Universidad Industrial de Santander', 'Colombia');
insert into University (university_name, locations) values ('Universidad Dr. Andreas Bello', 'El Salvador');
insert into University (university_name, locations) values ('Samarkand State University', 'Uzbekistan');
insert into University (university_name, locations) values ('University College of Arts, Crafts and Design', 'Sweden');
insert into University (university_name, locations) values ('European Management Center Paris', 'France');
insert into University (university_name, locations) values ('Belarussian State University of Informatics and Radioelectronics', 'Belarus');
insert into University (university_name, locations) values ('Instituto Superior de Psicologia Aplicada', 'Portugal');
insert into University (university_name, locations) values ('University of Grigol Robakidze', 'Georgia');
insert into University (university_name, locations) values ('Drzavni Univerzitet u Novom Pazaru', 'Serbia');
insert into University (university_name, locations) values ('Abo Akademi University', 'Finland');
insert into University (university_name, locations) values ('New Era University', 'Philippines');
insert into University (university_name, locations) values ('Kunmimg University of Science and Technology', 'China');
insert into University (university_name, locations) values ('Universidade Federal do Maranhão', 'Brazil');
insert into University (university_name, locations) values ('University of Primorska', 'Slovenia');
insert into University (university_name, locations) values ('Wesleyan University Philippines', 'Philippines');
insert into University (university_name, locations) values ('Belmont University', 'United States');
insert into University (university_name, locations) values ('Kharkiv State Medical University', 'Ukraine');
insert into University (university_name, locations) values ('Universidade Eduardo Mondlane', 'Mozambique');
insert into University (university_name, locations) values ('Universidad Autónoma del Paraguay', 'Paraguay');
insert into University (university_name, locations) values ('National University', 'Philippines');
insert into University (university_name, locations) values ('University of Calgary', 'Canada');
insert into University (university_name, locations) values ('South East European University', 'Macedonia');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO Enrollment (student_id, university_name)
SELECT student_id, university_name FROM Student, University
ORDER BY RANDOM()
LIMIT 1000;
