/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The code for the following questions is written for PostgreSQL.
The chosen example record investors' stock trading history.

1. Entity Table E1 is "Investor" table: it contains investor basic information, which includes following 3 attributes
	1.1 Attribute "investor_id" is the unique identifier of investor, being the primary key of the table
	1.2 Attribute "first_name" and "last_name" describe the full name of investors
	1.3 Attribute "email" provides investor contact details, which is unique per investor
	
2. Entity Table E2 is "Stock" table: it contains information of stock offered for trading, which includes following 3 attributes
	2.1 Attribute "stock_ticket" is the unique identifier of stock, being the primary key of the table
	2.2 Attribute "company_name" is the company name of the stock listed
	2.3 Attribute "exchange" is the exchange that the stock is listed on
	
3. Relationship Table R is "Transaction" table: it contains stock transacted by investor, which includes following 5 attributes
	3.1 Attribute "transaction_number" is the unique series number of transaction that happened in the past, being the primary key of the table
	3.2 Attribute "investor_id" indicates the investor who traded stock. This is a foreign key with reference to the Investor table.
	3.3 Attribute "stock_ticket" indicates the stock the investor traded. This is a foreign key with reference to the Stock table.
	3.4 Attribute "transact_date" indicates the date when the stock is traded
	3.5 Attribute "transact_quantity" indicates the unit of stock the investor traded.
		The quantity can be positive or negaitve, but cannot be zero.
		If the quantity is positive, the investor purchases / longs the stock; if the quantity is negative, investor sells / short the stock.
		
		**Stock price is not included as an attribute because it can be easily retrieved based on the transact_date (providing detailed datetime). 
		**There could be another table that store pricing information which include the stock price of a pariticular time, the corresponding platform fee, commission charge etc.
		  
All attributes in all tables are NOT NULL.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
-- DROP TABLE IF EXISTS INVESTOR, STOCK, TRANSACTION;

create table INVESTOR (
	investor_id CHAR(10) PRIMARY KEY,
	first_name VARCHAR(32) NOT NULL,
	last_name VARCHAR(32) NOT NULL,
	email VARCHAR(82) UNIQUE NOT NULL
);

create table STOCK (
	stock_ticket VARCHAR(10) PRIMARY KEY,
	company_name VARCHAR(100) NOT NULL,
	exchange VARCHAR(50) NOT NULL
);

create table TRANSACTION(
	transaction_number SERIAL PRIMARY KEY,
	investor_id CHAR(10) NOT NULL,
	stock_ticket VARCHAR(10) NOT NULL,
 	transact_date timestamp NOT NULL,
 	transact_quantity int NOT NULL CHECK (transact_quantity <> 0),
	FOREIGN KEY (investor_id) REFERENCES investor(investor_id) 
		ON UPDATE CASCADE
		ON DELETE CASCADE,
	FOREIGN KEY (stock_ticket) REFERENCES stock(stock_ticket)
		ON UPDATE CASCADE
		ON DELETE CASCADE
	);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into INVESTOR (investor_id, first_name, last_name, email) values ('85-4760179', 'Ranna', 'Carbry', 'rcarbry0@digg.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('21-1397527', 'Cookie', 'Davson', 'cdavson1@accuweather.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('51-0569976', 'Mae', 'Brownhill', 'mbrownhill2@symantec.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('50-0131339', 'Minerva', 'Colin', 'mcolin3@wikipedia.org');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('06-6826546', 'Giselle', 'Dabs', 'gdabs4@diigo.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('86-4134778', 'Melantha', 'Marquez', 'mmarquez5@artisteer.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('58-7763115', 'Ralph', 'Boagey', 'rboagey6@infoseek.co.jp');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('21-9869559', 'Merrick', 'Beartup', 'mbeartup7@baidu.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('74-3402281', 'Sandi', 'Lamont', 'slamont8@sohu.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('09-2771338', 'Judas', 'Menci', 'jmenci9@columbia.edu');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('43-7818274', 'Maurine', 'Yesenev', 'myeseneva@last.fm');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('39-3485062', 'Hermie', 'Dowbakin', 'hdowbakinb@behance.net');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('87-7556517', 'Anjanette', 'Brosel', 'abroselc@smugmug.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('32-9773684', 'Bernette', 'Rittmeier', 'brittmeierd@ow.ly');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('49-3348127', 'Dickie', 'Brogi', 'dbrogie@comcast.net');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('18-3519774', 'Callida', 'McNulty', 'cmcnultyf@foxnews.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('02-3226435', 'Pia', 'Bircher', 'pbircherg@wix.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('16-5606105', 'Fayth', 'Ruppelin', 'fruppelinh@netlog.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('27-8580031', 'Florri', 'Garlett', 'fgarletti@unc.edu');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('67-7535606', 'Milzie', 'Ransome', 'mransomej@moonfruit.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('21-8064251', 'Banky', 'Osgodby', 'bosgodbyk@tuttocitta.it');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('80-9614023', 'Terry', 'Housego', 'thousegol@bizjournals.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('79-8504931', 'Symon', 'Woolfoot', 'swoolfootm@storify.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('80-3010226', 'Starlin', 'Matelyunas', 'smatelyunasn@mail.ru');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('11-2478450', 'Eddie', 'Beagan', 'ebeagano@tinyurl.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('36-8599587', 'Patrick', 'Worham', 'pworhamp@nhs.uk');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('72-0285018', 'Tilly', 'Mellon', 'tmellonq@amazon.de');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('30-3059630', 'Karlotte', 'Warboys', 'kwarboysr@ted.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('40-6210374', 'Nancee', 'Goldes', 'ngoldess@cisco.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('83-0151684', 'Deborah', 'Coey', 'dcoeyt@jiathis.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('27-1626283', 'Pearce', 'Fermer', 'pfermeru@unc.edu');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('19-2442567', 'Billye', 'McHale', 'bmchalev@yale.edu');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('87-0047558', 'Dene', 'Glyde', 'dglydew@elegantthemes.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('91-9050433', 'Sheri', 'Shawyers', 'sshawyersx@cloudflare.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('32-6673709', 'Carmencita', 'Pirazzi', 'cpirazziy@usnews.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('78-8300615', 'Orran', 'Guerreau', 'oguerreauz@ucoz.ru');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('05-9585037', 'Emelen', 'Noddings', 'enoddings10@bravesites.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('77-9079319', 'Grange', 'Semens', 'gsemens11@icio.us');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('73-0560413', 'Farleigh', 'Abercromby', 'fabercromby12@hatena.ne.jp');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('12-5832717', 'Mickey', 'Broose', 'mbroose13@technorati.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('98-3915190', 'Heloise', 'Reveland', 'hreveland14@indiatimes.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('74-4010419', 'Shannah', 'Grzeszczak', 'sgrzeszczak15@deviantart.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('87-0863065', 'Joleen', 'Ziemke', 'jziemke16@example.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('94-0768168', 'Celesta', 'Lenaghen', 'clenaghen17@latimes.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('07-1754724', 'Ruprecht', 'Kimbell', 'rkimbell18@state.tx.us');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('46-1284050', 'Fremont', 'MacCarrane', 'fmaccarrane19@uol.com.br');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('82-5260296', 'Abbie', 'Oret', 'aoret1a@biglobe.ne.jp');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('27-7518533', 'Tandy', 'Challinor', 'tchallinor1b@mashable.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('19-0028311', 'Mikaela', 'Haycox', 'mhaycox1c@vkontakte.ru');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('79-3052866', 'Jacquelyn', 'Hext', 'jhext1d@arstechnica.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('70-9986458', 'Lula', 'Lince', 'llince1e@cornell.edu');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('72-3128264', 'Lurlene', 'Gatecliff', 'lgatecliff1f@china.com.cn');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('59-2989137', 'Bil', 'Gummow', 'bgummow1g@wikipedia.org');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('57-9666982', 'Beauregard', 'Putman', 'bputman1h@comsenz.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('42-5420453', 'Edgar', 'Mart', 'emart1i@behance.net');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('08-6847617', 'Coop', 'Beastall', 'cbeastall1j@sbwire.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('81-3174576', 'Dael', 'Silbersak', 'dsilbersak1k@deliciousdays.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('95-5843277', 'Scottie', 'Awde', 'sawde1l@linkedin.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('98-2975335', 'Papageno', 'Ruusa', 'pruusa1m@cpanel.net');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('17-6897258', 'Evered', 'Grevel', 'egrevel1n@yale.edu');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('01-6435917', 'Michel', 'Farron', 'mfarron1o@omniture.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('77-6749296', 'Erasmus', 'Melross', 'emelross1p@spiegel.de');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('83-1271982', 'Veronica', 'Lukacs', 'vlukacs1q@godaddy.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('77-6284025', 'Brigitte', 'Dudeney', 'bdudeney1r@amazon.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('01-3254894', 'Brodie', 'Cantle', 'bcantle1s@webs.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('42-3970897', 'Nikos', 'Tansill', 'ntansill1t@angelfire.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('50-7364036', 'Dyna', 'Sjostrom', 'dsjostrom1u@bloomberg.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('28-4144442', 'Gypsy', 'Siggers', 'gsiggers1v@skyrock.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('82-9591749', 'Aloysia', 'Maior', 'amaior1w@domainmarket.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('58-0732255', 'Fredek', 'Veillard', 'fveillard1x@statcounter.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('46-5420580', 'Ari', 'Bailes', 'abailes1y@usa.gov');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('75-8722674', 'Darnell', 'Girt', 'dgirt1z@themeforest.net');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('05-7391781', 'Kerk', 'Seefus', 'kseefus20@ftc.gov');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('90-4708273', 'Bert', 'Tucknutt', 'btucknutt21@nifty.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('02-6947052', 'Ardys', 'Tynemouth', 'atynemouth22@chronoengine.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('15-7910901', 'Leelah', 'Mioni', 'lmioni23@whitehouse.gov');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('74-9034488', 'Brigida', 'Koubu', 'bkoubu24@npr.org');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('54-6101667', 'Kalinda', 'Nadin', 'knadin25@engadget.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('00-7199307', 'Edvard', 'Hitzmann', 'ehitzmann26@e-recht24.de');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('69-4507082', 'Zia', 'Rowlett', 'zrowlett27@usgs.gov');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('16-6289627', 'Valery', 'Alphonso', 'valphonso28@si.edu');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('08-8942758', 'Dianemarie', 'Duckinfield', 'dduckinfield29@webs.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('63-7060613', 'Wilek', 'Greenstead', 'wgreenstead2a@columbia.edu');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('34-1466114', 'Camilla', 'Rippingall', 'crippingall2b@i2i.jp');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('54-6010001', 'Idelle', 'Acors', 'iacors2c@dion.ne.jp');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('49-5775116', 'Mohandis', 'Trunchion', 'mtrunchion2d@ft.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('49-0596205', 'Bryn', 'Stopper', 'bstopper2e@desdev.cn');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('02-7282763', 'Evie', 'Wederell', 'ewederell2f@myspace.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('49-0186248', 'Ashla', 'Pratty', 'apratty2g@accuweather.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('90-5141528', 'Madelyn', 'Jencey', 'mjencey2h@wsj.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('99-7566561', 'Enid', 'Chippindall', 'echippindall2i@apache.org');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('18-7137754', 'Gun', 'Mostin', 'gmostin2j@ycombinator.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('89-3446480', 'Zacharie', 'Wevell', 'zwevell2k@sun.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('68-8590002', 'Alyosha', 'Casini', 'acasini2l@timesonline.co.uk');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('54-7451085', 'Page', 'Bartalucci', 'pbartalucci2m@usgs.gov');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('46-6201898', 'Sharai', 'Adel', 'sadel2n@cnet.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('27-6057173', 'Lavinie', 'Vasenkov', 'lvasenkov2o@disqus.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('94-6977001', 'Annelise', 'Grenkov', 'agrenkov2p@google.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('79-9623114', 'Neils', 'Trunks', 'ntrunks2q@wikispaces.com');
insert into INVESTOR (investor_id, first_name, last_name, email) values ('47-0934105', 'Erasmus', 'Broe', 'ebroe2r@bravesites.com');

insert into stock (stock_ticket, company_name, exchange) values ('PSCT', 'PowerShares S&P SmallCap Information Technology Portfolio', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('SABR', 'Sabre Corporation', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('HUBS', 'HubSpot, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('SGQI', 'Janus Henderson SG Global Quality Income ETF', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('CSLT', 'Castlight Health, inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('MXL', 'MaxLinear, Inc', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('SCZ', 'iShares MSCI EAFE Small-Cap ETF', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('OGS', 'ONE Gas, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('MDRX', 'Allscripts Healthcare Solutions, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('CHKP', 'Check Point Software Technologies Ltd.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('NQP', 'Nuveen Pennsylvania Quality Municipal Income Fund', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('UBSH', 'Union Bankshares Corporation', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('S', 'Sprint Corporation', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('CBAK', 'CBAK Energy Technology, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('WBMD', 'WebMD Health Corp', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('HEP', 'Holly Energy Partners, L.P.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('CTL', 'CenturyLink, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('ARGX', 'argenx SE', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('PAGG', 'PowerShares Global Agriculture Portfolio', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('BITA', 'Bitauto Holdings Limited', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('MET', 'MetLife, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('SCACU', 'Saban Capital Acquisition Corp.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('HABT', 'The Habit Restaurants, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('EEA', 'European Equity Fund, Inc. (The)', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('ZAIS', 'ZAIS Group Holdings, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('JBK', 'Lehman ABS Corporation', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('LSI', 'Life Storage, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('FOMX', 'Foamix Pharmaceuticals Ltd.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('DPS', 'Dr Pepper Snapple Group, Inc', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('AXR', 'AMREP Corporation', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('RFEU', 'First Trust RiverFront Dynamic Europe ETF', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('CRH', 'CRH PLC', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('MCS', 'Marcus Corporation (The)', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('STON', 'StoneMor Partners L.P.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('WAIR', 'Wesco Aircraft Holdings, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('GNL', 'Global Net Lease, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('ARR^A', 'ARMOUR Residential REIT, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('FTSL', 'First Trust Senior Loan Fund ETF', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('MYRG', 'MYR Group, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('ENV', 'Envestnet, Inc', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('MORN', 'Morningstar, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('MSTR', 'MicroStrategy Incorporated', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('NVLN', 'Novelion Therapeutics Inc. ', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('EXK', 'Endeavour Silver Corporation', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('SRET', 'Global X SuperDividend REIT ETF', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('PFGC', 'Performance Food Group Company', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('FRTA', 'Forterra, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('SPWH', 'Sportsman''s Warehouse Holdings, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('FCCO', 'First Community Corporation', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('WFC^X', 'Wells Fargo & Company', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('WFT', 'Weatherford International plc', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('BDXA', 'Becton, Dickinson and Company', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('EL', 'Estee Lauder Companies, Inc. (The)', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('ADRD', 'BLDRS Developed Markets 100 ADR Index Fund', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('NBD', 'Nuveen Build America Bond Opportunity Fund', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('BNTCW', 'Benitec Biopharma Limited', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('FSNN', 'Fusion Telecommunications International, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('CYAN', 'Cyanotech Corporation', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('ESS', 'Essex Property Trust, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('SPWR', 'SunPower Corporation', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('SXCP', 'SunCoke Energy Partners, L.P.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('GUT', 'Gabelli Utility Trust (The)', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('GRBK', 'Green Brick Partners, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('BOSC', 'B.O.S. Better Online Solutions', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('NXP', 'Nuveen Select Tax Free Income Portfolio', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('XCO', 'EXCO Resources NL', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('EVHC^', 'Envision Healthcare Corporation', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('PME', 'Pingtan Marine Enterprise Ltd.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('ALLY', 'Ally Financial Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('BLBD', 'Blue Bird Corporation', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('VMO', 'Invesco Municipal Opportunity Trust', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('AVT', 'Avnet, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('LWAY', 'Lifeway Foods, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('FTXH', 'First Trust Nasdaq Pharmaceuticals ETF', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('BAM', 'Brookfield Asset Management Inc', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('MFO', 'MFA Financial, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('PBCT', 'People''s United Financial, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('MSL', 'MidSouth Bancorp', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('SNBC', 'Sun Bancorp, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('RPT', 'Ramco-Gershenson Properties Trust', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('GOL', 'Gol Linhas Aereas Inteligentes S.A.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('ZB^G', 'Zions Bancorporation', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('MED', 'MEDIFAST INC', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('ECL', 'Ecolab Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('HCN', 'Welltower Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('BPTH', 'Bio-Path Holdings, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('GPM', 'Guggenheim Enhanced Equity Income Fund', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('NANO', 'Nanometrics Incorporated', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('DPLO', 'Diplomat Pharmacy, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('BIOC', 'Biocept, Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('UNAM', 'Unico American Corporation', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('ORAN', 'Orange', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('BUSE', 'First Busey Corporation', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('BSRR', 'Sierra Bancorp', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('DFNL', 'Davis Select Financial ETF', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('NGG', 'National Grid Transco, PLC', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('VRX', 'Valeant Pharmaceuticals International, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('HDNG', 'Hardinge Inc.', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('STI.WS.A', 'SunTrust Banks, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('FSZ', 'First Trust Switzerland AlphaDEX Fund', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('WCN', 'Waste Connections, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('ONCS', 'OncoSec Medical Incorporated', 'NASDAQ');
insert into stock (stock_ticket, company_name, exchange) values ('JKS', 'JinkoSolar Holding Company Limited', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('WTR', 'Aqua America, Inc.', 'NYSE');
insert into stock (stock_ticket, company_name, exchange) values ('GEH', 'General Electric Capital Corporation', 'NYSE');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

SELECT setseed(0.6);

WITH possible_transaction AS (
	SELECT investor_id, stock_ticket FROM investor, stock
	ORDER BY RANDOM()
	LIMIT 1000
)

INSERT INTO transaction (investor_id, stock_ticket, transact_date, transact_quantity)
SELECT investor_id, stock_ticket,
timestamp '2020-01-01 20:00:00' + RANDOM() * (timestamp '2021-08-15 20:00:00' - timestamp '2020-01-01 20:00:00'),
RANDOM()*2000-1000
FROM possible_transaction
;
