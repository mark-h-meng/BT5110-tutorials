/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/

/*
The code is written for PostgreSQL
*/

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
My 3 tables will represent sales from an online drugstore.

Entity 1: Customer Details
Table Name: customer_details_mock
Columns are as followed

Row ID:						id INT
Registered First Name:		first_name VARCHAR(50)
Registered Last Name:		last_name VARCHAR(50)
Registered Email:			email VARCHAR(50)
Stated Gender:				gender VARCHAR(50)
Unique created username:	username VARCHAR(50)
Registered Country:			country_of_residence VARCHAR(50)

Entity 2: Available drug details and pricing 
Table Name: drug_mock
Columns are as followed

Row ID:			id INT
Brand of Drug:	drug_brand VARCHAR(1000)
Name of Drug:	drug_name VARCHAR(1000)
Price:			price INT

Relationship: Purchases made by customers in last 7 days
Table Name: purchases
Columns are as followed

date of purchase last 7 days:	date_of_purchase DATE
Unique created username:		username VARCHAR(50)
Brand of Drug:					drug_brand VARCHAR(1000)
Name of Drug:					drug_name VARCHAR(1000)
Price:							price INT


*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

create table IF NOT EXISTS customer_details_mock (
	id INT,
	first_name VARCHAR(50) NOT NULL,
	last_name VARCHAR(50) NOT NULL,
	email VARCHAR(50) UNIQUE NOT NULL,
	gender VARCHAR(50) NOT NULL,
	username VARCHAR(50) PRIMARY KEY,
	country_of_residence VARCHAR(50) NOT NULL
);

create table IF NOT EXISTS drug_mock (
	id INT,
	drug_brand VARCHAR(1000) NOT NULL,
	drug_name VARCHAR(1000) NOT NULL,
	price INT NOT NULL CHECK (price > 0),
	PRIMARY KEY (drug_brand , drug_name) 
);

create table IF NOT EXISTS purchases (
	date_of_purchase DATE,
	username VARCHAR(50) REFERENCES customer_details_mock (username)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED,
	drug_brand VARCHAR(1000),
	drug_name VARCHAR(1000),
	price INT NOT NULL CHECK (price > 0),
	FOREIGN KEY (drug_brand, drug_name) REFERENCES drug_mock (drug_brand, drug_name)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/*customer_details_mock*/
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (1, 'Orelia', 'Jovasevic', 'ojovasevic0@cdbaby.com', 'Female', 'ojovasevic0', 'Indonesia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (2, 'Garrott', 'Varlow', 'gvarlow1@jimdo.com', 'Non-binary', 'gvarlow1', 'Papua New Guinea');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (3, 'Claudina', 'Rodnight', 'crodnight2@fc2.com', 'Bigender', 'crodnight2', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (4, 'Josias', 'Kayley', 'jkayley3@dropbox.com', 'Genderfluid', 'jkayley3', 'Russia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (5, 'Terra', 'Cummine', 'tcummine4@amazon.co.jp', 'Polygender', 'tcummine4', 'Czech Republic');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (6, 'Chelsea', 'De Atta', 'cdeatta5@msn.com', 'Agender', 'cdeatta5', 'Burundi');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (7, 'Renell', 'Fackney', 'rfackney6@cnet.com', 'Genderfluid', 'rfackney6', 'Russia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (8, 'Fara', 'Tacon', 'ftacon7@arizona.edu', 'Polygender', 'ftacon7', 'Tunisia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (9, 'Sonia', 'Rogan', 'srogan8@facebook.com', 'Male', 'srogan8', 'Indonesia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (10, 'Akim', 'Danielian', 'adanielian9@nyu.edu', 'Agender', 'adanielian9', 'Russia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (11, 'Rita', 'Dannohl', 'rdannohla@zimbio.com', 'Polygender', 'rdannohla', 'Peru');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (12, 'Harriette', 'MacFaul', 'hmacfaulb@feedburner.com', 'Genderfluid', 'hmacfaulb', 'Russia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (13, 'Ozzy', 'Wittrington', 'owittringtonc@blog.com', 'Male', 'owittringtonc', 'Chile');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (14, 'Wayland', 'Goldsberry', 'wgoldsberryd@1688.com', 'Agender', 'wgoldsberryd', 'Brazil');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (15, 'Dougy', 'Dymoke', 'ddymokee@java.com', 'Agender', 'ddymokee', 'Guinea');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (16, 'Martie', 'Lacroix', 'mlacroixf@businessweek.com', 'Genderfluid', 'mlacroixf', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (17, 'Elmira', 'Allner', 'eallnerg@skyrock.com', 'Female', 'eallnerg', 'Russia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (18, 'Petronella', 'Ellen', 'pellenh@xrea.com', 'Male', 'pellenh', 'Thailand');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (19, 'Sayre', 'Ballham', 'sballhami@reverbnation.com', 'Male', 'sballhami', 'Zimbabwe');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (20, 'Brigg', 'Grabbam', 'bgrabbamj@irs.gov', 'Female', 'bgrabbamj', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (21, 'Hermann', 'Beers', 'hbeersk@chron.com', 'Genderfluid', 'hbeersk', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (22, 'Otis', 'Petasch', 'opetaschl@dailymail.co.uk', 'Genderqueer', 'opetaschl', 'United Arab Emirates');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (23, 'Aubrey', 'Sulman', 'asulmanm@amazonaws.com', 'Genderqueer', 'asulmanm', 'Indonesia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (24, 'Rae', 'Antyukhin', 'rantyukhinn@mit.edu', 'Genderqueer', 'rantyukhinn', 'Philippines');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (25, 'Sylvia', 'Jachtym', 'sjachtymo@yale.edu', 'Polygender', 'sjachtymo', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (26, 'Taylor', 'Margaritelli', 'tmargaritellip@china.com.cn', 'Genderfluid', 'tmargaritellip', 'United States');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (27, 'Edgar', 'Sunnucks', 'esunnucksq@plala.or.jp', 'Non-binary', 'esunnucksq', 'Honduras');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (28, 'Giff', 'Abden', 'gabdenr@blogger.com', 'Non-binary', 'gabdenr', 'Sweden');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (29, 'Correna', 'Ashard', 'cashards@go.com', 'Genderfluid', 'cashards', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (30, 'Kim', 'Lacasa', 'klacasat@apple.com', 'Genderfluid', 'klacasat', 'Italy');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (31, 'Welsh', 'Tugwell', 'wtugwellu@free.fr', 'Polygender', 'wtugwellu', 'United States');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (32, 'Judah', 'Geffe', 'jgeffev@who.int', 'Bigender', 'jgeffev', 'Japan');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (33, 'Jordan', 'Muldownie', 'jmuldowniew@gnu.org', 'Male', 'jmuldowniew', 'Paraguay');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (34, 'Domini', 'Demageard', 'ddemageardx@forbes.com', 'Bigender', 'ddemageardx', 'Poland');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (35, 'Chad', 'Blain', 'cblainy@sciencedaily.com', 'Genderfluid', 'cblainy', 'Ireland');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (36, 'Ellerey', 'Cars', 'ecarsz@list-manage.com', 'Non-binary', 'ecarsz', 'Thailand');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (37, 'Del', 'Roisen', 'droisen10@stanford.edu', 'Genderfluid', 'droisen10', 'Indonesia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (38, 'Janice', 'Brusle', 'jbrusle11@privacy.gov.au', 'Genderqueer', 'jbrusle11', 'Brazil');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (39, 'Madella', 'Henworth', 'mhenworth12@gizmodo.com', 'Agender', 'mhenworth12', 'Russia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (40, 'Dalli', 'Battams', 'dbattams13@bbc.co.uk', 'Bigender', 'dbattams13', 'Japan');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (41, 'Wallace', 'Allitt', 'wallitt14@google.pl', 'Genderqueer', 'wallitt14', 'Japan');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (42, 'Quintina', 'Wedlock', 'qwedlock15@addthis.com', 'Bigender', 'qwedlock15', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (43, 'Seline', 'Marham', 'smarham16@phoca.cz', 'Agender', 'smarham16', 'Tajikistan');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (44, 'Suzanna', 'Birtwistle', 'sbirtwistle17@princeton.edu', 'Female', 'sbirtwistle17', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (45, 'Cassie', 'Sex', 'csex18@a8.net', 'Genderfluid', 'csex18', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (46, 'Stefania', 'Hearon', 'shearon19@histats.com', 'Genderqueer', 'shearon19', 'Croatia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (47, 'Farrell', 'Bruun', 'fbruun1a@hp.com', 'Genderqueer', 'fbruun1a', 'Egypt');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (48, 'Almeda', 'Lucio', 'alucio1b@bizjournals.com', 'Agender', 'alucio1b', 'Libya');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (49, 'Rosco', 'Ricardin', 'rricardin1c@pen.io', 'Genderfluid', 'rricardin1c', 'Thailand');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (50, 'Verna', 'Maryska', 'vmaryska1d@goo.ne.jp', 'Male', 'vmaryska1d', 'Australia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (51, 'Bibbie', 'Crowcher', 'bcrowcher1e@sourceforge.net', 'Bigender', 'bcrowcher1e', 'Costa Rica');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (52, 'Maryanna', 'Jefford', 'mjefford1f@vinaora.com', 'Genderfluid', 'mjefford1f', 'Sweden');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (53, 'Terza', 'Lazar', 'tlazar1g@photobucket.com', 'Male', 'tlazar1g', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (54, 'Faythe', 'Searle', 'fsearle1h@studiopress.com', 'Female', 'fsearle1h', 'Russia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (55, 'Land', 'Richardsson', 'lrichardsson1i@infoseek.co.jp', 'Bigender', 'lrichardsson1i', 'Poland');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (56, 'Kristos', 'Powney', 'kpowney1j@acquirethisname.com', 'Polygender', 'kpowney1j', 'Russia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (57, 'Kikelia', 'Shurrocks', 'kshurrocks1k@exblog.jp', 'Bigender', 'kshurrocks1k', 'Cameroon');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (58, 'Trenton', 'Belitz', 'tbelitz1l@thetimes.co.uk', 'Female', 'tbelitz1l', 'Philippines');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (59, 'Anitra', 'Matevosian', 'amatevosian1m@php.net', 'Female', 'amatevosian1m', 'Germany');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (60, 'Hamlin', 'Zuppa', 'hzuppa1n@nasa.gov', 'Polygender', 'hzuppa1n', 'Argentina');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (61, 'Hans', 'Whiteson', 'hwhiteson1o@vk.com', 'Female', 'hwhiteson1o', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (62, 'Gabriel', 'Leele', 'gleele1p@buzzfeed.com', 'Bigender', 'gleele1p', 'Brazil');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (63, 'Maddy', 'Coster', 'mcoster1q@infoseek.co.jp', 'Genderqueer', 'mcoster1q', 'France');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (64, 'Pascal', 'Baughen', 'pbaughen1r@weebly.com', 'Non-binary', 'pbaughen1r', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (65, 'Marie-ann', 'Wallege', 'mwallege1s@stanford.edu', 'Non-binary', 'mwallege1s', 'Ethiopia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (66, 'Che', 'Dikelin', 'cdikelin1t@goo.ne.jp', 'Agender', 'cdikelin1t', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (67, 'Bobbette', 'Farndon', 'bfarndon1u@dell.com', 'Female', 'bfarndon1u', 'Cuba');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (68, 'Rolfe', 'Gladtbach', 'rgladtbach1v@bravesites.com', 'Genderfluid', 'rgladtbach1v', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (69, 'Wainwright', 'Oldershaw', 'woldershaw1w@rambler.ru', 'Agender', 'woldershaw1w', 'Portugal');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (70, 'Dian', 'Deakins', 'ddeakins1x@people.com.cn', 'Non-binary', 'ddeakins1x', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (71, 'Megen', 'Robyns', 'mrobyns1y@usda.gov', 'Genderqueer', 'mrobyns1y', 'Indonesia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (72, 'Lelia', 'Jaskowicz', 'ljaskowicz1z@theatlantic.com', 'Genderqueer', 'ljaskowicz1z', 'United States');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (73, 'Kit', 'Tulley', 'ktulley20@auda.org.au', 'Genderfluid', 'ktulley20', 'France');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (74, 'Annissa', 'Borsnall', 'aborsnall21@vimeo.com', 'Agender', 'aborsnall21', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (75, 'Demott', 'Pexton', 'dpexton22@nifty.com', 'Male', 'dpexton22', 'Indonesia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (76, 'Augie', 'McFayden', 'amcfayden23@gravatar.com', 'Male', 'amcfayden23', 'Morocco');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (77, 'Theodore', 'Keaveney', 'tkeaveney24@ca.gov', 'Polygender', 'tkeaveney24', 'Japan');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (78, 'Dennie', 'Goublier', 'dgoublier25@google.com.hk', 'Female', 'dgoublier25', 'Vietnam');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (79, 'Skell', 'Huby', 'shuby26@umn.edu', 'Male', 'shuby26', 'Poland');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (80, 'Aubine', 'Martyn', 'amartyn27@blogtalkradio.com', 'Female', 'amartyn27', 'Poland');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (81, 'Barbabra', 'Espada', 'bespada28@prweb.com', 'Non-binary', 'bespada28', 'Sweden');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (82, 'Ber', 'Barchrameev', 'bbarchrameev29@multiply.com', 'Male', 'bbarchrameev29', 'France');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (83, 'Quill', 'Sarge', 'qsarge2a@phpbb.com', 'Polygender', 'qsarge2a', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (84, 'Olenolin', 'Firpo', 'ofirpo2b@slideshare.net', 'Male', 'ofirpo2b', 'Canada');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (85, 'Weylin', 'Tourner', 'wtourner2c@networkadvertising.org', 'Non-binary', 'wtourner2c', 'Russia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (86, 'Alasdair', 'Petit', 'apetit2d@about.com', 'Male', 'apetit2d', 'Indonesia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (87, 'Dian', 'Hadwin', 'dhadwin2e@mayoclinic.com', 'Agender', 'dhadwin2e', 'Portugal');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (88, 'Dyanne', 'Leefe', 'dleefe2f@cpanel.net', 'Female', 'dleefe2f', 'Brazil');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (89, 'Alwin', 'Foulgham', 'afoulgham2g@blog.com', 'Bigender', 'afoulgham2g', 'Brazil');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (90, 'Liana', 'Brokenshire', 'lbrokenshire2h@123-reg.co.uk', 'Genderqueer', 'lbrokenshire2h', 'Thailand');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (91, 'Benedikt', 'Ick', 'bick2i@si.edu', 'Female', 'bick2i', 'South Korea');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (92, 'Creigh', 'Chartre', 'cchartre2j@miibeian.gov.cn', 'Genderfluid', 'cchartre2j', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (93, 'Joleen', 'Durrant', 'jdurrant2k@privacy.gov.au', 'Genderqueer', 'jdurrant2k', 'China');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (94, 'Amity', 'Bayston', 'abayston2l@diigo.com', 'Male', 'abayston2l', 'Egypt');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (95, 'Eachelle', 'Jagg', 'ejagg2m@ed.gov', 'Polygender', 'ejagg2m', 'Sweden');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (96, 'Regina', 'De Bruin', 'rdebruin2n@mac.com', 'Male', 'rdebruin2n', 'South Korea');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (97, 'Mufi', 'Henkmann', 'mhenkmann2o@a8.net', 'Polygender', 'mhenkmann2o', 'Uganda');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (98, 'Elene', 'Linfield', 'elinfield2p@smh.com.au', 'Polygender', 'elinfield2p', 'Russia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (99, 'Retha', 'Godbald', 'rgodbald2q@fda.gov', 'Agender', 'rgodbald2q', 'Russia');
insert into customer_details_mock (id, first_name, last_name, email, gender, username, country_of_residence) values (100, 'Domeniga', 'Burles', 'dburles2r@weather.com', 'Genderfluid', 'dburles2r', 'China');

/*drug_mock*/
insert into drug_mock (id, drug_brand, drug_name, price) values (1, 'Gleostine', 'lomustine', 114);
insert into drug_mock (id, drug_brand, drug_name, price) values (2, 'Naproxen', 'Naproxen', 155);
insert into drug_mock (id, drug_brand, drug_name, price) values (3, 'Testes Apis', 'Testes Apis', 192);
insert into drug_mock (id, drug_brand, drug_name, price) values (4, 'Acetaminophen, Chlorpheniramine Maleate, Dextromethorphan Hydrobromide, Phenylephrine Hydrochloride', 'ACETAMINOPHEN, CHLORPHENIRAMINE MALEATE, DEXTROMETHORPHAN HYDROBROMIDE, and PHENYLEPHRINE HYDROCHLORIDE', 192);
insert into drug_mock (id, drug_brand, drug_name, price) values (5, 'Ribavirin', 'Ribavirin', 137);
insert into drug_mock (id, drug_brand, drug_name, price) values (6, 'EPIVIR', 'lamivudine', 187);
insert into drug_mock (id, drug_brand, drug_name, price) values (7, 'Terrasil Foot and Nail Anti-Fungal', 'Clotrimazole', 185);
insert into drug_mock (id, drug_brand, drug_name, price) values (8, 'Evtox', 'Cochlearia officinalis, Echinacea angustifolia, Hydrastis canadensis, Lomatium, Tabebuia impetiginosa, Propolis, Glandula suprarenalis, Thymus, Aranea diadema,', 182);
insert into drug_mock (id, drug_brand, drug_name, price) values (9, 'PROSOPIS JULIFLORA POLLEN', 'Mesquite', 173);
insert into drug_mock (id, drug_brand, drug_name, price) values (10, 'Pedesil', 'Clotrimazole', 142);
insert into drug_mock (id, drug_brand, drug_name, price) values (11, 'ADVIL COLD AND SINUS', 'ibuprofen, pseudoephedrine HCl', 181);
insert into drug_mock (id, drug_brand, drug_name, price) values (12, 'SENEXON-S', 'DOCUSATE SODIUM -SENNOSIDES', 190);
insert into drug_mock (id, drug_brand, drug_name, price) values (13, 'Dibucaine', 'Dibucaine', 127);
insert into drug_mock (id, drug_brand, drug_name, price) values (14, 'Hydroxyzine Hydrochloride', 'Hydroxyzine Hydrochloride', 118);
insert into drug_mock (id, drug_brand, drug_name, price) values (15, 'Ondansetron Hydrochloride', 'Ondansetron Hydrochloride', 192);
insert into drug_mock (id, drug_brand, drug_name, price) values (16, 'Sulfamethoxazole and Trimethoprim', 'Sulfamethoxazole and Trimethoprim', 121);
insert into drug_mock (id, drug_brand, drug_name, price) values (17, 'Smooth texture Orange flavor', 'psyllium husk', 148);
insert into drug_mock (id, drug_brand, drug_name, price) values (18, 'HACKBERRY POLLEN', 'celtis occidentalis pollen', 105);
insert into drug_mock (id, drug_brand, drug_name, price) values (19, 'Brimonidine Tartrate', 'Brimonidine Tartrate', 187);
insert into drug_mock (id, drug_brand, drug_name, price) values (20, 'MAJOR DOK Docusate Sodium', 'DOCUSATE SODIUM', 100);
insert into drug_mock (id, drug_brand, drug_name, price) values (21, 'LOSARTAN POTASSIUM AND HYDROCHLOROTHIAZIDE', 'LOSARTAN POTASSIUM AND HYDROCHLOROTHIAZIDE', 113);
insert into drug_mock (id, drug_brand, drug_name, price) values (22, 'KLONOPIN', 'CLONAZEPAM', 140);
insert into drug_mock (id, drug_brand, drug_name, price) values (23, 'Nux vomica', 'Nux vomica', 110);
insert into drug_mock (id, drug_brand, drug_name, price) values (24, 'FENTANYL TRANSDERMAL SYSTEM', 'fentanyl transdermal system', 192);
insert into drug_mock (id, drug_brand, drug_name, price) values (25, 'Promethazine Hydrochloride', 'Promethazine Hydrochloride', 123);
insert into drug_mock (id, drug_brand, drug_name, price) values (26, 'Fremont Cottonwood', 'Fremont Cottonwood', 116);
insert into drug_mock (id, drug_brand, drug_name, price) values (27, 'Lithium Carbonate', 'Lithium Carbonate', 196);
insert into drug_mock (id, drug_brand, drug_name, price) values (28, 'Softlips Birthday Cake', 'dimethicone, octinoxate, octisalate, oxybenzone', 174);
insert into drug_mock (id, drug_brand, drug_name, price) values (29, 'Manefit Beauty Planner Lily Whitening Brightening Mask', 'Niacinamide', 195);
insert into drug_mock (id, drug_brand, drug_name, price) values (30, 'VERMA HP', 'Barium Carbonate, Oyster Shell Calcium Carbonate, Crude, Artemisia Cina Flower, Iron, Mercuric Sulfate, Sodium Phosphate, Dibasic, Heptahydrate, Schoenocaulon Officinale Seed, Spigelia Anthelmia, Teucrium Marum', 120);
insert into drug_mock (id, drug_brand, drug_name, price) values (31, 'CANDIDA MONILA ALBICANS', 'candida albicans', 192);
insert into drug_mock (id, drug_brand, drug_name, price) values (32, 'No7 Lifting and Firming Skincare System Day Sunscreen SPF 8', 'Avobenzone, Octinoxate and Octisalate', 146);
insert into drug_mock (id, drug_brand, drug_name, price) values (33, 'Ultracruz Antibacterial Hand', 'BENZALKONIUM CHLORIDE', 194);
insert into drug_mock (id, drug_brand, drug_name, price) values (34, 'PANADOL', 'acetaminophen and diphenhydramine HCl', 173);
insert into drug_mock (id, drug_brand, drug_name, price) values (35, 'Zicam', 'oxymetazoline hydrochloride', 112);
insert into drug_mock (id, drug_brand, drug_name, price) values (36, 'Pioglitazone Hydrochloride', 'pioglitazone hydrochloride', 103);
insert into drug_mock (id, drug_brand, drug_name, price) values (37, 'Quetiapine Fumarate', 'Quetiapine Fumarate', 186);
insert into drug_mock (id, drug_brand, drug_name, price) values (38, 'Lisinopril and Hydrochlorothiazide', 'lisinopril and hydrochlorothiazide', 159);
insert into drug_mock (id, drug_brand, drug_name, price) values (39, 'Neomycin and Polymyxin B Sulfates and Hydrocortisone', 'Neomycin and Polymyxin B Sulfates and Hydrocortisone', 137);
insert into drug_mock (id, drug_brand, drug_name, price) values (40, 'Sage', 'Sage', 127);
insert into drug_mock (id, drug_brand, drug_name, price) values (41, 'Neostigmine Methylsulfate', 'Neostigmine Methylsulfate', 143);
insert into drug_mock (id, drug_brand, drug_name, price) values (42, 'Cyclobenzaprine Hydrochloride', 'Cyclobenzaprine Hydrochloride', 106);
insert into drug_mock (id, drug_brand, drug_name, price) values (43, 'Bio Oak', 'Oak', 196);
insert into drug_mock (id, drug_brand, drug_name, price) values (44, 'IPKN Moist and Firm BB 02 MEDIUM', 'TITANIUM DIOXIDE, OCTINOXATE, ZINC OXIDE', 194);
insert into drug_mock (id, drug_brand, drug_name, price) values (45, 'PURE SHEER', 'Octinoxate and Titanium dioxide', 126);
insert into drug_mock (id, drug_brand, drug_name, price) values (46, 'Bumetanide', 'Bumetanide', 138);
insert into drug_mock (id, drug_brand, drug_name, price) values (47, 'Olanzapine', 'Olanzapine', 189);
insert into drug_mock (id, drug_brand, drug_name, price) values (48, 'Short Ragweed', 'Ambrosia artemisiifolia', 196);
insert into drug_mock (id, drug_brand, drug_name, price) values (49, 'Nighttime Cold and Flu Relief', 'ACETAMINOPHEN, DEXTROMETHORPHAN HYDROBROMIDE, DOXYLAMINE SUCCINATE', 183);
insert into drug_mock (id, drug_brand, drug_name, price) values (50, 'Ciprofloxacin and Dextrose', 'CIPROFLOXACIN', 149);
insert into drug_mock (id, drug_brand, drug_name, price) values (51, 'Antibacterial', 'Alcohol', 114);
insert into drug_mock (id, drug_brand, drug_name, price) values (52, 'CULTIVATED OATS POLLEN', 'avena sativa pollen', 193);
insert into drug_mock (id, drug_brand, drug_name, price) values (53, 'Soft Care Neutra Germ Fragrance Free Antibacterial', 'Triclosan', 118);
insert into drug_mock (id, drug_brand, drug_name, price) values (54, 'Loratadine and Pseudoephedrine Sulfate', 'Loratadine and Pseudoephedrine Sulfate', 189);
insert into drug_mock (id, drug_brand, drug_name, price) values (55, 'Exelon', 'rivastigmine', 108);
insert into drug_mock (id, drug_brand, drug_name, price) values (56, 'DiBromm DM', 'BROMPHENIRAMINE MALEATE , PHENYLEPHRINE HYDROCHLORIDE, DEXTROMETHORPHAN HYDROBROMIDE,', 190);
insert into drug_mock (id, drug_brand, drug_name, price) values (57, 'Lymphomyosot', 'GERANIUM ROBERTIANUM and RORIPPA NASTURTIUM-AQUATICUM and TRIBASIC CALCIUM PHOSPHATE and LEVOTHYROXINE and', 156);
insert into drug_mock (id, drug_brand, drug_name, price) values (58, 'Acetaminophen and Codeine', 'Acetaminophen and Codeine', 144);
insert into drug_mock (id, drug_brand, drug_name, price) values (59, 'Standardized Grass Pollen, Bluegrass, Kentucky (June)', 'Standardized Grass Pollen, Bluegrass, Kentucky (June)', 199);
insert into drug_mock (id, drug_brand, drug_name, price) values (60, 'Divalproex Sodium', 'Divalproex Sodium', 190);
insert into drug_mock (id, drug_brand, drug_name, price) values (61, 'SMITH BROS NON-DROWSY MULTI-SYMPTOM COLD and FLU', 'ACETAMINOPHEN, DEXTROMETHORPHAN HYDROBROMIDE, PHENYLEPHRINE HYDROCHLORIDE', 129);
insert into drug_mock (id, drug_brand, drug_name, price) values (62, 'Trichoderma harzianam', 'Trichoderma harzianam', 136);
insert into drug_mock (id, drug_brand, drug_name, price) values (63, 'Pyrilamine Maleate and Phenylephrine Hydrochloride', 'Pyrilamine Maleate and Phenylephrine Hydrochloride', 134);
insert into drug_mock (id, drug_brand, drug_name, price) values (64, 'Flu and Severe Cold and Cough', 'Acetaminophen, Dextromethorphan Hydrobromide, Phenylephrine Hydrochloride', 163);
insert into drug_mock (id, drug_brand, drug_name, price) values (65, 'Topcare Cold Head Congestion', 'Acetaminophen, Chlorpheniramine Maleate, Dextromethorphan Hydrobromide, Phenylephrine Hydrochloride', 133);
insert into drug_mock (id, drug_brand, drug_name, price) values (66, 'Clobetasol Propionate', 'Clobetasol Propionate', 134);
insert into drug_mock (id, drug_brand, drug_name, price) values (67, 'SIMETHICONE', 'DIMETHICONE', 176);
insert into drug_mock (id, drug_brand, drug_name, price) values (68, 'Risperidone M-TAB', 'risperidone', 111);
insert into drug_mock (id, drug_brand, drug_name, price) values (69, 'LBEL NATURAL FINISH MOISTURIZING FOUNDATION SPF 25', 'Octinoxate and Titanium Dioxide', 165);
insert into drug_mock (id, drug_brand, drug_name, price) values (70, 'Image Essentials Hair Regrowth Treatment', 'Minoxidil', 196);
insert into drug_mock (id, drug_brand, drug_name, price) values (71, 'Saline Nasal', 'Sodium chloride', 176);
insert into drug_mock (id, drug_brand, drug_name, price) values (72, 'Bicalutamide', 'Bicalutamide', 187);
insert into drug_mock (id, drug_brand, drug_name, price) values (73, 'Baby Respiration', 'Aconite, Antimonium Tart , Arnica , Carbo Veg', 143);
insert into drug_mock (id, drug_brand, drug_name, price) values (74, 'OXY', 'Salicylic Acid', 134);
insert into drug_mock (id, drug_brand, drug_name, price) values (75, 'CEFTRIAXONE', 'CEFTRIAXONE', 139);
insert into drug_mock (id, drug_brand, drug_name, price) values (76, 'Leader Adult Tussin DM', 'Dextromethorphan HBr, Guaifenesin', 187);
insert into drug_mock (id, drug_brand, drug_name, price) values (77, 'Alprazolam', 'alprazolam', 129);
insert into drug_mock (id, drug_brand, drug_name, price) values (78, 'Pork', 'Pork', 176);
insert into drug_mock (id, drug_brand, drug_name, price) values (79, 'Zoledronic Acid', 'Zoledronic Acid', 107);
insert into drug_mock (id, drug_brand, drug_name, price) values (80, 'Oxybutynin Chloride', 'Oxybutynin Chloride', 131);
insert into drug_mock (id, drug_brand, drug_name, price) values (81, 'Levofloxacin', 'Levofloxacin', 122);
insert into drug_mock (id, drug_brand, drug_name, price) values (82, 'Hydroxyzine Pamoate', 'Hydroxyzine Pamoate', 176);
insert into drug_mock (id, drug_brand, drug_name, price) values (83, 'Dr Smiths Diaper Rash', 'Zinc Oxide', 195);
insert into drug_mock (id, drug_brand, drug_name, price) values (84, 'Radish', 'Radish', 175);
insert into drug_mock (id, drug_brand, drug_name, price) values (85, 'Intuniv', 'guanfacine', 151);
insert into drug_mock (id, drug_brand, drug_name, price) values (86, 'Nisoldipine', 'Nisoldipine', 119);
insert into drug_mock (id, drug_brand, drug_name, price) values (87, 'Medical Provider Single Use EZ Flu Shot 2013-2014', 'influenza a virus a/christchurch/16/2010 nib-74 (h1n1) antigen (propiolactone inactivated), influenza a virus a/victoria/361/2011 ivr-165 (h3n2) antigen (propiolactone inactivated), influenza b virus b/hubei-wujiagang/158/2009 bx-39 antigen (propiolactone inactivated) and Isopropyl Alcohol', 145);
insert into drug_mock (id, drug_brand, drug_name, price) values (88, 'LoratadineXX and Pseudoephedrine Sulfate', 'LoratadineXX and Pseudoephedrine Sulfate', 189);
insert into drug_mock (id, drug_brand, drug_name, price) values (89, 'Childrens Mucinex Stuffy Nose and Cold', 'Guaifenesin and Phenylephrine Hydrochloride', 184);
insert into drug_mock (id, drug_brand, drug_name, price) values (90, 'Pramipexole Dihydrochloride', 'Pramipexole Dihydrochloride', 130);
insert into drug_mock (id, drug_brand, drug_name, price) values (91, 'ERY-TAB', 'Erythromycin', 183);
insert into drug_mock (id, drug_brand, drug_name, price) values (92, 'Equate Aspirin', 'Aspirin', 164);
insert into drug_mock (id, drug_brand, drug_name, price) values (93, 'Mickey Sun Smacker SPF 24 Classic Sherbet', 'OCTINOXATE, OXYBENZONE, PADIMATE O', 134);
insert into drug_mock (id, drug_brand, drug_name, price) values (94, 'MBM 4 Kidney', 'Kidney (suis), Solidago virgaurea, Berberis vulgaris, Carcinosinum, Belladonna, Cicuta virosa, Nitricum acidum, Aconitum napellus, Argentum nitricum, Arnica montana,', 141);
insert into drug_mock (id, drug_brand, drug_name, price) values (95, 'Amlodipine Besylate and Benazepril Hydrochloride', 'Amlodipine Besylate and Benazepril Hydrochloride', 158);
insert into drug_mock (id, drug_brand, drug_name, price) values (96, 'TYLENOL COLD', 'Acetaminophen, Dextromethorphan Hydrobromide, Doxylamine Succinate, and Phenylephrine Hydrochloride', 130);
insert into drug_mock (id, drug_brand, drug_name, price) values (97, 'Petroleum Jelly', 'WHITE PETROLEUM', 198);
insert into drug_mock (id, drug_brand, drug_name, price) values (98, 'GRASTEK', 'Timothy Grass Pollen Allergen Extract', 158);
insert into drug_mock (id, drug_brand, drug_name, price) values (99, 'DIDREX', 'benzphetamine hydrochloride', 176);
insert into drug_mock (id, drug_brand, drug_name, price) values (100, 'Disney PIXAR Cars Antibacterial Hand Wipes', 'BENZALKONIUM CHLORIDE', 162);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO purchases(
	date_of_purchase, username, drug_brand, drug_name, price)
	SELECT 
	(NOW() + (random() * (NOW()+'-7 days' - NOW()))) as date_of_purchase,
 	a.username, 
	b.drug_brand, 
	b.drug_name, 
	b.price
	FROM 
	customer_details_mock a
	CROSS JOIN 
	drug_mock b
	ORDER BY RANDOM()
	limit 1000;
