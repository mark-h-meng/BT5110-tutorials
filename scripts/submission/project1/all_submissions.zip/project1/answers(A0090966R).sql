/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/
/* Student Number : <A0090966R>                                         */
/* Student Name   : <WU BOWEI>                                          */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for SQLite */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The purpose of designing the tables is to know how many students enrolled
in each module within a academic year in order to plan the resources 
accordlingly, such as the sizes of the classrooms, number of teaching assistants 
and so on. In addition, the tables also allow us to know the total umber of 
module credits that each student is taking in order to prevent exceeding 
maximum module credits allowed to take for each year. 

There are three tables been created with names 'students', 'modules' and 
'enrolments' respectively.

Table 'students' (or entity set E1) contains the basic information of the
students from a school with admission year of 2010, for example NUS School 
of Computing. Basic information includs 'student_id', 'first_name', 'last_name', 
'email', 'nationality', 'admission_year' and 'date_of_birth'.

Table 'modules' (or entity set E2) contains the basic information of the 
models offer by the school. Information includes 'module_number', 'academic_year',
and 'module_credits'.

Table 'enrolments' (or many-to-many relationship set R) contains the modeule
enrolments of the students between year 2010 and 2012. The attributes include 
'student_id', 'module_number' and 'academic_year'. 

The code is written for SQLite
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS students (
	student_id VARCHAR(10) PRIMARY KEY,
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	email VARCHAR(256) UNIQUE NOT NULL,
	nationality VARCHAR(32) NOT NULL,
	admission_year DATE NOT NULL,
	date_of_birth DATE NOT NULL
	CHECK(admission_year >= date_of_birth)
	);

CREATE TABLE IF NOT EXISTS modules (
	module_number CHAR(5) NOT NULL,
	academic_year DATE NOT NULL,
	module_credits INT CHECK(module_credits>=0),
	PRIMARY KEY (module_number, academic_year)); 

CREATE TABLE IF NOT EXISTS enrolments (
	student_id VARCHAR(10) REFERENCES students(student_id)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED,
	module_number CHAR(5) NOT NULL,
	academic_year VARCHAR(4) NOT NULL,
	CHECK (academic_year > 2000),
	PRIMARY KEY (student_id, module_number, academic_year)
	FOREIGN KEY (module_number, academic_year) REFERENCES modules(module_number, academic_year)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED); 


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

--populate data into table 'students'
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S1', 'Keen', 'Benech', 'kbenech0@creativecommons.org', 'Jamaica', '2010-08-01', '1992-08-14');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S2', 'Timofei', 'Kain', 'tkain1@yahoo.com', 'Philippines', '2010-08-01', '1992-04-10');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S3', 'Sheela', 'Scrowby', 'sscrowby2@comsenz.com', 'Russia', '2010-08-01', '1990-10-05');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S4', 'Charlotte', 'Huerta', 'chuerta3@nhs.uk', 'Poland', '2010-08-01', '1993-09-01');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S5', 'Twyla', 'Ades', 'tades4@mlb.com', 'China', '2010-08-01', '1991-01-07');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S6', 'Ynes', 'Gossipin', 'ygossipin5@theatlantic.com', 'Cameroon', '2010-08-01', '1992-12-19');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S7', 'Gwenni', 'Birk', 'gbirk6@gmpg.org', 'China', '2010-08-01', '1993-10-25');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S8', 'Lyon', 'Bollis', 'lbollis7@nih.gov', 'Indonesia', '2010-08-01', '1990-08-25');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S9', 'Stanleigh', 'Dallosso', 'sdallosso8@sbwire.com', 'Indonesia', '2010-08-01', '1991-08-29');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S10', 'Almira', 'Coggell', 'acoggell9@noaa.gov', 'Philippines', '2010-08-01', '1992-09-22');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S11', 'Gabbi', 'Fontel', 'gfontela@vkontakte.ru', 'Indonesia', '2010-08-01', '1993-08-15');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S12', 'Salaidh', 'Carnew', 'scarnewb@sitemeter.com', 'China', '2010-08-01', '1992-05-04');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S13', 'Lalo', 'Folk', 'lfolkc@i2i.jp', 'Brazil', '2010-08-01', '1990-12-30');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S14', 'Randa', 'Kirkbright', 'rkirkbrightd@trellian.com', 'Brazil', '2010-08-01', '1992-12-22');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S15', 'Enriqueta', 'O''Bradain', 'eobradaine@unc.edu', 'Indonesia', '2010-08-01', '1992-10-05');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S16', 'Bobbie', 'Gerdes', 'bgerdesf@domainmarket.com', 'Thailand', '2010-08-01', '1990-06-29');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S17', 'Chloe', 'Bukac', 'cbukacg@jalbum.net', 'Thailand', '2010-08-01', '1991-02-04');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S18', 'Krystalle', 'Nanetti', 'knanettih@unicef.org', 'China', '2010-08-01', '1991-09-07');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S19', 'Arny', 'Bragger', 'abraggeri@altervista.org', 'Mexico', '2010-08-01', '1993-06-01');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S20', 'Selie', 'Eilles', 'seillesj@pbs.org', 'China', '2010-08-01', '1991-02-02');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S21', 'Laurent', 'MacSporran', 'lmacsporrank@oaic.gov.au', 'Ivory Coast', '2010-08-01', '1990-04-20');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S22', 'Dick', 'Derges', 'ddergesl@dell.com', 'Canada', '2010-08-01', '1990-01-28');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S23', 'Marlo', 'Esmond', 'mesmondm@salon.com', 'Peru', '2010-08-01', '1993-05-07');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S24', 'Jayme', 'Patinkin', 'jpatinkinn@utexas.edu', 'Ukraine', '2010-08-01', '1991-06-24');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S25', 'Jaime', 'Trangmar', 'jtrangmaro@eventbrite.com', 'South Korea', '2010-08-01', '1992-04-14');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S26', 'Ashely', 'Bartleet', 'abartleetp@storify.com', 'Russia', '2010-08-01', '1993-11-02');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S27', 'Jerad', 'Snook', 'jsnookq@columbia.edu', 'Sweden', '2010-08-01', '1993-10-30');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S28', 'Earlie', 'Acaster', 'eacasterr@sourceforge.net', 'Thailand', '2010-08-01', '1991-09-27');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S29', 'Terry', 'Lindro', 'tlindros@edublogs.org', 'Indonesia', '2010-08-01', '1991-08-16');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S30', 'Mellie', 'Bartell', 'mbartellt@liveinternet.ru', 'Honduras', '2010-08-01', '1991-06-12');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S31', 'Damon', 'Cherrison', 'dcherrisonu@trellian.com', 'Russia', '2010-08-01', '1991-01-19');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S32', 'Sande', 'Brashier', 'sbrashierv@zimbio.com', 'Indonesia', '2010-08-01', '1992-04-21');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S33', 'Billy', 'Cristofari', 'bcristofariw@ocn.ne.jp', 'China', '2010-08-01', '1992-07-18');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S34', 'Cully', 'McCreery', 'cmccreeryx@cdbaby.com', 'China', '2010-08-01', '1990-10-19');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S35', 'Noelani', 'Moniker', 'nmonikery@intel.com', 'Brazil', '2010-08-01', '1991-11-03');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S36', 'Arney', 'Blackaller', 'ablackallerz@guardian.co.uk', 'Indonesia', '2010-08-01', '1992-03-27');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S37', 'Zack', 'Crollman', 'zcrollman10@instagram.com', 'Brazil', '2010-08-01', '1992-02-19');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S38', 'Deidre', 'Yakunin', 'dyakunin11@i2i.jp', 'Indonesia', '2010-08-01', '1993-07-25');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S39', 'Dionne', 'Bottjer', 'dbottjer12@wired.com', 'China', '2010-08-01', '1990-09-16');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S40', 'Emilio', 'Hallihan', 'ehallihan13@linkedin.com', 'Mexico', '2010-08-01', '1990-10-17');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S41', 'Shawn', 'Verissimo', 'sverissimo14@wsj.com', 'Bosnia and Herzegovina', '2010-08-01', '1992-10-16');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S42', 'Dicky', 'Carragher', 'dcarragher15@blogspot.com', 'Slovenia', '2010-08-01', '1992-08-15');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S43', 'Yule', 'Pieche', 'ypieche16@europa.eu', 'Indonesia', '2010-08-01', '1992-11-11');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S44', 'Cyndia', 'Scurlock', 'cscurlock17@amazon.co.uk', 'Slovenia', '2010-08-01', '1993-11-14');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S45', 'Carroll', 'Donn', 'cdonn18@symantec.com', 'Armenia', '2010-08-01', '1991-09-28');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S46', 'Cati', 'Reaney', 'creaney19@state.tx.us', 'China', '2010-08-01', '1992-12-20');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S47', 'Rik', 'Larman', 'rlarman1a@admin.ch', 'Nigeria', '2010-08-01', '1990-06-19');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S48', 'Carmine', 'Clemenson', 'cclemenson1b@spotify.com', 'Tajikistan', '2010-08-01', '1993-09-10');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S49', 'Rubi', 'Huguenet', 'rhuguenet1c@webeden.co.uk', 'Cuba', '2010-08-01', '1990-10-04');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S50', 'Saw', 'Alibone', 'salibone1d@symantec.com', 'China', '2010-08-01', '1992-10-02');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S51', 'Odessa', 'Widdup', 'owiddup1e@amazon.com', 'Thailand', '2010-08-01', '1991-03-14');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S52', 'Stefan', 'Mulberry', 'smulberry1f@godaddy.com', 'Indonesia', '2010-08-01', '1992-02-06');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S53', 'Kay', 'Whitmore', 'kwhitmore1g@forbes.com', 'China', '2010-08-01', '1992-08-09');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S54', 'Egon', 'Gildroy', 'egildroy1h@quantcast.com', 'Sri Lanka', '2010-08-01', '1990-09-10');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S55', 'Andee', 'Groundwater', 'agroundwater1i@foxnews.com', 'United States', '2010-08-01', '1990-04-13');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S56', 'Arv', 'Minigo', 'aminigo1j@symantec.com', 'Bahrain', '2010-08-01', '1993-03-26');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S57', 'Farris', 'Amorts', 'famorts1k@huffingtonpost.com', 'China', '2010-08-01', '1992-09-21');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S58', 'Burg', 'Angood', 'bangood1l@dailymotion.com', 'Russia', '2010-08-01', '1993-09-18');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S59', 'Concettina', 'Moncreiff', 'cmoncreiff1m@devhub.com', 'Sweden', '2010-08-01', '1991-12-13');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S60', 'Maryl', 'Brunesco', 'mbrunesco1n@tinyurl.com', 'Japan', '2010-08-01', '1993-05-15');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S61', 'Kerianne', 'Wyer', 'kwyer1o@nyu.edu', 'Brazil', '2010-08-01', '1991-08-04');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S62', 'Heywood', 'Sarath', 'hsarath1p@freewebs.com', 'China', '2010-08-01', '1991-02-24');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S63', 'Shelby', 'Schubbert', 'sschubbert1q@forbes.com', 'Poland', '2010-08-01', '1990-02-15');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S64', 'Frank', 'Swinford', 'fswinford1r@tmall.com', 'Uganda', '2010-08-01', '1990-06-14');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S65', 'Cornie', 'Orring', 'corring1s@feedburner.com', 'Poland', '2010-08-01', '1990-09-06');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S66', 'Martina', 'Orehead', 'morehead1t@timesonline.co.uk', 'Bulgaria', '2010-08-01', '1993-11-27');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S67', 'Adrea', 'Briddock', 'abriddock1u@netvibes.com', 'Philippines', '2010-08-01', '1991-11-14');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S68', 'Oralia', 'Kiley', 'okiley1v@bravesites.com', 'China', '2010-08-01', '1991-06-02');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S69', 'Ardis', 'MacAndreis', 'amacandreis1w@cdbaby.com', 'Sweden', '2010-08-01', '1990-01-06');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S70', 'Beatrix', 'Baiss', 'bbaiss1x@ucsd.edu', 'China', '2010-08-01', '1990-09-30');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S71', 'Humfrey', 'Timny', 'htimny1y@geocities.jp', 'China', '2010-08-01', '1990-01-23');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S72', 'Shawna', 'O'' Cloney', 'socloney1z@reference.com', 'Colombia', '2010-08-01', '1991-05-23');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S73', 'Kyle', 'Britee', 'kbritee20@wordpress.org', 'Russia', '2010-08-01', '1993-07-30');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S74', 'Willi', 'Seago', 'wseago21@weebly.com', 'Russia', '2010-08-01', '1992-02-02');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S75', 'Mortimer', 'Klinck', 'mklinck22@flavors.me', 'Nepal', '2010-08-01', '1991-12-22');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S76', 'Elissa', 'Sleaford', 'esleaford23@imageshack.us', 'China', '2010-08-01', '1990-05-10');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S77', 'Gerrard', 'Turri', 'gturri24@cbsnews.com', 'Dominica', '2010-08-01', '1990-12-28');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S78', 'Richy', 'Innot', 'rinnot25@surveymonkey.com', 'China', '2010-08-01', '1993-08-13');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S79', 'Hadrian', 'Wormleighton', 'hwormleighton26@ameblo.jp', 'Indonesia', '2010-08-01', '1993-01-02');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S80', 'Maude', 'Inns', 'minns27@earthlink.net', 'Indonesia', '2010-08-01', '1993-03-25');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S81', 'Aidan', 'Muat', 'amuat28@yelp.com', 'China', '2010-08-01', '1991-11-15');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S82', 'Patrica', 'Redihough', 'predihough29@posterous.com', 'China', '2010-08-01', '1993-08-14');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S83', 'Geordie', 'Weiser', 'gweiser2a@omniture.com', 'Colombia', '2010-08-01', '1993-02-12');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S84', 'Jacques', 'Wickenden', 'jwickenden2b@biblegateway.com', 'China', '2010-08-01', '1993-09-30');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S85', 'Jarad', 'Menendes', 'jmenendes2c@tamu.edu', 'Indonesia', '2010-08-01', '1993-08-01');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S86', 'Velvet', 'Dannell', 'vdannell2d@ustream.tv', 'Sri Lanka', '2010-08-01', '1993-06-02');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S87', 'Siana', 'Tiley', 'stiley2e@smugmug.com', 'China', '2010-08-01', '1993-06-21');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S88', 'Toiboid', 'Westoff', 'twestoff2f@wikia.com', 'Slovenia', '2010-08-01', '1992-04-02');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S89', 'Erich', 'Deveral', 'edeveral2g@1und1.de', 'Thailand', '2010-08-01', '1992-04-01');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S90', 'Meier', 'Cronin', 'mcronin2h@blogger.com', 'Serbia', '2010-08-01', '1993-03-04');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S91', 'Celestyna', 'Bretland', 'cbretland2i@baidu.com', 'Norway', '2010-08-01', '1991-08-13');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S92', 'Stace', 'Mills', 'smills2j@ucoz.com', 'China', '2010-08-01', '1991-06-09');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S93', 'Rodolfo', 'Varcoe', 'rvarcoe2k@cam.ac.uk', 'France', '2010-08-01', '1990-06-08');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S94', 'Sibella', 'Brewitt', 'sbrewitt2l@vkontakte.ru', 'Argentina', '2010-08-01', '1992-05-26');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S95', 'Mateo', 'Rummins', 'mrummins2m@gmpg.org', 'Yemen', '2010-08-01', '1993-07-27');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S96', 'Bellanca', 'Fewless', 'bfewless2n@lycos.com', 'Philippines', '2010-08-01', '1991-02-24');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S97', 'Boy', 'Baffin', 'bbaffin2o@pinterest.com', 'China', '2010-08-01', '1993-03-07');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S98', 'Aleta', 'Cubbinelli', 'acubbinelli2p@exblog.jp', 'China', '2010-08-01', '1992-09-03');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S99', 'Mirella', 'Barthelmes', 'mbarthelmes2q@usgs.gov', 'Indonesia', '2010-08-01', '1993-04-27');
insert into students (student_id, first_name, last_name, email, nationality, admission_year, date_of_birth) values ('S100', 'Cherilyn', 'Needs', 'cneeds2r@scientificamerican.com', 'Costa Rica', '2010-08-01', '1992-07-21');

--populate data into table 'modules'
insert into modules (module_number, academic_year, module_credits) values ('M1541', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1482', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1323', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1069', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1296', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1780', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1995', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1819', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1723', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1809', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1329', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1152', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1615', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1970', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1270', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1012', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1718', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1558', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1055', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1297', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1448', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1536', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1362', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1047', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1102', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1015', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1425', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1078', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1525', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1383', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1224', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1197', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1638', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1886', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1128', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1295', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1220', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1487', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1034', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1471', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1784', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1099', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1122', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1356', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1933', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1687', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1210', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1190', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1908', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1746', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1338', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1100', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1115', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1985', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1926', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1560', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1267', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1051', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1978', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1137', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1008', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1058', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1029', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1431', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1134', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1185', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1631', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1113', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1465', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1801', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1931', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1426', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1232', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1878', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1796', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1664', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1420', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1229', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1613', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1686', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1714', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1265', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1119', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1838', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1637', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1967', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1775', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1347', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1607', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1410', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1885', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1389', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1400', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1773', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1751', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1472', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1001', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1439', '2010-08-01', 3);
insert into modules (module_number, academic_year, module_credits) values ('M1844', '2010-08-01', 4);
insert into modules (module_number, academic_year, module_credits) values ('M1194', '2010-08-01', 3);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS enrolments (
	student_id VARCHAR(10) REFERENCES enrolments(student_id),
	module_number CHAR(5) NOT NULL,
	academic_year DATE NOT NULL,
	PRIMARY KEY (student_id, module_number, academic_year)); 

INSERT INTO enrolments
SELECT s.student_id, m.module_number, m.academic_year
FROM students s CROSS JOIN modules m
ORDER BY RANDOM() LIMIT 1000;

--OR
--CREATE VIEW enrolments2 AS 
--SELECT s.student_id, m.module_number, m.academic_year
--FROM students s CROSS JOIN modules m
--ORDER BY RANDOM() LIMIT 1000;


