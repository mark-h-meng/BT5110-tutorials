/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*Entity E1 is different drugs produced by drug companies
Entity E2 is customers
Optional many-to-many relationship set R is the drug perscription
Written in PostgreSQL
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS Drug (
	company_name VARCHAR(1024) NOT NULL,
	brand_name VARCHAR(1024),
	generic_name VARCHAR(1024),
	price NUMERIC NOT NULL,
	PRIMARY KEY (company_name, brand_name));

CREATE TABLE IF NOT EXISTS Customer(
	customerid VARCHAR(64) PRIMARY KEY,
	first_name VARCHAR(1024) NOT NULL,
	last_name VARCHAR(11024) NOT NULL,
	email VARCHAR(1024) UNIQUE NOT NULL,
	dob DATE NOT NULL,
	country VARCHAR(64) NOT NULL);
	
CREATE TABLE IF NOT EXISTS Prescription(
	customerid VARCHAR(64) REFERENCES Customer (customerid),
	company_name VARCHAR (1024),
	brand_name VARCHAR(1024),
	PRIMARY KEY (customerid, company_name, brand_name),
	FOREIGN KEY (company_name, brand_name) REFERENCES Drug(company_name, brand_name));
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into Drug (company_name, brand_name, generic_name, price) values ('Nelco Laboratories, Inc.', 'Tangerine', 'Tangerine', 85);
insert into Drug (company_name, brand_name, generic_name, price) values ('AvPAK', 'Benazepril Hydrochloride', 'Benazepril Hydrochloride', 29);
insert into Drug (company_name, brand_name, generic_name, price) values ('Antigen Laboratories, Inc.', 'Treatment Set TS349945', 'Treatment Set TS349945', 45);
insert into Drug (company_name, brand_name, generic_name, price) values ('ImClone LLC', 'ERBITUX', 'cetuximab', 90);
insert into Drug (company_name, brand_name, generic_name, price) values ('Nelco Laboratories, Inc.', 'Casein', 'Casein', 76);
insert into Drug (company_name, brand_name, generic_name, price) values ('CVS', 'Extra Strength Acetaminohpen', 'Acetaminophen', 96);
insert into Drug (company_name, brand_name, generic_name, price) values ('McKesson Packaging Services a business unit of McKesson Corporation', 'Alprazolam', 'Alprazolam', 66);
insert into Drug (company_name, brand_name, generic_name, price) values ('AvPAK', 'DIPYRIDAMOLE', 'DIPYRIDAMOLE', 27);
insert into Drug (company_name, brand_name, generic_name, price) values ('Carilion Materials Management', 'Theophylline', 'Theophylline', 28);
insert into Drug (company_name, brand_name, generic_name, price) values ('Valeant Pharmaceuticals North America LLC', 'Retin-A MICRO', 'Tretinoin', 65);
insert into Drug (company_name, brand_name, generic_name, price) values ('Valeant Pharmaceuticals North America LLC', 'ANCOBON', 'Flucytosine', 60);
insert into Drug (company_name, brand_name, generic_name, price) values ('American Health Packaging', 'PROPOXYPHENE NAPSYLATE AND ACETAMINOPHEN', 'propoxyphene napsylate and acetaminophen', 55);
insert into Drug (company_name, brand_name, generic_name, price) values ('NorthStar Rx LLC', 'Cefdinir', 'Cefdinir', 31);
insert into Drug (company_name, brand_name, generic_name, price) values ('L Perrigo Company', 'good sense ibuprofen', 'Ibuprofen', 28);
insert into Drug (company_name, brand_name, generic_name, price) values ('DZA Brands LLC', 'healthy accents miconazole 3', 'Miconazole nitrate', 21);
insert into Drug (company_name, brand_name, generic_name, price) values ('Golden State Medical Supply, Inc.', 'Methocarbamol', 'Methocarbamol', 23);
insert into Drug (company_name, brand_name, generic_name, price) values ('ENCHANTE ACCESSORIES INC.', 'Charlie girl Grape Antibacterial Hand Sanitizer', 'ALCOHOL', 95);
insert into Drug (company_name, brand_name, generic_name, price) values ('Wal-Mart Stores Inc', 'Suphedrine PE', 'Chlorpheniramine maleate and Phenylephrine HCl', 21);
insert into Drug (company_name, brand_name, generic_name, price) values ('Amneal Pharmaceuticals, LLC', 'Oxycodone and Acetaminophen', 'Oxycodone and Acetaminophen', 75);
insert into Drug (company_name, brand_name, generic_name, price) values ('Empack Spraytech Inc', 'SunZone Kids SPF 45', 'Octocrylene, Octisalate, Homosalate, Avobenzone and Oxybenzone', 80);
insert into Drug (company_name, brand_name, generic_name, price) values ('Fenwal, Inc.', 'ADSOL Red Cell Preservation Solution System in Plastic Container (PL 146 Plastic)', 'Anticoagulant Citrate Phosphate Dextrose (CPD) Solution and ADSOL Preservation Solution', 56);
insert into Drug (company_name, brand_name, generic_name, price) values ('Clinical Solutions Wholesale', 'promethazine hydrochloride', 'promethazine hydrochloride', 97);
insert into Drug (company_name, brand_name, generic_name, price) values ('Amylin Pharmaceuticals, LLC', 'Byetta', 'exenatide', 34);
insert into Drug (company_name, brand_name, generic_name, price) values ('General Injectables & Vaccines, Inc', 'Propranolol Hydrochloride', 'Propranolol Hydrochloride', 52);
insert into Drug (company_name, brand_name, generic_name, price) values ('Melaleuca, Inc.', 'SUN SHADES', 'octinoxate and oxybenzone', 25);
insert into Drug (company_name, brand_name, generic_name, price) values ('Mylan Pharmaceuticals Inc.', 'Carbidopa, Levodopa and Entacapone', 'carbidopa, levodopa and entacapone', 100);
insert into Drug (company_name, brand_name, generic_name, price) values ('Mylan Pharmaceuticals Inc.', 'Diltiazem Hydrochloride', 'diltiazem hydrochloride', 49);
insert into Drug (company_name, brand_name, generic_name, price) values ('Watson Pharma, Inc.', 'Omeprazole', 'Omeprazole', 78);
insert into Drug (company_name, brand_name, generic_name, price) values ('ALK-Abello, Inc.', 'QUERCUS AGRIFOLIA POLLEN', 'Oak California Live Coast', 47);
insert into Drug (company_name, brand_name, generic_name, price) values ('WHITE MANUFACTURING INC. DBA MICRO WEST', 'CHRON SINO', 'ARSENICUM ALBUM,MAGNESIA PHOSPHORICA,PULSATILLA,RHUS TOXICODENDRON,BAPTISIA,PHYTOLACCA,HYDRASTIS,SEPIA,ECHINACEA,MERCURIUS SOLUBILIS,KALI BICHROMICUM,', 90);
insert into Drug (company_name, brand_name, generic_name, price) values ('Hospira Worldwide, Inc.', 'Methotrexate', 'METHOTREXATE SODIUM', 90);
insert into Drug (company_name, brand_name, generic_name, price) values ('REMEDYREPACK INC.', 'Doxazosin', 'Doxazosin Mesylate', 63);
insert into Drug (company_name, brand_name, generic_name, price) values ('Rebel Distributors Corp', 'Acetaminophen and Codeine Phosphate', 'Acetaminophen and Codeine Phosphate', 91);
insert into Drug (company_name, brand_name, generic_name, price) values ('HyVee Inc', 'pain relief', 'Acetaminophen', 27);
insert into Drug (company_name, brand_name, generic_name, price) values ('Kareway Product, Inc.', 'Alcohol Prep Pads', 'isopropyl alcohol', 48);
insert into Drug (company_name, brand_name, generic_name, price) values ('Special Care Medical', 'Oxygen', 'Oxygen', 42);
insert into Drug (company_name, brand_name, generic_name, price) values ('Unit Dose Services', 'NEXIUM', 'Esomeprazole magnesium', 31);
insert into Drug (company_name, brand_name, generic_name, price) values ('Babor Cosmetics America, Corp.', 'BABOR Cleansing Gel and Tonic', 'Equisetum Arvense Top', 99);
insert into Drug (company_name, brand_name, generic_name, price) values ('Mission Hills S.A de C.V', 'COLGATE', 'SODIUM MONOFLUOROPHOSPHATE', 35);
insert into Drug (company_name, brand_name, generic_name, price) values ('Summit Industries, Inc.', 'LanoGuard', 'LANOLIN', 95);
insert into Drug (company_name, brand_name, generic_name, price) values ('PD-Rx Pharmaceuticals, Inc.', 'Allopurinol', 'allopurinol', 74);
insert into Drug (company_name, brand_name, generic_name, price) values ('Bolero Home Decor, Inc.', 'Disney FROZEN BERRY SCENTED ANTISEPTIC HAND CLEANSING', 'ALCOHOL', 22);
insert into Drug (company_name, brand_name, generic_name, price) values ('Caraco Pharmaceutical Laboratories, Ltd.', 'Minocycline Hydrochloride', 'Minocycline Hydrochloride', 66);
insert into Drug (company_name, brand_name, generic_name, price) values ('Cardinal Health', 'Azithromycin', 'Azithromycin', 41);
insert into Drug (company_name, brand_name, generic_name, price) values ('Bare Escentuals Beauty, Inc.', 'bareMinerals Prime Time BB Primer Daily Defense Broad Spectrum SPF 30', 'Titanium Dioxide and Zinc Oxide', 21);
insert into Drug (company_name, brand_name, generic_name, price) values ('Tarte, Inc.', 'Amazonian Colored Clay Foundation Broad Spectrum SPF 15 Sunscreen', 'Titanium Dioxide and Zinc Oxide', 48);
insert into Drug (company_name, brand_name, generic_name, price) values ('Native Remedies,', 'Vagi-Clear', 'Kali phosphoricum, Kreosotum, Nitricum acidum, Pulsatilla, Sepia', 31);
insert into Drug (company_name, brand_name, generic_name, price) values ('ENERGIZER PERSONAL CARE, LLC', 'Banana Boat Mens', 'Avobenzone,Homosalate,Octisalate,Octocrylene,Oxybenzone', 82);
insert into Drug (company_name, brand_name, generic_name, price) values ('Claris Lifesciences, Inc.', 'Ampicillin', 'Ampicillin sodium', 73);
insert into Drug (company_name, brand_name, generic_name, price) values ('Dabur India Limited', 'Bee Smart', 'SODIUM MONOFLUOROPHOSPHATE', 62);
insert into Drug (company_name, brand_name, generic_name, price) values ('CVS PHARMACY', 'BABY TEETHING', 'CHAMOMILLA, CALCAREA PHOSPHORICA, COFFEA CRUDA, BELLADONNA', 32);
insert into Drug (company_name, brand_name, generic_name, price) values ('Roxane Laboratories, Inc.', 'Leucovorin Calcium', 'Leucovorin Calcium', 52);
insert into Drug (company_name, brand_name, generic_name, price) values ('Hebei Yihoucheng Commodity Co.,Ltd.', 'Antibacterial Wet Wipes', 'BENZALKONIUM CHLORIDE', 56);
insert into Drug (company_name, brand_name, generic_name, price) values ('Reckitt Benckiser LLC', 'Clearasil Ultra', 'Salicylic Acid', 84);
insert into Drug (company_name, brand_name, generic_name, price) values ('C.B. Fleet Company, Inc.', 'Fleet', 'Docusate Sodium', 48);
insert into Drug (company_name, brand_name, generic_name, price) values ('Nelco Laboratories, Inc.', 'Sisal', 'Sisal', 59);
insert into Drug (company_name, brand_name, generic_name, price) values ('Boehringer Ingelheim Pharmaceuticals, Inc.', 'DulcoGas', 'simethicone', 31);
insert into Drug (company_name, brand_name, generic_name, price) values ('Nelco Laboratories, Inc.', 'Cedar Elm', 'Cedar Elm', 94);
insert into Drug (company_name, brand_name, generic_name, price) values ('SAM''S WEST INC.', 'SIMPLY RIGHT', 'TRICLOSAN', 87);
insert into Drug (company_name, brand_name, generic_name, price) values ('Newton Laboratories, Inc.', 'Dizziness - Vertigo', 'Absinthium, Aconitum nap., Antimon. tart., Belladonna, Bryonia, Carbolicum acidum, Colchicum, Conium, Ferrum metallicum, Gelsemium, Glonoinum, Hyoscyamus, Ipecac., Iris versicolor, Lycopodium, Nux vom., Petroleum, Phosphorus, Sepia, Symphoricarpus racemosus, Tabacum, Theridion, Zingiber, Echinacea, Hypericum, Passiflora, Valeriana', 45);
insert into Drug (company_name, brand_name, generic_name, price) values ('AvPAK', 'Montelukast Sodium', 'Montelukast Sodium', 87);
insert into Drug (company_name, brand_name, generic_name, price) values ('Apotheca Company', 'Virotox WN', 'Echinacea angustifolia, Hydrastis canadensis, Lomatium, Myrrha, Nasturtium aquaticum, Tabebuia impetiginosa, Glandula suprarenalis, Thymus', 94);
insert into Drug (company_name, brand_name, generic_name, price) values ('Chang Kuo Chou Pharmaceutical Co. Ltd.', 'Stomachin Antacid', 'Magnesium carbonate and Sodium bicarbonate', 85);
insert into Drug (company_name, brand_name, generic_name, price) values ('HOMEOLAB USA INC.', 'ASAFOETIDA', 'ASAFOETIDA', 24);
insert into Drug (company_name, brand_name, generic_name, price) values ('Unit Dose Services', 'Propranolol Hydrochloride', 'Propranolol Hydrochloride', 91);
insert into Drug (company_name, brand_name, generic_name, price) values ('Johnson & Johnson Healthcare Products, Division of McNEIL-PPC, Inc.', 'Visine A', 'Naphazoline Hydrochloride and Pheniramine Maleate', 89);
insert into Drug (company_name, brand_name, generic_name, price) values ('Preferred Pharmaceuticals, Inc.', 'Butalbital, Acetaminophen and Caffeine', 'Butalbital, Acetaminophen and Caffeine', 60);
insert into Drug (company_name, brand_name, generic_name, price) values ('Mylan Pharmaceuticals Inc.', 'Oxycodone and Acetaminophen', 'Oxycodone hydrochloride and Acetaminophen', 45);
insert into Drug (company_name, brand_name, generic_name, price) values ('SiCap Industries LLC', 'Allergy Buster', 'Capsicum annuum, Urtica dioica', 73);
insert into Drug (company_name, brand_name, generic_name, price) values ('BioActive Nutritional, Inc.', 'Renotox', 'not applicable', 86);
insert into Drug (company_name, brand_name, generic_name, price) values ('Bryant Ranch Prepack', 'ATACAND', 'Candesartan cilexetil', 76);
insert into Drug (company_name, brand_name, generic_name, price) values ('Schering Plough Corporation', 'Avelox', 'moxifloxacin hydrochloride', 58);
insert into Drug (company_name, brand_name, generic_name, price) values ('State of Florida DOH Central Pharmacy', 'Digoxin', 'DIGOXIN', 20);
insert into Drug (company_name, brand_name, generic_name, price) values ('Home Smart Products', 'Health Smart Aloe Vera Petroleum', 'White Petroleum', 65);
insert into Drug (company_name, brand_name, generic_name, price) values ('Barona Co., Ltd', 'S Balloon Slim Body Line', 'HYDROGENATED SOYBEAN', 52);
insert into Drug (company_name, brand_name, generic_name, price) values ('Peaceful Mountain, Inc.', 'Muscle Ice', 'Phytolacca decandra, Symphytum officinale, Bellis perennis, Ledum palustre, Ruta graveolens, Magnesia phosphorica, Silicea,', 58);
insert into Drug (company_name, brand_name, generic_name, price) values ('LG Household and Healthcare, Inc.', 'ISAKNOX AGELESS SERUM COMPACT 23', 'TITANIUM DIOXIDE, OCTINOXATE', 77);
insert into Drug (company_name, brand_name, generic_name, price) values ('Salado Sales, Inc.', 'Sinus Congestion and Pain', 'Acetaminophen and Phenylephrine HCl', 21);
insert into Drug (company_name, brand_name, generic_name, price) values ('State of Florida DOH Central Pharmacy', 'Klor-Con', 'Potassium Chloride', 20);
insert into Drug (company_name, brand_name, generic_name, price) values ('Equaline', 'Childrens Plus Cough and Runny Nose', 'ACETAMINOPHEN, CHLORPHENIRAMINE MALEATE, DEXTROMETHORPHAN HYDROBROMIDE,', 95);
insert into Drug (company_name, brand_name, generic_name, price) values ('Synergy Formulas, Inc.', 'DEPRESSION COMPOSITION', 'NOT APPLICABLE', 50);
insert into Drug (company_name, brand_name, generic_name, price) values ('Sandoz Inc', 'cisatracurium besylate', 'cisatracurium besylate', 41);
insert into Drug (company_name, brand_name, generic_name, price) values ('Proficient Rx LP', 'good sense all day pain relief', 'Naproxen Sodium', 28);
insert into Drug (company_name, brand_name, generic_name, price) values ('Strides Arcolab Limited', 'pramipexole dihydrochloride', 'pramipexole dihydrochloride', 59);
insert into Drug (company_name, brand_name, generic_name, price) values ('Ben E. Keith Foods', 'Ben E. Keith', 'Triclosan', 49);
insert into Drug (company_name, brand_name, generic_name, price) values ('REMEDYREPACK INC.', 'KENALOG-40', 'TRIAMCINOLONE ACETONIDE', 54);
insert into Drug (company_name, brand_name, generic_name, price) values ('ALK-Abello, Inc.', 'PISTACHIO', 'Pistachio Nut', 27);
insert into Drug (company_name, brand_name, generic_name, price) values ('Liddell Laboratories, Inc.', 'Herpeset', 'Apis mellifica, Arsenicum album, Baptisia tinctoria, Capsicum annuum, Dulcamara, Echinacea, Nitricum acidum, Pyrogenium, Rhus toxicodendron,', 57);
insert into Drug (company_name, brand_name, generic_name, price) values ('Apotheca Company', 'Metabolism', 'Berberis vulgaris, Glycyrrhiza glabra, Lappa major, Rhamnus purshiana, Trifolium pratense, Xanthoxylum fraxineum, Ascorbic acid, Cyanocobalamin, Riboflavinum, Thiaminum hydrochloricum, German sesquiox', 47);
insert into Drug (company_name, brand_name, generic_name, price) values ('NCS HealthCare of KY, Inc dba Vangard Labs', 'Atenolol', 'atenolol', 20);
insert into Drug (company_name, brand_name, generic_name, price) values ('California Tool and Welding Supply, LLC', 'OXYGEN', 'OXYGEN', 90);
insert into Drug (company_name, brand_name, generic_name, price) values ('Actavis Pharma, Inc.', 'Guanfacine', 'Guanfacine', 43);
insert into Drug (company_name, brand_name, generic_name, price) values ('Guna spa', 'MICOX', 'ASPERGILLUS NIGER VAR. NIGER - CANDIDA ALBICANS - CENTELLA ASIATICA - MALIC ACID - MERCURIC CHLORIDE - RHIZOPUS STOLONIFER - SODIUM DIETHYL OXALACETATE - SULFUR - TABEBUIA IMPETIGINOSA BARK -', 67);
insert into Drug (company_name, brand_name, generic_name, price) values ('Ilex Consumer Products Group, LLC', 'Cough and Cold Relief HBP', 'Chlorpheniramine maleate and Dextromethorphan HBr', 31);
insert into Drug (company_name, brand_name, generic_name, price) values ('IASO Inc', 'IASO FOR MEN WHITE EX 2-IN-1 FLUID SUPREME', 'GLYCERIN', 61);
insert into Drug (company_name, brand_name, generic_name, price) values ('REMEDYREPACK INC.', 'NAPROXEN', 'NAPROXEN', 82);
insert into Drug (company_name, brand_name, generic_name, price) values ('BTA PHARMACEUTICALS INC', 'ZOVIRAX', 'acyclovir', 85);
insert into Drug (company_name, brand_name, generic_name, price) values ('New World Imports, Inc', 'Non-Aspirin PM Extra Strength', 'Acetaminophen, Diphenhydramine HCl', 96);
insert into Drug (company_name, brand_name, generic_name, price) values ('Rite Aid', 'Extra Strength Gas Relief', 'Simethicone', 35);
insert into Drug (company_name, brand_name, generic_name, price) values ('Northstar Rx LLC', 'MONO-LINYAH', 'Norgestimate and Ethinyl Estradiol', 92);

insert into Customer (customerid, first_name, last_name, email, dob, country) values ('70-076-8563', 'Claretta', 'Abbati', 'cabbati0@sina.com.cn', '1948-06-29', 'Indonesia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('77-498-9642', 'Ddene', 'Lempertz', 'dlempertz1@sfgate.com', '1998-11-13', 'Philippines');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('82-665-6149', 'Kris', 'Claasen', 'kclaasen2@auda.org.au', '2014-04-01', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('07-614-9183', 'Martynne', 'Carrack', 'mcarrack3@accuweather.com', '1932-01-27', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('58-525-9063', 'Moe', 'McOwan', 'mmcowan4@walmart.com', '1991-01-16', 'Peru');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('44-828-6922', 'Glenine', 'Marqyes', 'gmarqyes5@unesco.org', '2007-10-19', 'Taiwan');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('20-910-8214', 'Eben', 'Folliott', 'efolliott6@msn.com', '1965-10-14', 'France');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('47-762-5414', 'Evanne', 'Oboy', 'eoboy7@privacy.gov.au', '2010-02-16', 'Honduras');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('99-921-3783', 'Clemmy', 'Creaven', 'ccreaven8@house.gov', '1937-01-14', 'Finland');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('85-505-9235', 'Hilton', 'Delahunt', 'hdelahunt9@google.com.br', '2008-12-08', 'Argentina');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('50-190-3209', 'Emanuel', 'Arnal', 'earnala@symantec.com', '1947-02-19', 'Yemen');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('06-733-2024', 'Vin', 'Forsaith', 'vforsaithb@craigslist.org', '1976-06-01', 'Poland');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('18-008-9773', 'Jock', 'Currum', 'jcurrumc@webnode.com', '2020-02-12', 'Moldova');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('76-169-1853', 'Merv', 'MacIntosh', 'mmacintoshd@pen.io', '1966-10-01', 'Sweden');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('43-108-7260', 'Ivan', 'Bunt', 'ibunte@xrea.com', '1966-11-26', 'Indonesia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('80-879-1708', 'Rickie', 'Stubbings', 'rstubbingsf@bbb.org', '2007-02-05', 'Poland');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('95-023-9968', 'Michele', 'Pimme', 'mpimmeg@dell.com', '1958-03-11', 'Russia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('59-399-5442', 'Tanny', 'Sapshed', 'tsapshedh@4shared.com', '2018-10-26', 'Indonesia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('12-479-9393', 'Amandy', 'O''Keenan', 'aokeenani@narod.ru', '1944-03-12', 'Russia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('43-387-0163', 'Damara', 'Hing', 'dhingj@lulu.com', '1998-01-26', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('83-480-9692', 'Nance', 'Meredyth', 'nmeredythk@desdev.cn', '1923-12-21', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('37-854-3675', 'Brana', 'De Ruggiero', 'bderuggierol@trellian.com', '1978-07-02', 'Poland');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('47-142-6010', 'Wait', 'Snugg', 'wsnuggm@acquirethisname.com', '2014-05-05', 'Aland Islands');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('93-340-3828', 'Flinn', 'Rydzynski', 'frydzynskin@miibeian.gov.cn', '1984-11-23', 'Czech Republic');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('71-071-8804', 'Bernette', 'Gingold', 'bgingoldo@elpais.com', '1926-03-12', 'Greece');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('45-136-5937', 'Ogdan', 'MacCole', 'omaccolep@reuters.com', '1960-07-22', 'Nigeria');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('59-544-0828', 'Ronna', 'Elton', 'reltonq@uiuc.edu', '1977-12-22', 'Brazil');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('06-953-1082', 'Bourke', 'Dossetter', 'bdossetterr@hexun.com', '1994-07-04', 'Philippines');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('36-101-0535', 'Newton', 'Van Der Vlies', 'nvandervliess@prnewswire.com', '1998-06-06', 'Peru');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('99-957-6372', 'Alard', 'Chishull', 'achishullt@aol.com', '1936-11-21', 'Indonesia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('23-579-5565', 'Dacey', 'Sarjent', 'dsarjentu@gnu.org', '1957-08-12', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('31-263-3196', 'Valentin', 'Voase', 'vvoasev@sfgate.com', '1985-06-29', 'Nepal');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('37-902-8089', 'Corny', 'Emlyn', 'cemlynw@accuweather.com', '1949-09-14', 'Peru');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('56-017-7127', 'Bat', 'Perry', 'bperryx@seattletimes.com', '1920-08-04', 'Philippines');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('64-049-3949', 'Regine', 'Leppingwell', 'rleppingwelly@marketwatch.com', '1921-02-07', 'Brazil');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('40-120-5045', 'Bart', 'Methven', 'bmethvenz@timesonline.co.uk', '1927-09-27', 'Colombia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('52-117-9556', 'Rozamond', 'Gover', 'rgover10@illinois.edu', '2003-04-29', 'Greece');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('77-284-7921', 'Donn', 'Ellingham', 'dellingham11@wufoo.com', '1953-06-14', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('17-664-6501', 'Mallory', 'Strettle', 'mstrettle12@skyrock.com', '2012-04-03', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('34-430-9590', 'Tamma', 'Forbear', 'tforbear13@ask.com', '1961-12-24', 'Brazil');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('04-430-4388', 'Luella', 'Febre', 'lfebre14@plala.or.jp', '2008-12-22', 'Ghana');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('97-880-0166', 'Gina', 'Oldale', 'goldale15@loc.gov', '1969-09-20', 'Slovenia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('43-964-3224', 'Gardie', 'Lush', 'glush16@xing.com', '1954-07-15', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('45-892-6590', 'Grier', 'Kingscote', 'gkingscote17@mapy.cz', '2013-08-28', 'Poland');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('55-271-3459', 'Sutton', 'Okroy', 'sokroy18@google.de', '2003-01-03', 'Canada');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('03-065-8774', 'Caty', 'Venturoli', 'cventuroli19@pen.io', '1921-10-19', 'Greece');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('98-420-7326', 'Adrien', 'Palliser', 'apalliser1a@constantcontact.com', '1943-01-07', 'Brazil');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('51-744-9748', 'Gregg', 'Bellefonte', 'gbellefonte1b@people.com.cn', '1951-01-03', 'Russia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('78-727-7457', 'Ario', 'Corringham', 'acorringham1c@weebly.com', '1936-12-07', 'Central African Republic');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('32-869-1357', 'Johnny', 'Tesoe', 'jtesoe1d@mashable.com', '1979-02-21', 'Poland');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('92-202-5150', 'Frants', 'Hans', 'fhans1e@ifeng.com', '1953-05-04', 'Indonesia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('17-757-0140', 'Lanie', 'Wrates', 'lwrates1f@ehow.com', '1932-10-20', 'Brazil');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('73-685-4278', 'Tann', 'Tesmond', 'ttesmond1g@phoca.cz', '1962-01-16', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('29-880-8454', 'Kameko', 'Vasichev', 'kvasichev1h@xrea.com', '1977-04-04', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('17-809-8017', 'Miriam', 'MacCallam', 'mmaccallam1i@epa.gov', '1989-01-31', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('32-843-9442', 'Carmelita', 'Retallack', 'cretallack1j@g.co', '1985-11-20', 'Brazil');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('97-848-9844', 'Matteo', 'Hanes', 'mhanes1k@sogou.com', '1930-11-13', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('24-620-0028', 'Gallard', 'De Normanville', 'gdenormanville1l@goo.ne.jp', '1970-06-04', 'Switzerland');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('11-665-8960', 'Brent', 'Speeding', 'bspeeding1m@trellian.com', '1932-10-29', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('19-031-4059', 'Margarita', 'Grastye', 'mgrastye1n@purevolume.com', '1999-01-14', 'Russia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('46-692-3177', 'Ryun', 'Kimmince', 'rkimmince1o@barnesandnoble.com', '1970-03-30', 'Indonesia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('92-584-9629', 'Wheeler', 'Neilly', 'wneilly1p@sitemeter.com', '1986-02-13', 'Sweden');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('04-693-1094', 'Deeann', 'Simnel', 'dsimnel1q@youku.com', '1960-02-18', 'Ecuador');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('05-935-3654', 'Kimberli', 'Lippiett', 'klippiett1r@youku.com', '1923-03-26', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('90-670-8527', 'Richart', 'Dwyr', 'rdwyr1s@stumbleupon.com', '2012-10-23', 'Portugal');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('23-204-4456', 'Aretha', 'Ivashinnikov', 'aivashinnikov1t@umn.edu', '1959-01-24', 'Philippines');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('31-730-5480', 'Olympia', 'Coatman', 'ocoatman1u@salon.com', '1965-01-19', 'Uzbekistan');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('08-614-8042', 'Roddy', 'Carwardine', 'rcarwardine1v@earthlink.net', '1979-08-07', 'Brazil');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('90-877-9879', 'Nan', 'Stolli', 'nstolli1w@time.com', '1940-03-14', 'Saudi Arabia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('72-351-4782', 'Page', 'Cleen', 'pcleen1x@last.fm', '1924-08-20', 'Indonesia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('33-538-3177', 'Graham', 'Brimilcombe', 'gbrimilcombe1y@seattletimes.com', '1972-07-12', 'Burkina Faso');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('81-612-9227', 'Guglielma', 'Itzakson', 'gitzakson1z@altervista.org', '1948-09-24', 'French Southern Territories');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('27-471-0033', 'Emlynn', 'Stroton', 'estroton20@networkadvertising.org', '2011-04-25', 'Russia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('27-403-5456', 'Nikki', 'Martonfi', 'nmartonfi21@skype.com', '1961-07-23', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('03-920-6834', 'Karlens', 'Hlavecek', 'khlavecek22@samsung.com', '1954-08-11', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('25-152-8835', 'Krystle', 'Chipp', 'kchipp23@elpais.com', '1983-08-12', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('97-911-2312', 'Yasmin', 'Tedahl', 'ytedahl24@forbes.com', '2014-10-18', 'Indonesia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('18-003-4531', 'Lind', 'Cohani', 'lcohani25@miitbeian.gov.cn', '1950-09-02', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('89-170-4014', 'Eulalie', 'Halsho', 'ehalsho26@uiuc.edu', '1930-01-27', 'Poland');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('24-546-2166', 'Amil', 'Worgan', 'aworgan27@typepad.com', '1973-12-28', 'Thailand');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('35-116-2196', 'Torrin', 'Rosenau', 'trosenau28@feedburner.com', '1956-08-27', 'Indonesia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('56-111-5347', 'Mercy', 'Itzkowicz', 'mitzkowicz29@yelp.com', '1985-09-05', 'Poland');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('30-626-2318', 'Mame', 'Drescher', 'mdrescher2a@networksolutions.com', '2008-01-27', 'Indonesia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('55-206-1571', 'Sherrie', 'Jackalin', 'sjackalin2b@statcounter.com', '1926-02-05', 'Germany');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('10-728-1684', 'Emylee', 'Naisbit', 'enaisbit2c@diigo.com', '1997-02-07', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('59-646-2019', 'Sander', 'Outright', 'soutright2d@multiply.com', '1934-06-19', 'Indonesia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('19-070-6596', 'Marna', 'Mauro', 'mmauro2e@ifeng.com', '1947-04-11', 'Poland');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('32-895-8113', 'Anselm', 'Fellgett', 'afellgett2f@imageshack.us', '2018-11-22', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('90-982-7100', 'Annecorinne', 'Ruseworth', 'aruseworth2g@walmart.com', '2019-09-26', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('82-282-2125', 'Carley', 'Macieiczyk', 'cmacieiczyk2h@de.vu', '1942-08-07', 'Indonesia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('74-158-0213', 'Lacy', 'Trinke', 'ltrinke2i@theglobeandmail.com', '1951-06-04', 'Indonesia');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('47-695-5834', 'Martainn', 'Gudgion', 'mgudgion2j@answers.com', '2011-07-21', 'Comoros');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('59-172-2615', 'Daisie', 'Divver', 'ddivver2k@epa.gov', '1999-02-19', 'Uruguay');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('22-651-4555', 'Jedidiah', 'Masham', 'jmasham2l@bbb.org', '1990-10-20', 'China');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('29-767-3426', 'Calley', 'Melody', 'cmelody2m@stanford.edu', '1957-07-15', 'Brazil');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('02-171-3955', 'Georgeanne', 'Caddan', 'gcaddan2n@cyberchimps.com', '1997-03-10', 'Argentina');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('32-583-5005', 'Nerte', 'Cleiment', 'ncleiment2o@upenn.edu', '2004-09-15', 'Venezuela');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('90-969-5842', 'Ranique', 'Belton', 'rbelton2p@elegantthemes.com', '1924-07-04', 'Tajikistan');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('49-844-9633', 'Lay', 'Ballintyne', 'lballintyne2q@auda.org.au', '1960-03-16', 'South Africa');
insert into Customer (customerid, first_name, last_name, email, dob, country) values ('58-371-1367', 'Lew', 'Edgerton', 'ledgerton2r@twitpic.com', '2019-10-01', 'China');


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO Prescription
SELECT c.customerid, d.company_name, d.brand_name
FROM Customer c CROSS JOIN Drug d

ORDER BY RANDOM()
LIMIT 1000
