/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The entity set E1 is to be AppDATA, and the entity set E2 is to be CompanyDATA, and
the optional many-to-many relationship set R is to be ParticipateInDevelopmentMapping.
The table AppDATA contains 4 attributes(namely app name, issue ID, issue date, number of users. The
issue ID is to be the primary key).
The table CompanyDATA contains 2 attributes(namely company name, country. The company name is to be the
primary key).
The table ParticipateInDevelopmentMapping associates the issue ID of apps to the names of the companies they belong to.

The code is written for PostgreSQL
*/

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE public."AppDATA"
(
    app_name character varying(30) COLLATE pg_catalog."default",
    copyright_id integer NOT NULL,
    issue_date character varying COLLATE pg_catalog."default",
    number_of_users integer,
    CONSTRAINT "App_pkey" PRIMARY KEY (copyright_id)
);

CREATE TABLE public."CompanyDATA"
(
    company_name character varying(30) COLLATE pg_catalog."default" NOT NULL,
    country character varying(30) COLLATE pg_catalog."default",
    CONSTRAINT "Company_pkey" PRIMARY KEY (company_name)
);

CREATE TABLE public."ParticipateInDevelopmentMapping"
(
    copyright_id integer,
    company_name character varying(30) COLLATE pg_catalog."default"
);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Asoka', 523210, '11/15/2019', 9187832);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Vagram', 645299, '6/24/2021', 5419117);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Y-find', 30264, '1/20/2021', 5727229);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Transcof', 767718, '1/18/2021', 808585);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Biodex', 893985, '1/31/2020', 5970951);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Alphazap', 459856, '2/22/2020', 2385554);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Bamity', 624236, '5/27/2020', 5449296);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Tres-Zap', 582460, '3/27/2020', 2357224);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Zoolab', 691039, '4/4/2020', 2706501);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Subin', 313111, '4/6/2020', 6663440);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Redhold', 109818, '11/12/2020', 3703554);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Hatity', 221293, '3/9/2021', 6176943);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Y-Solowarm', 669903, '11/16/2019', 7561747);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Bitchip', 515322, '5/7/2020', 6401901);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Cardguard', 792987, '9/1/2019', 8529759);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Bamity', 300007, '5/10/2020', 5608227);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Otcom', 328837, '6/29/2021', 8576716);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Lotlux', 400183, '6/20/2021', 8145334);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Konklab', 325824, '10/25/2020', 9043119);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Stringtough', 947694, '12/19/2020', 1030398);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Vagram', 475224, '5/14/2021', 687833);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Flexidy', 848726, '2/18/2021', 5282934);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Daltfresh', 278457, '9/15/2019', 7631336);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Alphazap', 143422, '5/16/2020', 2665419);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Y-Solowarm', 283991, '10/11/2020', 1754954);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Wrapsafe', 904980, '4/26/2021', 3166984);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Gembucket', 679036, '4/25/2021', 4059181);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Toughjoyfax', 784213, '3/13/2021', 3053140);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Zaam-Dox', 693087, '2/26/2020', 5897012);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Stronghold', 515121, '5/23/2020', 2991827);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Asoka', 876260, '5/11/2020', 9669721);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Ronstring', 256835, '11/9/2019', 9740399);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Fixflex', 784229, '12/17/2020', 9875611);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Latlux', 246889, '9/1/2019', 6067554);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Aerified', 455911, '7/8/2020', 1108751);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Hatity', 145147, '9/4/2019', 8636058);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Domainer', 914385, '10/5/2020', 6544956);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Bytecard', 821595, '10/14/2019', 5505912);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Zamit', 437300, '9/26/2019', 22492);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Biodex', 441457, '12/29/2019', 5437702);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Wrapsafe', 28279, '2/22/2020', 7539060);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Ronstring', 506572, '9/7/2019', 631011);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Zaam-Dox', 725225, '3/15/2021', 7520178);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Zaam-Dox', 268213, '7/10/2020', 7343932);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Tampflex', 577675, '5/22/2020', 9295376);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Voyatouch', 457317, '3/12/2021', 8528149);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Tin', 55379, '2/17/2021', 6321003);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Fixflex', 331037, '12/1/2020', 1468389);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Wrapsafe', 175045, '7/6/2021', 579835);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Y-Solowarm', 579876, '2/10/2021', 5606245);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Sub-Ex', 813414, '10/1/2019', 1082464);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Home Ing', 114002, '7/21/2020', 7599963);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Viva', 147138, '11/27/2020', 8609631);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Lotstring', 185658, '8/31/2019', 9708344);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Solarbreeze', 997544, '3/30/2020', 5202775);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Y-find', 68319, '9/16/2020', 6889773);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Pannier', 104336, '12/15/2020', 4033107);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Keylex', 480650, '3/17/2020', 468315);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Temp', 887152, '12/9/2020', 9317878);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Overhold', 777824, '12/30/2019', 4610707);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Fixflex', 130684, '1/3/2021', 6552293);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Flexidy', 737821, '1/9/2020', 4040568);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Treeflex', 229375, '12/22/2020', 7442053);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Namfix', 42589, '5/22/2020', 7253778);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Lotstring', 879246, '1/10/2021', 1523750);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Sub-Ex', 125632, '2/16/2020', 2303988);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('It', 951053, '5/6/2021', 7037118);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Subin', 737563, '1/26/2020', 7404412);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Home Ing', 16147, '5/31/2020', 874675);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Cardify', 918539, '2/15/2020', 7070029);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Temp', 490870, '1/13/2021', 5843415);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Alphazap', 503302, '1/28/2021', 8184087);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Alpha', 949877, '5/4/2020', 8292415);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Tin', 438546, '8/13/2021', 5121819);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Prodder', 869479, '2/4/2020', 1123840);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Redhold', 644728, '4/28/2020', 7692644);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Fixflex', 225541, '7/14/2021', 5542454);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Opela', 152699, '3/24/2020', 5191841);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Vagram', 990919, '12/9/2019', 7973534);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Greenlam', 946468, '9/15/2019', 9338881);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Bitwolf', 241703, '8/4/2021', 3980076);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Hatity', 656598, '9/15/2019', 3082196);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Cardguard', 84453, '8/15/2021', 8073310);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Veribet', 116016, '4/5/2020', 5564650);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Cardguard', 909141, '6/25/2021', 5631048);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Duobam', 423432, '8/27/2019', 2933947);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Zontrax', 692785, '6/14/2020', 5615316);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Ventosanzap', 722390, '6/15/2021', 8994895);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Y-Solowarm', 263628, '3/17/2021', 496916);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Bitwolf', 174754, '8/28/2019', 1424544);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Duobam', 145347, '1/7/2020', 8705808);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Trippledex', 705698, '8/10/2020', 9087759);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Kanlam', 188870, '12/29/2020', 1778155);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Konklux', 528317, '8/31/2020', 600287);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Trippledex', 506481, '10/8/2020', 4727594);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Bamity', 204341, '10/6/2019', 1800703);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Konklab', 179266, '10/11/2019', 1604256);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Toughjoyfax', 570825, '9/2/2019', 9872368);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Sonair', 784790, '8/7/2021', 8441168);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Tampflex', 906406, '7/13/2020', 2142684);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Sonair', 679721, '2/16/2020', 597140);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('It', 55720, '8/12/2020', 1623543);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Vagram', 826351, '6/22/2020', 6220564);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Cardguard', 856789, '6/15/2021', 3448542);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Tresom', 682790, '8/18/2020', 9253066);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Bigtax', 389190, '9/21/2019', 5809920);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Lotlux', 776271, '12/11/2019', 2122204);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Greenlam', 224056, '3/11/2021', 8600677);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Tresom', 930257, '8/13/2021', 9844875);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Zaam-Dox', 593597, '1/1/2021', 62994);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Regrant', 861023, '10/10/2019', 7441657);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Duobam', 628675, '1/6/2020', 4563199);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Latlux', 772294, '8/17/2020', 6533324);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Bitchip', 96700, '8/17/2020', 8615502);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Stringtough', 308902, '7/30/2020', 7835561);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Voltsillam', 870708, '5/20/2021', 3193870);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Stronghold', 795893, '4/21/2020', 6586768);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Cardguard', 280392, '10/18/2020', 4238325);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Solarbreeze', 897088, '11/13/2019', 9952415);
insert into public."AppDATA" (app_name, copyright_id, issue_date, number_of_users) values ('Sonair', 16757, '10/13/2020', 29198);

insert into public."CompanyDATA" (company_name, country) values ('Rhyziolbudyfjc', 'Indonesia');
insert into public."CompanyDATA" (company_name, country) values ('Thoughtstormyfdxgslw', 'Poland');
insert into public."CompanyDATA" (company_name, country) values ('Kambajpsdrcum', 'Peru');
insert into public."CompanyDATA" (company_name, country) values ('Photobeandunfkape', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Kwinufprjilvu', 'Philippines');
insert into public."CompanyDATA" (company_name, country) values ('Trupeujtbxowg', 'Thailand');
insert into public."CompanyDATA" (company_name, country) values ('Cogilithtmbdqkcw', 'Philippines');
insert into public."CompanyDATA" (company_name, country) values ('Thoughtmixsyxzfktd', 'Bosnia and Herzegovina');
insert into public."CompanyDATA" (company_name, country) values ('Jatrileawfbmv', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Pixoboocdohxvyw', 'Indonesia');
insert into public."CompanyDATA" (company_name, country) values ('Trudeolvakinyo', 'Ireland');
insert into public."CompanyDATA" (company_name, country) values ('Fivechatitnaovcj', 'Jamaica');
insert into public."CompanyDATA" (company_name, country) values ('Jetpulselkqxfbuc', 'Indonesia');
insert into public."CompanyDATA" (company_name, country) values ('Voontesezmxgdv', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Digitubehnzkjtvc', 'Russia');
insert into public."CompanyDATA" (company_name, country) values ('Tazzymoeplctu', 'Sweden');
insert into public."CompanyDATA" (company_name, country) values ('Zoonoodlezdlhfmjy', 'United States');
insert into public."CompanyDATA" (company_name, country) values ('Thoughtspherelaebmgcr', 'Portugal');
insert into public."CompanyDATA" (company_name, country) values ('Roomboqxhlyrkv', 'Burkina Faso');
insert into public."CompanyDATA" (company_name, country) values ('Meezzyvtcazred', 'Palau');
insert into public."CompanyDATA" (company_name, country) values ('Leentiqcotvpfn', 'Ethiopia');
insert into public."CompanyDATA" (company_name, country) values ('Tanoodlerfdsixlv', 'Portugal');
insert into public."CompanyDATA" (company_name, country) values ('Obagmhanlvu', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Skybledjtukxeg', 'Portugal');
insert into public."CompanyDATA" (company_name, country) values ('Skalithbyrqtvud', 'Nigeria');
insert into public."CompanyDATA" (company_name, country) values ('Twindermwadgcls', 'Philippines');
insert into public."CompanyDATA" (company_name, country) values ('Kwilithtbxswzvu', 'United States');
insert into public."CompanyDATA" (company_name, country) values ('Zoomboxipkeyard', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Trilithhqfzobnk', 'Poland');
insert into public."CompanyDATA" (company_name, country) values ('Flipopiajoqrlbty', 'Estonia');
insert into public."CompanyDATA" (company_name, country) values ('Tekflyzteqsdbo', 'Philippines');
insert into public."CompanyDATA" (company_name, country) values ('Buzzsterzauofcsm', 'Indonesia');
insert into public."CompanyDATA" (company_name, country) values ('Aiveetwiuqaeh', 'Norway');
insert into public."CompanyDATA" (company_name, country) values ('Vindervsruzyxw', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Myworksvdficrxq', 'Russia');
insert into public."CompanyDATA" (company_name, country) values ('Zoonderjryehogx', 'Bolivia');
insert into public."CompanyDATA" (company_name, country) values ('Dabvinepuhoavek', 'Russia');
insert into public."CompanyDATA" (company_name, country) values ('Yombuapewmkdv', 'Portugal');
insert into public."CompanyDATA" (company_name, country) values ('Bubbletubehacgpvwb', 'France');
insert into public."CompanyDATA" (company_name, country) values ('Mudoekhzlaqu', 'Serbia');
insert into public."CompanyDATA" (company_name, country) values ('Zoozzyvnkhdsrf', 'Ivory Coast');
insert into public."CompanyDATA" (company_name, country) values ('Pixopevebhdyrs', 'Philippines');
insert into public."CompanyDATA" (company_name, country) values ('Fatzoeabkqus', 'Venezuela');
insert into public."CompanyDATA" (company_name, country) values ('Abatzuidrjflg', 'Sweden');
insert into public."CompanyDATA" (company_name, country) values ('Tanoodleovykuzmj', 'Indonesia');
insert into public."CompanyDATA" (company_name, country) values ('Riffwireecflswvk', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Dynaboxzpdgulvi', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Wordpediapbfszwck', 'Czech Republic');
insert into public."CompanyDATA" (company_name, country) values ('Youbridgeftkqzgxc', 'France');
insert into public."CompanyDATA" (company_name, country) values ('Camidolxgiqsya', 'Central African Republic');
insert into public."CompanyDATA" (company_name, country) values ('Meejopzhwvoey', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Avambatqaozeij', 'Indonesia');
insert into public."CompanyDATA" (company_name, country) values ('Quimmciljoxgn', 'Indonesia');
insert into public."CompanyDATA" (company_name, country) values ('Jazzyakncxfto', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Gigashotsdnjqegtv', 'Russia');
insert into public."CompanyDATA" (company_name, country) values ('Katznlmibpok', 'Philippines');
insert into public."CompanyDATA" (company_name, country) values ('Wikizzqrsdewki', 'Ukraine');
insert into public."CompanyDATA" (company_name, country) values ('Dynaboxlfrpcodn', 'Sweden');
insert into public."CompanyDATA" (company_name, country) values ('Mybuzzruwviyhs', 'Indonesia');
insert into public."CompanyDATA" (company_name, country) values ('Flipopiaxvjlayip', 'Kenya');
insert into public."CompanyDATA" (company_name, country) values ('Skiptubehoulkfiv', 'Tanzania');
insert into public."CompanyDATA" (company_name, country) values ('Babbleopiaqadufynb', 'Afghanistan');
insert into public."CompanyDATA" (company_name, country) values ('Thoughtmixmvoidspx', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Zooxoxnsheovj', 'Honduras');
insert into public."CompanyDATA" (company_name, country) values ('Kareqtfwpsoz', 'Sweden');
insert into public."CompanyDATA" (company_name, country) values ('Pixonyxgwpmkceq', 'Russia');
insert into public."CompanyDATA" (company_name, country) values ('Npathmjibwstd', 'Indonesia');
insert into public."CompanyDATA" (company_name, country) values ('Blogtagodjqwcby', 'Russia');
insert into public."CompanyDATA" (company_name, country) values ('Kwideolsezgwbk', 'Pakistan');
insert into public."CompanyDATA" (company_name, country) values ('Wordtunelbidfynz', 'France');
insert into public."CompanyDATA" (company_name, country) values ('Skynoodlesfurovtn', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Wordpediaatmuylcx', 'Greece');
insert into public."CompanyDATA" (company_name, country) values ('Myworksvnimhueq', 'Kenya');
insert into public."CompanyDATA" (company_name, country) values ('Dabtypehkazpljq', 'France');
insert into public."CompanyDATA" (company_name, country) values ('Mideluhvopbnt', 'Sweden');
insert into public."CompanyDATA" (company_name, country) values ('Gigashotsnojvatfx', 'Chile');
insert into public."CompanyDATA" (company_name, country) values ('Gigazoomiubpcvlh', 'United Kingdom');
insert into public."CompanyDATA" (company_name, country) values ('Shuffletaggmflkiaw', 'Indonesia');
insert into public."CompanyDATA" (company_name, country) values ('Browsetypexwvdyrbh', 'Thailand');
insert into public."CompanyDATA" (company_name, country) values ('Browsedriveqpnaltvj', 'South Korea');
insert into public."CompanyDATA" (company_name, country) values ('Kazioxwnudlpv', 'Portugal');
insert into public."CompanyDATA" (company_name, country) values ('Riffwiresncfmabk', 'Indonesia');
insert into public."CompanyDATA" (company_name, country) values ('Wikivulrjhiacg', 'Poland');
insert into public."CompanyDATA" (company_name, country) values ('Edgeifystmzvyxj', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Flashdogyprlzcif', 'Russia');
insert into public."CompanyDATA" (company_name, country) values ('Yakijoxvcrsugi', 'Philippines');
insert into public."CompanyDATA" (company_name, country) values ('Kaymbovzswhbqm', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Browsedrivevgqhxjmz', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Topicwarewcdbnrea', 'Uruguay');
insert into public."CompanyDATA" (company_name, country) values ('Skimiaqectfkyv', 'Comoros');
insert into public."CompanyDATA" (company_name, country) values ('Oyoloozsupveno', 'Libya');
insert into public."CompanyDATA" (company_name, country) values ('Edgewirexpaeqhny', 'Brazil');
insert into public."CompanyDATA" (company_name, country) values ('Meejokqdrvtmg', 'Serbia');
insert into public."CompanyDATA" (company_name, country) values ('Browsebugpflaidym', 'Canada');
insert into public."CompanyDATA" (company_name, country) values ('Oloonejxyuaw', 'Brazil');
insert into public."CompanyDATA" (company_name, country) values ('Jaxspanerhwxmfn', 'Poland');
insert into public."CompanyDATA" (company_name, country) values ('Jamiazdsqlthr', 'Philippines');
insert into public."CompanyDATA" (company_name, country) values ('Quinunstejxui', 'Russia');
insert into public."CompanyDATA" (company_name, country) values ('Jabbertypeghvquoyr', 'Russia');
insert into public."CompanyDATA" (company_name, country) values ('Oyoloognwqurym', 'Philippines');
insert into public."CompanyDATA" (company_name, country) values ('Fivespanprbxnyhf', 'Bangladesh');
insert into public."CompanyDATA" (company_name, country) values ('Yatarnhlytep', 'Gambia');
insert into public."CompanyDATA" (company_name, country) values ('Avambahrqgldxm', 'Sweden');
insert into public."CompanyDATA" (company_name, country) values ('Skabootdogzckr', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Dynaboxpgjtqxfl', 'Russia');
insert into public."CompanyDATA" (company_name, country) values ('Demiveeyhvslezm', 'Sweden');
insert into public."CompanyDATA" (company_name, country) values ('Brainsphereyoztkmwa', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Riffpathnvcefgtm', 'Indonesia');
insert into public."CompanyDATA" (company_name, country) values ('Wordpediaonjkhmcl', 'Bulgaria');
insert into public."CompanyDATA" (company_name, country) values ('Yoveoprmgwjei', 'Philippines');
insert into public."CompanyDATA" (company_name, country) values ('Feednationaziumbse', 'Nicaragua');
insert into public."CompanyDATA" (company_name, country) values ('Devpulseyejilxkt', 'Indonesia');
insert into public."CompanyDATA" (company_name, country) values ('Gigazoomptjmksur', 'Argentina');
insert into public."CompanyDATA" (company_name, country) values ('Oobawvmdrasj', 'Slovenia');
insert into public."CompanyDATA" (company_name, country) values ('Livefishanyojbic', 'China');
insert into public."CompanyDATA" (company_name, country) values ('Fivespanxfivdzwr', 'United Arab Emirates');
insert into public."CompanyDATA" (company_name, country) values ('Leexovawncyjb', 'Portugal');
insert into public."CompanyDATA" (company_name, country) values ('Kazuzoqiaysd', 'Russia');
insert into public."CompanyDATA" (company_name, country) values ('Voommsixlrcyf', 'France');
insert into public."CompanyDATA" (company_name, country) values ('Geveefrxkoewu', 'Venezuela');
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO public."ParticipateInDevelopmentMapping"
	select copyright_id,company_name
	from public."AppDATA",public."CompanyDATA"
	order by random()
	limit 1000;
