/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
Patients usually go to drugstores to buy common drugs. With stricter rules
issued by the state about management and control of drugs, XJZ Drugstore 
is  planning to build a database system to manage the their patients' drug 
purchase records to better monitor drug consumption and storage from 
1st Aug 2020 to 1st Aug 2021. The schema includes two entities and one 
relationship between them.
 
The first entity records information of patients, including some basic items
like the id one owns in the store, first name, last name, phone number and 
address. It also records the name and quantity which the patient buys, and 
the according purchase date.

The second entity records information of drugs, including durg id,drug
company and quantity of inventory in XJZ drugstore. It also includes drug's
production information like production date, production place, and expiration
date.

The relation is basically a many-to-many relationship linking the patient
and the drug the bought with particular patient_id and drug_id. To be more
straightforward and explicit it also includes the drug name and purchase date.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS patient (
	patient_id VARCHAR(64) NOT NULL,
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	phone_number VARCHAR(64) UNIQUE NOT NULL,
	drug_name VARCHAR(200) NOT NULL,
	address VARCHAR(64) NOT NULL,
	quantity INT NOT NULL,
	purchase_date DATE NOT NULL,
	PRIMARY KEY (patient_id, drug_name, purchase_date));

CREATE TABLE IF NOT EXISTS drug (
	drug_id VARCHAR(64) PRIMARY KEY,
	drug_company VARCHAR(64) NOT NULL,
	production_date DATE NOT NULL,
	production_place VARCHAR(64) NOT NULL,
	expiration_date DATE NOT NULL,
	inventory INT NOT NULL);
	
CREATE TABLE IF NOT EXISTS purchase (
	drug_id VARCHAR(64) REFERENCES drug(drug_id)
	  ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE,
	patient_id VARCHAR(64) NOT NULL,
    drug_name VARCHAR(200) NOT NULL,
	purchase_date DATE NOT NULL,
	PRIMARY KEY (drug_id, patient_id, drug_name, purchase_date),
	FOREIGN KEY (patient_id, drug_name, purchase_date) REFERENCES
	  patient(patient_id, drug_name, purchase_date)
	  ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

BEGIN TRANSACTION;
SET CONSTRAINTS ALL DEFERRED;
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('6082451694', 'Norina', 'MacMenemy', '665-688-9487', '466 Clarendon Place', 'Grama Grass', 5, '2021-03-09');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('4509209304', 'Christos', 'Witnall', '697-870-2169', '63 Acker Hill', 'SHISEIDO UV PROTECTIVE FOUNDATION', 4, '2020-12-26');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('2097565557', 'Kassey', 'Osgood', '439-130-6469', '88971 Fair Oaks Way', 'Levora', 3, '2020-11-22');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('8045747749', 'Adam', 'Luberto', '566-342-5412', '33787 Thompson Pass', 'SnowSkin Face Sunscreen', 2, '2020-09-13');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9106632335', 'Corbet', 'Langfield', '758-876-4862', '80127 Thackeray Alley', 'Harris Teeter', 2, '2020-10-29');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('2190745756', 'Bart', 'Jouhan', '251-507-2599', '98 Fallview Center', 'Sunmark Chest Congestion Relief PE', 5, '2020-08-31');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('2086238053', 'Zacharia', 'Ruskin', '967-888-6125', '41835 Kinsman Alley', 'acetaminophen', 5, '2021-03-19');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9852079247', 'Nola', 'Jahnig', '476-676-1574', '667 Troy Pass', 'Sodium Chloride', 2, '2020-08-30');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('7184941195', 'Stephanus', 'David', '261-968-0749', '92963 Del Mar Junction', 'Lemon Zest Antibacterial Foaming Hand Wash', 2, '2020-11-13');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('3263405802', 'Wolf', 'Wickey', '837-795-6420', '606 Nobel Avenue', 'Lumene Time Freeze Anti-Age CC Color Correcting SPF 20 Sunscreen Broad Spectrum MEDIUM', 5, '2021-02-05');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('1746753307', 'Burke', 'Eyckelberg', '201-765-1159', '2 Killdeer Street', 'WEGMANS', 2, '2020-11-09');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('1646421590', 'Barrie', 'Mariolle', '402-350-0879', '237 Armistice Park', 'Etodolac', 3, '2021-07-24');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('2430516837', 'Manuel', 'Vasyunin', '540-485-0771', '46105 Arkansas Avenue', 'Nite Time', 1, '2021-05-05');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('5691686070', 'Kellia', 'Cleever', '584-382-9651', '7 Lawn Terrace', 'Colocynthis Homaccord', 1, '2021-07-25');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('0890233039', 'Sydelle', 'McCrystal', '287-736-7089', '4087 Northridge Lane', 'CRESTOR', 4, '2020-08-01');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('8575615246', 'Davine', 'Beynke', '783-399-4506', '24507 Old Shore Court', 'Antiseptic', 5, '2021-05-01');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('7413023490', 'Zaneta', 'Oaks', '378-619-1817', '9 Mcguire Trail', 'Midol Complete', 4, '2021-01-03');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('7306379771', 'Didi', 'Ilive', '512-503-0708', '6 Atwood Pass', 'meloxicam', 5, '2020-10-13');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('6700668883', 'Tandi', 'Weavill', '554-287-8424', '07244 Glacier Hill Way', 'Olanzapine', 3, '2021-02-03');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('7757055385', 'Leona', 'Bovis', '298-354-6835', '23996 Kedzie Circle', 'BestHealth Cough Suppressant SUGAR FREE HONEY LEMON FLAVOR', 5, '2021-06-19');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9943931264', 'Petronilla', 'Ferrier', '511-192-2370', '8591 Riverside Park', 'Amlodipine Besylate', 4, '2020-08-07');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9174638823', 'Lizzy', 'Daout', '751-464-0426', '94 Burrows Avenue', 'Washington/Oregon Coastal Tree Mixture', 2, '2020-12-20');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('5426873836', 'Drusie', 'Form', '225-560-5382', '0 Bunker Hill Crossing', 'Rosanil', 2, '2020-11-20');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9552954657', 'Sherm', 'Wabb', '730-551-0611', '8 Lakewood Way', 'Clarifying Colloidal Sulfur Mask', 1, '2021-03-19');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('1864106832', 'Inessa', 'Sunshine', '108-455-6035', '7685 Oneill Circle', 'IOPE RETIGEN SMOOTHING PACT', 5, '2021-07-01');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('4904509994', 'Samaria', 'Raynton', '301-519-9555', '94504 Hagan Street', 'SE-DONNA PB HYOS', 3, '2020-12-31');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('1798290545', 'Wernher', 'Balogun', '973-293-2747', '620 Vahlen Hill', 'NEUTRA MAXX 5000', 1, '2020-08-29');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9044222856', 'Anabal', 'Huddle', '230-520-3428', '008 Rieder Avenue', 'Acyclovir', 3, '2020-08-18');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('0640702104', 'Malory', 'Franz-Schoninger', '571-935-7650', '078 Burrows Place', 'Tussigon', 4, '2020-09-23');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9213543883', 'Tabby', 'Duberry', '153-547-3908', '8472 Mendota Way', 'Constulose', 5, '2020-12-19');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('0826991122', 'Helsa', 'Simnel', '246-705-5849', '96 Michigan Pass', 'Trazodone Hydrochloride', 2, '2021-02-02');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9353065895', 'Julienne', 'Pollastro', '591-297-8260', '75933 8th Point', 'Carbidopa and Levodopa', 2, '2020-12-15');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9864362089', 'Donella', 'Mackness', '632-548-6475', '7 Reinke Way', 'NiteTime Cough DayTime Cough', 5, '2020-12-29');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('8832495473', 'Auria', 'Ceyssen', '250-304-2741', '4 Crownhardt Way', 'DOCTORS CHOICE', 5, '2021-03-20');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('4635812219', 'Scarlett', 'Gwillyam', '440-700-0023', '28 Monica Hill', 'Amiodarone Hydrochloride', 2, '2020-08-05');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('0121019810', 'Cheston', 'Landrieu', '779-652-7113', '6771 Oak Road', 'L OCCITANE CADE PROTECTIVE MOISTURIZING FLUID - FOR MEN BROAD SPECTRUM SPF 20 SUNSCREEN', 2, '2021-05-20');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9348251902', 'Emiline', 'Armatidge', '138-765-2717', '17903 Mitchell Circle', 'rexall enema', 2, '2020-10-05');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('6567331518', 'Justis', 'Blazynski', '852-665-3179', '7 Jay Terrace', 'Avandia', 3, '2021-06-05');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('5976712614', 'Jasmin', 'Rizzardo', '263-816-8172', '67 Mesta Crossing', 'Desert Bambu', 2, '2020-12-29');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('8432492663', 'Crista', 'Spillard', '775-673-3065', '46306 Springs Crossing', 'Lady Speed Stick', 3, '2021-02-22');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('6740045046', 'Britt', 'Janas', '191-421-1810', '04 Elka Alley', 'LBEL HYDRATESS', 5, '2021-05-07');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('1441555501', 'Herold', 'Westrey', '336-449-9425', '219 Westport Parkway', 'Pleo Nig', 4, '2020-09-29');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('4525233133', 'Northrop', 'Burnage', '666-996-6057', '3505 Golden Leaf Junction', 'Ciprofloxacin', 2, '2021-04-06');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9743808949', 'Carlee', 'McMurray', '248-766-2007', '9204 Namekagon Hill', 'Saline Laxative', 2, '2021-07-27');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('6877125800', 'Gwendolen', 'Spriggs', '525-381-7586', '57 Gerald Point', 'Connectissue', 2, '2021-03-23');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('4316114212', 'Randee', 'Waleran', '725-674-6939', '790 Crescent Oaks Way', 'KENALOG-40', 4, '2021-06-18');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('3905627612', 'Marla', 'Gerson', '361-285-0750', '958 Crescent Oaks Alley', 'Oxygen', 1, '2021-05-11');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('2723451127', 'Ricky', 'Domini', '563-911-6164', '34729 Sugar Point', 'Lycopodium clavatum', 2, '2021-03-06');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('6391168407', 'Trev', 'Clitherow', '583-591-3634', '34 Artisan Park', 'Rizatriptan Benzoate', 1, '2021-06-24');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('4966571073', 'Goldie', 'Rizzone', '180-736-8182', '036 Pine View Trail', 'Athletes Foot', 1, '2021-05-26');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('0619343958', 'Brandy', 'Averies', '167-133-6180', '87 Mitchell Lane', 'Lisinopril', 3, '2021-05-08');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('1600993796', 'Keary', 'Templman', '291-107-7013', '93 Kinsman Circle', 'Cyclobenzaprine Hydrochloride', 1, '2021-06-18');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('1556125712', 'Yalonda', 'Canadas', '126-382-1223', '2994 Vera Place', 'PredniSONE', 1, '2021-01-25');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('4794916132', 'Jerald', 'Raw', '127-905-3724', '9428 Bellgrove Pass', 'Bupropion Hydrochloride', 4, '2020-10-19');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('0483578223', 'Rogerio', 'Barrell', '584-797-4389', '2973 Crowley Alley', 'Estradiol', 3, '2021-06-19');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9467907402', 'Lay', 'Kisting', '789-392-2061', '0 Harbort Junction', 'FASLODEX', 3, '2021-02-19');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('1043372296', 'Sheffie', 'Danigel', '196-420-8173', '2 Westport Court', 'Latuda', 5, '2021-03-18');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('4399175494', 'Percival', 'Kielt', '898-501-4699', '8333 Corben Point', 'top care flu and sore throat', 1, '2020-10-22');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9142099498', 'Astrid', 'Clutterham', '885-972-2216', '0345 Portage Park', 'Azathioprine', 5, '2021-01-09');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('4611313999', 'Gordie', 'Bucknall', '184-258-7534', '565 Weeping Birch Avenue', 'Cardizem LA', 3, '2021-04-22');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9998699665', 'Retha', 'Machans', '851-991-9132', '9452 Mandrake Parkway', 'Indomethacin', 4, '2021-02-09');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('0311656641', 'Amabel', 'Firsby', '376-632-9044', '768 Caliangt Street', 'topiramate', 5, '2020-10-26');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('2482328926', 'Aridatha', 'Bannard', '226-968-9776', '47854 Darwin Drive', 'leader acid reducer complete', 3, '2020-09-14');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('3486483226', 'Vernon', 'Spruce', '312-128-6735', '405 Longview Junction', 'Instant Hand Sanitizer', 5, '2021-05-25');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('5850843620', 'Field', 'Earey', '965-721-7052', '91727 Jana Circle', 'leader headache formula', 4, '2020-12-28');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('3874956660', 'Mitchel', 'Roullier', '870-448-5744', '44 Di Loreto Terrace', 'M3 Metabolic Mineral Modulator', 3, '2020-09-13');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('1216479364', 'Delcina', 'Dilloway', '760-141-3220', '4 Del Mar Lane', 'LAClotion', 5, '2021-03-21');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('1097875407', 'Morrie', 'Lloyds', '474-509-0735', '6437 Buena Vista Plaza', 'Oxycodone Hydrochloride', 3, '2021-02-16');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('2522905287', 'Ema', 'Wilse', '192-982-1637', '1 Bowman Terrace', 'Celazome Fade Shades Lightening Cream w/ Glycolic Acid', 2, '2021-03-02');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('3112010345', 'Lavinia', 'Crewdson', '893-962-4015', '8 Carpenter Lane', 'Valacyclovir Hydrochloride', 5, '2021-06-23');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9808611796', 'Nomi', 'Binley', '671-713-6500', '12 Park Meadow Place', 'Ramipril', 1, '2020-08-23');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('0171460863', 'Deana', 'Hatherleigh', '485-514-3063', '043 Valley Edge Way', 'BETULA LENTA POLLEN', 3, '2020-11-25');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9310744081', 'Gerrilee', 'Verey', '405-324-7175', '90655 Barby Street', 'Clonazepam', 5, '2021-05-19');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('6178068093', 'Brigida', 'Bartul', '858-412-4197', '2 Alpine Center', 'Arnica Plus', 4, '2021-06-05');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('5688830921', 'Marten', 'Bateup', '503-392-1125', '38410 Heffernan Center', 'MORTON Natural Epsom Salt', 5, '2021-07-31');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('3865881653', 'Zebulon', 'Myford', '598-802-6997', '0 Hazelcrest Lane', 'Sciatic Rescue', 5, '2020-08-01');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('3343113662', 'Lilllie', 'Houston', '749-390-1314', '07482 Dryden Junction', 'COREG', 5, '2021-03-03');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('1604083433', 'Tomlin', 'Cargon', '938-326-6991', '04 Heffernan Terrace', 'Barielle Professional Maximum Strength Fungus Rx Antifungal PRO', 5, '2021-01-21');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('8305148882', 'Herminia', 'Fielders', '202-921-6974', '366 Magdeline Place', 'DOK', 1, '2020-12-11');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('0251719170', 'Gweneth', 'Whines', '969-417-4003', '0581 Cordelia Point', 'Levitra', 3, '2020-10-02');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('4074837943', 'Ronni', 'Linggood', '831-301-2941', '70 Bluestem Point', 'DOXYCYCLINE', 4, '2020-12-20');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('6993612399', 'Deeann', 'Pluvier', '815-715-0436', '14 Atwood Court', 'Fluconazole', 1, '2020-08-21');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('2478234467', 'Thorin', 'Averies', '640-590-6073', '3512 Russell Street', 'Purminerals 4-in-1 14-Hour Wear Foundation Broad Spectrum SPF 15 (BLUSH MEDIUM)', 3, '2021-04-16');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('6410226810', 'Garner', 'Berg', '260-566-2528', '02903 Dexter Road', 'Green Guard Super Stat Blood Clotting First Aid', 1, '2020-10-02');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('8412113586', 'Smitty', 'Dineen', '536-183-2020', '0652 Montana Court', 'Earths Best Mineral Sunscreen Broad Spectrum SPF30', 4, '2021-04-29');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('8212328090', 'Benjamin', 'Wadwell', '315-518-7101', '109 Springview Street', 'Toa Syrup Adult', 1, '2020-11-26');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('7305541826', 'Tommy', 'Lambin', '841-727-4135', '94206 Duke Pass', 'Bupropion Hydrochloride', 2, '2021-07-10');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('7797582734', 'Erek', 'Rahl', '718-275-5936', '0 Crest Line Point', 'Sun Broad Spectrum SPF 30', 2, '2021-02-27');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('2467478351', 'Jania', 'Kenforth', '496-467-4659', '7384 Corscot Alley', 'Nighttime Sleepaid', 3, '2020-10-15');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('1868847519', 'Mada', 'Lauret', '206-963-4764', '273 Sherman Road', 'Betadine', 2, '2020-11-06');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('6244085957', 'Minnnie', 'Brelsford', '417-548-6156', '282 Kingsford Center', 'Sulfasalazine', 3, '2021-01-11');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('5123527109', 'Babs', 'Flavelle', '822-919-7301', '741 Elka Center', 'Oxygen', 3, '2021-02-05');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('2990011269', 'Randy', 'Piatti', '473-929-6072', '129 Basil Lane', 'NovoLog', 3, '2020-12-29');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('8154238217', 'Myrwyn', 'Han', '365-494-0464', '5201 Rutledge Alley', 'MEPRON', 2, '2021-03-12');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9409673437', 'Rina', 'Branch', '512-912-2637', '8 Jay Street', 'DG BODY', 4, '2021-03-16');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('9741156391', 'Debbie', 'Schwandermann', '614-274-3680', '05 David Trail', 'Anti-bacterial Strawberry Kiss Hand', 4, '2020-11-11');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('1200156838', 'Pepito', 'Vernall', '895-607-8058', '6640 West Street', 'Antiseptic Mouthrinse', 4, '2020-12-07');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('3800103710', 'Marja', 'Gehringer', '350-266-1848', '9440 Mcguire Park', 'Jurlique Moisturizing Hand Sanitizer', 5, '2021-06-09');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('5882975018', 'Jodee', 'Birtles', '605-205-0033', '903 Canary Junction', 'Morphine Sulfate', 4, '2021-05-03');
insert into patient (patient_id, first_name, last_name, phone_number, address, drug_name, quantity, purchase_date) values ('8046159689', 'Ebeneser', 'Smitheman', '612-232-5900', '68253 Eagan Hill', 'Lovastatin', 1, '2021-03-31');
END TRANSACTION;

BEGIN TRANSACTION;
SET CONSTRAINTS ALL DEFERRED;
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('60-089-8331', 'Lake Erie Medical DBA Quality Care Products LLC', '2020-07-12', 'Cangzhou', '2023-12-21', 25);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('07-155-4168', 'Supervalu Inc', '2019-12-03', 'Bantay', '2022-09-06', 31);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('43-198-3516', 'Natural Health Supply', '2020-03-30', 'Energetik', '2023-10-10', 98);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('75-153-4157', 'Greenstone LLC', '2020-06-15', 'Landázuri', '2023-05-31', 70);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('09-439-8335', 'Taro Pharmaceuticals U.S.A., Inc.', '2019-12-14', 'Manuel Cavazos Lerma', '2022-10-22', 26);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('59-775-1748', 'Carilion Materials Management', '2020-01-26', 'Paris 01', '2023-10-11', 68);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('64-611-9631', 'CONOPCO Inc. d/b/a Unilever', '2020-06-12', 'Puamata', '2023-02-02', 45);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('46-083-5141', 'Topco Associates LLC', '2019-10-20', 'Loutrá', '2023-03-29', 34);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('02-502-6207', 'Teva Pharmaceuticals USA Inc', '2020-06-24', 'Rano', '2022-11-30', 5);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('39-921-2250', 'Elizabeth Arden, Inc', '2020-07-02', 'Burqah', '2022-11-22', 82);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('98-077-5438', 'GlaxoSmithKline Consumer Healthcare LP', '2020-06-07', 'Umm Şalāl ‘Alī', '2023-10-24', 62);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('57-835-0859', 'Bryant Ranch Prepack', '2020-02-29', 'Severnoye', '2022-12-20', 57);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('78-567-9860', 'H E B', '2020-05-02', 'Lugo', '2023-03-10', 49);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('92-803-5160', 'American Health Packaging', '2019-12-01', 'Filiátes', '2023-12-08', 31);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('46-845-8126', 'PD-Rx Pharmaceuticals, Inc.', '2020-04-29', 'Strömsund', '2022-11-19', 87);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('32-498-3323', 'ALK-Abello, Inc.', '2019-11-15', 'Uman’', '2022-08-30', 83);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('93-146-3819', 'Accra-Pac, Inc.', '2019-12-21', 'Rancho Nuevo', '2023-09-12', 47);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('52-599-4441', 'Wakefern Food Corporation', '2020-05-16', 'Hobaramachi', '2023-05-07', 34);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('70-570-1016', 'WOONSOCKET PRESCRIPTION CENTER,INCORPORATED', '2020-05-27', 'Guifões', '2022-09-05', 79);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('90-571-4615', 'Apotex Corp.', '2019-11-20', 'Talitsy', '2023-08-27', 11);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('65-147-9863', 'Nelco Laboratories, Inc.', '2020-07-07', 'Karangmelok', '2022-09-27', 75);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('48-617-2363', 'EQUALINE (SuperValu)', '2020-06-24', 'Nāṟay', '2023-05-21', 53);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('70-372-0050', 'Ventura Corporation, LTD', '2020-02-08', 'Srabah', '2023-03-19', 29);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('43-589-5386', 'REMEDYREPACK INC.', '2020-07-16', 'Navais', '2023-07-14', 87);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('33-604-7754', 'Perrigo New York Inc', '2019-09-30', 'Warungtanjung', '2023-05-17', 95);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('87-019-7507', 'AMERICAN SALES COMPANY', '2019-09-21', 'Romny', '2022-08-31', 41);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('38-275-2874', 'H E B', '2020-02-01', 'Barwałd Górny', '2023-03-21', 29);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('83-707-5514', 'NorthStar Rx LLC', '2020-07-22', 'Mortka', '2023-06-10', 1);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('74-498-3680', 'Bath & Body Works, Inc.', '2020-07-19', 'Libouchec', '2023-03-04', 1);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('45-652-7929', 'Aphena Pharma Solutions - Tennessee, LLC', '2020-01-09', 'Takaka', '2023-12-30', 7);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('83-913-8747', 'Nelco Laboratories, Inc.', '2019-10-17', 'Tbêng Méanchey', '2023-05-05', 95);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('46-821-2048', 'Nelco Laboratories, Inc.', '2019-10-08', 'Rāvar', '2023-03-02', 85);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('26-490-0246', 'Remedy Makers', '2020-06-24', 'Babakankadu', '2023-06-21', 86);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('72-045-8278', 'B. Braun Medical Inc.', '2019-09-01', 'Anjepy', '2023-01-23', 25);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('36-305-9011', 'Taizhou Ludao Cosmetics Co., Ltd.', '2019-11-11', 'Baleal', '2022-08-31', 60);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('87-435-6285', 'Cadila Healthcare Limited', '2020-05-15', 'Consuelo', '2023-06-02', 66);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('11-398-0953', 'Mangiacotti Floral LLC', '2019-12-08', 'Jiulong', '2023-03-18', 58);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('99-989-7427', 'REMEDYREPACK INC.', '2020-02-08', 'Alistráti', '2023-11-29', 23);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('34-776-6227', 'Antigen Laboratories, Inc.', '2019-10-07', 'Suvorov', '2023-10-27', 49);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('56-583-3473', 'PD-Rx Pharmaceuticals, Inc.', '2019-11-12', 'Taphan Hin', '2023-02-14', 4);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('46-886-1460', 'Wockhardt Limited', '2019-10-07', 'Yambol', '2023-01-24', 28);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('40-718-0243', 'Sandoz Inc', '2019-11-04', 'Smyków', '2022-09-14', 60);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('25-676-2430', 'Chain Drug Consortium, LLC', '2020-03-02', 'Novouzensk', '2023-06-19', 9);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('76-407-2372', 'DSHealthcare', '2020-01-25', 'Ciudad Bolívar', '2022-08-17', 54);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('22-735-0412', 'Ecomine Co., Ltd.', '2020-07-18', 'Doña Remedios Trinidad', '2022-12-13', 65);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('36-529-0590', 'Best Choice (Valu Merchandisers Company)', '2019-09-25', 'Saverne', '2023-02-02', 92);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('32-172-3255', 'Palmer Fixture Company', '2020-07-22', 'Wutong', '2023-01-10', 36);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('50-201-4815', 'Alcon Laboratories, Inc.', '2019-12-26', 'Al Manāqil', '2022-10-08', 39);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('55-331-8721', 'Apotex Corp.', '2020-03-19', 'Magang', '2023-04-01', 91);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('99-344-4410', 'Northwind Pharmaceuticals, LLC', '2019-10-27', 'Amagi', '2023-12-01', 22);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('95-724-9293', 'Premier Brands of America Inc.', '2020-01-12', 'Horodok', '2022-10-29', 21);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('47-334-0479', 'Cantrell Drug Company', '2020-03-23', '''Ali Sabieh', '2023-04-09', 8);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('17-584-2505', 'Stephen L. LaFrance Pharmacy, Inc.', '2019-10-03', 'Daqiao', '2023-08-30', 91);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('23-538-6785', 'Cardinal Health', '2020-07-29', 'Druju', '2023-07-12', 78);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('42-204-4163', 'Wockhardt Limited', '2019-09-13', 'Évreux', '2022-09-25', 20);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('03-516-1790', 'GOWOONSESANG COSMETICS CO., LTD.', '2019-09-20', 'Mengxi', '2023-02-28', 62);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('43-620-6862', 'SCOT-TUSSIN Pharmacal Co., Inc.', '2020-07-02', 'Stenungsund', '2023-12-02', 51);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('79-278-9547', 'ViiV Healthcare Company', '2019-09-16', 'Skuratovskiy', '2023-09-27', 24);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('03-977-3910', 'Pharmicell Co., Ltd.', '2020-02-12', 'Bingawan', '2022-12-03', 11);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('26-192-1957', 'AAA Pharmaceutical, Inc.', '2020-06-16', 'Dazuo', '2023-06-24', 47);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('21-333-1256', 'HOMEOLAB USA INC.', '2019-10-24', 'Beitan', '2023-05-11', 47);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('65-831-8091', 'TOMMY HILFIGER TOILETRIES', '2019-12-22', 'Longtanhe', '2023-10-08', 62);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('37-280-3662', 'Mylan Pharmaceuticals Inc.', '2019-09-13', 'Chemnitz', '2022-08-04', 82);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('19-869-3741', 'Cardinal Health', '2020-02-27', 'Shuibian', '2023-04-01', 48);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('52-951-1202', 'Newton Laboratories, Inc.', '2020-01-11', 'Khiwa', '2023-09-30', 74);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('89-378-9076', 'St Marys Medical Park Pharmacy', '2020-07-05', 'Pederneiras', '2023-05-31', 52);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('39-548-0397', 'Physicians Total Care, Inc.', '2020-05-04', 'Saint-Denis', '2023-01-21', 19);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('75-435-1962', 'Deseret Biologicals, Inc.', '2020-05-14', 'Kamaris', '2023-07-18', 58);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('77-696-3862', 'Cardinal Health', '2020-07-11', 'Kostino', '2023-09-26', 71);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('22-529-3940', 'AFFLAB, Affiliated Laboratories, a Division of AFFLINK', '2020-05-31', 'Mem Martins', '2022-11-11', 50);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('44-805-1337', 'State of Florida DOH Central Pharmacy', '2020-04-01', 'Seymchan', '2023-09-09', 79);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('16-025-5573', 'Roxane Laboratories, Inc', '2020-06-09', 'Barra', '2022-12-20', 80);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('42-195-5829', 'Nelco Laboratories, Inc.', '2019-11-08', 'Niños Heroes', '2022-10-28', 63);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('10-006-2496', 'KC Pharmaceuticals, Inc.', '2020-03-17', 'Stockholm', '2023-04-20', 12);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('19-186-5636', 'ALK-Abello, Inc.', '2019-10-24', 'Bīrganj', '2023-04-04', 32);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('90-260-4653', 'Laboratoires Boiron', '2020-04-29', 'T’ongch’ŏn-ŭp', '2023-08-27', 6);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('59-619-1425', 'Elizabeth Arden, Inc', '2019-12-19', 'Rancaerang', '2023-08-22', 19);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('14-049-7089', '7-Eleven', '2020-07-16', 'Thiais', '2023-06-21', 46);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('24-507-8051', 'General Injectables & Vaccines, Inc', '2020-04-07', 'Tanggu', '2023-08-10', 31);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('02-472-5845', 'Mylan Institutional LLC', '2019-10-15', 'Jiuli', '2023-12-18', 88);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('50-911-9930', 'Lupin Pharmaceuticals, Inc.', '2020-05-19', 'Khūgyāṉī', '2022-09-08', 89);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('24-391-4994', 'Physician Therapeutics LLC', '2020-07-27', 'Ijuí', '2023-10-29', 75);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('75-724-6516', 'Apotheca Company', '2020-02-05', 'Florida', '2023-06-21', 68);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('76-013-2334', 'L Perrigo Company', '2019-11-27', 'San Julian', '2023-11-22', 14);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('29-949-5997', 'HOMEOLAB USA INC.', '2020-06-24', 'Suncun', '2023-06-14', 99);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('45-488-0428', 'AvKARE, Inc.', '2020-03-12', 'Cigeulis', '2023-12-01', 82);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('58-919-1497', 'Rebel Distributors Corp', '2020-03-03', 'Varybóbi', '2023-02-27', 91);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('71-528-4083', 'State of Florida DOH Central Pharmacy', '2019-10-18', 'Ipatinga', '2023-07-19', 83);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('06-676-9669', 'KC Pharmaceuticals, Inc.', '2020-02-27', 'Huanggang', '2023-05-01', 8);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('54-677-9292', 'Energique, Inc.', '2019-10-23', 'Huzhen', '2022-12-12', 5);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('57-861-8640', 'ZO Skin Health, Inc.', '2019-11-05', 'Masons Bay', '2023-04-11', 31);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('91-973-4449', 'Physicians Total Care, Inc.', '2020-01-08', 'Le Mans', '2023-05-30', 5);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('21-181-9976', 'Heritage Pharmaceuticals Inc.', '2020-02-28', 'Oropesa', '2023-01-25', 20);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('96-599-2816', 'Dr.Reddy''s Laboratories Limited', '2019-09-10', 'Sukawaris', '2023-04-29', 22);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('97-606-6821', 'Physicians Total Care, Inc.', '2020-02-13', 'Almeria', '2022-09-18', 38);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('18-102-5004', 'Cargus International, Inc.', '2019-10-05', 'Jalinan', '2023-11-06', 62);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('99-800-6076', 'Jiangsu Province JianErKang Medical Dressing Co. ,Ltd.', '2019-08-02', 'Pedraza La Vieja', '2022-12-03', 18);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('26-675-0022', 'HomeopathyStore.com', '2019-09-16', 'Piraquara', '2023-07-30', 43);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('47-592-0080', 'Medline Industries, Inc.', '2019-08-05', 'Passal', '2022-09-27', 70);
insert into drug (drug_id, drug_company, production_date, production_place, expiration_date, inventory) values ('59-071-4469', 'REMEDYREPACK INC.', '2019-09-21', 'Taibai', '2023-11-19', 52);
END TRANSACTION;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

BEGIN TRANSACTION;
SET CONSTRAINTS ALL DEFERRED;
INSERT INTO purchase (drug_id,patient_id, drug_name, purchase_date)
SELECT drug_id, patient_id, drug_name, purchase_date 
FROM (SELECT drug_id FROM drug) AS I1
CROSS JOIN (SELECT patient_id, drug_name, purchase_date FROM patient) AS I2
ORDER BY random() LIMIT 1000;
END TRANSACTION;
