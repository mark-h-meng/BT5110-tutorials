/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/* A0177964J Jiang Mengrui                                              */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The entity 1: users
The entity 2: stocks 
The relationship: buyin
THe table of users is with their username, fisrt name, last name, country,
company, jobtitle
The table of stocks is with their stock name, stock sector, country, price, 
date, time
The table buyin associating the username and the price of stock name they 
bought in at which day and time

The table users designed with consideration in the person need to open a account 
with a username to trade in the stock market. And there should be risk assessment 
taken during account openning which will get the information from the user about 
their country staying at and the current company working for and the job title. 

The table stocks including stock name and the stock sector it belongs 
to, and country was restricted to be China which means the users trade in the Chinese 
stock market. Meanwhile, the time restricted to be 9am to 3pm which is the market openning 
period for Chinese stock market. This table will show the price of each stock at specific 
date and time. 

The table buyin is the relationship between users and stocks, to show different users bought
in different stock at specific price at exact date and time. 

The code is written for PostgreSQL
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DROP TABLE users, stocks, buyin;


CREATE TABLE IF NOT EXISTS users(
	username VARCHAR(32) PRIMARY KEY,
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	country VARCHAR(32) NOT NULL,
	company VARCHAR(32) NOT NULL,
	job_title VARCHAR(64) NOT NULL
);

CREATE TABLE IF NOT EXISTS stocks(
	stock_name VARCHAR(64) NOT NULL,
	stock_sector VARCHAR(64) NOT NULL,
	country VARCHAR(32) NOT NULL,
	price NUMERIC NOT NULL CHECK (price > 0),
	date DATE NOT NULL,
	time TIME NOT NULL,
	PRIMARY KEY (stock_name, price, date, time)
);

CREATE TABLE buyin(
	username VARCHAR(64) REFERENCES users(username)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED,
	stock_name VARCHAR(64) NOT NULL,
	price NUMERIC NOT NULL CHECK (price > 0),
	date DATE NOT NULL,
	time TIME NOT NULL,
	PRIMARY KEY (username, stock_name, price, date, time),
	FOREIGN KEY (stock_name, price, date, time) 
	REFERENCES stocks(stock_name, price, date, time)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into users (username, first_name, last_name, country, company, job_title) values ('jkayser0', 'Junette', 'Kayser', 'Norway', 'Jabberbean', 'Developer II');
insert into users (username, first_name, last_name, country, company, job_title) values ('ihay1', 'Inna', 'Hay', 'Luxembourg', 'Muxo', 'Product Engineer');
insert into users (username, first_name, last_name, country, company, job_title) values ('gbrumbye2', 'Geri', 'Brumbye', 'China', 'Oyoloo', 'Human Resources Manager');
insert into users (username, first_name, last_name, country, company, job_title) values ('cbreyt3', 'Cordelie', 'Breyt', 'Indonesia', 'Skippad', 'Librarian');
insert into users (username, first_name, last_name, country, company, job_title) values ('lkapelhoff4', 'Lenci', 'Kapelhoff', 'Russia', 'Twitterwire', 'Technical Writer');
insert into users (username, first_name, last_name, country, company, job_title) values ('afennick5', 'Amata', 'Fennick', 'Brazil', 'Jazzy', 'Sales Associate');
insert into users (username, first_name, last_name, country, company, job_title) values ('mlimrick6', 'Minette', 'Limrick', 'China', 'Ntag', 'Software Test Engineer II');
insert into users (username, first_name, last_name, country, company, job_title) values ('smacrury7', 'Sean', 'MacRury', 'Chile', 'Babblestorm', 'Marketing Manager');
insert into users (username, first_name, last_name, country, company, job_title) values ('kfogt8', 'Kylynn', 'Fogt', 'Czech Republic', 'Zooxo', 'Accountant I');
insert into users (username, first_name, last_name, country, company, job_title) values ('rtrickey9', 'Ron', 'Trickey', 'Ukraine', 'Photobug', 'Web Designer II');
insert into users (username, first_name, last_name, country, company, job_title) values ('lbiswella', 'Lil', 'Biswell', 'Ukraine', 'Twitternation', 'VP Sales');
insert into users (username, first_name, last_name, country, company, job_title) values ('sbeckittb', 'Shaylyn', 'Beckitt', 'Russia', 'Riffpedia', 'Human Resources Assistant II');
insert into users (username, first_name, last_name, country, company, job_title) values ('tcolgravec', 'Thain', 'Colgrave', 'Poland', 'Photojam', 'Financial Advisor');
insert into users (username, first_name, last_name, country, company, job_title) values ('sflethamd', 'Saleem', 'Fletham', 'Brazil', 'Skippad', 'Dental Hygienist');
insert into users (username, first_name, last_name, country, company, job_title) values ('eoatleye', 'Emmy', 'Oatley', 'Poland', 'Cogilith', 'General Manager');
insert into users (username, first_name, last_name, country, company, job_title) values ('wdeshortsf', 'Wenda', 'Deshorts', 'Indonesia', 'Flipopia', 'Associate Professor');
insert into users (username, first_name, last_name, country, company, job_title) values ('mcristofarig', 'Mimi', 'Cristofari', 'Serbia', 'Cogilith', 'Dental Hygienist');
insert into users (username, first_name, last_name, country, company, job_title) values ('cmicheauh', 'Cary', 'Micheau', 'Indonesia', 'Jabberbean', 'Safety Technician IV');
insert into users (username, first_name, last_name, country, company, job_title) values ('mcalverdi', 'Marley', 'Calverd', 'Indonesia', 'Voolith', 'Director of Sales');
insert into users (username, first_name, last_name, country, company, job_title) values ('amatczakj', 'Angie', 'Matczak', 'Brazil', 'Tavu', 'Marketing Assistant');
insert into users (username, first_name, last_name, country, company, job_title) values ('minchank', 'Maurene', 'Inchan', 'Indonesia', 'Talane', 'Marketing Assistant');
insert into users (username, first_name, last_name, country, company, job_title) values ('hhanningl', 'Haley', 'Hanning', 'United States', 'Flashpoint', 'Senior Developer');
insert into users (username, first_name, last_name, country, company, job_title) values ('wrechertm', 'Windy', 'Rechert', 'Russia', 'Jabberstorm', 'Administrative Officer');
insert into users (username, first_name, last_name, country, company, job_title) values ('lgrinvaldsn', 'Lethia', 'Grinvalds', 'Kenya', 'InnoZ', 'Environmental Specialist');
insert into users (username, first_name, last_name, country, company, job_title) values ('vcastanieo', 'Vaughan', 'Castanie', 'Israel', 'Flashpoint', 'Developer IV');
insert into users (username, first_name, last_name, country, company, job_title) values ('jfranzelp', 'Jorry', 'Franzel', 'Philippines', 'Abata', 'Chief Design Engineer');
insert into users (username, first_name, last_name, country, company, job_title) values ('wstaddartq', 'Wanda', 'Staddart', 'Russia', 'Zoomlounge', 'Dental Hygienist');
insert into users (username, first_name, last_name, country, company, job_title) values ('ehubaner', 'Ernest', 'Hubane', 'Swaziland', 'Realblab', 'Mechanical Systems Engineer');
insert into users (username, first_name, last_name, country, company, job_title) values ('alonghornes', 'Alva', 'Longhorne', 'Peru', 'Topicstorm', 'Compensation Analyst');
insert into users (username, first_name, last_name, country, company, job_title) values ('ybarryt', 'Yettie', 'Barry', 'Afghanistan', 'Shufflebeat', 'GIS Technical Architect');
insert into users (username, first_name, last_name, country, company, job_title) values ('jpietruschkau', 'Joya', 'Pietruschka', 'Indonesia', 'Yozio', 'Editor');
insert into users (username, first_name, last_name, country, company, job_title) values ('mshynnv', 'Micaela', 'Shynn', 'Philippines', 'Jaxbean', 'Professor');
insert into users (username, first_name, last_name, country, company, job_title) values ('bbuckseyw', 'Boot', 'Bucksey', 'Croatia', 'Realfire', 'Tax Accountant');
insert into users (username, first_name, last_name, country, company, job_title) values ('bwakefordx', 'Brooke', 'Wakeford', 'Tunisia', 'Jaxbean', 'Sales Representative');
insert into users (username, first_name, last_name, country, company, job_title) values ('eclaxtony', 'Elysha', 'Claxton', 'Switzerland', 'Blogtag', 'Senior Editor');
insert into users (username, first_name, last_name, country, company, job_title) values ('khadwinz', 'Karylin', 'Hadwin', 'Bolivia', 'Meedoo', 'VP Product Management');
insert into users (username, first_name, last_name, country, company, job_title) values ('cmetzig10', 'Carolee', 'Metzig', 'Senegal', 'Tagcat', 'Chemical Engineer');
insert into users (username, first_name, last_name, country, company, job_title) values ('jnesterov11', 'Job', 'Nesterov', 'China', 'Teklist', 'Design Engineer');
insert into users (username, first_name, last_name, country, company, job_title) values ('kfranceschelli12', 'Katie', 'Franceschelli', 'France', 'Devpulse', 'Safety Technician III');
insert into users (username, first_name, last_name, country, company, job_title) values ('estaddart13', 'Estell', 'Staddart', 'China', 'Eadel', 'Office Assistant III');
insert into users (username, first_name, last_name, country, company, job_title) values ('wkenninghan14', 'Wilfrid', 'Kenninghan', 'China', 'DabZ', 'Teacher');
insert into users (username, first_name, last_name, country, company, job_title) values ('bgauchier15', 'Brianne', 'Gauchier', 'Indonesia', 'Zoombeat', 'Clinical Specialist');
insert into users (username, first_name, last_name, country, company, job_title) values ('hpicot16', 'Harp', 'Picot', 'Taiwan', 'Plambee', 'Software Test Engineer IV');
insert into users (username, first_name, last_name, country, company, job_title) values ('sconstanza17', 'Shelley', 'Constanza', 'Ukraine', 'Wordpedia', 'Sales Representative');
insert into users (username, first_name, last_name, country, company, job_title) values ('dscreeton18', 'Delano', 'Screeton', 'South Africa', 'Twitterbeat', 'VP Accounting');
insert into users (username, first_name, last_name, country, company, job_title) values ('rdanilevich19', 'Rollo', 'Danilevich', 'Iraq', 'Topdrive', 'Health Coach I');
insert into users (username, first_name, last_name, country, company, job_title) values ('ysneaker1a', 'Yule', 'Sneaker', 'Russia', 'Dabvine', 'Systems Administrator II');
insert into users (username, first_name, last_name, country, company, job_title) values ('dsissons1b', 'Doris', 'Sissons', 'Myanmar', 'Trunyx', 'Junior Executive');
insert into users (username, first_name, last_name, country, company, job_title) values ('billesley1c', 'Bonnie', 'Illesley', 'Portugal', 'Rhybox', 'General Manager');
insert into users (username, first_name, last_name, country, company, job_title) values ('tgallear1d', 'Theo', 'Gallear', 'France', 'Meeveo', 'VP Quality Control');
insert into users (username, first_name, last_name, country, company, job_title) values ('nbernollet1e', 'Nancee', 'Bernollet', 'Cyprus', 'Omba', 'Community Outreach Specialist');
insert into users (username, first_name, last_name, country, company, job_title) values ('candreazzi1f', 'Camel', 'Andreazzi', 'United States', 'Linkbuzz', 'Professor');
insert into users (username, first_name, last_name, country, company, job_title) values ('mkimmitt1g', 'Martelle', 'Kimmitt', 'Denmark', 'Zoomzone', 'Senior Cost Accountant');
insert into users (username, first_name, last_name, country, company, job_title) values ('mpereira1h', 'Mallory', 'Pereira', 'Bosnia and Herzegovina', 'Thoughtbeat', 'Web Designer IV');
insert into users (username, first_name, last_name, country, company, job_title) values ('gkewley1i', 'Gaye', 'Kewley', 'China', 'Oyoyo', 'Web Designer II');
insert into users (username, first_name, last_name, country, company, job_title) values ('lbalding1j', 'Lacy', 'Balding', 'Liechtenstein', 'Edgeclub', 'Assistant Media Planner');
insert into users (username, first_name, last_name, country, company, job_title) values ('sdevonside1k', 'Shirl', 'Devonside', 'Brunei', 'Youtags', 'GIS Technical Architect');
insert into users (username, first_name, last_name, country, company, job_title) values ('csisnett1l', 'Clemmy', 'Sisnett', 'Indonesia', 'Miboo', 'Account Representative I');
insert into users (username, first_name, last_name, country, company, job_title) values ('mmcilheran1m', 'Margot', 'McIlheran', 'Myanmar', 'Muxo', 'Chemical Engineer');
insert into users (username, first_name, last_name, country, company, job_title) values ('pgleader1n', 'Pearle', 'Gleader', 'Indonesia', 'Yodo', 'Compensation Analyst');
insert into users (username, first_name, last_name, country, company, job_title) values ('hgingell1o', 'Honoria', 'Gingell', 'Poland', 'LiveZ', 'Administrative Assistant II');
insert into users (username, first_name, last_name, country, company, job_title) values ('vmcphelimy1p', 'Vidovik', 'McPhelimy', 'Norway', 'Photobug', 'Safety Technician I');
insert into users (username, first_name, last_name, country, company, job_title) values ('cgyles1q', 'Corrina', 'Gyles', 'China', 'Dynabox', 'Geologist II');
insert into users (username, first_name, last_name, country, company, job_title) values ('cgillbanks1r', 'Caye', 'Gillbanks', 'China', 'Flashdog', 'Graphic Designer');
insert into users (username, first_name, last_name, country, company, job_title) values ('ainnwood1s', 'Anita', 'Innwood', 'China', 'Skimia', 'Help Desk Operator');
insert into users (username, first_name, last_name, country, company, job_title) values ('wdelouch1t', 'Willis', 'Delouch', 'South Africa', 'Buzzster', 'Statistician II');
insert into users (username, first_name, last_name, country, company, job_title) values ('gyezafovich1u', 'Georgette', 'Yezafovich', 'China', 'Topiclounge', 'Operator');
insert into users (username, first_name, last_name, country, company, job_title) values ('cmatthew1v', 'Cosmo', 'Matthew', 'Russia', 'Jabbercube', 'Speech Pathologist');
insert into users (username, first_name, last_name, country, company, job_title) values ('ecuer1w', 'Elfrida', 'Cuer', 'Luxembourg', 'Tagcat', 'Senior Developer');
insert into users (username, first_name, last_name, country, company, job_title) values ('mbotley1x', 'Marguerite', 'Botley', 'Poland', 'Zazio', 'Developer III');
insert into users (username, first_name, last_name, country, company, job_title) values ('nharle1y', 'Nanine', 'Harle', 'Tanzania', 'Quinu', 'Assistant Manager');
insert into users (username, first_name, last_name, country, company, job_title) values ('ysayle1z', 'Yalonda', 'Sayle', 'China', 'Yodo', 'Media Manager III');
insert into users (username, first_name, last_name, country, company, job_title) values ('mdoelle20', 'Matty', 'Doelle', 'China', 'Blogspan', 'Product Engineer');
insert into users (username, first_name, last_name, country, company, job_title) values ('sikin21', 'Selestina', 'Ikin', 'Panama', 'Twitternation', 'Registered Nurse');
insert into users (username, first_name, last_name, country, company, job_title) values ('fhutfield22', 'Fulton', 'Hutfield', 'France', 'Brainbox', 'Research Nurse');
insert into users (username, first_name, last_name, country, company, job_title) values ('gceresa23', 'Georgi', 'Ceresa', 'Mexico', 'Plajo', 'Internal Auditor');
insert into users (username, first_name, last_name, country, company, job_title) values ('thundal24', 'Terrel', 'Hundal', 'Argentina', 'Kwimbee', 'Budget/Accounting Analyst IV');
insert into users (username, first_name, last_name, country, company, job_title) values ('lpriddey25', 'Leslie', 'Priddey', 'Uzbekistan', 'Voonder', 'Accounting Assistant II');
insert into users (username, first_name, last_name, country, company, job_title) values ('mcuthbertson26', 'Miller', 'Cuthbertson', 'China', 'Brainbox', 'Legal Assistant');
insert into users (username, first_name, last_name, country, company, job_title) values ('slowis27', 'Sunshine', 'Lowis', 'China', 'Jayo', 'Internal Auditor');
insert into users (username, first_name, last_name, country, company, job_title) values ('pfazzioli28', 'Peterus', 'Fazzioli', 'Philippines', 'Twitterbridge', 'Quality Control Specialist');
insert into users (username, first_name, last_name, country, company, job_title) values ('mselby29', 'Mic', 'Selby', 'Portugal', 'Blogtags', 'VP Sales');
insert into users (username, first_name, last_name, country, company, job_title) values ('tkemshell2a', 'Trixi', 'Kemshell', 'Indonesia', 'Centidel', 'Administrative Officer');
insert into users (username, first_name, last_name, country, company, job_title) values ('ebrassill2b', 'Emma', 'Brassill', 'Brazil', 'Bubblemix', 'Environmental Specialist');
insert into users (username, first_name, last_name, country, company, job_title) values ('ddenson2c', 'Demetre', 'Denson', 'Republic of the Congo', 'Brightdog', 'Statistician IV');
insert into users (username, first_name, last_name, country, company, job_title) values ('asadgrove2d', 'Ailene', 'Sadgrove', 'China', 'Twitterbeat', 'Media Manager IV');
insert into users (username, first_name, last_name, country, company, job_title) values ('akenny2e', 'Allianora', 'Kenny', 'United States', 'Twimbo', 'Account Coordinator');
insert into users (username, first_name, last_name, country, company, job_title) values ('dsebyer2f', 'Damara', 'Sebyer', 'Philippines', 'Eimbee', 'Dental Hygienist');
insert into users (username, first_name, last_name, country, company, job_title) values ('etoquet2g', 'Erl', 'Toquet', 'Philippines', 'Oba', 'Desktop Support Technician');
insert into users (username, first_name, last_name, country, company, job_title) values ('oreary2h', 'Onfre', 'Reary', 'Ecuador', 'Demimbu', 'Software Engineer II');
insert into users (username, first_name, last_name, country, company, job_title) values ('ctitmarsh2i', 'Clayton', 'Titmarsh', 'Philippines', 'Realcube', 'Nurse');
insert into users (username, first_name, last_name, country, company, job_title) values ('crickerby2j', 'Coretta', 'Rickerby', 'Brazil', 'Ainyx', 'Civil Engineer');
insert into users (username, first_name, last_name, country, company, job_title) values ('tcatanheira2k', 'Trina', 'Catanheira', 'China', 'Photobean', 'Electrical Engineer');
insert into users (username, first_name, last_name, country, company, job_title) values ('ayakobowitch2l', 'Ashil', 'Yakobowitch', 'Sweden', 'Vitz', 'Web Designer IV');
insert into users (username, first_name, last_name, country, company, job_title) values ('akernell2m', 'Abdel', 'Kernell', 'China', 'Demizz', 'Financial Advisor');
insert into users (username, first_name, last_name, country, company, job_title) values ('bgladbach2n', 'Barrett', 'Gladbach', 'Vietnam', 'Meeveo', 'Senior Developer');
insert into users (username, first_name, last_name, country, company, job_title) values ('gryhorovich2o', 'Germain', 'Ryhorovich', 'Kazakhstan', 'Skaboo', 'Tax Accountant');
insert into users (username, first_name, last_name, country, company, job_title) values ('dmatysiak2p', 'Dallon', 'Matysiak', 'China', 'Bluezoom', 'Automation Specialist I');
insert into users (username, first_name, last_name, country, company, job_title) values ('jnuemann2q', 'Jamill', 'Nuemann', 'United States', 'Flashdog', 'Marketing Assistant');
insert into users (username, first_name, last_name, country, company, job_title) values ('ayedall2r', 'Aurlie', 'Yedall', 'Portugal', 'Browsecat', 'Developer II');


insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Eyegate Pharmaceuticals, Inc.', 'Health Care', 'China', 71.2, '2021-03-01 00:27:54', '11:10 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Aflac Incorporated', 'Finance', 'China', 46.79, '2021-04-28 04:37:20', '9:02 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Eaton Vance Senior Income Trust', 'n/a', 'China', 32.02, '2021-05-03 14:23:23', '12:10 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Galena Biopharma, Inc.', 'Health Care', 'China', 26.55, '2021-03-22 17:34:21', '10:35 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Credit Suisse Group', 'Finance', 'China', 62.28, '2021-04-02 17:54:09', '2:45 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Ocular Therapeutix, Inc.', 'Health Care', 'China', 63.92, '2021-05-08 14:58:06', '9:10 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Nuveen Texas Quality Municipal Income Fund', 'n/a', 'China', 3.93, '2021-02-26 14:02:39', '1:58 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Westamerica Bancorporation', 'Finance', 'China', 48.8, '2021-01-19 03:29:11', '12:52 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('PIMCO California Municipal Income Fund', 'n/a', 'China', 27.9, '2021-04-12 15:11:26', '12:31 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('The AES Corporation', 'Basic Industries', 'China', 42.43, '2021-02-02 15:17:22', '11:31 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Noble Corporation', 'Energy', 'China', 93.33, '2021-05-02 11:34:12', '1:54 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('HCP, Inc.', 'Consumer Services', 'China', 29.67, '2021-04-17 22:10:08', '9:32 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Teligent, Inc.', 'Health Care', 'China', 81.04, '2021-05-04 04:29:34', '2:39 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Pzena Investment Management Inc', 'Finance', 'China', 4.37, '2021-02-03 01:54:22', '9:44 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Hugoton Royalty Trust', 'Energy', 'China', 53.95, '2021-04-29 21:22:32', '9:55 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Insignia Systems, Inc.', 'Consumer Services', 'China', 17.07, '2021-03-18 17:51:21', '10:09 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('LivaNova PLC', 'Health Care', 'China', 44.23, '2021-03-08 16:42:00', '9:48 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Global X Health & Wellness Thematic ETF', 'n/a', 'China', 66.09, '2021-06-06 10:45:00', '1:06 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Wintrust Financial Corporation', 'Finance', 'China', 39.47, '2021-01-26 19:54:29', '10:41 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Liberty Global plc', 'Consumer Services', 'China', 74.58, '2021-06-23 04:47:12', '10:22 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Trupanion, Inc.', 'Health Care', 'China', 90.37, '2021-03-26 09:07:16', '1:56 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Actuant Corporation', 'Technology', 'China', 98.39, '2021-05-08 06:54:07', '1:36 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Paychex, Inc.', 'Consumer Services', 'China', 66.4, '2021-02-14 21:03:51', '12:27 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Adams Natural Resources Fund, Inc.', 'n/a', 'China', 9.07, '2021-04-07 02:15:53', '1:36 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Dreyfus Strategic Municipal Bond Fund, Inc.', 'n/a', 'China', 91.9, '2021-05-24 21:39:41', '10:06 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Associated Banc-Corp', 'Finance', 'China', 13.98, '2021-01-23 03:10:39', '9:38 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Maui Land & Pineapple Company, Inc.', 'Finance', 'China', 25.5, '2021-03-23 03:29:45', '9:44 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Immuron Limited', 'Health Care', 'China', 33.62, '2021-06-06 00:47:26', '2:22 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('PNC Financial Services Group, Inc. (The)', 'n/a', 'China', 7.03, '2021-03-19 23:09:19', '11:12 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Transcontinental Realty Investors, Inc.', 'Consumer Services', 'China', 40.16, '2021-02-17 08:33:50', '11:23 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Pixelworks, Inc.', 'Technology', 'China', 65.39, '2021-06-08 07:24:08', '2:29 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('FuelCell Energy, Inc.', 'Miscellaneous', 'China', 65.18, '2021-04-11 09:19:01', '10:56 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Ares Dynamic Credit Allocation Fund, Inc.', 'n/a', 'China', 55.35, '2021-05-29 16:51:51', '2:29 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Xenia Hotels & Resorts, Inc.', 'Consumer Services', 'China', 29.79, '2021-03-16 00:44:20', '9:47 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Cellcom Israel, Ltd.', 'Public Utilities', 'China', 73.37, '2021-01-24 12:52:44', '11:41 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('First Trust Nasdaq Transportation ETF', 'n/a', 'China', 19.95, '2021-01-10 03:39:56', '11:11 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Azul S.A.', 'Transportation', 'China', 40.58, '2021-04-03 02:46:04', '1:00 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Home Bancorp, Inc.', 'Finance', 'China', 69.85, '2021-01-28 11:59:38', '12:34 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Oxford Immunotec Global PLC', 'Health Care', 'China', 91.95, '2021-01-19 12:19:21', '2:22 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Vistra Energy Corp.', 'Public Utilities', 'China', 55.26, '2021-03-18 02:47:00', '1:02 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Hunter Maritime Acquisition Corp.', 'Transportation', 'China', 92.75, '2021-01-02 09:29:32', '1:44 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Strongbridge Biopharma plc', 'Health Care', 'China', 64.21, '2021-05-21 10:32:18', '1:48 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('National Grid Transco, PLC', 'Public Utilities', 'China', 67.31, '2021-06-16 03:15:55', '9:24 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('TC PipeLines, LP', 'Public Utilities', 'China', 93.36, '2021-05-04 04:41:36', '11:00 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Universal Health Realty Income Trust', 'Consumer Services', 'China', 50.59, '2021-04-05 06:19:40', '12:05 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('The AES Corporation', 'n/a', 'China', 92.36, '2021-01-03 06:09:06', '9:44 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Comcast Corporation', 'Consumer Services', 'China', 47.09, '2021-04-19 09:04:46', '2:06 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('CarMax Inc', 'Consumer Durables', 'China', 99.07, '2021-04-19 21:42:58', '9:10 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('POSCO', 'Basic Industries', 'China', 29.88, '2021-04-13 13:58:38', '10:29 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Mexico Fund, Inc. (The)', 'n/a', 'China', 44.11, '2021-06-29 14:20:05', '10:03 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Callidus Software, Inc.', 'Technology', 'China', 73.37, '2021-05-11 00:09:42', '2:23 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Ambac Financial Group, Inc.', 'Finance', 'China', 90.13, '2021-03-06 07:58:55', '12:09 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Nuveen High Income December 2019 Target Term Fund', 'n/a', 'China', 17.37, '2021-06-12 13:20:22', '2:12 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('iFresh Inc.', 'Consumer Services', 'China', 1.48, '2021-06-29 00:55:57', '9:45 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Electro Scientific Industries, Inc.', 'Miscellaneous', 'China', 13.34, '2021-03-07 12:22:11', '9:50 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Raymond James Financial, Inc.', 'Finance', 'China', 78.98, '2021-03-09 06:31:29', '2:25 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Blackrock Municipal Bond Trust', 'n/a', 'China', 15.68, '2021-05-10 00:56:21', '9:16 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('InVivo Therapeutics Holdings Corp.', 'Health Care', 'China', 37.35, '2021-04-08 10:30:10', '11:56 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Oshkosh Corporation', 'Capital Goods', 'China', 63.74, '2021-04-26 21:24:34', '11:03 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Nustar Energy L.P.', 'n/a', 'China', 17.82, '2021-02-03 23:53:39', '10:44 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('X-Links Gold Shares Covered Call ETN', 'Finance', 'China', 75.15, '2021-02-25 04:38:19', '1:45 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Gabelli Utility Trust (The)', 'n/a', 'China', 91.31, '2021-06-18 00:14:35', '10:24 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Perfumania Holdings, Inc', 'Consumer Services', 'China', 38.2, '2021-02-10 04:49:38', '2:26 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Ringcentral, Inc.', 'Technology', 'China', 26.9, '2021-05-23 16:05:41', '11:08 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Liberty Broadband Corporation', 'Consumer Services', 'China', 65.22, '2021-02-27 10:02:47', '9:10 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Blackrock Florida Municipal 2020 Term Trust', 'n/a', 'China', 28.71, '2021-02-15 12:14:01', '1:13 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Tantech Holdings Ltd.', 'Basic Industries', 'China', 51.47, '2021-03-29 23:20:50', '2:35 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Dupont Fabros Technology, Inc.', 'n/a', 'China', 95.73, '2021-03-10 19:20:03', '10:43 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Sotheby''s', 'Miscellaneous', 'China', 63.62, '2021-01-22 20:31:55', '11:49 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Asia Pacific Fund, Inc. (The)', 'n/a', 'China', 46.41, '2021-01-18 11:16:25', '9:27 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('KraneShares CSI China Internet ETF', 'n/a', 'China', 50.81, '2021-06-27 22:47:19', '12:58 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Nova Lifestyle, Inc', 'Consumer Durables', 'China', 13.82, '2021-04-01 06:10:28', '11:59 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Blue Capital Reinsurance Holdings Ltd.', 'Finance', 'China', 90.3, '2021-04-08 04:29:40', '9:04 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('HTG Molecular Diagnostics, Inc.', 'Capital Goods', 'China', 45.03, '2021-03-18 17:44:01', '12:37 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('MGM Growth Properties LLC', 'Consumer Services', 'China', 40.01, '2021-01-01 19:27:25', '2:14 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('SAP SE', 'Technology', 'China', 60.4, '2021-04-25 21:32:08', '10:08 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Anadarko Petroleum Corporation', 'Energy', 'China', 78.98, '2021-04-05 09:46:48', '9:26 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('InfoSonics Corp', 'Consumer Non-Durables', 'China', 75.32, '2021-06-15 18:28:47', '1:51 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('China Advanced Construction Materials Group, Inc.', 'Basic Industries', 'China', 40.8, '2021-04-14 00:42:34', '12:10 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('PulteGroup, Inc.', 'Capital Goods', 'China', 24.88, '2021-02-08 12:26:18', '2:48 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('GCP Applied Technologies Inc.', 'Basic Industries', 'China', 88.51, '2021-01-03 16:42:19', '11:59 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Concordia International Corp.', 'Health Care', 'China', 57.4, '2021-04-29 16:20:20', '12:53 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Knight Transportation, Inc.', 'Transportation', 'China', 49.04, '2021-05-23 16:30:57', '2:13 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Legacy Reserves LP', 'Energy', 'China', 73.35, '2021-03-29 17:35:13', '2:41 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Regis Corporation', 'Consumer Services', 'China', 25.2, '2021-02-03 13:02:40', '2:50 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('GenVec, Inc.', 'Health Care', 'China', 48.58, '2021-01-08 09:49:51', '2:13 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Gabelli Equity Trust, Inc. (The)', 'n/a', 'China', 53.59, '2021-05-27 21:02:31', '10:49 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('National Oilwell Varco, Inc.', 'Energy', 'China', 59.69, '2021-01-08 13:39:07', '2:44 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('IRSA Propiedades Comerciales S.A.', 'Consumer Services', 'China', 79.98, '2021-05-17 15:34:10', '10:38 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Saul Centers, Inc.', 'Consumer Services', 'China', 79.89, '2021-01-30 01:04:00', '1:17 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Pennsylvania Real Estate Investment Trust', 'Consumer Services', 'China', 9.36, '2021-01-01 11:11:32', '2:28 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('TravelCenters of America LLC', 'Consumer Durables', 'China', 75.1, '2021-01-15 14:14:36', '12:07 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Norwegian Cruise Line Holdings Ltd.', 'Consumer Services', 'China', 44.66, '2021-06-17 00:46:27', '11:44 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Blackrock Muni New York Intermediate Duration Fund Inc', 'n/a', 'China', 69.28, '2021-02-12 10:15:09', '12:47 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Medtronic plc', 'Health Care', 'China', 88.18, '2021-05-08 11:51:14', '12:52 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Coffee Holding Co., Inc.', 'Consumer Non-Durables', 'China', 58.03, '2021-01-16 05:33:44', '9:22 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('BlackRock Energy and Resources Trust', 'n/a', 'China', 14.79, '2021-06-07 17:58:26', '9:06 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Verso Corporation', 'Basic Industries', 'China', 63.63, '2021-05-10 18:07:23', '2:29 PM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Otelco Inc.', 'Public Utilities', 'China', 8.19, '2021-01-02 11:15:06', '9:51 AM');
insert into stocks (stock_name, stock_sector, country, price, date, time) values ('Rayonier Inc.', 'Consumer Services', 'China', 11.14, '2021-01-01 21:04:43', '11:29 AM');


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

DELETE FROM buyin;
INSERT INTO buyin 
SELECT username, stock_name, price, date, time 
FROM users, stocks 
ORDER BY RANDOM()
LIMIT 1000; 