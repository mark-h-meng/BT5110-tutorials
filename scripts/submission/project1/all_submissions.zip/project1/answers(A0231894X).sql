/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/* Name: Shuangrui Gao 													*/
/* Student ID: A0231894X                                                */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* In my assignment, I create a set of tables, PEOPLE, LOCATION and VISIT, 
   which can help us find other people who may have close contact with the 
   COVID-19 patient through the places where the patient has arrived, 
   so as to avoid the further spread of the epidemic in time. 
   In the table PEOPLE, I record people's name, gender and email information. 
   In the table LOCATION, I record the places where people have been to. 
   Because I find that the specific location information of all cities around 
   the world can not be generated on mockaroo.com, I generate data only from 
   China, and I use longitude and latitude information to record the places 
   people have visited. Then, the table VISIT shows us who has been to which 
   places recently. With this method, once someone confirms COVID-19, we can 
   find out where he has been through the table, and find people who have been 
   to the same place with him. Then, we can test them in time to prevent the 
   spread of the epidemic. The following questions will be written for PostgreSQL. 
*/

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS PEOPLE (
	FIRST_NAME VARCHAR(50) NOT NULL,
	LAST_NAME VARCHAR(50) NOT NULL,
	GENDER VARCHAR(6) CHECK(GENDER = 'Male' OR GENDER = 'Female'),
	EMAIL VARCHAR(50) NOT NULL,
	PRIMARY KEY (FIRST_NAME, LAST_NAME, EMAIL)
);

CREATE TABLE IF NOT EXISTS LOCATION(
	COUNTRY VARCHAR(50),
	CITY VARCHAR(50),
	LONGITUDE VARCHAR(50),
	LATITUDE VARCHAR(50),
	PRIMARY KEY (LONGITUDE, LATITUDE)
);

CREATE TABLE IF NOT EXISTS VISIT(
	FIRST_NAME VARCHAR(50),
	LAST_NAME VARCHAR(50),
	EMAIL VARCHAR(50),
	FOREIGN KEY (FIRST_NAME, LAST_NAME, EMAIL) REFERENCES PEOPLE(FIRST_NAME, LAST_NAME, EMAIL) ON DELETE CASCADE DEFERRABLE,
	LONGITUDE VARCHAR(50),
	LATITUDE VARCHAR(50),
	FOREIGN KEY (LONGITUDE, LATITUDE) REFERENCES LOCATION(LONGITUDE, LATITUDE) ON DELETE CASCADE DEFERRABLE,
	PRIMARY KEY (FIRST_NAME, LAST_NAME, EMAIL, LONGITUDE, LATITUDE)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Oralia', 'Vinnick', 'Female', 'ovinnick0@netvibes.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Phebe', 'Ketts', 'Female', 'pketts1@comsenz.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Fidel', 'Rivelon', 'Female', 'frivelon2@instagram.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Iorgos', 'Lenton', 'Male', 'ilenton3@php.net');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Colene', 'Brumen', 'Female', 'cbrumen4@chicagotribune.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Flory', 'Schiell', 'Male', 'fschiell5@51.la');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Emmalee', 'Penna', 'Female', 'epenna6@elegantthemes.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Tomasina', 'Guynemer', 'Male', 'tguynemer7@apache.org');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Petey', 'Rawlingson', 'Male', 'prawlingson8@senate.gov');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Lurleen', 'Sanches', 'Female', 'lsanches9@howstuffworks.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Towney', 'Birtle', 'Female', 'tbirtlea@smugmug.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Sasha', 'De Bernardis', 'Male', 'sdebernardisb@gmpg.org');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Concettina', 'Millbank', 'Male', 'cmillbankc@wordpress.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Vania', 'Elkins', 'Female', 'velkinsd@pinterest.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Melitta', 'Austing', 'Female', 'maustinge@jimdo.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Juditha', 'Crust', 'Male', 'jcrustf@purevolume.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Beltran', 'Whapham', 'Male', 'bwhaphamg@umn.edu');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Chelsy', 'Heatley', 'Male', 'cheatleyh@nature.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Steffane', 'Saylor', 'Female', 'ssaylori@army.mil');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Darelle', 'Rees', 'Female', 'dreesj@google.de');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Wandie', 'Mishaw', 'Male', 'wmishawk@bravesites.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Pansie', 'Bundock', 'Male', 'pbundockl@cbc.ca');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Brooks', 'Ianizzi', 'Female', 'bianizzim@de.vu');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Vidovic', 'Lunge', 'Male', 'vlungen@archive.org');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Westleigh', 'Leavesley', 'Male', 'wleavesleyo@lulu.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Morie', 'Northing', 'Female', 'mnorthingp@drupal.org');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Lynelle', 'Jacox', 'Female', 'ljacoxq@foxnews.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Bethanne', 'Jewson', 'Female', 'bjewsonr@businesswire.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Elayne', 'Janeczek', 'Male', 'ejaneczeks@fema.gov');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Ashby', 'Showl', 'Male', 'ashowlt@cnn.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Cos', 'Goldberg', 'Male', 'cgoldbergu@google.de');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Wat', 'Hamberston', 'Male', 'whamberstonv@unicef.org');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Sharity', 'Ivasechko', 'Female', 'sivasechkow@vinaora.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Sergeant', 'Wisedale', 'Female', 'swisedalex@godaddy.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Aldon', 'Coate', 'Female', 'acoatey@discovery.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Steffen', 'Lilywhite', 'Female', 'slilywhitez@hubpages.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Hector', 'Browell', 'Female', 'hbrowell10@google.ca');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Aguie', 'Brotherton', 'Female', 'abrotherton11@chicagotribune.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Renae', 'Burds', 'Male', 'rburds12@wikimedia.org');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Petronia', 'Backson', 'Female', 'pbackson13@independent.co.uk');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Sharyl', 'Davydenko', 'Female', 'sdavydenko14@bbb.org');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Mal', 'Josebury', 'Male', 'mjosebury15@freewebs.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Dinnie', 'Calken', 'Female', 'dcalken16@yahoo.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Minnnie', 'Tunstall', 'Female', 'mtunstall17@msn.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Gregor', 'Widmoor', 'Male', 'gwidmoor18@hatena.ne.jp');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Raul', 'Jillitt', 'Female', 'rjillitt19@samsung.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Gonzales', 'Cramer', 'Female', 'gcramer1a@odnoklassniki.ru');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Melamie', 'Minci', 'Female', 'mminci1b@ustream.tv');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Weidar', 'Brave', 'Female', 'wbrave1c@cnbc.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Cherry', 'Mulvaney', 'Male', 'cmulvaney1d@squarespace.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Geoffrey', 'McGrorty', 'Male', 'gmcgrorty1e@illinois.edu');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Chastity', 'Farlane', 'Male', 'cfarlane1f@seattletimes.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Auroora', 'Howton', 'Male', 'ahowton1g@lycos.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Bord', 'Gavozzi', 'Male', 'bgavozzi1h@loc.gov');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Courtney', 'Aggis', 'Male', 'caggis1i@earthlink.net');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Jayme', 'Hakewell', 'Male', 'jhakewell1j@cam.ac.uk');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Angela', 'Mowsdell', 'Female', 'amowsdell1k@tripadvisor.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Nick', 'Trillow', 'Female', 'ntrillow1l@theguardian.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Karrie', 'Dwyr', 'Female', 'kdwyr1m@vk.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Darleen', 'Slad', 'Female', 'dslad1n@skyrock.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Randi', 'Farherty', 'Male', 'rfarherty1o@ted.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Roselin', 'Goundry', 'Female', 'rgoundry1p@i2i.jp');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Kellen', 'Lapsley', 'Female', 'klapsley1q@alexa.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Brendon', 'Rostron', 'Female', 'brostron1r@g.co');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Claiborn', 'Besnard', 'Male', 'cbesnard1s@youtu.be');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Clayborne', 'Duding', 'Female', 'cduding1t@cocolog-nifty.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Irene', 'Hought', 'Male', 'ihought1u@geocities.jp');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Shellie', 'Kikke', 'Male', 'skikke1v@epa.gov');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Maible', 'Sloy', 'Male', 'msloy1w@ycombinator.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Priscella', 'McDermott', 'Female', 'pmcdermott1x@youku.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Carney', 'Jozsa', 'Male', 'cjozsa1y@statcounter.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Faun', 'Mara', 'Male', 'fmara1z@unc.edu');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Bordie', 'Swyne', 'Female', 'bswyne20@un.org');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Eran', 'Minett', 'Female', 'eminett21@infoseek.co.jp');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Michaella', 'Skerme', 'Male', 'mskerme22@pen.io');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Elsey', 'Thunnerclef', 'Male', 'ethunnerclef23@wikipedia.org');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Kirk', 'Bonnesen', 'Male', 'kbonnesen24@nifty.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Johannah', 'Hurlston', 'Male', 'jhurlston25@unicef.org');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Kristan', 'Durante', 'Male', 'kdurante26@exblog.jp');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Andra', 'Pashby', 'Female', 'apashby27@lulu.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Cherise', 'Cockland', 'Female', 'ccockland28@google.com.br');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Robb', 'Bowfin', 'Female', 'rbowfin29@blogger.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Jud', 'Schoroder', 'Male', 'jschoroder2a@ebay.co.uk');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Enoch', 'O''Hengerty', 'Male', 'eohengerty2b@bigcartel.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Dalia', 'Mathew', 'Male', 'dmathew2c@godaddy.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Dur', 'Burnall', 'Female', 'dburnall2d@state.tx.us');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Raye', 'Stickney', 'Male', 'rstickney2e@oracle.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Chevalier', 'Arr', 'Male', 'carr2f@gmpg.org');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Wendy', 'Cox', 'Female', 'wcox2g@forbes.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Juline', 'Chmiel', 'Female', 'jchmiel2h@sfgate.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Jill', 'Arling', 'Female', 'jarling2i@vk.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Borg', 'Zecchinelli', 'Female', 'bzecchinelli2j@yahoo.co.jp');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Molli', 'Brent', 'Female', 'mbrent2k@google.de');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Immanuel', 'Kundert', 'Male', 'ikundert2l@cdbaby.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Michael', 'Tresler', 'Male', 'mtresler2m@studiopress.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Parry', 'Daymond', 'Male', 'pdaymond2n@bizjournals.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Damien', 'Shearston', 'Female', 'dshearston2o@ted.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Sal', 'Pidler', 'Female', 'spidler2p@arstechnica.com');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Lothario', 'Tooth', 'Female', 'ltooth2q@unblog.fr');
insert into PEOPLE (FIRST_NAME, LAST_NAME, GENDER, EMAIL) values ('Lizbeth', 'Gibling', 'Male', 'lgibling2r@washingtonpost.com');

insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Xiangyanglu', 111.6631302, 38.2792524);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Shanshi', 111.8568586, 37.2425649);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Tangjiakou', 114.886335, 40.767544);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Huangbei', 115.744112, 24.412155);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Jiangbei', 106.574271, 29.606703);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Huagai', 120.6626572, 28.0154753);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Tianta', 117.1770394, 39.0924952);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Shiyan', 110.798266, 32.629398);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Xianzong', 118.002516, 31.803171);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Jiuheyuan', 112.385429, 29.604453);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Lianhe', 101.808485, 36.608183);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Huanan', 130.553343, 46.239185);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Jingmen', 112.199427, 31.035395);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Malian', 116.4578203, 39.9391612);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Caigongzhuang', 117.081971, 38.78918);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Luoping', 104.308675, 24.884626);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Lingmen', -84.9047641, 32.5571916);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Quankou', 114.300474, 29.591108);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Jiangkou', 108.839557, 27.69965);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Jingmeng', 112.199427, 31.035398);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Penghu', 119.5793157, 23.5711899);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Houjia', 122.093267, 37.020948);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Lihu', 120.270218, 31.520703);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Ehu', 117.697041, 28.3079856);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Haicheng', 122.685217, 40.882377);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Huaqiao', 118.6422409, 24.9372186);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Zhangcaizhuang', 112.340495, 39.289991);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Gaoxiang', 120.632896, 27.974248);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Tianjiazhai', 109.465494, 29.686964);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Kanbula', 101.81962, 36.114691);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Yushugou', 89.939332, 43.897258);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Gyangkar', 87.771182, 28.363741);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Fuding', 120.216978, 27.324479);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Nanshi', 113.525165, 22.801624);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Burgastai', 94.192003, 44.718853);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Lugu', 100.7887231, 27.7244646);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Mazha', 114.010317, 23.460229);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Qilin', 103.805012, 25.495241);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Huifeng', 120.183979, 31.983055);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Sangzhou', 120.585289, 31.298974);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Namling', 89.099242, 29.68233);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Qinglung', 118.949684, 40.407578);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Da’an', 124.292626, 45.506995);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Chang’an', 108.906994, 34.158997);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Jiufeng', 120.4910168, 30.7446878);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Xiaolongmen', 117.103146, 40.412369);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Qiaonan', 113.3681177, 22.925131);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Zhengchang', 118.993664, 34.348841);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Amgalang', 118.2, 48.25);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Xirikxiy', 88.027707, 47.357916);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Xiting', 121.009708, 32.117935);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Huaping', 101.266195, 26.629211);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Niejiahe', 111.302191, 30.297685);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Fengshan', 107.04219, 24.546876);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Xinan', 112.132488, 34.728584);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Meicheng', 111.656407, 28.133945);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Kuasha', 101.529663, 32.610076);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Laoliangcang', 112.217855, 28.065524);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Xinkaikou', 114.8869194, 40.794611);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Zhaozhen', 104.439763, 30.856856);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Fengshuling', 116.475481, 30.235005);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Erping', 112.305145, 22.183206);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Suyang', 115.814504, 32.890479);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Yinjiaxi', 110.4185, 29.135219);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Yinhedahan’er', 123.0199373, 48.0288905);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Huangtian', 113.814606, 22.636828);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Shimen', 111.380014, 29.584292);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Baikui', 127.010966, 46.366234);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Qimeng', 2.1633946, 41.393981);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Caojia', 111.349622, 27.820674);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Machikou', 116.2144241, 40.1860023);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Bangjun', 117.274909, 39.989836);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Zhongping', 107.762268, 31.904326);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Taihua', 113.89831, 22.5738562);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Yanshi', 112.789534, 34.72722);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Runsonglaozhai', 109.09528, 26.86889);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Baqiao', 109.064671, 34.273409);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Maji', 106.009915, 34.34866);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Yanping', 118.182036, 26.637438);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Suzhong', 120.585289, 31.298978);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Leyuan', -94.4189829, 18.144657);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Hanyuan', 102.652483, 29.344616);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Nierumai', 89.944038, 28.708282);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Jiegan', 117.120095, 36.6512);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Chengji', 104.066801, 30.572815);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Hujiaying', 104.980581, 26.497669);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Ligang', 120.085146, 31.919897);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Tashang', 114.210844, 38.396542);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Sixi', 118.132068, 27.720727);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Yajiang', 101.014425, 30.031533);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Wutongkou', 115.400234, 25.84999);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Wanghu', 116.244678, 30.661419);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Xinxing', 112.225334, 22.69569);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Nanhu', 120.783024, 30.747842);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Poyang', 116.2777073, 29.1253133);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Shiren', 117.9041296, 28.6517036);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Hanchang', 113.584985, 28.704586);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Shuangfeng', 112.175245, 27.456658);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Pancheng', 120.16366, 33.347316);
insert into LOCATION (COUNTRY, CITY, LONGITUDE, LATITUDE) values ('China', 'Huangsha', 113.240664, 23.110052);
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO VISIT(FIRST_NAME, LAST_NAME, EMAIL, LONGITUDE, LATITUDE) 
SELECT PEOPLE.FIRST_NAME, PEOPLE.LAST_NAME, PEOPLE.EMAIL, LOCATION.LONGITUDE, LOCATION.LATITUDE
FROM PEOPLE, LOCATION ORDER BY RANDOM() LIMIT 1000;
