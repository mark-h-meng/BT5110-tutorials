/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/* name: Guan Zhiling                                   */
/*Student id: A0232012E                               */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for SQLite */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
If describing with the annotations in the diagram, then the entity set E1 is to be "students", the entity set E2 is to be "modules" and the relationship set R is to be "modreg".
In table students, there are 5 attributes, "first_name" and "last_name" indicating the students' first names and last names, "studentid" indicating students' identification number on the campus, "email" indicating students' unique email addresses, and "country" indicating the countries where students are from. 
In table modules, there are 4 attributes, "name" indicating unique names of modules, "code" indicating codes of the corresponding modules, "class" indicating the specific classes of the modules, and "unit" indicating units of the modules.
The last table modreg represents the modules that students register. There are 4 attributes in it. "studentid" represents the student's identification number. "modulecode" and "moduleclass" indicate the specific module and class that students register. "status" indicate if the student register the module successfully. Each student can register more than one module.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
.mode column
.header ON
PRAGMA foreign_keys = ON;

CREATE TABLE students(
first_name VARCHAR(64) NOT NULL,
last_name VARCHAR(64) NOT NULL,
studentid VARCHAR(32) PRIMARY KEY,
email VARCHAR(64) NOT NULL UNIQUE,
country VARCHAR(16) NOT NULL);

CREATE TABLE modules(
name VARCHAR(64) NOT NULL UNIQUE,
code VARCHAR(16),
class VARCHAR(2),
unit NUMERIC CHECK (unit>0),
PRIMARY KEY(code, class));

CREATE TABLE modreg(
studentid VARCHAR(32) REFERENCES students(studentid)
ON UPDATE CASCADE
ON DELETE CASCADE,
modulecode VARCHAR(16),
moduleclass VARCHAR(2),
status VARCHAR(1) DEFAULT "N",
PRIMARY KEY (studentid, modulecode, moduleclass),
FOREIGN KEY (modulecode, moduleclass) REFERENCES modules(code, class)
ON UPDATE CASCADE
ON DELETE CASCADE);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into students (first_name, last_name, studentid, email, country) values ('Kimmy', 'Fowlds', '59-7029525', 'kfowlds0@sphinn.com', 'Pakistan');
insert into students (first_name, last_name, studentid, email, country) values ('Jeralee', 'Bichener', '42-7818987', 'jbichener1@nytimes.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Lynelle', 'Jedrychowski', '24-8655326', 'ljedrychowski2@wiley.com', 'Sweden');
insert into students (first_name, last_name, studentid, email, country) values ('Charisse', 'Jancar', '82-9573038', 'cjancar3@hp.com', 'Indonesia');
insert into students (first_name, last_name, studentid, email, country) values ('Gabbie', 'Laxe', '73-0046303', 'glaxe4@homestead.com', 'Bulgaria');
insert into students (first_name, last_name, studentid, email, country) values ('Cash', 'Riddle', '83-3840677', 'criddle5@dyndns.org', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Sheilah', 'Forrington', '16-0217711', 'sforrington6@vinaora.com', 'Russia');
insert into students (first_name, last_name, studentid, email, country) values ('Alexia', 'Jorioz', '56-0505247', 'ajorioz7@fc2.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Dorothea', 'Bransby', '27-0154368', 'dbransby8@drupal.org', 'Norway');
insert into students (first_name, last_name, studentid, email, country) values ('Tore', 'Dickson', '23-4257072', 'tdickson9@ted.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Lura', 'Chaloner', '75-3674543', 'lchalonera@prweb.com', 'Norway');
insert into students (first_name, last_name, studentid, email, country) values ('Maurizio', 'Gorke', '32-6552974', 'mgorkeb@ustream.tv', 'Brazil');
insert into students (first_name, last_name, studentid, email, country) values ('Maud', 'McConachie', '28-1683192', 'mmcconachiec@example.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Prentice', 'Coller', '44-5608428', 'pcollerd@youku.com', 'Philippines');
insert into students (first_name, last_name, studentid, email, country) values ('Shari', 'Berrigan', '87-2142508', 'sberrigane@yahoo.com', 'Ukraine');
insert into students (first_name, last_name, studentid, email, country) values ('Norton', 'Rantoull', '83-3394896', 'nrantoullf@sbwire.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Ardis', 'Lilbourne', '67-4593387', 'alilbourneg@ftc.gov', 'Rwanda');
insert into students (first_name, last_name, studentid, email, country) values ('Margaux', 'Kadd', '09-4247519', 'mkaddh@sourceforge.net', 'Indonesia');
insert into students (first_name, last_name, studentid, email, country) values ('Son', 'Andriveaux', '06-4032966', 'sandriveauxi@cloudflare.com', 'Canada');
insert into students (first_name, last_name, studentid, email, country) values ('Lisette', 'Oddy', '94-4055753', 'loddyj@webmd.com', 'Tajikistan');
insert into students (first_name, last_name, studentid, email, country) values ('Pepe', 'Rosoni', '69-4140634', 'prosonik@domainmarket.com', 'Afghanistan');
insert into students (first_name, last_name, studentid, email, country) values ('Sollie', 'Melly', '73-1469780', 'smellyl@facebook.com', 'Philippines');
insert into students (first_name, last_name, studentid, email, country) values ('Olivette', 'Volcker', '78-1393533', 'ovolckerm@marriott.com', 'Thailand');
insert into students (first_name, last_name, studentid, email, country) values ('Alisha', 'McAviy', '57-0837803', 'amcaviyn@opera.com', 'Reunion');
insert into students (first_name, last_name, studentid, email, country) values ('Hershel', 'Swapp', '71-5212221', 'hswappo@mashable.com', 'South Korea');
insert into students (first_name, last_name, studentid, email, country) values ('Thatch', 'Robel', '36-8778967', 'trobelp@hubpages.com', 'Indonesia');
insert into students (first_name, last_name, studentid, email, country) values ('Addy', 'Kamiyama', '76-2773691', 'akamiyamaq@bloglines.com', 'Indonesia');
insert into students (first_name, last_name, studentid, email, country) values ('Yolande', 'Elwell', '42-9396454', 'yelwellr@hubpages.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Court', 'Minto', '88-5958564', 'cmintos@plala.or.jp', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Sosanna', 'Warke', '97-8261945', 'swarket@edublogs.org', 'Poland');
insert into students (first_name, last_name, studentid, email, country) values ('Randa', 'Faireclough', '87-6055384', 'rfairecloughu@wikispaces.com', 'Mongolia');
insert into students (first_name, last_name, studentid, email, country) values ('Nikaniki', 'Schenkel', '01-4835547', 'nschenkelv@elpais.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Cordell', 'Cutmare', '90-8636647', 'ccutmarew@hubpages.com', 'Philippines');
insert into students (first_name, last_name, studentid, email, country) values ('Garnet', 'Billborough', '87-2321108', 'gbillboroughx@quantcast.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Tabitha', 'Beckey', '71-5124189', 'tbeckeyy@sakura.ne.jp', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Ravi', 'Malan', '29-3992461', 'rmalanz@indiegogo.com', 'Russia');
insert into students (first_name, last_name, studentid, email, country) values ('Wally', 'Zecchinii', '02-5043325', 'wzecchinii10@hugedomains.com', 'Niger');
insert into students (first_name, last_name, studentid, email, country) values ('Adriaens', 'Leele', '33-5235023', 'aleele11@4shared.com', 'Indonesia');
insert into students (first_name, last_name, studentid, email, country) values ('Carrie', 'McClenaghan', '13-6113511', 'cmcclenaghan12@gravatar.com', 'Netherlands');
insert into students (first_name, last_name, studentid, email, country) values ('Adolf', 'Barfield', '76-7293020', 'abarfield13@yale.edu', 'Portugal');
insert into students (first_name, last_name, studentid, email, country) values ('Penelopa', 'Kildea', '64-4448009', 'pkildea14@oakley.com', 'Indonesia');
insert into students (first_name, last_name, studentid, email, country) values ('Saw', 'Catterson', '63-8903367', 'scatterson15@salon.com', 'Honduras');
insert into students (first_name, last_name, studentid, email, country) values ('Nil', 'Tertre', '90-7360584', 'ntertre16@e-recht24.de', 'Thailand');
insert into students (first_name, last_name, studentid, email, country) values ('Coral', 'Vasnev', '92-9419598', 'cvasnev17@ameblo.jp', 'Czech Republic');
insert into students (first_name, last_name, studentid, email, country) values ('Ag', 'Coch', '01-5473849', 'acoch18@so-net.ne.jp', 'Philippines');
insert into students (first_name, last_name, studentid, email, country) values ('Roderick', 'Wipfler', '31-1483753', 'rwipfler19@yahoo.com', 'Poland');
insert into students (first_name, last_name, studentid, email, country) values ('Rosene', 'Emsden', '28-4856938', 'remsden1a@nbcnews.com', 'Brazil');
insert into students (first_name, last_name, studentid, email, country) values ('Charyl', 'Drinkale', '12-9654230', 'cdrinkale1b@phoca.cz', 'Mexico');
insert into students (first_name, last_name, studentid, email, country) values ('Jackie', 'Dunster', '29-7703037', 'jdunster1c@businessweek.com', 'Canada');
insert into students (first_name, last_name, studentid, email, country) values ('Noam', 'Byrne', '13-4970937', 'nbyrne1d@1688.com', 'Poland');
insert into students (first_name, last_name, studentid, email, country) values ('Rachael', 'Hardie', '90-7515662', 'rhardie1e@comsenz.com', 'Indonesia');
insert into students (first_name, last_name, studentid, email, country) values ('Lea', 'Yurevich', '98-6322220', 'lyurevich1f@cbsnews.com', 'Pakistan');
insert into students (first_name, last_name, studentid, email, country) values ('Sib', 'Sturdgess', '62-0542395', 'ssturdgess1g@ucsd.edu', 'Indonesia');
insert into students (first_name, last_name, studentid, email, country) values ('Wilbur', 'Golbourn', '80-1543773', 'wgolbourn1h@chicagotribune.com', 'Nigeria');
insert into students (first_name, last_name, studentid, email, country) values ('Judye', 'Lumpkin', '12-0318935', 'jlumpkin1i@cmu.edu', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Dru', 'Hunston', '43-3736333', 'dhunston1j@economist.com', 'Poland');
insert into students (first_name, last_name, studentid, email, country) values ('Patsy', 'Stoneman', '03-9514342', 'pstoneman1k@smh.com.au', 'Philippines');
insert into students (first_name, last_name, studentid, email, country) values ('Felice', 'Lemme', '95-5734390', 'flemme1l@odnoklassniki.ru', 'Philippines');
insert into students (first_name, last_name, studentid, email, country) values ('Kirbee', 'Latehouse', '50-4427156', 'klatehouse1m@yelp.com', 'Philippines');
insert into students (first_name, last_name, studentid, email, country) values ('Leo', 'Bridle', '32-0684621', 'lbridle1n@tiny.cc', 'Peru');
insert into students (first_name, last_name, studentid, email, country) values ('Christophorus', 'Beamand', '73-6207710', 'cbeamand1o@whitehouse.gov', 'Panama');
insert into students (first_name, last_name, studentid, email, country) values ('Derick', 'Giacubbo', '93-9141454', 'dgiacubbo1p@newyorker.com', 'Indonesia');
insert into students (first_name, last_name, studentid, email, country) values ('Judah', 'Vinas', '85-5354681', 'jvinas1q@is.gd', 'Ukraine');
insert into students (first_name, last_name, studentid, email, country) values ('Elna', 'Bruhnicke', '29-9601800', 'ebruhnicke1r@vimeo.com', 'Macedonia');
insert into students (first_name, last_name, studentid, email, country) values ('Deborah', 'MacKaile', '91-8814233', 'dmackaile1s@cnbc.com', 'Russia');
insert into students (first_name, last_name, studentid, email, country) values ('Terra', 'Scrooby', '96-6762408', 'tscrooby1t@webnode.com', 'Japan');
insert into students (first_name, last_name, studentid, email, country) values ('Noble', 'Berthouloume', '66-4121239', 'nberthouloume1u@purevolume.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Shermie', 'Cuniam', '31-6502079', 'scuniam1v@squarespace.com', 'Argentina');
insert into students (first_name, last_name, studentid, email, country) values ('Lorettalorna', 'Streat', '39-9293275', 'lstreat1w@biblegateway.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Kassey', 'Edling', '20-8890883', 'kedling1x@wordpress.com', 'Sweden');
insert into students (first_name, last_name, studentid, email, country) values ('Jeddy', 'Cricket', '41-6049091', 'jcricket1y@purevolume.com', 'Estonia');
insert into students (first_name, last_name, studentid, email, country) values ('Finlay', 'Splevins', '77-3177729', 'fsplevins1z@google.es', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Rubia', 'Petras', '30-8606036', 'rpetras20@geocities.jp', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Lemmie', 'Labbe', '58-7785778', 'llabbe21@soundcloud.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Daisi', 'Hoodless', '19-6320928', 'dhoodless22@discovery.com', 'Indonesia');
insert into students (first_name, last_name, studentid, email, country) values ('Mathilda', 'Stourton', '10-9784625', 'mstourton23@naver.com', 'Malaysia');
insert into students (first_name, last_name, studentid, email, country) values ('Ambrosio', 'Reville', '12-8236281', 'areville24@google.it', 'Brazil');
insert into students (first_name, last_name, studentid, email, country) values ('Juliette', 'Rutledge', '29-1086231', 'jrutledge25@narod.ru', 'Indonesia');
insert into students (first_name, last_name, studentid, email, country) values ('Janey', 'Moulsdall', '31-6420012', 'jmoulsdall26@ask.com', 'Canada');
insert into students (first_name, last_name, studentid, email, country) values ('Cherrita', 'Antonoyev', '33-2516813', 'cantonoyev27@tiny.cc', 'Russia');
insert into students (first_name, last_name, studentid, email, country) values ('Kit', 'Foresight', '22-2828992', 'kforesight28@mac.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Winifred', 'Ebden', '91-0147092', 'webden29@woothemes.com', 'Ethiopia');
insert into students (first_name, last_name, studentid, email, country) values ('Jenilee', 'Linay', '10-6210515', 'jlinay2a@opera.com', 'Syria');
insert into students (first_name, last_name, studentid, email, country) values ('Thia', 'Fowley', '64-0328708', 'tfowley2b@nytimes.com', 'Philippines');
insert into students (first_name, last_name, studentid, email, country) values ('Adrianne', 'Borzoni', '35-6663489', 'aborzoni2c@gravatar.com', 'Indonesia');
insert into students (first_name, last_name, studentid, email, country) values ('Dulcia', 'Blowing', '35-3700105', 'dblowing2d@cyberchimps.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Cody', 'Westraw', '19-6407659', 'cwestraw2e@sfgate.com', 'Germany');
insert into students (first_name, last_name, studentid, email, country) values ('Dennison', 'Stoltz', '37-0598050', 'dstoltz2f@nydailynews.com', 'Macedonia');
insert into students (first_name, last_name, studentid, email, country) values ('Kara-lynn', 'Shiels', '59-9996947', 'kshiels2g@alibaba.com', 'Brazil');
insert into students (first_name, last_name, studentid, email, country) values ('Felicia', 'Evenett', '33-1153679', 'fevenett2h@netvibes.com', 'Mali');
insert into students (first_name, last_name, studentid, email, country) values ('Say', 'Cady', '85-4275745', 'scady2i@nsw.gov.au', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Carissa', 'Ayliff', '54-5325368', 'cayliff2j@mtv.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Janaya', 'Courtois', '31-5277389', 'jcourtois2k@pinterest.com', 'Portugal');
insert into students (first_name, last_name, studentid, email, country) values ('Daveen', 'Haibel', '91-5611245', 'dhaibel2l@nps.gov', 'Ukraine');
insert into students (first_name, last_name, studentid, email, country) values ('Doralia', 'Levy', '39-7105025', 'dlevy2m@biblegateway.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Kayne', 'Denis', '80-5353788', 'kdenis2n@ning.com', 'France');
insert into students (first_name, last_name, studentid, email, country) values ('Leland', 'Abramin', '65-7140230', 'labramin2o@icio.us', 'Sweden');
insert into students (first_name, last_name, studentid, email, country) values ('Lenard', 'Lidyard', '54-0275588', 'llidyard2p@hatena.ne.jp', 'Madagascar');
insert into students (first_name, last_name, studentid, email, country) values ('Merrel', 'Ossenna', '69-4841186', 'mossenna2q@seattletimes.com', 'China');
insert into students (first_name, last_name, studentid, email, country) values ('Ida', 'Bakeup', '36-1281621', 'ibakeup2r@slashdot.org', 'Brazil');

insert into modules (name, code, class, unit) values ('MODULENAME802', 'AC42', 'L3', 5);
insert into modules (name, code, class, unit) values ('MODULENAME514', 'BD35', 'T3', 6);
insert into modules (name, code, class, unit) values ('MODULENAME027', 'BD92', 'L3', 5);
insert into modules (name, code, class, unit) values ('MODULENAME678', 'AC70', 'L1', 3);
insert into modules (name, code, class, unit) values ('MODULENAME286', 'AD74', 'T3', 5);
insert into modules (name, code, class, unit) values ('MODULENAME153', 'BC95', 'S1', 1);
insert into modules (name, code, class, unit) values ('MODULENAME584', 'AC89', 'S3', 3);
insert into modules (name, code, class, unit) values ('MODULENAME585', 'AC42', 'S1', 5);
insert into modules (name, code, class, unit) values ('MODULENAME716', 'BD56', 'S3', 2);
insert into modules (name, code, class, unit) values ('MODULENAME603', 'BC61', 'S1', 1);
insert into modules (name, code, class, unit) values ('MODULENAME679', 'BD95', 'S3', 4);
insert into modules (name, code, class, unit) values ('MODULENAME654', 'BC43', 'L3', 6);
insert into modules (name, code, class, unit) values ('MODULENAME820', 'BD93', 'S2', 3);
insert into modules (name, code, class, unit) values ('MODULENAME681', 'AD79', 'T3', 6);
insert into modules (name, code, class, unit) values ('MODULENAME619', 'AC71', 'S1', 1);
insert into modules (name, code, class, unit) values ('MODULENAME370', 'BC35', 'L2', 1);
insert into modules (name, code, class, unit) values ('MODULENAME854', 'AC72', 'S1', 1);
insert into modules (name, code, class, unit) values ('MODULENAME825', 'BD61', 'L2', 2);
insert into modules (name, code, class, unit) values ('MODULENAME281', 'BD90', 'L3', 6);
insert into modules (name, code, class, unit) values ('MODULENAME536', 'BD23', 'T3', 4);
insert into modules (name, code, class, unit) values ('MODULENAME149', 'BD16', 'L3', 1);
insert into modules (name, code, class, unit) values ('MODULENAME006', 'AD08', 'S1', 3);
insert into modules (name, code, class, unit) values ('MODULENAME194', 'AD28', 'S1', 2);
insert into modules (name, code, class, unit) values ('MODULENAME582', 'AC32', 'L2', 2);
insert into modules (name, code, class, unit) values ('MODULENAME812', 'AC94', 'S1', 6);
insert into modules (name, code, class, unit) values ('MODULENAME304', 'AD67', 'T2', 5);
insert into modules (name, code, class, unit) values ('MODULENAME486', 'AD11', 'S1', 4);
insert into modules (name, code, class, unit) values ('MODULENAME512', 'AD33', 'S1', 6);
insert into modules (name, code, class, unit) values ('MODULENAME856', 'BD42', 'S2', 2);
insert into modules (name, code, class, unit) values ('MODULENAME535', 'BD41', 'T3', 1);
insert into modules (name, code, class, unit) values ('MODULENAME009', 'BD99', 'L1', 3);
insert into modules (name, code, class, unit) values ('MODULENAME596', 'BD14', 'L2', 6);
insert into modules (name, code, class, unit) values ('MODULENAME307', 'AC96', 'S3', 6);
insert into modules (name, code, class, unit) values ('MODULENAME124', 'BC74', 'L2', 1);
insert into modules (name, code, class, unit) values ('MODULENAME911', 'AC30', 'S3', 6);
insert into modules (name, code, class, unit) values ('MODULENAME549', 'BD45', 'S3', 6);
insert into modules (name, code, class, unit) values ('MODULENAME940', 'BC87', 'S1', 4);
insert into modules (name, code, class, unit) values ('MODULENAME113', 'AC39', 'S3', 1);
insert into modules (name, code, class, unit) values ('MODULENAME195', 'BD90', 'S1', 4);
insert into modules (name, code, class, unit) values ('MODULENAME729', 'AC55', 'S2', 4);
insert into modules (name, code, class, unit) values ('MODULENAME507', 'AD45', 'S2', 6);
insert into modules (name, code, class, unit) values ('MODULENAME547', 'AD59', 'S3', 3);
insert into modules (name, code, class, unit) values ('MODULENAME817', 'AD10', 'S3', 6);
insert into modules (name, code, class, unit) values ('MODULENAME612', 'AC58', 'T3', 2);
insert into modules (name, code, class, unit) values ('MODULENAME580', 'BC43', 'T3', 4);
insert into modules (name, code, class, unit) values ('MODULENAME146', 'BC97', 'S2', 4);
insert into modules (name, code, class, unit) values ('MODULENAME137', 'AD34', 'L2', 6);
insert into modules (name, code, class, unit) values ('MODULENAME143', 'BC18', 'L3', 4);
insert into modules (name, code, class, unit) values ('MODULENAME965', 'BD17', 'S1', 5);
insert into modules (name, code, class, unit) values ('MODULENAME314', 'AC64', 'S3', 4);
insert into modules (name, code, class, unit) values ('MODULENAME881', 'AC42', 'T3', 4);
insert into modules (name, code, class, unit) values ('MODULENAME341', 'BC71', 'T2', 6);
insert into modules (name, code, class, unit) values ('MODULENAME429', 'BC89', 'T3', 1);
insert into modules (name, code, class, unit) values ('MODULENAME250', 'AD62', 'S3', 4);
insert into modules (name, code, class, unit) values ('MODULENAME061', 'BD84', 'S3', 2);
insert into modules (name, code, class, unit) values ('MODULENAME032', 'AC44', 'S1', 5);
insert into modules (name, code, class, unit) values ('MODULENAME721', 'BC09', 'L3', 2);
insert into modules (name, code, class, unit) values ('MODULENAME136', 'AC24', 'T3', 2);
insert into modules (name, code, class, unit) values ('MODULENAME769', 'BC65', 'S2', 3);
insert into modules (name, code, class, unit) values ('MODULENAME373', 'BC18', 'T3', 2);
insert into modules (name, code, class, unit) values ('MODULENAME219', 'BC76', 'S3', 2);
insert into modules (name, code, class, unit) values ('MODULENAME016', 'BD88', 'S2', 1);
insert into modules (name, code, class, unit) values ('MODULENAME577', 'BD38', 'S3', 5);
insert into modules (name, code, class, unit) values ('MODULENAME752', 'AC86', 'S1', 3);
insert into modules (name, code, class, unit) values ('MODULENAME749', 'AC11', 'L3', 6);
insert into modules (name, code, class, unit) values ('MODULENAME982', 'BC04', 'S2', 4);
insert into modules (name, code, class, unit) values ('MODULENAME957', 'AD26', 'T3', 4);
insert into modules (name, code, class, unit) values ('MODULENAME588', 'AC87', 'L2', 4);
insert into modules (name, code, class, unit) values ('MODULENAME261', 'BD32', 'L2', 1);
insert into modules (name, code, class, unit) values ('MODULENAME294', 'AD60', 'T3', 5);
insert into modules (name, code, class, unit) values ('MODULENAME878', 'AD25', 'S2', 6);
insert into modules (name, code, class, unit) values ('MODULENAME479', 'BC86', 'L2', 2);
insert into modules (name, code, class, unit) values ('MODULENAME374', 'AD93', 'S2', 5);
insert into modules (name, code, class, unit) values ('MODULENAME207', 'BD12', 'T3', 5);
insert into modules (name, code, class, unit) values ('MODULENAME944', 'BC03', 'L3', 1);
insert into modules (name, code, class, unit) values ('MODULENAME760', 'BD88', 'L2', 1);
insert into modules (name, code, class, unit) values ('MODULENAME215', 'BD87', 'L3', 3);
insert into modules (name, code, class, unit) values ('MODULENAME133', 'AC88', 'L2', 5);
insert into modules (name, code, class, unit) values ('MODULENAME409', 'AC65', 'L1', 5);
insert into modules (name, code, class, unit) values ('MODULENAME543', 'AC54', 'T3', 3);
insert into modules (name, code, class, unit) values ('MODULENAME992', 'BC56', 'T1', 3);
insert into modules (name, code, class, unit) values ('MODULENAME477', 'AD56', 'L2', 3);
insert into modules (name, code, class, unit) values ('MODULENAME975', 'BD59', 'L3', 5);
insert into modules (name, code, class, unit) values ('MODULENAME144', 'BD88', 'L3', 6);
insert into modules (name, code, class, unit) values ('MODULENAME865', 'AC47', 'L1', 2);
insert into modules (name, code, class, unit) values ('MODULENAME209', 'BD39', 'T1', 3);
insert into modules (name, code, class, unit) values ('MODULENAME602', 'AC45', 'T2', 6);
insert into modules (name, code, class, unit) values ('MODULENAME519', 'AD51', 'S3', 4);
insert into modules (name, code, class, unit) values ('MODULENAME256', 'BD20', 'L3', 1);
insert into modules (name, code, class, unit) values ('MODULENAME941', 'BD22', 'S3', 3);
insert into modules (name, code, class, unit) values ('MODULENAME216', 'BD89', 'S3', 6);
insert into modules (name, code, class, unit) values ('MODULENAME906', 'AC97', 'S3', 4);
insert into modules (name, code, class, unit) values ('MODULENAME135', 'BD66', 'S2', 6);
insert into modules (name, code, class, unit) values ('MODULENAME747', 'AD85', 'L1', 2);
insert into modules (name, code, class, unit) values ('MODULENAME400', 'BC80', 'S2', 2);
insert into modules (name, code, class, unit) values ('MODULENAME391', 'BD11', 'S3', 3);
insert into modules (name, code, class, unit) values ('MODULENAME896', 'BC86', 'S3', 1);
insert into modules (name, code, class, unit) values ('MODULENAME742', 'BC49', 'S3', 3);
insert into modules (name, code, class, unit) values ('MODULENAME458', 'AC20', 'T3', 2);
insert into modules (name, code, class, unit) values ('MODULENAME134', 'BC03', 'S3', 2);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO modreg(studentid, modulecode, moduleclass)
SELECT s.studentid, m.code, m.class
FROM students s, modules m
ORDER BY random()
LIMIT 1000;

/*At last, */
/*
DROP TABLE modreg;
DROP TABLE modules;
DROP TABLE students;
.quit
*/
