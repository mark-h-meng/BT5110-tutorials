/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for SQLite */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*The first entity set is person and the second entity set is car. The relationship set R is owns. 
In essence the case refers to the person and the car/cars they own in their household.
Each person can own multiple cars and each car can have multiple owners.

The code is written for SQLite.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE persons (
 first_name VARCHAR(64) NOT NULL,
 last_name VARCHAR(64) NOT NULL,
 email VARCHAR(64) UNIQUE NOT NULL,
 id VARCHAR(16) PRIMARY KEY );

CREATE TABLE cars (
 brand VARCHAR(32) NOT NULL,
 model VARCHAR(32) NOT NULL,
 car_registration_number VARCHAR(16) PRIMARY KEY );

CREATE TABLE owns(
 id VARCHAR(16) REFERENCES persons(id),
 car_registration_number VARCHAR(16) REFERENCES cars(car_registration_number) ,
 PRIMARY KEY (id, car_registration_number));
 

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into persons (first_name, last_name, email, id) values ('Florrie', 'Coyett', 'fcoyett0@accuweather.com', 1);
insert into persons (first_name, last_name, email, id) values ('Daniele', 'Bradnum', 'dbradnum1@nba.com', 2);
insert into persons (first_name, last_name, email, id) values ('Calvin', 'Tetsall', 'ctetsall2@tiny.cc', 3);
insert into persons (first_name, last_name, email, id) values ('Frasquito', 'Stockle', 'fstockle3@uol.com.br', 4);
insert into persons (first_name, last_name, email, id) values ('Rosanna', 'Maccrea', 'rmaccrea4@mayoclinic.com', 5);
insert into persons (first_name, last_name, email, id) values ('Shani', 'De Cristofalo', 'sdecristofalo5@bing.com', 6);
insert into persons (first_name, last_name, email, id) values ('Catharina', 'Brownstein', 'cbrownstein6@storify.com', 7);
insert into persons (first_name, last_name, email, id) values ('Adelaida', 'Medforth', 'amedforth7@pbs.org', 8);
insert into persons (first_name, last_name, email, id) values ('Chickie', 'Seadon', 'cseadon8@yellowpages.com', 9);
insert into persons (first_name, last_name, email, id) values ('Clayson', 'Windridge', 'cwindridge9@desdev.cn', 10);
insert into persons (first_name, last_name, email, id) values ('Jacobo', 'Seldner', 'jseldnera@wikimedia.org', 11);
insert into persons (first_name, last_name, email, id) values ('Frederich', 'Slogrove', 'fslogroveb@blinklist.com', 12);
insert into persons (first_name, last_name, email, id) values ('Hubie', 'Antic', 'hanticc@odnoklassniki.ru', 13);
insert into persons (first_name, last_name, email, id) values ('Toby', 'Glentz', 'tglentzd@disqus.com', 14);
insert into persons (first_name, last_name, email, id) values ('Franzen', 'Calderon', 'fcalderone@mac.com', 15);
insert into persons (first_name, last_name, email, id) values ('Reinaldo', 'Meredyth', 'rmeredythf@aboutads.info', 16);
insert into persons (first_name, last_name, email, id) values ('Bryana', 'Pegden', 'bpegdeng@drupal.org', 17);
insert into persons (first_name, last_name, email, id) values ('Giulia', 'Mc Caughen', 'gmccaughenh@opera.com', 18);
insert into persons (first_name, last_name, email, id) values ('Jonathon', 'Moreby', 'jmorebyi@behance.net', 19);
insert into persons (first_name, last_name, email, id) values ('Gates', 'Schellig', 'gschelligj@yandex.ru', 20);
insert into persons (first_name, last_name, email, id) values ('Sibylla', 'Depka', 'sdepkak@umich.edu', 21);
insert into persons (first_name, last_name, email, id) values ('Imogen', 'Ridgeway', 'iridgewayl@scientificamerican.com', 22);
insert into persons (first_name, last_name, email, id) values ('Sella', 'Crucitti', 'scrucittim@free.fr', 23);
insert into persons (first_name, last_name, email, id) values ('Petronella', 'Duffit', 'pduffitn@slideshare.net', 24);
insert into persons (first_name, last_name, email, id) values ('Delmor', 'Murricanes', 'dmurricaneso@addthis.com', 25);
insert into persons (first_name, last_name, email, id) values ('Enrico', 'Candwell', 'ecandwellp@nih.gov', 26);
insert into persons (first_name, last_name, email, id) values ('Mommy', 'Touzey', 'mtouzeyq@csmonitor.com', 27);
insert into persons (first_name, last_name, email, id) values ('Erma', 'McCarl', 'emccarlr@lycos.com', 28);
insert into persons (first_name, last_name, email, id) values ('Neile', 'Pascoe', 'npascoes@google.com.hk', 29);
insert into persons (first_name, last_name, email, id) values ('Merrilee', 'Keasley', 'mkeasleyt@fema.gov', 30);
insert into persons (first_name, last_name, email, id) values ('Timoteo', 'Tomini', 'ttominiu@state.tx.us', 31);
insert into persons (first_name, last_name, email, id) values ('Colin', 'Sprigging', 'cspriggingv@wisc.edu', 32);
insert into persons (first_name, last_name, email, id) values ('Roseann', 'McNae', 'rmcnaew@soundcloud.com', 33);
insert into persons (first_name, last_name, email, id) values ('Kilian', 'Santacrole', 'ksantacrolex@reverbnation.com', 34);
insert into persons (first_name, last_name, email, id) values ('Lyda', 'Goor', 'lgoory@google.fr', 35);
insert into persons (first_name, last_name, email, id) values ('Roxine', 'Nolot', 'rnolotz@opera.com', 36);
insert into persons (first_name, last_name, email, id) values ('Berny', 'Ivashintsov', 'bivashintsov10@51.la', 37);
insert into persons (first_name, last_name, email, id) values ('Thornton', 'Columbine', 'tcolumbine11@edublogs.org', 38);
insert into persons (first_name, last_name, email, id) values ('Gertruda', 'McGeachie', 'gmcgeachie12@dmoz.org', 39);
insert into persons (first_name, last_name, email, id) values ('Jeanna', 'Stronack', 'jstronack13@sphinn.com', 40);
insert into persons (first_name, last_name, email, id) values ('Henderson', 'Penelli', 'hpenelli14@cnbc.com', 41);
insert into persons (first_name, last_name, email, id) values ('Brande', 'Fencott', 'bfencott15@globo.com', 42);
insert into persons (first_name, last_name, email, id) values ('Nert', 'Waistell', 'nwaistell16@google.com', 43);
insert into persons (first_name, last_name, email, id) values ('Gordon', 'Jopling', 'gjopling17@hp.com', 44);
insert into persons (first_name, last_name, email, id) values ('Brittney', 'Yeardsley', 'byeardsley18@technorati.com', 45);
insert into persons (first_name, last_name, email, id) values ('Spike', 'Linnock', 'slinnock19@cbc.ca', 46);
insert into persons (first_name, last_name, email, id) values ('Camila', 'Villalta', 'cvillalta1a@wiley.com', 47);
insert into persons (first_name, last_name, email, id) values ('Wilbur', 'Guyon', 'wguyon1b@loc.gov', 48);
insert into persons (first_name, last_name, email, id) values ('Jeanie', 'Adshead', 'jadshead1c@pbs.org', 49);
insert into persons (first_name, last_name, email, id) values ('Irwin', 'Grinyakin', 'igrinyakin1d@icq.com', 50);
insert into persons (first_name, last_name, email, id) values ('Zeke', 'Tezure', 'ztezure1e@list-manage.com', 51);
insert into persons (first_name, last_name, email, id) values ('Kata', 'Farlham', 'kfarlham1f@acquirethisname.com', 52);
insert into persons (first_name, last_name, email, id) values ('Shalna', 'Trendle', 'strendle1g@plala.or.jp', 53);
insert into persons (first_name, last_name, email, id) values ('Giovanni', 'Nicely', 'gnicely1h@1und1.de', 54);
insert into persons (first_name, last_name, email, id) values ('Blondell', 'Andrzejak', 'bandrzejak1i@admin.ch', 55);
insert into persons (first_name, last_name, email, id) values ('Beverlee', 'Branca', 'bbranca1j@de.vu', 56);
insert into persons (first_name, last_name, email, id) values ('Korie', 'Pendry', 'kpendry1k@si.edu', 57);
insert into persons (first_name, last_name, email, id) values ('Sioux', 'Perez', 'sperez1l@pinterest.com', 58);
insert into persons (first_name, last_name, email, id) values ('Brantley', 'Ernke', 'bernke1m@arstechnica.com', 59);
insert into persons (first_name, last_name, email, id) values ('Wendi', 'Porcas', 'wporcas1n@shinystat.com', 60);
insert into persons (first_name, last_name, email, id) values ('Martainn', 'Ciccottini', 'mciccottini1o@sciencedirect.com', 61);
insert into persons (first_name, last_name, email, id) values ('Allissa', 'Scalera', 'ascalera1p@macromedia.com', 62);
insert into persons (first_name, last_name, email, id) values ('Orsa', 'Gatling', 'ogatling1q@seesaa.net', 63);
insert into persons (first_name, last_name, email, id) values ('Madlen', 'Guenther', 'mguenther1r@opensource.org', 64);
insert into persons (first_name, last_name, email, id) values ('Briano', 'Eilhertsen', 'beilhertsen1s@dedecms.com', 65);
insert into persons (first_name, last_name, email, id) values ('Marquita', 'Capstake', 'mcapstake1t@eepurl.com', 66);
insert into persons (first_name, last_name, email, id) values ('Nanete', 'Kingzeth', 'nkingzeth1u@imgur.com', 67);
insert into persons (first_name, last_name, email, id) values ('Bucky', 'Frisby', 'bfrisby1v@jugem.jp', 68);
insert into persons (first_name, last_name, email, id) values ('Hasty', 'Matuschek', 'hmatuschek1w@apple.com', 69);
insert into persons (first_name, last_name, email, id) values ('Malvina', 'Manders', 'mmanders1x@cafepress.com', 70);
insert into persons (first_name, last_name, email, id) values ('Minne', 'Cowndley', 'mcowndley1y@shutterfly.com', 71);
insert into persons (first_name, last_name, email, id) values ('Crista', 'Bruneton', 'cbruneton1z@bloglovin.com', 72);
insert into persons (first_name, last_name, email, id) values ('Ernest', 'Ellings', 'eellings20@storify.com', 73);
insert into persons (first_name, last_name, email, id) values ('Desirae', 'McGonigle', 'dmcgonigle21@issuu.com', 74);
insert into persons (first_name, last_name, email, id) values ('Krishnah', 'Bridgestock', 'kbridgestock22@cloudflare.com', 75);
insert into persons (first_name, last_name, email, id) values ('Tallou', 'Beavington', 'tbeavington23@mail.ru', 76);
insert into persons (first_name, last_name, email, id) values ('Gwennie', 'Grigoryev', 'ggrigoryev24@cafepress.com', 77);
insert into persons (first_name, last_name, email, id) values ('Elisabetta', 'Czadla', 'eczadla25@topsy.com', 78);
insert into persons (first_name, last_name, email, id) values ('Phillip', 'Antoniades', 'pantoniades26@answers.com', 79);
insert into persons (first_name, last_name, email, id) values ('Matti', 'Di Carli', 'mdicarli27@booking.com', 80);
insert into persons (first_name, last_name, email, id) values ('Pennie', 'Offner', 'poffner28@ycombinator.com', 81);
insert into persons (first_name, last_name, email, id) values ('Juliann', 'Stovin', 'jstovin29@webeden.co.uk', 82);
insert into persons (first_name, last_name, email, id) values ('Michal', 'Kretchmer', 'mkretchmer2a@digg.com', 83);
insert into persons (first_name, last_name, email, id) values ('Man', 'Sumner', 'msumner2b@pinterest.com', 84);
insert into persons (first_name, last_name, email, id) values ('Patricio', 'Bennedsen', 'pbennedsen2c@ucoz.com', 85);
insert into persons (first_name, last_name, email, id) values ('Hilton', 'Cawsby', 'hcawsby2d@ebay.co.uk', 86);
insert into persons (first_name, last_name, email, id) values ('Rudd', 'Bunkle', 'rbunkle2e@ocn.ne.jp', 87);
insert into persons (first_name, last_name, email, id) values ('Mavra', 'Perago', 'mperago2f@jigsy.com', 88);
insert into persons (first_name, last_name, email, id) values ('Gaylord', 'Rieflin', 'grieflin2g@discovery.com', 89);
insert into persons (first_name, last_name, email, id) values ('Raina', 'Kinch', 'rkinch2h@japanpost.jp', 90);
insert into persons (first_name, last_name, email, id) values ('Kingsley', 'Burnett', 'kburnett2i@etsy.com', 91);
insert into persons (first_name, last_name, email, id) values ('Corene', 'Melburg', 'cmelburg2j@nih.gov', 92);
insert into persons (first_name, last_name, email, id) values ('Fowler', 'Jankovic', 'fjankovic2k@disqus.com', 93);
insert into persons (first_name, last_name, email, id) values ('Renell', 'Arni', 'rarni2l@uol.com.br', 94);
insert into persons (first_name, last_name, email, id) values ('Obie', 'Schultheiss', 'oschultheiss2m@yale.edu', 95);
insert into persons (first_name, last_name, email, id) values ('Mildrid', 'Flegg', 'mflegg2n@woothemes.com', 96);
insert into persons (first_name, last_name, email, id) values ('Orbadiah', 'Wafer', 'owafer2o@miitbeian.gov.cn', 97);
insert into persons (first_name, last_name, email, id) values ('Fawne', 'Normadell', 'fnormadell2p@usa.gov', 98);
insert into persons (first_name, last_name, email, id) values ('Grethel', 'Fabbri', 'gfabbri2q@bloomberg.com', 99);
insert into persons (first_name, last_name, email, id) values ('Jereme', 'Reiner', 'jreiner2r@mtv.com', 100);

insert into cars (brand, model, car_registration_number) values ('GMC', 'Sonoma Club Coupe', 'UGE0828V');
insert into cars (brand, model, car_registration_number) values ('Jaguar', 'XK', 'ZAR7767D');
insert into cars (brand, model, car_registration_number) values ('Suzuki', 'SJ', 'ZJU1366X');
insert into cars (brand, model, car_registration_number) values ('Mazda', '323', 'ZCM9541G');
insert into cars (brand, model, car_registration_number) values ('Suzuki', 'Kizashi', 'XWC0690H');
insert into cars (brand, model, car_registration_number) values ('Isuzu', 'Trooper', 'WOH3789L');
insert into cars (brand, model, car_registration_number) values ('BMW', '530', 'BZG6804O');
insert into cars (brand, model, car_registration_number) values ('Chevrolet', 'Caprice Classic', 'KBH5914P');
insert into cars (brand, model, car_registration_number) values ('Lincoln', 'Continental', 'TNC3839I');
insert into cars (brand, model, car_registration_number) values ('Pontiac', 'G5', 'BJP2393H');
insert into cars (brand, model, car_registration_number) values ('Dodge', 'Viper', 'LZC8974U');
insert into cars (brand, model, car_registration_number) values ('Suzuki', 'Reno', 'CQP4443G');
insert into cars (brand, model, car_registration_number) values ('Dodge', 'Omni', 'AQL9818B');
insert into cars (brand, model, car_registration_number) values ('Ford', 'Thunderbird', 'PWJ9872V');
insert into cars (brand, model, car_registration_number) values ('GMC', 'Envoy', 'WAB6386W');
insert into cars (brand, model, car_registration_number) values ('Mercury', 'Mystique', 'FGD2286G');
insert into cars (brand, model, car_registration_number) values ('Aston Martin', 'Vantage', 'AIQ9723N');
insert into cars (brand, model, car_registration_number) values ('Bentley', 'Continental Flying Spur', 'SDZ6705D');
insert into cars (brand, model, car_registration_number) values ('Saturn', 'VUE', 'TXA3685J');
insert into cars (brand, model, car_registration_number) values ('Volvo', '850', 'LHJ7331D');
insert into cars (brand, model, car_registration_number) values ('Chevrolet', 'Tahoe', 'HQO7502K');
insert into cars (brand, model, car_registration_number) values ('Acura', 'Integra', 'YWV9660G');
insert into cars (brand, model, car_registration_number) values ('Maserati', 'Gran Sport', 'PNT6086Y');
insert into cars (brand, model, car_registration_number) values ('Ford', 'Bronco', 'CEI2825I');
insert into cars (brand, model, car_registration_number) values ('Honda', 'Insight', 'UFC3310A');
insert into cars (brand, model, car_registration_number) values ('Buick', 'Park Avenue', 'PEI0701H');
insert into cars (brand, model, car_registration_number) values ('GMC', '3500', 'WAK3058G');
insert into cars (brand, model, car_registration_number) values ('Cadillac', 'Seville', 'FAE8305E');
insert into cars (brand, model, car_registration_number) values ('Chrysler', 'New Yorker', 'TYE0928N');
insert into cars (brand, model, car_registration_number) values ('GMC', 'Rally Wagon 3500', 'DJX7858R');
insert into cars (brand, model, car_registration_number) values ('Volkswagen', 'New Beetle', 'IOJ9287N');
insert into cars (brand, model, car_registration_number) values ('Chrysler', 'PT Cruiser', 'ZKB3418I');
insert into cars (brand, model, car_registration_number) values ('GMC', 'Yukon XL 2500', 'RAL8699X');
insert into cars (brand, model, car_registration_number) values ('Lexus', 'LX', 'MHK8668H');
insert into cars (brand, model, car_registration_number) values ('Honda', 'S2000', 'RXC3058S');
insert into cars (brand, model, car_registration_number) values ('Volkswagen', 'Fox', 'KTN3178O');
insert into cars (brand, model, car_registration_number) values ('Buick', 'Somerset', 'ESW9557S');
insert into cars (brand, model, car_registration_number) values ('Suzuki', 'SJ', 'ERP0305G');
insert into cars (brand, model, car_registration_number) values ('Kia', 'Spectra', 'LBQ5218Z');
insert into cars (brand, model, car_registration_number) values ('Buick', 'LeSabre', 'CDO0884D');
insert into cars (brand, model, car_registration_number) values ('Toyota', 'Previa', 'STX1572S');
insert into cars (brand, model, car_registration_number) values ('Nissan', 'Frontier', 'KDM5667Z');
insert into cars (brand, model, car_registration_number) values ('BMW', 'Z8', 'COD4125Y');
insert into cars (brand, model, car_registration_number) values ('Pontiac', 'Sunbird', 'IBX1637M');
insert into cars (brand, model, car_registration_number) values ('Ferrari', '458 Italia', 'YEU9833S');
insert into cars (brand, model, car_registration_number) values ('Nissan', 'Quest', 'RDL1017A');
insert into cars (brand, model, car_registration_number) values ('Volkswagen', 'GTI', 'QIV5068D');
insert into cars (brand, model, car_registration_number) values ('Chevrolet', 'Avalanche', 'FMP8496J');
insert into cars (brand, model, car_registration_number) values ('Pontiac', 'G3', 'YDV1393P');
insert into cars (brand, model, car_registration_number) values ('Buick', 'Regal', 'XOD4876T');
insert into cars (brand, model, car_registration_number) values ('Chevrolet', 'Tahoe', 'VAB2524Q');
insert into cars (brand, model, car_registration_number) values ('Chevrolet', 'TrailBlazer', 'TFM4014Y');
insert into cars (brand, model, car_registration_number) values ('Dodge', 'Ram 1500', 'RRQ0900W');
insert into cars (brand, model, car_registration_number) values ('Toyota', 'Sienna', 'CMN6613L');
insert into cars (brand, model, car_registration_number) values ('Dodge', 'Dakota', 'WDT4055Z');
insert into cars (brand, model, car_registration_number) values ('Mitsubishi', 'Eclipse', 'LXV7783Z');
insert into cars (brand, model, car_registration_number) values ('Toyota', 'Solara', 'EHE9298F');
insert into cars (brand, model, car_registration_number) values ('Volkswagen', 'Eurovan', 'JVK9615E');
insert into cars (brand, model, car_registration_number) values ('Nissan', 'Leaf', 'KZJ9195H');
insert into cars (brand, model, car_registration_number) values ('Mitsubishi', 'Lancer Evolution', 'HPV6333A');
insert into cars (brand, model, car_registration_number) values ('Oldsmobile', 'Achieva', 'MEL0953F');
insert into cars (brand, model, car_registration_number) values ('Porsche', '911', 'XQU8776H');
insert into cars (brand, model, car_registration_number) values ('Hummer', 'H1', 'ZOA0698D');
insert into cars (brand, model, car_registration_number) values ('Dodge', 'Ram Van 3500', 'JEK2887G');
insert into cars (brand, model, car_registration_number) values ('Mazda', 'MPV', 'BGB5484X');
insert into cars (brand, model, car_registration_number) values ('Buick', 'Park Avenue', 'ZDW0688H');
insert into cars (brand, model, car_registration_number) values ('Volkswagen', 'Eurovan', 'YJT1477U');
insert into cars (brand, model, car_registration_number) values ('Cadillac', 'CTS-V', 'XZW3612I');
insert into cars (brand, model, car_registration_number) values ('Jaguar', 'X-Type', 'OGF0549S');
insert into cars (brand, model, car_registration_number) values ('Saturn', 'S-Series', 'YDK3059H');
insert into cars (brand, model, car_registration_number) values ('Jaguar', 'XJ', 'IWR2614Z');
insert into cars (brand, model, car_registration_number) values ('Porsche', '928', 'DCY9852T');
insert into cars (brand, model, car_registration_number) values ('Mercury', 'Grand Marquis', 'PEW3309T');
insert into cars (brand, model, car_registration_number) values ('Honda', 'S2000', 'AFG8740F');
insert into cars (brand, model, car_registration_number) values ('Chevrolet', 'Corvette', 'WHE5731L');
insert into cars (brand, model, car_registration_number) values ('Ford', 'Escape', 'WBC0408R');
insert into cars (brand, model, car_registration_number) values ('Maybach', '62', 'OPS6952Y');
insert into cars (brand, model, car_registration_number) values ('Lexus', 'SC', 'ZOR8409V');
insert into cars (brand, model, car_registration_number) values ('Dodge', 'Ram Van 1500', 'KGZ1665U');
insert into cars (brand, model, car_registration_number) values ('Chevrolet', 'G-Series G30', 'ZCX4340G');
insert into cars (brand, model, car_registration_number) values ('Dodge', 'Caliber', 'RXH7720M');
insert into cars (brand, model, car_registration_number) values ('Volkswagen', 'Jetta', 'TYL0993M');
insert into cars (brand, model, car_registration_number) values ('Mitsubishi', 'Lancer Evolution', 'GGW1933W');
insert into cars (brand, model, car_registration_number) values ('Mitsubishi', 'Mirage', 'KSU1875A');
insert into cars (brand, model, car_registration_number) values ('Lotus', 'Esprit', 'UUZ1664O');
insert into cars (brand, model, car_registration_number) values ('Mercury', 'Cougar', 'FNZ5026S');
insert into cars (brand, model, car_registration_number) values ('Audi', '90', 'YTQ4593L');
insert into cars (brand, model, car_registration_number) values ('Mercedes-Benz', 'SLK55 AMG', 'OYL5008E');
insert into cars (brand, model, car_registration_number) values ('Cadillac', 'Escalade ESV', 'CQD2316S');
insert into cars (brand, model, car_registration_number) values ('Ford', 'Explorer', 'JSO7667C');
insert into cars (brand, model, car_registration_number) values ('Saab', '9-5', 'MAS4989S');
insert into cars (brand, model, car_registration_number) values ('Chevrolet', 'Silverado 3500', 'SOA6591R');
insert into cars (brand, model, car_registration_number) values ('Nissan', 'Sentra', 'HEB2217T');
insert into cars (brand, model, car_registration_number) values ('Dodge', 'Ram', 'IRB3397C');
insert into cars (brand, model, car_registration_number) values ('Mercury', 'Mystique', 'SJQ5455Y');
insert into cars (brand, model, car_registration_number) values ('Isuzu', 'Rodeo', 'TLQ4726A');
insert into cars (brand, model, car_registration_number) values ('Mazda', 'RX-7', 'TSY6868N');
insert into cars (brand, model, car_registration_number) values ('Mercedes-Benz', 'C-Class', 'PZM3230U');
insert into cars (brand, model, car_registration_number) values ('Mercury', 'Grand Marquis', 'VJQ8729T');
insert into cars (brand, model, car_registration_number) values ('BMW', 'M5', 'AVQ9276J');





/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


INSERT INTO owns (id , car_registration_number) 
SELECT persons.id, cars.car_registration_number
FROM persons cross join cars
ORDER BY random()
LIMIT 1000;