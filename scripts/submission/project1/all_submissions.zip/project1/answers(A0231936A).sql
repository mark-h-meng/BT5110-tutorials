/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */

/* I would make entity set E1 to be "students," a list of NUS           */
/* students' student id, first name, last name, gender, and email.      */
/* The primary key of "students" table would be student_id.             */
/* Entity set E2 could be "vaccines," a list of vaccines' name,         */
/* developer, and number of doses required. The primary key would be the*/
/* combination of vaccine name and developer.                           */
/* Relationship set R could be "vaccination_choices," which links NUS   */
/* students' IDs to the WTO certified vaccines' names and developers,   */
/* giving the choices of vaccines that each NUS student have.           */
/* The 'vaccination records' table contains student id (referencing     */
/* "students" table), vaccine name, and developer (vaccine name and     */
/* developer as the foreign key referencing "vaccines" table's          */
/* primary key). The primary key for vaccination records table is the   */
/* composite of student id, vaccine name and developer.                 */
/* The code in the following questions is written for PostgreSQL.       */

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DROP TABLE students CASCADE;
DROP TABLE vaccines CASCADE;
DROP TABLE IF EXISTS vaccination_choices;

CREATE TABLE students(
	student_id VARCHAR(16) PRIMARY KEY,
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	gender VARCHAR(64),
	email VARCHAR(64) UNIQUE
	);

CREATE TABLE vaccines(
	vaccine_name VARCHAR(500),
	developer VARCHAR(500),
	number_of_doses NUMERIC CHECK (number_of_doses > 0 AND number_of_doses < 4),
	PRIMARY KEY(vaccine_name, developer)
	);

CREATE TABLE vaccination_choices(
	student_id VARCHAR(16) REFERENCES students(student_id),
	vaccine_name VARCHAR(500),
	developer VARCHAR(500),
	FOREIGN KEY (vaccine_name, developer) REFERENCES vaccines(vaccine_name, developer)
		ON UPDATE CASCADE ON DELETE CASCADE,
	PRIMARY KEY (student_id, vaccine_name, developer)
	);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DROP TABLE students CASCADE;
DROP TABLE vaccines CASCADE;
DROP TABLE IF EXISTS vaccination_choices;

CREATE TABLE students(
	student_id VARCHAR(16) PRIMARY KEY,
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	gender VARCHAR(64),
	email VARCHAR(64) UNIQUE
	);

INSERT INTO students VALUES('1','Carter','Nicolas','Male','Carter_Nicolas5493@fuliss.net');
INSERT INTO students VALUES('2','Belinda','Reese','Female','Belinda_Reese7329@womeona.net');
INSERT INTO students VALUES('3','Melanie','Sloan','Female','Melanie_Sloan1425@zorer.org');
INSERT INTO students VALUES('4','Juliet','Paterson','Female','Juliet_Paterson3728@sveldo.biz');
INSERT INTO students VALUES('5','Johnathan','Jeffery','Male','Johnathan_Jeffery2214@deons.tech');
INSERT INTO students VALUES('6','Jacob','Steer','Male','Jacob_Steer7902@guentu.biz');
INSERT INTO students VALUES('7','Julian','Lynn','Male','Julian_Lynn7633@famism.biz');
INSERT INTO students VALUES('8','Josephine','Kerr','Female','Josephine_Kerr4662@zorer.org');
INSERT INTO students VALUES('9','Moira','Hopkins','Female','Moira_Hopkins2969@joiniaa.com');
INSERT INTO students VALUES('10','Chuck','Hopkins','Male','Chuck_Hopkins5149@qater.org');
INSERT INTO students VALUES('11','Emma','Hancock','Female','Emma_Hancock2848@gmail.com');
INSERT INTO students VALUES('12','Claire','Brett','Female','Claire_Brett6033@joiniaa.com');
INSERT INTO students VALUES('13','Domenic','Coleman','Male','Domenic_Coleman2597@deons.tech');
INSERT INTO students VALUES('14','Martin','Tennant','Male','Martin_Tennant2106@nanoff.biz');
INSERT INTO students VALUES('15','Christine','Webster','Female','Christine_Webster905@hourpy.biz');
INSERT INTO students VALUES('16','Brad','Mullins','Male','Brad_Mullins2068@hourpy.biz');
INSERT INTO students VALUES('17','Nicholas','Robe','Male','Nicholas_Robe8922@extex.org');
INSERT INTO students VALUES('18','Cedrick','Thomas','Male','Cedrick_Thomas4186@bulaffy.com');
INSERT INTO students VALUES('19','Elly','Hunter','Female','Elly_Hunter7203@guentu.biz');
INSERT INTO students VALUES('20','Chloe','Sherwood','Female','Chloe_Sherwood1160@guentu.biz');
INSERT INTO students VALUES('21','Matthew','Warner','Male','Matthew_Warner6167@ubusive.com');
INSERT INTO students VALUES('22','Bree','Logan','Female','Bree_Logan1816@ovock.tech');
INSERT INTO students VALUES('23','Boris','Wallace','Male','Boris_Wallace9238@ubusive.com');
INSERT INTO students VALUES('24','Domenic','Cassidy','Male','Domenic_Cassidy3742@jiman.org');
INSERT INTO students VALUES('25','Hayden','Simpson','Male','Hayden_Simpson9499@mafthy.com');
INSERT INTO students VALUES('26','Ronald','Larsen','Male','Ronald_Larsen2222@atink.com');
INSERT INTO students VALUES('27','Cameron','Wright','Female','Cameron_Wright9409@grannar.com');
INSERT INTO students VALUES('28','Ally','Lee','Female','Ally_Lee3767@extex.org');
INSERT INTO students VALUES('29','Paige','Bayliss','Female','Paige_Bayliss7327@brety.org');
INSERT INTO students VALUES('30','Livia','Judd','Female','Livia_Judd1171@bauros.biz');
INSERT INTO students VALUES('31','Hayden','Callan','Male','Hayden_Callan1270@tonsy.org');
INSERT INTO students VALUES('32','Ellen','Allen','Female','Ellen_Allen6553@ubusive.com');
INSERT INTO students VALUES('33','Logan','Brown','Male','Logan_Brown4499@bretoux.com');
INSERT INTO students VALUES('34','Erin','Edwards','Female','Erin_Edwards1930@gompie.com');
INSERT INTO students VALUES('35','Boris','Ainsworth','Male','Boris_Ainsworth1992@sveldo.biz');
INSERT INTO students VALUES('36','Elise','Patel','Female','Elise_Patel3319@dionrab.com');
INSERT INTO students VALUES('37','Kendra','Sawyer','Female','Kendra_Sawyer88@supunk.biz');
INSERT INTO students VALUES('38','Adeline','Oliver','Female','Adeline_Oliver3463@atink.com');
INSERT INTO students VALUES('39','Audrey','Paterson','Female','Audrey_Paterson4871@sheye.org');
INSERT INTO students VALUES('40','Wade','Trent','Male','Wade_Trent7106@supunk.biz');
INSERT INTO students VALUES('41','Parker','Hall','Female','Parker_Hall8195@tonsy.org');
INSERT INTO students VALUES('42','Amelia','Oldfield','Female','Amelia_Oldfield8224@ubusive.com');
INSERT INTO students VALUES('43','Shay','White','Female','Shay_White831@muall.tech');
INSERT INTO students VALUES('44','Clint','Martin','Male','Clint_Martin1929@brety.org');
INSERT INTO students VALUES('45','Olivia','Saunders','Female','Olivia_Saunders2555@sveldo.biz');
INSERT INTO students VALUES('46','Brad','Andrews','Male','Brad_Andrews5428@brety.org');
INSERT INTO students VALUES('47','Henry','Thompson','Male','Henry_Thompson5389@hourpy.biz');
INSERT INTO students VALUES('48','Noah','Funnell','Male','Noah_Funnell6921@bretoux.com');
INSERT INTO students VALUES('49','Shay','Armstrong','Female','Shay_Armstrong4889@tonsy.org');
INSERT INTO students VALUES('50','Hayden','Coleman','Female','Hayden_Coleman9654@sveldo.biz');
INSERT INTO students VALUES('51','Kendra','Marshall','Female','Kendra_Marshall9723@grannar.com');
INSERT INTO students VALUES('52','Clarissa','Noon','Female','Clarissa_Noon4673@fuliss.net');
INSERT INTO students VALUES('53','Johnny','Mackenzie','Male','Johnny_Mackenzie2334@twipet.com');
INSERT INTO students VALUES('54','Savannah','Utterson','Female','Savannah_Utterson2859@dionrab.com');
INSERT INTO students VALUES('55','Mina','Stone','Female','Mina_Stone5325@bauros.biz');
INSERT INTO students VALUES('56','Carrie','Wright','Female','Carrie_Wright3336@joiniaa.com');
INSERT INTO students VALUES('57','Boris','Kelly','Male','Boris_Kelly4177@zorer.org');
INSERT INTO students VALUES('58','Logan','Hunter','Female','Logan_Hunter1032@nanoff.biz');
INSERT INTO students VALUES('59','Chad','Radley','Male','Chad_Radley9843@zorer.org');
INSERT INTO students VALUES('60','Caleb','Whatson','Male','Caleb_Whatson1925@mafthy.com');
INSERT INTO students VALUES('61','Danny','Smith','Male','Danny_Smith9797@bulaffy.com');
INSERT INTO students VALUES('62','Daron','Roberts','Male','Daron_Roberts161@corti.com');
INSERT INTO students VALUES('63','Chuck','Stewart','Male','Chuck_Stewart9982@irrepsy.com');
INSERT INTO students VALUES('64','Rocco','Adams','Male','Rocco_Adams9892@deons.tech');
INSERT INTO students VALUES('65','Susan','Cooper','Female','Susan_Cooper5311@typill.biz');
INSERT INTO students VALUES('66','Denny','Amstead','Male','Denny_Amstead3106@deavo.com');
INSERT INTO students VALUES('67','Kurt','Booth','Male','Kurt_Booth2293@naiker.biz');
INSERT INTO students VALUES('68','Mason','Mcleod','Male','Mason_Mcleod4397@fuliss.net');
INSERT INTO students VALUES('69','Jolene','Walsh','Female','Jolene_Walsh8239@gmail.com');
INSERT INTO students VALUES('70','Javier','Bailey','Male','Javier_Bailey6882@atink.com');
INSERT INTO students VALUES('71','Mason','Larkin','Male','Mason_Larkin9716@muall.tech');
INSERT INTO students VALUES('72','Ember','Aldridge','Female','Ember_Aldridge5859@gembat.biz');
INSERT INTO students VALUES('73','Renee','Higgs','Female','Renee_Higgs4471@ubusive.com');
INSERT INTO students VALUES('74','Rachael','Ashwell','Female','Rachael_Ashwell642@mafthy.com');
INSERT INTO students VALUES('75','Barry','Summers','Male','Barry_Summers111@atink.com');
INSERT INTO students VALUES('76','Summer','Barrett','Female','Summer_Barrett4883@gompie.com');
INSERT INTO students VALUES('77','Ramon','Harrison','Male','Ramon_Harrison1104@joiniaa.com');
INSERT INTO students VALUES('78','Elijah','Devonport','Male','Elijah_Devonport7303@jiman.org');
INSERT INTO students VALUES('79','Ema','Maxwell','Female','Ema_Maxwell5493@grannar.com');
INSERT INTO students VALUES('80','Angelina','Evans','Female','Angelina_Evans9040@bauros.biz');
INSERT INTO students VALUES('81','Enoch','Bennett','Male','Enoch_Bennett9801@liret.org');
INSERT INTO students VALUES('82','Melania','Duvall','Female','Melania_Duvall4473@irrepsy.com');
INSERT INTO students VALUES('83','Josh','Chadwick','Male','Josh_Chadwick2296@qater.org');
INSERT INTO students VALUES('84','Davina','Vaughan','Female','Davina_Vaughan4070@nanoff.biz');
INSERT INTO students VALUES('85','Andrea','Shaw','Female','Andrea_Shaw9384@bauros.biz');
INSERT INTO students VALUES('86','Juliet','Pierce','Female','Juliet_Pierce6429@ubusive.com');
INSERT INTO students VALUES('87','Skylar','Bullock','Female','Skylar_Bullock2222@naiker.biz');
INSERT INTO students VALUES('88','Dakota','Bentley','Female','Dakota_Bentley7695@nickia.com');
INSERT INTO students VALUES('89','Mavis','Addison','Female','Mavis_Addison9191@ovock.tech');
INSERT INTO students VALUES('90','Manuel','Fields','Male','Manuel_Fields1067@supunk.biz');
INSERT INTO students VALUES('91','Jazmin','Grant','Female','Jazmin_Grant578@mafthy.com');
INSERT INTO students VALUES('92','Julius','Collis','Male','Julius_Collis5836@joiniaa.com');
INSERT INTO students VALUES('93','Rachael','Selby','Female','Rachael_Selby769@nickia.com');
INSERT INTO students VALUES('94','Javier','Sloan','Male','Javier_Sloan161@nanoff.biz');
INSERT INTO students VALUES('95','Alan','Archer','Male', 'Alan_Archer6801@naiker.biz');
INSERT INTO students VALUES('96','Adeline','Notman','Female','Adeline_Notman7101@nickia.com');
INSERT INTO students VALUES('97','Hayden','Phillips','Male','Hayden_Phillips8669@deons.tech');
INSERT INTO students VALUES('98','Ema','Mason','Female','Ema_Mason1046@naiker.biz');
INSERT INTO students VALUES('99','Benny','Fowler','Male','Benny_Fowler929@ovock.tech');
INSERT INTO students VALUES('100','Jessica','Buckley','Female','Jessica_Buckley1071@hourpy.biz');

CREATE TABLE vaccines(
	vaccine_name VARCHAR(500),
	developer VARCHAR(500),
	number_of_doses NUMERIC CHECK (number_of_doses > 0 AND number_of_doses < 4),
	PRIMARY KEY(vaccine_name, developer)
	);

INSERT INTO vaccines VALUES('CoronaVac;  inactivated SARS-CoV-2 vaccine (vero cell)','Sinovac Research and Development Co., Ltd','2');
INSERT INTO vaccines VALUES('Inactivated SARS-CoV-2 vaccine (Vero cell)','Sinopharm + China National Biotec Group Co + Wuhan Institute of Biological Products ','2');
INSERT INTO vaccines VALUES('Inactivated SARS-CoV-2 vaccine (Vero cell), vaccine name BBIBP-CorV','Sinopharm  + China National Biotec Group Co + Beijing Institute of Biological Products','2');
INSERT INTO vaccines VALUES('ChAdOx1-S - (AZD1222)','AstraZeneca + University of Oxford','2');
INSERT INTO vaccines VALUES('Recombinant novel coronavirus vaccine (Adenovirus type 5 vector)','CanSino Biological Inc./Beijing Institute of Biotechnology','1');
INSERT INTO vaccines VALUES('Gam-COVID-Vac  Adeno-based (rAd26-S+rAd5-S)','Gamaleya Research Institute ; Health Ministry of the Russian Federation','2');
INSERT INTO vaccines VALUES('Ad26.COV2.S','Janssen Pharmaceutical Johnson&Johnson','2');
INSERT INTO vaccines VALUES('SARS-CoV-2 rS/Matrix M1-Adjuvant (Full length recombinant SARS CoV-2 glycoprotein nanoparticle vaccine adjuvanted with Matrix M)NVX-CoV2373','Novavax','2');
INSERT INTO vaccines VALUES('mRNA-1273','Moderna + National Institute of Allergy and Infectious Diseases (NIAID)','2');
INSERT INTO vaccines VALUES('BNT162b2 (3 LNP-mRNAs ), also known as "Comirnaty"',' Pfizer/BioNTech  + Fosun Pharma ','2');
INSERT INTO vaccines VALUES('Recombinant SARS-CoV-2 vaccine (CHO Cell) ','Anhui Zhifei Longcom Biopharmaceutical + Institute of Microbiology, Chinese Academy of Sciences','3');
INSERT INTO vaccines VALUES('CVnCoV Vaccine','CureVac AG','2');
INSERT INTO vaccines VALUES('SARS-CoV-2 vaccine (vero cells)','Institute of Medical Biology + Chinese Academy of Medical Sciences','2');
INSERT INTO vaccines VALUES('QazCovid-in® - COVID-19 inactivated vaccine','Research Institute for Biological Safety Problems, Rep of Kazakhstan','2');
INSERT INTO vaccines VALUES('INO-4800+electroporation ','Inovio Pharmaceuticals + International Vaccine Institute + Advaccine (Suzhou) Biopharmaceutical Co., Ltd ','2');
INSERT INTO vaccines VALUES('AG0301-COVID19','AnGes + Takara Bio + Osaka University','2');
INSERT INTO vaccines VALUES('nCov vaccine','Zydus Cadila','3');
INSERT INTO vaccines VALUES('GX-19N','Genexine Consortium','2');
INSERT INTO vaccines VALUES('Whole-Virion Inactivated SARS-CoV-2 Vaccine (BBV152); Covaxin','Bharat Biotech International Limited','2');
INSERT INTO vaccines VALUES('KBP-COVID-19 (RBD-based)','Kentucky Bioprocessing Inc.','2');
INSERT INTO vaccines VALUES('VAT00002:   SARS-CoV-2 S protein with adjuvant ','Sanofi Pasteur + GSK','2');
INSERT INTO vaccines VALUES('ARCT-021 ','Arcturus Therapeutics ',NULL);
INSERT INTO vaccines VALUES('RBD SARS-CoV-2 HBsAg VLP vaccine','Serum Institute of India + Accelagen Pty + SpyBiotech','2');
INSERT INTO vaccines VALUES('Inactivated SARS-CoV-2 vaccine (Vero cell) ','Shenzhen Kangtai Biological Products Co., Ltd. ','2');
INSERT INTO vaccines VALUES(' GRAd-COV2 (Replication defective Simian Adenovirus (GRAd) encoding S)','ReiThera + Leukocare + Univercells','1');
INSERT INTO vaccines VALUES(' VXA-CoV2-1 Ad5 adjuvanted Oral Vaccine platform','Vaxart','2');
INSERT INTO vaccines VALUES('MVA-SARS-2-S','University of Munich (Ludwig-Maximilians)','2');
INSERT INTO vaccines VALUES('SCB-2019 + AS03 or CpG 1018 adjuvant plus Alum adjuvant  (Trimeric subunit Spike Protein vaccine)  ','Clover Biopharmaceuticals Inc./GSK/Dynavax','2');
INSERT INTO vaccines VALUES('COVAX-19® Recombinant spike protein + adjuvant','Vaxine Pty Ltd./CinnaGen Co.','1');
INSERT INTO vaccines VALUES('MVC-COV1901 (Spike-2P protein + adjuvant CpG 1018)','Medigen Vaccine Biologics + Dynavax + National Institute of Allergy and Infectious Diseases (NIAID)','2');
INSERT INTO vaccines VALUES('FINLAY-FR1 anti-SARS-CoV-2 Vaccine (RBD + adjuvant)','Instituto Finlay de Vacunas ','2');
INSERT INTO vaccines VALUES(' FINLAY-FR-2 anti-SARS-CoV-2 Vaccine (RBD chemically conjugated to tetanus toxoid plus adjuvant)','Instituto Finlay de Vacunas','2');
INSERT INTO vaccines VALUES('EpiVacCorona (EpiVacCorona vaccine based on peptide antigens for the prevention of COVID-19)','Federal Budgetary Research Institution State Research Center of Virology and Biotechnology "Vector"','2');
INSERT INTO vaccines VALUES('RBD (baculovirus production expressed in Sf9 cells)  Recombinant SARS-CoV-2 vaccine (Sf9 Cell) ','West China Hospital + Sichuan University','2');
INSERT INTO vaccines VALUES('IMP CoVac-1 (SARS-CoV-2 HLA-DR peptides)','University Hospital Tuebingen','1');
INSERT INTO vaccines VALUES('UB-612 (Multitope peptide based S1-RBD-protein based vaccine)','Vaxxinity','2');
INSERT INTO vaccines VALUES('DelNS1-2019-nCoV-RBD-OPT1 (Intranasal flu-based-RBD )','University of Hong Kong, Xiamen University and Beijing Wantai Biological Pharmacy','2');
INSERT INTO vaccines VALUES('LNP-nCoVsaRNA','Imperial College London','2');
INSERT INTO vaccines VALUES('SARS-CoV-2 mRNA vaccine (ARCoV)','Academy of Military Science (AMS), Walvax Biotechnology and Suzhou Abogen Biosciences','2');
INSERT INTO vaccines VALUES(' Coronavirus-Like Particle COVID-19 (CoVLP)','Medicago Inc.','2');
INSERT INTO vaccines VALUES('Covid-19/aAPC vaccine.   The Covid-19/aAPC vaccine is prepared by applying lentivirus modification with immune modulatory genes and the viral minigenes to the artificial antigen presenting cells (aAPCs).','	Shenzhen Geno-Immune Medical Institute ','3');
INSERT INTO vaccines VALUES('LV-SMENP-DC vaccine.   Dendritic cells are modified with lentivirus vectors expressing Covid-19 minigene SMENP and immune modulatory genes. CTLs are activated by LV-DC presenting Covid-19 specific antigens.','Shenzhen Geno-Immune Medical Institute ','1');
INSERT INTO vaccines VALUES('AdimrSC-2f (recombinant RBD +/- Aluminium)','Adimmune Corporation ',NULL);
INSERT INTO vaccines VALUES('Covigenix VAX-001 - DNA vaccines + proteo-lipid vehicle (PLV) formulation','Entos Pharmaceuticals Inc. ','2');
INSERT INTO vaccines VALUES('CORVax - Spike (S) Protein Plasmid DNA Vaccine ','Providence Health & Services','2');
INSERT INTO vaccines VALUES('ChulaCov19 mRNA vaccine','Chulalongkorn University','2');
INSERT INTO vaccines VALUES('bacTRL-Spike oral DNA vaccine','Symvivo Corporation','1');
INSERT INTO vaccines VALUES('Human Adenovirus Type 5: hAd5 S+N bivalent vaccine (S-Fusion + N-ETSD). E2b- Deleted Adeno.','ImmunityBio, Inc','2');
INSERT INTO vaccines VALUES('COH04S1 (MVA-SARS-2-S) - Modified vaccinia ankara (sMVA) platform + synthetic SARS-CoV-2','City of Hope Medical Center + National Cancer Institute','2');
INSERT INTO vaccines VALUES('rVSV-SARS-CoV-2-S Vaccine (IIBR-100)','Israel Institute for Biological Research ','1');
INSERT INTO vaccines VALUES('Dendritic cell vaccine AV-COVID-19.  A vaccine consisting of autologous dendritic cells loaded with antigens from SARS-CoV-2, with or without GM-CSF','Aivita Biomedical, Inc. National Institute of Health Research and Development, Ministry of Health Republic of Indonesia','1');
INSERT INTO vaccines VALUES('COVI-VAC','Codagenix/Serum Institute of India','2');
INSERT INTO vaccines VALUES('CIGB-669 (RBD+AgnHB)','Center for Genetic Engineering and Biotechnology (CIGB) ',3);
INSERT INTO vaccines VALUES('CIGB-66 (RBD+aluminium hydroxide)  ','Center for Genetic Engineering and Biotechnology (CIGB) ',3);
INSERT INTO vaccines VALUES('VLA2001','Valneva, National Institute for Health Research, United Kingdom',2);
INSERT INTO vaccines VALUES('BECOV2','Biological E. Limited ',2);
INSERT INTO vaccines VALUES('AdCLD-CoV19 (adenovirus vector) ','Cellid Co., Ltd.',1);
INSERT INTO vaccines VALUES('GLS-5310','GeneOne Life Science, Inc.',2);
INSERT INTO vaccines VALUES('Recombinant Sars-CoV-2 Spike protein, Aluminum adjuvanted (Nanocovax)','Nanogen Pharmaceutical Biotechnology',2);
INSERT INTO vaccines VALUES('Recombinant protein vaccine S-268019 (using Baculovirus expression vector system)','Shionogi',2);
INSERT INTO vaccines VALUES('SARS-CoV-2-RBD-Fc fusion protein','University Medical Center Groningen + Akston Biosciences Inc.',2);
INSERT INTO vaccines VALUES('ERUCOV-VAC, inactivated virus ','Erciyes University, Turkey',2);
INSERT INTO vaccines VALUES('COVAC-1 and COVAC-2 sub-unit vaccine (spike protein) + SWE adjuvant ','University of Saskatchewan',2);
INSERT INTO vaccines VALUES('GBP510, a recombinant surface protein vaccine with adjuvant AS03 (aluminium hydroxide)','SK Bioscience Co., Ltd. and CEPI',2);
INSERT INTO vaccines VALUES('Razi Cov Pars, recombinant spike protein','Razi Vaccine and Serum Research Institute',3);
INSERT INTO vaccines VALUES('COVID-19 inactivated vaccine','Shifa Pharmed Industrial Co',2);
INSERT INTO vaccines VALUES('MF59 adjuvanted SARS-CoV-2 Sclamp vaccine ','The University of Queensland',2);
INSERT INTO vaccines VALUES('COVIGEN ','University of Sydney, Bionet Co., Ltd Technovalia',2);
INSERT INTO vaccines VALUES('COVID-eVax, a candidate plasmid DNA vaccine of the Spike protein','Takis + Rottapharm Biotech',2);
INSERT INTO vaccines VALUES('BBV154, Adenoviral vector COVID-19 vaccine','Bharat Biotech International Limited',1);
INSERT INTO vaccines VALUES('PTX-COVID19-B, mRNA vaccine','Providence Therapeutics',2);
INSERT INTO vaccines VALUES('Inactivated (NDV-based) chimeric vaccine with or without the adjuvant CpG 1018','The Government Pharmaceutical Organization (GPO); PATH; Dynavax',2);
INSERT INTO vaccines VALUES(' CoV2 SAM (LNP) vaccine.  A self-amplifying mRNA (SAM) lipid nanoparticle (LNP) platform + Spike antigen','GlaxoSmithKline',2);
INSERT INTO vaccines VALUES('VBI-2902a.  An enveloped virus-like particle (eVLP) of SARS-CoV-2 spike (S) glycoprotein and aluminum phosphate adjuvant.','VBI Vaccines Inc.',2);
INSERT INTO vaccines VALUES('SK SARS-CoV-2 recombinant surface antigen protein subunit (NBP2001) + adjuvanted with alum.','SK Bioscience Co., Ltd.',2);
INSERT INTO vaccines VALUES('Chimpanzee Adenovirus serotype 68 (ChAd) and self-amplifying mRNA (SAM) vectors expressing spike alone, or spike plus additional SARS-CoV-2 T cell epitopes.','Gritstone Oncology ',3);
INSERT INTO vaccines VALUES('mRNA-1273.351. A lipid nanoparticle (LNP)-encapsulated mRNA-based vaccine that encodes for a full-length, prefusion stabilized S protein of the SARS-CoV-2 B.1.351 variant.','Moderna + National Institute of Allergy and Infectious Diseases (NIAID)',3);
INSERT INTO vaccines VALUES('SpFN (spike ferritin nanoparticle) uses spike proteins with a liposomal formulation QS21 (ALFQ) adjuvant.','Walter Reed Army Institute of Research (WRAIR)',3);
INSERT INTO vaccines VALUES('EuCorVac-19; A spike protein using the recombinant protein technology and with an adjuvant.','POP Biotechnologies and EuBiologics Co.,Ltd',2);
INSERT INTO vaccines VALUES('Inactivated SARS-CoV-2 vaccine FAKHRAVAC (MIVAC)','Organization of Defensive Innovation and Research',2);
INSERT INTO vaccines VALUES('MV-014-212, a live attenuated vaccine that expresses the spike (S) protein of SARS-CoV-2','Meissa Vaccines, Inc.',1);
INSERT INTO vaccines VALUES('MRT5500, an mRNA vaccine candidate','Sanofi Pasteur and Translate Bio',2);
INSERT INTO vaccines VALUES('SARS-CoV-2 VLP Vaccine','The Scientific and Technological Research Council of Turkey',2);
INSERT INTO vaccines VALUES('ReCOV: Recombinant two-component spike and RBD protein COVID-19 vaccine (CHO cell).','Jiangsu Rec-Biotechnology',2);
INSERT INTO vaccines VALUES('DS-5670a, mRNA vaccine','Daiichi Sankyo Co., Ltd.',2);
INSERT INTO vaccines VALUES('Koçak-19 Inactivated adjuvant COVID-19 viral vaccine','Kocak Farma, Turkey',2);
INSERT INTO vaccines VALUES('COVIVAC.  Newcastle Disease Virus (NDV) expressing membrane-anchored pre-fusion-stabilized trimeric SARS-CoV-2 S protein +/- adjuvant CpG 1018','Institute of Vaccines and Medical Biologicals, Vietnam',2);
INSERT INTO vaccines VALUES('SC-Ad6-1, Adneviral vector vaccine','Tetherex Pharmaceuticals Corporation',2);
INSERT INTO vaccines VALUES('ABNCoV2 capsid virus-like particle (cVLP) +/- adjuvant MF59','Radboud University',2);
INSERT INTO vaccines VALUES('Recombinant SARS-CoV-2 Fusion Protein Vaccine (V-01) ','Guangdong Provincial Center for Disease Control and Prevention/Gaozhou Center for Disease Control and Prevention ',2);
INSERT INTO vaccines VALUES('HDT-301: Self-replicating mRNA vaccine formulated as a lipid nanoparticle.','SENAI CIMATEC',2);
INSERT INTO vaccines VALUES('Adjuvanted inactivated vaccine against SARS-CoV-2 ','The Scientific and Technological Research Council of Turkey (TÜBITAK) ',2);
INSERT INTO vaccines VALUES('mRNA-1283 ','ModernaTX, Inc.',2);
INSERT INTO vaccines VALUES('Recombinant SARS-CoV-2 Vaccine (CHO cell)','National Vaccine and Serum Institute, China',2);
INSERT INTO vaccines VALUES('EXG-5003; a temperature-sensitive self-replicating RNA vaccine expressing the receptor binding domain of the SARS-CoV-2 spike protein.','Elixirgen Therapeutics, Inc',1);
INSERT INTO vaccines VALUES('Inactivated COVID-19 vaccine','KM Biologics Co., Ltd.',2);
INSERT INTO vaccines VALUES('Live recombinant Newcastle Disease Virus (rNDV) vector vaccine','Laboratorio Avi-Mex',2);
INSERT INTO vaccines VALUES('mRNA COVID-19 vaccine','Shanghai East Hospital and Stemirna Therapeutics',2);
INSERT INTO vaccines VALUES('CoVepiT vaccine: SARS-CoV-2 multi-target peptide vaccine (targeting Spike, M, N, and several non-structural proteins)','OSE Immunotherapeutics',2);
INSERT INTO vaccines VALUES('Modified Vaccinia Virus Ankara (MVA) vector expressing a stabilized SARS-CoV-2 spike protein','German Center for Infection Research',2);
INSERT INTO vaccines VALUES('CoV2-OGEN1, protein-based vaccine','USSF/Vaxform',2);
INSERT INTO vaccines VALUES('QazCoVac-P - COVID-19 Subunit Vaccine','Research Institute for Biological Safety Problems',2);
INSERT INTO vaccines VALUES('LNP-nCOV saRNA-02 vaccine; Self-amplifying RNA (saRNA) encapsulated in lipid nanoparticles (LNP)','MRC/UVRI and LSHTM Uganda Research Unit',2);
INSERT INTO vaccines VALUES('mRNA-1273.211.  A multivalent booster candidate combining mRNA-1273 plus mRNA-1273.351.','ModernaTX, Inc.',1);
INSERT INTO vaccines VALUES('RBD protein recombinant SARS-CoV-2 vaccine','Bagheiat-allah University of Medical Sciences',3);
INSERT INTO vaccines VALUES('Baiya SARS-CoV-2 VAX1, a plant-based subunit vaccine(RBD-Fc + adjuvant)','Baiya Phytopharm Co., Ltd.',2);
INSERT INTO vaccines VALUES('SCB-2020S, an adjuvanted recombinant SARS-CoV-2 trimeric S-protein (from B.1.351 variant) ','Clover Biopharmaceuticals AUS Pty Ltd',2);
INSERT INTO vaccines VALUES('PIV5 vector that encodes the SARS-CoV-2 spike protein','CyanVac LLC',1);
INSERT INTO vaccines VALUES('AZD2816; adenoviral vector ChAdOx platform and based on the Beta (B.1.351) variant','AstraZeneca + University of Oxford',2);
INSERT INTO vaccines VALUES('202-CoV; SARS-CoV-2 spike trimer protein + adjuvant, CpG7909.','Shanghai Zerun Biotechnology + Walvax Biotechnology  + CEPI',2);
INSERT INTO vaccines VALUES('AG0302-COVID19','AnGes, Inc',3);
INSERT INTO vaccines VALUES('Recombinant protein RBD fusion dimer adjuvanted vaccine  (COVID-19 Vaccine Hipra)','Laboratorios Hipra, S.A.',2);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE vaccination_choices(
	student_id VARCHAR(16) REFERENCES students(student_id),
	vaccine_name VARCHAR(500),
	developer VARCHAR(500),
	FOREIGN KEY (vaccine_name, developer) REFERENCES vaccines(vaccine_name, developer)
		ON UPDATE CASCADE ON DELETE CASCADE,
	PRIMARY KEY (student_id, vaccine_name, developer)
	);

INSERT INTO vaccination_choices
SELECT s.student_id, v.vaccine_name, v.developer
FROM students s, vaccines v
ORDER BY random() limit 1000
