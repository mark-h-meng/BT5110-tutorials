/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* instagram users can post many photos in their own accounts and they can also comment on other users' photos posted*/
/* hence, one photo can have many comments */
/* 1. table of instagram users that contain their usernames and emails */
/* 2. table of photos(in url) posted by the instagram users */
/* 3. table of comments posted by the instagram users on the photos */
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE users (
	id SERIAL PRIMARY KEY,
	username VARCHAR(50) NOT NULL,
	email VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE photos (
	id SERIAL PRIMARY KEY,
	user_id INTEGER NOT NULL REFERENCES users(id),
	url VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE comments (
	id SERIAL PRIMARY KEY,
	user_id INTEGER NOT NULL REFERENCES users(id),
	photo_id INTEGER NOT NULL REFERENCES photos(id),
	body VARCHAR(500) NOT NULL
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO users (username, email)
VALUES
	('aseaman0', 'hfarlowe0@dagondesign.com'),
	('kcoule1', 'lnelissen1@jugem.jp'),
	('akersey2', 'evoysey2@tiny.cc'),
	('fishaki3', 'dbisacre3@msu.edu'),
	('amcevay4', 'shambly4@hubpages.com'),
	('lnorrington5', 'lbudgeon5@google.ru'),
	('lmcveighty6', 'bpoacher6@statcounter.com'),
	('fgillmor7', 'roby7@businessinsider.com'),
	('nwharfe8', 'cfear8@ifeng.com'),
	('rloreit9', 'srudsdell9@usa.gov'),
	('dblondina', 'ggallaghera@dell.com'),
	('dcaskieb', 'cgallihawkb@salon.com'),
	('bdumberrillc', 'cshowalterc@ed.gov'),
	('ebiggsd', 'rdanaherd@discuz.net'),
	('kstaige', 'rblencoee@weibo.com'),
	('fhadleyf', 'ctearneyf@craigslist.org'),
	('aciabatterig', 'gmurdyg@moonfruit.com'),
	('mscraggh', 'elammash@facebook.com'),
	('mruckerti', 'jruggieroi@amazon.de'),
	('bkibelj', 'stwortj@sohu.com'),
	('kwiddowsk', 'tmartugink@etsy.com'),
	('ecollesl', 'alepiscopil@surveymonkey.com'),
	('rbemlottm', 'ochinnerym@comsenz.com'),
	('dfairbournn', 'cbrownriggn@typepad.com'),
	('bjurzyko', 'fwieldo@studiopress.com'),
	('wdavittip', 'reldersp@seattletimes.com'),
	('bgallehockq', 'sdeguiseq@netscape.com'),
	('ikristufekr', 'sglisenanr@google.co.jp'),
	('bwalworths', 'rkirtons@indiatimes.com'),
	('srevellt', 'brichardtt@rambler.ru'),
	('rruslingeu', 'yberksu@mapy.cz'),
	('tmussingtonv', 'jgonv@chicagotribune.com'),
	('ahendinw', 'hchadbournew@cafepress.com'),
	('eludewigx', 'kpurslowx@slideshare.net'),
	('kpetleyy', 'dleydony@ucla.edu'),
	('kdollarz', 'rmetzelz@ox.ac.uk'),
	('cfurze10', 'acunradi10@yelp.com'),
	('mdiehn11', 'jmucklestone11@vinaora.com'),
	('thurst12', 'afoskett12@auda.org.au'),
	('lstoodale13', 'mmanson13@jigsy.com'),
	('ocristoferi14', 'rbecarra14@businessinsider.com'),
	('kinnett15', 'spedrocco15@altervista.org'),
	('vreihill16', 'mconwell16@craigslist.org'),
	('cgalego17', 'rbelitz17@csmonitor.com'),
	('icouper18', 'ebuchanan18@addtoany.com'),
	('fmcgooch19', 'ecowser19@flickr.com'),
	('tackerley1a', 'fmargrem1a@virginia.edu'),
	('wgeake1b', 'zpattingson1b@arstechnica.com'),
	('ahinckley1c', 'ojupp1c@ebay.co.uk'),
	('mdomenichelli1d', 'jgarrat1d@psu.edu'),
	('hspink1e', 'caidler1e@cisco.com'),
	('gcoulsen1f', 'rgarratty1f@china.com.cn'),
	('bbetz1g', 'prope1g@ifeng.com'),
	('lyorkston1h', 'avennart1h@seesaa.net'),
	('erootham1i', 'akemster1i@sbwire.com'),
	('mwodham1j', 'cdikle1j@hao123.com'),
	('mbulter1k', 'acrumley1k@unicef.org'),
	('pconnock1l', 'hbustard1l@cdc.gov'),
	('rspringall1m', 'nkaygill1m@columbia.edu'),
	('ecouch1n', 'smarians1n@ocn.ne.jp'),
	('aheaphy1o', 'cludlem1o@soup.io'),
	('bhopkyns1p', 'kcayser1p@cnn.com'),
	('abevar1q', 'gsawkin1q@storify.com'),
	('bsetterfield1r', 'dshadbolt1r@hibu.com'),
	('bchapelhow1s', 'tandras1s@123-reg.co.uk'),
	('ewathan1t', 'mmarciskewski1t@mashable.com'),
	('cdeners1u', 'gmackimmie1u@yale.edu'),
	('clampet1v', 'vvanderhoven1v@go.com'),
	('jdaughtry1w', 'jidle1w@jugem.jp'),
	('fenderlein1x', 'gkorb1x@xinhuanet.com'),
	('amowson1y', 'alamberto1y@prlog.org'),
	('dspurret1z', 'lalldre1z@sfgate.com'),
	('ekeyzman20', 'jklulik20@posterous.com'),
	('aforesight21', 'kjones21@bluehost.com'),
	('hocorren22', 'syakhin22@1688.com'),
	('egowdy23', 'cbrandenburg23@army.mil'),
	('dusborn24', 'psnedden24@newsvine.com'),
	('clicciardo25', 'kstonier25@gnu.org'),
	('etramel26', 'lolexa26@reference.com'),
	('hfrancesch27', 'hbarwell27@homestead.com'),
	('onasi28', 'cluter28@tmall.com'),
	('jcareswell29', 'jlightwing29@nps.gov'),
	('mfarfalameev2a', 'gcallicott2a@businesswire.com'),
	('zdulany2b', 'mlyard2b@yandex.ru'),
	('cyelland2c', 'ffernando2c@t-online.de'),
	('jocloney2d', 'ewymer2d@nydailynews.com'),
	('mmynett2e', 'ltunnock2e@reverbnation.com'),
	('brenzo2f', 'lmutton2f@meetup.com'),
	('scarrane2g', 'paxup2g@slate.com'),
	('wtomankowski2h', 'shadcroft2h@ibm.com'),
	('clecount2i', 'jiskow2i@amazon.de'),
	('rpyle2j', 'tmowles2j@webs.com'),
	('ctomaszek2k', 'odundon2k@gmpg.org'),
	('pmacintyre2l', 'avallery2l@google.co.jp'),
	('rwingeat2m', 'gosbourne2m@abc.net.au'),
	('pduran2n', 'hstockman2n@vkontakte.ru'),
	('abotton2o', 'bgilvary2o@tinyurl.com'),
	('dpiscopiello2p', 'sleach2p@naver.com'),
	('mcannicott2q', 'cafield2q@newsvine.com'),
	('eduerden2r', 'jskilbeck2r@vkontakte.ru');

INSERT INTO photos (user_id, url)
VALUES
	(30, 'http://dummyimage.com/108x200.png/dddddd/000000'),
	(32, 'http://dummyimage.com/152x200.png/dddddd/000456'),
	(24, 'http://dummyimage.com/236x200.png/5fa2dd/ffffff'),
	(13, 'http://dummyimage.com/126x200.png/dddddd/000000'),
	(43, 'http://dummyimage.com/249x200.png/cc0000/ffffff'),
	(25, 'http://dummyimage.com/214x200.png/ff4444/ffffff'),
	(53, 'http://dummyimage.com/215x200.png/5fa2dd/000fff'),
	(68, 'http://dummyimage.com/203x200.png/dddddd/000000'),
	(15, 'http://dummyimage.com/101x200.png/ff4444/ffffff'),
	(6, 'http://dummyimage.com/143x200.png/5fa2dd/000fff'),
	(91, 'http://dummyimage.com/199x200.png/5fa2dd/ffffff'),
	(42, 'http://dummyimage.com/245x200.png/dddddd/000000'),
	(34, 'http://dummyimage.com/114x100.png/cc0000/ffffff'),
	(58, 'http://dummyimage.com/103x100.png/5fa2dd/000fff'),
	(37, 'http://dummyimage.com/131x100.png/dddddd/000000'),
	(94, 'http://dummyimage.com/211x100.png/cc0000/ffffff'),
	(36, 'http://dummyimage.com/179x100.png/5fa2dd/000fff'),
	(11, 'http://dummyimage.com/155x100.png/ff4444/ffffff'),
	(54, 'http://dummyimage.com/149x100.png/cc0000/ffffff'),
	(24, 'http://dummyimage.com/112x100.png/ff4444/000fff'),
	(84, 'http://dummyimage.com/183x100.png/cc0000/ffffff'),
	(83, 'http://dummyimage.com/165x100.png/ff4444/000fff'),
	(65, 'http://dummyimage.com/107x100.png/dddddd/000fff'),
	(2, 'http://dummyimage.com/114x100.png/5fa2dd/ffffff'),
	(14, 'http://dummyimage.com/216x100.png/dddddd/000fff'),
	(6, 'http://dummyimage.com/213x100.png/ff4444/000fff'),
	(100, 'http://dummyimage.com/240x100.png/dddddd/000000'),
	(39, 'http://dummyimage.com/231x150.png/5fa2dd/ffffff'),
	(27, 'http://dummyimage.com/113x150.png/5fa2dd/000fff'),
	(84, 'http://dummyimage.com/117x150.png/cc0000/ffffff'),
	(38, 'http://dummyimage.com/225x150.png/cc0000/000fff'),
	(69, 'http://dummyimage.com/131x150.png/ff4444/ffffff'),
	(7, 'http://dummyimage.com/171x150.png/ff4444/000fff'),
	(76, 'http://dummyimage.com/109x150.png/cc0000/ffffff'),
	(80, 'http://dummyimage.com/124x150.png/cc0000/fff000'),
	(11, 'http://dummyimage.com/126x150.png/dddddd/000fff'),
	(42, 'http://dummyimage.com/115x150.png/ff4444/ffffff'),
	(24, 'http://dummyimage.com/126x150.png/dddddd/000000'),
	(22, 'http://dummyimage.com/146x150.png/cc0000/ffffff'),
	(35, 'http://dummyimage.com/142x150.png/ff4444/fff000'),
	(26, 'http://dummyimage.com/213x150.png/5fa2dd/ffffff'),
	(67, 'http://dummyimage.com/211x150.png/5fa2dd/fff000'),
	(53, 'http://dummyimage.com/193x150.png/5fa2dd/ffffff'),
	(40, 'http://dummyimage.com/144x150.png/5fa2dd/fff000'),
	(96, 'http://dummyimage.com/108x150.png/5fa2dd/ffffff'),
	(74, 'http://dummyimage.com/148x120.png/ff4444/fff000'),
	(52, 'http://dummyimage.com/133x120.png/5fa2dd/ffffff'),
	(29, 'http://dummyimage.com/201x120.png/cc0000/fff000'),
	(11, 'http://dummyimage.com/116x120.png/5fa2dd/ffffff'),
	(39, 'http://dummyimage.com/130x120.png/cc0000/fff000'),
	(28, 'http://dummyimage.com/239x120.png/dddddd/123000'),
	(82, 'http://dummyimage.com/118x120.png/5fa2dd/ffffff'),
	(32, 'http://dummyimage.com/122x120.png/5fa2dd/123000'),
	(5, 'http://dummyimage.com/172x120.png/5fa2dd/ffffff'),
	(22, 'http://dummyimage.com/243x120.png/cc0000/123000'),
	(97, 'http://dummyimage.com/235x120.png/dddddd/000000'),
	(83, 'http://dummyimage.com/223x120.png/dddddd/123000'),
	(36, 'http://dummyimage.com/140x120.png/ff4444/ffffff'),
	(85, 'http://dummyimage.com/108x120.png/ff4444/123000'),
	(80, 'http://dummyimage.com/235x120.png/cc0000/ffffff'),
	(86, 'http://dummyimage.com/140x120.png/5fa2dd/123000'),
	(2, 'http://dummyimage.com/124x120.png/dddddd/000000'),
	(87, 'http://dummyimage.com/176x120.png/5fa2dd/ffffff'),
	(85, 'http://dummyimage.com/217x120.png/dddddd/123000'),
	(63, 'http://dummyimage.com/202x120.png/dddddd/000000'),
	(87, 'http://dummyimage.com/176x120.png/cc0000/ffffff'),
	(88, 'http://dummyimage.com/243x120.png/dddddd/123000'),
	(33, 'http://dummyimage.com/200x120.png/dddddd/000000'),
	(73, 'http://dummyimage.com/103x120.png/ff4444/ffffff'),
	(56, 'http://dummyimage.com/221x120.png/ff4444/123456'),
	(81, 'http://dummyimage.com/179x120.png/ff4444/ffffff'),
	(20, 'http://dummyimage.com/139x120.png/5fa2dd/ffffff'),
	(38, 'http://dummyimage.com/157x120.png/cc0000/123456'),
	(10, 'http://dummyimage.com/210x120.png/5fa2dd/ffffff'),
	(32, 'http://dummyimage.com/209x120.png/ff4444/ffffff'),
	(18, 'http://dummyimage.com/149x120.png/dddddd/123456'),
	(36, 'http://dummyimage.com/144x120.png/dddddd/000000'),
	(83, 'http://dummyimage.com/113x120.png/ff4444/ffffff'),
	(97, 'http://dummyimage.com/123x120.png/5fa2dd/123456'),
	(56, 'http://dummyimage.com/132x120.png/cc0000/ffffff'),
	(50, 'http://dummyimage.com/120x120.png/5fa2dd/123456'),
	(25, 'http://dummyimage.com/126x120.png/dddddd/000000'),
	(66, 'http://dummyimage.com/106x120.png/cc0000/ffffff'),
	(41, 'http://dummyimage.com/177x110.png/5fa2dd/123456'),
	(25, 'http://dummyimage.com/115x110.png/dddddd/000000'),
	(71, 'http://dummyimage.com/114x110.png/5fa2dd/123456'),
	(46, 'http://dummyimage.com/141x110.png/5fa2dd/ffffff'),
	(29, 'http://dummyimage.com/185x110.png/5fa2dd/123456'),
	(55, 'http://dummyimage.com/164x110.png/5fa2dd/ffffff'),
	(38, 'http://dummyimage.com/141x110.png/5fa2dd/000fff'),
	(95, 'http://dummyimage.com/148x110.png/5fa2dd/ffffff'),
	(52, 'http://dummyimage.com/233x110.png/5fa2dd/gggfff'),
	(92, 'http://dummyimage.com/152x110.png/dddddd/000000'),
	(9, 'http://dummyimage.com/167x110.png/dddddd/gggfff'),
	(90, 'http://dummyimage.com/202x110.png/ff4444/ffffff'),
	(50, 'http://dummyimage.com/226x110.png/5fa2dd/ffffff'),
	(27, 'http://dummyimage.com/185x110.png/cc0000/000fff'),
	(63, 'http://dummyimage.com/122x110.png/5fa2dd/ffffff'),
	(28, 'http://dummyimage.com/189x110.png/cc0000/gggfff'),
	(10, 'http://dummyimage.com/104x110.png/ff4444/ffffff');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO comments (user_id, photo_id, body)
WITH expanded AS (
	SELECT RANDOM(), seq, u.id AS user_id, p.id AS photo_id
	FROM GENERATE_SERIES(1,1000) seq, users u, photos p
), shuffled AS (
	SELECT e.*
	FROM expanded e
	INNER JOIN (
		SELECT ei.seq, MIN(ei.random) FROM expanded ei GROUP BY ei.seq
	) em ON (e.seq = em.seq AND e.random = em.min)
	ORDER BY e.seq
)

SELECT
	s.user_id,
	s.photo_id,
	'Comments ABCD ' || s.seq AS body
FROM shuffled s;

SELECT * FROM comments LIMIT 1000;


