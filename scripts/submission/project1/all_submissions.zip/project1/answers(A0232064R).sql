/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL-Pgadmin */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
Use the following SQL written in PostgreSQL-Pgadmin to find out which companies and which departments have the highest salaries.
The first table-company, contains its id, name and contacting email.

In the second sql, person represents the staff or workers in their compaies.Within the sql, you can find their salary information 
and department such as Human Resources Department. By using the given data, it will be easy to find the 'right' people and departments 
who have won the highest salary.

In the third table-worksfor, we cross join the former two tables(company and person). Then we can use the four columns to gain the 
insight.


*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

create table company (
  com_id VARCHAR(50),
  first_name VARCHAR(50),
  last_name VARCHAR(50),
  email VARCHAR(50)
);
create table person (
  staff_id VARCHAR(50),
  first_name VARCHAR(50),
  last_name VARCHAR(50),
  salary INT,
  staff_dpt VARCHAR(50)
);
create table worksfor (
  com_id VARCHAR(50),
  staff_id VARCHAR(50),
  salary INT,
  staff_dpt VARCHAR(50)
);

/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/* Write your answer in SQL below: */
insert into company (com_id, first_name, last_name, email) values ('83548', 'Emelia', 'Stoop', 'estoop0@msn.com');
insert into company (com_id, first_name, last_name, email) values ('3318', 'Netti', 'Lardge', 'nlardge1@phpbb.com');
insert into company (com_id, first_name, last_name, email) values ('1', 'Costa', 'Wrightam', 'cwrightam2@myspace.com');
insert into company (com_id, first_name, last_name, email) values ('5211', 'Quintin', 'Danilchev', 'qdanilchev3@angelfire.com');
insert into company (com_id, first_name, last_name, email) values ('362', 'Ulla', 'Escudier', 'uescudier4@behance.net');
insert into company (com_id, first_name, last_name, email) values ('9', 'Diego', 'Rocca', 'drocca5@nature.com');
insert into company (com_id, first_name, last_name, email) values ('04027', 'Geno', 'Eyles', 'geyles6@timesonline.co.uk');
insert into company (com_id, first_name, last_name, email) values ('3548', 'Felice', 'Mackleden', 'fmackleden7@google.com.hk');
insert into company (com_id, first_name, last_name, email) values ('68', 'Richmond', 'Fronczak', 'rfronczak8@ibm.com');
insert into company (com_id, first_name, last_name, email) values ('72082', 'Therese', 'Birtle', 'tbirtle9@unc.edu');
insert into company (com_id, first_name, last_name, email) values ('120', 'Hope', 'Vasyutochkin', 'hvasyutochkina@altervista.org');
insert into company (com_id, first_name, last_name, email) values ('21', 'Kimberli', 'Bugler', 'kbuglerb@canalblog.com');
insert into company (com_id, first_name, last_name, email) values ('9254', 'Antonio', 'Kesterton', 'akestertonc@state.gov');
insert into company (com_id, first_name, last_name, email) values ('2', 'Marianna', 'Theze', 'mthezed@dot.gov');
insert into company (com_id, first_name, last_name, email) values ('237', 'Christine', 'Gladtbach', 'cgladtbache@omniture.com');
insert into company (com_id, first_name, last_name, email) values ('32', 'Evelyn', 'Jennings', 'ejenningsf@miibeian.gov.cn');
insert into company (com_id, first_name, last_name, email) values ('54', 'Linnie', 'Leathes', 'lleathesg@abc.net.au');
insert into company (com_id, first_name, last_name, email) values ('5884', 'Teri', 'Klug', 'tklugh@un.org');
insert into company (com_id, first_name, last_name, email) values ('28', 'Sarah', 'Bardwell', 'sbardwelli@gmpg.org');
insert into company (com_id, first_name, last_name, email) values ('572', 'Teador', 'Woollons', 'twoollonsj@ifeng.com');
insert into company (com_id, first_name, last_name, email) values ('2765', 'Vally', 'Gouth', 'vgouthk@mozilla.com');
insert into company (com_id, first_name, last_name, email) values ('7', 'Felipe', 'Drakard', 'fdrakardl@istockphoto.com');
insert into company (com_id, first_name, last_name, email) values ('073', 'Kristel', 'Bento', 'kbentom@ftc.gov');
insert into company (com_id, first_name, last_name, email) values ('29306', 'Jelene', 'Firmin', 'jfirminn@google.de');
insert into company (com_id, first_name, last_name, email) values ('12', 'Elia', 'Swayne', 'eswayneo@elpais.com');
insert into company (com_id, first_name, last_name, email) values ('0605', 'Inness', 'Ciccarelli', 'iciccarellip@etsy.com');
insert into company (com_id, first_name, last_name, email) values ('55405', 'Allan', 'Pettersen', 'apettersenq@nydailynews.com');
insert into company (com_id, first_name, last_name, email) values ('41', 'Waylon', 'Danilyak', 'wdanilyakr@w3.org');
insert into company (com_id, first_name, last_name, email) values ('06161', 'Chrisse', 'Wankel', 'cwankels@simplemachines.org');
insert into company (com_id, first_name, last_name, email) values ('8', 'Louie', 'Manuely', 'lmanuelyt@ox.ac.uk');
insert into company (com_id, first_name, last_name, email) values ('55064', 'Peirce', 'Cargon', 'pcargonu@cdc.gov');
insert into company (com_id, first_name, last_name, email) values ('63', 'Corrie', 'Wynrahame', 'cwynrahamev@toplist.cz');
insert into company (com_id, first_name, last_name, email) values ('795', 'Brena', 'Lisamore', 'blisamorew@si.edu');
insert into company (com_id, first_name, last_name, email) values ('89234', 'Drusy', 'Boyse', 'dboysex@edublogs.org');
insert into company (com_id, first_name, last_name, email) values ('31777', 'Shaylynn', 'Tanswill', 'stanswilly@moonfruit.com');
insert into company (com_id, first_name, last_name, email) values ('87121', 'Hurleigh', 'Dory', 'hdoryz@usa.gov');
insert into company (com_id, first_name, last_name, email) values ('35', 'Brittne', 'Swaine', 'bswaine10@plala.or.jp');
insert into company (com_id, first_name, last_name, email) values ('1782', 'Alejandra', 'Kale', 'akale11@bloglines.com');
insert into company (com_id, first_name, last_name, email) values ('4', 'Kelsy', 'Theuff', 'ktheuff12@macromedia.com');
insert into company (com_id, first_name, last_name, email) values ('73168', 'Jamaal', 'Shenton', 'jshenton13@ca.gov');
insert into company (com_id, first_name, last_name, email) values ('42089', 'Grier', 'Joseff', 'gjoseff14@liveinternet.ru');
insert into company (com_id, first_name, last_name, email) values ('653', 'Baird', 'Wedlock', 'bwedlock15@blogger.com');
insert into company (com_id, first_name, last_name, email) values ('89191', 'Cleon', 'Friend', 'cfriend16@reuters.com');
insert into company (com_id, first_name, last_name, email) values ('50', 'Amalle', 'Normavill', 'anormavill17@constantcontact.com');
insert into company (com_id, first_name, last_name, email) values ('7', 'Brigg', 'Redford', 'bredford18@smh.com.au');
insert into company (com_id, first_name, last_name, email) values ('98', 'Stephanie', 'Naptine', 'snaptine19@shutterfly.com');
insert into company (com_id, first_name, last_name, email) values ('353', 'Rikki', 'Scrace', 'rscrace1a@google.com');
insert into company (com_id, first_name, last_name, email) values ('72', 'Mikel', 'Tinson', 'mtinson1b@netlog.com');
insert into company (com_id, first_name, last_name, email) values ('3', 'Penelopa', 'Erdis', 'perdis1c@artisteer.com');
insert into company (com_id, first_name, last_name, email) values ('37', 'Maighdiln', 'Quade', 'mquade1d@shareasale.com');
insert into company (com_id, first_name, last_name, email) values ('776', 'Luella', 'Dorsett', 'ldorsett1e@ibm.com');
insert into company (com_id, first_name, last_name, email) values ('13718', 'Alden', 'Wyper', 'awyper1f@indiegogo.com');
insert into company (com_id, first_name, last_name, email) values ('28', 'Kev', 'Addy', 'kaddy1g@wsj.com');
insert into company (com_id, first_name, last_name, email) values ('42', 'Roseline', 'MacCaghan', 'rmaccaghan1h@clickbank.net');
insert into company (com_id, first_name, last_name, email) values ('631', 'Maddy', 'Blanche', 'mblanche1i@youtu.be');
insert into company (com_id, first_name, last_name, email) values ('52875', 'Silvie', 'Crichmer', 'scrichmer1j@sakura.ne.jp');
insert into company (com_id, first_name, last_name, email) values ('83309', 'Doralyn', 'Holstein', 'dholstein1k@instagram.com');
insert into company (com_id, first_name, last_name, email) values ('0', 'Purcell', 'Robertot', 'probertot1l@joomla.org');
insert into company (com_id, first_name, last_name, email) values ('99169', 'Lowe', 'Nolot', 'lnolot1m@imdb.com');
insert into company (com_id, first_name, last_name, email) values ('55642', 'Silvia', 'Allridge', 'sallridge1n@nifty.com');
insert into company (com_id, first_name, last_name, email) values ('3', 'Juliana', 'Rentilll', 'jrentilll1o@smh.com.au');
insert into company (com_id, first_name, last_name, email) values ('07', 'Sianna', 'Ossipenko', 'sossipenko1p@blinklist.com');
insert into company (com_id, first_name, last_name, email) values ('72801', 'Chucho', 'McArthur', 'cmcarthur1q@spotify.com');
insert into company (com_id, first_name, last_name, email) values ('990', 'Devondra', 'Baigent', 'dbaigent1r@about.com');
insert into company (com_id, first_name, last_name, email) values ('10187', 'Nellie', 'Skipton', 'nskipton1s@hubpages.com');
insert into company (com_id, first_name, last_name, email) values ('16780', 'Carry', 'Bullier', 'cbullier1t@freewebs.com');
insert into company (com_id, first_name, last_name, email) values ('11', 'Mikey', 'Roddie', 'mroddie1u@ed.gov');
insert into company (com_id, first_name, last_name, email) values ('3149', 'Terri', 'Kubec', 'tkubec1v@berkeley.edu');
insert into company (com_id, first_name, last_name, email) values ('093', 'Essy', 'Laverack', 'elaverack1w@seesaa.net');
insert into company (com_id, first_name, last_name, email) values ('39', 'Josi', 'Brabyn', 'jbrabyn1x@uiuc.edu');
insert into company (com_id, first_name, last_name, email) values ('653', 'Reeba', 'Sparks', 'rsparks1y@merriam-webster.com');
insert into company (com_id, first_name, last_name, email) values ('6', 'Patrice', 'Crosbie', 'pcrosbie1z@dell.com');
insert into company (com_id, first_name, last_name, email) values ('1', 'Blondelle', 'Tomaszynski', 'btomaszynski20@gov.uk');
insert into company (com_id, first_name, last_name, email) values ('0', 'Rozelle', 'Madgwick', 'rmadgwick21@wordpress.org');
insert into company (com_id, first_name, last_name, email) values ('84507', 'Trudi', 'Keeble', 'tkeeble22@scribd.com');
insert into company (com_id, first_name, last_name, email) values ('03904', 'Akim', 'Boman', 'aboman23@yandex.ru');
insert into company (com_id, first_name, last_name, email) values ('520', 'Had', 'Eskriet', 'heskriet24@github.io');
insert into company (com_id, first_name, last_name, email) values ('495', 'Dean', 'Sibery', 'dsibery25@liveinternet.ru');
insert into company (com_id, first_name, last_name, email) values ('70665', 'Pall', 'Semour', 'psemour26@answers.com');
insert into company (com_id, first_name, last_name, email) values ('82536', 'Farlie', 'Prayer', 'fprayer27@xinhuanet.com');
insert into company (com_id, first_name, last_name, email) values ('88', 'Em', 'Dyet', 'edyet28@arizona.edu');
insert into company (com_id, first_name, last_name, email) values ('4', 'Prentiss', 'Wearne', 'pwearne29@livejournal.com');
insert into company (com_id, first_name, last_name, email) values ('13', 'Renae', 'Bassam', 'rbassam2a@cnbc.com');
insert into company (com_id, first_name, last_name, email) values ('821', 'Peggie', 'Hammand', 'phammand2b@sina.com.cn');
insert into company (com_id, first_name, last_name, email) values ('8', 'Pavel', 'Willoughby', 'pwilloughby2c@chicagotribune.com');
insert into company (com_id, first_name, last_name, email) values ('387', 'Clint', 'Chappel', 'cchappel2d@github.com');
insert into company (com_id, first_name, last_name, email) values ('7', 'Carita', 'Selwyne', 'cselwyne2e@japanpost.jp');
insert into company (com_id, first_name, last_name, email) values ('17524', 'Joycelin', 'Ben', 'jben2f@google.pl');
insert into company (com_id, first_name, last_name, email) values ('5207', 'Dulce', 'Dorran', 'ddorran2g@google.pl');
insert into company (com_id, first_name, last_name, email) values ('0', 'Carmine', 'Healks', 'chealks2h@youtu.be');
insert into company (com_id, first_name, last_name, email) values ('58910', 'Ibbie', 'Boner', 'iboner2i@usnews.com');
insert into company (com_id, first_name, last_name, email) values ('430', 'Jessika', 'Froggatt', 'jfroggatt2j@tiny.cc');
insert into company (com_id, first_name, last_name, email) values ('45665', 'Sherilyn', 'Shipston', 'sshipston2k@paypal.com');
insert into company (com_id, first_name, last_name, email) values ('42', 'Hilliary', 'Beddo', 'hbeddo2l@home.pl');
insert into company (com_id, first_name, last_name, email) values ('4', 'Lizzy', 'Karolczyk', 'lkarolczyk2m@wufoo.com');
insert into company (com_id, first_name, last_name, email) values ('782', 'Killie', 'De Cleen', 'kdecleen2n@ovh.net');
insert into company (com_id, first_name, last_name, email) values ('2', 'Lyndel', 'Brough', 'lbrough2o@etsy.com');
insert into company (com_id, first_name, last_name, email) values ('329', 'Reginauld', 'Gomme', 'rgomme2p@pcworld.com');
insert into company (com_id, first_name, last_name, email) values ('652', 'Kareem', 'Hodgon', 'khodgon2q@accuweather.com');
insert into company (com_id, first_name, last_name, email) values ('9317', 'Martie', 'Cavilla', 'mcavilla2r@go.com');


insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('023967100-7', 'Jacobo', 'Zorzetti', 48192, 'Sales');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('382548093-3', 'Mart', 'Battrum', 8289, 'Business Development');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('451252231-X', 'Matty', 'Duckham', 19097, 'Accounting');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('376606508-4', 'Alika', 'Dallywater', 61718, 'Training');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('884695010-0', 'Langsdon', 'McCarl', 85626, 'Human Resources');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('594542699-7', 'Atlanta', 'Stratford', 84604, 'Marketing');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('212217225-8', 'Hillie', 'Cords', 98669, 'Legal');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('538265015-2', 'Ileane', 'Colbourn', 16303, 'Sales');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('315604984-0', 'Lynna', 'Lodovichi', 20757, 'Marketing');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('144072370-2', 'Carina', 'Thormwell', 95810, 'Product Management');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('961187112-0', 'Dalt', 'Corgenvin', 97231, 'Product Management');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('566481857-3', 'Roxanne', 'Oldfield', 82407, 'Product Management');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('246578037-9', 'Edvard', 'Inchley', 34026, 'Training');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('296607321-7', 'Arny', 'Cass', 54882, 'Support');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('453647628-8', 'Berkie', 'Garralts', 26092, 'Marketing');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('067858458-3', 'Parsifal', 'Lembcke', 66297, 'Sales');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('628743297-7', 'Ebony', 'Lovell', 21264, 'Human Resources');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('679524346-X', 'Andreas', 'Christoforou', 57980, 'Product Management');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('801383589-8', 'Alain', 'Warman', 8688, 'Support');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('855031112-X', 'Benedicto', 'Lampke', 69307, 'Engineering');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('597591401-9', 'Demetria', 'Jirusek', 94644, 'Services');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('199821210-6', 'Madelon', 'Venard', 5618, 'Support');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('619694595-5', 'Bebe', 'Shenfish', 56338, 'Sales');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('064968415-X', 'Danny', 'Leas', 47189, 'Legal');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('749871934-7', 'Ranee', 'Shiel', 32082, 'Product Management');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('832865191-2', 'Gaynor', 'Cressor', 45186, 'Business Development');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('813096859-2', 'Leodora', 'Wroughton', 99068, 'Human Resources');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('895409730-8', 'Grady', 'McConaghy', 73539, 'Accounting');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('282487838-X', 'Zena', 'Smooth', 63874, 'Marketing');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('305631781-9', 'Hallsy', 'Stockau', 93062, 'Research and Development');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('955578472-8', 'Sayre', 'Gregolotti', 84148, 'Business Development');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('343064698-7', 'Anjela', 'Patty', 52502, 'Support');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('174031162-0', 'Merrili', 'Rollings', 38564, 'Sales');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('880680055-8', 'Brande', 'Butterfill', 5015, 'Services');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('958218355-1', 'Derek', 'Fulks', 21354, 'Marketing');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('078884502-0', 'Alissa', 'Christon', 52469, 'Marketing');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('695033764-7', 'Sibbie', 'Mellor', 54502, 'Engineering');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('699110886-3', 'Fayina', 'Malam', 77153, 'Marketing');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('699582998-0', 'Kaja', 'Keenan', 76856, 'Support');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('586918286-7', 'Herc', 'Grisenthwaite', 75659, 'Engineering');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('834817497-4', 'Billy', 'Kiera', 87704, 'Support');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('984497314-7', 'Deina', 'Farbrace', 83531, 'Legal');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('755127928-8', 'Barbabas', 'Schnieder', 28927, 'Accounting');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('319693990-1', 'Walt', 'Rambaut', 10556, 'Marketing');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('416787489-X', 'Annabal', 'Rawsen', 40374, 'Engineering');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('221560977-X', 'Vin', 'Slyne', 28257, 'Marketing');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('092632246-X', 'Libby', 'Lieber', 49743, 'Support');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('629720088-2', 'Doris', 'Aldersea', 9829, 'Accounting');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('551772654-2', 'Rana', 'Spilsbury', 76943, 'Research and Development');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('991840967-3', 'Virginia', 'Swinglehurst', 20499, 'Engineering');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('772116448-6', 'Rafaellle', 'Hambrick', 38025, 'Services');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('696547160-3', 'Ellene', 'Currm', 27258, 'Sales');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('025527528-5', 'Hercules', 'Balsillie', 88750, 'Sales');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('877636308-2', 'Elden', 'Novic', 82303, 'Legal');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('979009906-1', 'Suzanna', 'Bustin', 17224, 'Legal');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('716192643-2', 'Matt', 'Craggs', 35256, 'Legal');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('397797202-2', 'Ardeen', 'Hendrich', 17358, 'Business Development');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('996486792-1', 'Andriana', 'Antill', 53082, 'Business Development');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('358161021-3', 'Gino', 'Portman', 11978, 'Support');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('282542744-6', 'Alyss', 'Irnis', 4232, 'Training');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('712817952-6', 'Hamel', 'Capey', 46009, 'Services');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('040598389-1', 'Ward', 'Loxston', 63343, 'Product Management');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('136826516-2', 'Mag', 'Bushaway', 31717, 'Legal');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('165683345-X', 'Lorettalorna', 'Scotchmer', 9435, 'Legal');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('112338783-4', 'Marja', 'Matoshin', 12928, 'Accounting');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('108552427-2', 'Gina', 'Griswood', 31108, 'Accounting');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('658047588-9', 'Kalila', 'Gossage', 59477, 'Services');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('408780056-3', 'Rickie', 'Barrs', 40676, 'Human Resources');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('137883655-3', 'Ciel', 'Ades', 69280, 'Product Management');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('414335158-7', 'Gordon', 'Haslam', 73147, 'Services');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('844609700-1', 'Kim', 'Janaszkiewicz', 28796, 'Marketing');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('426120253-0', 'Rosemary', 'Tebbut', 49572, 'Legal');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('916280618-1', 'Stanly', 'Dennett', 80531, 'Accounting');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('517512878-7', 'Agustin', 'Rathmell', 14417, 'Human Resources');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('455868864-4', 'Christabella', 'Tollit', 83714, 'Product Management');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('807166350-6', 'Ines', 'Udie', 44091, 'Product Management');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('186301518-3', 'Bert', 'Spinelli', 20750, 'Human Resources');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('246951413-4', 'Sandy', 'Downie', 94389, 'Sales');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('892169276-2', 'Harri', 'Squeers', 96499, 'Support');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('123693607-8', 'Anneliese', 'Bidwell', 13618, 'Marketing');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('564147667-6', 'Harlene', 'Jorio', 88964, 'Legal');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('152079695-1', 'Gallard', 'Oriel', 67044, 'Support');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('474579378-2', 'Riva', 'Hillitt', 22970, 'Accounting');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('183626028-8', 'Francesca', 'Bate', 66499, 'Accounting');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('747198368-X', 'Nikki', 'Hirth', 18153, 'Training');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('170606309-1', 'Leia', 'Bartholomaus', 26299, 'Sales');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('439612008-7', 'Yoko', 'Duddan', 4065, 'Product Management');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('687305371-6', 'Ulick', 'Normadell', 74938, 'Product Management');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('942435583-1', 'Dalila', 'Rossi', 50832, 'Legal');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('569877556-7', 'Livia', 'Standring', 77087, 'Marketing');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('659079708-0', 'Gertrudis', 'Caldero', 73364, 'Training');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('573555464-6', 'Merry', 'Uttley', 81609, 'Business Development');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('738584377-8', 'Kariotta', 'Gulc', 89267, 'Marketing');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('044662534-5', 'Tully', 'Frears', 9479, 'Business Development');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('091017102-5', 'Jessamine', 'Schroder', 57828, 'Sales');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('141710652-2', 'Baryram', 'Potter', 55764, 'Product Management');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('675292034-6', 'Ewart', 'Millen', 27357, 'Legal');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('531372792-3', 'Gerta', 'Ruzek', 5161, 'Product Management');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('611492059-7', 'Lavinie', 'Srutton', 97246, 'Engineering');
insert into person (staff_id, first_name, last_name, salary, staff_dpt) values ('277059202-5', 'Berti', 'Vannoort', 7014, 'Training');

/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/* Write your answer in SQL below: */

INSERT INTO worksfor(com_id, staff_id,salary, staff_dpt)SELECT com_id, staff_id,salary, staff_dpt 
FROM company cross join person order by random() limit 1000;
