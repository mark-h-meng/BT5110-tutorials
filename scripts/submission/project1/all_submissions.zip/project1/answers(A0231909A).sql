/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
Table A describes personal information for individuals,
e.g.,id, first_name, last_name, email, gender, birthday.
Table C describes club information,
e.g.,id, club_name, email, address.
Table B describes whether individuals in Table A is a member of the clubs in Table B.
The code is written for PostgreSQL.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table person (
	id INT,
	first_name VARCHAR(50),
	last_name VARCHAR(50),
	email VARCHAR(50),
	gender VARCHAR(50),
	birthday DATE
);
create table club (
	id INT,
	club_name VARCHAR(50),
	email VARCHAR(50),
	address VARCHAR(50)
);
create table member_of (
	member_of VARCHAR(50)
);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into person (id, first_name, last_name, email, gender, birthday) values (1, 'Tobiah', 'Kacheller', 'tkacheller0@slideshare.net', 'Non-binary', '8/2/1981');
insert into person (id, first_name, last_name, email, gender, birthday) values (2, 'Flinn', 'Tuckett', 'ftuckett1@pcworld.com', 'Female', '12/25/1969');
insert into person (id, first_name, last_name, email, gender, birthday) values (3, 'Susann', 'Rodgier', 'srodgier2@sciencedaily.com', 'Genderfluid', '10/5/1955');
insert into person (id, first_name, last_name, email, gender, birthday) values (4, 'Kyle', 'Oganian', 'koganian3@yellowpages.com', 'Male', '8/19/1967');
insert into person (id, first_name, last_name, email, gender, birthday) values (5, 'Sibley', 'Sille', 'ssille4@japanpost.jp', 'Bigender', '2/21/1956');
insert into person (id, first_name, last_name, email, gender, birthday) values (6, 'Hedvige', 'Martinson', 'hmartinson5@tripadvisor.com', 'Female', '7/1/1973');
insert into person (id, first_name, last_name, email, gender, birthday) values (7, 'Bethanne', 'Yitshak', 'byitshak6@nifty.com', 'Bigender', '5/29/1967');
insert into person (id, first_name, last_name, email, gender, birthday) values (8, 'Guglielma', 'Lazell', 'glazell7@xinhuanet.com', 'Genderfluid', '5/12/2008');
insert into person (id, first_name, last_name, email, gender, birthday) values (9, 'Marena', 'Ranscome', 'mranscome8@about.com', 'Genderfluid', '8/20/1998');
insert into person (id, first_name, last_name, email, gender, birthday) values (10, 'Evin', 'de Quincey', 'edequincey9@mail.ru', 'Polygender', '7/16/1985');
insert into person (id, first_name, last_name, email, gender, birthday) values (11, 'Sigismond', 'Pochet', 'spocheta@reddit.com', 'Polygender', '3/24/1975');
insert into person (id, first_name, last_name, email, gender, birthday) values (12, 'Milka', 'Strognell', 'mstrognellb@vkontakte.ru', 'Genderfluid', '12/11/1975');
insert into person (id, first_name, last_name, email, gender, birthday) values (13, 'Clive', 'Knotte', 'cknottec@hao123.com', 'Genderqueer', '10/14/2017');
insert into person (id, first_name, last_name, email, gender, birthday) values (14, 'Valery', 'Cearley', 'vcearleyd@usgs.gov', 'Polygender', '6/18/1974');
insert into person (id, first_name, last_name, email, gender, birthday) values (15, 'Laverna', 'Fargher', 'lfarghere@fda.gov', 'Male', '5/4/1972');
insert into person (id, first_name, last_name, email, gender, birthday) values (16, 'Seymour', 'Churm', 'schurmf@wufoo.com', 'Polygender', '2/1/1951');
insert into person (id, first_name, last_name, email, gender, birthday) values (17, 'Maynard', 'Sutch', 'msutchg@seesaa.net', 'Polygender', '10/27/1967');
insert into person (id, first_name, last_name, email, gender, birthday) values (18, 'Lesley', 'Jarad', 'ljaradh@xing.com', 'Bigender', '1/13/1960');
insert into person (id, first_name, last_name, email, gender, birthday) values (19, 'Horatia', 'Angrave', 'hangravei@tuttocitta.it', 'Genderfluid', '10/23/1990');
insert into person (id, first_name, last_name, email, gender, birthday) values (20, 'Terrance', 'Lillistone', 'tlillistonej@psu.edu', 'Genderqueer', '10/13/2016');
insert into person (id, first_name, last_name, email, gender, birthday) values (21, 'Verena', 'Bolte', 'vboltek@taobao.com', 'Female', '12/10/1974');
insert into person (id, first_name, last_name, email, gender, birthday) values (22, 'Jessie', 'Bolino', 'jbolinol@istockphoto.com', 'Female', '11/1/2002');
insert into person (id, first_name, last_name, email, gender, birthday) values (23, 'Vitia', 'Adkins', 'vadkinsm@networksolutions.com', 'Bigender', '7/31/1992');
insert into person (id, first_name, last_name, email, gender, birthday) values (24, 'Tremayne', 'Espinheira', 'tespinheiran@yelp.com', 'Bigender', '8/16/2009');
insert into person (id, first_name, last_name, email, gender, birthday) values (25, 'Nicola', 'Scoular', 'nscoularo@t.co', 'Non-binary', '5/3/1966');
insert into person (id, first_name, last_name, email, gender, birthday) values (26, 'Giacobo', 'Entwisle', 'gentwislep@nature.com', 'Genderfluid', '3/31/1971');
insert into person (id, first_name, last_name, email, gender, birthday) values (27, 'Alis', 'Cupitt', 'acupittq@ameblo.jp', 'Male', '5/10/1984');
insert into person (id, first_name, last_name, email, gender, birthday) values (28, 'Dasi', 'Bowman', 'dbowmanr@sphinn.com', 'Female', '9/24/1989');
insert into person (id, first_name, last_name, email, gender, birthday) values (29, 'Galina', 'Orsman', 'gorsmans@washington.edu', 'Non-binary', '10/16/1975');
insert into person (id, first_name, last_name, email, gender, birthday) values (30, 'Dud', 'Bim', 'dbimt@ucoz.ru', 'Polygender', '7/15/1984');
insert into person (id, first_name, last_name, email, gender, birthday) values (31, 'Freeland', 'Wortman', 'fwortmanu@phpbb.com', 'Genderqueer', '6/8/1982');
insert into person (id, first_name, last_name, email, gender, birthday) values (32, 'Dode', 'Thunder', 'dthunderv@lycos.com', 'Agender', '1/9/1958');
insert into person (id, first_name, last_name, email, gender, birthday) values (33, 'Betsey', 'Tudge', 'btudgew@shareasale.com', 'Male', '10/7/2011');
insert into person (id, first_name, last_name, email, gender, birthday) values (34, 'Michail', 'Zelner', 'mzelnerx@wufoo.com', 'Bigender', '11/1/1979');
insert into person (id, first_name, last_name, email, gender, birthday) values (35, 'Madelin', 'Romans', 'mromansy@statcounter.com', 'Polygender', '3/3/2020');
insert into person (id, first_name, last_name, email, gender, birthday) values (36, 'Luigi', 'Crepel', 'lcrepelz@nsw.gov.au', 'Bigender', '1/31/1979');
insert into person (id, first_name, last_name, email, gender, birthday) values (37, 'Cloris', 'Giacoppoli', 'cgiacoppoli10@cdbaby.com', 'Female', '7/28/2017');
insert into person (id, first_name, last_name, email, gender, birthday) values (38, 'Forrest', 'Vauls', 'fvauls11@sun.com', 'Genderqueer', '11/29/2017');
insert into person (id, first_name, last_name, email, gender, birthday) values (39, 'Adolpho', 'Schorah', 'aschorah12@oaic.gov.au', 'Male', '9/13/2010');
insert into person (id, first_name, last_name, email, gender, birthday) values (40, 'Augustine', 'Wittman', 'awittman13@accuweather.com', 'Female', '9/29/1997');
insert into person (id, first_name, last_name, email, gender, birthday) values (41, 'Nicholle', 'Hugill', 'nhugill14@opensource.org', 'Genderqueer', '5/15/1991');
insert into person (id, first_name, last_name, email, gender, birthday) values (42, 'Liam', 'Cornock', 'lcornock15@google.co.jp', 'Agender', '7/4/1990');
insert into person (id, first_name, last_name, email, gender, birthday) values (43, 'Tana', 'Bushrod', 'tbushrod16@huffingtonpost.com', 'Bigender', '8/7/1983');
insert into person (id, first_name, last_name, email, gender, birthday) values (44, 'Dimitri', 'Towner', 'dtowner17@1688.com', 'Female', '7/25/2012');
insert into person (id, first_name, last_name, email, gender, birthday) values (45, 'Galven', 'Abramchik', 'gabramchik18@chicagotribune.com', 'Male', '6/12/1959');
insert into person (id, first_name, last_name, email, gender, birthday) values (46, 'Kandy', 'Neill', 'kneill19@nhs.uk', 'Bigender', '4/16/1995');
insert into person (id, first_name, last_name, email, gender, birthday) values (47, 'Mitzi', 'Sellstrom', 'msellstrom1a@cnet.com', 'Non-binary', '5/8/2009');
insert into person (id, first_name, last_name, email, gender, birthday) values (48, 'Giraldo', 'Brahan', 'gbrahan1b@tuttocitta.it', 'Male', '9/4/2010');
insert into person (id, first_name, last_name, email, gender, birthday) values (49, 'Delly', 'Cervantes', 'dcervantes1c@yahoo.com', 'Genderfluid', '2/8/1987');
insert into person (id, first_name, last_name, email, gender, birthday) values (50, 'Carolin', 'Odhams', 'codhams1d@constantcontact.com', 'Female', '11/24/1980');
insert into person (id, first_name, last_name, email, gender, birthday) values (51, 'Marcia', 'Jentges', 'mjentges1e@howstuffworks.com', 'Genderqueer', '8/20/2019');
insert into person (id, first_name, last_name, email, gender, birthday) values (52, 'Pebrook', 'Bartles', 'pbartles1f@dagondesign.com', 'Agender', '6/18/1993');
insert into person (id, first_name, last_name, email, gender, birthday) values (53, 'Corie', 'Alyokhin', 'calyokhin1g@sciencedaily.com', 'Male', '2/19/1998');
insert into person (id, first_name, last_name, email, gender, birthday) values (54, 'Allan', 'Bonsale', 'abonsale1h@tumblr.com', 'Female', '4/20/2003');
insert into person (id, first_name, last_name, email, gender, birthday) values (55, 'Gabbie', 'Napoleon', 'gnapoleon1i@msn.com', 'Bigender', '9/5/1981');
insert into person (id, first_name, last_name, email, gender, birthday) values (56, 'Brok', 'Powter', 'bpowter1j@sitemeter.com', 'Genderqueer', '3/14/1984');
insert into person (id, first_name, last_name, email, gender, birthday) values (57, 'Haily', 'Kalaher', 'hkalaher1k@sogou.com', 'Non-binary', '3/14/1957');
insert into person (id, first_name, last_name, email, gender, birthday) values (58, 'Rem', 'Langworthy', 'rlangworthy1l@biblegateway.com', 'Polygender', '10/19/2015');
insert into person (id, first_name, last_name, email, gender, birthday) values (59, 'Audrie', 'Littleton', 'alittleton1m@si.edu', 'Male', '4/1/1960');
insert into person (id, first_name, last_name, email, gender, birthday) values (60, 'Fred', 'Grimwade', 'fgrimwade1n@lulu.com', 'Genderqueer', '3/4/1965');
insert into person (id, first_name, last_name, email, gender, birthday) values (61, 'Mirella', 'Dibben', 'mdibben1o@meetup.com', 'Bigender', '4/13/2019');
insert into person (id, first_name, last_name, email, gender, birthday) values (62, 'Trisha', 'Forrestill', 'tforrestill1p@4shared.com', 'Bigender', '9/19/1968');
insert into person (id, first_name, last_name, email, gender, birthday) values (63, 'Clea', 'Snufflebottom', 'csnufflebottom1q@si.edu', 'Bigender', '2/29/1972');
insert into person (id, first_name, last_name, email, gender, birthday) values (64, 'Lon', 'Galpen', 'lgalpen1r@chronoengine.com', 'Non-binary', '8/2/1970');
insert into person (id, first_name, last_name, email, gender, birthday) values (65, 'Kessiah', 'Farragher', 'kfarragher1s@si.edu', 'Female', '2/25/1980');
insert into person (id, first_name, last_name, email, gender, birthday) values (66, 'Melosa', 'Vallender', 'mvallender1t@deliciousdays.com', 'Genderqueer', '2/9/1987');
insert into person (id, first_name, last_name, email, gender, birthday) values (67, 'Ernest', 'MacSherry', 'emacsherry1u@sourceforge.net', 'Genderqueer', '1/2/1995');
insert into person (id, first_name, last_name, email, gender, birthday) values (68, 'Nadiya', 'Reinbach', 'nreinbach1v@amazon.de', 'Non-binary', '7/5/1973');
insert into person (id, first_name, last_name, email, gender, birthday) values (69, 'Gwen', 'Dowson', 'gdowson1w@si.edu', 'Non-binary', '7/28/1977');
insert into person (id, first_name, last_name, email, gender, birthday) values (70, 'Jorrie', 'Chrismas', 'jchrismas1x@indiegogo.com', 'Non-binary', '9/23/1967');
insert into person (id, first_name, last_name, email, gender, birthday) values (71, 'Nady', 'Maciak', 'nmaciak1y@vk.com', 'Male', '6/19/1953');
insert into person (id, first_name, last_name, email, gender, birthday) values (72, 'Kathie', 'Duce', 'kduce1z@howstuffworks.com', 'Female', '12/18/1961');
insert into person (id, first_name, last_name, email, gender, birthday) values (73, 'Faina', 'Moffet', 'fmoffet20@sina.com.cn', 'Female', '1/15/1972');
insert into person (id, first_name, last_name, email, gender, birthday) values (74, 'Marisa', 'Strutley', 'mstrutley21@geocities.com', 'Agender', '11/14/1983');
insert into person (id, first_name, last_name, email, gender, birthday) values (75, 'Annecorinne', 'Lamps', 'alamps22@cnn.com', 'Male', '7/5/1974');
insert into person (id, first_name, last_name, email, gender, birthday) values (76, 'Robin', 'Arderne', 'rarderne23@devhub.com', 'Bigender', '6/11/1956');
insert into person (id, first_name, last_name, email, gender, birthday) values (77, 'Tatiana', 'Harefoot', 'tharefoot24@webs.com', 'Polygender', '6/30/2007');
insert into person (id, first_name, last_name, email, gender, birthday) values (78, 'Gavrielle', 'Rowbury', 'growbury25@163.com', 'Genderfluid', '12/8/1998');
insert into person (id, first_name, last_name, email, gender, birthday) values (79, 'Phaedra', 'Posthill', 'pposthill26@quantcast.com', 'Agender', '7/15/2016');
insert into person (id, first_name, last_name, email, gender, birthday) values (80, 'Gunar', 'Laise', 'glaise27@vistaprint.com', 'Non-binary', '2/2/2014');
insert into person (id, first_name, last_name, email, gender, birthday) values (81, 'Carlin', 'Portingale', 'cportingale28@tripadvisor.com', 'Agender', '7/23/1960');
insert into person (id, first_name, last_name, email, gender, birthday) values (82, 'Lovell', 'Winspare', 'lwinspare29@woothemes.com', 'Female', '10/8/1953');
insert into person (id, first_name, last_name, email, gender, birthday) values (83, 'Mano', 'Kirley', 'mkirley2a@washingtonpost.com', 'Bigender', '4/4/1974');
insert into person (id, first_name, last_name, email, gender, birthday) values (84, 'Gillie', 'Phillott', 'gphillott2b@blogspot.com', 'Polygender', '9/19/1984');
insert into person (id, first_name, last_name, email, gender, birthday) values (85, 'Giffard', 'Crush', 'gcrush2c@mayoclinic.com', 'Bigender', '7/19/1988');
insert into person (id, first_name, last_name, email, gender, birthday) values (86, 'Dorine', 'Avraham', 'davraham2d@irs.gov', 'Genderfluid', '11/19/1980');
insert into person (id, first_name, last_name, email, gender, birthday) values (87, 'Zia', 'Suddock', 'zsuddock2e@noaa.gov', 'Genderfluid', '8/13/2018');
insert into person (id, first_name, last_name, email, gender, birthday) values (88, 'Maritsa', 'Newiss', 'mnewiss2f@people.com.cn', 'Genderfluid', '8/21/2007');
insert into person (id, first_name, last_name, email, gender, birthday) values (89, 'Barbee', 'Braisher', 'bbraisher2g@cornell.edu', 'Non-binary', '1/6/2006');
insert into person (id, first_name, last_name, email, gender, birthday) values (90, 'Dorian', 'Hasel', 'dhasel2h@salon.com', 'Agender', '4/30/1981');
insert into person (id, first_name, last_name, email, gender, birthday) values (91, 'Shir', 'Platt', 'splatt2i@sohu.com', 'Agender', '3/24/1968');
insert into person (id, first_name, last_name, email, gender, birthday) values (92, 'Ferdie', 'Shadfourth', 'fshadfourth2j@deliciousdays.com', 'Female', '7/26/2015');
insert into person (id, first_name, last_name, email, gender, birthday) values (93, 'Mile', 'Schankelborg', 'mschankelborg2k@feedburner.com', 'Agender', '2/20/1990');
insert into person (id, first_name, last_name, email, gender, birthday) values (94, 'Melisse', 'Mapledoram', 'mmapledoram2l@flickr.com', 'Genderqueer', '8/7/1966');
insert into person (id, first_name, last_name, email, gender, birthday) values (95, 'Drusy', 'Outram', 'doutram2m@amazon.co.uk', 'Bigender', '11/24/1980');
insert into person (id, first_name, last_name, email, gender, birthday) values (96, 'Maxy', 'Aldwich', 'maldwich2n@newyorker.com', 'Polygender', '7/20/1970');
insert into person (id, first_name, last_name, email, gender, birthday) values (97, 'Kendricks', 'Mac Geaney', 'kmacgeaney2o@discovery.com', 'Agender', '3/20/2009');
insert into person (id, first_name, last_name, email, gender, birthday) values (98, 'Laryssa', 'Littledike', 'llittledike2p@fema.gov', 'Agender', '9/16/1954');
insert into person (id, first_name, last_name, email, gender, birthday) values (99, 'Frans', 'Ebbles', 'febbles2q@creativecommons.org', 'Bigender', '5/24/1956');
insert into person (id, first_name, last_name, email, gender, birthday) values (100, 'Margarita', 'Wetherick', 'mwetherick2r@icq.com', 'Polygender', '1/14/1994');

insert into club (id, club_name, email, address) values (1, 'Yvor', 'ypassey0@globo.com', '86776 Kensington Park');
insert into club (id, club_name, email, address) values (2, 'Emmalynn', 'ekenlin1@technorati.com', '647 Hauk Way');
insert into club (id, club_name, email, address) values (3, 'Erica', 'ecurry2@typepad.com', '4 Arrowood Place');
insert into club (id, club_name, email, address) values (4, 'Ambros', 'awabersich3@trellian.com', '46 Miller Place');
insert into club (id, club_name, email, address) values (5, 'Adorne', 'acongrave4@dailymotion.com', '75320 Hazelcrest Street');
insert into club (id, club_name, email, address) values (6, 'Kelcie', 'kmaulden5@reference.com', '712 Mockingbird Place');
insert into club (id, club_name, email, address) values (7, 'Bailie', 'bmcclune6@nifty.com', '78883 Hanover Street');
insert into club (id, club_name, email, address) values (8, 'Annnora', 'agrinnikov7@paypal.com', '167 Susan Drive');
insert into club (id, club_name, email, address) values (9, 'Berkie', 'bsivills8@washington.edu', '38 Warner Alley');
insert into club (id, club_name, email, address) values (10, 'Jonathan', 'jhiseman9@booking.com', '6 Atwood Court');
insert into club (id, club_name, email, address) values (11, 'Bili', 'bgosdina@squarespace.com', '1646 Gale Lane');
insert into club (id, club_name, email, address) values (12, 'Cristobal', 'cmaccrackenb@usa.gov', '27 Clove Way');
insert into club (id, club_name, email, address) values (13, 'Eleonora', 'edudeneyc@booking.com', '26292 Burrows Plaza');
insert into club (id, club_name, email, address) values (14, 'Querida', 'qstuckleyd@virginia.edu', '93 Sugar Hill');
insert into club (id, club_name, email, address) values (15, 'Bertie', 'bbuttnere@mapquest.com', '78172 Gale Center');
insert into club (id, club_name, email, address) values (16, 'Nettie', 'nmaevelaf@nydailynews.com', '242 Hauk Pass');
insert into club (id, club_name, email, address) values (17, 'Flss', 'fpetkovicg@123-reg.co.uk', '50458 Susan Circle');
insert into club (id, club_name, email, address) values (18, 'Felice', 'fblakemanh@nyu.edu', '14 Fairview Plaza');
insert into club (id, club_name, email, address) values (19, 'Angel', 'aivanitsai@about.me', '7736 Westend Park');
insert into club (id, club_name, email, address) values (20, 'Kaleb', 'kwhitmellj@va.gov', '75 Luster Road');
insert into club (id, club_name, email, address) values (21, 'Dom', 'dpuckhamk@vk.com', '3 Scofield Place');
insert into club (id, club_name, email, address) values (22, 'Noe', 'nforshawl@meetup.com', '3 Meadow Ridge Pass');
insert into club (id, club_name, email, address) values (23, 'Anstice', 'aespm@mapy.cz', '554 Westerfield Court');
insert into club (id, club_name, email, address) values (24, 'Corbet', 'cpidgleyn@amazon.co.uk', '3 Mifflin Junction');
insert into club (id, club_name, email, address) values (25, 'Vance', 'vhandkeo@indiegogo.com', '35044 Mockingbird Avenue');
insert into club (id, club_name, email, address) values (26, 'Karylin', 'kalessandrellip@freewebs.com', '3972 Jackson Lane');
insert into club (id, club_name, email, address) values (27, 'Jenilee', 'jdeleaq@spiegel.de', '2621 Washington Drive');
insert into club (id, club_name, email, address) values (28, 'Wright', 'wkymer@earthlink.net', '72677 Johnson Terrace');
insert into club (id, club_name, email, address) values (29, 'Constancy', 'cdedmans@privacy.gov.au', '5463 Scofield Center');
insert into club (id, club_name, email, address) values (30, 'Sherill', 'smatzkaitist@icio.us', '1 Waxwing Center');
insert into club (id, club_name, email, address) values (31, 'Wit', 'wolenchenkou@smugmug.com', '7827 Ilene Drive');
insert into club (id, club_name, email, address) values (32, 'Christiano', 'cgeevesv@reddit.com', '3 Lake View Court');
insert into club (id, club_name, email, address) values (33, 'Ramsey', 'rdomenicow@prweb.com', '96 Burrows Pass');
insert into club (id, club_name, email, address) values (34, 'Kizzie', 'kwornhamx@globo.com', '02 Raven Way');
insert into club (id, club_name, email, address) values (35, 'Doralia', 'dmuldrewy@amazon.de', '480 Washington Circle');
insert into club (id, club_name, email, address) values (36, 'Caril', 'cquilleashz@weebly.com', '0096 Bunker Hill Hill');
insert into club (id, club_name, email, address) values (37, 'Kyle', 'kricoald10@tamu.edu', '941 Mockingbird Lane');
insert into club (id, club_name, email, address) values (38, 'Garrek', 'glacelett11@php.net', '08 Anderson Place');
insert into club (id, club_name, email, address) values (39, 'Olivie', 'opoxon12@accuweather.com', '41 Blackbird Way');
insert into club (id, club_name, email, address) values (40, 'Carly', 'ctwigley13@google.fr', '54 Raven Way');
insert into club (id, club_name, email, address) values (41, 'Pat', 'prubel14@mashable.com', '3 Pennsylvania Road');
insert into club (id, club_name, email, address) values (42, 'Burty', 'bdowderswell15@foxnews.com', '49 Thompson Court');
insert into club (id, club_name, email, address) values (43, 'Karie', 'kotoole16@51.la', '9 Saint Paul Road');
insert into club (id, club_name, email, address) values (44, 'Grethel', 'gilett17@tmall.com', '0 Lukken Place');
insert into club (id, club_name, email, address) values (45, 'Allie', 'afaussett18@si.edu', '72225 Bonner Plaza');
insert into club (id, club_name, email, address) values (46, 'North', 'ntuny19@surveymonkey.com', '54 Esch Pass');
insert into club (id, club_name, email, address) values (47, 'Colan', 'cduffill1a@sbwire.com', '27151 Summit Avenue');
insert into club (id, club_name, email, address) values (48, 'Bevon', 'bmichelin1b@wunderground.com', '8 Paget Junction');
insert into club (id, club_name, email, address) values (49, 'Blakeley', 'bscough1c@unicef.org', '07422 Hovde Place');
insert into club (id, club_name, email, address) values (50, 'Rick', 'rflaherty1d@yahoo.com', '66522 Vidon Drive');
insert into club (id, club_name, email, address) values (51, 'Fletch', 'fbowdery1e@studiopress.com', '20620 Clyde Gallagher Terrace');
insert into club (id, club_name, email, address) values (52, 'Josefina', 'jshay1f@linkedin.com', '6 Starling Circle');
insert into club (id, club_name, email, address) values (53, 'Mae', 'mpoate1g@linkedin.com', '3 Manley Street');
insert into club (id, club_name, email, address) values (54, 'Lynnett', 'lhuc1h@ted.com', '41 Coolidge Parkway');
insert into club (id, club_name, email, address) values (55, 'Henderson', 'hhowat1i@multiply.com', '93 Meadow Ridge Park');
insert into club (id, club_name, email, address) values (56, 'Arabel', 'abartaloni1j@cornell.edu', '00 Chinook Way');
insert into club (id, club_name, email, address) values (57, 'Georgetta', 'gdymoke1k@fema.gov', '216 Harbort Crossing');
insert into club (id, club_name, email, address) values (58, 'Carie', 'clittlejohn1l@mayoclinic.com', '90357 Acker Place');
insert into club (id, club_name, email, address) values (59, 'Lulu', 'lhessing1m@usnews.com', '12624 Hollow Ridge Way');
insert into club (id, club_name, email, address) values (60, 'Marji', 'mferriby1n@nih.gov', '320 Prairie Rose Parkway');
insert into club (id, club_name, email, address) values (61, 'Hermina', 'hilbert1o@phpbb.com', '436 Trailsway Plaza');
insert into club (id, club_name, email, address) values (62, 'Daisi', 'dmarquand1p@sphinn.com', '039 Hayes Center');
insert into club (id, club_name, email, address) values (63, 'Penn', 'pdyerson1q@homestead.com', '507 Messerschmidt Center');
insert into club (id, club_name, email, address) values (64, 'Doti', 'dmcnalley1r@army.mil', '40 Maple Wood Point');
insert into club (id, club_name, email, address) values (65, 'Prent', 'pattryde1s@zdnet.com', '5578 Maple Park');
insert into club (id, club_name, email, address) values (66, 'Kyle', 'kdegoey1t@bravesites.com', '2270 Eagle Crest Lane');
insert into club (id, club_name, email, address) values (67, 'Georgi', 'grosbrough1u@infoseek.co.jp', '51 North Lane');
insert into club (id, club_name, email, address) values (68, 'Lexie', 'ldinsale1v@mayoclinic.com', '758 Kinsman Place');
insert into club (id, club_name, email, address) values (69, 'Howey', 'htremberth1w@hud.gov', '3493 Iowa Center');
insert into club (id, club_name, email, address) values (70, 'Lola', 'llinder1x@spotify.com', '05736 Sherman Park');
insert into club (id, club_name, email, address) values (71, 'Anna-diana', 'acathcart1y@slate.com', '976 Raven Terrace');
insert into club (id, club_name, email, address) values (72, 'Carita', 'ckerne1z@howstuffworks.com', '507 Forest Court');
insert into club (id, club_name, email, address) values (73, 'Penelope', 'ppessler20@ocn.ne.jp', '40 Almo Court');
insert into club (id, club_name, email, address) values (74, 'Candis', 'cjoel21@ask.com', '5014 Artisan Trail');
insert into club (id, club_name, email, address) values (75, 'Gwendolyn', 'gkale22@bing.com', '47982 Kings Crossing');
insert into club (id, club_name, email, address) values (76, 'Leona', 'ldorrian23@umich.edu', '62484 Morningstar Junction');
insert into club (id, club_name, email, address) values (77, 'Zaccaria', 'zslidders24@yellowpages.com', '53951 Gale Plaza');
insert into club (id, club_name, email, address) values (78, 'Zorana', 'zcollins25@unblog.fr', '2 Claremont Circle');
insert into club (id, club_name, email, address) values (79, 'Kelley', 'kstarbuck26@mozilla.com', '2 Golden Leaf Center');
insert into club (id, club_name, email, address) values (80, 'Wilhelmine', 'wvittore27@sohu.com', '53050 Haas Parkway');
insert into club (id, club_name, email, address) values (81, 'Carmella', 'cdougliss28@tumblr.com', '02 Forster Street');
insert into club (id, club_name, email, address) values (82, 'Stephi', 'stallyn29@multiply.com', '5 Garrison Parkway');
insert into club (id, club_name, email, address) values (83, 'Aurel', 'adunstan2a@kickstarter.com', '5 5th Terrace');
insert into club (id, club_name, email, address) values (84, 'Marion', 'mstirrup2b@opensource.org', '4 Farmco Street');
insert into club (id, club_name, email, address) values (85, 'Bernete', 'bbolter2c@github.io', '7849 Old Shore Street');
insert into club (id, club_name, email, address) values (86, 'Aretha', 'abrosch2d@sakura.ne.jp', '1195 Shasta Terrace');
insert into club (id, club_name, email, address) values (87, 'Yetty', 'yorrah2e@shop-pro.jp', '534 Dawn Way');
insert into club (id, club_name, email, address) values (88, 'Nikolos', 'nrosenberg2f@dailymail.co.uk', '4057 Warbler Street');
insert into club (id, club_name, email, address) values (89, 'Krisha', 'kdudman2g@nba.com', '03 Cottonwood Junction');
insert into club (id, club_name, email, address) values (90, 'Hedwiga', 'hkopelman2h@irs.gov', '1363 Iowa Place');
insert into club (id, club_name, email, address) values (91, 'Blythe', 'bbielefeld2i@tripod.com', '940 Golf Terrace');
insert into club (id, club_name, email, address) values (92, 'Pembroke', 'pholmes2j@hc360.com', '9 Loftsgordon Way');
insert into club (id, club_name, email, address) values (93, 'Perkin', 'psawell2k@redcross.org', '8 Lake View Junction');
insert into club (id, club_name, email, address) values (94, 'Daryle', 'dluard2l@paginegialle.it', '45029 Spaight Crossing');
insert into club (id, club_name, email, address) values (95, 'Wilow', 'wcadigan2m@cbsnews.com', '60 School Place');
insert into club (id, club_name, email, address) values (96, 'Angel', 'afawlkes2n@wordpress.org', '4577 Manitowish Crossing');
insert into club (id, club_name, email, address) values (97, 'Josie', 'jmccrae2o@squarespace.com', '9 Ruskin Terrace');
insert into club (id, club_name, email, address) values (98, 'Tull', 'taaron2p@cargocollective.com', '9 Meadow Ridge Pass');
insert into club (id, club_name, email, address) values (99, 'Cole', 'cduffill2q@biglobe.ne.jp', '4333 Meadow Ridge Place');
insert into club (id, club_name, email, address) values (100, 'Findlay', 'fspottswood2r@reference.com', '234 Lake View Road');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into member_of
select * from person, club order by random() limit 1000;