/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/



/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */



/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Imagine you work at Spotify and you want to know what songs of your platform people listen to in each country.
We choose the entity set E_1 to be "client", the entity set E_2 to be "song", and the many-to-many relationship set R to be "listensto".
The attributes of "client" are:
- client_id, the identification number of the client
- pseudo, the pseudoname of the client, which has to be unique
- first_name
- last_name
- email
- country, for the nationality of the client
The attributes of "song" are:
- title_id
- title
- artist
- country
The attributes of "listensto" are:
- client_id
- title_id
There is no need to add other features to the table "listensto" from the other tables, as they can be deduced from client_id or title_id.
*/



/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/

CREATE TABLE IF NOT EXISTS client ( 
    client_id VARCHAR(16) PRIMARY KEY,
    pseudo VARCHAR(64) UNIQUE NOT NULL, 
    first_name VARCHAR(64) NOT NULL, 
    last_name VARCHAR(64) NOT NULL, 
    email VARCHAR(64) UNIQUE NOT NULL, 
    country VARCHAR(64) NOT NULL 
);

CREATE TABLE IF NOT EXISTS song ( 
    title_id VARCHAR(16) PRIMARY KEY, 
    title VARCHAR(64) NOT NULL, 
    artist VARCHAR(64) NOT NULL, 
    country VARCHAR(64) NOT NULL 
);

CREATE TABLE IF NOT EXISTS listensto ( 
    client_id VARCHAR(64) REFERENCES client(client_id)
        ON UPDATE CASCADE ON DELETE CASCADE
        DEFERRABLE INITIALLY DEFERRED, 
    title_id VARCHAR(16), 
    PRIMARY KEY(client_id, title_id),
    FOREIGN KEY (title_id) REFERENCES song(title_id)
        ON UPDATE CASCADE ON DELETE CASCADE
        DEFERRABLE INITIALLY DEFERRED
);



/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/

/************************************************************************/
/* We populate the table client: */
/************************************************************************/
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        1, 'ediiorio0', 'Estel', 'Di Iorio', 'ediiorio0@yellowbook.com', 'Thailand'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        2, 'hdarlington1', 'Hollie', 'Darlington', 'hdarlington1@census.gov', 'Russia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        3, 'ssimkovitz2', 'Simone', 'Simkovitz', 'ssimkovitz2@studiopress.com', 'China'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        4, 'rkapelhof3', 'Royal', 'Kapelhof', 'rkapelhof3@diigo.com', 'Kazakhstan'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        5, 'scharlesworth4', 'Shelton', 'Charlesworth', 'scharlesworth4@bing.com', 'China'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        6, 'mweyland5', 'Mahala', 'Weyland', 'mweyland5@latimes.com', 'Philippines'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        7, 'wcoling6', 'Winna', 'Coling', 'wcoling6@hhs.gov', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        8, 'jpyser7', 'Jacinta', 'Pyser', 'jpyser7@unc.edu', 'China'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        9, 'ipalay8', 'Igor', 'Palay', 'ipalay8@sphinn.com', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        10, 'vancketill9', 'Viviene', 'Ancketill', 'vancketill9@ftc.gov', 'Poland'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        11, 'wpargetera', 'Winifred', 'Pargeter', 'wpargetera@facebook.com', 'France'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        12, 'tbleazardb', 'Thomasin', 'Bleazard', 'tbleazardb@walmart.com', 'China'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        13, 'wdeniseauc', 'Weidar', 'Deniseau', 'wdeniseauc@usgs.gov', 'Czech Republic'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        14, 'qtreaced', 'Quinn', 'Treace', 'qtreaced@nydailynews.com', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        15, 'pdwyere', 'Pooh', 'Dwyer', 'pdwyere@seattletimes.com', 'Portugal'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        16, 'jsheweryf', 'Javier', 'Shewery', 'jsheweryf@ning.com', 'China'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        17, 'aodyvoieg', 'Asia', 'O''Dyvoie', 'aodyvoieg@csmonitor.com', 'Cuba'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        18, 'eboanash', 'Elna', 'Boanas', 'eboanash@google.ca', 'Netherlands'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        19, 'jclapstoni', 'Jackelyn', 'Clapston', 'jclapstoni@mozilla.org', 'Peru'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        20, 'hsalmanj', 'Heloise', 'Salman', 'hsalmanj@zimbio.com', 'Afghanistan'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        21, 'tribchesterk', 'Teena', 'Ribchester', 'tribchesterk@indiatimes.com', 'Portugal'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        22, 'pwagstaffl', 'Pooh', 'Wagstaff', 'pwagstaffl@toplist.cz', 'Chile'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        23, 'rratem', 'Rycca', 'Rate', 'rratem@independent.co.uk', 'Thailand'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        24, 'mferrieroin', 'Marcela', 'Ferrieroi', 'mferrieroin@typepad.com', 'Portugal'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        25, 'ckleslo', 'Cirstoforo', 'Klesl', 'ckleslo@nhs.uk', 'Japan'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        26, 'lfairep', 'Lilly', 'Faire', 'lfairep@webeden.co.uk', 'China'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        27, 'cmattioliq', 'Cully', 'Mattioli', 'cmattioliq@mozilla.org', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        28, 'eritzmanr', 'Ertha', 'Ritzman', 'eritzmanr@artisteer.com', 'Poland'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        29, 'swhitcombes', 'Skipp', 'Whitcombe', 'swhitcombes@blogspot.com', 'Philippines'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        30, 'lwigsellt', 'Link', 'Wigsell', 'lwigsellt@diigo.com', 'China'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        31, 'jalwoodu', 'Jeremias', 'Alwood', 'jalwoodu@wiley.com', 'Serbia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        32, 'abedenv', 'Aldus', 'Beden', 'abedenv@163.com', 'Japan'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        33, 'eorteauw', 'Emerson', 'Orteau', 'eorteauw@pen.io', 'Sweden'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        34, 'dharbronx', 'Deanne', 'Harbron', 'dharbronx@nifty.com', 'Lithuania'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        35, 'eosichevy', 'Elena', 'Osichev', 'eosichevy@alibaba.com', 'Ecuador'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        36, 'rcromerz', 'Robina', 'Cromer', 'rcromerz@amazon.co.uk', 'Nepal'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        37, 'asarge10', 'Anitra', 'Sarge', 'asarge10@zimbio.com', 'Philippines'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        38, 'gkilner11', 'Gipsy', 'Kilner', 'gkilner11@istockphoto.com', 'China'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        39, 'aringer12', 'Anna-diane', 'Ringer', 'aringer12@google.nl', 'Colombia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        40, 'atalbot13', 'Alphonse', 'Talbot', 'atalbot13@newyorker.com', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        41, 'spollicote14', 'Shaine', 'Pollicote', 'spollicote14@msu.edu', 'Poland'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        42, 'bcuttles15', 'Barny', 'Cuttles', 'bcuttles15@free.fr', 'Poland'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        43, 'aferreira16', 'Aubrey', 'Ferreira', 'aferreira16@bloglovin.com', 'Lesotho'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        44, 'abaythorp17', 'Aurlie', 'Baythorp', 'abaythorp17@prlog.org', 'Saint Martin'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        45, 'dthews18', 'Daniela', 'Thews', 'dthews18@taobao.com', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        46, 'isarch19', 'Iggie', 'Sarch', 'isarch19@bloglines.com', 'Portugal'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        47, 'aanstice1a', 'Alysia', 'Anstice', 'aanstice1a@yellowpages.com', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        48, 'gsize1b', 'Glen', 'Size', 'gsize1b@mail.ru', 'South Africa'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        49, 'fmarkus1c', 'Felizio', 'Markus', 'fmarkus1c@opera.com', 'Argentina'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        50, 'hbrisseau1d', 'Holt', 'Brisseau', 'hbrisseau1d@unicef.org', 'South Africa'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        51, 'calishoner1e', 'Clerissa', 'Alishoner', 'calishoner1e@hugedomains.com', 'Philippines'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        52, 'csheal1f', 'Corine', 'Sheal', 'csheal1f@baidu.com', 'Czech Republic'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        53, 'tpinchen1g', 'Thorstein', 'Pinchen', 'tpinchen1g@wsj.com', 'China'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        54, 'jstroband1h', 'Jermain', 'Stroband', 'jstroband1h@google.co.uk', 'Sweden'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        55, 'ibanbrook1i', 'Iver', 'Banbrook', 'ibanbrook1i@altervista.org', 'China'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        56, 'fbeaulieu1j', 'Farlie', 'Beaulieu', 'fbeaulieu1j@icio.us', 'Canada'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        57, 'tluebbert1k', 'Theo', 'Luebbert', 'tluebbert1k@blinklist.com', 'Peru'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        58, 'cbewfield1l', 'Catherin', 'Bewfield', 'cbewfield1l@mediafire.com', 'Philippines'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        59, 'dtooze1m', 'Dre', 'Tooze', 'dtooze1m@ed.gov', 'France'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        60, 'cmcnirlan1n', 'Corinne', 'McNirlan', 'cmcnirlan1n@printfriendly.com', 'Tanzania'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        61, 'rtooley1o', 'Rena', 'Tooley', 'rtooley1o@unblog.fr', 'Czech Republic'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        62, 'vbauduin1p', 'Vinita', 'Bauduin', 'vbauduin1p@chron.com', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        63, 'arichards1q', 'Arabele', 'Richards', 'arichards1q@mail.ru', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        64, 'dricards1r', 'Donetta', 'Ricards', 'dricards1r@twitter.com', 'Belarus'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        65, 'igetcliffe1s', 'Ignazio', 'Getcliffe', 'igetcliffe1s@opensource.org', 'Burkina Faso'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        66, 'bcromly1t', 'Bram', 'Cromly', 'bcromly1t@google.nl', 'China'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        67, 'tganning1u', 'Torrance', 'Ganning', 'tganning1u@nsw.gov.au', 'Sudan'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        68, 'rsantarelli1v', 'Rock', 'Santarelli', 'rsantarelli1v@freewebs.com', 'China'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        69, 'aseeger1w', 'Allie', 'Seeger', 'aseeger1w@unblog.fr', 'Belarus'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        70, 'kscrowton1x', 'Karolina', 'Scrowton', 'kscrowton1x@hibu.com', 'Israel'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        71, 'jnassie1y', 'Jeri', 'Nassie', 'jnassie1y@slashdot.org', 'Russia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        72, 'gjanikowski1z', 'Griz', 'Janikowski', 'gjanikowski1z@nps.gov', 'Russia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        73, 'sodunniom20', 'Simona', 'O''Dunniom', 'sodunniom20@patch.com', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        74, 'gsnufflebottom21', 'Giffard', 'Snufflebottom', 'gsnufflebottom21@wp.com', 'Finland'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        75, 'mfivey22', 'Melantha', 'Fivey', 'mfivey22@baidu.com', 'Colombia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        76, 'jeverex23', 'Jim', 'Everex', 'jeverex23@cbsnews.com', 'Mauritius'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        77, 'scatlette24', 'Shaughn', 'Catlette', 'scatlette24@amazonaws.com', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        78, 'estreak25', 'Elva', 'Streak', 'estreak25@dyndns.org', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        79, 'mbrunet26', 'Melisenda', 'Brunet', 'mbrunet26@wordpress.org', 'Brazil'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        80, 'bsmitherman27', 'Bryanty', 'Smitherman', 'bsmitherman27@seattletimes.com', 'Cuba'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        81, 'omathan28', 'Olive', 'Mathan', 'omathan28@lulu.com', 'Austria'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        82, 'zfranssen29', 'Zia', 'Franssen', 'zfranssen29@4shared.com', 'Czech Republic'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        83, 'nmclarnon2a', 'Nolly', 'McLarnon', 'nmclarnon2a@hostgator.com', 'China'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        84, 'imacdearmont2b', 'Inigo', 'MacDearmont', 'imacdearmont2b@storify.com', 'Philippines'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        85, 'dhards2c', 'Diane-marie', 'Hards', 'dhards2c@printfriendly.com', 'Brazil'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        86, 'kgehrels2d', 'Kalila', 'Gehrels', 'kgehrels2d@whitehouse.gov', 'Honduras'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        87, 'ahardstaff2e', 'Antonino', 'Hardstaff', 'ahardstaff2e@goo.ne.jp', 'Somalia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        88, 'balliker2f', 'Bertha', 'Alliker', 'balliker2f@ifeng.com', 'Honduras'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        89, 'ahaslegrave2g', 'Alysia', 'Haslegrave', 'ahaslegrave2g@behance.net', 'Iran'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        90, 'kszymoni2h', 'Kaleena', 'Szymoni', 'kszymoni2h@earthlink.net', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        91, 'zmcroberts2i', 'Zared', 'McRoberts', 'zmcroberts2i@theguardian.com', 'Greece'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        92, 'htoppin2j', 'Hadley', 'Toppin', 'htoppin2j@businessweek.com', 'China'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        93, 'jwapplington2k', 'Jacki', 'Wapplington', 'jwapplington2k@dell.com', 'Argentina'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        94, 'pferenczi2l', 'Pegeen', 'Ferenczi', 'pferenczi2l@kickstarter.com', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        95, 'sdrewell2m', 'Sherlocke', 'Drewell', 'sdrewell2m@google.com.au', 'South Africa'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        96, 'wbartlam2n', 'Wood', 'Bartlam', 'wbartlam2n@hc360.com', 'Poland'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        97, 'bcassels2o', 'Brittan', 'Cassels', 'bcassels2o@japanpost.jp', 'Russia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        98, 'kbees2p', 'Kalli', 'Bees', 'kbees2p@businesswire.com', 'Russia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        99, 'jmclae2q', 'Jessi', 'McLae', 'jmclae2q@ibm.com', 'Indonesia'
    )
;
INSERT INTO
    client (client_id, pseudo, first_name, last_name, email, country) 
VALUES
    (
        100, 'cprewer2r', 'Charleen', 'Prewer', 'cprewer2r@soup.io', 'Mozambique'
    )
;



/************************************************************************/
/* We populate the table song: */
/************************************************************************/
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        1, 'venenatis tristique fusce', 'Doralyn', 'China'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        2, 'quisque arcu', 'Berni', 'Philippines'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        3, 'etiam vel', 'Datha', 'Brazil'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        4, 'dictumst etiam', 'Gallard', 'Uganda'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        5, 'lorem integer', 'Dirk', 'Portugal'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        6, 'pede', 'Sileas', 'China'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        7, 'sit amet justo', 'Chrissie', 'Netherlands'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        8, 'purus sit amet', 'Twyla', 'Ukraine'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        9, 'morbi porttitor lorem id', 'Ester', 'Brazil'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        10, 'integer pede justo lacinia eget', 'Martynne', 'Colombia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        11, 'primis in faucibus orci luctus', 'Babbette', 'Indonesia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        12, 'amet nunc viverra dapibus', 'Juliette', 'Tanzania'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        13, 'libero convallis eget eleifend luctus', 'Patty', 'China'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        14, 'habitasse', 'Kale', 'Philippines'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        15, 'eleifend', 'Hunfredo', 'China'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        16, 'sit amet lobortis sapien', 'Sloan', 'Sweden'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        17, 'et', 'Corissa', 'China'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        18, 'nulla nisl nunc', 'Eydie', 'Philippines'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        19, 'amet eleifend pede libero', 'Coralie', 'Japan'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        20, 'aenean', 'Erna', 'Armenia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        21, 'etiam', 'Dalila', 'Brazil'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        22, 'in hac', 'Eba', 'Brazil'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        23, 'in hac habitasse platea', 'Selle', 'Armenia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        24, 'lobortis convallis tortor', 'Denys', 'Democratic Republic of the Congo'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        25, 'scelerisque mauris', 'Chrisse', 'Czech Republic'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        26, 'id', 'Hervey', 'Argentina'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        27, 'sem duis aliquam convallis', 'Burch', 'Indonesia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        28, 'mattis pulvinar nulla pede ullamcorper', 'Chick', 'United States'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        29, 'morbi a ipsum integer', 'Tabbitha', 'Indonesia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        30, 'felis', 'Valencia', 'Indonesia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        31, 'sed tristique in tempus', 'Anastasie', 'Gabon'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        32, 'morbi vestibulum', 'Lisha', 'Poland'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        33, 'mauris', 'Cybill', 'France'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        34, 'nam ultrices libero', 'Tomi', 'Sweden'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        35, 'in eleifend', 'Caryn', 'Indonesia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        36, 'et', 'Flossie', 'New Zealand'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        37, 'rutrum nulla nunc purus phasellus', 'Alfonse', 'France'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        38, 'pellentesque', 'Adah', 'France'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        39, 'sit amet consectetuer adipiscing elit', 'Rebbecca', 'United States'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        40, 'in lectus pellentesque at nulla', 'Vanny', 'China'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        41, 'lectus', 'Zorine', 'Greece'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        42, 'faucibus orci', 'Ardith', 'Poland'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        43, 'quam sollicitudin vitae', 'Idalia', 'United States'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        44, 'vulputate nonummy', 'Valida', 'Japan'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        45, 'ante ipsum primis in faucibus', 'Gina', 'Argentina'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        46, 'aliquet', 'Odessa', 'Egypt'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        47, 'porttitor lorem', 'Jania', 'Argentina'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        48, 'id ligula suspendisse', 'Oby', 'Pakistan'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        49, 'consequat metus', 'Jordan', 'Chad'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        50, 'maecenas tincidunt lacus at velit', 'Abagael', 'Moldova'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        51, 'ac neque duis bibendum morbi', 'Gus', 'Indonesia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        52, 'placerat praesent blandit nam nulla', 'Nalani', 'Indonesia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        53, 'quisque arcu libero rutrum', 'Alayne', 'Indonesia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        54, 'dictumst maecenas ut', 'Smitty', 'Serbia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        55, 'vel dapibus at diam', 'Claresta', 'Indonesia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        56, 'turpis', 'Osmond', 'Mexico'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        57, 'pulvinar', 'Milzie', 'Czech Republic'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        58, 'eros vestibulum ac est lacinia', 'Margot', 'Brazil'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        59, 'elementum pellentesque', 'Fran', 'Thailand'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        60, 'sit', 'Wilek', 'Czech Republic'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        61, 'tincidunt', 'Alasteir', 'France'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        62, 'justo pellentesque viverra', 'Meier', 'Sweden'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        63, 'id luctus nec molestie', 'Juline', 'Poland'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        64, 'pellentesque ultrices phasellus', 'Onida', 'Philippines'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        65, 'lobortis ligula', 'Benito', 'Portugal'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        66, 'luctus rutrum', 'Meade', 'Netherlands'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        67, 'nec sem', 'Tarrance', 'Norway'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        68, 'lorem', 'Corby', 'Indonesia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        69, 'posuere', 'Hallie', 'Brazil'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        70, 'penatibus et magnis dis', 'Vivia', 'France'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        71, 'vestibulum ante', 'Kandy', 'Sweden'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        72, 'in faucibus orci', 'Mahmoud', 'Russia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        73, 'mus', 'Ida', 'Mauritius'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        74, 'non quam nec dui', 'Phaidra', 'Honduras'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        75, 'magna ac', 'Clair', 'China'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        76, 'elementum in', 'Riley', 'Azerbaijan'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        77, 'accumsan', 'Zsazsa', 'Macedonia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        78, 'felis donec semper sapien', 'Cynde', 'Thailand'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        79, 'vulputate justo', 'Dulcine', 'Philippines'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        80, 'mi sit amet', 'Roley', 'Guatemala'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        81, 'enim sit', 'Tandy', 'Malaysia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        82, 'mauris sit amet eros suspendisse', 'Cristi', 'Democratic Republic of the Congo'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        83, 'nunc rhoncus', 'Anatola', 'France'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        84, 'aliquam augue', 'Kelila', 'China'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        85, 'proin interdum', 'Alana', 'China'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        86, 'nonummy integer', 'Bent', 'Malawi'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        87, 'porttitor lacus at', 'Chrisse', 'United Arab Emirates'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        88, 'dapibus augue vel accumsan tellus', 'Elli', 'Estonia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        89, 'fermentum donec ut mauris eget', 'Peg', 'China'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        90, 'dapibus dolor', 'Stefan', 'South Korea'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        91, 'nulla suspendisse potenti cras in', 'Myrtice', 'China'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        92, 'orci eget', 'Karly', 'Croatia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        93, 'sed', 'Stacy', 'China'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        94, 'posuere cubilia', 'Valina', 'Myanmar'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        95, 'aliquam erat volutpat in congue', 'Rebe', 'Canada'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        96, 'vivamus', 'Gris', 'Indonesia'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        97, 'tortor eu pede', 'Emlyn', 'Mexico'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        98, 'potenti cras in purus', 'Colas', 'France'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        99, 'at dolor quis odio consequat', 'Lester', 'Nigeria'
    )
;
INSERT INTO
    song (title_id, title, artist, country) 
VALUES
    (
        100, 'lectus pellentesque eget nunc', 'Desmond', 'Uganda'
    )
;



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/

INSERT INTO
    listensto (client_id, title_id) 
    SELECT
        c.client_id,
        s.title_id 
    FROM
        client c,
        song s 
    ORDER BY
        RANDOM() LIMIT 1000 ;