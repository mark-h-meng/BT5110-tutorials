/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/* ZENG JIAQI   Student ID: A0231867X                                   */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/

/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
Three tables have been created, for they are client, medicine and prescription respectively.
I assume that the entity set E1 to be client, the entity set E2 to be medicine, 
and the optional many-to-many relationship set R to be prescription.
The client table include the patient's id, first name, last name, email adress and phone number.
The medicine table include the drug's fda_code, name and the company.
The prescription table include the client's id and the code of drug they bought.

Once again, the code is written for PostgreSQL.  
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

create table client (
  id VARCHAR(50) primary key, 
  first_name VARCHAR(50) not null, 
  last_name VARCHAR(50), 
  email VARCHAR(50), 
  phone VARCHAR(50) not null
);


create table medicine (
  fda_code VARCHAR(50) primary key, 
  drug_name VARCHAR(100) not null, 
  drug_company VARCHAR(100)
);


create table PRESCRIPTION (
  client_id VARCHAR(50) not null references client(id), 
  drug_id VARCHAR(50) not null references medicine(fda_code)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


/* populate table client */

insert into client (id, first_name, last_name, email, phone) values ('91-5502630', 'Catlaina', 'Messum', 'cmessum0@narod.ru', '329-535-2060');
insert into client (id, first_name, last_name, email, phone) values ('00-3869245', 'Stefa', 'Lovatt', 'slovatt1@plala.or.jp', '972-880-0793');
insert into client (id, first_name, last_name, email, phone) values ('60-2485799', 'Angelico', 'Cotmore', 'acotmore2@amazonaws.com', '373-923-0554');
insert into client (id, first_name, last_name, email, phone) values ('73-8468185', 'Oliver', 'Bert', 'obert3@seattletimes.com', '814-276-4805');
insert into client (id, first_name, last_name, email, phone) values ('42-6284396', 'Red', 'Josephov', 'rjosephov4@tumblr.com', '268-450-1695');
insert into client (id, first_name, last_name, email, phone) values ('54-9005097', 'Stephanus', 'Drinkhill', 'sdrinkhill5@moonfruit.com', '989-601-4855');
insert into client (id, first_name, last_name, email, phone) values ('65-3646143', 'Kain', 'Lapthorne', 'klapthorne6@timesonline.co.uk', '681-220-5068');
insert into client (id, first_name, last_name, email, phone) values ('06-8450264', 'Isidoro', 'Rodell', 'irodell7@amazonaws.com', '428-545-7293');
insert into client (id, first_name, last_name, email, phone) values ('32-9595130', 'Bartel', 'Peaden', 'bpeaden8@webeden.co.uk', '709-914-2463');
insert into client (id, first_name, last_name, email, phone) values ('78-3136541', 'Guglielmo', 'Eagleston', 'geagleston9@jalbum.net', '392-182-5674');
insert into client (id, first_name, last_name, email, phone) values ('88-3058944', 'Kayne', 'Jenman', 'kjenmana@netlog.com', '896-195-1562');
insert into client (id, first_name, last_name, email, phone) values ('47-7963530', 'Laurel', 'Tansill', 'ltansillb@is.gd', '219-171-3895');
insert into client (id, first_name, last_name, email, phone) values ('38-9467012', 'Shalne', 'Churchley', 'schurchleyc@infoseek.co.jp', '239-930-0711');
insert into client (id, first_name, last_name, email, phone) values ('94-6254282', 'Niki', 'Kemp', 'nkempd@barnesandnoble.com', '152-670-5256');
insert into client (id, first_name, last_name, email, phone) values ('21-8443323', 'Chery', 'Hilley', 'chilleye@google.de', '164-920-6079');
insert into client (id, first_name, last_name, email, phone) values ('02-1602737', 'Astrix', 'Simko', 'asimkof@yellowpages.com', '186-408-7589');
insert into client (id, first_name, last_name, email, phone) values ('02-9011444', 'Regen', 'Spinelli', 'rspinellig@technorati.com', '356-393-9727');
insert into client (id, first_name, last_name, email, phone) values ('98-0894633', 'Lavinie', 'Peschet', 'lpescheth@desdev.cn', '871-532-6863');
insert into client (id, first_name, last_name, email, phone) values ('16-3544354', 'Merla', 'Libero', 'mliberoi@ning.com', '231-338-2982');
insert into client (id, first_name, last_name, email, phone) values ('74-9973744', 'Henryetta', 'Bremeyer', 'hbremeyerj@oracle.com', '514-969-1595');
insert into client (id, first_name, last_name, email, phone) values ('15-9755676', 'Allan', 'Slimming', 'aslimmingk@fema.gov', '834-108-8450');
insert into client (id, first_name, last_name, email, phone) values ('70-8143005', 'Bear', 'Howatt', 'bhowattl@blogs.com', '582-799-3325');
insert into client (id, first_name, last_name, email, phone) values ('23-2026191', 'Mary', 'Jimeno', 'mjimenom@cnbc.com', '823-405-9209');
insert into client (id, first_name, last_name, email, phone) values ('95-3193948', 'Andras', 'Clavey', 'aclaveyn@creativecommons.org', '586-981-4575');
insert into client (id, first_name, last_name, email, phone) values ('32-6566923', 'Bernard', 'Francey', 'bfranceyo@globo.com', '486-116-2273');
insert into client (id, first_name, last_name, email, phone) values ('00-3670442', 'Min', 'Dancer', 'mdancerp@netlog.com', '215-678-3774');
insert into client (id, first_name, last_name, email, phone) values ('77-3686205', 'Hatty', 'Dikle', 'hdikleq@about.me', '946-773-5799');
insert into client (id, first_name, last_name, email, phone) values ('10-3837728', 'Risa', 'Peatman', 'rpeatmanr@elegantthemes.com', '844-259-0675');
insert into client (id, first_name, last_name, email, phone) values ('77-4027975', 'Brand', 'Bertl', 'bbertls@cbsnews.com', '328-889-2170');
insert into client (id, first_name, last_name, email, phone) values ('35-3253150', 'Freddi', 'Sanderson', 'fsandersont@miibeian.gov.cn', '119-402-8193');
insert into client (id, first_name, last_name, email, phone) values ('42-0569134', 'Janot', 'Jaspar', 'jjasparu@myspace.com', '519-794-0961');
insert into client (id, first_name, last_name, email, phone) values ('25-7077445', 'Rutter', 'Scrace', 'rscracev@webeden.co.uk', '222-111-7592');
insert into client (id, first_name, last_name, email, phone) values ('57-9716637', 'Wain', 'Rosso', 'wrossow@sphinn.com', '386-881-1342');
insert into client (id, first_name, last_name, email, phone) values ('69-9625437', 'Sonia', 'Knobell', 'sknobellx@howstuffworks.com', '504-406-2798');
insert into client (id, first_name, last_name, email, phone) values ('52-7617083', 'Emma', 'Pranger', 'eprangery@example.com', '252-389-3403');
insert into client (id, first_name, last_name, email, phone) values ('97-2932533', 'Leshia', 'Hamnet', 'lhamnetz@multiply.com', '211-389-6070');
insert into client (id, first_name, last_name, email, phone) values ('48-8938808', 'Devora', 'Polkinghorne', 'dpolkinghorne10@multiply.com', '145-252-5131');
insert into client (id, first_name, last_name, email, phone) values ('97-8003784', 'Devland', 'Fumagallo', 'dfumagallo11@dedecms.com', '597-204-5613');
insert into client (id, first_name, last_name, email, phone) values ('00-9692648', 'Kris', 'Sackur', 'ksackur12@businessweek.com', '696-241-4614');
insert into client (id, first_name, last_name, email, phone) values ('95-0194379', 'Sharona', 'Beniesh', 'sbeniesh13@ameblo.jp', '146-334-3118');
insert into client (id, first_name, last_name, email, phone) values ('61-4765442', 'Rahal', 'Crutcher', 'rcrutcher14@pinterest.com', '639-344-6179');
insert into client (id, first_name, last_name, email, phone) values ('70-3868067', 'Delilah', 'Raper', 'draper15@unicef.org', '567-405-2479');
insert into client (id, first_name, last_name, email, phone) values ('68-3655521', 'Bevon', 'McGookin', 'bmcgookin16@cnet.com', '765-467-0880');
insert into client (id, first_name, last_name, email, phone) values ('07-7781224', 'Caroline', 'Bearcock', 'cbearcock17@cafepress.com', '221-673-4606');
insert into client (id, first_name, last_name, email, phone) values ('60-4262197', 'Nikki', 'Ragbourne', 'nragbourne18@sciencedaily.com', '943-255-9093');
insert into client (id, first_name, last_name, email, phone) values ('25-0807107', 'Alford', 'McVicker', 'amcvicker19@shinystat.com', '832-178-6145');
insert into client (id, first_name, last_name, email, phone) values ('37-2052561', 'Ibrahim', 'Rogister', 'irogister1a@smugmug.com', '194-658-0110');
insert into client (id, first_name, last_name, email, phone) values ('29-2796530', 'Barth', 'Scown', 'bscown1b@ted.com', '986-141-0493');
insert into client (id, first_name, last_name, email, phone) values ('30-7247392', 'Reg', 'Jedryka', 'rjedryka1c@youtu.be', '364-900-7530');
insert into client (id, first_name, last_name, email, phone) values ('46-1703654', 'Morly', 'Lukins', 'mlukins1d@nhs.uk', '660-962-3174');
insert into client (id, first_name, last_name, email, phone) values ('49-6162368', 'Barde', 'McFade', 'bmcfade1e@youku.com', '551-880-4981');
insert into client (id, first_name, last_name, email, phone) values ('89-6018593', 'Neile', 'Tourle', 'ntourle1f@arizona.edu', '929-521-6434');
insert into client (id, first_name, last_name, email, phone) values ('15-0224361', 'Siffre', 'Castro', 'scastro1g@linkedin.com', '930-665-2814');
insert into client (id, first_name, last_name, email, phone) values ('52-2298060', 'Felipa', 'Bausmann', 'fbausmann1h@pcworld.com', '795-589-1595');
insert into client (id, first_name, last_name, email, phone) values ('70-0412297', 'Casar', 'Chaunce', 'cchaunce1i@pcworld.com', '718-350-3369');
insert into client (id, first_name, last_name, email, phone) values ('78-0444095', 'Ailey', 'Bell', 'abell1j@list-manage.com', '422-770-5735');
insert into client (id, first_name, last_name, email, phone) values ('48-4511901', 'Liuka', 'McLarty', 'lmclarty1k@sitemeter.com', '472-938-6304');
insert into client (id, first_name, last_name, email, phone) values ('93-2399598', 'Alyse', 'Croydon', 'acroydon1l@ning.com', '248-584-8806');
insert into client (id, first_name, last_name, email, phone) values ('42-2088974', 'Madelaine', 'Lowdwell', 'mlowdwell1m@fotki.com', '343-921-7136');
insert into client (id, first_name, last_name, email, phone) values ('80-0878290', 'Marcelline', 'Lippingwell', 'mlippingwell1n@engadget.com', '595-585-7171');
insert into client (id, first_name, last_name, email, phone) values ('58-3301015', 'Gerhard', 'Sallter', 'gsallter1o@smh.com.au', '134-522-6865');
insert into client (id, first_name, last_name, email, phone) values ('25-1932841', 'Katherine', 'Grabb', 'kgrabb1p@sina.com.cn', '967-844-3577');
insert into client (id, first_name, last_name, email, phone) values ('34-7243161', 'Dolores', 'Gofford', 'dgofford1q@state.tx.us', '631-295-7330');
insert into client (id, first_name, last_name, email, phone) values ('10-2184438', 'Rosco', 'Schellig', 'rschellig1r@rambler.ru', '547-698-8939');
insert into client (id, first_name, last_name, email, phone) values ('30-2919662', 'Gale', 'Ruppelin', 'gruppelin1s@digg.com', '821-671-0847');
insert into client (id, first_name, last_name, email, phone) values ('54-6617200', 'Lezley', 'Venny', 'lvenny1t@ameblo.jp', '769-644-2645');
insert into client (id, first_name, last_name, email, phone) values ('51-0507903', 'Ashlee', 'Nicely', 'anicely1u@bloglines.com', '609-149-1740');
insert into client (id, first_name, last_name, email, phone) values ('32-1121865', 'Ariel', 'Berthomier', 'aberthomier1v@cbsnews.com', '745-694-5217');
insert into client (id, first_name, last_name, email, phone) values ('53-1218971', 'Cleveland', 'Hackworth', 'chackworth1w@cyberchimps.com', '313-163-7802');
insert into client (id, first_name, last_name, email, phone) values ('26-6029399', 'Tome', 'Jandak', 'tjandak1x@sohu.com', '659-867-2413');
insert into client (id, first_name, last_name, email, phone) values ('27-9053711', 'Kiersten', 'O''Duilleain', 'koduilleain1y@cyberchimps.com', '534-945-7426');
insert into client (id, first_name, last_name, email, phone) values ('93-7172944', 'Konrad', 'Claxson', 'kclaxson1z@naver.com', '486-453-3060');
insert into client (id, first_name, last_name, email, phone) values ('42-7156245', 'Vidovik', 'Boyat', 'vboyat20@slate.com', '102-752-1319');
insert into client (id, first_name, last_name, email, phone) values ('22-8968976', 'Lazare', 'Tankin', 'ltankin21@phoca.cz', '470-671-5536');
insert into client (id, first_name, last_name, email, phone) values ('10-3165810', 'Evita', 'Rickman', 'erickman22@sohu.com', '614-930-8606');
insert into client (id, first_name, last_name, email, phone) values ('33-7615551', 'Robby', 'Vickars', 'rvickars23@mlb.com', '493-742-7434');
insert into client (id, first_name, last_name, email, phone) values ('32-7050338', 'Chase', 'Swetland', 'cswetland24@jugem.jp', '706-114-1532');
insert into client (id, first_name, last_name, email, phone) values ('68-9054674', 'Gerladina', 'McDill', 'gmcdill25@amazon.com', '659-208-4632');
insert into client (id, first_name, last_name, email, phone) values ('54-3941843', 'Nat', 'Minguet', 'nminguet26@phpbb.com', '776-480-9183');
insert into client (id, first_name, last_name, email, phone) values ('55-3142492', 'Jimmy', 'Ranson', 'jranson27@paypal.com', '660-428-8257');
insert into client (id, first_name, last_name, email, phone) values ('96-3870090', 'Nolie', 'Buxey', 'nbuxey28@qq.com', '280-260-1461');
insert into client (id, first_name, last_name, email, phone) values ('27-7098548', 'Carla', 'Comberbach', 'ccomberbach29@opera.com', '783-743-0706');
insert into client (id, first_name, last_name, email, phone) values ('22-4434029', 'Algernon', 'Vearncombe', 'avearncombe2a@blinklist.com', '300-759-6423');
insert into client (id, first_name, last_name, email, phone) values ('93-6899706', 'Fan', 'Mingey', 'fmingey2b@google.cn', '497-609-4347');
insert into client (id, first_name, last_name, email, phone) values ('67-0329672', 'Angie', 'Dunsire', 'adunsire2c@sphinn.com', '490-422-4297');
insert into client (id, first_name, last_name, email, phone) values ('42-2418741', 'Trumann', 'Ockland', 'tockland2d@businessweek.com', '812-472-1677');
insert into client (id, first_name, last_name, email, phone) values ('89-2786901', 'Cindi', 'Dignall', 'cdignall2e@fastcompany.com', '102-325-0101');
insert into client (id, first_name, last_name, email, phone) values ('54-6641492', 'Reinhard', 'Cartlidge', 'rcartlidge2f@umn.edu', '621-786-0054');
insert into client (id, first_name, last_name, email, phone) values ('68-0161563', 'Ches', 'Padbury', 'cpadbury2g@kickstarter.com', '715-794-5920');
insert into client (id, first_name, last_name, email, phone) values ('05-1490835', 'Mari', 'Abethell', 'mabethell2h@sciencedirect.com', '363-849-3711');
insert into client (id, first_name, last_name, email, phone) values ('19-7470416', 'Vicki', 'Kilfedder', 'vkilfedder2i@foxnews.com', '656-714-7232');
insert into client (id, first_name, last_name, email, phone) values ('37-8683285', 'Nichole', 'Wibberley', 'nwibberley2j@netlog.com', '680-965-6816');
insert into client (id, first_name, last_name, email, phone) values ('26-0832232', 'Fraser', 'Pickerin', 'fpickerin2k@amazon.co.jp', '839-868-1693');
insert into client (id, first_name, last_name, email, phone) values ('83-1233579', 'Georgette', 'McGeaney', 'gmcgeaney2l@amazon.co.uk', '494-720-5104');
insert into client (id, first_name, last_name, email, phone) values ('77-7946867', 'Monique', 'Matteotti', 'mmatteotti2m@nps.gov', '514-425-9574');
insert into client (id, first_name, last_name, email, phone) values ('59-4321306', 'Donella', 'Rhoddie', 'drhoddie2n@slideshare.net', '527-698-3230');
insert into client (id, first_name, last_name, email, phone) values ('42-7835076', 'Raychel', 'Purdom', 'rpurdom2o@go.com', '549-560-0825');
insert into client (id, first_name, last_name, email, phone) values ('25-0459564', 'Earle', 'Stegers', 'estegers2p@ucoz.com', '199-784-0330');
insert into client (id, first_name, last_name, email, phone) values ('65-7086880', 'Barrie', 'Putten', 'bputten2q@thetimes.co.uk', '555-759-7539');
insert into client (id, first_name, last_name, email, phone) values ('94-2352210', 'Duky', 'Mirfield', 'dmirfield2r@ibm.com', '761-982-1696');
insert into client (id, first_name, last_name, email, phone) values ('48-3665861', 'Petr', 'Czajka', 'pczajka2s@vk.com', '216-698-1158');
insert into client (id, first_name, last_name, email, phone) values ('39-0354044', 'Deny', 'Hegley', 'dhegley2t@ucla.edu', '810-663-3873');
insert into client (id, first_name, last_name, email, phone) values ('76-4259827', 'Minnaminnie', 'Fancy', 'mfancy2u@yahoo.com', '693-506-4349');
insert into client (id, first_name, last_name, email, phone) values ('64-0200128', 'Malynda', 'Knighton', 'mknighton2v@booking.com', '273-153-4928');
insert into client (id, first_name, last_name, email, phone) values ('63-5038586', 'Nobe', 'Leyre', 'nleyre2w@economist.com', '365-231-0056');
insert into client (id, first_name, last_name, email, phone) values ('15-7370473', 'Bord', 'Fawdry', 'bfawdry2x@nature.com', '664-517-3549');
insert into client (id, first_name, last_name, email, phone) values ('98-5345749', 'Vernice', 'Smitheman', 'vsmitheman2y@miibeian.gov.cn', '477-795-4375');
insert into client (id, first_name, last_name, email, phone) values ('99-4633174', 'Pietra', 'Stigers', 'pstigers2z@phoca.cz', '359-883-6677');
insert into client (id, first_name, last_name, email, phone) values ('09-4435024', 'Adam', 'Couch', 'acouch30@google.com.au', '119-515-5573');
insert into client (id, first_name, last_name, email, phone) values ('31-1735167', 'Ab', 'O''Fergus', 'aofergus31@ucoz.com', '111-866-7401');
insert into client (id, first_name, last_name, email, phone) values ('58-9767765', 'Jeremie', 'Petrie', 'jpetrie32@pen.io', '189-897-2035');
insert into client (id, first_name, last_name, email, phone) values ('51-7218721', 'Clemmy', 'Trevaskus', 'ctrevaskus33@ameblo.jp', '793-302-6811');
insert into client (id, first_name, last_name, email, phone) values ('78-8730827', 'Sibby', 'Atkinson', 'satkinson34@joomla.org', '336-106-0096');
insert into client (id, first_name, last_name, email, phone) values ('36-4163851', 'Benedikt', 'Brotherton', 'bbrotherton35@jugem.jp', '697-124-0214');
insert into client (id, first_name, last_name, email, phone) values ('87-3641319', 'Benoit', 'Rishworth', 'brishworth36@auda.org.au', '755-846-7293');
insert into client (id, first_name, last_name, email, phone) values ('77-6214110', 'Xenia', 'Flett', 'xflett37@sphinn.com', '706-697-5410');
insert into client (id, first_name, last_name, email, phone) values ('26-9222486', 'Elane', 'Farish', 'efarish38@google.com.au', '382-831-6521');
insert into client (id, first_name, last_name, email, phone) values ('66-8736799', 'Keary', 'Ritmeier', 'kritmeier39@dot.gov', '152-606-0143');
insert into client (id, first_name, last_name, email, phone) values ('39-9229548', 'Augusta', 'Fawcett', 'afawcett3a@google.ru', '106-258-5074');
insert into client (id, first_name, last_name, email, phone) values ('95-7580808', 'Dulcy', 'Behagg', 'dbehagg3b@wikipedia.org', '899-572-3503');
insert into client (id, first_name, last_name, email, phone) values ('15-5115273', 'Inger', 'Bucktrout', 'ibucktrout3c@adobe.com', '258-468-6280');
insert into client (id, first_name, last_name, email, phone) values ('54-7149010', 'Glory', 'Jiggens', 'gjiggens3d@comsenz.com', '761-412-9121');
insert into client (id, first_name, last_name, email, phone) values ('26-7083921', 'Jodee', 'Josskovitz', 'jjosskovitz3e@bizjournals.com', '679-317-0779');
insert into client (id, first_name, last_name, email, phone) values ('63-8282610', 'Colline', 'Levee', 'clevee3f@vimeo.com', '645-239-6723');
insert into client (id, first_name, last_name, email, phone) values ('64-4589644', 'Cleopatra', 'Minnock', 'cminnock3g@amazon.co.uk', '198-247-5173');
insert into client (id, first_name, last_name, email, phone) values ('46-2911825', 'Katharina', 'Littlecote', 'klittlecote3h@independent.co.uk', '202-370-2100');
insert into client (id, first_name, last_name, email, phone) values ('72-3705494', 'Tallou', 'Billham', 'tbillham3i@bluehost.com', '572-325-8714');
insert into client (id, first_name, last_name, email, phone) values ('31-9455743', 'Merrili', 'Anton', 'manton3j@un.org', '152-688-8072');
insert into client (id, first_name, last_name, email, phone) values ('60-1286283', 'Daveta', 'McTrustam', 'dmctrustam3k@ted.com', '379-797-3851');
insert into client (id, first_name, last_name, email, phone) values ('45-1834498', 'Ian', 'Itzakson', 'iitzakson3l@techcrunch.com', '252-502-4967');
insert into client (id, first_name, last_name, email, phone) values ('84-5515142', 'Merrill', 'Bitcheno', 'mbitcheno3m@over-blog.com', '816-965-8666');
insert into client (id, first_name, last_name, email, phone) values ('45-2789631', 'Henrik', 'Smylie', 'hsmylie3n@imgur.com', '181-621-2149');
insert into client (id, first_name, last_name, email, phone) values ('45-7724990', 'Monte', 'Sprague', 'msprague3o@springer.com', '801-575-1244');
insert into client (id, first_name, last_name, email, phone) values ('68-8977489', 'Marcel', 'Pottell', 'mpottell3p@thetimes.co.uk', '336-768-6861');
insert into client (id, first_name, last_name, email, phone) values ('30-0929861', 'Park', 'Fernehough', 'pfernehough3q@google.com.br', '141-201-6800');
insert into client (id, first_name, last_name, email, phone) values ('84-3058165', 'Carmelita', 'Coaten', 'ccoaten3r@devhub.com', '846-571-7089');
insert into client (id, first_name, last_name, email, phone) values ('75-1086281', 'Hazlett', 'Sedgman', 'hsedgman3s@blogger.com', '151-686-0316');
insert into client (id, first_name, last_name, email, phone) values ('28-7277533', 'Maurie', 'Govern', 'mgovern3t@cnet.com', '294-413-1479');
insert into client (id, first_name, last_name, email, phone) values ('47-9013056', 'Uta', 'Colson', 'ucolson3u@twitter.com', '632-447-7356');
insert into client (id, first_name, last_name, email, phone) values ('50-9009266', 'Jannel', 'Humm', 'jhumm3v@tinypic.com', '488-278-5919');
insert into client (id, first_name, last_name, email, phone) values ('62-1342238', 'Lonnard', 'Dewes', 'ldewes3w@moonfruit.com', '309-253-9714');
insert into client (id, first_name, last_name, email, phone) values ('26-3475134', 'Timothea', 'MacAlaster', 'tmacalaster3x@admin.ch', '318-199-3293');
insert into client (id, first_name, last_name, email, phone) values ('20-9890692', 'Karena', 'Lydford', 'klydford3y@dailymotion.com', '859-678-9315');



/* populate table medicine */

insert into medicine (fda_code, drug_name, drug_company) values ('0115-2622', 'TERBUTALINE SULFATE', 'Global Pharmaceuticals, Division of Impax Laboratories Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('54859-702', 'Conex', 'LLORENS PHARMACEUTICALS INTERNATIONAL DIVISION');
insert into medicine (fda_code, drug_name, drug_company) values ('42852-001', 'Ciprofloxacin Hydrochloride', 'Apothecary Shop Wholesale Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('64942-1060', 'Degree For Women Delicious Bliss', 'Conopco Inc. d/b/a Unilever');
insert into medicine (fda_code, drug_name, drug_company) values ('49349-766', 'Parafon Forte DSC', 'REMEDYREPACK INC.');
insert into medicine (fda_code, drug_name, drug_company) values ('61598-200', 'VeraSeptine Multipurpose Moisture Barrier', 'LTC Products, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('0078-0246', 'Neoral', 'Novartis Pharmaceuticals Corporation');
insert into medicine (fda_code, drug_name, drug_company) values ('0781-3004', 'Omnitrope', 'Sandoz Inc');
insert into medicine (fda_code, drug_name, drug_company) values ('76229-234', 'Likewise Facial Moisturizer - Sun Protectant SPF 50 Oily Skin', 'Likewise Incorporated');
insert into medicine (fda_code, drug_name, drug_company) values ('53113-104', 'Gadavyt Enema', 'Gadal Laboratories Inc');
insert into medicine (fda_code, drug_name, drug_company) values ('40085-219', 'Promethazine Hydrochloride', 'Renaissance Pharma, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('21695-915', 'AK-Con', 'Rebel Distributors Corp.');
insert into medicine (fda_code, drug_name, drug_company) values ('0904-5889', 'Theophylline', 'Major Pharmaceuticals');
insert into medicine (fda_code, drug_name, drug_company) values ('0143-9888', 'Amoxicillin', 'West-Ward Pharmaceutical Corp');
insert into medicine (fda_code, drug_name, drug_company) values ('11084-632', 'DebMed Antimicrobial', 'Deb USA, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('0409-7936', 'Dextrose', 'Hospira, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('61957-1420', 'Capture Totale Radiance Restoring Serum Foundation SPF 15 020', 'Parfums Christian Dior');
insert into medicine (fda_code, drug_name, drug_company) values ('63739-228', 'Sulfamethoxazole and Trimethoprim', 'McKesson Packaging Services a business unit of McKesson Corporation');
insert into medicine (fda_code, drug_name, drug_company) values ('57520-0064', 'Cerebraplex', 'Apotheca Company');
insert into medicine (fda_code, drug_name, drug_company) values ('43857-0085', 'Liver Tonic', 'BioActive Nutritional, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('55154-1490', 'Hydralazine', 'Cardinal Health');
insert into medicine (fda_code, drug_name, drug_company) values ('0924-0123', 'PhysiciansCare Non Aspirin', 'Acme United Corporation');
insert into medicine (fda_code, drug_name, drug_company) values ('0338-0089', 'Dextrose and Sodium Chloride', 'Baxter Healthcare Corporation');
insert into medicine (fda_code, drug_name, drug_company) values ('0703-5233', 'daunorubicin hydrochloride', 'Teva Parenteral Medicines, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('33261-849', 'Risperidone', 'Aidarex Pharmaceuticals LLC');
insert into medicine (fda_code, drug_name, drug_company) values ('52584-904', 'Lidocaine Hydrochloride', 'General Injectables & Vaccine, Inc');
insert into medicine (fda_code, drug_name, drug_company) values ('68472-126', 'No7 Lift and Luminate Foundation Sunscreen Broad Spectrum SPF 15 Calico', 'Boots Retail USA Inc');
insert into medicine (fda_code, drug_name, drug_company) values ('0268-1399', 'PLANTAGO LANCEOLATA POLLEN', 'ALK-Abello, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('11419-001', 'Oxygen', 'SheSham, Inc. T/A Wilson Supply');
insert into medicine (fda_code, drug_name, drug_company) values ('55316-296', 'Dry Scalp Care', 'DZA Brands, LLC');
insert into medicine (fda_code, drug_name, drug_company) values ('58668-2591', 'CLARINS Skin Illusion SPF 10 Natural Radiance Foundation Tint 117', 'Laboratoires Clarins S.A.');
insert into medicine (fda_code, drug_name, drug_company) values ('0378-5410', 'Fluoxetine Hydrochloride', 'Mylan Pharmaceuticals Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('76268-001', 'Antibacterial Hand', 'ORGANICA (UK) LTD');
insert into medicine (fda_code, drug_name, drug_company) values ('45802-650', 'Loratadine', 'Perrigo New York Inc');
insert into medicine (fda_code, drug_name, drug_company) values ('36987-2434', 'Soft Cheat Brome', 'Nelco Laboratories, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('43853-0005', 'Testosterone', 'ProBLEN');
insert into medicine (fda_code, drug_name, drug_company) values ('0904-0647', 'Nitro-Time', 'Major Pharmaceuticals');
insert into medicine (fda_code, drug_name, drug_company) values ('0126-0075', 'PreviDent', 'Colgate-Palmolive Company');
insert into medicine (fda_code, drug_name, drug_company) values ('55316-272', 'healthy accents sinus congestion and pain', 'DZA Brands LLC');
insert into medicine (fda_code, drug_name, drug_company) values ('64578-0093', 'Sinus-Tone', 'Energetix Corp');
insert into medicine (fda_code, drug_name, drug_company) values ('59779-661', 'CVS Pharmacy Daytime Nighttime Severe Cold and Cough Kit', 'CVS Pharmacy');
insert into medicine (fda_code, drug_name, drug_company) values ('54569-1754', 'Promethazine Hydrochloride', 'A-S Medication Solutions LLC');
insert into medicine (fda_code, drug_name, drug_company) values ('75936-112', 'Gradual Self-tanning sunscreen SPF 20', 'TAYLOR JAMES, LTD.');
insert into medicine (fda_code, drug_name, drug_company) values ('55714-1105', 'Prime Plus', 'Newton Laboratories, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('50458-389', 'RAZADYNE', 'Janssen Pharmaceuticals, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('50730-4401', 'Povidone-Iodine Scrub Swabstick', 'H and P Industries, Inc. dba Triad Group');
insert into medicine (fda_code, drug_name, drug_company) values ('64942-1331', 'Degree', 'Conopco Inc. d/b/a Unilever');
insert into medicine (fda_code, drug_name, drug_company) values ('10191-1255', 'ARNICA MONTANA (Whole Plant)', 'Remedy Makers');
insert into medicine (fda_code, drug_name, drug_company) values ('11559-720', 'RESILIENCE LIFT EXTREME CREME COMPACT MAKEUP', 'ESTEE LAUDER INC');
insert into medicine (fda_code, drug_name, drug_company) values ('49527-751', 'ACNE SOLUTIONS LIQUID MAKEUP', 'CLINIQUE LABORATORIES INC');
insert into medicine (fda_code, drug_name, drug_company) values ('41520-614', 'MEDICATED DANDRUFF', 'AMERICAN SALES COMPANY');
insert into medicine (fda_code, drug_name, drug_company) values ('10544-047', 'Hydrochlorothiazide', 'Blenheim Pharmacal, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('66582-320', 'LIPTRUZET', 'Merck Sharp & Dohme Corp.');
insert into medicine (fda_code, drug_name, drug_company) values ('0904-5780', 'Major Heartburn Relief', 'Major Pharmaceuticals');
insert into medicine (fda_code, drug_name, drug_company) values ('68084-789', 'Hydrocortisone', 'American Health Packaging');
insert into medicine (fda_code, drug_name, drug_company) values ('0536-0815', 'ACNE MEDICATION 10', 'Rugby Laboratories');
insert into medicine (fda_code, drug_name, drug_company) values ('68604-231', 'Hand Kleen Foaming Antibacterial Hand', 'Auto-Chlor System, LLC');
insert into medicine (fda_code, drug_name, drug_company) values ('11084-106', 'Appeal Non-Alcohol Foaming Hand Sanitizer', 'Deb USA, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('43063-427', 'CIPROFLOXACIN', 'PD-Rx Pharmaceuticals, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('49738-903', 'smart sense multi symptom cold', 'Kmart Corporation');
insert into medicine (fda_code, drug_name, drug_company) values ('36987-3223', 'Iodine Bush', 'Nelco Laboratories, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('0363-0238', 'Stool Softener', 'Walgreens');
insert into medicine (fda_code, drug_name, drug_company) values ('66992-399', 'Regimex', 'Wraser Pharmaceuticals');
insert into medicine (fda_code, drug_name, drug_company) values ('68196-324', 'SIMPLY RIGHT BODY CARE', 'SAM''S WEST INC.');
insert into medicine (fda_code, drug_name, drug_company) values ('66336-878', 'Etodolac', 'Dispensing Solutions, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('49643-312', 'Alder, White Pollen', 'Allermed Laboratories, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('63629-3944', 'HYDROCODONE BITARTRATE AND ACETAMINOPHEN', 'bryant ranch prepack');
insert into medicine (fda_code, drug_name, drug_company) values ('36987-2062', 'Phoma glomerata', 'Nelco Laboratories, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('59779-157', 'Aspirin', 'WOONSOCKET PRESCRIPTION CENTER,INCORPORATED');
insert into medicine (fda_code, drug_name, drug_company) values ('21749-095', 'MICRELL Antibacterial Foam Handwash', 'GOJO Industries, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('64679-962', 'AZITHROMYCIN', 'WOCKHARDT USA LLC.');
insert into medicine (fda_code, drug_name, drug_company) values ('43063-133', 'sotalol hydrochloride', 'PD-Rx Pharmaceuticals, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('49349-352', 'Ibuprofen', 'REMEDYREPACK INC.');
insert into medicine (fda_code, drug_name, drug_company) values ('0268-6116', 'CARROT', 'ALK-Abello, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('64725-0586', 'Dicyclomine Hydrochloride', 'TYA Pharmaceuticals');
insert into medicine (fda_code, drug_name, drug_company) values ('98132-171', 'Ready Foundation', 'Bare Escentuals Beauty Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('68025-073', 'ConZip', 'Vertical Pharmaceuticals, LLC');
insert into medicine (fda_code, drug_name, drug_company) values ('51293-612', 'Phenazopyridine Hydrochloride', 'ECI Pharmaceuticals, LLC');
insert into medicine (fda_code, drug_name, drug_company) values ('66689-401', 'Oxycodone Hydrochloride', 'VistaPharm Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('55154-0217', 'Premarin', 'Cardinal Health');
insert into medicine (fda_code, drug_name, drug_company) values ('49349-607', 'Prednisone', 'REMEDYREPACK INC.');
insert into medicine (fda_code, drug_name, drug_company) values ('10812-398', 'Neutrogena All in 1 Acne Control', 'Neutrogena Corporation');
insert into medicine (fda_code, drug_name, drug_company) values ('47593-499', 'Clean Strike', 'Ecolab Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('36987-2413', 'Cultivated Wheat', 'Nelco Laboratories, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('52125-173', 'Cyclobenzaprine Hydrochloride', 'REMEDYREPACK INC.');
insert into medicine (fda_code, drug_name, drug_company) values ('16252-509', 'Simvastatin', 'Cobalt Laboratories Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('21695-407', 'TriNessa', 'Rebel Distributors Corp');
insert into medicine (fda_code, drug_name, drug_company) values ('0904-6142', 'Doxazosin Mesylate', 'Major Pharmaceuticals');
insert into medicine (fda_code, drug_name, drug_company) values ('42361-008', 'The Cover Classic Pro Foundation', 'Dong Sung Pharm. Co., Ltd.');
insert into medicine (fda_code, drug_name, drug_company) values ('61616-010', 'Four Season', 'OneLineSun Co., Ltd.');
insert into medicine (fda_code, drug_name, drug_company) values ('30807-2002', 'Quit Nits Advance', 'Wild Child W A Pty Ltd');
insert into medicine (fda_code, drug_name, drug_company) values ('0573-1926', 'CHAPSTICK MOISTURIZER', 'Wyeth Consumer Healthcare');
insert into medicine (fda_code, drug_name, drug_company) values ('37808-351', 'Acid Reducer', 'H E B');
insert into medicine (fda_code, drug_name, drug_company) values ('35356-254', 'IMITREX', 'Lake Erie Medical & Surgical Supply DBA Quality Care Products LLC');
insert into medicine (fda_code, drug_name, drug_company) values ('58443-0035', 'Australian Gold', 'Prime Enterprises, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('63672-0051', 'Levocetirizine dihydrochloride', 'Synthon Pharmaceuticals, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('54575-915', 'MOUNTAIN CEDAR POLLEN', 'Allergy Laboratories, Inc.');
insert into medicine (fda_code, drug_name, drug_company) values ('0093-7477', 'Mycophenolate Mofetil', 'Teva Pharmaceuticals USA Inc');
insert into medicine (fda_code, drug_name, drug_company) values ('10056-105', 'fulton street market triple antibiotic', 'Access Business Group LLC');
insert into medicine (fda_code, drug_name, drug_company) values ('65293-412', 'Midazolam', 'The Medicines Company');




/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* populate table prescription   */
insert into
   PRESCRIPTION(client_id, drug_id) 
   SELECT
      * 
   FROM
      (
         SELECT
            * 
         FROM
            (
               SELECT
                  client.id AS a_id,
                  medicine.fda_code AS b_id 
               FROM
                  client 
                  CROSS JOIN
                     medicine 
               ORDER BY
                  random() 
            )
            AS s0 LIMIT 1000 
      )
      AS s1 
   ORDER BY
      a_id,
      b_id;


/* The end of ZENG JIAQI's work */