/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*

This case is to simply demonstrate a many to many relationship in database, the example I chose is an online video on demand sales history system.

The first entity set is the users data, including username, their first name and last name, their email address, phone number, country, billing address and credit card number that they used on our VOD platform.

The second entity set is the movies that are available on our platform, movie title, genres,  content providers of those movie and price for each movie are stored in this table.

The many to many relationship in this case is the user’s VOD playback history. This table only has two attributes, they are username and the title of movie that the customers order on our VOD platform.
Ideally, in real case, we would like to have a timestamp of transaction and web order number in this table as well, but because of the way we populate this table, it is not feasible to add those attributes, so I just skipped.

The code is written for PostgreSQL

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* Drop tables as needed */
DROP TABLE IF EXISTS vod;
DROP TABLE IF EXISTS movies;
DROP TABLE IF EXISTS users;


/* Create users table*/
CREATE TABLE IF NOT EXISTS users (
 username VARCHAR(64) PRIMARY KEY,
 first_name VARCHAR(64) NOT NULL,
 last_name VARCHAR(64) NOT NULL,
 email VARCHAR(64) UNIQUE NOT NULL,
 phone_number VARCHAR(32) UNIQUE NOT NULL,
 country VARCHAR(64) NOT NULL,
 billing_address VARCHAR(128) NOT NULL,
 cc_number VARCHAR(32) NOT NULL
);
/* all attributes are set to be not null in users table. In PostgreSQL, we dont't need to explicitly declare the primary key as not null.
Phone number and email address is set to be unique as it is not allowed to create the account again using the same email or phone number.
 */

 /* Create movies table */
 CREATE TABLE IF NOT EXISTS movies(
  title VARCHAR(128) PRIMARY KEY,
  genres VARCHAR(128) NOT NULL,
  provider VARCHAR(64) NOT NULL,
  price NUMERIC NOT NULL CHECK (price >= 0)
  );
  /*
  All attributes are set to be not null.
  If we generate 1000 rows of movie records from Mockaroo, it was noticed that there could be some duplicate movie titles in the dataset,
  but fortunately, the set of data here doesn't have any duplicate movie titles, so we can choose it as primary key.
 One way to create the constraint in case of duplicate titles is to use the combination of tile and realease year as primary key, whicn can be generated using 'car model year' in mockaroo.
 This also happens in real life. E.g. The movie Ghostbuster
 The assumption we have to make here is that there isn't any movie that released in the same year with the same title.
 If that's not the case, the best way is to create a movie_id column as primary key in this table.
 */

 /* Create vod table*/
CREATE TABLE vod(
 username VARCHAR(32) REFERENCES users(username) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
 title  VARCHAR(128) REFERENCES movies(title) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
 PRIMARY KEY(username,title)
 );

 /*
 Both attributes are foreign key in this table.
 As what was being discussed earlier,
 ideally, in real case, we would like to have a timestamp of transaction and web order number in this table as well,
 but because of the way we populate this table, it is not feasible to populating those attributes using one single insert statement,
 so I just skipped.
 */


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Populating table movies */
insert into movies (title, genres, provider, price) values ('When I Grow Up, I''ll Be a Kangaroo (Kad porastem bicu Kengur)', 'Comedy', 'Walsh Group', 9);
insert into movies (title, genres, provider, price) values ('Chronos', 'Documentary|IMAX', 'Windler and Sons', 10);
insert into movies (title, genres, provider, price) values ('Rooster Cogburn', 'Comedy|Western', 'Walsh and Sons', 14);
insert into movies (title, genres, provider, price) values ('The Last Gladiators', 'Documentary', 'Boehm-Schaden', 11);
insert into movies (title, genres, provider, price) values ('When You Comin'' Back, Red Ryder?', 'Drama', 'Moore, Bogisich and Moore', 9);
insert into movies (title, genres, provider, price) values ('South, The (Sur)', 'Drama', 'Reilly, Beer and Wuckert', 14);
insert into movies (title, genres, provider, price) values ('Friend Is a Treasure, A (Chi Trova Un Amico, Trova un Tesoro) (Who Finds a Friend Finds a Treasure)', 'Action|Adventure|Comedy', 'Bogan, Prosacco and Emard', 10);
insert into movies (title, genres, provider, price) values ('Rumble in the Bronx (Hont faan kui)', 'Action|Adventure|Comedy|Crime', 'Parisian Inc', 15);
insert into movies (title, genres, provider, price) values ('Gleaners & I, The (Les glaneurs et la glaneuse)', 'Documentary', 'Gottlieb, Bartoletti and Reynolds', 17);
insert into movies (title, genres, provider, price) values ('Ca$h', 'Action|Comedy|Crime|Thriller', 'Jerde Inc', 10);
insert into movies (title, genres, provider, price) values ('Tarnished Angels, The', 'Drama', 'Marquardt and Sons', 19);
insert into movies (title, genres, provider, price) values ('Bikini Beach', 'Comedy', 'Kuphal Group', 18);
insert into movies (title, genres, provider, price) values ('There Will Be No Leave Today (Segodnya uvolneniya ne budet)', 'Drama|Thriller', 'Stroman, Johns and Herzog', 12);
insert into movies (title, genres, provider, price) values ('Wholly Moses', 'Comedy', 'Trantow-Spinka', 14);
insert into movies (title, genres, provider, price) values ('Detachment', 'Drama', 'Schultz, Gutmann and Baumbach', 11);
insert into movies (title, genres, provider, price) values ('No Escape', 'Action|Drama|Sci-Fi', 'Russel, Kilback and Olson', 11);
insert into movies (title, genres, provider, price) values ('Extreme Measures', 'Drama|Thriller', 'Lesch-Rath', 15);
insert into movies (title, genres, provider, price) values ('Dance with the Devil (Perdita Durango)', 'Action|Crime|Drama|Romance', 'Reichert Inc', 9);
insert into movies (title, genres, provider, price) values ('Plague Dogs, The', 'Adventure|Animation|Drama', 'Bruen Group', 11);
insert into movies (title, genres, provider, price) values ('No', 'Drama', 'Schimmel, Braun and Upton', 13);
insert into movies (title, genres, provider, price) values ('Hangover Part III, The', 'Comedy', 'Dare-Beatty', 11);
insert into movies (title, genres, provider, price) values ('Pieces of April', 'Comedy|Drama', 'Herman, Wuckert and Mitchell', 18);
insert into movies (title, genres, provider, price) values ('Turtle''s Tale: Sammy''s Adventures, A', 'Adventure|Animation', 'McGlynn-Schumm', 17);
insert into movies (title, genres, provider, price) values ('Drunken Angel (Yoidore tenshi)', 'Drama|Film-Noir', 'Shanahan Group', 12);
insert into movies (title, genres, provider, price) values ('13th Letter, The', 'Film-Noir', 'Huels, McLaughlin and Kiehn', 18);
insert into movies (title, genres, provider, price) values ('Gate of Heavenly Peace, The', 'Documentary', 'Parisian-Padberg', 16);
insert into movies (title, genres, provider, price) values ('Margot at the Wedding', 'Drama', 'Ankunding, Lowe and Kohler', 15);
insert into movies (title, genres, provider, price) values ('New One-Armed Swordsman, The (Xin du bi dao)', 'Action|Drama|War', 'Williamson, Littel and Wiegand', 9);
insert into movies (title, genres, provider, price) values ('Public Eye, The', 'Crime|Thriller', 'Aufderhar, Bechtelar and Doyle', 12);
insert into movies (title, genres, provider, price) values ('Hemingway & Gellhorn', 'Drama|Romance|War', 'Howe, Abshire and Cole', 13);
insert into movies (title, genres, provider, price) values ('Dialogues with Solzhenitsyn (Uzel)', 'Documentary', 'Bins-Cummings', 9);
insert into movies (title, genres, provider, price) values ('Grey Fox, The', 'Romance|Western', 'Lockman and Sons', 19);
insert into movies (title, genres, provider, price) values ('Love Exposure', 'Action|Comedy|Drama|Romance', 'Sanford-Huel', 18);
insert into movies (title, genres, provider, price) values ('Jupiter''s Darling', 'Comedy|Musical|Romance', 'Barrows Group', 14);
insert into movies (title, genres, provider, price) values ('Show Boat', 'Comedy|Drama|Musical|Romance', 'Mills, Johnston and Kilback', 17);
insert into movies (title, genres, provider, price) values ('Darktown Strutters (Get Down and Boogie)', 'Action|Comedy|Musical', 'Wisozk Group', 10);
insert into movies (title, genres, provider, price) values ('Valley Girl', 'Comedy|Romance', 'Barrows-Kozey', 18);
insert into movies (title, genres, provider, price) values ('Good Hair', 'Comedy|Documentary', 'Wisoky, Bergstrom and Tillman', 18);
insert into movies (title, genres, provider, price) values ('Le crocodile du Botswanga', 'Comedy', 'Conroy Inc', 11);
insert into movies (title, genres, provider, price) values ('Stoplight Society, The (La Sociedad del Semáforo)', 'Drama', 'Huels LLC', 14);
insert into movies (title, genres, provider, price) values ('Lesbian Vampire Killers', 'Action|Comedy|Horror', 'Pfannerstill Group', 13);
insert into movies (title, genres, provider, price) values ('Forget Me Not', 'Horror|Romance|Thriller', 'Rolfson Group', 17);
insert into movies (title, genres, provider, price) values ('Hounds, The', 'Crime|Horror|Thriller', 'Lubowitz, O''Connell and Ward', 19);
insert into movies (title, genres, provider, price) values ('Chorus, The (Choristes, Les)', 'Drama', 'Rice, Emard and Block', 14);
insert into movies (title, genres, provider, price) values ('Spirited Away (Sen to Chihiro no kamikakushi)', 'Adventure|Animation|Fantasy', 'Treutel-Leuschke', 18);
insert into movies (title, genres, provider, price) values ('Drogówka', 'Comedy|Crime|Drama', 'Cremin-Orn', 19);
insert into movies (title, genres, provider, price) values ('Captain Horatio Hornblower R.N.', 'Action|Adventure|Drama|War', 'Prosacco and Sons', 13);
insert into movies (title, genres, provider, price) values ('Right Now (À tout de suite)', 'Crime|Drama|Romance|Thriller', 'Morar-Hahn', 12);
insert into movies (title, genres, provider, price) values ('Conquest 1453 (Fetih 1453)', 'Action|Adventure|Drama|War', 'Lakin and Sons', 9);
insert into movies (title, genres, provider, price) values ('Blade, The (Dao)', 'Action|Drama', 'Nikolaus, Hegmann and Hilll', 13);
insert into movies (title, genres, provider, price) values ('Bride Came C.O.D., The', 'Comedy|Romance', 'Balistreri-Smitham', 18);
insert into movies (title, genres, provider, price) values ('Big Bang Love, Juvenile A (46-okunen no koi)', 'Drama', 'Bauch and Sons', 11);
insert into movies (title, genres, provider, price) values ('I Can''t Sleep (J''ai pas sommeil)', 'Drama|Thriller', 'Reinger, Kuphal and Howell', 19);
insert into movies (title, genres, provider, price) values ('Slaves of New York', 'Drama', 'Streich, Hirthe and Macejkovic', 20);
insert into movies (title, genres, provider, price) values ('Great Outdoors, The', 'Comedy', 'Rath LLC', 16);
insert into movies (title, genres, provider, price) values ('Hara-Kiri: Death of a Samurai', 'Drama', 'Johns-Bosco', 11);
insert into movies (title, genres, provider, price) values ('Apple Dumpling Gang, The', 'Children|Comedy|Western', 'Greenholt-Huels', 15);
insert into movies (title, genres, provider, price) values ('Two Days in April', 'Documentary', 'Powlowski LLC', 9);
insert into movies (title, genres, provider, price) values ('Butcher''s Wife, The', 'Comedy|Romance', 'Treutel-Dare', 12);
insert into movies (title, genres, provider, price) values ('And So It Goes', 'Comedy|Drama|Romance', 'Hirthe, Wolf and Morar', 18);
insert into movies (title, genres, provider, price) values ('Exodus', 'Drama|Romance|War', 'Herzog, Dare and Kassulke', 11);
insert into movies (title, genres, provider, price) values ('Ice Soldiers', 'Action|Sci-Fi', 'Nikolaus, Hand and Gleason', 16);
insert into movies (title, genres, provider, price) values ('Easy Money', 'Comedy', 'Kuphal, Hyatt and Bernhard', 12);
insert into movies (title, genres, provider, price) values ('Woman Next Door, The (Femme d''à côté, La)', 'Drama|Romance', 'Hand-Beer', 9);
insert into movies (title, genres, provider, price) values ('Dear White People', 'Comedy|Drama', 'Funk-Stanton', 18);
insert into movies (title, genres, provider, price) values ('Melinda and Melinda', 'Comedy|Drama', 'Kshlerin Group', 16);
insert into movies (title, genres, provider, price) values ('And the Pursuit of Happiness (La poursuite du bonheur)', 'Documentary', 'Herman-Upton', 19);
insert into movies (title, genres, provider, price) values ('Love Sick Love', 'Thriller', 'Schumm-Goodwin', 12);
insert into movies (title, genres, provider, price) values ('Homicide', 'Crime|Drama|Thriller', 'Heathcote, Schneider and Kassulke', 14);
insert into movies (title, genres, provider, price) values ('Big Circus, The', 'Drama', 'Anderson, Ondricka and Feil', 10);
insert into movies (title, genres, provider, price) values ('Wrong Side Up (Pribehy obycejneho silenstvi)', 'Comedy|Drama', 'O''Kon-Paucek', 14);
insert into movies (title, genres, provider, price) values ('Front Page, The', 'Comedy|Drama|Romance', 'Torphy-Koepp', 20);
insert into movies (title, genres, provider, price) values ('Star Kid', 'Adventure|Children|Fantasy|Sci-Fi', 'Pollich-Johnston', 17);
insert into movies (title, genres, provider, price) values ('Megaforce', 'Action|Sci-Fi', 'Ledner, Reilly and Ryan', 16);
insert into movies (title, genres, provider, price) values ('Koumiko Mystery, The (Mystère Koumiko, Le)', 'Documentary', 'Ledner, Veum and Bahringer', 12);
insert into movies (title, genres, provider, price) values ('The Loft', 'Thriller', 'Gutkowski Inc', 18);
insert into movies (title, genres, provider, price) values ('Go for It', 'Action|Adventure|Comedy', 'Feeney Group', 18);
insert into movies (title, genres, provider, price) values ('Double Dynamite', 'Comedy|Musical', 'Ziemann, O''Hara and Von', 17);
insert into movies (title, genres, provider, price) values ('That Night in Varennes (Nuit de Varennes, La)', 'Drama', 'Waelchi LLC', 19);
insert into movies (title, genres, provider, price) values ('Comandante', 'Documentary', 'Borer-Collier', 15);
insert into movies (title, genres, provider, price) values ('Dare', 'Drama', 'Kunde LLC', 10);
insert into movies (title, genres, provider, price) values ('Sunday Bloody Sunday', 'Drama', 'Barton Inc', 12);
insert into movies (title, genres, provider, price) values ('Beginning of the End', 'Sci-Fi', 'Murphy-Deckow', 18);
insert into movies (title, genres, provider, price) values ('Patton Oswalt: My Weakness Is Strong', 'Comedy', 'Kihn and Sons', 16);
insert into movies (title, genres, provider, price) values ('Korso', 'Drama', 'Goyette Group', 15);
insert into movies (title, genres, provider, price) values ('Innocence', 'Adventure|Fantasy|Horror', 'Walsh and Sons', 19);
insert into movies (title, genres, provider, price) values ('Lisztomania', 'Comedy|Fantasy|Musical', 'Gislason, Stiedemann and Bergstrom', 12);
insert into movies (title, genres, provider, price) values ('Boomerang', 'Comedy|Romance', 'Metz, Gerlach and Dicki', 17);
insert into movies (title, genres, provider, price) values ('Blacksmith, The', 'Comedy', 'Becker, Wuckert and Boehm', 13);
insert into movies (title, genres, provider, price) values ('Alien Contamination', 'Action|Horror|Sci-Fi', 'Kshlerin Group', 10);
insert into movies (title, genres, provider, price) values ('Poto and Cabengo', 'Documentary', 'Powlowski Inc', 20);
insert into movies (title, genres, provider, price) values ('Real Men', 'Comedy|Sci-Fi', 'Schuppe-Schowalter', 16);
insert into movies (title, genres, provider, price) values ('The Body', 'Mystery|Thriller', 'Barrows and Sons', 11);
insert into movies (title, genres, provider, price) values ('Vile ', 'Horror', 'Crooks, O''Kon and Conroy', 16);
insert into movies (title, genres, provider, price) values ('Wild Man Blues', 'Documentary', 'Herzog-Schuppe', 11);
insert into movies (title, genres, provider, price) values ('Dopamine', 'Comedy|Drama|Romance', 'Donnelly Group', 12);
insert into movies (title, genres, provider, price) values ('Brief Crossing (Brève traversée)', 'Comedy|Drama|Romance', 'Greenholt-Blanda', 18);
insert into movies (title, genres, provider, price) values ('Pinchcliffe Grand Prix (Flåklypa Grand Prix)', 'Adventure|Animation|Children|Comedy', 'Towne-Mayert', 14);
insert into movies (title, genres, provider, price) values ('Net 2.0, The ', 'Action|Drama|Thriller', 'Lebsack LLC', 16);
insert into movies (title, genres, provider, price) values ('BFFs', 'Comedy', 'Zboncak Inc', 17);


  /* Populating table users */
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('spunyer0', 'Sybilla', 'Punyer', 'spunyer0@washingtonpost.com', '167 188 6818', 'China', '2 Mcbride Point', '3530396380330618');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('apevie1', 'Auria', 'Pevie', 'apevie1@squidoo.com', '642 367 6187', 'Portugal', '4584 Swallow Terrace', '5574012546167552');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('bmaylam2', 'Briant', 'Maylam', 'bmaylam2@google.com', '935 930 5043', 'Uganda', '4937 Banding Street', '3579255852631956');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('rpaten3', 'Rockey', 'Paten', 'rpaten3@github.com', '782 984 4760', 'Japan', '907 Crownhardt Lane', '3561434232109872');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('tmealham4', 'Tommie', 'Mealham', 'tmealham4@posterous.com', '345 232 1939', 'Philippines', '1647 Eliot Pass', '6387905659011845');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('estrattan5', 'Emmerich', 'Strattan', 'estrattan5@uol.com.br', '279 814 5686', 'Japan', '539 Dawn Junction', '4844602695681382');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('dtheakston6', 'Dalt', 'Theakston', 'dtheakston6@dailymail.co.uk', '137 645 7165', 'Poland', '1 Sullivan Park', '30159387842725');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('cyukhnini7', 'Casey', 'Yukhnini', 'cyukhnini7@bbb.org', '167 281 3536', 'Indonesia', '71 Fair Oaks Parkway', '3571053501739520');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('isneaker8', 'Ignacio', 'Sneaker', 'isneaker8@wikipedia.org', '660 282 4828', 'Mexico', '01 Nevada Street', '3557562131397960');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('mwhenman9', 'Maiga', 'Whenman', 'mwhenman9@nps.gov', '511 502 8371', 'Indonesia', '759 Pepper Wood Parkway', '560221408807353975');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('lweeksa', 'Laurette', 'Weeks', 'lweeksa@sun.com', '156 741 9755', 'South Africa', '89647 Logan Terrace', '3535481421083551');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('dleedalb', 'De', 'Leedal', 'dleedalb@examiner.com', '909 196 5231', 'China', '168 Glacier Hill Circle', '3534432347824694');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('ecorroc', 'Emmye', 'Corro', 'ecorroc@alexa.com', '812 400 8017', 'Czech Republic', '051 Prairieview Parkway', '3558633971287261');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('pdeliad', 'Page', 'Delia', 'pdeliad@godaddy.com', '606 356 2772', 'Argentina', '602 Glacier Hill Alley', '3540851392196504');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('veschalettee', 'Valencia', 'Eschalette', 'veschalettee@wsj.com', '772 979 5607', 'China', '76 Spaight Crossing', '3539060679667392');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('wburstowef', 'Worth', 'Burstowe', 'wburstowef@twitter.com', '620 390 4759', 'Colombia', '70507 Messerschmidt Center', '5010128585595461');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('slorentzg', 'Shelagh', 'Lorentz', 'slorentzg@imgur.com', '855 718 2771', 'Myanmar', '6 Lunder Lane', '5388828076948566');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('fdalessandroh', 'Feodora', 'D''Alessandro', 'fdalessandroh@webnode.com', '596 709 5158', 'China', '9168 Shoshone Park', '5100147749114564');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('cyearnsi', 'Colas', 'Yearns', 'cyearnsi@wired.com', '982 608 3312', 'Indonesia', '00 Dakota Avenue', '3544642082173135');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('sweekleyj', 'Shaun', 'Weekley', 'sweekleyj@arizona.edu', '730 777 1091', 'Russia', '8373 Gina Crossing', '4405961572484083');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('dbrimelowk', 'Delaney', 'Brimelow', 'dbrimelowk@army.mil', '417 196 7732', 'China', '4 Mayfield Street', '676106424379479902');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('mtantonl', 'Mariann', 'Tanton', 'mtantonl@storify.com', '936 532 9631', 'China', '39652 Mallard Hill', '3581226479298269');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('mcowdraym', 'Mickie', 'Cowdray', 'mcowdraym@wisc.edu', '441 553 8249', 'Chile', '09586 Lindbergh Drive', '3563012397595339');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('fwackettn', 'Florette', 'Wackett', 'fwackettn@cnn.com', '895 463 9291', 'Portugal', '009 Chinook Trail', '56022309498176073');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('jguerreruo', 'Jase', 'Guerreru', 'jguerreruo@networksolutions.com', '323 450 1059', 'Vietnam', '1 Blaine Terrace', '30213156040340');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('dkneathp', 'Doralynn', 'Kneath', 'dkneathp@mlb.com', '388 841 6170', 'Philippines', '8 Monica Center', '30459946001528');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('mwadmanq', 'Merrill', 'Wadman', 'mwadmanq@globo.com', '405 685 2072', 'Tunisia', '16070 Bayside Court', '5610724948802000');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('glautier', 'Gordon', 'Lautie', 'glautier@adobe.com', '692 800 3136', 'Egypt', '65742 Southridge Park', '4041376408249057');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('tsilbys', 'Talya', 'Silby', 'tsilbys@dyndns.org', '565 690 3632', 'Republic of the Congo', '655 Harper Avenue', '5108754760566721');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('afoyt', 'Alasdair', 'Foy', 'afoyt@unc.edu', '756 423 1994', 'Indonesia', '8 Bowman Trail', '3572676485785249');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('fjaffreyu', 'Florella', 'Jaffrey', 'fjaffreyu@bing.com', '130 300 4880', 'Poland', '2613 Mcguire Parkway', '3564640699191610');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('pkinanev', 'Pancho', 'Kinane', 'pkinanev@amazon.co.jp', '796 346 7420', 'Portugal', '95135 Sachs Center', '5584737631227378');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('rblackburnew', 'Richard', 'Blackburne', 'rblackburnew@ucsd.edu', '526 826 5250', 'France', '466 Eastlawn Court', '3569438378953011');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('scorryx', 'Sol', 'Corry', 'scorryx@hao123.com', '381 460 3965', 'Poland', '18295 Hanover Avenue', '3529129738341562');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('rsparshatty', 'Rustie', 'Sparshatt', 'rsparshatty@zdnet.com', '105 431 7957', 'France', '35 Meadow Ridge Place', '374283799617022');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('tiacovinoz', 'Tadio', 'Iacovino', 'tiacovinoz@apache.org', '417 227 4417', 'China', '40037 Eliot Hill', '5419743573526885');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('bshreeve10', 'Boone', 'Shreeve', 'bshreeve10@auda.org.au', '680 145 0492', 'China', '5733 Kensington Lane', '3577214595326327');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('cmessruther11', 'Corliss', 'Messruther', 'cmessruther11@flickr.com', '841 795 8907', 'Nigeria', '9724 Valley Edge Pass', '3589469743777419');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('rdengel12', 'Rebbecca', 'Dengel', 'rdengel12@narod.ru', '226 235 1968', 'Philippines', '7 Forest Dale Circle', '4844377835721816');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('kprangley13', 'Kippie', 'Prangley', 'kprangley13@xrea.com', '591 482 1554', 'China', '8914 Talisman Point', '3581069160654790');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('runger14', 'Rebbecca', 'Unger', 'runger14@ucoz.ru', '412 703 3901', 'Bangladesh', '678 Coleman Park', '3530582775754088');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('agebhard15', 'Aldrich', 'Gebhard', 'agebhard15@nasa.gov', '862 627 1744', 'China', '06 Village Place', '30536646373297');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('amaykin16', 'Alvina', 'Maykin', 'amaykin16@cbsnews.com', '676 557 2445', 'Portugal', '4 Morrow Hill', '6762097732835153');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('cphilip17', 'Crysta', 'Philip', 'cphilip17@w3.org', '853 783 1034', 'Indonesia', '95 8th Crossing', '3545778411968974');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('pdunster18', 'Peyton', 'Dunster', 'pdunster18@un.org', '168 129 6990', 'Netherlands', '56 Dixon Place', '201918601776990');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('udallender19', 'Ulrika', 'Dallender', 'udallender19@mayoclinic.com', '383 381 7482', 'China', '562 Morrow Crossing', '3530203310953990');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('geglese1a', 'Gay', 'Eglese', 'geglese1a@1688.com', '992 523 8858', 'Brazil', '9 Center Lane', '30267837293744');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('ssmewing1b', 'Sergent', 'Smewing', 'ssmewing1b@last.fm', '615 775 7023', 'China', '452 Kedzie Avenue', '30021396884504');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('edurker1c', 'Emiline', 'Durker', 'edurker1c@digg.com', '289 457 6825', 'Laos', '15 Thackeray Road', '5010128420959351');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('gbelvard1d', 'Gerrie', 'Belvard', 'gbelvard1d@blogtalkradio.com', '743 380 7122', 'China', '3086 Bultman Road', '372301001885500');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('ahruska1e', 'Alonzo', 'Hruska', 'ahruska1e@photobucket.com', '995 522 6553', 'Indonesia', '30224 Butternut Alley', '5610643686756493');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('smulvaney1f', 'Sybille', 'Mulvaney', 'smulvaney1f@wsj.com', '768 700 8084', 'Sweden', '4032 Johnson Pass', '3558727766409013');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('pgrigoriscu1g', 'Poppy', 'Grigoriscu', 'pgrigoriscu1g@abc.net.au', '408 358 5187', 'United States', '62 Hayes Court', '337941600261902');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('mmorriss1h', 'Marys', 'Morriss', 'mmorriss1h@paypal.com', '675 641 0557', 'China', '0 Drewry Plaza', '6706687918622082500');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('efadian1i', 'Estell', 'Fadian', 'efadian1i@chicagotribune.com', '820 927 9550', 'China', '9104 Calypso Terrace', '3548465281929701');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('dbaxendale1j', 'Dyna', 'Baxendale', 'dbaxendale1j@ca.gov', '832 187 6202', 'South Africa', '4 Glacier Hill Place', '6394926001189593');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('scolclough1k', 'Sidney', 'Colclough', 'scolclough1k@last.fm', '334 906 4572', 'Peru', '271 Lakeland Crossing', '5602214981475195');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('mbussel1l', 'Maison', 'Bussel', 'mbussel1l@ovh.net', '745 539 7602', 'France', '3 Rutledge Place', '4026475451916320');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('ajeffree1m', 'Adrianne', 'Jeffree', 'ajeffree1m@dailymail.co.uk', '226 960 3733', 'China', '473 Fallview Point', '4041592486617');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('fbirchenough1n', 'Frannie', 'Birchenough', 'fbirchenough1n@mtv.com', '640 288 6301', 'Indonesia', '4 Trailsway Circle', '4903002177981484756');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('dcardero1o', 'Dolli', 'Cardero', 'dcardero1o@1688.com', '148 623 5282', 'Poland', '4 Namekagon Court', '3574764949301122');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('rtoll1p', 'Rayner', 'Toll', 'rtoll1p@timesonline.co.uk', '942 944 5294', 'China', '09857 Jay Court', '374283803817626');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('lgittoes1q', 'Leanna', 'Gittoes', 'lgittoes1q@stanford.edu', '514 630 4400', 'Indonesia', '781 Holmberg Circle', '4041374859858');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('jlurriman1r', 'Janey', 'Lurriman', 'jlurriman1r@icio.us', '562 514 5075', 'Brazil', '29926 Saint Paul Way', '5193337685540496');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('pmuzzillo1s', 'Paloma', 'Muzzillo', 'pmuzzillo1s@army.mil', '180 716 3489', 'Indonesia', '348 Longview Parkway', '3534450142079843');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('aekell1t', 'Allan', 'Ekell', 'aekell1t@java.com', '187 377 2656', 'Indonesia', '901 Claremont Lane', '201401612330404');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('psilbersak1u', 'Philomena', 'Silbersak', 'psilbersak1u@ustream.tv', '850 805 1499', 'Malaysia', '83687 Elgar Road', '3542211713395038');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('lboyton1v', 'Lynnea', 'Boyton', 'lboyton1v@paypal.com', '760 995 2522', 'Latvia', '348 Holy Cross Crossing', '3571485776075562');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('achotty1w', 'Ashlen', 'Chotty', 'achotty1w@fema.gov', '982 491 1361', 'France', '7 Surrey Park', '0604063260243272');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('acraker1x', 'Agace', 'Craker', 'acraker1x@yahoo.com', '150 158 3561', 'Brazil', '9 Ruskin Parkway', '30565286183351');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('fwithams1y', 'Freeman', 'Withams', 'fwithams1y@posterous.com', '588 283 4814', 'Venezuela', '260 7th Street', '3580076173599822');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('kpycock1z', 'Kathrine', 'Pycock', 'kpycock1z@youtu.be', '119 574 1525', 'Philippines', '9 Columbus Terrace', '5180322602865999');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('dtipping20', 'Darin', 'Tipping', 'dtipping20@house.gov', '702 207 0467', 'Greece', '1186 Arkansas Way', '3554099171464544');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('cdakin21', 'Carly', 'Dakin', 'cdakin21@dmoz.org', '616 290 6370', 'Madagascar', '7 Nobel Hill', '3537707378397562');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('jeckh22', 'Janaya', 'Eckh', 'jeckh22@creativecommons.org', '575 533 2087', 'China', '238 Hanson Terrace', '3586885706893476');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('dgaroghan23', 'Darci', 'Garoghan', 'dgaroghan23@uol.com.br', '628 791 9951', 'Cambodia', '44 Lake View Point', '201619015867405');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('awatling24', 'Ambrosi', 'Watling', 'awatling24@about.me', '807 270 8878', 'France', '54866 Bluejay Terrace', '4913806116084250');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('skebell25', 'Sandra', 'Kebell', 'skebell25@istockphoto.com', '387 927 6267', 'Portugal', '06696 Hoffman Parkway', '3575882715668695');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('kbergeau26', 'Kippie', 'Bergeau', 'kbergeau26@answers.com', '876 871 6089', 'Bonaire, Saint Eustatius and Saba ', '9 Arapahoe Way', '5048372724486184');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('gvella27', 'Geri', 'Vella', 'gvella27@examiner.com', '770 441 6274', 'United States', '61763 Eagle Crest Way', '3552026916590681');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('nderisley28', 'Neville', 'Derisley', 'nderisley28@nymag.com', '893 788 0094', 'Philippines', '485 Nobel Center', '30476273007829');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('ikrzyzaniak29', 'Ira', 'Krzyzaniak', 'ikrzyzaniak29@hibu.com', '408 617 5141', 'Indonesia', '2705 Darwin Point', '4893771467353619');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('krobbe2a', 'Karlee', 'Robbe', 'krobbe2a@twitpic.com', '755 518 8513', 'China', '03840 Gerald Lane', '3535289828279858');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('sblowick2b', 'Selle', 'Blowick', 'sblowick2b@dailymotion.com', '537 581 3094', 'China', '8 Eliot Drive', '5602220352229301');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('dgomez2c', 'Dyann', 'Gomez', 'dgomez2c@alibaba.com', '842 697 9459', 'China', '7921 School Point', '6759154892187547376');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('bbunclark2d', 'Binky', 'Bunclark', 'bbunclark2d@myspace.com', '176 436 8975', 'China', '66 1st Avenue', '3551340621006789');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('osefton2e', 'Olwen', 'Sefton', 'osefton2e@spiegel.de', '911 471 3504', 'Indonesia', '4487 Darwin Terrace', '5002353276620846');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('bkhalid2f', 'Birgitta', 'Khalid', 'bkhalid2f@slate.com', '494 201 4414', 'China', '0 Hintze Lane', '201449825948991');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('gchristophersen2g', 'Gunther', 'Christophersen', 'gchristophersen2g@artisteer.com', '803 879 2806', 'Sri Lanka', '520 Linden Trail', '4175008109285944');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('rtewkesbury2h', 'Renae', 'Tewkesbury', 'rtewkesbury2h@cafepress.com', '847 640 8604', 'Thailand', '357 Cottonwood Terrace', '3550766676805850');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('kdolligon2i', 'Kerrie', 'Dolligon', 'kdolligon2i@mysql.com', '522 756 5843', 'Japan', '6 Pine View Circle', '4508501618852525');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('nbrandenberg2j', 'Nigel', 'Brandenberg', 'nbrandenberg2j@google.es', '497 386 4171', 'Philippines', '3 Jenna Trail', '3539123456131832');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('mcasewell2k', 'Matelda', 'Casewell', 'mcasewell2k@phoca.cz', '158 631 1999', 'Finland', '07715 Texas Pass', '5602250591438389');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('bbirrel2l', 'Brendis', 'Birrel', 'bbirrel2l@sogou.com', '397 324 3130', 'Croatia', '99 Crest Line Pass', '50380255440770019');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('nhessel2m', 'Nigel', 'Hessel', 'nhessel2m@google.co.jp', '360 929 7499', 'Angola', '147 Burning Wood Street', '5602259410704616');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('umedgwick2n', 'Udell', 'Medgwick', 'umedgwick2n@narod.ru', '989 921 6174', 'Brazil', '6681 Lakewood Gardens Alley', '375362621272815');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('gscambler2o', 'Grier', 'Scambler', 'gscambler2o@cbsnews.com', '870 482 7490', 'Indonesia', '94 Red Cloud Junction', '6762832083323513423');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('bandrieux2p', 'Bailie', 'Andrieux', 'bandrieux2p@wikispaces.com', '913 933 5678', 'China', '41949 Tomscot Road', '3541955172216009');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('fdillet2q', 'Ferris', 'Dillet', 'fdillet2q@hostgator.com', '438 955 5947', 'Norway', '0 Briar Crest Terrace', '4917096698854785');
insert into users (username, first_name, last_name, email, phone_number, country, billing_address, cc_number) values ('wridges2r', 'Waiter', 'Ridges', 'wridges2r@newsvine.com', '954 262 8330', 'Chile', '309 Goodland Center', '3571719368887624');


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO vod (username,title)
SELECT username,title FROM users, movies
ORDER BY random() LIMIT 1000;

SELECT * FROM vod;
