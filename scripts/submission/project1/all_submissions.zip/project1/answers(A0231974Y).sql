/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/

 The code is written for PostgreSQL 


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
The CUSTOMER table records the user ID (unique identifier), user name, and user gender, including male and female.
The record ID of the product table is the unique identifier of the product. The product name is a string.
The orders table records user purchases of products, identifying which products a customer purchased, where OID is the ID of the Orders table for non-repeat primary key.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
create table customer 
(
CID INT PRIMARY KEY,
first_name VARCHAR(30),
last_name VARCHAR(30),
gender VARCHAR(4)
);

create table product 
(
PID int primary key,
Pname VARCHAR(30)
);

create table orders 
(
OID INT PRIMARY KEY,
CID INT , foreign key(CID) references customer(CID),
PID INT ,foreign key(PID) references product(PID)
);


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
insert into customer (CID, first_name, last_name, gender) values (1, 'Salomi', 'Weekly', 'Female');
insert into customer (CID, first_name, last_name, gender) values (2, 'Ches', 'Courtier', 'Male');
insert into customer (CID, first_name, last_name, gender) values (3, 'Deeyn', 'Stannas', 'Female');
insert into customer (CID, first_name, last_name, gender) values (4, 'Hans', 'Marns', 'Female');
insert into customer (CID, first_name, last_name, gender) values (5, 'Flory', 'Farfull', 'Female');
insert into customer (CID, first_name, last_name, gender) values (6, 'Paule', 'Lydden', 'Female');
insert into customer (CID, first_name, last_name, gender) values (7, 'Reggie', 'Riddles', 'Male');
insert into customer (CID, first_name, last_name, gender) values (8, 'Darill', 'Gillingwater', 'Male');
insert into customer (CID, first_name, last_name, gender) values (9, 'Isadora', 'Trump', 'Male');
insert into customer (CID, first_name, last_name, gender) values (10, 'Gabby', 'Olford', 'Female');
insert into customer (CID, first_name, last_name, gender) values (11, 'Deonne', 'Anneslie', 'Female');
insert into customer (CID, first_name, last_name, gender) values (12, 'Hart', 'Giannasi', 'Male');
insert into customer (CID, first_name, last_name, gender) values (13, 'Gloriana', 'Botten', 'Male');
insert into customer (CID, first_name, last_name, gender) values (14, 'Mikaela', 'Watkins', 'Male');
insert into customer (CID, first_name, last_name, gender) values (15, 'Bobinette', 'Skipworth', 'Male');
insert into customer (CID, first_name, last_name, gender) values (16, 'Natassia', 'Varsey', 'Male');
insert into customer (CID, first_name, last_name, gender) values (17, 'Kip', 'Thewys', 'Female');
insert into customer (CID, first_name, last_name, gender) values (18, 'Suki', 'Doidge', 'Male');
insert into customer (CID, first_name, last_name, gender) values (19, 'Upton', 'Linacre', 'Female');
insert into customer (CID, first_name, last_name, gender) values (20, 'Shandy', 'Hartles', 'Female');
insert into customer (CID, first_name, last_name, gender) values (21, 'Vivi', 'Greenhalgh', 'Female');
insert into customer (CID, first_name, last_name, gender) values (22, 'Ulric', 'Becerra', 'Female');
insert into customer (CID, first_name, last_name, gender) values (23, 'Petr', 'Legat', 'Male');
insert into customer (CID, first_name, last_name, gender) values (24, 'Chrisy', 'Poulson', 'Male');
insert into customer (CID, first_name, last_name, gender) values (25, 'Rowan', 'Jermyn', 'Male');
insert into customer (CID, first_name, last_name, gender) values (26, 'Kathie', 'Heitz', 'Female');
insert into customer (CID, first_name, last_name, gender) values (27, 'Sollie', 'Mattiazzi', 'Male');
insert into customer (CID, first_name, last_name, gender) values (28, 'Annabella', 'Tombs', 'Male');
insert into customer (CID, first_name, last_name, gender) values (29, 'Angus', 'Rummins', 'Female');
insert into customer (CID, first_name, last_name, gender) values (30, 'Therine', 'Tumini', 'Male');
insert into customer (CID, first_name, last_name, gender) values (31, 'Smitty', 'Apfelmann', 'Male');
insert into customer (CID, first_name, last_name, gender) values (32, 'Arvy', 'Huegett', 'Female');
insert into customer (CID, first_name, last_name, gender) values (33, 'Sherie', 'Corbitt', 'Male');
insert into customer (CID, first_name, last_name, gender) values (34, 'Mela', 'Hodinton', 'Male');
insert into customer (CID, first_name, last_name, gender) values (35, 'Angie', 'Clouter', 'Female');
insert into customer (CID, first_name, last_name, gender) values (36, 'Morey', 'Carhart', 'Male');
insert into customer (CID, first_name, last_name, gender) values (37, 'Blinnie', 'Rolfe', 'Female');
insert into customer (CID, first_name, last_name, gender) values (38, 'Gaylene', 'Mehew', 'Male');
insert into customer (CID, first_name, last_name, gender) values (39, 'Gaven', 'Codling', 'Male');
insert into customer (CID, first_name, last_name, gender) values (40, 'Clerc', 'Freeberne', 'Female');
insert into customer (CID, first_name, last_name, gender) values (41, 'Shell', 'Mingaye', 'Female');
insert into customer (CID, first_name, last_name, gender) values (42, 'Goober', 'Niblock', 'Male');
insert into customer (CID, first_name, last_name, gender) values (43, 'Leif', 'Meatyard', 'Male');
insert into customer (CID, first_name, last_name, gender) values (44, 'Buiron', 'Twinberrow', 'Female');
insert into customer (CID, first_name, last_name, gender) values (45, 'Corissa', 'Basile', 'Female');
insert into customer (CID, first_name, last_name, gender) values (46, 'Timofei', 'Kasman', 'Female');
insert into customer (CID, first_name, last_name, gender) values (47, 'Libbie', 'Vitte', 'Male');
insert into customer (CID, first_name, last_name, gender) values (48, 'Ashla', 'Pantridge', 'Male');
insert into customer (CID, first_name, last_name, gender) values (49, 'Rhodie', 'Lamberts', 'Female');
insert into customer (CID, first_name, last_name, gender) values (50, 'Vilhelmina', 'Grubey', 'Female');
insert into customer (CID, first_name, last_name, gender) values (51, 'Lindi', 'Gors', 'Female');
insert into customer (CID, first_name, last_name, gender) values (52, 'Ruthy', 'O''Shavlan', 'Male');
insert into customer (CID, first_name, last_name, gender) values (53, 'Judon', 'Gotcliff', 'Female');
insert into customer (CID, first_name, last_name, gender) values (54, 'Darnell', 'Salvage', 'Male');
insert into customer (CID, first_name, last_name, gender) values (55, 'Valerye', 'Batalini', 'Female');
insert into customer (CID, first_name, last_name, gender) values (56, 'Tiff', 'Maylour', 'Female');
insert into customer (CID, first_name, last_name, gender) values (57, 'Sherlock', 'Parmer', 'Male');
insert into customer (CID, first_name, last_name, gender) values (58, 'Marlo', 'Winscomb', 'Male');
insert into customer (CID, first_name, last_name, gender) values (59, 'Angelico', 'Pinkerton', 'Male');
insert into customer (CID, first_name, last_name, gender) values (60, 'Maggee', 'Kemmey', 'Male');
insert into customer (CID, first_name, last_name, gender) values (61, 'Darryl', 'Yarnold', 'Male');
insert into customer (CID, first_name, last_name, gender) values (62, 'Frazier', 'Riggert', 'Male');
insert into customer (CID, first_name, last_name, gender) values (63, 'Delmore', 'Costock', 'Female');
insert into customer (CID, first_name, last_name, gender) values (64, 'Thorstein', 'Rennison', 'Female');
insert into customer (CID, first_name, last_name, gender) values (65, 'Agnola', 'Paquet', 'Female');
insert into customer (CID, first_name, last_name, gender) values (66, 'Jeramey', 'Seabridge', 'Female');
insert into customer (CID, first_name, last_name, gender) values (67, 'Rochell', 'Fitter', 'Male');
insert into customer (CID, first_name, last_name, gender) values (68, 'Brodie', 'Triplett', 'Female');
insert into customer (CID, first_name, last_name, gender) values (69, 'Emmit', 'Garrat', 'Female');
insert into customer (CID, first_name, last_name, gender) values (70, 'Philipa', 'Klimochkin', 'Male');
insert into customer (CID, first_name, last_name, gender) values (71, 'Janey', 'Lassetter', 'Male');
insert into customer (CID, first_name, last_name, gender) values (72, 'Caroline', 'Kuzemka', 'Female');
insert into customer (CID, first_name, last_name, gender) values (73, 'Kinna', 'Prendeville', 'Male');
insert into customer (CID, first_name, last_name, gender) values (74, 'Allie', 'Zelner', 'Female');
insert into customer (CID, first_name, last_name, gender) values (75, 'Roarke', 'Cawsey', 'Female');
insert into customer (CID, first_name, last_name, gender) values (76, 'Franklin', 'Cescotti', 'Female');
insert into customer (CID, first_name, last_name, gender) values (77, 'Amara', 'Tonbridge', 'Female');
insert into customer (CID, first_name, last_name, gender) values (78, 'Carmelle', 'Curuclis', 'Female');
insert into customer (CID, first_name, last_name, gender) values (79, 'Andreana', 'Hoonahan', 'Female');
insert into customer (CID, first_name, last_name, gender) values (80, 'Abigail', 'Elliff', 'Male');
insert into customer (CID, first_name, last_name, gender) values (81, 'Shelagh', 'Tooley', 'Female');
insert into customer (CID, first_name, last_name, gender) values (82, 'Nola', 'Hughlock', 'Female');
insert into customer (CID, first_name, last_name, gender) values (83, 'Daniella', 'Huttley', 'Male');
insert into customer (CID, first_name, last_name, gender) values (84, 'Louise', 'Magor', 'Female');
insert into customer (CID, first_name, last_name, gender) values (85, 'Willey', 'Baumler', 'Female');
insert into customer (CID, first_name, last_name, gender) values (86, 'Keefer', 'Jan', 'Female');
insert into customer (CID, first_name, last_name, gender) values (87, 'Georgette', 'Sitch', 'Male');
insert into customer (CID, first_name, last_name, gender) values (88, 'Dorice', 'Possa', 'Male');
insert into customer (CID, first_name, last_name, gender) values (89, 'Dareen', 'Strahan', 'Male');
insert into customer (CID, first_name, last_name, gender) values (90, 'Alec', 'Rockcliff', 'Male');
insert into customer (CID, first_name, last_name, gender) values (91, 'Tersina', 'Eisenberg', 'Female');
insert into customer (CID, first_name, last_name, gender) values (92, 'Joyann', 'Ilewicz', 'Male');
insert into customer (CID, first_name, last_name, gender) values (93, 'Dorena', 'Tysall', 'Female');
insert into customer (CID, first_name, last_name, gender) values (94, 'Katharine', 'O''Nions', 'Female');
insert into customer (CID, first_name, last_name, gender) values (95, 'Danika', 'Rawlins', 'Male');
insert into customer (CID, first_name, last_name, gender) values (96, 'Kori', 'Betho', 'Male');
insert into customer (CID, first_name, last_name, gender) values (97, 'Melissa', 'Kordova', 'Female');
insert into customer (CID, first_name, last_name, gender) values (98, 'Dee', 'Maris', 'Male');
insert into customer (CID, first_name, last_name, gender) values (99, 'Gleda', 'Arrow', 'Female');
insert into customer (CID, first_name, last_name, gender) values (100, 'Kalil', 'Moreinu', 'Female');

insert into product (Pid, pname) values (1, 'Melon - Watermelon Yellow');
insert into product (Pid, pname) values (2, 'Onions - White');
insert into product (Pid, pname) values (3, 'Cheese - Brick With Pepper');
insert into product (Pid, pname) values (4, 'Chicken Giblets');
insert into product (Pid, pname) values (5, 'Remy Red Berry Infusion');
insert into product (Pid, pname) values (6, 'Thyme - Lemon, Fresh');
insert into product (Pid, pname) values (7, 'Rice - Brown');
insert into product (Pid, pname) values (8, 'Shallots');
insert into product (Pid, pname) values (9, 'Apple - Delicious, Golden');
insert into product (Pid, pname) values (10, 'Bread - French Stick');
insert into product (Pid, pname) values (11, 'Cream - 35%');
insert into product (Pid, pname) values (12, 'Steampan - Foil');
insert into product (Pid, pname) values (13, 'Cheese - Brie,danish');
insert into product (Pid, pname) values (14, 'Food Colouring - Green');
insert into product (Pid, pname) values (15, 'Pepper - Chillies, Crushed');
insert into product (Pid, pname) values (16, 'Potatoes - Instant, Mashed');
insert into product (Pid, pname) values (17, 'Puree - Pear');
insert into product (Pid, pname) values (18, 'Vodka - Smirnoff');
insert into product (Pid, pname) values (19, 'Wine - White, Pinot Grigio');
insert into product (Pid, pname) values (20, 'Ham - Cooked Italian');
insert into product (Pid, pname) values (21, 'Chinese Foods - Thick Noodles');
insert into product (Pid, pname) values (22, 'Rum - Cream, Amarula');
insert into product (Pid, pname) values (23, 'Pork - Caul Fat');
insert into product (Pid, pname) values (24, 'Lotus Leaves');
insert into product (Pid, pname) values (25, 'Mangoes');
insert into product (Pid, pname) values (26, 'Tart Shells - Savory, 3');
insert into product (Pid, pname) values (27, 'Calypso - Strawberry Lemonade');
insert into product (Pid, pname) values (28, 'Contreau');
insert into product (Pid, pname) values (29, 'Petite Baguette');
insert into product (Pid, pname) values (30, 'Cheese - Goat');
insert into product (Pid, pname) values (31, 'Pork - Bacon, Double Smoked');
insert into product (Pid, pname) values (32, 'Oven Mitts 17 Inch');
insert into product (Pid, pname) values (33, 'Sobe - Berry Energy');
insert into product (Pid, pname) values (34, 'Pineapple - Canned, Rings');
insert into product (Pid, pname) values (35, 'Rice - Aborio');
insert into product (Pid, pname) values (36, 'Wine - Puligny Montrachet A.');
insert into product (Pid, pname) values (37, 'Soup - Campbells - Tomato');
insert into product (Pid, pname) values (38, 'Food Colouring - Pink');
insert into product (Pid, pname) values (39, 'Appetizer - Veg Assortment');
insert into product (Pid, pname) values (40, 'Versatainer Nc - 8288');
insert into product (Pid, pname) values (41, 'Lamb - Bones');
insert into product (Pid, pname) values (42, 'Doilies - 7, Paper');
insert into product (Pid, pname) values (43, 'Paper Towel Touchless');
insert into product (Pid, pname) values (44, 'Yoplait - Strawbrasp Peac');
insert into product (Pid, pname) values (45, 'Cheese - La Sauvagine');
insert into product (Pid, pname) values (46, 'Soup - French Can Pea');
insert into product (Pid, pname) values (47, 'Cinnamon Buns Sticky');
insert into product (Pid, pname) values (48, 'Eggs - Extra Large');
insert into product (Pid, pname) values (49, 'Pears - Bosc');
insert into product (Pid, pname) values (50, 'Mushroom - Crimini');
insert into product (Pid, pname) values (51, 'Jam - Raspberry');
insert into product (Pid, pname) values (52, 'Bread - Bagels, Plain');
insert into product (Pid, pname) values (53, 'Jack Daniels');
insert into product (Pid, pname) values (54, 'Soup - Boston Clam Chowder');
insert into product (Pid, pname) values (55, 'Puff Pastry - Sheets');
insert into product (Pid, pname) values (56, 'Buffalo - Tenderloin');
insert into product (Pid, pname) values (57, 'Flour - Corn, Fine');
insert into product (Pid, pname) values (58, 'Icecream - Dibs');
insert into product (Pid, pname) values (59, 'Coconut - Shredded, Unsweet');
insert into product (Pid, pname) values (60, 'Beets - Pickled');
insert into product (Pid, pname) values (61, 'Paste - Black Olive');
insert into product (Pid, pname) values (62, 'Temperature Recording Station');
insert into product (Pid, pname) values (63, 'Wine - Muscadet Sur Lie');
insert into product (Pid, pname) values (64, 'Dc Hikiage Hira Huba');
insert into product (Pid, pname) values (65, 'Rice Pilaf, Dry,package');
insert into product (Pid, pname) values (66, 'Onions - Vidalia');
insert into product (Pid, pname) values (67, 'Flavouring - Rum');
insert into product (Pid, pname) values (68, 'Wine - Cahors Ac 2000, Clos');
insert into product (Pid, pname) values (69, 'Flower - Daisies');
insert into product (Pid, pname) values (70, 'Wine - Ruffino Chianti');
insert into product (Pid, pname) values (71, 'Potatoes - Mini White 3 Oz');
insert into product (Pid, pname) values (72, 'Seedlings - Clamshell');
insert into product (Pid, pname) values (73, 'Milkettes - 2%');
insert into product (Pid, pname) values (74, 'Vinegar - Tarragon');
insert into product (Pid, pname) values (75, 'Wine - Vovray Sec Domaine Huet');
insert into product (Pid, pname) values (76, 'Wine - Chablis 2003 Champs');
insert into product (Pid, pname) values (77, 'Wine - Ruffino Chianti Classico');
insert into product (Pid, pname) values (78, 'Sage - Fresh');
insert into product (Pid, pname) values (79, 'Brandy - Bar');
insert into product (Pid, pname) values (80, 'Bread - Italian Sesame Poly');
insert into product (Pid, pname) values (81, 'Sage - Ground');
insert into product (Pid, pname) values (82, 'Chinese Lemon Pork');
insert into product (Pid, pname) values (83, 'Wood Chips - Regular');
insert into product (Pid, pname) values (84, 'Veal - Bones');
insert into product (Pid, pname) values (85, 'Pork - Side Ribs');
insert into product (Pid, pname) values (86, 'Chicken - Base');
insert into product (Pid, pname) values (87, 'Coffee - Frthy Coffee Crisp');
insert into product (Pid, pname) values (88, 'Lemonade - Island Tea, 591 Ml');
insert into product (Pid, pname) values (89, 'Easy Off Oven Cleaner');
insert into product (Pid, pname) values (90, 'Wine - Ruffino Chianti Classico');
insert into product (Pid, pname) values (91, 'Buffalo - Striploin');
insert into product (Pid, pname) values (92, 'Carroway Seed');
insert into product (Pid, pname) values (93, 'Sage - Rubbed');
insert into product (Pid, pname) values (94, 'Steamers White');
insert into product (Pid, pname) values (95, 'Lemonade - Natural, 591 Ml');
insert into product (Pid, pname) values (96, 'Lemon Pepper');
insert into product (Pid, pname) values (97, 'Corn Meal');
insert into product (Pid, pname) values (98, 'Pepperoni Slices');
insert into product (Pid, pname) values (99, 'Flower - Dish Garden');
insert into product (Pid, pname) values (100, 'Coconut - Shredded, Unsweet');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
insert into orders
select rank() over(order by cid,pid),cid,pid from customer,product
 ORDER BY random() LIMIT 1000;

