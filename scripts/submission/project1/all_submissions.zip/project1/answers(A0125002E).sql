/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*   Name: Hpone Myat Khine (A0125002E)                                 */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*In a fictional country Sinyanpur, education is compulsory starting at primary school level. 
There is often competition for the limited placesso balloting may be needed depending on the number of applications to the school. 

For the future intake in year 2023, to have an idea of the popularity of the schools, an initial round of 
application is made containing information about the incoming students, the schools, & the applications to them.

The database records the information about the incoming student. It contains the students' first name, last name, one parent's name,parent's email,
gender, date of birth to ensure that the student is not too young or too old (for 2023 to be aged between 6 - 7 years), postal code & the student's ID, whereby student ID is used to identify the student.

The database records information on the school too containing the school name which is used as the identification method, & the postal code of the school.

The database has the applications information which shows the student ID and the school names, in essence the schools applied to 
by each student. 

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE potential_student(
  first_name VARCHAR(64) NOT NULL, 
  last_name VARCHAR(64) NOT NULL, 
  parent_name VARCHAR(64) NOT NULL, 
  parent_email VARCHAR(64) UNIQUE NOT NULL, 
  gender VARCHAR(9) NOT NULL, 
  date_of_birth DATE NOT NULL CHECK (
    (date_of_birth >= '2016-01-02') 
    AND(date_of_birth <= ' 2017-01-01')
  ), 
  postal_code INT NOT NULL, 
  student_ID VARCHAR(9) PRIMARY KEY
);

CREATE TABLE primary_school(
  school_name VARCHAR(64) PRIMARY KEY, 
  School_postal_code INT NOT NULL
);


CREATE TABLE application(
  student_ID VARCHAR(9) REFERENCES potential_student(student_ID) 
	ON UPDATE CASCADE ON DELETE CASCADE 
	DEFERRABLE INITIALLY DEFERRED, 
    school_name VARCHAR(64) REFERENCES primary_school(school_name) 
	ON UPDATE CASCADE ON DELETE CASCADE 
	DEFERRABLE INITIALLY DEFERRED
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Kassia', 'Toping', 'Averil', 'atoping0@about.me', 'Male', '2016-03-13', '863783', 'S7709552I');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Tabby', 'Kretschmer', 'Henrieta', 'hkretschmer1@cpanel.net', 'Female', '2016-09-30', '058312', 'S8625620G');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Ruby', 'Stonnell', 'Crichton', 'cstonnell2@feedburner.com', 'Male', '2016-10-12', '909458', 'S2007452Y');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Jillie', 'Boliver', 'Janifer', 'jboliver3@geocities.com', 'Male', '2016-02-24', '928952', 'S1627522E');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Christan', 'Cowan', 'Shoshanna', 'scowan4@youtube.com', 'Female', '2016-09-29', '015649', 'S6912295H');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Lettie', 'Padmore', 'Galina', 'gpadmore5@exblog.jp', 'Female', '2016-11-27', '809753', 'S8701213J');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Harold', 'Castagnasso', 'Florenza', 'fcastagnasso6@ebay.co.uk', 'Male', '2016-03-19', '852542', 'S2641418B');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Goran', 'Assur', 'Gleda', 'gassur7@ucoz.ru', 'Female', '2016-08-18', '845651', 'S3487780W');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Patrice', 'Ruperto', 'Othella', 'oruperto8@storify.com', 'Male', '2016-12-07', '338612', 'S8215858D');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Bentlee', 'Copeland', 'Hedda', 'hcopeland9@cyberchimps.com', 'Female', '2016-08-18', '126221', 'S0215376D');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Christos', 'Syde', 'Eloise', 'esydea@springer.com', 'Male', '2016-07-24', '418636', 'S7284837W');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Karalynn', 'Dohmann', 'Adoree', 'adohmannb@g.co', 'Male', '2016-12-16', '422897', 'S7941354L');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Karena', 'Mangan', 'Aigneis', 'amanganc@bloomberg.com', 'Male', '2016-05-02', '698112', 'S5308869L');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Irwinn', 'Pietrusiak', 'Carline', 'cpietrusiakd@ca.gov', 'Male', '2016-08-15', '850396', 'S3692746U');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Ardelia', 'Lau', 'Rafa', 'rlaue@google.ca', 'Female', '2016-09-27', '037729', 'S2430051C');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Marietta', 'Alenin', 'Katinka', 'kaleninf@webeden.co.uk', 'Male', '2016-11-24', '095689', 'S7396359B');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Kamila', 'Leftridge', 'Netta', 'nleftridgeg@oaic.gov.au', 'Male', '2016-04-19', '349432', 'S2164119B');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Chilton', 'Whetnall', 'Billye', 'bwhetnallh@51.la', 'Male', '2016-05-08', '703535', 'S5814779L');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Ninette', 'Spivey', 'Helenelizabeth', 'hspiveyi@rakuten.co.jp', 'Female', '2016-11-22', '290165', 'S1245552B');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Boony', 'MacGovern', 'Deloria', 'dmacgovernj@unesco.org', 'Male', '2016-05-14', '413935', 'S3119105E');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Emili', 'Wichard', 'Mattie', 'mwichardk@whitehouse.gov', 'Female', '2016-03-06', '812988', 'S1790384E');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Melantha', 'Adenot', 'Loydie', 'ladenotl@chronoengine.com', 'Male', '2016-03-26', '264471', 'S7802744P');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Devondra', 'Gulston', 'Urban', 'ugulstonm@cnet.com', 'Male', '2016-12-01', '192634', 'S1426274D');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Stormie', 'Waddilow', 'Dillie', 'dwaddilown@wp.com', 'Female', '2016-06-28', '668640', 'S3687934B');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Christabella', 'Camillo', 'Roma', 'rcamilloo@answers.com', 'Male', '2016-12-25', '014768', 'S1070580H');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Garnette', 'Rapa', 'Kerstin', 'krapap@mashable.com', 'Female', '2016-09-27', '803671', 'S3057520D');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Letizia', 'Shackelton', 'Giffie', 'gshackeltonq@guardian.co.uk', 'Male', '2016-11-22', '583842', 'S2591042C');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Tadeo', 'Dufaur', 'Iorgo', 'idufaurr@people.com.cn', 'Male', '2016-08-28', '807254', 'S3980567P');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Reube', 'Wooldridge', 'Delmar', 'dwooldridges@goo.ne.jp', 'Female', '2016-03-20', '501947', 'S7119261S');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Gerty', 'Wallwork', 'Tallie', 'twallworkt@wordpress.com', 'Female', '2016-05-31', '003179', 'S4663528P');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Riley', 'Tibbles', 'Bernhard', 'btibblesu@sitemeter.com', 'Female', '2016-08-11', '781360', 'S8994018D');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Danielle', 'Coast', 'Darrel', 'dcoastv@alibaba.com', 'Female', '2016-05-31', '139088', 'S9251192I');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Wynn', 'Portlock', 'Gilly', 'gportlockw@nature.com', 'Female', '2016-05-25', '107652', 'S7394879J');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Reese', 'Genders', 'Charmaine', 'cgendersx@shutterfly.com', 'Female', '2016-09-05', '077820', 'S8862299F');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Davine', 'Pedersen', 'Malynda', 'mpederseny@mac.com', 'Female', '2016-02-04', '400588', 'S8944615C');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Arch', 'Hellcat', 'Minne', 'mhellcatz@joomla.org', 'Male', '2016-12-06', '448290', 'S4346483F');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Tedra', 'Lillford', 'Grantley', 'glillford10@sun.com', 'Female', '2016-02-10', '451818', 'S3891542Z');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Estel', 'Kopta', 'Phillida', 'pkopta11@facebook.com', 'Male', '2016-12-01', '225289', 'S0073620Z');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Glennis', 'Barnwille', 'Alberta', 'abarnwille12@apache.org', 'Female', '2016-04-04', '677475', 'S2647261L');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Harris', 'Whisson', 'Constantine', 'cwhisson13@webmd.com', 'Female', '2016-08-09', '681713', 'S8548901X');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Dannie', 'Levis', 'Robers', 'rlevis14@blogtalkradio.com', 'Female', '2016-08-12', '331825', 'S9766408G');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Nowell', 'Drysdall', 'Faunie', 'fdrysdall15@weebly.com', 'Male', '2016-02-24', '285668', 'S3011733L');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Stafford', 'Eayres', 'Blancha', 'beayres16@hexun.com', 'Male', '2016-02-16', '376464', 'S8140865D');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Marline', 'Speaks', 'Pearla', 'pspeaks17@patch.com', 'Male', '2016-11-25', '270101', 'S0264565B');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Georas', 'Dunk', 'Corliss', 'cdunk18@nsw.gov.au', 'Female', '2016-02-20', '225653', 'S0600316C');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Roberto', 'Flintoff', 'Leena', 'lflintoff19@nps.gov', 'Female', '2016-06-12', '147879', 'S0682468N');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Engelbert', 'Pragnall', 'Yoshiko', 'ypragnall1a@miibeian.gov.cn', 'Female', '2016-07-11', '682767', 'S3373704U');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Teddy', 'Jills', 'Roderick', 'rjills1b@sogou.com', 'Male', '2016-02-20', '149953', 'S5842843X');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Mathilde', 'Shears', 'Ahmad', 'ashears1c@squidoo.com', 'Male', '2016-11-04', '856127', 'S6672890U');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Marwin', 'Wrangle', 'Monica', 'mwrangle1d@pcworld.com', 'Male', '2016-06-13', '948143', 'S1059984Z');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Edvard', 'But', 'Reta', 'rbut1e@theatlantic.com', 'Male', '2016-11-05', '554821', 'S7182265W');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Barty', 'Christophle', 'Norean', 'nchristophle1f@blogger.com', 'Female', '2016-04-16', '461730', 'S0983813P');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Angeline', 'Possell', 'Dennie', 'dpossell1g@blog.com', 'Male', '2016-11-29', '777519', 'S8449937F');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Niccolo', 'Milham', 'Luciana', 'lmilham1h@odnoklassniki.ru', 'Male', '2016-09-17', '198748', 'S7023537O');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Giralda', 'Roast', 'Chlo', 'croast1i@uiuc.edu', 'Male', '2016-10-04', '990801', 'S0709111P');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Bunni', 'Yukhnin', 'Lowe', 'lyukhnin1j@acquirethisname.com', 'Male', '2016-08-15', '573738', 'S6763177J');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Dotti', 'Chudleigh', 'Zondra', 'zchudleigh1k@163.com', 'Female', '2016-04-30', '450165', 'S0049804G');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Miles', 'Ogdahl', 'Lesly', 'logdahl1l@usgs.gov', 'Male', '2016-12-30', '638949', 'S8307902A');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Akim', 'Clewett', 'Joletta', 'jclewett1m@mail.ru', 'Female', '2016-11-07', '662398', 'S9018406G');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Ring', 'Serchwell', 'Dorelia', 'dserchwell1n@tiny.cc', 'Male', '2016-02-14', '206281', 'S4366306B');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Natalina', 'Jossum', 'Klara', 'kjossum1o@who.int', 'Male', '2016-11-11', '934129', 'S0921188C');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Stanly', 'Rubinek', 'Shari', 'srubinek1p@baidu.com', 'Male', '2016-10-23', '752858', 'S5400223D');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Sammy', 'Grimsditch', 'Silvester', 'sgrimsditch1q@cafepress.com', 'Male', '2016-07-14', '247079', 'S7715487L');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Mitchael', 'Teggin', 'Lorrie', 'lteggin1r@aol.com', 'Male', '2016-09-01', '300551', 'S4475388S');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Lee', 'Bunhill', 'Frederico', 'fbunhill1s@feedburner.com', 'Male', '2016-06-02', '706508', 'S6666581D');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Melodie', 'Lavell', 'Wendall', 'wlavell1t@cnbc.com', 'Male', '2016-09-17', '832890', 'S0498094S');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Mattie', 'Morston', 'Red', 'rmorston1u@google.co.uk', 'Female', '2016-08-29', '778192', 'S8676410X');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Stoddard', 'Munn', 'Teodorico', 'tmunn1v@va.gov', 'Female', '2016-12-06', '127491', 'S8580901W');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Werner', 'Sarjeant', 'Lilli', 'lsarjeant1w@hao123.com', 'Female', '2016-03-28', '317177', 'S3154029J');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Parry', 'Fynan', 'Ewen', 'efynan1x@ted.com', 'Male', '2016-12-06', '083953', 'S7796598Z');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Lorena', 'Hatry', 'Lucy', 'lhatry1y@harvard.edu', 'Female', '2016-10-05', '919169', 'S5794014Y');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Elvyn', 'Elgie', 'Margaretha', 'melgie1z@wiley.com', 'Female', '2016-10-08', '385310', 'S8547931E');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Calypso', 'Wiggett', 'Adolf', 'awiggett20@about.me', 'Female', '2016-07-30', '019691', 'S4234034U');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Kizzie', 'Treacher', 'Mikel', 'mtreacher21@studiopress.com', 'Male', '2016-06-13', '216901', 'S6900050U');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Annmaria', 'Blind', 'Teresita', 'tblind22@free.fr', 'Male', '2016-02-18', '883318', 'S0653197D');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Forest', 'Belsham', 'Lelia', 'lbelsham23@dion.ne.jp', 'Female', '2016-11-28', '698072', 'S7788520V');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Melly', 'Cargen', 'Auguste', 'acargen24@icio.us', 'Female', '2016-08-24', '328765', 'S8637724C');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Iseabal', 'Marty', 'Darius', 'dmarty25@nsw.gov.au', 'Female', '2016-07-19', '372777', 'S9808171A');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Jeana', 'Horley', 'Ariadne', 'ahorley26@webs.com', 'Female', '2016-10-24', '352883', 'S4556645U');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Halsey', 'Attewell', 'Ellwood', 'eattewell27@hud.gov', 'Male', '2016-11-03', '614288', 'S4183177O');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Omero', 'Bunker', 'Camila', 'cbunker28@ycombinator.com', 'Female', '2016-04-10', '356096', 'S7620550J');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Davon', 'Whittek', 'Eamon', 'ewhittek29@sun.com', 'Female', '2016-09-02', '378134', 'S0724815A');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Sherye', 'Weine', 'Christabel', 'cweine2a@networksolutions.com', 'Male', '2016-07-02', '626288', 'S2640581F');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Cull', 'Jorissen', 'Florenza', 'fjorissen2b@phpbb.com', 'Male', '2016-06-24', '189730', 'S1292962K');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Goldi', 'Walisiak', 'Kathrine', 'kwalisiak2c@xrea.com', 'Female', '2016-11-19', '467892', 'S6493183C');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Alfie', 'Scanlon', 'Dennie', 'dscanlon2d@google.cn', 'Female', '2016-07-15', '206751', 'S3519142V');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Ringo', 'Lightbody', 'Erika', 'elightbody2e@deliciousdays.com', 'Male', '2016-06-24', '903219', 'S6330568L');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Curtis', 'Devlin', 'Felisha', 'fdevlin2f@ca.gov', 'Female', '2016-12-22', '846982', 'S3831498Q');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Rosanna', 'Ruberry', 'Willey', 'wruberry2g@nytimes.com', 'Male', '2016-11-18', '594923', 'S9438225L');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Angelique', 'Kuzma', 'Anita', 'akuzma2h@plala.or.jp', 'Female', '2016-06-27', '070173', 'S7535330L');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Letti', 'Matsell', 'Christoph', 'cmatsell2i@cnn.com', 'Female', '2016-06-09', '503088', 'S4575748C');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Vanda', 'Blanche', 'Bobette', 'bblanche2j@hc360.com', 'Male', '2016-07-06', '775445', 'S0124286D');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Paulita', 'Powley', 'Kristofer', 'kpowley2k@mail.ru', 'Female', '2016-08-21', '348672', 'S9755570J');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Danna', 'Hargraves', 'Rufe', 'rhargraves2l@arizona.edu', 'Female', '2016-10-18', '952448', 'S0441198E');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Celinka', 'Gobbett', 'Rozelle', 'rgobbett2m@patch.com', 'Female', '2016-02-14', '798561', 'S0160534C');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Ara', 'Aberhart', 'Lionello', 'laberhart2n@github.io', 'Male', '2016-03-18', '834604', 'S8781786E');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Rubie', 'Pruce', 'Glynis', 'gpruce2o@gravatar.com', 'Female', '2016-07-12', '243698', 'S7981621Z');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Leonie', 'Dagworthy', 'Maurizio', 'mdagworthy2p@princeton.edu', 'Male', '2016-07-06', '841637', 'S3648079K');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Elli', 'Lynn', 'Gottfried', 'glynn2q@accuweather.com', 'Female', '2016-06-18', '065801', 'S3525256V');
insert into potential_student (first_name, last_name, parent_name, parent_email, gender, date_of_birth, postal_code, student_ID) values ('Nap', 'Crosbie', 'Charlene', 'ccrosbie2r@acquirethisname.com', 'Female', '2016-05-06', '060038', 'S3310203K');


insert into primary_school (school_name, school_postal_code) values ('gigs primary school', '847309');
insert into primary_school (school_name, school_postal_code) values ('envoy primary school', '902393');
insert into primary_school (school_name, school_postal_code) values ('shutdown primary school', '522440');
insert into primary_school (school_name, school_postal_code) values ('could primary school', '433973');
insert into primary_school (school_name, school_postal_code) values ('bind primary school', '654320');
insert into primary_school (school_name, school_postal_code) values ('trite primary school', '618833');
insert into primary_school (school_name, school_postal_code) values ('mouse''s primary school', '222318');
insert into primary_school (school_name, school_postal_code) values ('prevails primary school', '979588');
insert into primary_school (school_name, school_postal_code) values ('palomino primary school', '964049');
insert into primary_school (school_name, school_postal_code) values ('surmise primary school', '171500');
insert into primary_school (school_name, school_postal_code) values ('itchiest primary school', '879246');
insert into primary_school (school_name, school_postal_code) values ('causal primary school', '449034');
insert into primary_school (school_name, school_postal_code) values ('haze primary school', '064580');
insert into primary_school (school_name, school_postal_code) values ('throne''s primary school', '738303');
insert into primary_school (school_name, school_postal_code) values ('wars primary school', '637203');
insert into primary_school (school_name, school_postal_code) values ('climb''s primary school', '321308');
insert into primary_school (school_name, school_postal_code) values ('symbolic primary school', '987187');
insert into primary_school (school_name, school_postal_code) values ('mask''s primary school', '664779');
insert into primary_school (school_name, school_postal_code) values ('bony primary school', '614825');
insert into primary_school (school_name, school_postal_code) values ('leper''s primary school', '271208');
insert into primary_school (school_name, school_postal_code) values ('sure primary school', '093670');
insert into primary_school (school_name, school_postal_code) values ('close primary school', '417500');
insert into primary_school (school_name, school_postal_code) values ('yarn primary school', '196329');
insert into primary_school (school_name, school_postal_code) values ('mains primary school', '092514');
insert into primary_school (school_name, school_postal_code) values ('cleft''s primary school', '149021');
insert into primary_school (school_name, school_postal_code) values ('tuck primary school', '120107');
insert into primary_school (school_name, school_postal_code) values ('lollypop primary school', '718264');
insert into primary_school (school_name, school_postal_code) values ('dead''s primary school', '557515');
insert into primary_school (school_name, school_postal_code) values ('cord primary school', '410013');
insert into primary_school (school_name, school_postal_code) values ('bird primary school', '266934');
insert into primary_school (school_name, school_postal_code) values ('bums primary school', '235742');
insert into primary_school (school_name, school_postal_code) values ('sale primary school', '945029');
insert into primary_school (school_name, school_postal_code) values ('moans primary school', '701425');
insert into primary_school (school_name, school_postal_code) values ('plagues primary school', '865032');
insert into primary_school (school_name, school_postal_code) values ('enjoyed primary school', '493456');
insert into primary_school (school_name, school_postal_code) values ('secrecy primary school', '405956');
insert into primary_school (school_name, school_postal_code) values ('fisher primary school', '532533');
insert into primary_school (school_name, school_postal_code) values ('whim''s primary school', '106617');
insert into primary_school (school_name, school_postal_code) values ('wastage primary school', '212788');
insert into primary_school (school_name, school_postal_code) values ('cuing primary school', '943767');
insert into primary_school (school_name, school_postal_code) values ('crops primary school', '736674');
insert into primary_school (school_name, school_postal_code) values ('dues primary school', '397347');
insert into primary_school (school_name, school_postal_code) values ('toxin primary school', '406061');
insert into primary_school (school_name, school_postal_code) values ('power primary school', '781183');
insert into primary_school (school_name, school_postal_code) values ('bowl primary school', '623720');
insert into primary_school (school_name, school_postal_code) values ('relics primary school', '369791');
insert into primary_school (school_name, school_postal_code) values ('lither primary school', '931403');
insert into primary_school (school_name, school_postal_code) values ('piles primary school', '905851');
insert into primary_school (school_name, school_postal_code) values ('decibels primary school', '828323');
insert into primary_school (school_name, school_postal_code) values ('needless primary school', '471430');
insert into primary_school (school_name, school_postal_code) values ('look primary school', '543103');
insert into primary_school (school_name, school_postal_code) values ('sucking primary school', '510733');
insert into primary_school (school_name, school_postal_code) values ('fattest primary school', '080199');
insert into primary_school (school_name, school_postal_code) values ('donuts primary school', '466959');
insert into primary_school (school_name, school_postal_code) values ('telling primary school', '848319');
insert into primary_school (school_name, school_postal_code) values ('zeta primary school', '633803');
insert into primary_school (school_name, school_postal_code) values ('writhing primary school', '104207');
insert into primary_school (school_name, school_postal_code) values ('hayed primary school', '441460');
insert into primary_school (school_name, school_postal_code) values ('bygone''s primary school', '849430');
insert into primary_school (school_name, school_postal_code) values ('tinkles primary school', '493799');
insert into primary_school (school_name, school_postal_code) values ('enter primary school', '751380');
insert into primary_school (school_name, school_postal_code) values ('café primary school', '570653');
insert into primary_school (school_name, school_postal_code) values ('sobbing primary school', '760209');
insert into primary_school (school_name, school_postal_code) values ('jittery primary school', '584507');
insert into primary_school (school_name, school_postal_code) values ('laziest primary school', '474564');
insert into primary_school (school_name, school_postal_code) values ('stain primary school', '690349');
insert into primary_school (school_name, school_postal_code) values ('simmers primary school', '955621');
insert into primary_school (school_name, school_postal_code) values ('overdid primary school', '055585');
insert into primary_school (school_name, school_postal_code) values ('weekly''s primary school', '461172');
insert into primary_school (school_name, school_postal_code) values ('basket primary school', '523943');
insert into primary_school (school_name, school_postal_code) values ('unawares primary school', '816727');
insert into primary_school (school_name, school_postal_code) values ('fallible primary school', '512165');
insert into primary_school (school_name, school_postal_code) values ('lurch''s primary school', '854098');
insert into primary_school (school_name, school_postal_code) values ('palms primary school', '717049');
insert into primary_school (school_name, school_postal_code) values ('wisest primary school', '425393');
insert into primary_school (school_name, school_postal_code) values ('droop primary school', '577922');
insert into primary_school (school_name, school_postal_code) values ('dismays primary school', '345964');
insert into primary_school (school_name, school_postal_code) values ('norm primary school', '132620');
insert into primary_school (school_name, school_postal_code) values ('pepped primary school', '840628');
insert into primary_school (school_name, school_postal_code) values ('shaving primary school', '370716');
insert into primary_school (school_name, school_postal_code) values ('sissiest primary school', '826401');
insert into primary_school (school_name, school_postal_code) values ('so''s primary school', '721272');
insert into primary_school (school_name, school_postal_code) values ('damage primary school', '892211');
insert into primary_school (school_name, school_postal_code) values ('duvet primary school', '314387');
insert into primary_school (school_name, school_postal_code) values ('tires primary school', '372318');
insert into primary_school (school_name, school_postal_code) values ('goodies primary school', '513997');
insert into primary_school (school_name, school_postal_code) values ('hornet''s primary school', '540967');
insert into primary_school (school_name, school_postal_code) values ('sods primary school', '515581');
insert into primary_school (school_name, school_postal_code) values ('guides primary school', '013187');
insert into primary_school (school_name, school_postal_code) values ('synapse primary school', '977704');
insert into primary_school (school_name, school_postal_code) values ('mishap primary school', '285425');
insert into primary_school (school_name, school_postal_code) values ('mutes primary school', '458257');
insert into primary_school (school_name, school_postal_code) values ('jells primary school', '066114');
insert into primary_school (school_name, school_postal_code) values ('idol primary school', '896944');
insert into primary_school (school_name, school_postal_code) values ('jumping primary school', '895544');
insert into primary_school (school_name, school_postal_code) values ('reap primary school', '127322');
insert into primary_school (school_name, school_postal_code) values ('nicest primary school', '064986');
insert into primary_school (school_name, school_postal_code) values ('fourths primary school', '604523');
insert into primary_school (school_name, school_postal_code) values ('brute''s primary school', '953476');
insert into primary_school (school_name, school_postal_code) values ('pulped primary school', '432537');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO application(student_ID, school_name) 
SELECT 
  student_ID, 
  school_name 
FROM 
  potential_student, 
  primary_school 
ORDER BY 
  random() 
LIMIT 
  1000;
