/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* Create one database including the information of the movie tickets booked 
online by customers for the monitoring period.
Assume that the monitoring period is from 24-Aug-2021 to 29-Aug-2021.

Table E1 stores the information about the customers, 
 - their first name, 
 - last name, 
 - email, 
 - and mobile number.
Table E2 stores the information about the movies, 
 - movie name,
 - movie genres, 
 - and movie date.
Table R provides the information about the potential bookings for the 
given period. It presents a many-to-many relationship to show that one 
customer can choose various movies on the differet dates,and one movie
can be shown to many customers on the different dates. 

customers (E1) table contains information of 
	first_name, 
	last_name, 
	email, 
	and mobile_no (primary key).
movies (E2) table contains information of 
	movie_name, movie_date (primary key)
	and movie_genres.
bookings (R) table contains information of 
	mobile_no (referenced column), 
	movie_name, movie_date (referenced column), 
	and the primary key is mobile_no from customers and 
	movie_name & movie_date from movies.                                */
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS customers (
	 first_name VARCHAR(50) NOT NULL,
	 last_name VARCHAR(50) NOT NULL,
	 email VARCHAR(50) NOT NULL,
	 mobile_no VARCHAR(12) PRIMARY KEY);
	
CREATE TABLE IF NOT EXISTS movies(
	 movie_name VARCHAR(150) NOT NULL,
	 movie_genres VARCHAR(150) NOT NULL,
	 movie_date DATE NOT NULL,
	 PRIMARY KEY (movie_name, movie_date));
  
 CREATE TABLE IF NOT EXISTS bookings(
	 mobile_no VARCHAR(12) REFERENCES customers (mobile_no)
		 ON UPDATE CASCADE
		 ON DELETE CASCADE
	 	 DEFERRABLE INITIALLY DEFERRED,
	 movie_name VARCHAR(150),
	 movie_date DATE,
	 PRIMARY KEY (mobile_no, movie_name, movie_date),
	 FOREIGN KEY (movie_name, movie_date) REFERENCES movies (movie_name, movie_date)
		 ON UPDATE CASCADE
		 ON DELETE CASCADE
 		 DEFERRABLE INITIALLY DEFERRED);
		 
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Populate the customers table */

insert into customers values ('Daphene', 'Summerbell', 'dsummerbell0@marriott.com', '896-350-4737');
insert into customers values ('Rozanne', 'MacGarvey', 'rmacgarvey1@yale.edu', '900-300-5152');
insert into customers values ('Joannes', 'Raulin', 'jraulin2@zimbio.com', '865-431-6667');
insert into customers values ('Lind', 'Worsall', 'lworsall3@vk.com', '318-889-9880');
insert into customers values ('Nevil', 'Jeduch', 'njeduch4@upenn.edu', '482-699-2034');
insert into customers values ('Conchita', 'Burborough', 'cburborough5@virginia.edu', '801-129-2005');
insert into customers values ('Kimble', 'Ogilvie', 'kogilvie6@dailymotion.com', '165-143-5402');
insert into customers values ('Licha', 'Mackilpatrick', 'lmackilpatrick7@amazon.com', '776-969-3167');
insert into customers values ('Atlante', 'Preshaw', 'apreshaw8@delicious.com', '772-412-6998');
insert into customers values ('Jeri', 'Wasbrough', 'jwasbrough9@home.pl', '456-357-8724');
insert into customers values ('Dee dee', 'Clemmey', 'dclemmeya@reuters.com', '960-611-6211');
insert into customers values ('Mata', 'Keig', 'mkeigb@statcounter.com', '382-733-3808');
insert into customers values ('Berta', 'Bourges', 'bbourgesc@imageshack.us', '274-577-9585');
insert into customers values ('Mariele', 'Bulluck', 'mbulluckd@godaddy.com', '139-296-1958');
insert into customers values ('Arron', 'Coggin', 'acoggine@naver.com', '335-479-9609');
insert into customers values ('Tessy', 'Suttle', 'tsuttlef@gravatar.com', '738-803-7208');
insert into customers values ('Prudy', 'MacAdie', 'pmacadieg@histats.com', '121-701-5911');
insert into customers values ('Deeyn', 'Simond', 'dsimondh@samsung.com', '261-963-1484');
insert into customers values ('Shanna', 'Gerish', 'sgerishi@i2i.jp', '165-876-8165');
insert into customers values ('Jasmina', 'Hentzeler', 'jhentzelerj@ucoz.com', '805-190-3250');
insert into customers values ('Livy', 'Linwood', 'llinwoodk@about.me', '595-772-1769');
insert into customers values ('Gilligan', 'Semrad', 'gsemradl@bravesites.com', '362-569-2733');
insert into customers values ('Nisse', 'Bowditch', 'nbowditchm@ning.com', '809-737-7242');
insert into customers values ('Katherine', 'Brou', 'kbroun@gravatar.com', '907-822-9782');
insert into customers values ('Oberon', 'Dyball', 'odyballo@nyu.edu', '113-563-5777');
insert into customers values ('Renaldo', 'Mossop', 'rmossopp@noaa.gov', '115-944-5356');
insert into customers values ('Pearle', 'Fried', 'pfriedq@yahoo.co.jp', '243-241-5665');
insert into customers values ('Sonnie', 'Scothorn', 'sscothornr@addthis.com', '921-466-7779');
insert into customers values ('Winny', 'Silber', 'wsilbers@time.com', '936-651-5622');
insert into customers values ('Ammamaria', 'Pollen', 'apollent@china.com.cn', '770-487-1912');
insert into customers values ('Fara', 'Varsey', 'fvarseyu@gmpg.org', '204-875-1295');
insert into customers values ('Morgun', 'Paulazzi', 'mpaulazziv@wiley.com', '590-731-4860');
insert into customers values ('Heindrick', 'Cockings', 'hcockingsw@wired.com', '749-940-1067');
insert into customers values ('Marga', 'Randerson', 'mrandersonx@squarespace.com', '391-188-9032');
insert into customers values ('Christy', 'O''Doghesty', 'codoghestyy@com.com', '381-109-0104');
insert into customers values ('Bibby', 'MacTerlagh', 'bmacterlaghz@tumblr.com', '629-695-2611');
insert into customers values ('Bev', 'Foukx', 'bfoukx10@google.es', '708-160-9116');
insert into customers values ('Pinchas', 'Greatrakes', 'pgreatrakes11@slashdot.org', '118-288-8119');
insert into customers values ('Grannie', 'Sheavills', 'gsheavills12@trellian.com', '299-938-3828');
insert into customers values ('Bale', 'Casassa', 'bcasassa13@redcross.org', '560-717-7656');
insert into customers values ('Katleen', 'Wernher', 'kwernher14@lycos.com', '634-387-6772');
insert into customers values ('Raimundo', 'Soames', 'rsoames15@vimeo.com', '768-860-8917');
insert into customers values ('Vickie', 'Folkerd', 'vfolkerd16@washingtonpost.com', '388-571-3097');
insert into customers values ('Jack', 'Gairdner', 'jgairdner17@webnode.com', '363-456-8173');
insert into customers values ('Ira', 'Davidovitch', 'idavidovitch18@nih.gov', '800-505-9941');
insert into customers values ('Carol', 'Bellard', 'cbellard19@163.com', '956-576-5120');
insert into customers values ('Jecho', 'Bleue', 'jbleue1a@vistaprint.com', '603-264-5370');
insert into customers values ('Cordie', 'Dowdell', 'cdowdell1b@springer.com', '560-724-6260');
insert into customers values ('Kathi', 'Antonchik', 'kantonchik1c@gov.uk', '139-187-9250');
insert into customers values ('Alleyn', 'Abercrombie', 'aabercrombie1d@phoca.cz', '668-288-0827');
insert into customers values ('Yettie', 'Yvens', 'yyvens1e@hostgator.com', '285-249-3201');
insert into customers values ('Matthias', 'Oldridge', 'moldridge1f@deliciousdays.com', '181-354-8724');
insert into customers values ('Drusie', 'Medforth', 'dmedforth1g@tiny.cc', '416-325-4650');
insert into customers values ('Salomo', 'Tiesman', 'stiesman1h@blogtalkradio.com', '564-778-2628');
insert into customers values ('Aurthur', 'Wiggett', 'awiggett1i@forbes.com', '528-842-5374');
insert into customers values ('Gigi', 'Cristofor', 'gcristofor1j@adobe.com', '409-415-0214');
insert into customers values ('Martyn', 'Pabelik', 'mpabelik1k@digg.com', '752-145-0241');
insert into customers values ('Hobie', 'Horney', 'hhorney1l@slate.com', '752-277-9543');
insert into customers values ('Bryan', 'Rudram', 'brudram1m@instagram.com', '413-541-4791');
insert into customers values ('Colline', 'Caswell', 'ccaswell1n@icq.com', '819-345-6880');
insert into customers values ('Ebony', 'Tilmouth', 'etilmouth1o@google.com.br', '728-365-0391');
insert into customers values ('Darrick', 'Theuss', 'dtheuss1p@cargocollective.com', '404-810-3898');
insert into customers values ('Tansy', 'Neesham', 'tneesham1q@reference.com', '828-316-0084');
insert into customers values ('Lonny', 'Ordidge', 'lordidge1r@vk.com', '279-144-8145');
insert into customers values ('Fredra', 'Boxell', 'fboxell1s@si.edu', '160-508-0105');
insert into customers values ('Nat', 'Sessions', 'nsessions1t@psu.edu', '796-604-5484');
insert into customers values ('Micaela', 'Chatelot', 'mchatelot1u@goo.gl', '638-939-2108');
insert into customers values ('Jeramey', 'Castagneri', 'jcastagneri1v@answers.com', '446-846-5550');
insert into customers values ('Nadia', 'Tooth', 'ntooth1w@last.fm', '908-688-8269');
insert into customers values ('Gloriane', 'Capponer', 'gcapponer1x@time.com', '158-709-0553');
insert into customers values ('Kayley', 'Marling', 'kmarling1y@mediafire.com', '928-285-1280');
insert into customers values ('Keane', 'Aronowicz', 'karonowicz1z@ebay.co.uk', '713-999-7213');
insert into customers values ('Ibby', 'Ellingham', 'iellingham20@moonfruit.com', '296-513-7521');
insert into customers values ('Sapphira', 'Boothe', 'sboothe21@topsy.com', '398-643-1449');
insert into customers values ('Rog', 'D''Antoni', 'rdantoni22@wufoo.com', '114-979-8357');
insert into customers values ('Corbet', 'Hatherley', 'chatherley23@lycos.com', '296-873-1820');
insert into customers values ('Pat', 'Cuttles', 'pcuttles24@dell.com', '203-350-7206');
insert into customers values ('Chaim', 'Timblett', 'ctimblett25@thetimes.co.uk', '480-931-5884');
insert into customers values ('Salim', 'Scarsbrick', 'sscarsbrick26@facebook.com', '302-692-8832');
insert into customers values ('Radcliffe', 'Willavize', 'rwillavize27@netvibes.com', '526-686-6821');
insert into customers values ('Rossy', 'Frizzell', 'rfrizzell28@elegantthemes.com', '279-542-7288');
insert into customers values ('Lexine', 'Patton', 'lpatton29@eventbrite.com', '633-893-1498');
insert into customers values ('Iseabal', 'Reihill', 'ireihill2a@icq.com', '658-836-1174');
insert into customers values ('Mike', 'Preedy', 'mpreedy2b@tamu.edu', '190-841-0248');
insert into customers values ('Alonso', 'Kuschek', 'akuschek2c@shinystat.com', '774-364-9455');
insert into customers values ('Doralia', 'Sappson', 'dsappson2d@chron.com', '392-486-8558');
insert into customers values ('Eb', 'Rosenfrucht', 'erosenfrucht2e@eepurl.com', '102-485-1952');
insert into customers values ('Tallou', 'Hallgath', 'thallgath2f@nature.com', '995-734-1716');
insert into customers values ('Daron', 'Flasby', 'dflasby2g@berkeley.edu', '153-931-5407');
insert into customers values ('Wrennie', 'Scurrer', 'wscurrer2h@gizmodo.com', '885-187-5072');
insert into customers values ('Lorenzo', 'Saice', 'lsaice2i@yelp.com', '987-736-7003');
insert into customers values ('Germain', 'Fallawe', 'gfallawe2j@studiopress.com', '825-712-7344');
insert into customers values ('Stace', 'Cotton', 'scotton2k@spotify.com', '888-275-3686');
insert into customers values ('Law', 'Crockett', 'lcrockett2l@vk.com', '417-882-4053');
insert into customers values ('Etienne', 'Gonnard', 'egonnard2m@kickstarter.com', '598-537-1291');
insert into customers values ('Ashbey', 'Simonnet', 'asimonnet2n@photobucket.com', '473-566-7052');
insert into customers values ('Cathrine', 'Gladbeck', 'cgladbeck2o@booking.com', '133-344-1784');
insert into customers values ('Caril', 'Buttle', 'cbuttle2p@pen.io', '592-890-7377');
insert into customers values ('Tracey', 'Arlt', 'tarlt2q@pbs.org', '454-595-6996');
insert into customers values ('Addison', 'Jouen', 'ajouen2r@sina.com.cn', '334-749-1063');

/* Populate the movies table */

insert into movies values ('Snarveien (Detour)', 'Horror|Thriller', '2021-08-13');
insert into movies values ('Beauty and the Bastard (Tyttö sinä olet tähti)', 'Drama|Musical|Romance', '2020-08-24');
insert into movies values ('Life On A String (Bian chang Bian Zou)', 'Adventure|Drama|Fantasy|Musical', '2021-02-27');
insert into movies values ('20,000 Leagues Under the Sea', 'Action|Adventure|Sci-Fi', '2021-07-18');
insert into movies values ('The Studio Murder Mystery', 'Mystery', '2021-08-11');
insert into movies values ('Giant Gila Monster, The', 'Horror|Sci-Fi', '2021-06-04');
insert into movies values ('Mike''s New Car', 'Animation|Comedy', '2021-03-12');
insert into movies values ('Street Trash', 'Comedy|Horror', '2021-06-06');
insert into movies values ('Manufacturing Reality: Slavoj Zizek and the Reality of the Virtual (Slavoj Zizek: The Reality of the Virtual)', 'Documentary', '2021-04-06');
insert into movies values ('Pink Panther Strikes Again, The', 'Comedy|Crime', '2021-08-08');
insert into movies values ('Jim Thorpe -- All-American', 'Drama', '2021-05-21');
insert into movies values ('Same Time, Next Year', 'Comedy|Drama|Romance', '2020-09-15');
insert into movies values ('Free Willy', 'Adventure|Children|Drama', '2020-09-02');
insert into movies values ('Hours, The', 'Drama|Romance', '2020-09-14');
insert into movies values ('Fantastic Night, The (Nuit fantastique, La)', 'Romance', '2021-02-08');
insert into movies values ('I Wake Up Screaming', 'Crime|Film-Noir|Mystery|Romance|Thriller', '2020-12-24');
insert into movies values ('Comic-Con Episode IV: A Fan''s Hope', 'Documentary', '2021-01-25');
insert into movies values ('North and South, Book II', 'Drama|Romance|War', '2021-06-15');
insert into movies values ('The Remaining', 'Horror|Thriller', '2021-06-21');
insert into movies values ('Murder by Numbers', 'Crime|Thriller', '2020-10-24');
insert into movies values ('Triumph of Love, The', 'Comedy', '2020-09-22');
insert into movies values ('How to Meet Girls from a Distance', 'Comedy', '2021-04-14');
insert into movies values ('10 to Midnight', 'Action|Adventure|Thriller', '2021-07-08');
insert into movies values ('Matriarch, The (Lieksa!)', 'Comedy|Drama|Romance', '2021-03-24');
insert into movies values ('Crime and Punishment', 'Drama', '2020-10-17');
insert into movies values ('For the Love of a Dog', 'Children', '2021-03-28');
insert into movies values ('Evangelion: 1.0 You Are (Not) Alone (Evangerion shin gekijôban: Jo)', 'Action|Animation|Sci-Fi', '2021-02-13');
insert into movies values ('Fly Away', 'Drama', '2020-12-14');
insert into movies values ('Summer House', 'Drama', '2021-08-18');
insert into movies values ('House of Angels (Änglagård)', 'Comedy|Drama', '2021-04-09');
insert into movies values ('Melbourne', 'Drama', '2021-03-21');
insert into movies values ('Stromboli', 'Drama', '2021-07-20');
insert into movies values ('On a Clear Day', 'Drama', '2020-11-15');
insert into movies values ('Trials of Henry Kissinger, The', 'Documentary', '2020-11-07');
insert into movies values ('Destiny (a.k.a. Between Two Worlds) (Der müde Tod)', 'Fantasy', '2021-01-21');
insert into movies values ('It Rains in My Village (Bice skoro propast sveta)', 'Drama', '2020-09-18');
insert into movies values ('Love Exposure (Ai No Mukidashi)', 'Action|Comedy|Drama|Romance', '2020-09-20');
insert into movies values ('Couch Trip, The', 'Comedy', '2021-08-12');
insert into movies values ('Three Ages', 'Comedy', '2021-05-06');
insert into movies values ('Signs', 'Romance', '2020-09-09');
insert into movies values ('My Piece of the Pie (Ma part du gâteau)', 'Comedy|Drama', '2020-09-17');
insert into movies values ('When the Road Bends: Tales of a Gypsy Caravan', 'Documentary', '2020-09-16');
insert into movies values ('Year of the Yao, The', 'Documentary', '2020-09-05');
insert into movies values ('Biloxi Blues', 'Comedy|Drama', '2021-08-12');
insert into movies values ('April Story', 'Romance', '2021-04-10');
insert into movies values ('Main Prem Ki Diwani Hoon', 'Comedy|Drama|Romance', '2021-04-18');
insert into movies values ('What Goes Up', 'Drama', '2021-08-09');
insert into movies values ('Rock of Ages', 'Comedy|Drama|Musical|IMAX', '2021-02-08');
insert into movies values ('Mr. Hobbs Takes a Vacation', 'Comedy', '2021-07-11');
insert into movies values ('Contact', 'Drama|Sci-Fi', '2021-03-25');
insert into movies values ('Die, Mommie, Die', 'Comedy', '2021-05-07');
insert into movies values ('Nine', 'Drama|Musical|Romance', '2021-07-31');
insert into movies values ('Solan og Ludvig: Jul i Flåklypa', 'Animation|Children', '2021-02-20');
insert into movies values ('Soldier of Orange (a.k.a. Survival Run) (Soldaat van Oranje)', 'Drama|Thriller|War', '2020-11-21');
insert into movies values ('Lon Chaney: A Thousand Faces', 'Documentary', '2021-05-21');
insert into movies values ('The Mask You Live In', 'Documentary', '2021-05-08');
insert into movies values ('Big Doll House, The', 'Action', '2020-12-18');
insert into movies values ('Sentinel, The', 'Crime|Drama|Thriller', '2021-06-26');
insert into movies values ('Larry Crowne', 'Comedy|Drama|Romance', '2021-03-15');
insert into movies values ('It Came from Beneath the Sea', 'Sci-Fi', '2020-09-03');
insert into movies values ('Chicago 10', 'Animation|Documentary', '2021-03-07');
insert into movies values ('Girl, Interrupted', 'Drama', '2021-06-11');
insert into movies values ('Whose Life Is It Anyway?', 'Drama', '2021-06-13');
insert into movies values ('Last of the High Kings, The (a.k.a. Summer Fling)', 'Comedy|Drama', '2021-02-27');
insert into movies values ('Campus Man', 'Comedy', '2021-06-29');
insert into movies values ('Chato''s Land', 'Western', '2020-10-20');
insert into movies values ('Orpheus (Orphée)', 'Drama|Fantasy|Romance', '2020-08-26');
insert into movies values ('Regeneration', 'Drama|War', '2021-08-08');
insert into movies values ('Turin Horse, The (A Torinói ló)', 'Drama', '2021-07-23');
insert into movies values ('Experience Preferred... But Not Essential', 'Drama', '2021-06-20');
insert into movies values ('Fat, Sick & Nearly Dead', 'Documentary', '2021-05-18');
insert into movies values ('Dancing Outlaw II: Jesco Goes to Hollywood', 'Documentary', '2021-07-30');
insert into movies values ('Metropolis', 'Animation|Sci-Fi', '2020-09-08');
insert into movies values ('Connie and Carla', 'Comedy', '2021-05-08');
insert into movies values ('Waxworks (Das Wachsfigurenkabinett)', 'Comedy|Drama|Romance|Thriller', '2021-05-03');
insert into movies values ('Redes (Fishermen''s Nets) (Wave, The)', 'Drama', '2021-02-19');
insert into movies values ('Carbon Nation', 'Documentary', '2020-11-01');
insert into movies values ('Richard Pryor Here and Now', 'Comedy|Documentary', '2020-08-30');
insert into movies values ('While You Were Sleeping', 'Comedy|Romance', '2020-10-15');
insert into movies values ('Substitute, The (Vikaren)', 'Comedy|Sci-Fi|Thriller', '2020-12-06');
insert into movies values ('Across the Universe', 'Drama|Fantasy|Musical|Romance', '2021-05-14');
insert into movies values ('Adventures of Ichabod and Mr. Toad, The', 'Animation|Children', '2021-06-03');
insert into movies values ('Absentia', 'Horror', '2021-04-11');
insert into movies values ('Teahouse of the August Moon, The', 'Comedy', '2020-09-25');
insert into movies values ('Moonshot', 'Drama', '2021-01-18');
insert into movies values ('Jellyfish (Meduzot)', 'Drama', '2020-11-26');
insert into movies values ('Greenwich Village: Music That Defined a Generation ', 'Documentary', '2020-09-06');
insert into movies values ('At First Sight (Entre Nous) (Coup de foudre)', 'Drama', '2020-10-20');
insert into movies values ('Hanna', 'Action|Adventure|Mystery|Thriller', '2021-05-27');
insert into movies values ('Strapped', 'Action|Drama', '2021-04-20');
insert into movies values ('Crossing the Bridge', 'Comedy|Drama', '2021-01-04');
insert into movies values ('Testament of Dr. Mabuse, The (Das Testament des Dr. Mabuse)', 'Crime|Horror|Mystery|Thriller', '2021-03-28');
insert into movies values ('Madagascar: Escape 2 Africa', 'Action|Adventure|Animation|Children|Comedy|IMAX', '2020-09-19');
insert into movies values ('Women, The', 'Comedy', '2021-04-21');
insert into movies values ('Bachelor Apartment', 'Comedy|Drama|Romance', '2021-02-05');
insert into movies values ('Carlito''s Way: Rise to Power (Carlito''s Way 2: Rise to Power)', 'Action|Crime|Drama|Thriller', '2021-05-24');
insert into movies values ('Breathless (À bout de souffle)', 'Crime|Drama|Romance', '2020-10-28');
insert into movies values ('Summer School', 'Horror', '2021-07-18');
insert into movies values ('Trailer Park Boys: Don''t Legalize It', 'Comedy|Crime|Drama', '2021-04-21');
insert into movies values ('I, Robot', 'Action|Adventure|Sci-Fi|Thriller', '2021-06-14');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO bookings 
	(SELECT mobile_no, movie_name, movie_date FROM customers,movies) 
		ORDER BY RANDOM() LIMIT 1000;

SELECT * FROM bookings;

