/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*I use these three table to describe the transactions of bitcoins. 
The first table contains the information about sellers while the second table contains the information about buyers.
The third table represents the transation of sellers and buyers.
Both of the first and the second table have four columns: Name, Bitcoin address, Email, Country. The bitcoin address
indicates the source or destination of payments. A person can have several bitcoin addresses while a bitcoin address can only belong to one person.
The third table records the buyers, seller, transaction date and transaction price.


*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS buyers(
	buyer_name VARCHAR(64) NOT NULL,
	bitcoin_address VARCHAR(64) PRIMARY KEY,
	email VARCHAR(64) UNIQUE NOT NULL,
	country VARCHAR(64) NOT NULL
);

CREATE TABLE IF NOT EXISTS sellers(
	seller_name VARCHAR(64) NOT NULL,
	bitcoin_address VARCHAR(64) PRIMARY KEY,
	email VARCHAR(64) UNIQUE NOT NULL,
	country VARCHAR(64) NOT NULL
);

CREATE TABLE IF NOT EXISTS transactions(
	buyer_address VARCHAR(64) REFERENCES buyers(bitcoin_address)
	ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
	seller_address VARCHAR(64) REFERENCES sellers(bitcoin_address)
	ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
	transaction_date DATE NOT NULL,
	transaction_price NUMERIC NOT NULL,
	PRIMARY KEY (buyer_address, seller_address, transaction_date)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into buyers (buyer_name, bitcoin_address, email, country) values ('smarchington0', '19HoJ9Ls1wbHFFYML5XWtrN9MKFXXdd61s', 'rbrecknock0@epa.gov', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('kworrall1', '1LVk3ASyxHZW1KAxP1wfxNQi8u6vg2rNyg', 'afoottit1@ibm.com', 'Honduras');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('lpeller2', '18xHQ8CF3SV7AAFuL8XXs3VmTbmqTEBuzg', 'lmerrett2@gravatar.com', 'Philippines');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('aropcke3', '18oA3LADBUPsBLZzTvhxRbdx926SznhdTC', 'slouth3@cbc.ca', 'France');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('mridhole4', '12whmTyhcHr4VBWJ5McpkYRyaojuwsr2eX', 'eklausewitz4@businesswire.com', 'Indonesia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('sviggers5', '1MaQfJze3m7PP6NwRZ9UWdvBQsEu6ERiZh', 'kbatterton5@sbwire.com', 'New Zealand');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('rhaselwood6', '1LBEKQJgeL4DyF5mV2Vmm8oVpTY5V9RyPZ', 'hgoodlip6@ocn.ne.jp', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('ggalliver7', '169idhghC4suSxFjZr2sSJ6E113j5FE26D', 'egodbolt7@hao123.com', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('ycraney8', '15jNa5bFcrmJpQC5KwKDGpkijpvHEg6BYk', 'gsapsed8@simplemachines.org', 'Zimbabwe');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('jferryman9', '14Te9C8kC88zNsBYZ5Y67NaFuGVk6ZMjts', 'rbunney9@usatoday.com', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('dfridayea', '13fyFhmXusCMBVBnDwGACRTuGL6pvRDZHQ', 'apresdiea@t.co', 'Ghana');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('fmacdunlevyb', '13gz2AdQDGKMSh7XLdPvKGnMfUbw3jprbm', 'pjoppichb@hhs.gov', 'Guatemala');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('tramlotc', '13F1j4sUSzqutRFcLiZhLB6mDvRtpz2K32', 'hmaccaghanc@creativecommons.org', 'Czech Republic');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('ktollertond', '1MutNmygNMqPVNebfWgFMMmL5ULdkKpcV5', 'swathelld@google.com.au', 'Canada');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('tharkine', '12TG9bHnhnfhc4f1piiDXeWjVeShCjYHdW', 'rsaffine@china.com.cn', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('fkassmanf', '1NPTLQuvKdqECiGK39RYMwLuNCsgPREDFe', 'sdeandisief@goo.gl', 'Brazil');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('msaundersong', '1edLoVQg9tRDKMMMqNqR6Vo7RjnW8gPDg', 'tpuddiferg@dell.com', 'Portugal');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('rpolsinh', '1AG2vZDfa7Vwzqy2pExKoMKj1tMP5fmzeB', 'wfilippovh@boston.com', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('rjennemanni', '1NftdB9U3XRBVfA2nivPV3i8TEcAEuPvw', 'dsalteri@eventbrite.com', 'Indonesia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('pchappelowj', '19CkFwCfZFViwggFXBMQgSxqj4Gswy6f7D', 'bmarousekj@networksolutions.com', 'Uzbekistan');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('fskilbeckk', '1CMxcG1GBY4FapitNGiCfpUjXJNuYK95St', 'awastallk@wp.com', 'Republic of the Congo');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('rdaicel', '18wefTFuA1EBN52CFkqRKVxzhabauPi7fA', 'flegallol@cnn.com', 'Argentina');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('pdignallm', '14tUgyMWNami4xEFr11hTXK9ien6ndsx4f', 'mdomenichinim@tamu.edu', 'Mongolia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('dcressyn', '1HFdn8XVCHzi3hD4Xx6XToGwpP88XHrBB5', 'arembaudn@zdnet.com', 'Netherlands');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('jdevennieo', '1FYo54Y8fPaQo1kNKMvLAs9Cez9ve68NfW', 'gkurtono@infoseek.co.jp', 'Japan');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('tnevettp', '1JYVrXN58EKM3VJScTGDiTtXCVbtDSiRDM', 'afairchildp@vimeo.com', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('ftebbq', '1K5v78ogdUFuBtfAyXicjPewxRDvDMeszG', 'sbenzieq@fc2.com', 'Lithuania');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('shabbler', '1Na32XNGEV1KDoFHFSpjBrVYSDhHCtkapn', 'uhealingsr@jiathis.com', 'Bangladesh');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('mtrunbys', '13rescux3bQ1g75c6M4ovj1thCBrEnHLwX', 'rpetrashovs@ehow.com', 'Indonesia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('ngariet', '1FYmG81FLTFwG8fehcatbp4EwSPhEbtDZ', 'egothardt@pagesperso-orange.fr', 'Indonesia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('ksaipyu', '13aWQBMn3rmVovDx7TrVqu97dVMoGWMwiR', 'sgarratu@china.com.cn', 'Ukraine');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('bjaffrayv', '1LwWS4PnE7iyXy66RdUtYnyyYKrfgKi4vB', 'rdjordjevicv@phoca.cz', 'Pakistan');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('rspellacyw', '13KTV1XRbJCJua3UZ2Nh188nnLZWfXbYK6', 'ajustunw@addtoany.com', 'Russia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('cgraingerx', '1MH2RxDwXUPvxD9Fj78DJqpFGoGccCgzkh', 'erambadtx@cam.ac.uk', 'Argentina');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('efrendy', '1TJvsgqb14N5aRs6BbhphtCmzBccHc6XT', 'jgreenally@wordpress.com', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('gbrandz', '1HTHpSFFT6LsWLLq7xopfnNP9t1Zo129fM', 'rtyddz@com.com', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('tjendrys10', '19kXyWvgedMHkTkCjrvF6VRLY8J1uD2adC', 'mcanfer10@wisc.edu', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('mtapply11', '15uQfxSScNbA2AGebMfwkHSEtTeDY8812W', 'adimmne11@dailymail.co.uk', 'Bosnia and Herzegovina');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('bhaslen12', '1db7J14kSXg2nSZeXGzDZ1PgEyqQDF5iL', 'dwayte12@state.gov', 'Czech Republic');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('ggotfrey13', '19GELz6ugFkdLcUyuFazXpUyQHYfjXxgof', 'lcayet13@illinois.edu', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('ifillingham14', '1M8wBkTD9TvaR2D8fNWCeizNBgoxyz7N4e', 'odebrett14@baidu.com', 'Tanzania');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('dglasscott15', '1Nxrxp3byy7hEsNn7HhFfqLYwT1oxQekpj', 'bcastellone15@soundcloud.com', 'South Africa');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('wpapis16', '1DhRjcbSikVyzGAhv1qHuSZQQyqvyqVugH', 'charrill16@sitemeter.com', 'Bosnia and Herzegovina');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('sshearn17', '13JspjygpBhufZdicsh52SPvDzNcuBbdsm', 'sbineham17@odnoklassniki.ru', 'Marshall Islands');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('wposvner18', '16rJXL9S7S22DqpDzeLiDwFyYNB9RKzdQ5', 'rvanetti18@tinyurl.com', 'Russia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('pdunderdale19', '1JozbjuDtVzgJN6tjmNYFscK4rPckzwWv6', 'deite19@forbes.com', 'Indonesia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('sfayerman1a', '173eopo6K8f28E19HPXgqAmTVqtKkUxu8w', 'mdumphrey1a@ifeng.com', 'Indonesia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('edagostini1b', '13YVn9quuNrZNG5NcQAXUyYy57B26R383j', 'bveld1b@admin.ch', 'Indonesia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('bstpierre1c', '1GqaDBwNd1g5EgmZQoT8Aw9kczexGYEK8n', 'dcrann1c@oaic.gov.au', 'Bulgaria');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('bchurchouse1d', '1H7dbCg4JC1ztC4yqDsH1hh3rg7KKiaubx', 'tgherardini1d@google.it', 'Serbia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('awrintmore1e', '1B419smo6Yyy9LDQG96hPrYWnkWzjziYEU', 'psterke1e@sfgate.com', 'South Africa');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('dlloyds1f', '1JWMdEucGi9DdfkKmxgqLHYpeeduPwkp93', 'agofton1f@cargocollective.com', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('jslimmon1g', '1AvjaSkBLkw4wGu9XQM1G34vqu2y6sJM14', 'hpomfrett1g@elegantthemes.com', 'Democratic Republic of the Congo');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('dfollan1h', '1GWBwbp2u3KUgzWxUHUAc8es838tibTRG6', 'rlokier1h@pbs.org', 'Afghanistan');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('jdanat1i', '1EbKfqXMidm8yLUqrLZPGZBcnvAT59jFMc', 'rrhoades1i@apache.org', 'Indonesia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('bwooffitt1j', '1Cn5p9wtJ8zx7JyTMJLnbtrWZZMh8fQfNz', 'htourner1j@slate.com', 'United Kingdom');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('jmoiser1k', '16y3VcJGaM5q5fNy32PhuMwD1XJSG9xh9V', 'fnoades1k@nifty.com', 'Portugal');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('emenlove1l', '14CcE11Jy1ge8ytUKjQQwyf6Rw2pTJibfU', 'ccopozio1l@bloomberg.com', 'Poland');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('khaines1m', '1wLtWzYp7RiK4a2ciLAdZS6REST9u99Af', 'ftimewell1m@ed.gov', 'Dominican Republic');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('hfoxcroft1n', '1KCx48MGWumR7RtLgY3U55zvqk82wgGhb5', 'kwanka1n@psu.edu', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('gtinwell1o', '1My9NQfnAmTaLf2xBAodzm2arjVDRYZrKB', 'ahedman1o@webmd.com', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('vlempel1p', '1LGxtxhPENrqXSQVvxfZbp5STwCwWu8AnD', 'akeymar1p@liveinternet.ru', 'Poland');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('ltrobe1q', '1EmxuLqzCneEmEmbgzT6ER9LQ835pb4pdV', 'imedgewick1q@printfriendly.com', 'Mexico');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('llarge1r', '1ASGX9xmMjHFaSz2LsGKaCeyLtSAqm9nDW', 'tgritland1r@aboutads.info', 'Brazil');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('kbreston1s', '177Shvw91cGmpiWmmVgYNhWNhkxwg8A84z', 'rkevis1s@dell.com', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('ucuchey1t', '1PDtSp8JY2BNwfFDWPv2jiwHBsJjfm8VkN', 'kbagehot1t@sciencedaily.com', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('bkinnen1u', '18wp9YjdiEaEYCxvr4Qs9zwNmreeuqx7CV', 'cbagwell1u@goo.gl', 'Indonesia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('tgrubey1v', '18Zihc2RFRwESHgwDN5hCtULaj9cbZggkJ', 'nmilroy1v@google.it', 'Russia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('hscholler1w', '1KeT4pj2i7g9opokydyVyBGi8Ewbr2tiVb', 'rroe1w@ning.com', 'Nigeria');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('thatrick1x', '1PigPsUvxcZR1BuoyAjic5fgqd2JhhermM', 'ahailey1x@webeden.co.uk', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('jgrenfell1y', '1LJ3WcnLwW51Sgq6JNcjtmgfts6HtCMF27', 'cfollan1y@imageshack.us', 'Brazil');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('cbythway1z', '1F2TPBqxFAABTeDL34fySXfsVCbAWFRc4k', 'cmurrey1z@pcworld.com', 'United States');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('esingleton20', '1GVWoUXjnAYnXDMYNjLyfuW9udHC4q4z6z', 'gfrounks20@example.com', 'Jordan');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('nnelius21', '18MsfSwF1aQx4YQGu89JmGNyLUt1FR4GAZ', 'oboniface21@moonfruit.com', 'Canada');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('mrowen22', '1KhXRWBmvJvH7QVeKJ3fEKGmBJAxf3QMxj', 'scourtier22@ox.ac.uk', 'Thailand');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('jgabala23', '1NJvQRBBimSmKhPQAAoABFYhA9J8TMFpR1', 'vadrianello23@auda.org.au', 'Philippines');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('sdowse24', '1KvLQMT4WQsQ5tE2FMf4kVNZ1G3t5AvqWA', 'ptatterton24@ftc.gov', 'Russia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('wbisco25', '1L9YL3izWrbJWpxczq6f3scZCsEeAJxzxe', 'kkellick25@a8.net', 'Nicaragua');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('bdickman26', '19c15LWgBMdPiAxFnJ8Wz9AYYNVxWHpAG7', 'ksargerson26@1und1.de', 'Argentina');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('mthorington27', '1DBnN57sm39eGjXbmsnvy9BvKpyUbZZq3s', 'hromero27@blogs.com', 'Saudi Arabia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('edezamora28', '1NHE2nmKrcwjJPLej1AokZk79NCrurraPC', 'wlissandrini28@rambler.ru', 'Malaysia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('movitz29', '1D2CBdoZ9SzdxiXNZLBU8j1bLbwVZSZ6kX', 'emerchant29@wikimedia.org', 'Vietnam');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('bsharkey2a', '1JXEEsfz19dRRdePpakDKEaWj1k2cq6Tp4', 'dmurkitt2a@blogspot.com', 'Brazil');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('asarfat2b', '18E9JYAWFE1cBMrqcKoytFiy8HqBbUmkEp', 'ckearle2b@nytimes.com', 'Philippines');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('mjowling2c', '1Poyb3jzFdmugZXba9esJz8CfkZWX4HwBd', 'tdruel2c@latimes.com', 'Russia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('hpetti2d', '1JkHs3aG5inDrwZXyn7BDhJ2mQsrTnkdva', 'hvineall2d@free.fr', 'Philippines');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('dkubanek2e', '14gJGgr7YEtYYZDzbzuGFJeu3LEmmNRoFr', 'rpashby2e@washingtonpost.com', 'Portugal');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('amackeller2f', '1MZgaubzRC9qB6ZizQoP8kUvApDWBFeBuG', 'jtestin2f@comcast.net', 'Poland');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('mcolkett2g', '12DtiKXMHEff3rFeK3J1y78L52zM6X6TGb', 'dforsdike2g@tinyurl.com', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('jhoy2h', '1CRASrKwEnD6bvMBau63LExs7CMaKjVqEv', 'hforre2h@last.fm', 'Indonesia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('gsherston2i', '1MNtAB5ksYeEp8wHASxbG2hbk7KR6SpUiB', 'odabbes2i@marriott.com', 'Indonesia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('lwordsley2j', '1F1dg8Tqk3oSkBKrHaiPvW9kKYVjH7VYP4', 'amcilwrath2j@apple.com', 'Kyrgyzstan');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('dcharker2k', '1Gro6GXDZEfgch32prqEP1SYZTwafMhtQ', 'dlightbown2k@theatlantic.com', 'Indonesia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('dadin2l', '18mtZQyJx217eHJHkCK7dY65VJcQqMfwnL', 'kmatzl2l@engadget.com', 'Philippines');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('crannie2m', '1FWFHSf1TZJtV11qZEBkb7HdbGhonSNt1z', 'akehir2m@answers.com', 'Indonesia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('cwell2n', '191UFpdbv9rMKVy4UL2errBYcqV8YYPRpC', 'kskellington2n@odnoklassniki.ru', 'Cambodia');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('vmallinson2o', '1DNfHqqDHGwi1LHsCQYkmwaPD6fsqdPDYN', 'yreeders2o@microsoft.com', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('nselborne2p', '17WtqKHA84SEVT6oFuiU4HRJXkUvY5SUTT', 'fschlagh2p@upenn.edu', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('kkrolak2q', '12A2WCGim9A5gsUEWXCjRTVQKodoxP1vpp', 'eattwill2q@msn.com', 'China');
insert into buyers (buyer_name, bitcoin_address, email, country) values ('acarlsson2r', '1AgQ8QJajfYfM1CX9bPoYX7EhR2G85WuPh', 'gucceli2r@xinhuanet.com', 'Canada');

insert into sellers (seller_name, bitcoin_address, email, country) values ('abarbara0', '12ANBtENvTq3ixzZC6Z4ZfzxdrCVrHTrbM', 'thirtzmann0@google.com.au', 'Philippines');
insert into sellers (seller_name, bitcoin_address, email, country) values ('mrafferty1', '1KK2tuYzPHpdXqKz2hZPqqmACmugN1jyxG', 'abarrick1@ox.ac.uk', 'Indonesia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('gsawart2', '18NG22vCVAHsihLbFoxVca5CXKvvNzQk3S', 'cscargle2@exblog.jp', 'Brazil');
insert into sellers (seller_name, bitcoin_address, email, country) values ('dkenson3', '1NNNAD1zz7bCXa1xakCkpJVKDWUryuoaPU', 'poene3@networkadvertising.org', 'Georgia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('rkyteley4', '12foCsqum6ZMwBowUdqfnid7Zcg6PjHs34', 'ejosebury4@usa.gov', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('bravelus5', '141hrfG8gZ4vtWiUiBSXa2nFxwbUV2rbf3', 'bwint5@ning.com', 'Peru');
insert into sellers (seller_name, bitcoin_address, email, country) values ('titchingham6', '19P5o6v49v3nbHX5AasLKbqeji4wz2Ywkn', 'ccollman6@reference.com', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('gberrick7', '1JsZjNMerPyRcJeuVgG1UHXeHTjARGVjwT', 'spardie7@shareasale.com', 'Iran');
insert into sellers (seller_name, bitcoin_address, email, country) values ('dgillatt8', '1AbaCK5VWkKPDvT4DjTSfsP2RNwNGm2UZR', 'ecorradengo8@t-online.de', 'Greece');
insert into sellers (seller_name, bitcoin_address, email, country) values ('mperell9', '17sZh9urJXpqxm7WiasDqY2JisdR5XeYid', 'bewbanche9@exblog.jp', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('sscrigmoura', '1Bt4Mx8ttpQoeXFcdv4zYYUEUeosRqQtcZ', 'smithama@jimdo.com', 'Indonesia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('tblaslib', '15ARwoVCwxXV3e33tVtsqLNNRAR87Ckxju', 'jwoffendenb@github.io', 'Greece');
insert into sellers (seller_name, bitcoin_address, email, country) values ('dcallwayc', '1GDtVfv2x1F7mRX4HwRpSkm1VrbSyoopc3', 'bkalinskyc@wordpress.org', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('lvasyagind', '1HfiLMcpfaaN9qZNsNKkw6XAEDaAygyKan', 'dkohrtd@sitemeter.com', 'Bosnia and Herzegovina');
insert into sellers (seller_name, bitcoin_address, email, country) values ('mbeddise', '1GyH3bPvZhKCD7ND2RRRg6YQKKfFGPxHWN', 'lcaistore@myspace.com', 'Yemen');
insert into sellers (seller_name, bitcoin_address, email, country) values ('swinmillf', '1E8DSHgQGwWnuncyoeKQHrnRXKebUoWqPN', 'csutheranf@yahoo.com', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('gletixierg', '13xP1Wavq94FrM3vH1dmUtMnuHRnZMthSW', 'nwoodhamg@ask.com', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('lziehmsh', '1MBySCpgnn2pfuu31ADhfg3obXVaUsgi2p', 'dbernadeh@hexun.com', 'Czech Republic');
insert into sellers (seller_name, bitcoin_address, email, country) values ('rbrownsmithi', '1K7ktsm3mbLnkDSNapRoRpebXvF5cTVBGs', 'ntropmani@artisteer.com', 'Palestinian Territory');
insert into sellers (seller_name, bitcoin_address, email, country) values ('hbushbyj', '1CmkkMbQsFoWxnRm5nL6UPSYTMSAzsLa4J', 'jlinscottj@deviantart.com', 'Belarus');
insert into sellers (seller_name, bitcoin_address, email, country) values ('sworsallk', '13qNZ55s2ESTjkJemyFXMRx4g5vEe8brg1', 'crothmank@amazonaws.com', 'Estonia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('atoobyl', '14HVWp7tCKKcb43uVeLVfdu16fp9uTAR9K', 'afilasovl@smugmug.com', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('bnibleym', '137cYKVeGwxhDcESYTKMUHjQ1KSyYstCBY', 'obussm@wordpress.com', 'Micronesia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('dhamlingtonn', '14xeSWojriH79Q3qSCKVL6X1gcbH1yhehs', 'ndrinkalen@geocities.jp', 'United States');
insert into sellers (seller_name, bitcoin_address, email, country) values ('pgouldthorpo', '1JNZAHaeHrmroWGR2javJhngsseELzPwfZ', 'cheadlyo@who.int', 'Luxembourg');
insert into sellers (seller_name, bitcoin_address, email, country) values ('olondesboroughp', '1MhCFrsEFUjvS6ajb9gZuhgkCKbtAos4ue', 'cskevingtonp@webs.com', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('smactrusteyq', '1Ms2VDG5nEYyEGk1w3ALkKFcXX9Gpg9EDg', 'lhanselq@chronoengine.com', 'Indonesia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('hlavrinovr', '1GCdUisri4QtjXgYGDULMR36c45azdAcLP', 'sgiacobonir@economist.com', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('dfairleys', '12MxE5wExXVJ61ar4zvWLzPYJT1Y3kG7cP', 'bcleminshaws@google.com.hk', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('adefriest', '1GErigUAamvEz7AHsRsKipahmoJuRwD2Ne', 'spinnt@surveymonkey.com', 'Ukraine');
insert into sellers (seller_name, bitcoin_address, email, country) values ('wmurrhauptu', '18NacFNHtNxz33WvhzmrUwRxX4RiLSJSTv', 'planghoru@hhs.gov', 'Indonesia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('lgilleanv', '1HSfBVdDJiQ9bmd8gGyjSb1ZbiGAs4Fzp2', 'sbosquetv@wordpress.org', 'Peru');
insert into sellers (seller_name, bitcoin_address, email, country) values ('gpomfrettw', '1Cx15QaDU8PwgYngA7QXosx3Kgy8T1rtfT', 'cpohlakw@4shared.com', 'Sweden');
insert into sellers (seller_name, bitcoin_address, email, country) values ('hworvillx', '19XLmEM6KkLoNCXmYmkCZA88XT5pF7vUdc', 'htresslerx@java.com', 'Ecuador');
insert into sellers (seller_name, bitcoin_address, email, country) values ('mjacomby', '1N8KRq4eGcoa9oDF2NAF7opSifVGrLsYTS', 'mcarolly@samsung.com', 'Philippines');
insert into sellers (seller_name, bitcoin_address, email, country) values ('tmckiez', '151VKJ6vZ5AHPPkQA3q7EfHQ4HhYaGqbxT', 'cbrealeyz@cbsnews.com', 'Honduras');
insert into sellers (seller_name, bitcoin_address, email, country) values ('lforesight10', '1BrGVFHtkpz2umctV4s5v7Yr7S2yEoKgX8', 'pmumby10@whitehouse.gov', 'Philippines');
insert into sellers (seller_name, bitcoin_address, email, country) values ('tglendzer11', '1N7vUDQi3Ayk1eNWB42tuRD1L7ig4caBqG', 'hprozescky11@fastcompany.com', 'Republic of the Congo');
insert into sellers (seller_name, bitcoin_address, email, country) values ('mwanka12', '1MNXSbrywYiyAF5HaBqsfymthSTX47bspw', 'arennard12@google.ca', 'Czech Republic');
insert into sellers (seller_name, bitcoin_address, email, country) values ('lhibbart13', '1C7N4iM3XkzDWRdqwDzfdtSAi9scDPdU8b', 'ckellington13@dropbox.com', 'Japan');
insert into sellers (seller_name, bitcoin_address, email, country) values ('kdunridge14', '1KW551LcuwPC5dW9wPCBH12HHdXCnJUXw3', 'mgodlip14@sogou.com', 'Netherlands');
insert into sellers (seller_name, bitcoin_address, email, country) values ('gwigfield15', '1HUHr9N4XfjERio23tbvBtwEyo58V4nZMm', 'cgrealish15@google.nl', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('cspare16', '13dkNRtrX2Cy18HVWcrRkCtjKf3ZfoDv9k', 'cscreen16@cloudflare.com', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('lchucks17', '15hcUNJV25vfCEiBAZkkZoyyUGLqSDexm2', 'ereeders17@facebook.com', 'Philippines');
insert into sellers (seller_name, bitcoin_address, email, country) values ('vdaniel18', '142j7Wro75YrmBnzJiC8q4Uy5XH3F44XPW', 'jdugget18@nbcnews.com', 'Indonesia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('aferrari19', '1HGmQceaQ7uiXrWG8g7JgKFTt9jbY8VAD7', 'rianniello19@aboutads.info', 'Norway');
insert into sellers (seller_name, bitcoin_address, email, country) values ('hkilmurray1a', '1QJ1kgJbxq77XP16dHBe9iRb4thAJcAJ17', 'doaker1a@ox.ac.uk', 'Russia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('tdever1b', '112ySWahiRtQSrPvejEkufafTEEHnnjDn4', 'smoggie1b@google.nl', 'France');
insert into sellers (seller_name, bitcoin_address, email, country) values ('sharnwell1c', '14FZeDtbL22F6QyAvVCX5tvxTkM7U8cNGv', 'rtimmins1c@ustream.tv', 'Japan');
insert into sellers (seller_name, bitcoin_address, email, country) values ('hnorthrop1d', '1LbwHhKaNDgz8ypTYWreNnih8odyonMepV', 'gyancey1d@gravatar.com', 'Croatia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('mshevell1e', '1DQuu28ZDT5wjccNaT6u67DTQpFyq4DJ4K', 'lfarrear1e@wordpress.com', 'Philippines');
insert into sellers (seller_name, bitcoin_address, email, country) values ('gfreeborn1f', '1LjFXf5XmaM3U73WMdS361QeVujTorjmwE', 'kpattle1f@bloglines.com', 'Russia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('awerndley1g', '18qbJKwtRsnfxg1g2pZUMuHdVkMQJyKTTp', 'itivenan1g@clickbank.net', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('rbollis1h', '12HT2duvhXLjXLiBdQXNjMrPk5anGnxdqF', 'astobbes1h@cam.ac.uk', 'Russia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('rrawne1i', '1DkkcYaxjg4rhW9PgUBieqYB9iAczrTg1x', 'jugolotti1i@pinterest.com', 'Russia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('hgotmann1j', '1GKZ28Vz8RuFhi59vwtzC25vsv1bfQ1qrr', 'dmarien1j@constantcontact.com', 'Sweden');
insert into sellers (seller_name, bitcoin_address, email, country) values ('mpellew1k', '1G5p4t7VERe48bM1oSNK9Dc85vsJ2JYLLy', 'zraff1k@oracle.com', 'Indonesia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('lproffer1l', '1K4GCoaN1BwHgP15jBmSXu8fFkrxQsyqXb', 'tschonfelder1l@yandex.ru', 'Oman');
insert into sellers (seller_name, bitcoin_address, email, country) values ('nbutson1m', '15BbMTnYwdpFrGVkKGRSMP9znqLNJSeakr', 'rmonkleigh1m@youtube.com', 'Argentina');
insert into sellers (seller_name, bitcoin_address, email, country) values ('sjolliff1n', '17CknfwoxufJRu9XfgEZkzE2dm5FDMKoMA', 'fespin1n@opera.com', 'Oman');
insert into sellers (seller_name, bitcoin_address, email, country) values ('amoisey1o', '17p53oQQH1NESuBZuJCGyZPJaiKEqxzwPA', 'tchristopher1o@abc.net.au', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('fgreneham1p', '1RTZcAcrNF9QHumVBxq2yshcJyEy32ZDL', 'achiplin1p@zdnet.com', 'Sweden');
insert into sellers (seller_name, bitcoin_address, email, country) values ('ashelmerdine1q', '19tr3RZ46SX1UZwAYc2m8VQ4vgVV8QPwFm', 'rballe1q@51.la', 'Spain');
insert into sellers (seller_name, bitcoin_address, email, country) values ('kharesnaip1r', '1E7DqdcdSJpzmkwRtC6mJVYKDUrj99Pcut', 'lvescovini1r@blogger.com', 'United States');
insert into sellers (seller_name, bitcoin_address, email, country) values ('afarnall1s', '1DF9PDApTmohoDye2YAhnpeWr6LJPmtsnN', 'gcamamill1s@blogtalkradio.com', 'Finland');
insert into sellers (seller_name, bitcoin_address, email, country) values ('apretsell1t', '1B8ezKMgm9TrtzMmgharKNcNnV3vSySRqE', 'mkocher1t@discovery.com', 'Namibia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('rbrydone1u', '12W8YVcoUqq2cdXqzH6ZoTSKAKB9XT3Lfq', 'hloosmore1u@geocities.jp', 'Portugal');
insert into sellers (seller_name, bitcoin_address, email, country) values ('gpennington1v', '1EJv9rF6HpT4bpLyEmGfvjiyWtuzMyexsv', 'aspilsbury1v@usatoday.com', 'Greece');
insert into sellers (seller_name, bitcoin_address, email, country) values ('gcamilleri1w', '15sSr5UjawdPpCeh5s7coH88trEyfnPkFD', 'rmorrice1w@wiley.com', 'Greece');
insert into sellers (seller_name, bitcoin_address, email, country) values ('ncoughan1x', '1Ji3RcXPZzYKrFhtXtwjNPf8J4NYdRB5m2', 'pkenworthey1x@youku.com', 'Cambodia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('drenton1y', '1P64JnmfNziRYYQ2KsFsV3T4tgY4VhUnuK', 'bgipp1y@europa.eu', 'Bangladesh');
insert into sellers (seller_name, bitcoin_address, email, country) values ('bwindybank1z', '1PPvLY2fcVtTX3GS72aWMVy14vJcYZvJsG', 'phollerin1z@surveymonkey.com', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('nraun20', '1E2jmECxXpkPjQEqvf5qWdhK4wRiQJgUzv', 'kmale20@posterous.com', 'Uganda');
insert into sellers (seller_name, bitcoin_address, email, country) values ('otarn21', '1DR4u2sM9eQpueZYnKpiTk3aGa9gN4fBPw', 'bcandey21@sourceforge.net', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('lpotier22', '1DxrV13BNGwkiC7bz71gdSefDsXwnsuJQ1', 'bmiguel22@wikimedia.org', 'Indonesia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('tguiso23', '16QzZiUS9RdMpFMwwWr32so26gChjJiWcs', 'dwernham23@time.com', 'Sweden');
insert into sellers (seller_name, bitcoin_address, email, country) values ('bbaumadier24', '18ojTLX6c54x16QKuNcyBnxhsyTVDmqzY8', 'ecaren24@tinypic.com', 'Portugal');
insert into sellers (seller_name, bitcoin_address, email, country) values ('ilongbone25', '1HFwXZd7FEJiuNGSYM2N91XPDncWWkUuFo', 'fkemmett25@unblog.fr', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('fgivens26', '1K4aPg3QRJbzA7iirmR9VTEXUe5xu5EsaT', 'cdaouze26@irs.gov', 'Denmark');
insert into sellers (seller_name, bitcoin_address, email, country) values ('dtowlson27', '1JKqBTC7XoaaKhztZKWkxHnY6iLbrytq2d', 'sdarnody27@addtoany.com', 'Russia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('dtwigley28', '19PkMXTeUNyXjJtPCv5kn3Ax5NEJudB5BW', 'ldicks28@va.gov', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('khoppner29', '1ADojGyYxQZvVi6LNeyX7ibkuivWu3B6Qe', 'scompton29@ibm.com', 'Mongolia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('ssharpley2a', '1BKZe1vwHcTHpapwjRxkropWBTfJNG34br', 'acolicot2a@tripadvisor.com', 'Indonesia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('rhumble2b', '1J3uenLTbfJHtyCjN1FzKdXNPT9cvZzALs', 'aputt2b@mayoclinic.com', 'Israel');
insert into sellers (seller_name, bitcoin_address, email, country) values ('lcorinton2c', '1JvriBVNBhj5RXwmEuvQLA4iz4FWjZNvSM', 'hbradmore2c@businesswire.com', 'China');
insert into sellers (seller_name, bitcoin_address, email, country) values ('tgale2d', '16Rb4Vy4jkTssDHpDYN2f4omarwr2Z92h7', 'agriniov2d@dell.com', 'Brazil');
insert into sellers (seller_name, bitcoin_address, email, country) values ('avauter2e', '1CSphP3v1rhh2S5DaFtADS4frnQVJEJxPk', 'sfryatt2e@europa.eu', 'Sweden');
insert into sellers (seller_name, bitcoin_address, email, country) values ('hgiamitti2f', '1DS5gN39bGR7UrC7TmS7g8GcTZkcTWfUVD', 'mbynert2f@baidu.com', 'Belarus');
insert into sellers (seller_name, bitcoin_address, email, country) values ('jcarder2g', '16sErpwinDwwjhfwnaEBXY6wWckAUqSy4s', 'hpentecost2g@comcast.net', 'United States');
insert into sellers (seller_name, bitcoin_address, email, country) values ('mlodevick2h', '1F6pwqr8G1rJ58qqe1JpMQi8S5Ut7eZhGk', 'rsimony2h@ted.com', 'Peru');
insert into sellers (seller_name, bitcoin_address, email, country) values ('dnerheny2i', '13YrMT8jH3TjKeaizHd4Ryq2i4zutkREDA', 'mmiddlehurst2i@yellowbook.com', 'United States');
insert into sellers (seller_name, bitcoin_address, email, country) values ('mmacchaell2j', '12QYpUbjjpqnxzUqqW5GduzZG9nHDS1PVM', 'jmecozzi2j@hibu.com', 'Brazil');
insert into sellers (seller_name, bitcoin_address, email, country) values ('cdudderidge2k', '1BehnbEgRYGNTrj6eJfoa5K68yaYEBev59', 'jrameau2k@altervista.org', 'Tunisia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('gcallear2l', '1JEYboogbVDmmg4g2pyXLXcyCWpsdgGy6U', 'nelvy2l@google.com.au', 'Portugal');
insert into sellers (seller_name, bitcoin_address, email, country) values ('gkoenen2m', '1G6kgb2TuojEExX6Uqi8AeFaFf6qcYYasq', 'mstollmeyer2m@bigcartel.com', 'Pakistan');
insert into sellers (seller_name, bitcoin_address, email, country) values ('ostonman2n', '1EdnunoPnZfHWYvmHu9a29CXw7jx6ZVDad', 'rgalbraeth2n@ow.ly', 'Portugal');
insert into sellers (seller_name, bitcoin_address, email, country) values ('lmorkham2o', '13pMQPDYPzVQ2ymv48f4nN7YSuNuqzxrU5', 'jpearn2o@nsw.gov.au', 'Poland');
insert into sellers (seller_name, bitcoin_address, email, country) values ('pbaggett2p', '1PmknddxAW4eT6pGf5RpaQxYDgytgGwQGE', 'gdunne2p@delicious.com', 'Indonesia');
insert into sellers (seller_name, bitcoin_address, email, country) values ('jkernan2q', '1G5Ab2Tndnj1pNcCaw3SxYRSsWKLueX3Rg', 'tkinzel2q@si.edu', 'Norway');
insert into sellers (seller_name, bitcoin_address, email, country) values ('lmanns2r', '1N1SyHgrWNuewwhjFj9WNddJ1QrBy2ckvi', 'tsouthwell2r@flavors.me', 'Colombia');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO transactions (
	select b.bitcoin_address, s.bitcoin_address, now() - ((random()*1000)::integer||' day')::interval, (random()*10000)::numeric(6,1) 
	from buyers as b,sellers as s order by random() limit 1000
);




