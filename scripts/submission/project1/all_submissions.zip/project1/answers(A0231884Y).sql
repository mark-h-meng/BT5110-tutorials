/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* 
I design a used car online trading records database.
I set the entity set E1 to be used_cars, the entity set E2 to be users and the relationship set R to be orders.

Table used_cars records the used cars that have been sold at the online trading platform.
It contains 7 attributes:
carid is the primary key given by the platform to identify each used car,
quoted_price is the price offered by seller,
car_make is the brand of the used car,
car_model is the model of the used car,
bought_year is the time when the seller bought the car,
color is the color of the used car,
and seller_phone is the phone number of the seller that enables both the users and platform to contact with him to check the used car. 

Table users records all the registered users at the platform.
It contains 4 attributes:
username is the primary key,
fullname is the real identity information of the users which guarantees the authenticity of the transaction,
email and user_phone are unique attributes of the users that ensures one can only register with an email and a phone number once.

Table orders records the transaction orders completed at the platform.
It contains 2 foreign keys and 2 inner attributes:
carid is a foreign key referring to table used_cars’s carid and username is a foreign key referring to table users’s username.
They are both on update cascade because the trading platform and users are allowed to change their carid or username and alter the corresponding records in table orders so that the buyers and sellers can be traced.
Carid and username also constitute the primary key of table orders.
Besides, transaction_price is the end price of the sold used car,
and datetime is the date when the transaction completed.


*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

-- create table for entity used_cars:

CREATE TABLE IF NOT EXISTS used_cars (
	carid VARCHAR(64) NOT NULL PRIMARY KEY,
	quoted_price NUMERIC NOT NULL,
	car_make VARCHAR(64) NOT NULL,
	car_model VARCHAR(64) NOT NULL,
	bought_year VARCHAR(8) NOT NULL,
	color VARCHAR(16) NOT NULL,
	seller_phone VARCHAR(64) NOT NULL);

-- create table for entity users:

CREATE TABLE IF NOT EXISTS users(
	username VARCHAR(64) NOT NULL PRIMARY KEY,
	fullname VARCHAR(64) NOT NULL,
	email VARCHAR(64) UNIQUE NOT NULL,
	user_phone VARCHAR(64) UNIQUE NOT NULL);

-- create table for relationship orders:

CREATE TABLE IF NOT EXISTS orders(
	carid VARCHAR(64) REFERENCES used_cars(carid)
		ON UPDATE CASCADE
		DEFERRABLE INITIALLY DEFERRED,
	username VARCHAR(64) REFERENCES users(username)
		ON UPDATE CASCADE
		DEFERRABLE INITIALLY DEFERRED,
	PRIMARY KEY (carid, username),
	transaction_price NUMERIC NOT NULL,
	datetime DATE NOT NULL);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

-- insert data into table used_cars:

insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('3519001127', 310269, 'Pontiac', 'GTO', 1964, 'Aquamarine', '+48 680 580 4619');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('1668374866', 74979, 'Ford', 'E350', 2004, 'Indigo', '+86 837 988 0452');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9542328771', 172208, 'BMW', 'X3', 2007, 'Turquoise', '+1 404 555 9101');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('2637561954', 711558, 'Ford', 'E150', 2003, 'Purple', '+992 254 189 2426');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('5253390143', 469161, 'Honda', 'Pilot', 2008, 'Puce', '+86 788 350 5892');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9329059076', 394189, 'Honda', 'Civic', 2007, 'Crimson', '+86 992 321 5402');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('3885117355', 104190, 'Mitsubishi', 'Lancer Evolution', 2010, 'Blue', '+62 474 352 5271');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('8308038721', 387471, 'Dodge', 'Nitro', 2009, 'Mauv', '+86 898 839 9553');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('1445214340', 974187, 'GMC', '2500', 1997, 'Blue', '+62 868 172 1306');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9773711404', 195425, 'Chevrolet', 'Suburban 1500', 1995, 'Orange', '+52 731 238 1136');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('5205459321', 442570, 'Mitsubishi', 'Galant', 1998, 'Fuscia', '+39 503 989 4987');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9881283113', 456249, 'Volkswagen', 'GTI', 2008, 'Khaki', '+351 202 481 9865');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('1464097825', 170796, 'Mitsubishi', 'Mighty Max Macro', 1994, 'Red', '+30 879 908 7447');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('5785219403', 406448, 'Lamborghini', 'Gallardo', 2007, 'Yellow', '+30 598 484 5600');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('1364692628', 330467, 'Ford', 'E350', 2004, 'Khaki', '+62 203 707 9410');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('3619750688', 855214, 'Dodge', 'Dakota', 2003, 'Goldenrod', '+1 913 505 3768');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('1028204177', 140502, 'Nissan', 'Armada', 2007, 'Aquamarine', '+62 639 850 7424');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('3088915529', 641117, 'Volkswagen', 'New Beetle', 1998, 'Puce', '+62 610 239 7559');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('8084097392', 578433, 'Volkswagen', 'Cabriolet', 1998, 'Khaki', '+86 315 776 4368');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('6562129766', 669939, 'Chevrolet', 'Prizm', 1999, 'Green', '+355 306 402 3043');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9391865499', 745857, 'Jeep', 'Wrangler', 2000, 'Pink', '+86 654 229 8338');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('8118512990', 265424, 'Honda', 'S2000', 2004, 'Red', '+66 765 414 0503');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('7143335327', 958318, 'Hyundai', 'Elantra', 2008, 'Fuscia', '+506 637 419 9480');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9507674945', 180354, 'Volkswagen', 'Cabriolet', 2000, 'Red', '+93 482 171 6028');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9893891905', 331081, 'Mercury', 'Grand Marquis', 1999, 'Fuscia', '+504 697 362 9556');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('1724058181', 725153, 'Subaru', 'XT', 1985, 'Maroon', '+357 333 941 5380');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('5657949817', 498170, 'Chevrolet', 'Suburban 1500', 1997, 'Mauv', '+381 614 862 7043');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('6291514253', 200394, 'Ford', 'Explorer Sport Trac', 2007, 'Blue', '+51 746 221 2876');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('7774112425', 645462, 'Chevrolet', '1500', 1994, 'Goldenrod', '+420 634 865 1277');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9222036757', 553155, 'Lexus', 'GX', 2006, 'Goldenrod', '+86 332 306 3248');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('5263136247', 990234, 'Chrysler', 'Concorde', 1995, 'Goldenrod', '+86 425 122 5267');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('8366108261', 719141, 'Saturn', 'L-Series', 2002, 'Red', '+62 405 563 6438');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('5727886217', 710001, 'Mercury', 'Sable', 1994, 'Yellow', '+86 560 281 1389');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('2633573607', 47173, 'Volkswagen', 'New Beetle', 1999, 'Turquoise', '+7 265 589 6106');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('7678178009', 937373, 'Chevrolet', 'Avalanche 1500', 2002, 'Fuscia', '+62 170 702 5212');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('7416073958', 823096, 'Dodge', 'Ram 1500 Club', 1997, 'Pink', '+86 894 612 2948');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('6436004205', 694882, 'Mitsubishi', 'Pajero', 1995, 'Fuscia', '+30 681 701 4714');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('3458716632', 138571, 'Bentley', 'Continental GT', 2008, 'Turquoise', '+82 585 695 6598');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9709578907', 68424, 'Hyundai', 'Sonata', 2001, 'Purple', '+86 628 656 3795');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9084201209', 331063, 'Mercedes-Benz', 'CL-Class', 2009, 'Indigo', '+62 541 834 9478');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9908512533', 994426, 'Suzuki', 'Grand Vitara', 2010, 'Khaki', '+93 411 267 4521');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('2816796551', 195743, 'Land Rover', 'Range Rover', 1990, 'Mauv', '+7 687 145 5081');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('7445525002', 831263, 'Mercedes-Benz', 'CL-Class', 2002, 'Orange', '+53 506 492 6746');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('5371502500', 860693, 'Maserati', 'Quattroporte', 2009, 'Mauv', '+86 931 295 1873');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('7262085226', 203936, 'Mitsubishi', 'Challenger', 2001, 'Orange', '+420 714 724 2984');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('7374396830', 232845, 'Chrysler', 'Voyager', 2003, 'Purple', '+86 160 858 6681');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('4588185379', 420989, 'Porsche', 'Cayenne', 2011, 'Pink', '+63 362 416 6322');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('4432745212', 439091, 'Ford', 'LTD Crown Victoria', 1986, 'Violet', '+62 640 593 3596');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('6314785183', 156376, 'Nissan', 'Xterra', 2006, 'Pink', '+86 245 305 3038');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('2906822669', 407745, 'Dodge', 'Viper', 2006, 'Turquoise', '+57 959 359 0080');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('7069011531', 468087, 'Saturn', 'S-Series', 1998, 'Puce', '+598 915 294 1425');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('7302730869', 948282, 'Maserati', 'Biturbo', 1984, 'Violet', '+352 251 142 5063');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('2598423023', 796276, 'Eagle', 'Talon', 1995, 'Turquoise', '+351 423 335 6281');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('6847213862', 732013, 'Toyota', 'TundraMax', 2011, 'Green', '+86 618 192 8266');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('5079632585', 896288, 'Pontiac', 'GTO', 2006, 'Blue', '+380 445 924 8127');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('2112682626', 172125, 'Subaru', 'Impreza', 1999, 'Crimson', '+1 469 689 0618');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('7153407659', 549006, 'Mazda', 'CX-5', 2013, 'Pink', '+7 516 540 4455');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('4975697573', 610571, 'Ford', 'Torino', 1970, 'Turquoise', '+33 769 844 0197');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('6806077211', 799176, 'Honda', 'Element', 2009, 'Turquoise', '+39 801 839 2888');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('8088517469', 77702, 'Mazda', 'RX-7', 1992, 'Puce', '+63 676 959 7718');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9086560877', 54810, 'Lotus', 'Evora', 2011, 'Violet', '+66 706 985 6847');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('5155629663', 460311, 'Chrysler', 'PT Cruiser', 2009, 'Green', '+63 281 702 0938');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('6365673728', 654022, 'Volvo', '240', 1992, 'Violet', '+86 667 547 7317');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('1015692761', 717329, 'Chevrolet', 'Cobalt SS', 2008, 'Turquoise', '+86 897 569 3683');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('4344708774', 824609, 'Volkswagen', 'New Beetle', 2009, 'Yellow', '+232 660 762 1484');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('3283463760', 93678, 'Aston Martin', 'Virage', 2011, 'Mauv', '+386 298 551 3739');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('3017552652', 547150, 'Land Rover', 'Range Rover', 2008, 'Aquamarine', '+33 144 286 2002');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('2114699289', 882082, 'Chevrolet', 'Monte Carlo', 1996, 'Khaki', '+86 400 512 5102');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('1729131916', 223496, 'Chevrolet', 'Cavalier', 1994, 'Turquoise', '+48 846 877 9879');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9104876939', 640113, 'Nissan', 'Pathfinder', 2010, 'Blue', '+62 838 626 4629');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('8887399342', 407273, 'Mercury', 'Topaz', 1989, 'Goldenrod', '+358 273 727 9241');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('8101146559', 309281, 'Dodge', 'D350 Club', 1993, 'Blue', '+229 448 302 3717');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('6506886111', 428571, 'Eagle', 'Talon', 1997, 'Aquamarine', '+86 755 213 6047');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('4284298290', 967393, 'Nissan', '240SX', 1995, 'Purple', '+86 994 291 0071');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9338128884', 760849, 'Audi', 'A8', 2003, 'Violet', '+57 400 898 0041');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('6057152990', 417594, 'Honda', 'S2000', 2004, 'Indigo', '+7 549 212 4653');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9419386565', 259818, 'Ford', 'Aerostar', 1996, 'Turquoise', '+63 729 204 8098');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('2208771811', 262635, 'Cadillac', 'DeVille', 2005, 'Turquoise', '+62 645 361 1083');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('3499263824', 505633, 'Lincoln', 'MKX', 2008, 'Crimson', '+265 127 566 9244');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('3397876185', 26051, 'Ford', 'F350', 2007, 'Green', '+62 634 945 6639');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9551971687', 387495, 'Lamborghini', 'Murciélago', 2003, 'Fuscia', '+1 407 455 7012');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('8112095812', 463162, 'Nissan', 'Altima', 2006, 'Teal', '+86 543 342 8570');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('4412051868', 694418, 'Dodge', 'Ram 3500', 2000, 'Maroon', '+972 520 497 8039');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('6256403465', 437882, 'Toyota', 'Sequoia', 2009, 'Teal', '+225 140 383 8483');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('4554641407', 139807, 'Pontiac', 'GTO', 2005, 'Goldenrod', '+7 213 709 6215');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('1134264792', 16252, 'Suzuki', 'Aerio', 2005, 'Indigo', '+81 214 404 7473');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('1207852167', 469664, 'BMW', '3 Series', 2011, 'Purple', '+57 490 597 8015');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('4282697963', 783300, 'Subaru', 'Baja', 2005, 'Crimson', '+970 340 465 2040');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9502155296', 336471, 'Chevrolet', 'Cruze', 2013, 'Khaki', '+374 681 688 9059');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('1248883620', 511283, 'BMW', '5 Series', 1995, 'Khaki', '+86 857 344 6732');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('6727891774', 510440, 'Mercedes-Benz', 'SL-Class', 1992, 'Khaki', '+63 384 921 9749');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('2679033082', 257580, 'Scion', 'xB', 2005, 'Fuscia', '+595 580 285 9104');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('1383747881', 503478, 'Plymouth', 'Grand Voyager', 1993, 'Purple', '+48 717 972 1381');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('9589765444', 148227, 'Infiniti', 'I', 2001, 'Aquamarine', '+86 791 155 7903');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('2024093589', 592462, 'Mercedes-Benz', 'GLK-Class', 2011, 'Khaki', '+86 467 273 7868');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('6236882789', 886372, 'Pontiac', 'Sunbird', 1988, 'Blue', '+48 923 889 4541');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('7091261924', 402164, 'Mitsubishi', 'RVR', 1995, 'Yellow', '+63 608 199 3704');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('3152018765', 376087, 'Isuzu', 'i-290', 2008, 'Puce', '+27 968 865 5024');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('2822313943', 391450, 'BMW', '650', 2006, 'Green', '+86 175 507 4887');
insert into used_cars (carid, quoted_price, car_make, car_model, bought_year, color, seller_phone) values ('2793769081', 513063, 'Porsche', 'Cayenne', 2006, 'Fuscia', '+503 343 253 3618');


-- insert data into table users:

insert into users (username, fullname, email, user_phone) values ('jlimon0', 'Jemmy Limon', 'jlimon0@bbb.org', '+62 806 212 4484');
insert into users (username, fullname, email, user_phone) values ('mvondrak1', 'Mollee Vondrak', 'mvondrak1@newsvine.com', '+1 770 764 7023');
insert into users (username, fullname, email, user_phone) values ('cchestnut2', 'Carlen Chestnut', 'cchestnut2@cargocollective.com', '+94 909 961 9041');
insert into users (username, fullname, email, user_phone) values ('wblockey3', 'Wakefield Blockey', 'wblockey3@microsoft.com', '+46 266 300 8736');
insert into users (username, fullname, email, user_phone) values ('kburlingham4', 'Kelci Burlingham', 'kburlingham4@t-online.de', '+976 680 504 5180');
insert into users (username, fullname, email, user_phone) values ('fgreatrex5', 'Frayda Greatrex', 'fgreatrex5@samsung.com', '+62 138 779 6237');
insert into users (username, fullname, email, user_phone) values ('jwatmore6', 'Jessi Watmore', 'jwatmore6@geocities.com', '+86 998 482 5060');
insert into users (username, fullname, email, user_phone) values ('cjostan7', 'Carlina Jostan', 'cjostan7@etsy.com', '+62 378 534 1939');
insert into users (username, fullname, email, user_phone) values ('ghearson8', 'Gilligan Hearson', 'ghearson8@mtv.com', '+1 656 693 9357');
insert into users (username, fullname, email, user_phone) values ('rphuprate9', 'Rebekkah Phuprate', 'rphuprate9@prlog.org', '+237 460 902 6250');
insert into users (username, fullname, email, user_phone) values ('mhodjettsa', 'Meta Hodjetts', 'mhodjettsa@bbb.org', '+53 461 836 2680');
insert into users (username, fullname, email, user_phone) values ('tperellb', 'Townsend Perell', 'tperellb@pbs.org', '+54 712 613 3764');
insert into users (username, fullname, email, user_phone) values ('fschimekc', 'Fred Schimek', 'fschimekc@ezinearticles.com', '+267 119 540 9729');
insert into users (username, fullname, email, user_phone) values ('gsynnotd', 'Giraud Synnot', 'gsynnotd@wikimedia.org', '+62 307 679 5645');
insert into users (username, fullname, email, user_phone) values ('tshortene', 'Tucky Shorten', 'tshortene@weather.com', '+86 423 218 0316');
insert into users (username, fullname, email, user_phone) values ('mlubertif', 'Melina Luberti', 'mlubertif@craigslist.org', '+970 460 499 5433');
insert into users (username, fullname, email, user_phone) values ('jmuschetteg', 'Jodee Muschette', 'jmuschetteg@newyorker.com', '+7 718 651 4624');
insert into users (username, fullname, email, user_phone) values ('psiggeeh', 'Pepi Siggee', 'psiggeeh@about.com', '+7 845 403 0187');
insert into users (username, fullname, email, user_phone) values ('ahaughtoni', 'Abbot Haughton', 'ahaughtoni@alibaba.com', '+81 634 932 6862');
insert into users (username, fullname, email, user_phone) values ('kbillj', 'Kassey Bill', 'kbillj@goo.ne.jp', '+55 503 161 3862');
insert into users (username, fullname, email, user_phone) values ('smerrigank', 'Silvie Merrigan', 'smerrigank@e-recht24.de', '+62 644 931 6884');
insert into users (username, fullname, email, user_phone) values ('icartyl', 'Ingaberg Carty', 'icartyl@omniture.com', '+351 563 221 0726');
insert into users (username, fullname, email, user_phone) values ('lhakkingm', 'Lyndsie Hakking', 'lhakkingm@discovery.com', '+269 679 366 4747');
insert into users (username, fullname, email, user_phone) values ('jmoren', 'Johnny More', 'jmoren@fc2.com', '+63 467 133 3911');
insert into users (username, fullname, email, user_phone) values ('gfranssenio', 'Gerhardine Fransseni', 'gfranssenio@stanford.edu', '+62 178 867 4271');
insert into users (username, fullname, email, user_phone) values ('ebeechcraftp', 'Elwin Beechcraft', 'ebeechcraftp@disqus.com', '+55 494 202 1779');
insert into users (username, fullname, email, user_phone) values ('apunyerq', 'Auria Punyer', 'apunyerq@dmoz.org', '+55 298 650 1290');
insert into users (username, fullname, email, user_phone) values ('grolfor', 'Gabbi Rolfo', 'grolfor@dyndns.org', '+351 353 599 5619');
insert into users (username, fullname, email, user_phone) values ('cblazas', 'Cilka Blaza', 'cblazas@accuweather.com', '+58 441 196 8629');
insert into users (username, fullname, email, user_phone) values ('rdaveleyt', 'Rosabelle Daveley', 'rdaveleyt@123-reg.co.uk', '+57 119 705 1558');
insert into users (username, fullname, email, user_phone) values ('myvensu', 'Moreen Yvens', 'myvensu@discovery.com', '+7 299 214 9718');
insert into users (username, fullname, email, user_phone) values ('bspowagev', 'Becka Spowage', 'bspowagev@google.ca', '+51 956 128 6369');
insert into users (username, fullname, email, user_phone) values ('rleaheyw', 'Robenia Leahey', 'rleaheyw@comcast.net', '+86 394 114 6548');
insert into users (username, fullname, email, user_phone) values ('jyeox', 'Jareb Yeo', 'jyeox@123-reg.co.uk', '+86 697 985 8748');
insert into users (username, fullname, email, user_phone) values ('marghenty', 'Marley Arghent', 'marghenty@google.nl', '+86 557 610 5851');
insert into users (username, fullname, email, user_phone) values ('ssnookesz', 'Shayna Snookes', 'ssnookesz@bluehost.com', '+7 302 866 4022');
insert into users (username, fullname, email, user_phone) values ('smacdaid10', 'Sarine MacDaid', 'smacdaid10@deviantart.com', '+225 150 955 7311');
insert into users (username, fullname, email, user_phone) values ('coxbrow11', 'Clem Oxbrow', 'coxbrow11@deviantart.com', '+86 277 227 9512');
insert into users (username, fullname, email, user_phone) values ('fle12', 'Fenelia Le Fleming', 'fle12@squarespace.com', '+86 107 507 5535');
insert into users (username, fullname, email, user_phone) values ('wstainbridge13', 'Whittaker Stainbridge', 'wstainbridge13@hugedomains.com', '+86 875 344 6926');
insert into users (username, fullname, email, user_phone) values ('mtomes14', 'Marchall Tomes', 'mtomes14@google.de', '+30 964 441 8650');
insert into users (username, fullname, email, user_phone) values ('gwestphal15', 'Gallagher Westphal', 'gwestphal15@cisco.com', '+86 538 303 8346');
insert into users (username, fullname, email, user_phone) values ('gdiboll16', 'Grenville Diboll', 'gdiboll16@hexun.com', '+48 790 884 9419');
insert into users (username, fullname, email, user_phone) values ('taiskrigg17', 'Tandi Aiskrigg', 'taiskrigg17@istockphoto.com', '+86 459 436 4142');
insert into users (username, fullname, email, user_phone) values ('fmacbane18', 'Frayda Macbane', 'fmacbane18@goo.ne.jp', '+62 991 798 0837');
insert into users (username, fullname, email, user_phone) values ('adunsford19', 'Ashley Dunsford', 'adunsford19@ibm.com', '+58 436 497 2558');
insert into users (username, fullname, email, user_phone) values ('ndevoy1a', 'Nikos Devoy', 'ndevoy1a@newsvine.com', '+234 782 574 4616');
insert into users (username, fullname, email, user_phone) values ('cbevens1b', 'Corabelle Bevens', 'cbevens1b@cbsnews.com', '+62 769 536 7002');
insert into users (username, fullname, email, user_phone) values ('pbutts1c', 'Park Butts', 'pbutts1c@columbia.edu', '+1 478 538 3019');
insert into users (username, fullname, email, user_phone) values ('aseamarke1d', 'Aurore Seamarke', 'aseamarke1d@cbc.ca', '+86 983 747 2330');
insert into users (username, fullname, email, user_phone) values ('gwintringham1e', 'Guy Wintringham', 'gwintringham1e@stanford.edu', '+503 304 304 2196');
insert into users (username, fullname, email, user_phone) values ('bteanby1f', 'Brittani Teanby', 'bteanby1f@ca.gov', '+63 984 920 3821');
insert into users (username, fullname, email, user_phone) values ('jludron1g', 'Jenica Ludron', 'jludron1g@cbsnews.com', '+351 653 600 8370');
insert into users (username, fullname, email, user_phone) values ('ddahill1h', 'Deloria Dahill', 'ddahill1h@yandex.ru', '+86 688 837 0150');
insert into users (username, fullname, email, user_phone) values ('mdeverock1i', 'Miranda Deverock', 'mdeverock1i@woothemes.com', '+86 401 333 0801');
insert into users (username, fullname, email, user_phone) values ('cbisgrove1j', 'Carri Bisgrove', 'cbisgrove1j@goo.gl', '+63 641 825 5768');
insert into users (username, fullname, email, user_phone) values ('tmedcalfe1k', 'Talia Medcalfe', 'tmedcalfe1k@gizmodo.com', '+352 884 179 0889');
insert into users (username, fullname, email, user_phone) values ('kslamaker1l', 'Kitty Slamaker', 'kslamaker1l@infoseek.co.jp', '+86 395 681 3719');
insert into users (username, fullname, email, user_phone) values ('lniesegen1m', 'Libbey Niesegen', 'lniesegen1m@cyberchimps.com', '+48 512 297 5116');
insert into users (username, fullname, email, user_phone) values ('miggalden1n', 'Maribel Iggalden', 'miggalden1n@webeden.co.uk', '+381 126 345 7717');
insert into users (username, fullname, email, user_phone) values ('scrumpton1o', 'Shawn Crumpton', 'scrumpton1o@hugedomains.com', '+86 630 589 6868');
insert into users (username, fullname, email, user_phone) values ('nshanklin1p', 'Neel Shanklin', 'nshanklin1p@g.co', '+48 684 811 2747');
insert into users (username, fullname, email, user_phone) values ('agoring1q', 'Allard Goring', 'agoring1q@answers.com', '+86 495 953 7537');
insert into users (username, fullname, email, user_phone) values ('kshingles1r', 'Keane Shingles', 'kshingles1r@imgur.com', '+48 372 457 9870');
insert into users (username, fullname, email, user_phone) values ('mdecourt1s', 'Micki Decourt', 'mdecourt1s@pinterest.com', '+54 823 494 7362');
insert into users (username, fullname, email, user_phone) values ('breville1t', 'Bronny Reville', 'breville1t@businesswire.com', '+62 910 108 4964');
insert into users (username, fullname, email, user_phone) values ('chedgecock1u', 'Caressa Hedgecock', 'chedgecock1u@webs.com', '+260 422 823 6085');
insert into users (username, fullname, email, user_phone) values ('lroome1v', 'Lilith Roome', 'lroome1v@feedburner.com', '+63 665 726 1415');
insert into users (username, fullname, email, user_phone) values ('ktongs1w', 'Karlie Tongs', 'ktongs1w@ca.gov', '+81 320 249 3944');
insert into users (username, fullname, email, user_phone) values ('lweatherburn1x', 'Lamond Weatherburn', 'lweatherburn1x@usa.gov', '+48 746 707 3380');
insert into users (username, fullname, email, user_phone) values ('aduce1y', 'Amabel Duce', 'aduce1y@admin.ch', '+52 516 484 6697');
insert into users (username, fullname, email, user_phone) values ('xsweeten1z', 'Ximenes Sweeten', 'xsweeten1z@exblog.jp', '+967 936 567 2323');
insert into users (username, fullname, email, user_phone) values ('iaddicott20', 'Inigo Addicott', 'iaddicott20@illinois.edu', '+86 202 324 5686');
insert into users (username, fullname, email, user_phone) values ('lleeb21', 'Lucho Leeb', 'lleeb21@ucsd.edu', '+46 992 172 6665');
insert into users (username, fullname, email, user_phone) values ('csinclar22', 'Corbett Sinclar', 'csinclar22@qq.com', '+86 749 742 3520');
insert into users (username, fullname, email, user_phone) values ('ibiddleston23', 'Issy Biddleston', 'ibiddleston23@constantcontact.com', '+51 990 985 5101');
insert into users (username, fullname, email, user_phone) values ('ksarvar24', 'Kathe Sarvar', 'ksarvar24@sohu.com', '+376 826 314 2304');
insert into users (username, fullname, email, user_phone) values ('gpetrillo25', 'Gustie Petrillo', 'gpetrillo25@rediff.com', '+62 536 523 8685');
insert into users (username, fullname, email, user_phone) values ('kdartnell26', 'Keenan Dartnell', 'kdartnell26@pinterest.com', '+46 809 990 1874');
insert into users (username, fullname, email, user_phone) values ('crowles27', 'Calypso Rowles', 'crowles27@vkontakte.ru', '+380 720 586 9898');
insert into users (username, fullname, email, user_phone) values ('bhawkshaw28', 'Bertrand Hawkshaw', 'bhawkshaw28@paginegialle.it', '+502 924 472 4083');
insert into users (username, fullname, email, user_phone) values ('mevitts29', 'Minni Evitts', 'mevitts29@google.co.jp', '+7 261 643 0958');
insert into users (username, fullname, email, user_phone) values ('gdixson2a', 'Griselda Dixson', 'gdixson2a@photobucket.com', '+62 218 548 4717');
insert into users (username, fullname, email, user_phone) values ('dgoody2b', 'Daloris Goody', 'dgoody2b@i2i.jp', '+43 866 570 4404');
insert into users (username, fullname, email, user_phone) values ('cwinfield2c', 'Clarinda Winfield', 'cwinfield2c@nasa.gov', '+86 650 611 9481');
insert into users (username, fullname, email, user_phone) values ('dburman2d', 'Dasya Burman', 'dburman2d@marketwatch.com', '+46 737 662 7480');
insert into users (username, fullname, email, user_phone) values ('eparis2e', 'Eberhard Paris', 'eparis2e@engadget.com', '+86 678 455 8183');
insert into users (username, fullname, email, user_phone) values ('aeverwin2f', 'Alysa Everwin', 'aeverwin2f@storify.com', '+383 578 628 3505');
insert into users (username, fullname, email, user_phone) values ('vpattini2g', 'Velvet Pattini', 'vpattini2g@nhs.uk', '+86 639 185 2774');
insert into users (username, fullname, email, user_phone) values ('adunkerley2h', 'Aigneis Dunkerley', 'adunkerley2h@artisteer.com', '+86 779 263 3519');
insert into users (username, fullname, email, user_phone) values ('awilby2i', 'Agosto Wilby', 'awilby2i@google.com.br', '+385 168 680 3430');
insert into users (username, fullname, email, user_phone) values ('dbugdale2j', 'Doralin Bugdale', 'dbugdale2j@reverbnation.com', '+84 653 707 1570');
insert into users (username, fullname, email, user_phone) values ('sakess2k', 'Stearne Akess', 'sakess2k@scientificamerican.com', '+62 366 441 5613');
insert into users (username, fullname, email, user_phone) values ('vmattiussi2l', 'Vassili Mattiussi', 'vmattiussi2l@newsvine.com', '+84 934 141 7287');
insert into users (username, fullname, email, user_phone) values ('gcaws2m', 'Gratiana Caws', 'gcaws2m@irs.gov', '+7 593 852 9373');
insert into users (username, fullname, email, user_phone) values ('eokeevan2n', 'Elene O''Keevan', 'eokeevan2n@networkadvertising.org', '+54 123 636 4419');
insert into users (username, fullname, email, user_phone) values ('ggockeler2o', 'Gale Gockeler', 'ggockeler2o@furl.net', '+33 483 268 4736');
insert into users (username, fullname, email, user_phone) values ('atrembath2p', 'Avrit Trembath', 'atrembath2p@yahoo.com', '+39 682 172 9839');
insert into users (username, fullname, email, user_phone) values ('creville2q', 'Cammy Reville', 'creville2q@mediafire.com', '+63 677 676 1489');
insert into users (username, fullname, email, user_phone) values ('lcracknall2r', 'Lauraine Cracknall', 'lcracknall2r@newsvine.com', '+86 683 472 6419');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

-- select foreign keys from table used_cars, users, and generate transaction_price and datetime randomly:

INSERT INTO orders
SELECT carid, username,
	ROUND(RANDOM()*100000 + 10000),
	(NOW() - '1000 day'::INTERVAL * ROUND(RANDOM() * 20))::date
FROM used_cars, users
ORDER BY RANDOM()
LIMIT 1000;

