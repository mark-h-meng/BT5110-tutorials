/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* 
In this project, we have 3 tables: movies, watches, and customers. The 
entity sets are movies and customers, and the relationship is the watches,
which links the two entities.

The table 'movies' list all the movies we have on offer on our movies streaming
website, and contains the fields 'name', 'genre', 'language', 'year', which 
are respectively the name of the movie, genre of movie,the language of the 
movie, and the year that the movie was produced. Together, the name, language,
and year make up the primary key of a movie to uniquely identify it.

The 'customers' table list all the information of the customers that we have
on our streaming services. So, 'first_name', 'last_name' correspond to the
customers' names, 'email' corresponds to their email address, 'dob' is their
date of birth (we may want to offer special discounts for this date), 'since'
tells us when the customer joined our website, 'country' says where the 
customers are located, and 'customerid' is the unique customer identification
number. 'customerid' is set to be the primary key.

The table 'watches' tells us which movies a customer has watched. It 
references 'customerid' from the table 'customers', and the unique movie
identifier, which is a foreign key, (name, language,year) identifying
a unique movie.


*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


CREATE TABLE customers (
first_name VARCHAR(64), 
last_name VARCHAR(64),
email VARCHAR(64),
dob DATE,
since DATE,
customerid VARCHAR(16) PRIMARY KEY,
country VARCHAR(32));

CREATE TABLE movies(
name VARCHAR(120),
genre VARCHAR(50),
language VARCHAR(50),
year DATE,
PRIMARY KEY (name, language,year) );

CREATE TABLE watches (
customerid VARCHAR(16) REFERENCES customers (customerid),
name VARCHAR(120),
language CHAR(50),
year DATE,
FOREIGN KEY (name,language,year) REFERENCES movies(name,language,year));



/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Itch', 'Bradburn', 'ibradburn0@slate.com', '14/10/1961', '16/06/2002', 'Wr4894243', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Cornelle', 'Goodding', 'cgoodding1@google.com.au', '26/07/1962', '21/07/2006', 'Xj4891842', 'Indonesia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Iggie', 'Donoghue', 'idonoghue2@twitter.com', '04/05/2000', '18/12/2013', 'Nc6086290', 'Luxembourg');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Portie', 'Walewicz', 'pwalewicz3@timesonline.co.uk', '22/03/1976', '16/05/2018', 'Rb1079910', 'Philippines');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Zilvia', 'Georger', 'zgeorger4@hc360.com', '24/01/1927', '13/06/1984', 'Hr2916918', 'Brazil');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Corney', 'Izod', 'cizod5@usatoday.com', '31/08/1981', '24/09/1996', 'Nw1352387', 'Indonesia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Emanuel', 'Nand', 'enand6@digg.com', '15/06/2007', '30/01/1984', 'Oc5320727', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Malena', 'Winchurst', 'mwinchurst7@sfgate.com', '16/06/1906', '16/02/1990', 'Vv3542984', 'Portugal');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Tera', 'Reynault', 'treynault8@cafepress.com', '25/09/1942', '05/12/1990', 'Ie9614733', 'Croatia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Darcie', 'Gooddy', 'dgooddy9@theguardian.com', '17/01/1991', '30/07/2003', 'Gc1616326', 'Thailand');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Chevy', 'Lukianov', 'clukianova@eventbrite.com', '29/07/1988', '23/08/2000', 'Nj5111126', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Crysta', 'Adin', 'cadinb@acquirethisname.com', '12/02/1977', '09/07/2021', 'Sb7811933', 'Poland');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Adair', 'Risso', 'arissoc@usatoday.com', '09/06/1937', '06/11/2006', 'Md8564512', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Hewie', 'Matchett', 'hmatchettd@irs.gov', '30/04/1943', '28/01/1984', 'Qc7391521', 'Nepal');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Dollie', 'Venart', 'dvenarte@unicef.org', '19/05/1950', '09/09/2016', 'Wq7196687', 'Sierra Leone');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Trever', 'Burnhams', 'tburnhamsf@surveymonkey.com', '28/06/1985', '06/11/1998', 'Lc8018510', 'France');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Aprilette', 'Friedman', 'afriedmang@livejournal.com', '16/06/1962', '06/02/1985', 'Jx2420269', 'Palau');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Carter', 'Scholtis', 'cscholtish@ox.ac.uk', '13/05/1926', '19/04/1981', 'Pg5262709', 'Russia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Walton', 'Dumberrill', 'wdumberrilli@wikispaces.com', '15/06/1901', '03/01/2013', 'Bs6607423', 'Indonesia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Alonso', 'Blaskett', 'ablaskettj@un.org', '09/02/1997', '14/10/1997', 'Ps9762076', 'Japan');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Tomasine', 'Curryer', 'tcurryerk@amazon.co.jp', '02/06/1992', '02/03/2007', 'Dj0277622', 'Netherlands');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Starlene', 'Nordass', 'snordassl@delicious.com', '15/12/1996', '28/12/1998', 'He3729190', 'Uganda');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Yorke', 'Doe', 'ydoem@mozilla.com', '14/11/1954', '01/05/1991', 'Tz6340457', 'Ukraine');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Alta', 'O'' Cloney', 'aocloneyn@about.me', '24/11/1950', '05/10/2018', 'Sx8617681', 'France');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Pancho', 'Rippon', 'prippono@comcast.net', '20/07/1974', '02/11/2011', 'Rn0585900', 'French Guiana');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Coleman', 'Kolodziejski', 'ckolodziejskip@shareasale.com', '22/06/2006', '10/07/2000', 'Yu2981002', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Hestia', 'Pilipets', 'hpilipetsq@weather.com', '18/02/1921', '28/11/1987', 'Fd4494695', 'Morocco');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Teena', 'Veart', 'tveartr@nifty.com', '27/10/1951', '16/08/1983', 'Gj3121754', 'Russia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Allx', 'Amberger', 'aambergers@weibo.com', '26/09/2019', '04/05/1992', 'Tj3504511', 'Portugal');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Andonis', 'Hillan', 'ahillant@adobe.com', '24/08/1998', '22/07/1989', 'Eu7646781', 'Palestinian Territory');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Marlowe', 'Baptista', 'mbaptistau@ning.com', '28/10/1991', '21/02/1988', 'Pq9614088', 'Cameroon');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Clevey', 'Gladbach', 'cgladbachv@hhs.gov', '05/04/1994', '24/08/2008', 'Mk0887253', 'Mexico');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Antons', 'Turton', 'aturtonw@nps.gov', '29/01/1957', '14/09/2007', 'Qp5875844', 'Ukraine');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Benetta', 'Ketcher', 'bketcherx@cmu.edu', '30/03/1988', '30/06/2008', 'Jl6720702', 'Japan');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Darda', 'Rapier', 'drapiery@youtu.be', '17/01/1905', '02/10/1998', 'Ph6499648', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Jacky', 'McCromley', 'jmccromleyz@ocn.ne.jp', '11/08/1969', '04/11/2019', 'Iy8709046', 'Italy');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Faina', 'O''Griffin', 'fogriffin10@bigcartel.com', '30/06/1910', '03/01/1987', 'Lh5968541', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Ailbert', 'Millery', 'amillery11@state.gov', '06/06/2015', '14/08/1990', 'Kv7945132', 'Peru');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Bebe', 'Cadding', 'bcadding12@go.com', '11/05/1976', '02/07/1990', 'Lu7914324', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Everett', 'Pettengell', 'epettengell13@accuweather.com', '08/02/2015', '30/10/2010', 'Yd1177976', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Alexina', 'Ashington', 'aashington14@usnews.com', '11/07/2019', '07/12/2000', 'Nd4091543', 'Namibia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Ailey', 'Casetti', 'acasetti15@slate.com', '25/02/1968', '16/09/1983', 'Bn2305083', 'Portugal');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Zacharia', 'Boschmann', 'zboschmann16@quantcast.com', '22/05/1929', '02/05/2004', 'Cs1271411', 'Greece');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Kurtis', 'Cordero', 'kcordero17@typepad.com', '11/10/1914', '22/10/2012', 'Lv4861044', 'Burkina Faso');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Brendin', 'Hanford', 'bhanford18@google.com.hk', '08/04/1920', '14/01/1980', 'Jv9937652', 'Chad');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Ricardo', 'Hinstridge', 'rhinstridge19@cnn.com', '31/08/1975', '12/07/2006', 'Rg9815629', 'Indonesia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Haskell', 'Law', 'hlaw1a@homestead.com', '26/01/1910', '29/04/2000', 'Qw8769552', 'Portugal');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Vincenty', 'Hatz', 'vhatz1b@elegantthemes.com', '20/10/1908', '14/03/2007', 'Pd4774609', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Agata', 'Simon', 'asimon1c@linkedin.com', '04/05/1919', '26/12/1983', 'Wm7196431', 'Finland');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Royce', 'Bramhill', 'rbramhill1d@shop-pro.jp', '30/12/1912', '08/09/2005', 'Uy1803956', 'Indonesia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Cristen', 'Doxsey', 'cdoxsey1e@va.gov', '04/07/1985', '21/02/2008', 'Pa3450702', 'France');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Darcy', 'Wethey', 'dwethey1f@godaddy.com', '02/07/1964', '16/05/1980', 'Mz6658024', 'Greece');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Mohandis', 'Stanfield', 'mstanfield1g@java.com', '31/10/1996', '22/12/2004', 'Cb2569424', 'Russia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Devora', 'Wiggin', 'dwiggin1h@weebly.com', '01/02/1922', '18/12/2005', 'Rb0570562', 'Tajikistan');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Eddy', 'Druhan', 'edruhan1i@nsw.gov.au', '17/11/2011', '14/11/2016', 'Db4460069', 'Indonesia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Zane', 'Revie', 'zrevie1j@blog.com', '28/03/1903', '30/07/2004', 'Zv2414484', 'North Korea');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Isa', 'Jeffray', 'ijeffray1k@ameblo.jp', '23/05/1981', '03/05/1994', 'Jn2881521', 'Dominican Republic');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Bess', 'Swithenby', 'bswithenby1l@statcounter.com', '19/12/1906', '23/11/1996', 'Po7779897', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Vivianne', 'Red', 'vred1m@barnesandnoble.com', '01/08/1944', '09/11/1987', 'Ys1542273', 'Brazil');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Ashien', 'Dummigan', 'adummigan1n@shinystat.com', '05/08/1942', '08/06/1993', 'Vh6641797', 'Brazil');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Baxie', 'Sclanders', 'bsclanders1o@tumblr.com', '21/04/1982', '21/01/2005', 'If5942312', 'Ukraine');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Sollie', 'Itzkovich', 'sitzkovich1p@unc.edu', '28/06/1956', '31/08/1983', 'Vs9718256', 'Philippines');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Donny', 'Frankton', 'dfrankton1q@twitpic.com', '25/12/1921', '19/08/2013', 'Dw6503126', 'Japan');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Ephrayim', 'Ygou', 'eygou1r@bloglines.com', '28/05/1954', '02/08/1998', 'Cr0518525', 'Antigua and Barbuda');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Kaela', 'Arnaudot', 'karnaudot1s@flavors.me', '01/12/1945', '23/06/2017', 'Lu2783562', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Arnold', 'Whaplington', 'awhaplington1t@studiopress.com', '27/06/1950', '06/04/1993', 'An3292880', 'Portugal');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Shurlock', 'Philpotts', 'sphilpotts1u@acquirethisname.com', '19/09/1988', '01/05/1986', 'Kj5848906', 'Nigeria');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Hadley', 'Spurdens', 'hspurdens1v@goodreads.com', '13/04/2000', '01/06/1985', 'Ft3204413', 'Brazil');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Weider', 'Belf', 'wbelf1w@springer.com', '04/12/1999', '25/07/2004', 'Bh5021394', 'Kazakhstan');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Cheri', 'Liquorish', 'cliquorish1x@booking.com', '11/02/1912', '12/06/1985', 'Lj3407822', 'Germany');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Jacquenette', 'Duiguid', 'jduiguid1y@tamu.edu', '08/12/2017', '15/08/1987', 'My3538576', 'Indonesia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Tonnie', 'Tuxsell', 'ttuxsell1z@virginia.edu', '29/07/1982', '17/06/2005', 'Gp0167782', 'Chad');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Wenonah', 'Kermath', 'wkermath20@photobucket.com', '09/11/1916', '23/08/2007', 'Ty0249792', 'Burkina Faso');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Inglis', 'Grealish', 'igrealish21@seesaa.net', '15/09/1924', '23/11/1990', 'Ge4608330', 'Russia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Annemarie', 'Whitsey', 'awhitsey22@furl.net', '22/04/2017', '10/10/2014', 'Cw3637485', 'Vietnam');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Clifford', 'Adel', 'cadel23@1688.com', '10/10/1964', '24/07/2013', 'Xl3624002', 'France');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Dru', 'Skahill', 'dskahill24@elegantthemes.com', '07/10/1923', '09/02/1988', 'Al8719436', 'Ecuador');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Jasen', 'Lemerle', 'jlemerle25@ucla.edu', '16/03/1958', '06/03/1993', 'Gf4117339', 'Belarus');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Margo', 'Mutton', 'mmutton26@facebook.com', '29/06/1947', '17/05/2002', 'Qb7200388', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Bobbee', 'Gareisr', 'bgareisr27@baidu.com', '12/02/1970', '14/12/1996', 'Tp3404961', 'Philippines');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Germaine', 'Gunston', 'ggunston28@nba.com', '24/02/1941', '13/02/2008', 'Hx0917248', 'Russia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Alameda', 'Zimek', 'azimek29@weather.com', '04/11/2016', '19/11/1986', 'Xg5593334', 'Iraq');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Filippo', 'Eloy', 'feloy2a@dmoz.org', '11/10/1918', '19/07/1994', 'Vi5526902', 'Indonesia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Den', 'Hailwood', 'dhailwood2b@eepurl.com', '09/12/1944', '21/08/1999', 'Uh6177555', 'Georgia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Evvy', 'Cartin', 'ecartin2c@csmonitor.com', '31/12/2001', '27/04/1992', 'Nl2254333', 'Madagascar');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Pate', 'Coneybeare', 'pconeybeare2d@who.int', '17/02/1951', '25/06/2008', 'Ve6781203', 'Pakistan');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Aida', 'Eilhart', 'aeilhart2e@ask.com', '29/09/1917', '19/02/1989', 'Lu4869937', 'Indonesia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Francene', 'Dannehl', 'fdannehl2f@answers.com', '24/05/1947', '26/12/1981', 'Dk2602388', 'Philippines');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Haydon', 'Haquard', 'hhaquard2g@digg.com', '02/06/2018', '17/04/2007', 'Oq1434742', 'Mauritius');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Pepita', 'Briatt', 'pbriatt2h@sohu.com', '10/06/1990', '08/09/2000', 'Ij7129945', 'France');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Andriette', 'Willgress', 'awillgress2i@theguardian.com', '01/04/2004', '24/05/1994', 'Ob8916948', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Steffen', 'Duggan', 'sduggan2j@chron.com', '30/05/1918', '27/10/2018', 'Tg5911352', 'Indonesia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Diandra', 'Wisedale', 'dwisedale2k@independent.co.uk', '04/01/1906', '27/07/2012', 'Yy1614453', 'Indonesia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Pru', 'Blabie', 'pblabie2l@forbes.com', '28/08/1938', '11/02/1987', 'Qp9871170', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Corrine', 'Phythien', 'cphythien2m@purevolume.com', '13/03/1977', '11/02/1984', 'Ia4476467', 'Ukraine');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Andriette', 'Rendbaek', 'arendbaek2n@hhs.gov', '07/07/1950', '01/09/1988', 'Ox7781236', 'Russia');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Mitchell', 'Duligall', 'mduligall2o@dagondesign.com', '30/05/1975', '05/11/2015', 'Cr1270791', 'United States');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Marthena', 'Mundle', 'mmundle2p@dell.com', '18/01/2020', '19/04/2006', 'Iy5176985', 'China');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Hayyim', 'McCritichie', 'hmccritichie2q@oaic.gov.au', '04/03/2009', '26/03/1997', 'Md0779877', 'Argentina');
insert into CUSTOMERS (first_name, last_name, email, dob, since, customerid, country) values ('Rozina', 'Rebillard', 'rrebillard2r@yahoo.co.jp', '06/04/1932', '23/02/2002', 'Rk4826604', 'Colombia');

insert into movies (name, genre, language, year) values ('Boxtrolls, The', 'Adventure|Animation|Children|Comedy|Fantasy', 'Tajik', '31/10/2005');
insert into movies (name, genre, language, year) values ('Game, The', 'Drama|Mystery|Thriller', 'Swedish', '20/06/1993');
insert into movies (name, genre, language, year) values ('Triad Underworld (Gong wu) (Jiang Hu)', 'Action|Crime|Drama', 'Kazakh', '11/11/1997');
insert into movies (name, genre, language, year) values ('Monsieur Ibrahim (Monsieur Ibrahim et les fleurs du Coran)', 'Drama', 'Malagasy', '28/06/1997');
insert into movies (name, genre, language, year) values ('Cry-Baby', 'Comedy|Musical|Romance', 'Dari', '30/10/2008');
insert into movies (name, genre, language, year) values ('Stella Street', 'Comedy', 'Spanish', '08/09/2007');
insert into movies (name, genre, language, year) values ('47  Ronin (Shijûshichinin no shikaku)', 'Action|Drama', 'Latvian', '10/05/1969');
insert into movies (name, genre, language, year) values ('Brotherhood', 'Crime|Drama|Thriller', 'Catalan', '21/09/1989');
insert into movies (name, genre, language, year) values ('Holidays by the Sea (Ni à vendre ni à louer)', 'Comedy', 'Māori', '05/02/2004');
insert into movies (name, genre, language, year) values ('Grand Piano', 'Mystery|Thriller', 'Zulu', '01/12/1990');
insert into movies (name, genre, language, year) values ('Have Rocket, Will Travel', 'Comedy|Sci-Fi', 'Arabic', '22/08/1967');
insert into movies (name, genre, language, year) values ('Such a Long Journey', 'Drama|War', 'Polish', '20/04/1980');
insert into movies (name, genre, language, year) values ('Gregory Go Boom', 'Comedy', 'Guaraní', '23/08/1965');
insert into movies (name, genre, language, year) values ('Flight of the Living Dead', 'Action|Horror|Sci-Fi', 'Somali', '14/11/1995');
insert into movies (name, genre, language, year) values ('Money (L''argent)', 'Crime|Drama', 'Belarusian', '11/07/1999');
insert into movies (name, genre, language, year) values ('Erasing David', 'Documentary', 'Dhivehi', '03/05/2006');
insert into movies (name, genre, language, year) values ('Leap of Faith', 'Comedy|Drama', 'Tajik', '17/09/1987');
insert into movies (name, genre, language, year) values ('Shinobi No Mono 3: Resurrection (Shin shinobi no mono)', 'Action|Drama', 'Lao', '05/10/1990');
insert into movies (name, genre, language, year) values ('Dazed and Confused', 'Comedy', 'Albanian', '28/01/1989');
insert into movies (name, genre, language, year) values ('Fata Morgana', 'Documentary|Drama|Sci-Fi', 'Fijian', '21/07/1999');
insert into movies (name, genre, language, year) values ('Barber of Siberia, The (Sibirskij tsiryulnik)', 'Drama|Romance', 'Catalan', '11/09/1998');
insert into movies (name, genre, language, year) values ('American Ninja 3: Blood Hunt', 'Action|Adventure', 'Tajik', '20/10/1993');
insert into movies (name, genre, language, year) values ('Running from Crazy', 'Documentary', 'Spanish', '13/03/2015');
insert into movies (name, genre, language, year) values ('Snake and Crane Arts of Shaolin (She hao ba bu)', 'Action|Drama', 'Montenegrin', '11/06/1984');
insert into movies (name, genre, language, year) values ('Black on White (Mustaa valkoisella)', 'Drama', 'Gujarati', '13/01/1990');
insert into movies (name, genre, language, year) values ('Bastards (Les salauds)', 'Drama', 'Yiddish', '12/04/2018');
insert into movies (name, genre, language, year) values ('One Body Too Many', 'Comedy|Horror|Mystery', 'Bengali', '10/12/2005');
insert into movies (name, genre, language, year) values ('Clapham Junction', 'Drama', 'Bulgarian', '06/01/2014');
insert into movies (name, genre, language, year) values ('Basket Case', 'Comedy|Horror', 'Danish', '24/04/2012');
insert into movies (name, genre, language, year) values ('Air Crew', 'Action|Drama|Thriller', 'Filipino', '23/04/1979');
insert into movies (name, genre, language, year) values ('Park Row', 'Drama|Thriller', 'Amharic', '30/10/1997');
insert into movies (name, genre, language, year) values ('Galician Caress (Of Clay)', 'Documentary', 'Persian', '16/12/2008');
insert into movies (name, genre, language, year) values ('10 Rillington Place', 'Crime|Drama|Thriller', 'Nepali', '11/01/1998');
insert into movies (name, genre, language, year) values ('Along Came a Spider', 'Action|Crime|Mystery|Thriller', 'Dhivehi', '05/03/1966');
insert into movies (name, genre, language, year) values ('Heaven Can Wait', 'Comedy|Fantasy|Romance', 'Estonian', '28/03/2010');
insert into movies (name, genre, language, year) values ('Scooby-Doo! Curse of the Lake Monster', 'Adventure|Children|Comedy|Mystery', 'Persian', '15/01/1975');
insert into movies (name, genre, language, year) values ('Ator, the Fighting Eagle (Ator l''invincibile)', 'Action|Adventure|Fantasy', 'Bengali', '07/09/1975');
insert into movies (name, genre, language, year) values ('Argentina latente', 'Documentary', 'Lao', '09/02/2001');
insert into movies (name, genre, language, year) values ('Kisses (Kuchizuke)', 'Drama|Romance', 'Malayalam', '08/05/2018');
insert into movies (name, genre, language, year) values ('Not Another Not Another Movie', 'Comedy', 'Lao', '03/02/2018');
insert into movies (name, genre, language, year) values ('Prisoners of the Lost Universe', 'Action|Adventure|Sci-Fi', 'Guaraní', '25/04/1962');
insert into movies (name, genre, language, year) values ('Fight, Zatoichi, Fight (Zatôichi kesshô-tabi) (Zatôichi 8)', 'Action|Adventure|Comedy|Drama', 'Quechua', '16/01/2006');
insert into movies (name, genre, language, year) values ('Other Side of Heaven, The', 'Adventure|Drama', 'Georgian', '19/11/1973');
insert into movies (name, genre, language, year) values ('Last Emperor, The', 'Drama', 'Estonian', '09/07/2014');
insert into movies (name, genre, language, year) values ('House with Laughing Windows, The (Casa dalle finestre che ridono, La)', 'Horror|Mystery|Thriller', 'Zulu', '18/09/2010');
insert into movies (name, genre, language, year) values ('Underground Comedy Movie, The', 'Comedy', 'Kyrgyz', '03/02/1984');
insert into movies (name, genre, language, year) values ('After the Wedding (Efter brylluppet)', 'Drama', 'Filipino', '29/09/1986');
insert into movies (name, genre, language, year) values ('Supermensch: The Legend of Shep Gordon', 'Documentary', 'Greek', '13/04/2008');
insert into movies (name, genre, language, year) values ('Flower Drum Song', 'Comedy|Musical|Romance', 'Haitian Creole', '05/10/1970');
insert into movies (name, genre, language, year) values ('Father and Son (Otets i syn)', 'Drama', 'Macedonian', '22/05/2004');
insert into movies (name, genre, language, year) values ('Mighty Joe Young', 'Adventure|Children|Drama', 'Lao', '31/05/1961');
insert into movies (name, genre, language, year) values ('Motocrossed', 'Action|Children|Comedy|Romance', 'Catalan', '16/09/2000');
insert into movies (name, genre, language, year) values ('Bright Lights', 'Comedy', 'Quechua', '23/01/1986');
insert into movies (name, genre, language, year) values ('The Monastery of Sendomir', 'Drama', 'Punjabi', '11/09/1994');
insert into movies (name, genre, language, year) values ('Kung Fu Panda', 'Action|Animation|Children|Comedy|IMAX', 'Quechua', '22/01/1966');
insert into movies (name, genre, language, year) values ('Wreckers', 'Drama', 'Kashmiri', '12/04/1995');
insert into movies (name, genre, language, year) values ('Last Lions, The', 'Documentary', 'Tetum', '20/07/2019');
insert into movies (name, genre, language, year) values ('Gridiron Gang', 'Drama', 'Malay', '01/05/1979');
insert into movies (name, genre, language, year) values ('Wild River', 'Drama|Romance', 'Nepali', '30/06/2002');
insert into movies (name, genre, language, year) values ('May in the Summer', 'Comedy|Drama', 'Kannada', '29/03/2016');
insert into movies (name, genre, language, year) values ('The Police Serve the Citizens?', 'Action|Crime', 'Afrikaans', '11/01/1993');
insert into movies (name, genre, language, year) values ('Shanghai Noon', 'Action|Adventure|Comedy|Western', 'Finnish', '25/04/1974');
insert into movies (name, genre, language, year) values ('Vigilante', 'Action|Crime|Drama', 'Māori', '05/03/2003');
insert into movies (name, genre, language, year) values ('LEGO Batman: The Movie - DC Heroes Unite', 'Action|Adventure|Animation', 'French', '07/07/2000');
insert into movies (name, genre, language, year) values ('Tribulation', 'Drama|Sci-Fi|Thriller', 'Malay', '04/07/1970');
insert into movies (name, genre, language, year) values ('Balls of Fury', 'Comedy', 'Dutch', '20/05/1993');
insert into movies (name, genre, language, year) values ('Conan O''Brien Can''t Stop', 'Documentary', 'Tajik', '22/08/1996');
insert into movies (name, genre, language, year) values ('Goodbye Again', 'Drama|Romance', 'Arabic', '19/03/1979');
insert into movies (name, genre, language, year) values ('Airheads', 'Comedy', 'Bengali', '17/06/2017');
insert into movies (name, genre, language, year) values ('Committed', 'Comedy|Drama', 'Dzongkha', '30/06/1966');
insert into movies (name, genre, language, year) values ('Off the Charts: The Song-Poem Story', 'Documentary', 'Sotho', '13/12/1970');
insert into movies (name, genre, language, year) values ('Rurouni Kenshin (Rurôni Kenshin: Meiji kenkaku roman tan)', 'Action|Drama', 'Hebrew', '06/12/1995');
insert into movies (name, genre, language, year) values ('Lovely Molly', 'Horror', 'Sotho', '13/04/2000');
insert into movies (name, genre, language, year) values ('Knowing', 'Action|Drama|Mystery|Sci-Fi|Thriller', 'Tajik', '13/05/1977');
insert into movies (name, genre, language, year) values ('The Garden of Sinners - Chapter 5: Paradox Paradigm', 'Animation', 'Haitian Creole', '24/06/1981');
insert into movies (name, genre, language, year) values ('Without a Paddle: Nature''s Calling', 'Adventure|Comedy', 'Marathi', '25/04/1989');
insert into movies (name, genre, language, year) values ('Torrente 5: Operación Eurovegas', 'Action|Comedy', 'Kurdish', '11/07/1995');
insert into movies (name, genre, language, year) values ('American Virgin', 'Comedy', 'Arabic', '09/08/2020');
insert into movies (name, genre, language, year) values ('Legend of Hell House, The', 'Horror|Thriller', 'Dutch', '22/07/1970');
insert into movies (name, genre, language, year) values ('Condition Red (Beyond the Law)', 'Action|Drama|Thriller', 'Oriya', '08/07/1980');
insert into movies (name, genre, language, year) values ('Water Lilies (Naissance des pieuvres)', 'Drama', 'Latvian', '30/10/1976');
insert into movies (name, genre, language, year) values ('Godzilla vs. Megalon (Gojira tai Megaro)', 'Action|Sci-Fi', 'Fijian', '26/07/2003');
insert into movies (name, genre, language, year) values ('Harvey Girls, The', 'Comedy|Musical|Western', 'Malay', '03/04/1966');
insert into movies (name, genre, language, year) values ('Anything for Her (Pour elle)', 'Crime|Drama|Thriller', 'Persian', '05/02/1996');
insert into movies (name, genre, language, year) values ('What to Do in Case of Fire (Was tun, wenn''s brennt?)', 'Comedy|Drama', 'Maltese', '12/12/1996');
insert into movies (name, genre, language, year) values ('Insomnia', 'Drama|Mystery|Thriller', 'Aymara', '14/10/2020');
insert into movies (name, genre, language, year) values ('Blow Out', 'Mystery|Thriller', 'Quechua', '01/03/1995');
insert into movies (name, genre, language, year) values ('State of Play', 'Crime|Drama|Thriller', 'Assamese', '06/02/1979');
insert into movies (name, genre, language, year) values ('Crazy Kind of Love', 'Comedy|Drama|Romance', 'Amharic', '02/06/1972');
insert into movies (name, genre, language, year) values ('Do You Remember Dolly Bell? (Sjecas li se, Dolly Bell)', 'Comedy|Drama|Romance', 'Tetum', '18/08/2011');
insert into movies (name, genre, language, year) values ('I''ll Sleep When I''m Dead', 'Crime|Drama', 'Moldovan', '14/07/1963');
insert into movies (name, genre, language, year) values ('Miss Nobody', 'Comedy|Crime', 'Lao', '30/04/2012');
insert into movies (name, genre, language, year) values ('The Orkly Kid', 'Comedy', 'Catalan', '25/09/1973');
insert into movies (name, genre, language, year) values ('Begotten', 'Drama|Horror', 'Czech', '26/06/2001');
insert into movies (name, genre, language, year) values ('Westfront 1918', 'Drama|War', 'Thai', '10/04/1981');
insert into movies (name, genre, language, year) values ('It Runs in the Family (My Summer Story)', 'Comedy', 'Hiri Motu', '10/05/1963');
insert into movies (name, genre, language, year) values ('Darkest Hour, The', 'Action|Horror|Sci-Fi|Thriller', 'Maltese', '06/06/2021');
insert into movies (name, genre, language, year) values ('Ride the Divide', 'Adventure|Documentary', 'Tetum', '21/05/2011');
insert into movies (name, genre, language, year) values ('Centenarian Who Climbed Out the Window and Vanished, The (Hundraåringen som klev ut genom fönstret och försvann)', 'Adventure|Comedy|Drama', 'Hiri Motu', '20/10/1986');
insert into movies (name, genre, language, year) values ('Arthur', 'Comedy', 'Hiri Motu', '07/08/2000');


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


INSERT INTO watches (customerid, name,language,year)
SELECT customerid, name, language, year from customers,movies
ORDER BY RANDOM()
LIMIT 1000 ;


SELECT * from watches;



