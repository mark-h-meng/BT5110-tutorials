/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
Entity set E1 (client) is a list of clients of a trading firm, 
providing information about their customer demographics such as gender, income as well as address (including latitude and longitude).

Entity set E2 (ticker) is a list of stocks available on various exchange,
providing information regarding the stock name, ticker, industry, sector and market cap.

The relationship table (client_ticker) tells us the transaction details of clients, 
providing information on transaction creation timestamp, ticker, stock name and total amount purchased.

Using the clients' demographics, we can analyse whether there are transactional patterns over time among age group, gender and income,
including with their preferences in sector and industry.  
One interesting use case of this entity-relationship is to find out which ticker is the most heavily invested
amongst geographical locations (using latitude and longitude to plot on map).

*/

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

DROP TABLE IF EXISTS client_ticker;
DROP TABLE IF EXISTS client;
DROP TABLE IF EXISTS ticker;

create table client (
	customer_id VARCHAR(40) PRIMARY KEY,
	email_address VARCHAR(50) UNIQUE,
	first_name VARCHAR(50) NOT NULL,
	last_name VARCHAR(50) NOT NULL,
	gender VARCHAR(50) NOT NULL,
	income NUMERIC NOT NULL,
	latitude NUMERIC NOT NULL,
	longitude NUMERIC NOT NULL
);

CREATE table ticker (
	stock_name VARCHAR(100) UNIQUE NOT NULL,
	ticker VARCHAR(50) UNIQUE NOT NULL,
	market VARCHAR(50),
	sector VARCHAR(50),
	market_cap VARCHAR(50),
	industry VARCHAR(100),
  PRIMARY KEY (stock_name, ticker)
);


CREATE TABLE client_ticker (
	customer_id VARCHAR(40) REFERENCES client (customer_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE,
	stock_name VARCHAR(100) NOT NULL REFERENCES ticker (stock_name) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE,
	ticker VARCHAR(50) NOT NULL REFERENCES ticker (ticker) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE,
	created_at TIMESTAMPTZ,
	total_purchased NUMERIC NOT NULL CHECK (total_purchased>0), 
	PRIMARY KEY (customer_id, stock_name, ticker, created_at)
);


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('f911fe55-6fb5-4252-8ff0-02ba0ac6e880', 'cperri0@cdc.gov', 'Carline', 'Perri', 'Bigender', 629795, 45.2911425, 20.1955026);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('ee98f1a5-2231-4a58-a651-ff10899ef0f0', 'vgilvary1@yandex.ru', 'Vernor', 'Gilvary', 'Bigender', 830904, 22.463604, -79.7231612);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('42c3fb23-e901-4a14-b0e3-41a451ac9b0b', 'bmarchello2@guardian.co.uk', 'Borden', 'Marchello', 'Bigender', 418106, 59.9123889, 10.8335476);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('d3f6431d-caec-41be-a782-74721b5f309b', 'gbonnor3@wiley.com', 'Gregory', 'Bonnor', 'Polygender', 825220, -8.1844859, 113.6680747);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('d4e22b68-9649-4cad-8607-fd2ac5d31a2d', 'mpirozzi4@so-net.ne.jp', 'Moselle', 'Pirozzi', 'Agender', 784795, 23.0706415, 112.4852219);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('a8e3e0f1-238e-4d0a-8e4f-921efcb3b3fa', 'mgardener5@vistaprint.com', 'Myrvyn', 'Gardener', 'Polygender', 142189, 40.819371, 122.248779);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('01bc7b86-7b2e-4520-a7ba-f5e02563cef8', 'ddahlman6@jiathis.com', 'Daren', 'Dahlman', 'Genderfluid', 164375, 23.125735, 113.964824);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('1ac2f932-e39c-4321-8593-5b95c52b3e70', 'lprobart7@360.cn', 'Lorilyn', 'Probart', 'Genderqueer', 13989, 11.7808864, 9.597952);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('b7b8efe1-c096-4a2a-b6dc-e92042c524c8', 'mpavluk8@blogger.com', 'Marie-jeanne', 'Pavluk', 'Agender', 280097, 13.274365, 120.618416);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('8b881784-eaa6-4de9-9a98-1daaa02ba400', 'gorfeur9@weebly.com', 'Gallard', 'Orfeur', 'Genderqueer', 959943, 48.9848042, 16.4023975);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('84d1a3ba-0319-41c7-84af-022e251c7127', 'cgilardonia@hugedomains.com', 'Chevy', 'Gilardoni', 'Female', 858626, -2.1596406, -79.8184684);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('23eb532d-412e-4187-8f54-7cc41a80434d', 'yputtickb@sbwire.com', 'Yuma', 'Puttick', 'Genderfluid', 184013, -13.6824359, -71.6228355);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('c872b2de-35ef-4f59-8bc0-ae58032df500', 'fkendredc@dion.ne.jp', 'Fernande', 'Kendred', 'Bigender', 741968, -19.6499319, -45.2243578);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('b2a61271-d856-40bf-8e23-9cc661a00fc2', 'rroysond@businessinsider.com', 'Rickard', 'Royson', 'Non-binary', 352732, 50.85237, 19.9677201);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('269830d8-27c9-45fe-8f5f-8892132eb617', 'svamplerse@barnesandnoble.com', 'Sarena', 'Vamplers', 'Genderfluid', 462656, 38.47436, 106.239679);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('4d6a6d75-c865-4e35-8fe3-cc5465de008d', 'mdenerleyf@google.co.jp', 'Merline', 'Denerley', 'Female', 210224, 2.18873, 98.61185);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('51bc8396-d0d6-43fc-b501-ff3c887faeb4', 'dgodfreyg@comsenz.com', 'Dorena', 'Godfrey', 'Agender', 61144, 55.6558059, 37.4793238);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('80feeaf1-b1e0-4850-a328-4c5a474cab46', 'kclach@surveymonkey.com', 'Katha', 'Clac', 'Male', 443983, 39.059554, 117.457493);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('195717df-cf18-42f5-b53e-6489fe186602', 'dvondruskai@addthis.com', 'Dixie', 'Vondruska', 'Agender', 415156, 59.3320898, 18.0574901);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('e6f5088b-ca80-48ba-82b3-c53edc3791c9', 'dcleynej@uiuc.edu', 'Donnajean', 'Cleyne', 'Genderqueer', 73555, 48.966667, 96.783333);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('8d1937a1-4531-4ccc-9b3d-76d8db5f9e29', 'achalcraftk@ning.com', 'Aurel', 'Chalcraft', 'Genderfluid', 510067, 53.3284298, -6.3048641);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('1ded48fa-0362-4042-86c6-cc2ce5751aab', 'lsexceyl@instagram.com', 'Lindsay', 'Sexcey', 'Male', 809622, 49.8508, -100.93262);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('0b985ee1-5e56-49c9-9fab-0a63712a0035', 'cmacgruerm@booking.com', 'Caril', 'MacGruer', 'Non-binary', 6535, 49.83258, 14.6843228);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('2e32052c-5826-4f11-a027-46228ce89d4a', 'bportingalen@artisteer.com', 'Bayard', 'Portingale', 'Agender', 643887, 40.7822677, 22.5735489);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('99839599-28b3-4cc5-b902-38b8b16d4535', 'acancotto@cocolog-nifty.com', 'Aurelie', 'Cancott', 'Female', 584641, 33.7282738, 135.9914552);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('acc710fd-3e53-4540-90c1-a549c29780df', 'amaclucaisp@ed.gov', 'Ange', 'MacLucais', 'Polygender', 791464, 16.3270679, 103.4916438);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('efdb5764-ebb0-4ee6-a872-5b36ef94ebf1', 'jmagogq@last.fm', 'Jerry', 'Magog', 'Bigender', 687674, 6.9827437, -5.7405139);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('f798f2a3-0991-4e0b-885c-67ff7cd5b5e7', 'tpopeleyr@woothemes.com', 'Tirrell', 'Popeley', 'Polygender', 722013, -28.3833642, -53.929557);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('6155f481-e1b9-4dd1-b979-9be3f0adbfc9', 'shindricks@wp.com', 'Sadie', 'Hindrick', 'Agender', 224119, 50.025483, 16.2590848);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('be6bc15f-9c2f-47c2-8978-4d0a49da12d8', 'nronchettit@hugedomains.com', 'Niven', 'Ronchetti', 'Bigender', 756030, 21.1494763, -100.956682);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('31ebd271-1119-4b6d-96a5-e202fbd35b82', 'mspeersu@tamu.edu', 'Manuel', 'Speers', 'Non-binary', 570966, 14.0031627, 0.7556575);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('63f8e629-1a7a-4dd5-a172-561df8a59190', 'fkingerbyv@github.com', 'Flora', 'Kingerby', 'Bigender', 515274, -8.3408114, 123.6231723);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('b0674148-9b1e-437c-9b05-3d4da19facc0', 'mbashfordw@independent.co.uk', 'Milo', 'Bashford', 'Polygender', 65396, -7.1272731, 108.6828838);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('4f6d85f0-9609-409e-ab1b-562be9d78ecf', 'jheapsx@aol.com', 'Jessie', 'Heaps', 'Male', 747052, 23.7322067, -99.1829833);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('7ea26dc3-20c4-4f78-aee8-0ac835d26254', 'piannelloy@phoca.cz', 'Papageno', 'Iannello', 'Polygender', 639048, 27.517896, 109.213644);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('6fdd2d78-5a4e-4230-bbed-22c40965b64f', 'jbaptistz@printfriendly.com', 'Jeana', 'Baptist', 'Female', 373463, 40.6945206, -7.8725232);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('880b1089-4d0d-4eb6-9890-e6d1484982c4', 'gwoolnough10@seesaa.net', 'Gunter', 'Woolnough', 'Female', 823954, -7.1259703, 112.4023244);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('92ccea0d-df6c-42ec-a0bc-e3529766882c', 'fbrettell11@bigcartel.com', 'Fitz', 'Brettell', 'Genderfluid', 62015, 5.329576, 103.1369108);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('3e663e4d-5027-40e6-9a53-cbdfe48682af', 'bmcwhan12@issuu.com', 'Buiron', 'McWhan', 'Genderqueer', 630730, 49.9936338, 20.0199888);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('f1ddcdb0-74bf-4f23-9cd7-77cb96acc274', 'lspeke13@g.co', 'Laurena', 'Speke', 'Polygender', 460518, -5.1841285, -37.3477805);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('55ee210b-badb-4e1d-9927-89d6b6ec6c41', 'cbrandon14@prlog.org', 'Catlaina', 'Brandon', 'Agender', 597337, 58.955833, 36.5925);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('855f2de7-5da1-406a-9e77-64e3fa08adab', 'kdomenichini15@cisco.com', 'Ky', 'Domenichini', 'Agender', 191301, 39.6920939, -8.4272356);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('939b5f0c-7bc8-40a6-86d9-bf773782a227', 'mmonck16@google.it', 'Madelyn', 'Monck', 'Genderfluid', 160636, -6.995577, 112.9862557);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('990ea455-4f26-40c0-bf66-8723ec5ad0f2', 'disbell17@merriam-webster.com', 'Daisy', 'Isbell', 'Female', 879852, -33.93274, 151.188577);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('dc1c4599-f668-4051-9126-f8afcbaa2dc4', 'prickarsey18@nih.gov', 'Pietra', 'Rickarsey', 'Female', 664445, 37.9440927, 139.3739616);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('9a565a61-6043-4817-913c-f658d2c589a6', 'elarrad19@yahoo.com', 'Eustace', 'Larrad', 'Agender', 60083, 40.8358295, 20.1089899);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('838c0ada-b778-4bfe-8c58-d266f54dd1bb', 'dhamel1a@instagram.com', 'Dew', 'Hamel', 'Bigender', 799560, 60.6302526, 28.7309501);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('2d055390-d164-44e7-a3ef-abab329a93de', 'ahaining1b@ow.ly', 'Aharon', 'Haining', 'Female', 637220, 32.2945837, -64.7858887);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('7d78fdf4-7b1c-4aca-b8ec-5fc7605a73c1', 'opendergast1c@mozilla.org', 'Olenolin', 'Pendergast', 'Genderqueer', 231049, 15.8359591, 104.4024704);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('1a66f7d8-ea70-4d92-8b2e-6fdd68c94eb6', 'adavidowsky1d@bloglovin.com', 'Alair', 'Davidowsky', 'Male', 588264, 35.202503, 102.521807);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('5a7bcb99-0ea3-414c-9997-70a2f2eb3da4', 'jgribben1e@imageshack.us', 'Job', 'Gribben', 'Bigender', 567148, 49.3055868, 18.0616373);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('a8e88dc4-8242-4c26-aaa8-aa4c0d9639e4', 'bdeclerc1f@geocities.com', 'Burr', 'de Clerc', 'Male', 159992, 55.85, 37.58333);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('9f691cac-34fd-4b3b-8d0d-2c62b0c3dafc', 'adandison1g@posterous.com', 'Aurea', 'Dandison', 'Polygender', 246676, 28.260141, 112.571923);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('4f63d313-7f01-4db5-8918-0a2bcffcec17', 'wmccullagh1h@privacy.gov.au', 'Wilek', 'McCullagh', 'Male', 39318, 36.307064, 120.39631);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('427c0af9-7280-4e21-b5d4-3b92686e5747', 'gjerson1i@qq.com', 'Giustino', 'Jerson', 'Male', 564925, 50.2014324, 14.8328189);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('d8545932-904f-430d-b7be-91f8175c8303', 'cbodley1j@merriam-webster.com', 'Clevey', 'Bodley', 'Female', 381522, 24.479833, 118.089425);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('fcffdcb8-1938-4846-a8d1-e882486b08f5', 'dhallowell1k@miibeian.gov.cn', 'Demetra', 'Hallowell', 'Bigender', 58801, 48.9802395, 2.612562);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('3384533b-b876-4d5e-900a-99fc8356a15a', 'afligg1l@github.io', 'Ana', 'Fligg', 'Non-binary', 947870, 30.845968, 104.408801);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('c767b001-e6ab-4622-8c52-3d0dea46ee79', 'cborgnet1m@netvibes.com', 'Cody', 'Borgnet', 'Female', 726312, 31.2579515, 120.2051096);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('5e8db269-3ad0-49a8-8e9e-7fadfe367761', 'jturtle1n@networksolutions.com', 'Jaime', 'Turtle', 'Non-binary', 349086, 28.739865, 106.720976);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('4fe629dc-af81-43fa-a902-88c49f3b93a3', 'larderne1o@netlog.com', 'Louie', 'Arderne', 'Bigender', 126779, 37.943121, 115.217658);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('478d9121-c31c-407c-8238-345d25e0928f', 'zyashaev1p@ucla.edu', 'Zachary', 'Yashaev', 'Male', 865292, 60.2057626, 24.9005746);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('148e579e-7d97-429d-9653-0e3770de7754', 'jmcinulty1q@cpanel.net', 'Jere', 'McInulty', 'Agender', 181290, 49.6705225, 13.3996389);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('3aa08acb-8515-4b1b-ba78-317f6c52223b', 'cfarnan1r@rakuten.co.jp', 'Cort', 'Farnan', 'Non-binary', 878817, 37.953529, 114.816881);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('30ef890c-35cd-45bb-9d73-3d9ce9c3751f', 'mlusty1s@meetup.com', 'Melitta', 'Lusty', 'Bigender', 34397, 30.3608801, 31.3793398);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('a4b322b4-4f04-48cf-bb8f-7826171fc232', 'gmangeon1t@senate.gov', 'Giovanni', 'Mangeon', 'Polygender', 833695, -6.8575149, 107.6422488);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('82d1f6fe-86ee-4539-a647-c945fff7863f', 'tbarfitt1u@t-online.de', 'Thaddus', 'Barfitt', 'Bigender', 718485, 30.42594, 111.76053);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('e6d0ca07-caa2-4999-876d-320dbb9c1a90', 'bsannes1v@cdc.gov', 'Bessy', 'Sannes', 'Polygender', 260398, 59.5891945, 16.5104253);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('be0f0c8c-5b05-441c-a8e4-537755067cf1', 'jhilliam1w@nifty.com', 'Jorey', 'Hilliam', 'Male', 697971, 42.43848, 70.4759186);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('a507da59-5285-4920-a4aa-800870f079c8', 'icockroft1x@bandcamp.com', 'Isidora', 'Cockroft', 'Female', 322603, 41.9208048, 41.9931328);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('1fed4dad-2a01-4431-aa27-100fe5c3902d', 'vchamberlayne1y@reference.com', 'Vivyanne', 'Chamberlayne', 'Agender', 870757, 31.6903638, -106.4245478);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('e203c202-f020-4e15-9436-7be222de7124', 'ekellough1z@cnet.com', 'Ernestus', 'Kellough', 'Agender', 983437, 30.0689467, 103.0991829);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('38b92cbe-ecf4-4ec4-b5c8-48ce017e29cb', 'msummerly20@berkeley.edu', 'Mechelle', 'Summerly', 'Genderfluid', 474008, -14.23792, -72.591949);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('1b1194fc-fde9-431b-a1de-29df2f7d6f30', 'whatter21@auda.org.au', 'Wright', 'Hatter', 'Bigender', 270390, -13.8474624, -172.0448001);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('02c719fe-cd8f-4db8-818f-8dd005d3c6df', 'hhartup22@quantcast.com', 'Hazel', 'Hartup', 'Genderfluid', 621193, 59.9399586, 10.7217496);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('76575612-f390-4d0c-a8e1-3e152b1f6cb2', 'edottridge23@independent.co.uk', 'Edmund', 'Dottridge', 'Bigender', 639963, 21.938596, 110.552977);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('75b2b612-f2df-4bce-bc9a-30438453f8e2', 'dheffernon24@ask.com', 'Dehlia', 'Heffernon', 'Genderqueer', 404402, 34.0577762, 131.6460781);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('b654c187-3b8a-4d59-b18b-da6a20c32482', 'lkeningham25@furl.net', 'Luisa', 'Keningham', 'Non-binary', 527346, -2.8670033, 30.5322273);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('e7ead097-ffc0-4eb3-9d53-0457a5b85d55', 'egery26@hatena.ne.jp', 'Ermentrude', 'Gery', 'Agender', 107499, 55.9576019, 36.2249059);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('e2f248e1-3a40-4124-93d8-a6a75262dfd4', 'mrumbold27@nydailynews.com', 'Meade', 'Rumbold', 'Non-binary', 925015, -7.6095457, 110.9655659);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('461244b9-e998-4f7e-8b86-7f77ba403bc3', 'dthomazet28@soundcloud.com', 'Deb', 'Thomazet', 'Female', 357512, 21.0598649, 105.4943648);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('754de818-096a-44a5-8c78-ec5a88493653', 'kkocher29@addtoany.com', 'Kai', 'Kocher', 'Genderfluid', 365937, 40.6180185, -8.7338528);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('a75ac747-56fa-47bf-9a6f-952339179483', 'bgoulden2a@cisco.com', 'Babita', 'Goulden', 'Bigender', 603836, 24.8805556, 102.4752778);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('63c04ae3-5e99-4727-a173-97176bd41ba9', 'twesthoff2b@cdc.gov', 'Terza', 'Westhoff', 'Genderfluid', 367914, -0.4359644, 30.5729962);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('e4d9737b-4734-4daf-9f48-fdef9b313e20', 'ddibbe2c@nationalgeographic.com', 'Dania', 'Dibbe', 'Female', 28868, 38.1553558, 140.2706039);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('754bfe15-29f2-46de-b4b5-768cc00c3a42', 'ctomenson2d@meetup.com', 'Carmel', 'Tomenson', 'Polygender', 134734, 45.5159664, -73.4049684);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('adff374f-a59e-4d11-aa89-7914165f89c1', 'mrefford2e@posterous.com', 'Morgen', 'Refford', 'Agender', 617707, -6.6063841, 106.7617984);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('8a48e412-3881-4ad4-adf9-e9420ee6dfd9', 'kmair2f@columbia.edu', 'Klara', 'Mair', 'Polygender', 371599, -20.488399, 27.8018337);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('a81af9e3-0418-4624-a71d-4d2550d0f75f', 'ajeune2g@livejournal.com', 'Alic', 'Jeune', 'Polygender', 490302, 11.0256293, 123.9064425);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('60c7ad1e-a2af-4fb4-b938-5b48ecd1c53c', 'bcrisp2h@typepad.com', 'Brittney', 'Crisp', 'Male', 810156, -20.6037462, -41.203524);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('01c85987-a28c-40b5-bd0b-9fc6ab902c2a', 'jstarte2i@seattletimes.com', 'Juliana', 'Starte', 'Non-binary', 852757, 43.6422125, -79.3744257);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('2ad6495a-5a24-48a8-af1a-f19740e388be', 'cknapper2j@ca.gov', 'Clary', 'Knapper', 'Non-binary', 567179, 8.9517713, -11.9783208);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('7d2d0211-3166-4c70-a8ce-a4ed4aea6c37', 'hwindibank2k@reference.com', 'Henri', 'Windibank', 'Male', 63523, 1.2730471, 124.7851264);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('47b331a6-cb2c-4608-82d2-3c6db2e4862b', 'wbendson2l@edublogs.org', 'Winston', 'Bendson', 'Polygender', 796148, 37.8334351, 23.802873);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('a49610ec-d4b0-4354-839e-42a870662e1d', 'cinkle2m@sogou.com', 'Cathrine', 'Inkle', 'Female', 280769, -7.5557614, 111.4469654);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('ff7d45bc-1132-4baa-bfc4-6653dd0cbf07', 'cschimank2n@hc360.com', 'Claudetta', 'Schimank', 'Genderfluid', 793450, 38.0426062, 23.7536323);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('7c52e215-26ee-436d-9d81-dc4a68987983', 'ctetla2o@nymag.com', 'Codie', 'Tetla', 'Polygender', 29537, 41.942393, 126.558573);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('38444c4a-9c06-4a64-b94c-24ab2ad3d648', 'tpossel2p@tamu.edu', 'Thomasina', 'Possel', 'Bigender', 313548, 30.911728, 119.552359);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('7f52bf12-74c2-4ddd-9ea0-06fedd2790fb', 'rlegging2q@blogger.com', 'Roseann', 'Legging', 'Bigender', 220842, 46.0952765, -64.7486638);
insert into client (customer_id, email_address, first_name, last_name, gender, income, latitude, longitude) values ('8bafc7a4-6f02-44b0-a229-7816f1ae15ca', 'hworsnap2r@newyorker.com', 'Hew', 'Worsnap', 'Bigender', 334166, 37.032706, 80.3411123);

insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Tennessee Valley Authority', 'TVE', 'NYSE', 'Public Utilities', 'n/a', 'Electric Utilities: Central');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Columbia Sportswear Company', 'COLM', 'NASDAQ', 'Consumer Non-Durables', '$3.94B', 'Apparel');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('iShares MSCI Europe Small-Cap ETF', 'IEUS', 'NASDAQ', 'n/a', '$126.72M', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('LSI Industries Inc.', 'LYTS', 'NASDAQ', 'Consumer Durables', '$230.63M', 'Building Products');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Ivy NextShares', 'IVFVC', 'NASDAQ', 'n/a', 'n/a', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('THL Credit, Inc.', 'TCRZ', 'NYSE', 'n/a', 'n/a', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Tesoro Corporation', 'TSO', 'NYSE', 'Energy', '$14.78B', 'Integrated oil Companies');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('American Water Works', 'AWK', 'NYSE', 'Public Utilities', '$14.72B', 'Water Supply');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Spectra Energy Partners, LP', 'SEP', 'NYSE', 'Public Utilities', '$13.13B', 'Natural Gas Distribution');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Comtech Telecommunications Corp.', 'CMTL', 'NASDAQ', 'Technology', '$448.07M', 'Radio And Television Broadcasting And Communications Equipment');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Research Frontiers Incorporated', 'REFR', 'NASDAQ', 'Miscellaneous', '$32.7M', 'Multi-Sector Companies');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('NextEra Energy, Inc.', 'NEE^J', 'NYSE', 'n/a', 'n/a', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Oasmia Pharmaceutical AB', 'OASM', 'NASDAQ', 'Health Care', '$38.24M', 'Major Pharmaceuticals');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Innodata Inc.', 'INOD', 'NASDAQ', 'Technology', '$41.4M', 'EDP Services');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Federal Realty Investment Trust', 'FRT', 'NYSE', 'Consumer Services', '$9.06B', 'Real Estate Investment Trusts');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Vital Therapies, Inc.', 'VTL', 'NASDAQ', 'Health Care', '$122.4M', 'Major Pharmaceuticals');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Lincoln National Corporation', 'LNC', 'NYSE', 'Finance', '$15.26B', 'Life Insurance');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('First Cash, Inc.', 'FCFS', 'NYSE', 'Consumer Services', '$2.69B', 'Other Specialty Stores');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Medley Management Inc.', 'MDLY', 'NYSE', 'Finance', '$176.73M', 'Investment Managers');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Epizyme, Inc.', 'EPZM', 'NASDAQ', 'Health Care', '$796.59M', 'Major Pharmaceuticals');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('WhiteHorse Finance, Inc.', 'WHFBL', 'NASDAQ', 'n/a', 'n/a', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Quest Resource Holding Corporation.', 'QRHC', 'NASDAQ', 'Technology', '$38.18M', 'Diversified Commercial Services');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Foresight Autonomous Holdings Ltd.', 'FRSX', 'NASDAQ', 'n/a', 'n/a', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Zillow Group, Inc.', 'Z', 'NASDAQ', 'Miscellaneous', '$8.4B', 'Business Services');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Shiloh Industries, Inc.', 'SHLO', 'NASDAQ', 'Capital Goods', '$243.62M', 'Industrial Specialties');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Fairmount Santrol Holdings Inc.', 'FMSA', 'NYSE', 'Basic Industries', '$882.34M', 'Mining & Quarrying of Nonmetallic Minerals (No Fuels)');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Meridian Bioscience Inc.', 'VIVO', 'NASDAQ', 'Health Care', '$654.14M', 'Biotechnology: In Vitro & In Vivo Diagnostic Substances');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Cambrex Corporation', 'CBM', 'NYSE', 'Health Care', '$1.87B', 'Major Pharmaceuticals');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Compania Cervecerias Unidas, S.A.', 'CCU', 'NYSE', 'Consumer Non-Durables', '$4.88B', 'Beverages (Production/Distribution)');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Genpact Limited', 'G', 'NYSE', 'Consumer Services', '$5.21B', 'Professional Services');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Acacia Research Corporation', 'ACTG', 'NASDAQ', 'Miscellaneous', '$192.23M', 'Multi-Sector Companies');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Open Text Corporation', 'OTEX', 'NASDAQ', 'Technology', '$8.28B', 'EDP Services');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Community West Bancshares', 'CWBC', 'NASDAQ', 'Finance', '$81.44M', 'Major Banks');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Callon Petroleum Company', 'CPE^A', 'NYSE', 'Energy', 'n/a', 'Oil & Gas Production');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('American Equity Investment Life Holding Company', 'AEL', 'NYSE', 'Finance', '$2.22B', 'Life Insurance');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Saratoga Investment Corp', 'SAB', 'NYSE', 'n/a', 'n/a', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('AG Mortgage Investment Trust, Inc.', 'MITT^A', 'NYSE', 'n/a', 'n/a', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Maiden Holdings, Ltd.', 'MHLD', 'NASDAQ', 'Finance', '$982.38M', 'Property-Casualty Insurers');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('CRISPR Therapeutics AG', 'CRSP', 'NASDAQ', 'Health Care', '$592.36M', 'Biotechnology: Biological Products (No Diagnostic Substances)');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Educational Development Corporation', 'EDUC', 'NASDAQ', 'Consumer Durables', '$42.15M', 'Consumer Specialties');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Endurance International Group Holdings, Inc.', 'EIGI', 'NASDAQ', 'Technology', '$1.21B', 'Computer Software: Prepackaged Software');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Eaton Vance Tax Advantaged Dividend Income Fund', 'EVT', 'NYSE', 'n/a', '$1.6B', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('DarioHealth Corp.', 'DRIOW', 'NASDAQ', 'Health Care', 'n/a', 'Medical/Dental Instruments');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Legg Mason, Inc.', 'LMHA', 'NYSE', 'Finance', 'n/a', 'Investment Managers');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('CU Bancorp (CA)', 'CUNB', 'NASDAQ', 'Finance', '$658.05M', 'Major Banks');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Analog Devices, Inc.', 'ADI', 'NASDAQ', 'Technology', '$29.38B', 'Semiconductors');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Arbor Realty Trust', 'ABR^B', 'NYSE', 'n/a', 'n/a', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Quidel Corporation', 'QDEL', 'NASDAQ', 'Health Care', '$854.72M', 'Biotechnology: In Vitro & In Vivo Diagnostic Substances');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Polar Power, Inc.', 'POLA', 'NASDAQ', 'n/a', '$47.06M', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Guangshen Railway Company Limited', 'GSH', 'NYSE', 'Transportation', '$3.68B', 'Railroads');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('ENSCO plc', 'ESV', 'NYSE', 'Energy', '$1.74B', 'Oil & Gas Production');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Citi Trends, Inc.', 'CTRN', 'NASDAQ', 'Consumer Services', '$303.43M', 'Clothing/Shoe/Accessory Stores');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Alibaba Group Holding Limited', 'BABA', 'NYSE', 'Miscellaneous', '$341.22B', 'Business Services');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Ferroglobe PLC', 'GSM', 'NASDAQ', 'Capital Goods', '$1.8B', 'Metal Fabrications');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('SLM Corporation', 'SLMBP', 'NASDAQ', 'Finance', '$289.76M', 'Finance: Consumer Services');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Veritex Holdings, Inc.', 'VBTX', 'NASDAQ', 'Finance', '$425.82M', 'Major Banks');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('HP Inc.', 'HPQ', 'NYSE', 'Technology', '$29.21B', 'Computer Manufacturing');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('W.R. Grace & Co.', 'GRA', 'NYSE', 'Basic Industries', '$4.82B', 'Major Chemicals');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Electrum Special Acquisition Corporation', 'ELECW', 'NASDAQ', 'Finance', 'n/a', 'Business Services');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Torchmark Corporation', 'TMK', 'NYSE', 'Finance', '$9.04B', 'Life Insurance');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('ORBCOMM Inc.', 'ORBC', 'NASDAQ', 'Consumer Services', '$789.19M', 'Telecommunications Equipment');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Cerecor Inc.', 'CERC', 'NASDAQ', 'Health Care', '$7.18M', 'Major Pharmaceuticals');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Bill Barrett Corporation', 'BBG', 'NYSE', 'Energy', '$252.54M', 'Oil & Gas Production');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Molson Coors Brewing  Company', 'TAP', 'NYSE', 'Consumer Non-Durables', '$14.14B', 'Beverages (Production/Distribution)');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('ConAgra Brands, Inc.', 'CAG', 'NYSE', 'Consumer Non-Durables', '$16.17B', 'Packaged Foods');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Ability Inc.', 'ABIL', 'NASDAQ', 'Finance', '$31.94M', 'Business Services');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Teck Resources Ltd', 'TECK', 'NYSE', 'Basic Industries', '$8.51B', 'Mining & Quarrying of Nonmetallic Minerals (No Fuels)');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Enbridge Energy, L.P.', 'EEP', 'NYSE', 'Energy', '$6.76B', 'Natural Gas Distribution');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Pingtan Marine Enterprise Ltd.', 'PME', 'NASDAQ', 'n/a', '$287.76M', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Brookfield Business Partners L.P.', 'BBU', 'NYSE', 'Basic Industries', '$1.4B', 'Engineering & Construction');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Impax Laboratories, Inc.', 'IPXL', 'NASDAQ', 'Health Care', '$1.02B', 'Major Pharmaceuticals');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Golub Capital BDC, Inc.', 'GBDC', 'NASDAQ', 'n/a', '$1.11B', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Equity Commonwealth', 'EQCO', 'NYSE', 'Consumer Services', 'n/a', 'Real Estate Investment Trusts');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Berkshire Hathaway Inc.', 'BRK.A', 'NYSE', 'n/a', 'n/a', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Trimble Inc.', 'TRMB', 'NASDAQ', 'Capital Goods', '$9.26B', 'Industrial Machinery/Components');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('VictoryShares US Small Cap High Div Volatility Wtd ETF', 'CSB', 'NASDAQ', 'n/a', 'n/a', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Navistar International Corporation', 'NAV^D', 'NYSE', 'Capital Goods', 'n/a', 'Auto Manufacturing');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Saul Centers, Inc.', 'BFS^C', 'NYSE', 'n/a', 'n/a', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('58.com Inc.', 'WUBA', 'NYSE', 'Technology', '$5.96B', 'Computer Software: Programming, Data Processing');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Monroe Capital Corporation', 'MRCC', 'NASDAQ', 'n/a', '$253.51M', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Pacira Pharmaceuticals, Inc.', 'PCRX', 'NASDAQ', 'Health Care', '$1.7B', 'Major Pharmaceuticals');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('KCAP Financial, Inc.', 'KAP', 'NYSE', 'n/a', 'n/a', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('AlphaMark Actively Managed Small Cap ETF', 'SMCP', 'NASDAQ', 'n/a', '$26.26M', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Southside Bancshares, Inc.', 'SBSI', 'NASDAQ', 'Finance', '$1.02B', 'Major Banks');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Kennedy-Wilson Holdings Inc.', 'KW', 'NYSE', 'Finance', '$2.07B', 'Real Estate');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Liberty Media Corporation', 'BATRA', 'NASDAQ', 'Consumer Services', 'n/a', 'Broadcasting');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Templeton Global Income Fund, Inc.', 'GIM', 'NYSE', 'n/a', '$896.08M', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('PDC Energy, Inc.', 'PDCE', 'NASDAQ', 'Energy', '$3B', 'Oil & Gas Production');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Minerva Neurosciences, Inc', 'NERV', 'NASDAQ', 'Health Care', '$356.04M', 'Major Pharmaceuticals');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Ceragon Networks Ltd.', 'CRNT', 'NASDAQ', 'Technology', '$197.71M', 'Radio And Television Broadcasting And Communications Equipment');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('CytomX Therapeutics, Inc.', 'CTMX', 'NASDAQ', 'Health Care', '$499.8M', 'Major Pharmaceuticals');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Service Corporation International', 'SCI', 'NYSE', 'Consumer Services', '$6.05B', 'Other Consumer Services');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('LightInTheBox Holding Co., Ltd.', 'LITB', 'NYSE', 'Consumer Services', '$170.21M', 'Catalog/Specialty Distribution');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Bio-Techne Corp', 'TECH', 'NASDAQ', 'Health Care', '$4.17B', 'Biotechnology: Biological Products (No Diagnostic Substances)');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Value Line, Inc.', 'VALU', 'NASDAQ', 'Finance', '$176.62M', 'Investment Managers');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Rocket Fuel Inc.', 'FUEL', 'NASDAQ', 'Technology', '$128.18M', 'Computer Software: Programming, Data Processing');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Ellington Residential Mortgage REIT', 'EARN', 'NYSE', 'Consumer Services', '$140.16M', 'Real Estate Investment Trusts');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Gabelli Equity Trust, Inc. (The)', 'GAB^J', 'NYSE', 'n/a', 'n/a', 'n/a');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('Hardinge Inc.', 'HDNG', 'NASDAQ', 'Capital Goods', '$162.72M', 'Industrial Machinery/Components');
insert into ticker (stock_name, ticker, market, sector, market_cap, industry) values ('O2Micro International Limited', 'OIIM', 'NASDAQ', 'Technology', '$47.92M', 'Semiconductors');



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO client_ticker 
SELECT * FROM (SELECT customer_id, stock_name, ticker,
NOW() - (random()*10 * (interval '365 days'))  AS created_at,
floor(random()*9999999)/100 AS total_purchased
FROM client, ticker)
ORDER BY random()
LIMIT 1000;