/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/
/* Student Number : A0124216U                                           */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The code is written for PostgreSQL version 13.

The example in this is about offenders who are in or had been in prison, 
and the offences they committed that resulted in prison time.

The first table, PrisonersTable, contains the information of prison inmates such as their identication 
number (IC), first name (IC), last name (IC), their start (Start_Date) and expected release 
date (Expected_Release_Date) in prison, the prison the prisoner is in (Prison), the street the prison is 
on (Prison_Address), and the case id (case_id). The case id is the foreign key identifer that will link to a 
separate table contain the list of offence related to the case ID. The primary key for this table is case_id, 
as each unique case id pertains to a prisoner and why that prisoner is in prison. There may be multiple entries 
of the same IC, since they might be repeated offenders. In addition, the expected release date and start date 
is checked to ensure that start date is always before expected end date.

The second table, OffenceTable, contains the different types of offences (Offence_Type), 
the unique id of offence (Offence_Id), the specific offence act (Offence_Act), the jail term (Jail_Term) 
and fine amount (Fine_Amount) from commiting the offence. The primary key is the Offence_Type and Offence_Act,
and the Offence_Id is unique, since it is generated from the Offence_Type and Offence_Act.

The third table, CaseTable, contains the case id (Case_ID) and the offences (Offence_Type, Offence_Act)
committed in the case.  There are no primary and unique key as each case may have multiple offences committed. 
If the case is deleted or updated in PrisonersTable, then there is no reason for the cases inside the table
to stay, since these could mean that the records of the prisoner being in prison is expunge, hence so will
the case and offences recorded in CaseTable
*/

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/*PrisonersTable*/
create table PrisonersTable (
	IC VARCHAR(99) NOT NULL,
	First_Name VARCHAR(99) NOT NULL,
	Last_Name VARCHAR(99) NOT NULL,
	Start_Date DATE NOT NULL,
	Expected_Release_Date DATE NOT NULL,
	Prison VARCHAR(99) NOT NULL,
	Prison_Address VARCHAR(99) NOT NULL,
	Case_Id VARCHAR(99) PRIMARY KEY NOT NULL,
	CHECK(Expected_Release_Date >= Start_Date)
);

/*OffenceTable*/
CREATE TABLE IF NOT EXISTS OffenceTable(
	Offence_Id   VARCHAR(99) UNIQUE NOT NULL,
  	Offence_Type VARCHAR(130) NOT NULL,
  	Offence_Act  VARCHAR(99) NOT NULL,
  	Jail_Term    INTEGER  NOT NULL,
  	Fine_Amount  DECIMAL NOT NULL,
  	PRIMARY KEY (Offence_Type,Offence_Act)
);

/*CaseTable*/
CREATE TABLE IF NOT EXISTS CaseTable(
	Case_Id VARCHAR(99) NOT NULL references PrisonersTable(Case_Id)
		on update cascade
		on delete cascade,
  	Offence_Type VARCHAR(130) NOT NULL,
  	Offence_Act  VARCHAR(99) NOT NULL
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/*PrisonersTable*/
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('227601800-3', 'Edita', 'Acklands', '2021-04-02', '2023-03-03', 'Maryland Prison', '599 Golf View Drive', '729-26-2847');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('383903305-5', 'Isidoro', 'Ballham', '2021-07-15', '2022-10-10', 'Tennessee Prison', '49182 Eastlawn Pass', '785-80-5084');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('310738504-2', 'Gris', 'Huncoot', '2021-06-14', '2022-02-07', 'Michigan Prison', '53298 Thompson Parkway', '370-04-8744');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('452734649-0', 'Althea', 'Wimmer', '2021-04-27', '2022-01-16', 'Texas Prison', '72235 Hanson Trail', '184-89-5289');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('158185715-2', 'Harmonia', 'Brakewell', '2021-02-08', '2024-01-26', 'Pennsylvania Prison', '1864 Milwaukee Place', '898-21-1485');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('122758738-4', 'Madelon', 'Pharrow', '2020-08-03', '2021-11-14', 'Illinois Prison', '78 Hoffman Place', '491-58-1646');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('019312543-9', 'Vasili', 'Setterington', '2021-06-14', '2022-01-20', 'Oklahoma Prison', '9 Grayhawk Court', '268-27-8682');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('707491505-X', 'Lucio', 'Blencoe', '2020-10-27', '2022-08-29', 'Missouri Prison', '0 2nd Terrace', '455-34-1040');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('539865110-2', 'Chaddie', 'Leguay', '2021-01-08', '2023-05-02', 'California Prison', '9 Marquette Road', '849-35-1946');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('389032066-X', 'Marlyn', 'Abdey', '2021-08-13', '2023-11-27', 'South Carolina Prison', '7030 Leroy Hill', '701-71-4015');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('026272753-6', 'Lief', 'Parlett', '2021-05-23', '2023-12-20', 'Florida Prison', '82600 Warbler Park', '207-41-9755');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('637837440-6', 'Zitella', 'Spoor', '2020-12-13', '2023-04-18', 'Nevada Prison', '35765 Trailsway Crossing', '810-22-3418');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('100312533-6', 'Kipper', 'Ughi', '2021-07-18', '2023-06-12', 'Arkansas Prison', '089 Twin Pines Alley', '717-69-2111');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('729543062-8', 'See', 'Creyke', '2021-04-19', '2022-02-06', 'Louisiana Prison', '2504 Brown Park', '417-06-1779');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('971852330-8', 'Alonzo', 'Derricoat', '2021-04-10', '2023-07-16', 'California Prison', '44 Rutledge Way', '483-99-3661');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('400130387-6', 'Donall', 'MacElroy', '2021-08-02', '2022-06-07', 'Iowa Prison', '73 Manitowish Hill', '707-66-0365');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('565849702-7', 'Jeth', 'Purver', '2021-01-16', '2023-03-13', 'Illinois Prison', '24843 La Follette Junction', '846-72-4730');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('061650317-2', 'Cary', 'Tocqueville', '2021-01-08', '2022-01-05', 'California Prison', '97404 Buell Hill', '351-28-9937');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('209444523-2', 'Darice', 'Krabbe', '2021-07-24', '2023-01-25', 'Texas Prison', '05 Hanover Alley', '543-86-4741');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('990388577-6', 'Colly', 'McGrowther', '2020-08-10', '2022-01-25', 'Texas Prison', '518 Boyd Trail', '585-74-0339');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('573455426-X', 'Enos', 'Tumility', '2021-06-05', '2023-07-30', 'Georgia Prison', '17542 Melvin Crossing', '402-83-5471');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('892140629-8', 'Gusti', 'Packman', '2021-08-03', '2023-11-27', 'New York Prison', '9 Acker Junction', '550-29-6436');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('190097068-6', 'Junia', 'Bondley', '2020-10-04', '2022-05-26', 'New York Prison', '810 Sutteridge Way', '469-50-0742');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('235829459-4', 'Emmy', 'Smithe', '2021-02-22', '2023-10-16', 'Georgia Prison', '83059 Mallard Court', '288-34-4560');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('332393242-0', 'Teri', 'Tuck', '2021-07-09', '2022-05-20', 'Colorado Prison', '6807 Riverside Street', '179-13-5373');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('009602661-8', 'Alexandre', 'Ullett', '2021-07-06', '2022-10-29', 'Arkansas Prison', '53049 Kipling Plaza', '779-44-5086');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('610995018-1', 'Dalia', 'Errigo', '2020-09-07', '2022-11-16', 'New Mexico Prison', '8 Lotheville Crossing', '864-13-7412');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('116323309-9', 'Emogene', 'Housaman', '2020-12-28', '2022-05-13', 'Connecticut Prison', '9239 Sutteridge Way', '443-63-5307');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('616073638-8', 'Stephannie', 'Ricci', '2021-08-13', '2023-12-01', 'Wisconsin Prison', '9962 Esch Circle', '219-17-4581');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('030213795-5', 'Lock', 'Meneghi', '2021-02-08', '2022-07-16', 'Kentucky Prison', '226 Melrose Road', '370-27-0299');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('409853498-3', 'Mead', 'Gretton', '2021-03-01', '2021-09-04', 'Georgia Prison', '936 John Wall Point', '886-17-9690');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('933473246-6', 'Ellary', 'Redparth', '2020-10-14', '2022-09-26', 'Texas Prison', '83068 Manufacturers Junction', '890-71-8057');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('628249410-9', 'Skippie', 'Maseyk', '2021-03-27', '2022-12-24', 'Ohio Prison', '1321 Sherman Parkway', '528-55-2278');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('955999714-9', 'Tanner', 'Lound', '2021-07-23', '2023-11-23', 'District of Columbia Prison', '26 Caliangt Pass', '488-83-2806');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('273581281-2', 'Jonis', 'Fere', '2020-11-13', '2022-07-23', 'Colorado Prison', '71 Bartelt Circle', '499-21-8654');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('514956653-5', 'Harp', 'Burhill', '2021-08-04', '2022-08-30', 'Texas Prison', '8359 Bonner Avenue', '512-07-4916');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('664687763-7', 'Ches', 'Bewley', '2020-10-19', '2021-12-26', 'Alabama Prison', '6638 Beilfuss Crossing', '567-25-3758');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('961639737-0', 'Ilyssa', 'Twinberrow', '2020-11-17', '2023-01-15', 'Kansas Prison', '478 Little Fleur Park', '869-74-3328');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('622229237-2', 'Phillida', 'Whatman', '2021-05-31', '2023-02-24', 'Ohio Prison', '5 Logan Avenue', '767-35-4033');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('005346428-1', 'Tome', 'Gladding', '2021-06-11', '2022-02-01', 'Washington Prison', '5241 Ridgeway Court', '123-93-2242');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('857663905-X', 'Ronnica', 'Nibley', '2020-10-28', '2023-06-24', 'Virginia Prison', '55 Westerfield Parkway', '814-17-8749');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('305291535-5', 'Gerrie', 'Andreaccio', '2021-01-12', '2022-09-18', 'Texas Prison', '420 Bluestem Center', '629-54-4510');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('517332887-8', 'Sadye', 'Huntall', '2020-12-12', '2022-08-31', 'Wisconsin Prison', '4092 Bowman Plaza', '456-82-5525');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('692653144-7', 'Elsie', 'Bortolazzi', '2021-07-14', '2023-11-02', 'Texas Prison', '26 Farmco Road', '283-35-9962');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('855532967-1', 'Karoly', 'Cavolini', '2021-01-05', '2022-10-21', 'Florida Prison', '23591 Carioca Trail', '113-63-2230');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('379619636-5', 'Courtney', 'Norgate', '2020-10-07', '2023-08-01', 'Ohio Prison', '7 Calypso Avenue', '358-05-2897');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('981371442-5', 'Marge', 'Seaking', '2021-02-25', '2021-11-20', 'California Prison', '2336 Browning Pass', '680-03-2158');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('428315748-1', 'Roderich', 'Wormstone', '2021-01-08', '2022-05-02', 'Texas Prison', '4 Bartillon Way', '502-98-0629');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('824244359-9', 'Gunilla', 'Connold', '2020-09-18', '2023-12-31', 'North Carolina Prison', '17 Kensington Circle', '166-56-0877');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('097765865-1', 'Hugues', 'Tomaszynski', '2020-10-09', '2023-10-22', 'Florida Prison', '12786 Union Lane', '553-84-4235');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('507498731-8', 'Arni', 'Pharaoh', '2021-07-08', '2024-03-16', 'North Carolina Prison', '7973 Badeau Pass', '176-66-2227');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('348190847-4', 'Clem', 'Bohman', '2021-04-16', '2021-10-19', 'Texas Prison', '5368 Esch Street', '648-38-9364');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('494163936-7', 'Merry', 'Danelet', '2021-08-17', '2022-01-20', 'South Carolina Prison', '545 Raven Junction', '145-63-0047');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('174909488-6', 'Giacinta', 'Mifflin', '2021-07-27', '2022-03-30', 'Delaware Prison', '10 Rockefeller Park', '657-44-3885');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('146847286-0', 'Kelvin', 'Bilby', '2021-03-11', '2023-09-14', 'Pennsylvania Prison', '13 Dorton Crossing', '421-30-2076');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('249264933-4', 'Milton', 'Paynes', '2020-10-03', '2023-11-05', 'New York Prison', '1799 Cardinal Point', '765-67-5053');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('318629367-7', 'Hedi', 'Glison', '2020-11-28', '2023-06-28', 'Indiana Prison', '8 Katie Pass', '625-89-4874');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('880813413-X', 'Cesya', 'Rottgers', '2021-03-11', '2023-11-24', 'Nevada Prison', '7 Corben Drive', '558-26-8293');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('478002063-8', 'Simonne', 'Elwin', '2021-02-19', '2024-01-24', 'Texas Prison', '555 Merrick Trail', '787-60-2285');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('200062079-5', 'Sullivan', 'Wynne', '2021-04-27', '2023-12-10', 'California Prison', '3818 Brentwood Way', '686-74-9548');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('435791571-6', 'Sophie', 'Duckinfield', '2020-12-15', '2022-01-07', 'Georgia Prison', '61 Oriole Center', '491-63-6426');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('340162857-7', 'Rebeca', 'Ealles', '2021-07-24', '2022-10-14', 'Texas Prison', '53 Vahlen Street', '481-25-9382');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('326354197-8', 'Demetria', 'Kendell', '2021-06-11', '2023-08-22', 'Texas Prison', '616 Schiller Way', '698-35-6159');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('040972285-5', 'Kaspar', 'Strettle', '2021-01-18', '2023-06-16', 'Oregon Prison', '9423 Rieder Alley', '651-66-8483');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('394286908-X', 'Jilli', 'Goor', '2020-12-30', '2022-12-30', 'Louisiana Prison', '9 Sunnyside Center', '624-25-0370');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('530589184-1', 'Fernanda', 'Clayfield', '2020-08-26', '2024-03-04', 'North Carolina Prison', '838 Mitchell Parkway', '365-19-3033');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('777886439-8', 'Jasen', 'Strivens', '2020-09-10', '2021-10-17', 'Oklahoma Prison', '02822 Algoma Drive', '477-77-3897');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('878913427-3', 'Dud', 'Bloxam', '2020-08-25', '2024-03-02', 'Pennsylvania Prison', '9903 Coleman Court', '457-53-7992');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('416458722-9', 'Dulcie', 'Raittie', '2020-09-14', '2022-02-11', 'Florida Prison', '6790 Clemons Place', '696-32-5614');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('269986096-4', 'Gilberte', 'Rhodef', '2021-03-20', '2023-08-08', 'Ohio Prison', '66 Crescent Oaks Park', '263-05-8800');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('639895472-6', 'Carr', 'Andor', '2021-01-17', '2021-10-30', 'Texas Prison', '446 Norway Maple Way', '304-54-7702');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('156607487-8', 'Agatha', 'Chiechio', '2021-08-02', '2023-09-29', 'Kentucky Prison', '1666 Graceland Crossing', '271-38-1285');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('782577858-8', 'Emmy', 'Whitby', '2020-11-01', '2023-12-25', 'Maryland Prison', '998 5th Parkway', '603-97-1646');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('664255009-9', 'Cory', 'Conlon', '2021-04-11', '2023-03-19', 'Michigan Prison', '155 Rieder Hill', '155-95-0990');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('140054342-8', 'Darya', 'Callard', '2020-11-08', '2021-12-16', 'North Carolina Prison', '4 Artisan Court', '217-88-4072');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('934477388-2', 'Carmelina', 'Cavill', '2021-04-03', '2022-06-13', 'Texas Prison', '0287 Westend Junction', '558-83-7422');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('341069765-9', 'Erica', 'Firmager', '2021-01-21', '2023-04-05', 'Colorado Prison', '76096 Everett Center', '400-70-5560');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('614233689-6', 'Nicolea', 'Hollingsbee', '2021-02-18', '2022-08-26', 'Alabama Prison', '8 Superior Parkway', '319-77-7380');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('629104718-7', 'Sinclare', 'Langan', '2021-04-07', '2022-07-26', 'Virginia Prison', '1208 Marcy Plaza', '395-65-7515');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('309836151-4', 'Quincey', 'Mariault', '2021-04-26', '2022-11-18', 'Kansas Prison', '58 Service Place', '107-47-1676');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('357685503-3', 'Con', 'Lauritsen', '2020-08-12', '2022-07-07', 'California Prison', '42 Service Place', '845-18-7545');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('609042946-5', 'Rusty', 'Wyrall', '2021-04-28', '2021-12-29', 'Illinois Prison', '51225 Hayes Lane', '556-73-6780');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('010717785-4', 'Roby', 'Jehu', '2020-08-13', '2021-12-06', 'Ohio Prison', '1175 Elka Crossing', '132-48-4652');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('991540090-X', 'Tiffanie', 'Sawfoot', '2021-04-13', '2023-04-27', 'Texas Prison', '789 Farwell Pass', '566-01-3619');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('219360391-X', 'Burke', 'Baudesson', '2020-11-01', '2022-05-01', 'Nebraska Prison', '607 Oriole Pass', '157-93-2898');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('293299666-5', 'Othelia', 'Reedman', '2020-10-03', '2024-01-17', 'New York Prison', '19604 Browning Point', '743-14-1327');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('523068443-7', 'Cordi', 'O'' Neligan', '2021-03-25', '2021-12-05', 'Arizona Prison', '6255 Leroy Circle', '452-23-2881');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('851759858-X', 'Michel', 'Ayliff', '2021-08-15', '2023-04-27', 'Washington Prison', '1188 Myrtle Plaza', '700-20-7376');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('623957117-2', 'Suzy', 'Flintiff', '2021-01-07', '2021-10-03', 'Kentucky Prison', '13887 Harper Circle', '309-73-9481');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('981742439-1', 'Riordan', 'Dowsing', '2021-08-07', '2021-11-04', 'South Carolina Prison', '52619 Kings Crossing', '374-29-6037');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('424039477-5', 'Benjie', 'Baptiste', '2020-09-29', '2022-12-20', 'Florida Prison', '6 Swallow Place', '242-40-3961');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('704352976-X', 'Deane', 'Redsell', '2020-12-13', '2023-04-04', 'Texas Prison', '00 Hansons Drive', '745-68-4248');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('706049932-6', 'Rhea', 'Castellan', '2020-12-09', '2023-09-17', 'Georgia Prison', '68989 Esch Circle', '578-24-8781');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('037333430-3', 'Chiquia', 'Norcliff', '2020-08-01', '2021-12-29', 'Michigan Prison', '7 Manitowish Way', '567-61-3671');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('982123044-X', 'Charmine', 'Angell', '2020-11-28', '2024-03-09', 'Wisconsin Prison', '9 Magdeline Circle', '377-02-2946');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('530159259-9', 'Ilse', 'Didsbury', '2021-06-01', '2022-12-23', 'Georgia Prison', '6 Old Gate Crossing', '734-81-6048');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('829724304-4', 'Brade', 'MacFaell', '2021-07-09', '2022-09-24', 'Georgia Prison', '14 Prairie Rose Circle', '516-71-7116');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('060983100-3', 'Erica', 'Braga', '2021-05-01', '2022-05-16', 'Oregon Prison', '419 Crowley Plaza', '353-66-1241');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('346655245-1', 'Katinka', 'Zoellner', '2021-02-28', '2022-07-12', 'North Carolina Prison', '7 Lunder Trail', '885-85-2907');
insert into PrisonersTable (IC, First_Name, Last_Name, Start_Date, Expected_Release_Date, Prison, Prison_Address, Case_Id) values ('318981007-9', 'Odessa', 'Cleynman', '2021-04-26', '2023-05-19', 'Florida Prison', '4 Emmet Way', '441-62-0229');

/*OffenceTable*/
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('d49ccf0e-b32c-4b18-87cb-c34070123d35','Murder','Common Law',42,54940.11);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('1abc3e76-e511-4009-a76a-d19c37c3c087','Manslaughter','Common Law',15,47712.68);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('e0002018-d16e-41e3-9615-826466a3013f','Infanticide','Common Law',4,71774.63);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('cd9d80a2-27cd-47ad-8958-abd0975cb451','Kidnapping','Common Law',33,34224.29);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('781fef9d-3b9c-4423-9d7a-d3929802fe91','False Imprisonment','Common Law',45,91470.93);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('183ae587-7d5a-4c77-aff8-18b89318e8cf','Assault or battery','Common Law',38,14611.82);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('781c6cce-7be8-4bac-b257-a5b549b5752b','Indecent exposure','Section 4',36,93196.52);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('29844d4e-efba-4ad6-9673-476d963f5953','Indecent exposure','Section 28',42,69074.98);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('5df9fd62-3215-41f6-8d90-14195cc710d9','Conspiring or soliciting to commit murder','Section 4',46,74633.27);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('cc3e08e0-c2ff-4d10-b6e7-e75f4b8eb667','Administering poison, or wounding, with intent to murder','Section 11',6,42725.09);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('2bed3b1e-2dc0-4dd6-9c98-cadf7a5f1ca0','Threats to kill','Section 16',50,96826.63);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('a75c8eff-66e9-4a15-8405-f42763cbbdea','Wounding and causing grievous bodily harm: Wounding with intent','Section 18',9,37536.29);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('9433a5a4-b836-45ee-a03c-284c219c91fd','Wounding and causing grievous bodily harm: Inflicting bodily injury','Section 20',10,66233.1);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('7cf2868a-0859-4514-87fd-810a20097809','Maliciously administering poison','Section 23',37,39182.41);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('4b0de29f-355a-44b4-8993-63cc11e99605','Abandonment of children under two','Section 27',48,2407.27);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('c663db7b-0925-4815-9496-21681ff8d7a8','Assault occasioning actual bodily harm','Section 47',33,20656.13);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('16427e54-5da8-4178-8992-edea539f14dd','Child stealing','Section 56',17,74707.47);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('d8332749-ed55-45a3-a45a-a0b3a649d301','Drunk in charge of a child under 7 years','Section 2',18,99731.61);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('d73f8805-55a1-4e3f-a6e4-7289a068735a','Cruelty to children','Section 1',32,5469.4);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('63e6ce81-4292-403c-b345-7f48df65c35d','Allowing persons under 16 to be in brothels','Section 3',27,79382.28);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('d0929a30-951b-4890-ab69-3fe8d64af3e3','Causing or allowing persons under 16 to be used for begging','Section 4',44,23941.5);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('f7a58f35-6c82-4486-9e6c-db5fea173c00','Give / cause to be given intoxicating liquor to a child under 5 years','Section 5',46,32255.04);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('5e861afb-cec1-48ae-8334-1a51acdf4471','Exposing children under seven to risk of burning','Section 11',1,48274.95);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('29fa1800-02cd-4239-9b84-e4eded619356','Prohibition against persons under 16 taking part in performances endangering life and limb','Section 23',44,84418.57);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('c6ed4f8e-e786-4a62-9799-c1dec14425dc','Infanticide','Section 1',33,9690.77);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('d8643789-e348-460d-a53e-ce763d982cb3','Rape','Section 1',28,50820.16);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('d5c37109-e003-401c-a429-a379c7684696','Procurement of a woman by threats','Section 2',25,28307.99);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('cb4c702f-bf4d-4355-b25a-5c5ca83d2f71','Procurement of a woman by false pretences','Section 3',36,89150.73);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('ce750a5a-f177-43f5-a7d7-6d93e7a8ba9d','Administering drugs to obtain or facilitate intercourse','Section 4',29,75877.19);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('e481d354-eb04-4d01-a9b5-cf9c13997b06','Intercourse with a girl under 13','Section 5',38,25633.14);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('aa0750a5-4d7f-42bb-8d87-4a108a9c9239','Intercourse with a girl under 16','Section 6',39,67295.97);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('406cfa2a-087f-49bf-aee5-c117ddf68256','Intercourse with defective','Section 7',34,74285.19);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('3afb619d-78bf-4cdc-8634-84412a3409da','Procurement of defective','Section 9',22,53156.89);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('15043213-62b0-4535-8c1d-30309e031c2c','Incest by a man','Section 10',19,57257.51);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('343a0bdb-45ae-4378-ae32-c893b3f31648','Incest by a woman','Section 11',23,82208.31);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('03f7a394-b71c-422d-ab4e-188b84712ae3','Buggery where the victim is under 16*','Section 12',46,87252.54);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('384bced7-268d-4b36-bb0e-5ec0e66989e7','Indecency between men (gross indecency)','Section 13',45,34831.36);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('16ca1229-3a9b-47b2-bbe7-ed49bfdad669','Indecent assault on a woman','Section 14',40,97087.31);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('becffda9-9e7a-498a-bcb2-177cca939535','Indecent assault on a man','Section 15',2,78154.04);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('91118ab6-27d1-4100-8171-982ed789eeef','Assault with intent to commit buggery','Section 16',38,93587.01);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('671052a9-b877-4c85-8f06-e097c47d2073','Abduction of a woman by force or for the sake of her property','Section 17',18,70747.73);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('f0cd4460-e6f9-4139-b760-b77123fd0b57','Abduction of unmarried girl under 18 from parent or guardian','Section 19',25,3423.46);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('6853c95a-9419-4dd8-9e97-bbbb1c674a11','Abduction of unmarried girl under 16 from parent or guardian','Section 20',50,16260.65);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('8541e81e-bb4b-40d2-b2a7-bd9e2db8bab6','Abduction of defective from parent or guardian','Section 21',31,21415.33);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('b7f5cedd-4f97-4567-934c-ecb499a9e620','Causing prostitution of women','Section 22',17,85309.18);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('a2084b57-d136-485d-8331-687abca72579','Procuration of girl under 21','Section 23',37,26285.56);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('02dcd908-d51d-4f84-aced-adc348bd8d11','Detention of a woman in a brothel or other premises','Section 24',30,28285.97);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('b04a0e35-db6c-4435-8357-342ff2b2b384','Permitting a girl under 13 to use premises for intercourse','Section 25',6,85913.28);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('70a9178c-6d56-45e5-9abf-c4b14ecbc06f','Permitting a girl between 13 and 16 to use premises for intercourse','Section 26',37,70622.59);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('e7d914ba-24a5-47ed-9805-6f4468e877f6','Permitting defective to use premises for intercourse','Section 27',18,60186.31);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('0c5f33f6-5ec9-41fb-85bb-81bd0c17cebf','Causing or encouraging prostitution of, or intercourse with, or indecent assault on, girl under 16','Section 28',26,4355.47);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('d56abdb6-37eb-4231-9424-74f40cdb2e0d','Causing or encouraging prostitution of a defective','Section 29',32,27183.33);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('b6925075-3117-48ce-aaf0-f4c084e893d8','Man living on earnings of prostitution','Section 30',50,79692.96);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('9689a79d-1d2c-45aa-bbf9-1b93eeec859e','Women exercising control over prostitute','Section 31',9,57918.99);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('a60d31da-aeac-4fb6-ad8b-313506f1d8a0','Sexual intercourse with patients','Section 128',37,79145.64);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('4352d613-4989-47c9-a772-67dd998e8a6a','Indecent conduct towards young child','Section 1',47,76946.38);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('5cce760b-9fa0-420a-a228-00e5daddc44d','Aiding, abetting, counselling or procuring the suicide of a child or young person','Section 2',34,95465.84);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('1dc9fdbc-de1d-41a2-a24b-4fac338a7a6a','Recovery of missing or unlawfully held children','Section 50',35,75802.19);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('3ec55e01-e520-4fb5-94e9-8c8166dcdf6d','Abuse of Trust','Section 3',33,1480.38);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('1a78298b-543f-4483-8945-6f14e54c916c','Traffic in prostitution','Section 145',44,76734.18);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('917c3299-46dd-44e6-bb1c-3e508f737f3c','Rape','Section 6',37,38147.86);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('ee62bfc4-4ccb-4c0b-8383-73543b3062ee','Assault by penetration','Section 2',42,1621.6);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('e94d2666-3dec-4880-aa96-aa32ac0aaca8','Sexual assault','Section 3',14,79960.49);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('4cb0ccdf-14cc-47d8-b1b8-0864275b9f0e','Causing a person to engage in sexual activity without consent','Section 4',2,14055.14);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('304ad86b-f176-4a05-8fa6-5ea2fdb89432','Rape of a child under 13','Section 5',19,50778.81);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('b351a209-7aa1-42c5-a64d-dd5b6976f467','Assault of a child under 13 by penetration','Section 6',47,42503.6);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('73c40c1e-6701-4673-a494-3fe5e106b539','Sexual assault of a child under 13','Section 7',34,86382.88);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('74e5ba31-a651-43de-9669-92af2f8c8289','Causing or inciting a child under 13 to engage in sexual activity','Section 8',11,47201.21);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('96b4c568-abf8-4797-8a14-87f2a08967a1','Sexual Activity with a Child','Section 9',33,12181.81);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('b2746a16-a902-4a9b-96be-8ccd174060a5','Causing or inciting a child to engage in sexual activity','Section 10',17,46153.17);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('89093108-0c0c-4cb6-ae59-967f34d68c72','Engaging in sexual activity in the presence of a child','Section 11',36,76767.47);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('d846f5c5-d956-45e7-a36f-64ea7cfa5f70','Causing a child to watch a sexual act','Section 12',19,40957.3);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('a15cff32-1bb0-412e-bce2-cf658a546910','Child sex offences committed by a children or young persons','Section 13',47,23954.4);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('e89b3fef-13bc-46f4-9a79-ac2d861634e4','Arranging or facilitating commission of a child sex offence','Section 14',26,84480.86);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('1191fb05-bc21-4627-82b0-9de6edee6ef6','Meeting a child following sexual grooming etc.','Section 15',46,47408.12);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('2943cd6c-14ec-4e1f-9dea-b2658f3e4664','Causing or inciting a person, with a mental disorder impeding choice, to engage in sexual activity','Section 31',28,58864.42);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('4970f14f-0ce2-417f-ade9-7d01dd959c3f','Engaging in sexual activity in the presence of a person with a mental disorder impeding choice','Section 32',13,20209.61);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('bafd4887-bc53-4284-8ef3-41cb5cee86a4','Causing a person, with a mental disorder impeding choice, to watch a sexual act','Section 33',12,22790.45);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('12b6bf1f-18fa-484f-9646-68c999fc1110','Inducement, threat or deception to procure sexual activity with a person with a mental disorder','Section 34',28,66352.75);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('84e31b22-697d-4ce2-9a4c-09755edfdda2','Causing a person with a mental disorder to engage in or agree to engage in sexual activity by inducement, threat or deception','Section 35',43,95390.25);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('6eb9ab9c-7112-4d47-9460-bde6c1ba4629','Engaging in sexual activity in the presence, procured by inducement, threat or deception, of a person with a mental disorder','Section 36',29,84450.62);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('5d34f055-3157-4950-b686-6f0d7a25d869','Causing a person with a mental disorder to watch a sexual act by inducement, threat or deception','Section 37',2,2715.08);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('c560911f-f477-4973-b311-1e13c8fc87c6','Care workers: sexual activity with a person with a mental disorder','Section 38',31,8073.27);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('4f60117a-d9b1-464f-a0ac-77365c31d200','Care workers: causing or inciting sexual activity','Section 39',40,22670.74);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('4427880c-dba5-42a0-b979-a39d3b936989','Care workers: sexual activity in the presence of a person with a mental disorder','Section 40',31,79132.14);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('9a8fa05b-9ad6-4275-8483-c6daaeebc8f3','Care workers: causing a person with a mental disorder to watch a sexual act','Section 41',29,51871.17);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('bbf39c94-20d2-40ca-8a70-2366ae1f2ed9','Paying for the sexual services of a child','Section 47',5,16804.43);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('df03efbf-b089-4d0b-95cb-3321a4a147e6','Causing or inciting child prostitution or pornography','Section 48',10,72312.93);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('c6f4ba7d-915e-4219-8db5-257b12d7b501','Controlling a child prostitute or a child involved in pornography','Section 49',32,54635.32);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('4bfb5363-a02e-4ec7-a05f-250d5559814a','Arranging or facilitating child prostitution or pornography','Section 50',43,27296.97);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('aa15b5ca-382e-43a7-8d16-0778ce2d3e2a','Causing or inciting prostitution for gain','Section 52',33,12505.57);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('2aed8d89-efe7-44fd-b40a-a38b927c1c1a','Controlling prostitution for gain','Section 53',8,2083.09);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('569f4317-a3d5-4aef-a296-23dd6642df08','Trafficking into the UK for sexual exploitation','Section 57',32,95730.47);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('cb3cdb11-bf15-4c6e-a382-4175db25349b','Administering a substance with intent','Section 61',16,33397.85);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('a7cb6b8d-8a6d-4986-b172-08979cefec2d','Committing an offence with intent to commit a sexual offence (in a case where the intended offence was an offence against a child)','Section 62',41,58598.15);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('288117cf-b869-4241-80e7-0f87a49caa30','Trespass with intent to commit a sexual offence (in a case where the intended offence was an offence against a child)','Section 63',35,31605.87);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('052c3a8e-db18-48ff-9a27-634b25508496','Exposure','Section 66',16,98524.25);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('bca09f12-471b-4536-a098-b046db31d5f4','Voyeurism','Section 67',30,11398.5);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('9473b4db-664c-42df-832b-150b9b791bca','Trafficking people for exploitation','Section 4',43,33182.44);
INSERT INTO OffenceTable(Offence_Id,Offence_Type,Offence_Act,Jail_Term,Fine_Amount) VALUES ('8473fac3-c56a-45fe-953e-aeb1c16da8ec','Causing or allowing the death of a child or vulnerable adult','Section 5',29,62525.17);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into casetable
select case_id,offence_type,offence_act
from offencetable, prisonerstable
order by random()
limit 1000;