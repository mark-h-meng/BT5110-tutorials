/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*

My chosen example is an online wine shop. The shop sells many different kind of fine wine from various countries 
and customers can choose to subscribe to their email newsletter to receive news about the wine products. 
Entity set E1 is customers (customers who subscribed to the newsletter), entity set E2 is products (types of wine
the shop sells) and the many-to-many relationship set R is transactions (associating the email of a customer to
the type of wine and quantity they have purchased).  

Below are the details of the 3 tables. 

Table 1 (Customers):
-Customer_name (not null)
-Email (primary key)
-Age (not null and check constraint as customers must be 18 years old or above to sign up)

Table 2 (Products):
-LWIN (Primary key) (similar to ISBN for books, LWIN is a 7 digit unique identifier for fine wine)
-Country (not null) (country which the wine is from)  
-Price (not null and check constraint as price must be more than 0)

Table 3 (Transactions): 
-Transaction ID (primary key)
-Email (foreign key which references customer's email from customers table)
-LWIN (foreign key which references lwin from products table)
-Quantity (not null and check constraint as quantity must be more than 0)

The code will be written in PostgreSQL.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE customers (
  customer_name VARCHAR(64) NOT NULL, 
  email VARCHAR(64) PRIMARY KEY, 
  age NUMERIC NOT NULL CHECK (age > 17)
);

CREATE TABLE products (
  lwin NUMERIC PRIMARY KEY, 
  country VARCHAR(64) NOT NULL, 
  price NUMERIC NOT NULL CHECK (price > 0)
);

CREATE TABLE transactions (
  transaction_id SERIAL PRIMARY KEY, 
  email VARCHAR(64) REFERENCES customers (email), 
  lwin NUMERIC REFERENCES products (lwin),
  quantity NUMERIC NOT NULL CHECK (quantity>0)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO customers (customer_name, email, age) VALUES ('Germaine', 'gpikesley0@twitter.com', 81);
INSERT INTO customers (customer_name, email, age) VALUES ('Hephzibah', 'hgosland1@posterous.com', 78);
INSERT INTO customers (customer_name, email, age) VALUES ('Shay', 'sfantini2@trellian.com', 78);
INSERT INTO customers (customer_name, email, age) VALUES ('Donal', 'dkulic3@disqus.com', 89);
INSERT INTO customers (customer_name, email, age) VALUES ('Maisie', 'mmayou4@eventbrite.com', 52);
INSERT INTO customers (customer_name, email, age) VALUES ('Fawne', 'fabilowitz5@wordpress.com', 25);
INSERT INTO customers (customer_name, email, age) VALUES ('Susann', 'santonchik6@geocities.jp', 76);
INSERT INTO customers (customer_name, email, age) VALUES ('Rock', 'rledger7@state.gov', 22);
INSERT INTO customers (customer_name, email, age) VALUES ('Felike', 'fdenslow8@angelfire.com', 75);
INSERT INTO customers (customer_name, email, age) VALUES ('Dan', 'dtolchard9@theatlantic.com', 23);
INSERT INTO customers (customer_name, email, age) VALUES ('Brig', 'blaviellea@skyrock.com', 88);
INSERT INTO customers (customer_name, email, age) VALUES ('Michele', 'mlanfranchib@free.fr', 79);
INSERT INTO customers (customer_name, email, age) VALUES ('Cory', 'clelloc@arizona.edu', 63);
INSERT INTO customers (customer_name, email, age) VALUES ('Melba', 'manneyd@uiuc.edu', 19);
INSERT INTO customers (customer_name, email, age) VALUES ('Tabbie', 'ttandeye@google.cn', 81);
INSERT INTO customers (customer_name, email, age) VALUES ('Petey', 'pistonf@theglobeandmail.com', 35);
INSERT INTO customers (customer_name, email, age) VALUES ('Georgeanne', 'gbrownseyg@linkedin.com', 47);
INSERT INTO customers (customer_name, email, age) VALUES ('Nelly', 'ndrewesh@instagram.com', 57);
INSERT INTO customers (customer_name, email, age) VALUES ('Any', 'abilsoni@princeton.edu', 25);
INSERT INTO customers (customer_name, email, age) VALUES ('Carlos', 'ccancellarioj@abc.net.au', 21);
INSERT INTO customers (customer_name, email, age) VALUES ('Jorie', 'jeunsonk@printfriendly.com', 46);
INSERT INTO customers (customer_name, email, age) VALUES ('Masha', 'mstinsonl@techcrunch.com', 64);
INSERT INTO customers (customer_name, email, age) VALUES ('Bari', 'blippettm@arstechnica.com', 25);
INSERT INTO customers (customer_name, email, age) VALUES ('Iolanthe', 'ivearnalsn@latimes.com', 62);
INSERT INTO customers (customer_name, email, age) VALUES ('Vally', 'vmeako@gizmodo.com', 72);
INSERT INTO customers (customer_name, email, age) VALUES ('Fran', 'fcestardp@stumbleupon.com', 22);
INSERT INTO customers (customer_name, email, age) VALUES ('Lilyan', 'lcressinghamq@fastcompany.com', 33);
INSERT INTO customers (customer_name, email, age) VALUES ('Jan', 'jsextonr@soundcloud.com', 69);
INSERT INTO customers (customer_name, email, age) VALUES ('Devonna', 'dfeilds@uol.com.br', 43);
INSERT INTO customers (customer_name, email, age) VALUES ('Susana', 'smacgilmartint@ocn.ne.jp', 62);
INSERT INTO customers (customer_name, email, age) VALUES ('Sephira', 'swenderothu@netlog.com', 60);
INSERT INTO customers (customer_name, email, age) VALUES ('Hamel', 'hgrinsdalev@friendfeed.com', 18);
INSERT INTO customers (customer_name, email, age) VALUES ('Portie', 'pecclesw@craigslist.org', 50);
INSERT INTO customers (customer_name, email, age) VALUES ('Jarib', 'jmathanx@princeton.edu', 67);
INSERT INTO customers (customer_name, email, age) VALUES ('Yankee', 'yriggeyy@salon.com', 67);
INSERT INTO customers (customer_name, email, age) VALUES ('Daisie', 'dbrewertonz@techcrunch.com', 24);
INSERT INTO customers (customer_name, email, age) VALUES ('Tucker', 'tlurcock10@google.it', 79);
INSERT INTO customers (customer_name, email, age) VALUES ('Dallas', 'dpittwood11@earthlink.net', 66);
INSERT INTO customers (customer_name, email, age) VALUES ('Alfons', 'amoyser12@va.gov', 79);
INSERT INTO customers (customer_name, email, age) VALUES ('Petrina', 'pcatrell13@nationalgeographic.com', 73);
INSERT INTO customers (customer_name, email, age) VALUES ('Torry', 'tlung14@washingtonpost.com', 66);
INSERT INTO customers (customer_name, email, age) VALUES ('Itch', 'iorodane15@wikipedia.org', 30);
INSERT INTO customers (customer_name, email, age) VALUES ('Sandi', 'syapp16@paginegialle.it', 62);
INSERT INTO customers (customer_name, email, age) VALUES ('Vasilis', 'vscanterbury17@dedecms.com', 71);
INSERT INTO customers (customer_name, email, age) VALUES ('Beltran', 'btirrey18@t.co', 42);
INSERT INTO customers (customer_name, email, age) VALUES ('Winfield', 'wpress19@istockphoto.com', 61);
INSERT INTO customers (customer_name, email, age) VALUES ('Lotty', 'ldudenie1a@washington.edu', 42);
INSERT INTO customers (customer_name, email, age) VALUES ('Yvette', 'ydunkirk1b@nhs.uk', 52);
INSERT INTO customers (customer_name, email, age) VALUES ('Golda', 'gjoules1c@themeforest.net', 58);
INSERT INTO customers (customer_name, email, age) VALUES ('Claudius', 'cohone1d@forbes.com', 46);
INSERT INTO customers (customer_name, email, age) VALUES ('Eldredge', 'esein1e@berkeley.edu', 90);
INSERT INTO customers (customer_name, email, age) VALUES ('Sarene', 'sharrill1f@google.ca', 90);
INSERT INTO customers (customer_name, email, age) VALUES ('Bud', 'bzoanetti1g@eepurl.com', 28);
INSERT INTO customers (customer_name, email, age) VALUES ('Reid', 'rantonsson1h@flavors.me', 90);
INSERT INTO customers (customer_name, email, age) VALUES ('Rosina', 'rburlay1i@about.me', 61);
INSERT INTO customers (customer_name, email, age) VALUES ('Elfreda', 'esigge1j@independent.co.uk', 89);
INSERT INTO customers (customer_name, email, age) VALUES ('Laurella', 'lhaldane1k@arizona.edu', 72);
INSERT INTO customers (customer_name, email, age) VALUES ('Sybilla', 'shussey1l@com.com', 71);
INSERT INTO customers (customer_name, email, age) VALUES ('Reese', 'rmacalroy1m@businesswire.com', 46);
INSERT INTO customers (customer_name, email, age) VALUES ('Marline', 'mpedri1n@xinhuanet.com', 46);
INSERT INTO customers (customer_name, email, age) VALUES ('Jackquelin', 'jcrabtree1o@mit.edu', 58);
INSERT INTO customers (customer_name, email, age) VALUES ('Brandi', 'biacomo1p@thetimes.co.uk', 29);
INSERT INTO customers (customer_name, email, age) VALUES ('Rhonda', 'rchasemoore1q@reuters.com', 38);
INSERT INTO customers (customer_name, email, age) VALUES ('Teriann', 'thardwicke1r@shutterfly.com', 50);
INSERT INTO customers (customer_name, email, age) VALUES ('Jerrilee', 'jcaddell1s@hp.com', 81);
INSERT INTO customers (customer_name, email, age) VALUES ('Jonathon', 'jlaudham1t@psu.edu', 89);
INSERT INTO customers (customer_name, email, age) VALUES ('Aharon', 'alyford1u@time.com', 84);
INSERT INTO customers (customer_name, email, age) VALUES ('Onfre', 'oarrundale1v@alexa.com', 45);
INSERT INTO customers (customer_name, email, age) VALUES ('Devondra', 'dallmann1w@php.net', 88);
INSERT INTO customers (customer_name, email, age) VALUES ('Faith', 'ftomeo1x@marketwatch.com', 60);
INSERT INTO customers (customer_name, email, age) VALUES ('Cristionna', 'cpelz1y@desdev.cn', 66);
INSERT INTO customers (customer_name, email, age) VALUES ('Salmon', 'sfinlry1z@dell.com', 61);
INSERT INTO customers (customer_name, email, age) VALUES ('Janette', 'jmaben20@nature.com', 49);
INSERT INTO customers (customer_name, email, age) VALUES ('Tucker', 'tkeyme21@ox.ac.uk', 71);
INSERT INTO customers (customer_name, email, age) VALUES ('Bentlee', 'bmackie22@360.cn', 63);
INSERT INTO customers (customer_name, email, age) VALUES ('Fidela', 'fyesinin23@ow.ly', 53);
INSERT INTO customers (customer_name, email, age) VALUES ('Jenelle', 'jsmuth24@theglobeandmail.com', 62);
INSERT INTO customers (customer_name, email, age) VALUES ('Agneta', 'afoottit25@msu.edu', 31);
INSERT INTO customers (customer_name, email, age) VALUES ('Sheffie', 'smacleod26@about.me', 19);
INSERT INTO customers (customer_name, email, age) VALUES ('Evaleen', 'ekamien27@tumblr.com', 48);
INSERT INTO customers (customer_name, email, age) VALUES ('Camellia', 'cdowne28@tiny.cc', 54);
INSERT INTO customers (customer_name, email, age) VALUES ('Jammie', 'jlerwill29@cdbaby.com', 31);
INSERT INTO customers (customer_name, email, age) VALUES ('Adelice', 'awhotton2a@desdev.cn', 81);
INSERT INTO customers (customer_name, email, age) VALUES ('Maris', 'mjefferys2b@springer.com', 35);
INSERT INTO customers (customer_name, email, age) VALUES ('Manfred', 'mgoodhand2c@about.com', 32);
INSERT INTO customers (customer_name, email, age) VALUES ('Maryanne', 'mtortis2d@pen.io', 49);
INSERT INTO customers (customer_name, email, age) VALUES ('Tully', 'tlittlepage2e@domainmarket.com', 29);
INSERT INTO customers (customer_name, email, age) VALUES ('Yves', 'ygauvin2f@about.me', 19);
INSERT INTO customers (customer_name, email, age) VALUES ('Udall', 'uborn2g@wix.com', 67);
INSERT INTO customers (customer_name, email, age) VALUES ('Ardyce', 'abarfford2h@jigsy.com', 39);
INSERT INTO customers (customer_name, email, age) VALUES ('Jimmy', 'jhadcock2i@sogou.com', 49);
INSERT INTO customers (customer_name, email, age) VALUES ('Colman', 'cbedberry2j@berkeley.edu', 85);
INSERT INTO customers (customer_name, email, age) VALUES ('Ikey', 'itulip2k@google.co.uk', 88);
INSERT INTO customers (customer_name, email, age) VALUES ('Hedwig', 'hlees2l@list-manage.com', 45);
INSERT INTO customers (customer_name, email, age) VALUES ('Misti', 'mmussington2m@bing.com', 69);
INSERT INTO customers (customer_name, email, age) VALUES ('Prudi', 'psidney2n@macromedia.com', 61);
INSERT INTO customers (customer_name, email, age) VALUES ('Eleonore', 'estilgo2o@cafepress.com', 70);
INSERT INTO customers (customer_name, email, age) VALUES ('Chad', 'cflagg2p@domainmarket.com', 42);
INSERT INTO customers (customer_name, email, age) VALUES ('Diego', 'dgodber2q@behance.net', 64);
INSERT INTO customers (customer_name, email, age) VALUES ('Teddy', 'tbowmen2r@goo.gl', 77);


INSERT INTO products (lwin, country, price) VALUES (7732768, 'Russia', 4500);
INSERT INTO products (lwin, country, price) VALUES (3503629, 'France', 4500);
INSERT INTO products (lwin, country, price) VALUES (5519823, 'Russia', 550);
INSERT INTO products (lwin, country, price) VALUES (6484793, 'Australia', 950);
INSERT INTO products (lwin, country, price) VALUES (2166735, 'Russia', 500);
INSERT INTO products (lwin, country, price) VALUES (2166453, 'France', 625);
INSERT INTO products (lwin, country, price) VALUES (8569449, 'Spain', 820);
INSERT INTO products (lwin, country, price) VALUES (1640905, 'United States', 980);
INSERT INTO products (lwin, country, price) VALUES (1953745, 'Russia', 5800);
INSERT INTO products (lwin, country, price) VALUES (7554775, 'Russia', 950);
INSERT INTO products (lwin, country, price) VALUES (2145658, 'Russia', 135);
INSERT INTO products (lwin, country, price) VALUES (5706997, 'Russia', 950);
INSERT INTO products (lwin, country, price) VALUES (3389065, 'Russia', 860);
INSERT INTO products (lwin, country, price) VALUES (2004704, 'United States', 2500);
INSERT INTO products (lwin, country, price) VALUES (4692109, 'New Zealand', 820);
INSERT INTO products (lwin, country, price) VALUES (7725820, 'France', 3050);
INSERT INTO products (lwin, country, price) VALUES (2001124, 'France', 850);
INSERT INTO products (lwin, country, price) VALUES (4355613, 'Spain', 3050);
INSERT INTO products (lwin, country, price) VALUES (4782958, 'Russia', 3600);
INSERT INTO products (lwin, country, price) VALUES (8942697, 'France', 5800);
INSERT INTO products (lwin, country, price) VALUES (6070086, 'Russia', 3050);
INSERT INTO products (lwin, country, price) VALUES (8011881, 'France', 2050);
INSERT INTO products (lwin, country, price) VALUES (3543633, 'Russia', 850);
INSERT INTO products (lwin, country, price) VALUES (3455469, 'Russia', 3800);
INSERT INTO products (lwin, country, price) VALUES (7542105, 'New Zealand', 2050);
INSERT INTO products (lwin, country, price) VALUES (3587714, 'France', 625);
INSERT INTO products (lwin, country, price) VALUES (7206990, 'France', 2000);
INSERT INTO products (lwin, country, price) VALUES (7290216, 'France', 2500);
INSERT INTO products (lwin, country, price) VALUES (3926626, 'United States', 3600);
INSERT INTO products (lwin, country, price) VALUES (5984306, 'France', 3600);
INSERT INTO products (lwin, country, price) VALUES (2753604, 'United States', 500);
INSERT INTO products (lwin, country, price) VALUES (8527227, 'Russia', 500);
INSERT INTO products (lwin, country, price) VALUES (8219479, 'Russia', 3600);
INSERT INTO products (lwin, country, price) VALUES (2174040, 'Russia', 950);
INSERT INTO products (lwin, country, price) VALUES (6398556, 'France', 5800);
INSERT INTO products (lwin, country, price) VALUES (2081281, 'Russia', 850);
INSERT INTO products (lwin, country, price) VALUES (8244160, 'Russia', 2050);
INSERT INTO products (lwin, country, price) VALUES (5398001, 'France', 980);
INSERT INTO products (lwin, country, price) VALUES (3702598, 'France', 860);
INSERT INTO products (lwin, country, price) VALUES (5725760, 'United States', 860);
INSERT INTO products (lwin, country, price) VALUES (2636469, 'France', 950);
INSERT INTO products (lwin, country, price) VALUES (3886127, 'United States', 950);
INSERT INTO products (lwin, country, price) VALUES (1330258, 'France', 5800);
INSERT INTO products (lwin, country, price) VALUES (7276121, 'France', 625);
INSERT INTO products (lwin, country, price) VALUES (4156992, 'United States', 3800);
INSERT INTO products (lwin, country, price) VALUES (6179173, 'United States', 3800);
INSERT INTO products (lwin, country, price) VALUES (2170881, 'Russia', 2500);
INSERT INTO products (lwin, country, price) VALUES (8391930, 'France', 1250);
INSERT INTO products (lwin, country, price) VALUES (1676411, 'Russia', 3600);
INSERT INTO products (lwin, country, price) VALUES (5454749, 'France', 4500);
INSERT INTO products (lwin, country, price) VALUES (3928222, 'United States', 850);
INSERT INTO products (lwin, country, price) VALUES (8682361, 'United States', 820);
INSERT INTO products (lwin, country, price) VALUES (8425936, 'Russia', 135);
INSERT INTO products (lwin, country, price) VALUES (1974068, 'Australia', 2050);
INSERT INTO products (lwin, country, price) VALUES (5490524, 'United States', 3600);
INSERT INTO products (lwin, country, price) VALUES (7832036, 'Russia', 1250);
INSERT INTO products (lwin, country, price) VALUES (3157027, 'United States', 500);
INSERT INTO products (lwin, country, price) VALUES (4985409, 'Russia', 980);
INSERT INTO products (lwin, country, price) VALUES (3573020, 'United States', 500);
INSERT INTO products (lwin, country, price) VALUES (1151268, 'France', 4500);
INSERT INTO products (lwin, country, price) VALUES (5311809, 'Germany', 3600);
INSERT INTO products (lwin, country, price) VALUES (1521320, 'Russia', 820);
INSERT INTO products (lwin, country, price) VALUES (3540110, 'Russia', 4500);
INSERT INTO products (lwin, country, price) VALUES (2011945, 'France', 2000);
INSERT INTO products (lwin, country, price) VALUES (6954779, 'Russia', 1250);
INSERT INTO products (lwin, country, price) VALUES (3194014, 'France', 950);
INSERT INTO products (lwin, country, price) VALUES (6028638, 'Russia', 4500);
INSERT INTO products (lwin, country, price) VALUES (7259792, 'Russia', 1250);
INSERT INTO products (lwin, country, price) VALUES (2525621, 'United States', 950);
INSERT INTO products (lwin, country, price) VALUES (1824926, 'Russia', 1250);
INSERT INTO products (lwin, country, price) VALUES (3429375, 'Russia', 3050);
INSERT INTO products (lwin, country, price) VALUES (2425645, 'Germany', 4500);
INSERT INTO products (lwin, country, price) VALUES (4611937, 'France', 1250);
INSERT INTO products (lwin, country, price) VALUES (3826733, 'Russia', 135);
INSERT INTO products (lwin, country, price) VALUES (8423734, 'France', 860);
INSERT INTO products (lwin, country, price) VALUES (8583550, 'Germany', 2000);
INSERT INTO products (lwin, country, price) VALUES (1709497, 'United States', 5800);
INSERT INTO products (lwin, country, price) VALUES (2215703, 'Russia', 2500);
INSERT INTO products (lwin, country, price) VALUES (1324287, 'Russia', 3050);
INSERT INTO products (lwin, country, price) VALUES (2226568, 'United States', 980);
INSERT INTO products (lwin, country, price) VALUES (7675910, 'Russia', 2000);
INSERT INTO products (lwin, country, price) VALUES (1332239, 'United States', 2050);
INSERT INTO products (lwin, country, price) VALUES (2232983, 'Russia', 2000);
INSERT INTO products (lwin, country, price) VALUES (2298222, 'Russia', 5800);
INSERT INTO products (lwin, country, price) VALUES (5965202, 'France', 1250);
INSERT INTO products (lwin, country, price) VALUES (1199874, 'France', 1250);
INSERT INTO products (lwin, country, price) VALUES (5082331, 'France', 980);
INSERT INTO products (lwin, country, price) VALUES (7464355, 'Russia', 3600);
INSERT INTO products (lwin, country, price) VALUES (3305492, 'United States', 550);
INSERT INTO products (lwin, country, price) VALUES (3416074, 'Russia', 135);
INSERT INTO products (lwin, country, price) VALUES (4339370, 'United States', 3050);
INSERT INTO products (lwin, country, price) VALUES (5127923, 'United States', 2000);
INSERT INTO products (lwin, country, price) VALUES (8327762, 'United States', 3600);
INSERT INTO products (lwin, country, price) VALUES (3704155, 'France', 4500);
INSERT INTO products (lwin, country, price) VALUES (7423716, 'France', 820);
INSERT INTO products (lwin, country, price) VALUES (6506590, 'France', 860);
INSERT INTO products (lwin, country, price) VALUES (2407068, 'United States', 850);
INSERT INTO products (lwin, country, price) VALUES (1177685, 'France', 2000);
INSERT INTO products (lwin, country, price) VALUES (2616036, 'Russia', 850);
INSERT INTO products (lwin, country, price) VALUES (8703110, 'France', 3050);


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO transactions (email, lwin, quantity) 
SELECT 
  c.email, 
  p.lwin,
  CAST (random()*(20-1+1)+1 as INT)
FROM 
  customers c, 
  products p 
ORDER BY 
  random () 
LIMIT 
  1000;

/*Note: for the purpose of this question, will set quantity to be a random number between 1-20*/
