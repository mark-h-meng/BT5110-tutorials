/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The answer keeps the maintenance record of the equipment owned by a company.

The table 'workers' contains the information of the workers who carry out maintenance.
Its attributes contain the first name, last name, employee number and nationality of the employee.
The employee number is unique for each employee and set to the primary key.

The table 'equipment' contains the information of the equipment.
Its atrributes contain the serial number, supplier company name and purchase date of the equipment.
The serial number of a particular piece of equipment is unique and set to the primary key.

The relationship 'maintains' keeps the record of the service done by a worker on a piece of equipment.
It has foreign keys with reference to the worker employee number and the equipment serial number.
The combination of the employee number and serial number is assumed to be unique and set to the primary key.

The code is written for PostgreSQL.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE workers(
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	employee_number VARCHAR(16) PRIMARY KEY,
	nationality VARCHAR(16) NOT NULL);
	
CREATE TABLE equipment(
	serial_number VARCHAR(16) PRIMARY KEY,
	supplier VARCHAR(64) NOT NULL,
	purchase_date DATE NOT NULL );
	
CREATE TABLE maintains(
	employee_number VARCHAR(16) REFERENCES workers(employee_number),
	serial_number VARCHAR(16) REFERENCES equipment(serial_number),
	PRIMARY KEY (employee_number, serial_number));
	
	
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Populating table 'workers' */
insert into workers (first_name, last_name, employee_number, nationality) values ('Cos', 'Leinster', '877396', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Geneva', 'Spreadbury', '739210', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Talya', 'Dyble', '447204', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Melisa', 'Morhall', '268535', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Karlotte', 'Christofle', '664213', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Christie', 'Bitterton', '324311', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Carlyle', 'Gronav', '025423', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Bobby', 'Southerton', '240321', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Kristi', 'Latek', '222850', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Gavra', 'Outibridge', '265915', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Jo ann', 'Roden', '629243', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Doralia', 'Seif', '372157', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Tricia', 'Dwight', '249298', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Mora', 'Coopman', '988683', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Chelsea', 'Porrett', '404945', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Nanette', 'Gledhill', '465326', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Tobit', 'Sapsed', '149303', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Marlane', 'McCaskill', '721983', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Thorndike', 'Nortcliffe', '265701', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Frankie', 'Cattow', '005682', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Brigid', 'Cassel', '122028', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Yancey', 'Sabatini', '641657', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Silvio', 'Luby', '310247', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Libby', 'Mains', '919098', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Colette', 'Helder', '126781', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Deva', 'Gouth', '173198', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Abbie', 'Coursor', '691541', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Curr', 'Liffe', '202862', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Phip', 'Cranfield', '390266', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Betteanne', 'Pettet', '925588', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Muffin', 'Callan', '909473', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Idette', 'Mauvin', '072913', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Lorianna', 'Croizier', '038938', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Ralph', 'Jillard', '035654', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Quinta', 'Bagster', '521244', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Ahmed', 'Rogger', '639706', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Jerry', 'Lightning', '155815', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Velvet', 'Teml', '649419', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Dorris', 'Hehnke', '535957', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Brody', 'Nicholes', '542948', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Claresta', 'Oakwell', '456661', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Karylin', 'Webbe', '476595', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Abram', 'Veltmann', '527007', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Katy', 'Gerner', '667063', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Valentin', 'Maccrea', '747664', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Krystalle', 'Heaps', '197193', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Gerhardine', 'Naul', '153923', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Hermina', 'Grigoliis', '830255', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Forest', 'Durning', '104706', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Katharina', 'Gidman', '064871', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Brendon', 'Loughead', '184470', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Shawnee', 'Orsay', '349570', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Lothaire', 'Lanaway', '614390', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Cloe', 'Cocksedge', '164935', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Bronny', 'Conkie', '784381', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Hedda', 'Tommis', '220413', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Trix', 'Grubbe', '480865', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Dalton', 'Baldacchino', '714438', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Nigel', 'Garrals', '157607', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Gwendolyn', 'Lapidus', '527444', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Corliss', 'Rostron', '455639', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Xenos', 'Danaher', '984558', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Ddene', 'Kinnon', '142934', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Clara', 'Preskett', '040539', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Elie', 'Orme', '256196', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Elva', 'Wellstead', '002157', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Michail', 'Rosle', '489246', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Brana', 'Lovemore', '267490', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Fredric', 'Stailey', '435110', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Sarina', 'Prangnell', '407099', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Welbie', 'Mc Cahey', '194264', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Edeline', 'Lambertson', '984418', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Melisenda', 'Ortmann', '138571', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Jake', 'Atack', '534751', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Shayla', 'Waller-Bridge', '507433', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Renee', 'Delouch', '553743', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Avrom', 'Sphinxe', '889701', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Janna', 'Vannar', '084917', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Phillipp', 'Lucio', '907809', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Roley', 'Beniesh', '082536', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Galvan', 'Crozier', '465794', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Anneliese', 'Ucceli', '809271', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Jazmin', 'Altofts', '877969', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Gillie', 'Gratten', '060497', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Nelle', 'Gertray', '815365', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Devland', 'Brandreth', '648757', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Penelopa', 'Leggate', '114877', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Filmer', 'Inker', '631435', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Emilia', 'Jacobson', '406519', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Hersch', 'Schuchmacher', '773391', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Johnathon', 'Giamo', '020099', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Margette', 'Himpson', '182639', 'Malaysia');
insert into workers (first_name, last_name, employee_number, nationality) values ('Haven', 'Roseborough', '918657', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Philippa', 'Yendall', '119554', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Nevil', 'Sacchetti', '532733', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Herold', 'Lavielle', '321228', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Jaimie', 'Madner', '358372', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Ferris', 'Lancetter', '668848', 'Thailand');
insert into workers (first_name, last_name, employee_number, nationality) values ('Aggy', 'Chave', '627828', 'Vietnam');
insert into workers (first_name, last_name, employee_number, nationality) values ('Jeremiah', 'Baldin', '231220', 'Vietnam');

/* Populating table 'equipment' */
insert into equipment (serial_number, supplier, purchase_date) values ('dcc-0037', 'Klocko-Funk', '2019-07-24');
insert into equipment (serial_number, supplier, purchase_date) values ('ljg-5991', 'Hartmann Group', '2016-12-26');
insert into equipment (serial_number, supplier, purchase_date) values ('pfe-7158', 'Maggio and Sons', '2019-09-03');
insert into equipment (serial_number, supplier, purchase_date) values ('uoj-6249', 'Welch, Runolfsson and Cole', '2020-02-06');
insert into equipment (serial_number, supplier, purchase_date) values ('ssx-8428', 'Zieme-Gutmann', '2017-12-29');
insert into equipment (serial_number, supplier, purchase_date) values ('har-5832', 'Ziemann Inc', '2019-09-27');
insert into equipment (serial_number, supplier, purchase_date) values ('xhi-3389', 'Maggio-Nolan', '2019-04-05');
insert into equipment (serial_number, supplier, purchase_date) values ('jpf-6746', 'Gusikowski LLC', '2018-06-03');
insert into equipment (serial_number, supplier, purchase_date) values ('mij-5863', 'Gleason-Hickle', '2017-07-15');
insert into equipment (serial_number, supplier, purchase_date) values ('mbf-9502', 'Carter-Monahan', '2018-10-11');
insert into equipment (serial_number, supplier, purchase_date) values ('rcb-1033', 'Schultz Group', '2017-05-02');
insert into equipment (serial_number, supplier, purchase_date) values ('xnq-9141', 'Davis-Klein', '2019-02-07');
insert into equipment (serial_number, supplier, purchase_date) values ('jsz-9977', 'Runte and Sons', '2020-06-04');
insert into equipment (serial_number, supplier, purchase_date) values ('cxn-1224', 'Bednar-Hintz', '2018-09-27');
insert into equipment (serial_number, supplier, purchase_date) values ('ufg-9109', 'Johnston, Huels and Conn', '2020-05-13');
insert into equipment (serial_number, supplier, purchase_date) values ('eai-4718', 'Sanford Inc', '2019-04-18');
insert into equipment (serial_number, supplier, purchase_date) values ('fpq-0568', 'Gorczany-Bradtke', '2019-03-20');
insert into equipment (serial_number, supplier, purchase_date) values ('umi-8819', 'Dooley, Swift and Bode', '2018-07-09');
insert into equipment (serial_number, supplier, purchase_date) values ('qkh-1369', 'Lind-Simonis', '2020-03-17');
insert into equipment (serial_number, supplier, purchase_date) values ('izn-3651', 'Hamill-Rempel', '2019-07-13');
insert into equipment (serial_number, supplier, purchase_date) values ('cpg-8159', 'Prohaska-Murray', '2017-04-23');
insert into equipment (serial_number, supplier, purchase_date) values ('ugb-7271', 'Berge, Klein and Grant', '2018-09-22');
insert into equipment (serial_number, supplier, purchase_date) values ('hfx-9767', 'Crooks and Sons', '2018-05-06');
insert into equipment (serial_number, supplier, purchase_date) values ('jwn-7201', 'Kling-Weimann', '2016-12-13');
insert into equipment (serial_number, supplier, purchase_date) values ('tmo-3481', 'Dietrich, Baumbach and Balistreri', '2017-08-08');
insert into equipment (serial_number, supplier, purchase_date) values ('pgr-7339', 'Schulist-Aufderhar', '2018-12-31');
insert into equipment (serial_number, supplier, purchase_date) values ('eeb-9520', 'Farrell-Torp', '2020-09-05');
insert into equipment (serial_number, supplier, purchase_date) values ('vsv-8257', 'Kuhlman-Reynolds', '2018-08-28');
insert into equipment (serial_number, supplier, purchase_date) values ('xqa-2301', 'Runte Group', '2017-10-06');
insert into equipment (serial_number, supplier, purchase_date) values ('jwm-2764', 'Kilback-Von', '2017-12-05');
insert into equipment (serial_number, supplier, purchase_date) values ('ygo-8770', 'Spencer, Halvorson and Stehr', '2018-05-07');
insert into equipment (serial_number, supplier, purchase_date) values ('uhl-1901', 'Veum-Rath', '2017-12-22');
insert into equipment (serial_number, supplier, purchase_date) values ('ule-5660', 'Kub Inc', '2018-11-09');
insert into equipment (serial_number, supplier, purchase_date) values ('euq-0057', 'Volkman LLC', '2018-10-23');
insert into equipment (serial_number, supplier, purchase_date) values ('dhp-8521', 'Toy Inc', '2017-02-17');
insert into equipment (serial_number, supplier, purchase_date) values ('laz-2698', 'Ernser-Miller', '2019-09-29');
insert into equipment (serial_number, supplier, purchase_date) values ('knk-3067', 'Kilback, Monahan and Murphy', '2020-06-16');
insert into equipment (serial_number, supplier, purchase_date) values ('nnu-6991', 'Pollich and Sons', '2020-06-24');
insert into equipment (serial_number, supplier, purchase_date) values ('efw-5348', 'Pfannerstill, Wehner and Heathcote', '2019-08-09');
insert into equipment (serial_number, supplier, purchase_date) values ('scp-4886', 'Hilll-Terry', '2019-11-11');
insert into equipment (serial_number, supplier, purchase_date) values ('spf-7273', 'Hintz-Heaney', '2019-07-29');
insert into equipment (serial_number, supplier, purchase_date) values ('mcc-0908', 'Douglas-Lesch', '2018-04-24');
insert into equipment (serial_number, supplier, purchase_date) values ('ste-6662', 'Turner, Olson and Little', '2017-09-19');
insert into equipment (serial_number, supplier, purchase_date) values ('mpx-4644', 'Abbott, Bode and Legros', '2018-08-22');
insert into equipment (serial_number, supplier, purchase_date) values ('qua-0342', 'Pollich and Sons', '2019-06-01');
insert into equipment (serial_number, supplier, purchase_date) values ('kwv-9734', 'Mitchell, Mayert and Murazik', '2017-07-03');
insert into equipment (serial_number, supplier, purchase_date) values ('oqm-6538', 'West-Ward', '2017-04-01');
insert into equipment (serial_number, supplier, purchase_date) values ('pdr-5528', 'Turcotte-Glover', '2020-09-30');
insert into equipment (serial_number, supplier, purchase_date) values ('dtk-0148', 'Mante-Friesen', '2017-08-01');
insert into equipment (serial_number, supplier, purchase_date) values ('net-5718', 'Abbott, Schulist and Zieme', '2017-08-02');
insert into equipment (serial_number, supplier, purchase_date) values ('iqi-1532', 'Torphy, Moore and Waelchi', '2017-10-09');
insert into equipment (serial_number, supplier, purchase_date) values ('mhd-8729', 'Pfeffer, Hammes and Schmeler', '2018-07-29');
insert into equipment (serial_number, supplier, purchase_date) values ('dje-5577', 'McGlynn-Osinski', '2017-02-13');
insert into equipment (serial_number, supplier, purchase_date) values ('frg-9289', 'Schimmel-Oberbrunner', '2019-11-10');
insert into equipment (serial_number, supplier, purchase_date) values ('sdo-1127', 'Lynch Inc', '2016-12-08');
insert into equipment (serial_number, supplier, purchase_date) values ('xfm-5238', 'Breitenberg, Dickinson and Hammes', '2020-08-30');
insert into equipment (serial_number, supplier, purchase_date) values ('nxh-2319', 'Prosacco, Lynch and Dach', '2020-08-24');
insert into equipment (serial_number, supplier, purchase_date) values ('flj-2177', 'Runolfsson and Sons', '2017-11-26');
insert into equipment (serial_number, supplier, purchase_date) values ('rep-4454', 'Schowalter and Sons', '2019-11-28');
insert into equipment (serial_number, supplier, purchase_date) values ('gbd-2592', 'Wiegand, Orn and Prohaska', '2019-01-09');
insert into equipment (serial_number, supplier, purchase_date) values ('pzk-5694', 'Douglas-Mayert', '2020-06-04');
insert into equipment (serial_number, supplier, purchase_date) values ('gjx-3722', 'Strosin, Okuneva and Kutch', '2017-10-12');
insert into equipment (serial_number, supplier, purchase_date) values ('ghz-3032', 'Shanahan Inc', '2017-09-17');
insert into equipment (serial_number, supplier, purchase_date) values ('tdt-4675', 'Runte, Botsford and Zulauf', '2019-11-06');
insert into equipment (serial_number, supplier, purchase_date) values ('yvu-9275', 'Olson-McGlynn', '2017-06-01');
insert into equipment (serial_number, supplier, purchase_date) values ('voa-3099', 'Thompson Group', '2020-05-13');
insert into equipment (serial_number, supplier, purchase_date) values ('wqn-5170', 'Hettinger and Sons', '2020-06-20');
insert into equipment (serial_number, supplier, purchase_date) values ('ayd-0892', 'Crona, Blick and Mueller', '2018-04-09');
insert into equipment (serial_number, supplier, purchase_date) values ('yjb-7038', 'Reilly-Farrell', '2016-12-06');
insert into equipment (serial_number, supplier, purchase_date) values ('nff-1017', 'Swift Inc', '2017-09-07');
insert into equipment (serial_number, supplier, purchase_date) values ('ntx-5944', 'Stehr, Vandervort and Kessler', '2017-06-25');
insert into equipment (serial_number, supplier, purchase_date) values ('dck-1330', 'Fisher, Waters and Hauck', '2017-04-12');
insert into equipment (serial_number, supplier, purchase_date) values ('jqf-1856', 'Hayes, Sauer and Pacocha', '2019-06-13');
insert into equipment (serial_number, supplier, purchase_date) values ('xwj-5166', 'Howell, Jerde and Schmitt', '2018-05-20');
insert into equipment (serial_number, supplier, purchase_date) values ('asj-8622', 'Steuber, Hahn and Wunsch', '2019-11-24');
insert into equipment (serial_number, supplier, purchase_date) values ('sku-0230', 'Hane, Ortiz and Pfannerstill', '2016-12-04');
insert into equipment (serial_number, supplier, purchase_date) values ('bro-8747', 'Baumbach, Kihn and Stracke', '2019-11-10');
insert into equipment (serial_number, supplier, purchase_date) values ('wdn-9582', 'Rau Inc', '2018-07-15');
insert into equipment (serial_number, supplier, purchase_date) values ('max-5957', 'Botsford and Sons', '2018-04-08');
insert into equipment (serial_number, supplier, purchase_date) values ('whi-1819', 'Carroll, Halvorson and Smith', '2017-10-13');
insert into equipment (serial_number, supplier, purchase_date) values ('bhv-4682', 'Sanford, Klein and Gleason', '2020-02-11');
insert into equipment (serial_number, supplier, purchase_date) values ('atq-8013', 'Hayes and Sons', '2016-12-04');
insert into equipment (serial_number, supplier, purchase_date) values ('qgk-7512', 'Schamberger-Beahan', '2018-12-12');
insert into equipment (serial_number, supplier, purchase_date) values ('klb-9515', 'Boyer, Effertz and Gislason', '2019-06-03');
insert into equipment (serial_number, supplier, purchase_date) values ('olc-6135', 'Mayer, Jacobson and Hand', '2020-05-15');
insert into equipment (serial_number, supplier, purchase_date) values ('gob-0713', 'Torp LLC', '2018-01-24');
insert into equipment (serial_number, supplier, purchase_date) values ('oux-8395', 'Okuneva, Boyle and Boyle', '2018-11-08');
insert into equipment (serial_number, supplier, purchase_date) values ('mep-0918', 'Hilpert-Becker', '2019-03-14');
insert into equipment (serial_number, supplier, purchase_date) values ('akv-5037', 'Wiegand Group', '2020-06-18');
insert into equipment (serial_number, supplier, purchase_date) values ('fkv-2557', 'Mitchell-Wintheiser', '2020-02-03');
insert into equipment (serial_number, supplier, purchase_date) values ('tvj-0910', 'Tillman-Fadel', '2018-12-03');
insert into equipment (serial_number, supplier, purchase_date) values ('hmu-8825', 'Prohaska, Ledner and Lesch', '2019-11-10');
insert into equipment (serial_number, supplier, purchase_date) values ('hxd-9863', 'Greenholt and Sons', '2020-08-08');
insert into equipment (serial_number, supplier, purchase_date) values ('okb-4563', 'Wolf, Pollich and Abbott', '2018-08-16');
insert into equipment (serial_number, supplier, purchase_date) values ('yvv-2002', 'Stoltenberg, Kovacek and Nikolaus', '2019-10-10');
insert into equipment (serial_number, supplier, purchase_date) values ('cpw-3268', 'O''Reilly LLC', '2019-12-28');
insert into equipment (serial_number, supplier, purchase_date) values ('opt-6312', 'Olson-Jast', '2017-07-03');
insert into equipment (serial_number, supplier, purchase_date) values ('jeg-0035', 'Sanford, Davis and Daugherty', '2018-03-11');
insert into equipment (serial_number, supplier, purchase_date) values ('lph-1140', 'Will-Ortiz', '2017-02-26');
insert into equipment (serial_number, supplier, purchase_date) values ('wvd-6584', 'Turner LLC', '2020-08-20');


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO maintains
SELECT w.employee_number, e.serial_number
FROM workers w, equipment e
ORDER BY RANDOM()
LIMIT 1000;

