/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */                                                                   */
/************************************************************************/
/* 
/* Write your answer in plain text in English below: */
/* I will design three tables. 
   The first table is student, which contains rows of first_name, last_name, studentid and email. The first_name and last_name are not null. The primary key is studentid. And use a unique constraint on email.
   The second table is club, which contains rows of club_name, club_email, and establish_time. The pramary key is the combination of club_name and club_email.
   The third table is attendence, which contains rows of studentid, club_name and club_email. The studentid in this table must correspond to an existing studentid in the student table. The club_name and club_email in this table must correspond to the club_name and club_email in the club table.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE student(
    first_name VARCHAR(64) NOT NULL,
    last_name VARCHAR(64) NOT NULL,
    studentid VARCHAR(64) PRIMARY KEY,
    email VARCHAR(64));

CREATE TABLE club(
    club_name VARCHAR(64),
    club_email VARCHAR(64),
    establish_time DATE,
    PRIMARY KEY(club_name, club_email));
	
CREATE TABLE attendence(
    studentid VARCHAR(64) REFERENCES student(studentid)
          ON UPDATE CASCADE
          ON DELETE CASCADE,
    club_name VARCHAR(64),
    club_email VARCHAR(64),
    FOREIGN KEY (club_name, club_email) REFERENCES club(club_name, club_email)
          ON UPDATE CASCADE
          ON DELETE CASCADE);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into student (first_name, last_name, studentid, email) values ('Nolana', 'Badrock', '4624994515', 'nbadrock0@stanford.edu');
insert into student (first_name, last_name, studentid, email) values ('Richard', 'Yockley', '4114508147', 'ryockley1@eepurl.com');
insert into student (first_name, last_name, studentid, email) values ('Gifford', 'Dunabie', '8352378791', 'gdunabie2@symantec.com');
insert into student (first_name, last_name, studentid, email) values ('Marcela', 'Milnthorpe', '0672547910', 'mmilnthorpe3@gizmodo.com');
insert into student (first_name, last_name, studentid, email) values ('Raviv', 'Tussaine', '2437936734', 'rtussaine4@g.co');
insert into student (first_name, last_name, studentid, email) values ('Antonietta', 'Heathcote', '6061328656', 'aheathcote5@example.com');
insert into student (first_name, last_name, studentid, email) values ('Norrie', 'Brisseau', '9387917800', 'nbrisseau6@sina.com.cn');
insert into student (first_name, last_name, studentid, email) values ('Karlotta', 'Nowill', '0648350622', 'knowill7@berkeley.edu');
insert into student (first_name, last_name, studentid, email) values ('Samson', 'Farra', '2139892003', 'sfarra8@t-online.de');
insert into student (first_name, last_name, studentid, email) values ('Simmonds', 'Earl', '8833110060', 'searl9@parallels.com');
insert into student (first_name, last_name, studentid, email) values ('Nerty', 'Boni', '4273506440', 'nbonia@java.com');
insert into student (first_name, last_name, studentid, email) values ('Vilma', 'McClory', '6166530242', 'vmccloryb@livejournal.com');
insert into student (first_name, last_name, studentid, email) values ('Loraine', 'MacKegg', '2504787995', 'lmackeggc@github.io');
insert into student (first_name, last_name, studentid, email) values ('Katharyn', 'Januszewicz', '7843522492', 'kjanuszewiczd@joomla.org');
insert into student (first_name, last_name, studentid, email) values ('Kirsteni', 'Lombard', '1925268772', 'klombarde@cafepress.com');
insert into student (first_name, last_name, studentid, email) values ('Durward', 'Dallender', '7065007790', 'ddallenderf@soup.io');
insert into student (first_name, last_name, studentid, email) values ('Dasya', 'Banbridge', '6192658390', 'dbanbridgeg@tripod.com');
insert into student (first_name, last_name, studentid, email) values ('Harald', 'Barrat', '7790650688', 'hbarrath@sciencedaily.com');
insert into student (first_name, last_name, studentid, email) values ('Robbi', 'Trundle', '6136071363', 'rtrundlei@ted.com');
insert into student (first_name, last_name, studentid, email) values ('Blondelle', 'Hateley', '9719086092', 'bhateleyj@ovh.net');
insert into student (first_name, last_name, studentid, email) values ('Terra', 'Bome', '7683138541', 'tbomek@is.gd');
insert into student (first_name, last_name, studentid, email) values ('Leicester', 'Pearmine', '5994856223', 'lpearminel@chicagotribune.com');
insert into student (first_name, last_name, studentid, email) values ('Arlee', 'Scemp', '0470729732', 'ascempm@nifty.com');
insert into student (first_name, last_name, studentid, email) values ('Bellanca', 'Hazel', '1542567963', 'bhazeln@imageshack.us');
insert into student (first_name, last_name, studentid, email) values ('Taddeo', 'Priddie', '3112371836', 'tpriddieo@issuu.com');
insert into student (first_name, last_name, studentid, email) values ('Noam', 'Willox', '5646106117', 'nwilloxp@cafepress.com');
insert into student (first_name, last_name, studentid, email) values ('Alair', 'Parker', '9608212316', 'aparkerq@comsenz.com');
insert into student (first_name, last_name, studentid, email) values ('Maxi', 'Sheather', '4120079023', 'msheatherr@nifty.com');
insert into student (first_name, last_name, studentid, email) values ('Gretchen', 'Cambling', '5015095627', 'gcamblings@homestead.com');
insert into student (first_name, last_name, studentid, email) values ('Adrian', 'Perico', '7738470275', 'apericot@cafepress.com');
insert into student (first_name, last_name, studentid, email) values ('Marnie', 'Franzen', '2508943614', 'mfranzenu@wikia.com');
insert into student (first_name, last_name, studentid, email) values ('Eberhard', 'Fossett', '4741977560', 'efossettv@unicef.org');
insert into student (first_name, last_name, studentid, email) values ('Paulita', 'Melluish', '4927660206', 'pmelluishw@fotki.com');
insert into student (first_name, last_name, studentid, email) values ('Carl', 'Nattriss', '6466349578', 'cnattrissx@sphinn.com');
insert into student (first_name, last_name, studentid, email) values ('Udale', 'Lannin', '2814179780', 'ulanniny@archive.org');
insert into student (first_name, last_name, studentid, email) values ('Terri-jo', 'Broszkiewicz', '8608544792', 'tbroszkiewiczz@home.pl');
insert into student (first_name, last_name, studentid, email) values ('Angeline', 'O''dell', '0444047697', 'aodell10@tinyurl.com');
insert into student (first_name, last_name, studentid, email) values ('Cornelius', 'Dimitrijevic', '9248114199', 'cdimitrijevic11@theguardian.com');
insert into student (first_name, last_name, studentid, email) values ('Cassie', 'Barras', '0440708745', 'cbarras12@disqus.com');
insert into student (first_name, last_name, studentid, email) values ('Cordie', 'Mitton', '4004785960', 'cmitton13@phpbb.com');
insert into student (first_name, last_name, studentid, email) values ('Paulita', 'Gregh', '0818833351', 'pgregh14@gov.uk');
insert into student (first_name, last_name, studentid, email) values ('Pepi', 'Hardbattle', '0153301880', 'phardbattle15@toplist.cz');
insert into student (first_name, last_name, studentid, email) values ('Ave', 'Hulland', '9342553443', 'ahulland16@webs.com');
insert into student (first_name, last_name, studentid, email) values ('Jeni', 'Jirka', '4062465469', 'jjirka17@yellowbook.com');
insert into student (first_name, last_name, studentid, email) values ('Alden', 'Ransfield', '7733324823', 'aransfield18@census.gov');
insert into student (first_name, last_name, studentid, email) values ('Frankie', 'Decourcy', '2810554145', 'fdecourcy19@cdc.gov');
insert into student (first_name, last_name, studentid, email) values ('Margi', 'Midghall', '9649982523', 'mmidghall1a@go.com');
insert into student (first_name, last_name, studentid, email) values ('Perkin', 'Coleshill', '3457166706', 'pcoleshill1b@opensource.org');
insert into student (first_name, last_name, studentid, email) values ('Sharia', 'Cutteridge', '8498797292', 'scutteridge1c@stanford.edu');
insert into student (first_name, last_name, studentid, email) values ('Tiffi', 'Cripwell', '2897025573', 'tcripwell1d@meetup.com');
insert into student (first_name, last_name, studentid, email) values ('Babara', 'Muldowney', '4744313973', 'bmuldowney1e@go.com');
insert into student (first_name, last_name, studentid, email) values ('Fax', 'Viscovi', '1986127133', 'fviscovi1f@yellowpages.com');
insert into student (first_name, last_name, studentid, email) values ('Liva', 'Keigher', '1358996032', 'lkeigher1g@webeden.co.uk');
insert into student (first_name, last_name, studentid, email) values ('Kellen', 'Firmin', '4993836252', 'kfirmin1h@google.es');
insert into student (first_name, last_name, studentid, email) values ('Helli', 'Shiliton', '7192922854', 'hshiliton1i@xrea.com');
insert into student (first_name, last_name, studentid, email) values ('Curcio', 'Syfax', '0254990363', 'csyfax1j@oracle.com');
insert into student (first_name, last_name, studentid, email) values ('Ichabod', 'Wiggall', '7832442530', 'iwiggall1k@noaa.gov');
insert into student (first_name, last_name, studentid, email) values ('Iormina', 'Bedell', '3296640347', 'ibedell1l@cbslocal.com');
insert into student (first_name, last_name, studentid, email) values ('Zenia', 'Spadeck', '9783880438', 'zspadeck1m@1688.com');
insert into student (first_name, last_name, studentid, email) values ('Shirley', 'Kroch', '6943925547', 'skroch1n@clickbank.net');
insert into student (first_name, last_name, studentid, email) values ('Kale', 'Verlinde', '4235029797', 'kverlinde1o@phpbb.com');
insert into student (first_name, last_name, studentid, email) values ('Pierrette', 'Kilcoyne', '2445556953', 'pkilcoyne1p@studiopress.com');
insert into student (first_name, last_name, studentid, email) values ('Alla', 'Woodward', '5775694295', 'awoodward1q@bluehost.com');
insert into student (first_name, last_name, studentid, email) values ('Jami', 'Carter', '9560473611', 'jcarter1r@reference.com');
insert into student (first_name, last_name, studentid, email) values ('Bailey', 'Stickel', '9524289938', 'bstickel1s@pinterest.com');
insert into student (first_name, last_name, studentid, email) values ('Neda', 'Breslin', '4975653931', 'nbreslin1t@histats.com');
insert into student (first_name, last_name, studentid, email) values ('Carrie', 'Joslow', '1096613921', 'cjoslow1u@house.gov');
insert into student (first_name, last_name, studentid, email) values ('Pansy', 'Brangan', '2354433816', 'pbrangan1v@usa.gov');
insert into student (first_name, last_name, studentid, email) values ('Cam', 'Watters', '8447856593', 'cwatters1w@gov.uk');
insert into student (first_name, last_name, studentid, email) values ('Petra', 'Stappard', '3297343338', 'pstappard1x@odnoklassniki.ru');
insert into student (first_name, last_name, studentid, email) values ('Linell', 'Viles', '7612687801', 'lviles1y@thetimes.co.uk');
insert into student (first_name, last_name, studentid, email) values ('Quillan', 'Matteuzzi', '2660897131', 'qmatteuzzi1z@histats.com');
insert into student (first_name, last_name, studentid, email) values ('Fedora', 'Parsonage', '1033453048', 'fparsonage20@independent.co.uk');
insert into student (first_name, last_name, studentid, email) values ('Nedda', 'Lathleiffure', '4752343029', 'nlathleiffure21@sitemeter.com');
insert into student (first_name, last_name, studentid, email) values ('Tadeo', 'Conichie', '8847579724', 'tconichie22@yolasite.com');
insert into student (first_name, last_name, studentid, email) values ('Masha', 'Scotchbrook', '3398722040', 'mscotchbrook23@google.com.br');
insert into student (first_name, last_name, studentid, email) values ('Crystal', 'Dring', '2080366777', 'cdring24@histats.com');
insert into student (first_name, last_name, studentid, email) values ('Mikaela', 'Frowd', '2483089542', 'mfrowd25@opera.com');
insert into student (first_name, last_name, studentid, email) values ('Chev', 'Lumley', '2517537240', 'clumley26@businessweek.com');
insert into student (first_name, last_name, studentid, email) values ('Cosimo', 'Buncom', '4226095154', 'cbuncom27@wired.com');
insert into student (first_name, last_name, studentid, email) values ('Emera', 'McCallum', '3244486797', 'emccallum28@yellowbook.com');
insert into student (first_name, last_name, studentid, email) values ('Darrin', 'Tearny', '7377351616', 'dtearny29@ameblo.jp');
insert into student (first_name, last_name, studentid, email) values ('Courtenay', 'Barthrop', '3691984622', 'cbarthrop2a@shareasale.com');
insert into student (first_name, last_name, studentid, email) values ('Rosaleen', 'Hunnisett', '8899644691', 'rhunnisett2b@flavors.me');
insert into student (first_name, last_name, studentid, email) values ('Alis', 'Swinerd', '6823237538', 'aswinerd2c@shop-pro.jp');
insert into student (first_name, last_name, studentid, email) values ('Nickie', 'Gettone', '9693091418', 'ngettone2d@storify.com');
insert into student (first_name, last_name, studentid, email) values ('Shanda', 'Hardern', '6164682258', 'shardern2e@admin.ch');
insert into student (first_name, last_name, studentid, email) values ('Livvy', 'Pringell', '6488297074', 'lpringell2f@yahoo.com');
insert into student (first_name, last_name, studentid, email) values ('Ursa', 'Waddup', '0957238215', 'uwaddup2g@miibeian.gov.cn');
insert into student (first_name, last_name, studentid, email) values ('Madelene', 'Hallows', '3492804241', 'mhallows2h@auda.org.au');
insert into student (first_name, last_name, studentid, email) values ('Vivianne', 'Rousby', '4796697810', 'vrousby2i@w3.org');
insert into student (first_name, last_name, studentid, email) values ('Carlee', 'McPhail', '7511365299', 'cmcphail2j@uol.com.br');
insert into student (first_name, last_name, studentid, email) values ('Timothea', 'Welchman', '4320497694', 'twelchman2k@shinystat.com');
insert into student (first_name, last_name, studentid, email) values ('Rourke', 'McKeefry', '2009300467', 'rmckeefry2l@answers.com');
insert into student (first_name, last_name, studentid, email) values ('Filide', 'McKerron', '1531159826', 'fmckerron2m@posterous.com');
insert into student (first_name, last_name, studentid, email) values ('Neville', 'Crispin', '9731914080', 'ncrispin2n@twitter.com');
insert into student (first_name, last_name, studentid, email) values ('Karia', 'Lambdin', '1589651251', 'klambdin2o@mozilla.org');
insert into student (first_name, last_name, studentid, email) values ('Christel', 'Andrews', '7978854698', 'candrews2p@apple.com');
insert into student (first_name, last_name, studentid, email) values ('Bertie', 'Thieme', '9454042653', 'bthieme2q@gov.uk');
insert into student (first_name, last_name, studentid, email) values ('Zahara', 'Cotterill', '5783352640', 'zcotterill2r@mac.com');

insert into club (club_name, club_email, establish_time) values ('Johnston-O''Conner', 'mthuillier0@networksolutions.com', '2021-03-20');
insert into club (club_name, club_email, establish_time) values ('Muller-Thiel', 'yclubb1@nih.gov', '2021-04-11');
insert into club (club_name, club_email, establish_time) values ('Donnelly, Osinski and Nikolaus', 'eronayne2@tuttocitta.it', '2021-08-03');
insert into club (club_name, club_email, establish_time) values ('Spinka, Crona and Stracke', 'fbastin3@tinyurl.com', '2021-07-27');
insert into club (club_name, club_email, establish_time) values ('Koelpin and Sons', 'sheales4@tiny.cc', '2021-04-16');
insert into club (club_name, club_email, establish_time) values ('Bahringer-Little', 'fblazynski5@t-online.de', '2021-07-22');
insert into club (club_name, club_email, establish_time) values ('McGlynn, Parisian and Corwin', 'cskaife6@google.co.jp', '2021-05-08');
insert into club (club_name, club_email, establish_time) values ('Schuster Group', 'ggettings7@theatlantic.com', '2021-06-05');
insert into club (club_name, club_email, establish_time) values ('Aufderhar, Maggio and Grimes', 'mblincow8@hexun.com', '2020-12-08');
insert into club (club_name, club_email, establish_time) values ('Mante-Simonis', 'swoodman9@kickstarter.com', '2020-11-24');
insert into club (club_name, club_email, establish_time) values ('Prosacco, Waters and Dickinson', 'dpendergasta@vimeo.com', '2021-06-17');
insert into club (club_name, club_email, establish_time) values ('Stehr, Daniel and Ortiz', 'jholdb@ustream.tv', '2021-01-14');
insert into club (club_name, club_email, establish_time) values ('Abbott and Sons', 'gsharrocksc@blogtalkradio.com', '2020-09-06');
insert into club (club_name, club_email, establish_time) values ('Jacobi Group', 'ayuranovevd@china.com.cn', '2021-02-09');
insert into club (club_name, club_email, establish_time) values ('Nolan and Sons', 'tthomasone@weebly.com', '2020-11-17');
insert into club (club_name, club_email, establish_time) values ('Johns, Ferry and Walsh', 'olustedf@photobucket.com', '2020-10-14');
insert into club (club_name, club_email, establish_time) values ('Rowe and Sons', 'nbreadg@oracle.com', '2021-04-02');
insert into club (club_name, club_email, establish_time) values ('Hickle-Conroy', 'gdigweedh@reference.com', '2021-05-25');
insert into club (club_name, club_email, establish_time) values ('Lindgren-Deckow', 'rportwainei@eventbrite.com', '2021-02-25');
insert into club (club_name, club_email, establish_time) values ('Schinner-Mitchell', 'smanleyj@tamu.edu', '2020-11-15');
insert into club (club_name, club_email, establish_time) values ('Hoeger, Bruen and Corwin', 'ahinckesmank@timesonline.co.uk', '2021-05-09');
insert into club (club_name, club_email, establish_time) values ('Beier Inc', 'bhurdedgel@artisteer.com', '2020-11-28');
insert into club (club_name, club_email, establish_time) values ('Reichert Group', 'gbaversorm@harvard.edu', '2021-07-06');
insert into club (club_name, club_email, establish_time) values ('Smitham, Boehm and Glover', 'amcmullenn@live.com', '2020-10-24');
insert into club (club_name, club_email, establish_time) values ('Cummerata, Brown and Beier', 'aellseo@flavors.me', '2020-12-15');
insert into club (club_name, club_email, establish_time) values ('Kub, Quigley and Heathcote', 'crayntonp@auda.org.au', '2021-02-11');
insert into club (club_name, club_email, establish_time) values ('Spinka, Cole and Runte', 'ashemminq@networkadvertising.org', '2020-09-28');
insert into club (club_name, club_email, establish_time) values ('Reichert Group', 'cspendlover@amazon.com', '2021-02-08');
insert into club (club_name, club_email, establish_time) values ('Mayer-Beahan', 'voclovans@bandcamp.com', '2020-09-24');
insert into club (club_name, club_email, establish_time) values ('Auer-Doyle', 'lrubinszteint@japanpost.jp', '2020-11-16');
insert into club (club_name, club_email, establish_time) values ('Toy Inc', 'jeitteru@reference.com', '2021-02-23');
insert into club (club_name, club_email, establish_time) values ('Lubowitz, Watsica and Runolfsdottir', 'edeguisev@dyndns.org', '2021-08-20');
insert into club (club_name, club_email, establish_time) values ('Rolfson, Kirlin and Kris', 'ncussonsw@epa.gov', '2021-07-11');
insert into club (club_name, club_email, establish_time) values ('Cummings Group', 'rsymex@tinypic.com', '2020-12-28');
insert into club (club_name, club_email, establish_time) values ('Bartell, Koch and Willms', 'wjurgenseny@paypal.com', '2021-01-19');
insert into club (club_name, club_email, establish_time) values ('Hilpert, Bernier and Blick', 'abromfieldz@shutterfly.com', '2020-11-27');
insert into club (club_name, club_email, establish_time) values ('Hansen, Hahn and O''Keefe', 'aroofe10@washington.edu', '2021-05-04');
insert into club (club_name, club_email, establish_time) values ('Russel-Harvey', 'jzavattero11@illinois.edu', '2021-07-02');
insert into club (club_name, club_email, establish_time) values ('Mosciski, Conn and Kuhic', 'sjendas12@privacy.gov.au', '2021-07-11');
insert into club (club_name, club_email, establish_time) values ('Deckow-Walsh', 'rnowakowski13@sakura.ne.jp', '2021-06-18');
insert into club (club_name, club_email, establish_time) values ('Huels-Hahn', 'mgrieveson14@mozilla.org', '2020-09-08');
insert into club (club_name, club_email, establish_time) values ('O''Connell, Buckridge and Zieme', 'ralaway15@cnn.com', '2021-07-10');
insert into club (club_name, club_email, establish_time) values ('Kuphal, Gislason and Quigley', 'pleatherborrow16@networksolutions.com', '2021-05-03');
insert into club (club_name, club_email, establish_time) values ('Zemlak Inc', 'akingerby17@netlog.com', '2021-01-13');
insert into club (club_name, club_email, establish_time) values ('Kovacek Inc', 'twaren18@europa.eu', '2021-07-18');
insert into club (club_name, club_email, establish_time) values ('Conroy-West', 'esimner19@unesco.org', '2021-03-31');
insert into club (club_name, club_email, establish_time) values ('Boyle-Abbott', 'scrossley1a@miibeian.gov.cn', '2021-07-07');
insert into club (club_name, club_email, establish_time) values ('Harber-Weissnat', 'nsutherden1b@theguardian.com', '2020-09-26');
insert into club (club_name, club_email, establish_time) values ('Cummerata-Corwin', 'tvoisey1c@prweb.com', '2021-01-09');
insert into club (club_name, club_email, establish_time) values ('Daugherty and Sons', 'phabbeshaw1d@ebay.co.uk', '2021-07-21');
insert into club (club_name, club_email, establish_time) values ('Lindgren LLC', 'ktodarini1e@blog.com', '2020-12-17');
insert into club (club_name, club_email, establish_time) values ('Wilderman Group', 'kdoulden1f@hostgator.com', '2021-05-03');
insert into club (club_name, club_email, establish_time) values ('Schimmel LLC', 'idemerida1g@columbia.edu', '2021-02-16');
insert into club (club_name, club_email, establish_time) values ('Hane, Ryan and Blanda', 'ebaselli1h@businessweek.com', '2020-12-01');
insert into club (club_name, club_email, establish_time) values ('Baumbach-Wuckert', 'aflacknoe1i@gov.uk', '2021-08-13');
insert into club (club_name, club_email, establish_time) values ('McCullough LLC', 'eannesley1j@trellian.com', '2020-10-16');
insert into club (club_name, club_email, establish_time) values ('Tillman and Sons', 'mcomizzoli1k@163.com', '2020-12-23');
insert into club (club_name, club_email, establish_time) values ('Cummings LLC', 'mwhatmough1l@joomla.org', '2021-01-06');
insert into club (club_name, club_email, establish_time) values ('Hickle-Gutmann', 'tscarf1m@state.tx.us', '2021-04-11');
insert into club (club_name, club_email, establish_time) values ('Ullrich, Heidenreich and Heaney', 'lollington1n@wix.com', '2021-04-29');
insert into club (club_name, club_email, establish_time) values ('Homenick LLC', 'mbootes1o@usda.gov', '2020-10-09');
insert into club (club_name, club_email, establish_time) values ('Dooley, Raynor and Jaskolski', 'blegier1p@i2i.jp', '2020-08-29');
insert into club (club_name, club_email, establish_time) values ('Schaden, Hoeger and Little', 'kmacneilly1q@wikipedia.org', '2021-04-29');
insert into club (club_name, club_email, establish_time) values ('Pfeffer, Wyman and Morissette', 'dlettuce1r@sina.com.cn', '2020-11-19');
insert into club (club_name, club_email, establish_time) values ('Cole, Koss and Prohaska', 'dtourville1s@typepad.com', '2021-01-08');
insert into club (club_name, club_email, establish_time) values ('Wolff-Wintheiser', 'creame1t@wsj.com', '2020-11-18');
insert into club (club_name, club_email, establish_time) values ('Feest, Fadel and Klocko', 'ylofty1u@fema.gov', '2021-08-14');
insert into club (club_name, club_email, establish_time) values ('Mosciski, Collier and Dach', 'cgething1v@si.edu', '2021-03-10');
insert into club (club_name, club_email, establish_time) values ('O''Connell, Swift and Moen', 'adelnevo1w@shareasale.com', '2021-02-21');
insert into club (club_name, club_email, establish_time) values ('Schowalter and Sons', 'pswithenby1x@moonfruit.com', '2021-03-02');
insert into club (club_name, club_email, establish_time) values ('Buckridge-McCullough', 'ocowing1y@slideshare.net', '2020-08-31');
insert into club (club_name, club_email, establish_time) values ('Kemmer-Walsh', 'rgodwin1z@princeton.edu', '2021-03-27');
insert into club (club_name, club_email, establish_time) values ('Ziemann-Schamberger', 'pbridgwood20@google.cn', '2021-01-30');
insert into club (club_name, club_email, establish_time) values ('Stiedemann-Rowe', 'arheam21@mysql.com', '2021-02-17');
insert into club (club_name, club_email, establish_time) values ('Sauer-Dickens', 'pwilloughby22@vinaora.com', '2021-01-24');
insert into club (club_name, club_email, establish_time) values ('Renner-Jenkins', 'cmowbray23@people.com.cn', '2020-11-04');
insert into club (club_name, club_email, establish_time) values ('Ward, Bosco and Runolfsdottir', 'hguerreau24@phoca.cz', '2020-10-27');
insert into club (club_name, club_email, establish_time) values ('Schoen Inc', 'dlavies25@ucsd.edu', '2021-04-10');
insert into club (club_name, club_email, establish_time) values ('Kuphal-Jaskolski', 'tworgan26@cnn.com', '2020-09-28');
insert into club (club_name, club_email, establish_time) values ('Reynolds, Parker and Wolff', 'markill27@webmd.com', '2021-03-23');
insert into club (club_name, club_email, establish_time) values ('Sauer and Sons', 'aglasson28@harvard.edu', '2020-11-21');
insert into club (club_name, club_email, establish_time) values ('Stiedemann, Cartwright and Mann', 'jverdun29@rediff.com', '2021-05-29');
insert into club (club_name, club_email, establish_time) values ('Connelly-Kessler', 'jbranwhite2a@howstuffworks.com', '2020-12-26');
insert into club (club_name, club_email, establish_time) values ('Lueilwitz, Bauch and Klocko', 'rvenning2b@webeden.co.uk', '2021-07-22');
insert into club (club_name, club_email, establish_time) values ('Vandervort and Sons', 'mredmain2c@addthis.com', '2021-02-26');
insert into club (club_name, club_email, establish_time) values ('Wilkinson-Williamson', 'jolyhane2d@wordpress.org', '2021-07-05');
insert into club (club_name, club_email, establish_time) values ('Miller LLC', 'mtrevena2e@altervista.org', '2021-02-21');
insert into club (club_name, club_email, establish_time) values ('Raynor-Trantow', 'aleifer2f@dropbox.com', '2021-02-05');
insert into club (club_name, club_email, establish_time) values ('Gerhold, Kerluke and Bode', 'seastbury2g@ning.com', '2021-06-26');
insert into club (club_name, club_email, establish_time) values ('Towne-Greenholt', 'hmccaughen2h@gnu.org', '2020-08-27');
insert into club (club_name, club_email, establish_time) values ('McCullough-Prosacco', 'mmingard2i@economist.com', '2021-06-12');
insert into club (club_name, club_email, establish_time) values ('Goodwin, Klocko and Veum', 'eaizik2j@mayoclinic.com', '2021-06-26');
insert into club (club_name, club_email, establish_time) values ('Keebler LLC', 'creboulet2k@gizmodo.com', '2020-11-30');
insert into club (club_name, club_email, establish_time) values ('Stracke Group', 'teickhoff2l@livejournal.com', '2020-10-16');
insert into club (club_name, club_email, establish_time) values ('Glover-Larson', 'dweben2m@wisc.edu', '2021-04-02');
insert into club (club_name, club_email, establish_time) values ('Stroman Inc', 'mpippard2n@constantcontact.com', '2020-10-31');
insert into club (club_name, club_email, establish_time) values ('Heller Group', 'hgoodliffe2o@cnet.com', '2021-03-28');
insert into club (club_name, club_email, establish_time) values ('Orn, Wiegand and Cummerata', 'rbudgeon2p@loc.gov', '2021-02-18');
insert into club (club_name, club_email, establish_time) values ('McGlynn and Sons', 'hocurneen2q@amazon.de', '2020-10-15');
insert into club (club_name, club_email, establish_time) values ('Beer-Reilly', 'jjeanet2r@jiathis.com', '2020-11-05');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into attendence
select t.studentid, c.club_name, c.club_email
from student t, club c
order by random()
limit 1000;
