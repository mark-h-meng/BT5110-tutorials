/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/
 
-- Mingzhe Xu
-- A0232022A

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/*
 The code is written for PostgreSQL 
*/

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
	For this project, I am willing to construct three tables which
indicate the match between Bitcoin address and its password, and also insert into the
table corresponding to these two entity sets. Moreover, during this process,
I randomly choose 1000 rows by Cartesian product as possible relationships
from these two entity sets.

	In table person_info, I have bitcoin_id as primary key. Same as table person_info,
table password_note has password as primary key. In table relationship,
it has 1000 rows of random cross productions as possible relationships. 

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

create table person_info (
	bitcoin_id  VARCHAR(64),
	first_name  VARCHAR(64),
	last_name   VARCHAR(64),
    primary key(bitcoin_id)
);


create table relationship(
	bitcoin_id    VARCHAR(64),
    password      VARCHAR(64)
);

create table password_note(
	password      VARCHAR(64),
	location      VARCHAR(64),
	email         VARCHAR(64),
	primary key(password)
);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into person_info (bitcoin_id, first_name, last_name) values ('1JaCprCU5oFn3tuz3A1FKxWJFosdeXU8hW', 'Auroora', 'Sainsberry');
insert into person_info (bitcoin_id, first_name, last_name) values ('14x4kwxfWNjk76unf5zMzvWxCqvFMd2HDL', 'Baudoin', 'Woodfin');
insert into person_info (bitcoin_id, first_name, last_name) values ('1E9xFHxCiw3YbemomF3cmmRWVn81RY8i9C', 'Lorenza', 'Hoble');
insert into person_info (bitcoin_id, first_name, last_name) values ('1NEfnCp2DsA5XXua6YbnCqdngTP9N5rWnv', 'Issi', 'Ducarne');
insert into person_info (bitcoin_id, first_name, last_name) values ('1BaL92g58LPq6tdhoAKXCMcnRh3dB5dRgG', 'Andriana', 'Finnigan');
insert into person_info (bitcoin_id, first_name, last_name) values ('1HDmdzwVWgyhFxKzJxyaPfpXKcoZ94oXq9', 'Lindsay', 'Drakers');
insert into person_info (bitcoin_id, first_name, last_name) values ('13N1YEvq1WypfwcTatAzzFQf7LxXQK6o1r', 'Galvan', 'Dowles');
insert into person_info (bitcoin_id, first_name, last_name) values ('15UfNsfXxsEcGmYAstpw9d8WdPYYyPaR3f', 'Anastasie', 'Arundell');
insert into person_info (bitcoin_id, first_name, last_name) values ('1JK9zZB99d9vUP54temkRWURENsTSqQLuA', 'Elga', 'Hasslocher');
insert into person_info (bitcoin_id, first_name, last_name) values ('1DwBrsFzRwTBczDrKLsXrUkucbvDUbptQL', 'Renault', 'Fahrenbach');
insert into person_info (bitcoin_id, first_name, last_name) values ('1CnWiisvLbrpW1QddWCf9L1jEWs2sdQEwo', 'Austin', 'Alenin');
insert into person_info (bitcoin_id, first_name, last_name) values ('1FRs486sfq6jfHYS5pTZYdC9CKEQrdKSiP', 'Desiree', 'Tissington');
insert into person_info (bitcoin_id, first_name, last_name) values ('1GJcHfzVEV5RtKRnnwatkDAjjzARbT5Q1R', 'Doroteya', 'Ruos');
insert into person_info (bitcoin_id, first_name, last_name) values ('1LxZm6tsEc9NZqgQDnbhP8QpeKvqwu2Sd5', 'Kellie', 'Winwright');
insert into person_info (bitcoin_id, first_name, last_name) values ('1MNHfJdEVzFYHHF42QTHQ31fmTVg6riy5n', 'Beatriz', 'Kermott');
insert into person_info (bitcoin_id, first_name, last_name) values ('1L3bcUn2H7TWJjyVtB9GYWEX613ym8gTUY', 'Avrit', 'Lamdin');
insert into person_info (bitcoin_id, first_name, last_name) values ('1MmW5qpE44e9C7fSv42edv53VHkaMtMZmE', 'Maridel', 'Darwin');
insert into person_info (bitcoin_id, first_name, last_name) values ('1G9pocS4cB2FFuBLXbhWEN3kvL5unSAwNg', 'Sileas', 'Raffels');
insert into person_info (bitcoin_id, first_name, last_name) values ('19RXd1zNmVN8xXJWkCFFWpQTY4kWzrf6kw', 'Amandi', 'Enga');
insert into person_info (bitcoin_id, first_name, last_name) values ('12G1fBrccJfZCNtQuBy1xjA2rZk23iQPK5', 'Dan', 'Pietasch');
insert into person_info (bitcoin_id, first_name, last_name) values ('13Un3a6GNUGhPK5gTv72yZS5UEfPFxhjpj', 'Thorin', 'Willcock');
insert into person_info (bitcoin_id, first_name, last_name) values ('1AojqHh2AfKEkXgYjXRNUUhB774M3BedFy', 'Ginny', 'Lobe');
insert into person_info (bitcoin_id, first_name, last_name) values ('19pywMQSGXKX8jVJbNdi4GN3R5DgaEr1jv', 'Franciskus', 'Heninghem');
insert into person_info (bitcoin_id, first_name, last_name) values ('1FhaUjFuW8W5PMF82caDRonMheWuf5uPod', 'Myrtice', 'Walisiak');
insert into person_info (bitcoin_id, first_name, last_name) values ('18CCZtN6kWVForPpqLNzzr8jHGjSChCaJg', 'Edith', 'Hollyland');
insert into person_info (bitcoin_id, first_name, last_name) values ('1BUexEDvY3LShifW23QoQWWjzmjgvTbw67', 'Christophorus', 'Marlen');
insert into person_info (bitcoin_id, first_name, last_name) values ('1FaqD6DwmQ1tZrNpt1QiZXgjY46LY96P32', 'Dela', 'Ashfold');
insert into person_info (bitcoin_id, first_name, last_name) values ('1BysAB2QPdtue9ah441AvqkWw8Bhjy3oKP', 'Deny', 'O''Connolly');
insert into person_info (bitcoin_id, first_name, last_name) values ('1MgZLxtY9imUo7dabMVYjihz3ypMLjpkyQ', 'Griz', 'Huyge');
insert into person_info (bitcoin_id, first_name, last_name) values ('1LvpXBES9tKzuh88ttLb99sdC92YTBdUWZ', 'Sharl', 'Bernardoni');
insert into person_info (bitcoin_id, first_name, last_name) values ('1GRrpDrsQhFZ2vbaXB7hRSZTtHojR8HC4i', 'Ebba', 'Beckley');
insert into person_info (bitcoin_id, first_name, last_name) values ('1J28fUySG1mKQTUCazDK38ofFMA1H5XJzp', 'Tomi', 'Potteridge');
insert into person_info (bitcoin_id, first_name, last_name) values ('12urEb4XaaeKBG68nf49wgxnQC7VaURQoc', 'Jeffie', 'Anyene');
insert into person_info (bitcoin_id, first_name, last_name) values ('1HdHbPBYxQD8d3XLxrrEsqhvKS4P21JMk9', 'Kristine', 'Widdop');
insert into person_info (bitcoin_id, first_name, last_name) values ('1KrDYMgnqGdkdBfV4HUBADDntvCGdFV1NS', 'Sargent', 'Lile');
insert into person_info (bitcoin_id, first_name, last_name) values ('173iivpS5uq2EQhw3bjHkX1srW3X2qgf2o', 'Simmonds', 'Rogeron');
insert into person_info (bitcoin_id, first_name, last_name) values ('1LB5yaK8rtZSNHHt3wjLCTd4ApDJ9XTQEW', 'Sanders', 'Addicote');
insert into person_info (bitcoin_id, first_name, last_name) values ('1Fh6sC4iXrq1T9AgKQhryfoKCvGFxXmux6', 'Oona', 'Tingey');
insert into person_info (bitcoin_id, first_name, last_name) values ('1NM6e21xEywBdbHe4quEjGnRDTfGNuHtof', 'Fianna', 'Beldan');
insert into person_info (bitcoin_id, first_name, last_name) values ('1AJGPVJsuoPTQ7naEqKAnrk3ichvkWV2r1', 'Erl', 'Calvert');
insert into person_info (bitcoin_id, first_name, last_name) values ('1KVHKufaoWzoyvTSpJMhiEM88NkfgfYZbt', 'Konstance', 'Sandal');
insert into person_info (bitcoin_id, first_name, last_name) values ('1N316c24EQiahFrd5f4nunWhMN3HYye6op', 'Bunnie', 'Nuzzi');
insert into person_info (bitcoin_id, first_name, last_name) values ('17xXFV4dY6cNfXwFDB7AFerV2bYB6kEnqX', 'Laurice', 'Pisculli');
insert into person_info (bitcoin_id, first_name, last_name) values ('18YFegNyC5juEm4J1LLsUta7wHmw1fuUw9', 'Halimeda', 'Train');
insert into person_info (bitcoin_id, first_name, last_name) values ('16PW5SNtEgQZ6YvV7AfZQfe926ZPCE2255', 'D''arcy', 'Lauritsen');
insert into person_info (bitcoin_id, first_name, last_name) values ('1PshMfCuZXPFVb6XinWASarWANwMBdfNCu', 'Terrence', 'Spatoni');
insert into person_info (bitcoin_id, first_name, last_name) values ('15GvtfadQU8gGpADJLBoWhu8yMHdgXszE4', 'Modesty', 'Benz');
insert into person_info (bitcoin_id, first_name, last_name) values ('1LzbAEMgtdNuBGebgtANRDEtaXdLuTMgRX', 'Conrade', 'Rankcom');
insert into person_info (bitcoin_id, first_name, last_name) values ('18fvRzSG158DMCG9hqHPNjYcGwf4WQUrmM', 'Debor', 'Wrates');
insert into person_info (bitcoin_id, first_name, last_name) values ('1P7zbKxQpVqNUS1Qwm3sSWqNLVkQFsATPV', 'Shalna', 'Willans');
insert into person_info (bitcoin_id, first_name, last_name) values ('17WXrZNbL27yKC4sUWFL4EK6WfnJzQ7B3c', 'Nina', 'Boseley');
insert into person_info (bitcoin_id, first_name, last_name) values ('1FibPy5bLPmhtpcWCFqkQypJdwBYiqRVfr', 'Michele', 'Podd');
insert into person_info (bitcoin_id, first_name, last_name) values ('1JzQGUYskEtbcfs4HBqxsM2v9GpfvvFMxj', 'Rhody', 'Janko');
insert into person_info (bitcoin_id, first_name, last_name) values ('13kYesvSgWbnu9NNKykbNFuoiXNYMB82bE', 'Pandora', 'Pretley');
insert into person_info (bitcoin_id, first_name, last_name) values ('184W1hHVBrSEt1k9h3UD8NZyKMtyuo7JN2', 'Garvey', 'Willmott');
insert into person_info (bitcoin_id, first_name, last_name) values ('1KsPaTSEew6FHt3ccAx7V9E2K7aGhqQ3ud', 'Dedra', 'Best');
insert into person_info (bitcoin_id, first_name, last_name) values ('1Hv5X3zjvBNFJcubVECCUcoz61VBRuU19S', 'Woodman', 'Flowerdew');
insert into person_info (bitcoin_id, first_name, last_name) values ('1F2Gw9beAAmyQTwsdN821unuMD4iZPpH6E', 'Carri', 'Okker');
insert into person_info (bitcoin_id, first_name, last_name) values ('1GUvgDuULR79w4JYngmgxByfn9dYUafNDG', 'Pierson', 'Zanini');
insert into person_info (bitcoin_id, first_name, last_name) values ('1PRw6sFaB8EhdM3ATER2ZVdQZ7JGh5sJfV', 'Elita', 'Krale');
insert into person_info (bitcoin_id, first_name, last_name) values ('1FKjociDQRLhec3hzFn9ubM5FDSHD4stMQ', 'Maryjo', 'Ghilardi');
insert into person_info (bitcoin_id, first_name, last_name) values ('1MmECELaEG2ahCY4F4NpRxkQqFD8qGSo3s', 'Ashlan', 'Caghy');
insert into person_info (bitcoin_id, first_name, last_name) values ('1L5TitoG1zqCMXScNzXe3QvQMSU6MN7t93', 'Warde', 'Spikeings');
insert into person_info (bitcoin_id, first_name, last_name) values ('1ExRaxsA4sTsc3qY57ZA9nKfw6S1fkSy7V', 'Tawnya', 'Osban');
insert into person_info (bitcoin_id, first_name, last_name) values ('1AthFqhMkJhUD2JbFSKDAXtogUwwhmTKir', 'Ezmeralda', 'Robertshaw');
insert into person_info (bitcoin_id, first_name, last_name) values ('17DX2XV2xbfuRB16ukbuycgpSzMLdJzuGG', 'Ellwood', 'Ebourne');
insert into person_info (bitcoin_id, first_name, last_name) values ('12aPeEDeFga1VoAL3weapaZoVHrggzD69a', 'Murial', 'Napoleone');
insert into person_info (bitcoin_id, first_name, last_name) values ('14cB2pZH1KxqAFrLqfCjvP2m5D5txBcdWd', 'Nickey', 'Wittke');
insert into person_info (bitcoin_id, first_name, last_name) values ('1L1ojkgJdpsgMi8nZCZFHTzXGbqrP7TamD', 'Arlyne', 'Creavan');
insert into person_info (bitcoin_id, first_name, last_name) values ('1GMGhbtSvJxPGYBEdYn7KyGFQuFQKPKbr', 'Monique', 'Kilfoyle');
insert into person_info (bitcoin_id, first_name, last_name) values ('17Nah7AhSQ712RQrsdpDLwtfLHjSChcYGX', 'Dorelia', 'Bulford');
insert into person_info (bitcoin_id, first_name, last_name) values ('13rFZPcWnpvbwHY3vtCEKHMxcDxyK4eRUH', 'Maribel', 'Lidgely');
insert into person_info (bitcoin_id, first_name, last_name) values ('16nDXpNadrLdiQ3feimUFiEJc3aVsfGGaM', 'Verine', 'Jelphs');
insert into person_info (bitcoin_id, first_name, last_name) values ('14ff7hV5vrNm3jeL6ZgUF14iCDAB1zdX1J', 'Toni', 'Jewiss');
insert into person_info (bitcoin_id, first_name, last_name) values ('1EyVCJtaqqTkufdSKt27sA3YHcpN9Ct6Qy', 'Thomasa', 'Downgate');
insert into person_info (bitcoin_id, first_name, last_name) values ('17N9tGbdVs1jy52ZJdw7Wtaqn2Honurgn4', 'Catharina', 'Hildred');
insert into person_info (bitcoin_id, first_name, last_name) values ('1LLcSTs82yNYK1qjtD2hqzAUHE4guHYMA5', 'Raviv', 'Edgler');
insert into person_info (bitcoin_id, first_name, last_name) values ('1L1zUZ45hLAZJzQNaWpxSmWtL82w8fsovJ', 'Chickie', 'Schrader');
insert into person_info (bitcoin_id, first_name, last_name) values ('1GS1tC8u6W3DuvUUk2r5FBn7tuiQmyENKK', 'Regine', 'Saur');
insert into person_info (bitcoin_id, first_name, last_name) values ('1ChbcKbbwGb6WCQAs4pWs9rYTFUA15o12P', 'Debbi', 'Prevost');
insert into person_info (bitcoin_id, first_name, last_name) values ('1uucLLEQEDyTyuN6EPibdT6th7ocyoKhA', 'Micky', 'Curedell');
insert into person_info (bitcoin_id, first_name, last_name) values ('1MTZAifpjTTiSm92eQQ3vC9KSSQPWMuuBW', 'Garth', 'Vellacott');
insert into person_info (bitcoin_id, first_name, last_name) values ('1JnPeSGx3r8qnsUQEXjrQnmpNw6nvw5QtX', 'Reeba', 'McCullen');
insert into person_info (bitcoin_id, first_name, last_name) values ('18y28V9vp4p3gPCsV5opvznjQWkhqZWqwb', 'Tobi', 'Collough');
insert into person_info (bitcoin_id, first_name, last_name) values ('1Mjkh7BwGwKBiNJYPSMTx5G6EJbMn8Z36C', 'Kelci', 'Vaughn');
insert into person_info (bitcoin_id, first_name, last_name) values ('1DXzAwnLnGnYgyE8fPriB1SbB8zCdmoLkp', 'Al', 'Pooly');
insert into person_info (bitcoin_id, first_name, last_name) values ('1uvDw8k4dbeooTucFWbDehropVjqKviB4', 'Ephrem', 'Dan');
insert into person_info (bitcoin_id, first_name, last_name) values ('1LneN3rH31qUiWmR3ru9GBdmc6WKjpepAp', 'Savina', 'Barff');
insert into person_info (bitcoin_id, first_name, last_name) values ('14t1oUgPX2kj3AQXp4NeGt2kMbvzcFbFtu', 'Gary', 'Knott');
insert into person_info (bitcoin_id, first_name, last_name) values ('19bYaM2mwv7yAep5zm8vFi3J6YUKVPVo4e', 'Gleda', 'Melbert');
insert into person_info (bitcoin_id, first_name, last_name) values ('164RZSdsSj9FH5JAc9ANKuUNFsj867StQQ', 'Doralia', 'Shilburne');
insert into person_info (bitcoin_id, first_name, last_name) values ('16PL5EzZ8iAsDRbs12LX2EkhVR6iqRJPeC', 'Ikey', 'Crebo');
insert into person_info (bitcoin_id, first_name, last_name) values ('1BqcHn9e7XkZLH6hzU6HSsQbZ2QcSF6TTZ', 'Lulu', 'Laws');
insert into person_info (bitcoin_id, first_name, last_name) values ('14YGEhSg7E8fyTwTR7FYSuXVsyHECsAUwi', 'Zach', 'Cane');
insert into person_info (bitcoin_id, first_name, last_name) values ('1Q82dMkhMbvxuc22zGShaoFX76ZV4ixH8D', 'Rod', 'Hadlington');
insert into person_info (bitcoin_id, first_name, last_name) values ('1FyYcHjKKBp2L89s3ENWgHyXo5fUrKBHvB', 'Charlena', 'Wemyss');
insert into person_info (bitcoin_id, first_name, last_name) values ('1DCFNKCJhku9z7V4hEeh5rtoighVVTLPMo', 'Alyssa', 'Prazor');
insert into person_info (bitcoin_id, first_name, last_name) values ('1AFvJGbETp1x4yt2PP9uDrYxJtyBDp55fn', 'Geoffrey', 'Craddock');
insert into person_info (bitcoin_id, first_name, last_name) values ('1Feg5Z1eJjY8whXyczibyP333qaPgGi1Rq', 'Corinne', 'Gobat');
insert into person_info (bitcoin_id, first_name, last_name) values ('12s3Q83yRgRLcidtAu1R4eiKEiBeYfhrDL', 'Hercules', 'Mapis');



insert into password_note (password, location, email) values ('VunkGu', '49549 Haas Plaza', 'jthews0@lycos.com');
insert into password_note (password, location, email) values ('BPE01ivHl3ot', '63 Vahlen Plaza', 'dfuller1@weibo.com');
insert into password_note (password, location, email) values ('Lv12hT01b', '4743 Manley Circle', 'rcragoe2@ifeng.com');
insert into password_note (password, location, email) values ('OfXqb2UldY1', '0 Daystar Pass', 'mstodd3@dion.ne.jp');
insert into password_note (password, location, email) values ('Xm6PRn6QcJ9', '797 Kennedy Junction', 'zmanion4@printfriendly.com');
insert into password_note (password, location, email) values ('3tsNjjmnYn', '3 Pennsylvania Park', 'lsavaage5@biblegateway.com');
insert into password_note (password, location, email) values ('Gbw3zs', '70458 Washington Drive', 'cbelverstone6@unc.edu');
insert into password_note (password, location, email) values ('AONuYkRd', '37 Moose Street', 'gdezamudio7@blogger.com');
insert into password_note (password, location, email) values ('shpmZsmOC', '68330 Prentice Street', 'rohanley8@angelfire.com');
insert into password_note (password, location, email) values ('mhk9kKCb15', '7 Morrow Way', 'kbroxton9@umn.edu');
insert into password_note (password, location, email) values ('dj5qEH8HTG8E', '03002 Del Mar Street', 'njanocha@histats.com');
insert into password_note (password, location, email) values ('ymS1NG6', '09 Bellgrove Way', 'skelwickb@npr.org');
insert into password_note (password, location, email) values ('AvrqwTOOP', '3600 Grover Hill', 'lbaruchc@sakura.ne.jp');
insert into password_note (password, location, email) values ('iDZ8dal0e2', '317 Mcguire Trail', 'gmushettd@de.vu');
insert into password_note (password, location, email) values ('X534LxuL', '1 Dawn Pass', 'mlilburnee@hibu.com');
insert into password_note (password, location, email) values ('t8YBLO1', '9 Jackson Avenue', 'rdillistonf@networkadvertising.org');
insert into password_note (password, location, email) values ('vaL8B8Or9smG', '2065 Summer Ridge Park', 'sdrainsg@jigsy.com');
insert into password_note (password, location, email) values ('8xxmxJ', '37 Shelley Pass', 'bcunninghamh@tripadvisor.com');
insert into password_note (password, location, email) values ('bohd8YwQeN', '68 Red Cloud Parkway', 'dmavini@adobe.com');
insert into password_note (password, location, email) values ('u7WdSZqfZZ', '31 Union Hill', 'eeltringhamj@istockphoto.com');
insert into password_note (password, location, email) values ('bhZ5PizyWM', '2182 Oak Crossing', 'sdomenck@meetup.com');
insert into password_note (password, location, email) values ('Swz4anup', '76 Summit Hill', 'wkobielal@reference.com');
insert into password_note (password, location, email) values ('ev8bRXJYYL', '63 Miller Pass', 'lmacm@squarespace.com');
insert into password_note (password, location, email) values ('WQAG33HyJmsY', '96 Truax Center', 'jissacn@about.com');
insert into password_note (password, location, email) values ('TrRoJxzt', '0 Goodland Avenue', 'ahaxleyo@people.com.cn');
insert into password_note (password, location, email) values ('hoOTuyZiw9dU', '66 Texas Place', 'apickoverp@reference.com');
insert into password_note (password, location, email) values ('pEyQYsj3O', '59024 Starling Plaza', 'mraymenq@archive.org');
insert into password_note (password, location, email) values ('Jd8HwFmeY', '8 Kenwood Hill', 'lgerbir@hc360.com');
insert into password_note (password, location, email) values ('5tQqYAIUT8r', '8 Forest Dale Lane', 'dsturzakers@google.es');
insert into password_note (password, location, email) values ('ScDgnaE3', '65983 Stang Crossing', 'nlishmundt@twitpic.com');
insert into password_note (password, location, email) values ('4YLGpe', '6 Randy Park', 'rcallisu@ycombinator.com');
insert into password_note (password, location, email) values ('JmB9XhUb', '8 Schlimgen Center', 'aoverpoolv@wikipedia.org');
insert into password_note (password, location, email) values ('fiPrOHZJ', '4 Meadow Valley Circle', 'rashw@wordpress.com');
insert into password_note (password, location, email) values ('Kozu3Z0fiR', '11 Russell Plaza', 'bthompsonx@earthlink.net');
insert into password_note (password, location, email) values ('EdBESXH', '55 Kropf Hill', 'nenderley@mozilla.org');
insert into password_note (password, location, email) values ('sorhbzD', '301 Jackson Parkway', 'gramiroz@adobe.com');
insert into password_note (password, location, email) values ('Y6lH92F', '295 Gulseth Point', 'hsicely10@wunderground.com');
insert into password_note (password, location, email) values ('154L5O9', '689 Stoughton Center', 'tweild11@house.gov');
insert into password_note (password, location, email) values ('74C8fqZdgmr', '36948 Lake View Place', 'sricketts12@comsenz.com');
insert into password_note (password, location, email) values ('FcWGBqHlhazO', '727 Monterey Terrace', 'fwoofendell13@artisteer.com');
insert into password_note (password, location, email) values ('2a6skXWjRku', '9627 Maple Lane', 'dfreear14@bloglovin.com');
insert into password_note (password, location, email) values ('K42YgQmNNEjd', '6369 Amoth Hill', 'cpaggitt15@nature.com');
insert into password_note (password, location, email) values ('FWhmx6jxNFs', '75 Hoffman Parkway', 'eelger16@drupal.org');
insert into password_note (password, location, email) values ('LE22DXxRqIP', '8 Jenna Road', 'mcombe17@jiathis.com');
insert into password_note (password, location, email) values ('cgCipeMy04k', '6601 Dwight Point', 'dband18@blogspot.com');
insert into password_note (password, location, email) values ('dH4VLGFReF4', '314 Meadow Valley Junction', 'aasprey19@rambler.ru');
insert into password_note (password, location, email) values ('6hBA9G5GyY', '07 Debs Hill', 'sosbaldeston1a@cocolog-nifty.com');
insert into password_note (password, location, email) values ('6Of5JvX', '8193 Dixon Crossing', 'oarmytage1b@telegraph.co.uk');
insert into password_note (password, location, email) values ('mAhHfj3Bkj', '0 Anniversary Street', 'bjerok1c@ed.gov');
insert into password_note (password, location, email) values ('eAxaDIp7', '563 Browning Center', 'tmaken1d@vinaora.com');
insert into password_note (password, location, email) values ('7bX5N7AVr4r', '59693 Dayton Trail', 'nmoyers1e@smugmug.com');
insert into password_note (password, location, email) values ('ZFO0q1BeJgLb', '27 Randy Street', 'fwaistall1f@google.fr');
insert into password_note (password, location, email) values ('SXVsC80L8b', '1217 Iowa Trail', 'dhearmon1g@cam.ac.uk');
insert into password_note (password, location, email) values ('GaqnMTWkjq', '2 Dunning Court', 'bverdun1h@wikispaces.com');
insert into password_note (password, location, email) values ('4UPYZZ', '6511 Forster Pass', 'npanting1i@youtu.be');
insert into password_note (password, location, email) values ('gwimeehQ', '7 Express Court', 'agogay1j@t.co');
insert into password_note (password, location, email) values ('dOi5uEec2ra', '99137 Bultman Pass', 'elittlewood1k@cafepress.com');
insert into password_note (password, location, email) values ('cRlNiDQ0x', '6 Summer Ridge Trail', 'csaffer1l@flavors.me');
insert into password_note (password, location, email) values ('RE9xvoqUIc', '23397 Fairfield Drive', 'hdorbon1m@sogou.com');
insert into password_note (password, location, email) values ('ODV48rY', '79 Sugar Alley', 'fantonowicz1n@w3.org');
insert into password_note (password, location, email) values ('ldpnnFBSxdr', '2969 Chive Parkway', 'lstarton1o@imgur.com');
insert into password_note (password, location, email) values ('prUfKV', '21136 Shopko Avenue', 'fjaeggi1p@businesswire.com');
insert into password_note (password, location, email) values ('GWmH1U', '49525 Stang Circle', 'gcyster1q@mail.ru');
insert into password_note (password, location, email) values ('Q0HP2se', '0 Boyd Center', 'mollerton1r@meetup.com');
insert into password_note (password, location, email) values ('y0nCOyFaTR', '15911 Bellgrove Pass', 'ksutlieff1s@edublogs.org');
insert into password_note (password, location, email) values ('oVB6c7hV7G2', '64 Coleman Place', 'mfranzel1t@de.vu');
insert into password_note (password, location, email) values ('Xckf2GfLdsX', '358 6th Place', 'nbuckerfield1u@ustream.tv');
insert into password_note (password, location, email) values ('4UQoTS', '12 Cardinal Junction', 'dgerram1v@bigcartel.com');
insert into password_note (password, location, email) values ('mkz0C4vP', '68216 Golf Lane', 'klafflina1w@dion.ne.jp');
insert into password_note (password, location, email) values ('vzX5Tge', '04569 Tennessee Street', 'clapthorn1x@stumbleupon.com');
insert into password_note (password, location, email) values ('g6FJZB1DJnn', '05 Pearson Park', 'fharner1y@washington.edu');
insert into password_note (password, location, email) values ('SnBMc0OtP', '62774 Spenser Street', 'krattery1z@diigo.com');
insert into password_note (password, location, email) values ('AAFGsQb6', '78350 Doe Crossing Street', 'tcranton20@ustream.tv');
insert into password_note (password, location, email) values ('dKsKf0', '3 Meadow Vale Parkway', 'kspellard21@salon.com');
insert into password_note (password, location, email) values ('evYHZbhY2NSf', '86 Ohio Street', 'cvispo22@devhub.com');
insert into password_note (password, location, email) values ('a9tTH104Y', '90 Dottie Terrace', 'mgouldsmith23@disqus.com');
insert into password_note (password, location, email) values ('qoWi6X97G', '482 Fisk Avenue', 'hkibard24@hubpages.com');
insert into password_note (password, location, email) values ('zTfU6SoNsu', '7 5th Crossing', 'lsills25@bravesites.com');
insert into password_note (password, location, email) values ('rQWXPcwt1es', '4085 Dexter Lane', 'abarense26@diigo.com');
insert into password_note (password, location, email) values ('0GzM4TwFe', '6712 Hazelcrest Trail', 'mhartop27@bloomberg.com');
insert into password_note (password, location, email) values ('pjdUBYaz', '3 Canary Crossing', 'gnucciotti28@imdb.com');
insert into password_note (password, location, email) values ('HQNnZSjjRAdV', '3799 Nobel Crossing', 'gcarder29@themeforest.net');
insert into password_note (password, location, email) values ('D2UYv9GFXlCs', '965 Bellgrove Terrace', 'lhubber2a@usa.gov');
insert into password_note (password, location, email) values ('CfhyiAf4T8s', '0022 Hanover Pass', 'afulks2b@surveymonkey.com');
insert into password_note (password, location, email) values ('AnhvBUzDQ4Pp', '57880 Fairview Park', 'rfarnan2c@360.cn');
insert into password_note (password, location, email) values ('skOv3x', '70 Thackeray Drive', 'swaterworth2d@sogou.com');
insert into password_note (password, location, email) values ('nXTgk5QzA', '8 Oakridge Pass', 'kmacmychem2e@wikispaces.com');
insert into password_note (password, location, email) values ('vNeKwC8Uflpf', '738 Marcy Place', 'ltant2f@networksolutions.com');
insert into password_note (password, location, email) values ('iNtsmGokjtwz', '8488 High Crossing Park', 'vrastall2g@cyberchimps.com');
insert into password_note (password, location, email) values ('rnviJ5q', '4835 Montana Plaza', 'jhurd2h@themeforest.net');
insert into password_note (password, location, email) values ('H8VgH8mU', '81650 Duke Lane', 'sclaibourn2i@ed.gov');
insert into password_note (password, location, email) values ('rIPjXHg', '27 Barnett Circle', 'cclaughton2j@e-recht24.de');
insert into password_note (password, location, email) values ('QilEFhC', '347 Surrey Circle', 'clodford2k@symantec.com');
insert into password_note (password, location, email) values ('T8ezBCec', '89821 Truax Street', 'aellershaw2l@china.com.cn');
insert into password_note (password, location, email) values ('sAKkYX7jmEU', '0 Charing Cross Point', 'mbelz2m@si.edu');
insert into password_note (password, location, email) values ('JAqkyCy0C', '378 Hauk Street', 'kkordes2n@about.me');
insert into password_note (password, location, email) values ('VQe7UgyWfH9o', '14351 Forster Center', 'bminto2o@marriott.com');
insert into password_note (password, location, email) values ('KeJxMeds', '49 Buena Vista Place', 'cshirer2p@hao123.com');
insert into password_note (password, location, email) values ('frP9oJtdLc', '78331 Golden Leaf Parkway', 'sclausen2q@bluehost.com');
insert into password_note (password, location, email) values ('EnY6U6v61l', '88113 Glendale Crossing', 'cgiraudat2r@unblog.fr');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
-- inert into second table 1000 rows
insert into relationship (
	select bitcoin_id,password from person_info,password_note)
	Order By random() Limit 1000;
	 






