/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/

/* Answers by A0218929N */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
This is a goalkeeper database that allows football managers to keep track
and perform analysis on goalkeepers to recruit. The two entity tables are 
called goalkeepers and clubs. The relationship table is called 
games_played_for.

The goalkeepers table has a serial primary key and its attributes are 
first name, last name, birth date and t-shirt number.

The clubs table has club name as primary key because the league authorities
do not allow clubs to have same names. Its other attributes are city, date 
of formation and club value.

The games_played_for table records the game played by a goalkeeper for a
club. This is a very liberal football league that allows goalkeepers to
move around. So, there is a many-to-many relationship as goalkeepers can
play for multiple clubs, and each club may have multiple goalkeepers.

The primary key is a serial game ID. The attributes are goalkeeper involved, 
club played for, number of goals saved by goalkeeper, whether it was a home
or away game. 

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE goalkeepers (
	goalkeeper_id SERIAL PRIMARY KEY,
	first_name VARCHAR(50) NOT NULL,
	last_name VARCHAR(50) NOT NULL,
	birth_date DATE NOT NULL,
	tshirt_number INT NOT NULL CHECK(tshirt_number BETWEEN 0 AND 100)
);

CREATE TABLE clubs (
	club_name VARCHAR(50) PRIMARY KEY,
	city VARCHAR(50) NOT NULL,
	date_of_formation DATE NOT NULL,
	club_value NUMERIC NOT NULL
);

CREATE TABLE games_played_for (
	game_id SERIAL PRIMARY KEY,
	club_name VARCHAR(50) NOT NULL,
	home_game BOOLEAN NOT NULL,
	goalkeeper_id INT NOT NULL,
	goals_saved INT NOT NULL CHECK(goals_saved >= 0),
	FOREIGN KEY (club_name) REFERENCES clubs(club_name),
	FOREIGN KEY (goalkeeper_id) REFERENCES goalkeepers(goalkeeper_id)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Humbert', 'Dinse', '12/11/1989', 41);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Alyss', 'Mouncey', '12/25/2002', 81);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Julia', 'Kiff', '10/2/1993', 30);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Keriann', 'Braunton', '10/2/1999', 87);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Kala', 'Birkhead', '6/13/2016', 7);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Norby', 'Plowell', '12/7/2010', 37);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Reta', 'Boanas', '7/25/2019', 39);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Luciano', 'Haresnape', '10/30/1986', 5);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Terrance', 'O''Driscole', '4/24/2016', 29);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('May', 'Liepina', '6/19/1996', 56);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Leshia', 'Osmon', '2/28/2020', 99);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Dag', 'Giovannoni', '7/31/1994', 23);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Quinta', 'Persent', '7/8/2010', 10);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Marie', 'Twining', '9/15/1995', 59);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Colver', 'Petrol', '6/1/2002', 21);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Samuel', 'Dorre', '3/10/1982', 40);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Lelia', 'Jarred', '8/18/2011', 52);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Emmett', 'Hacket', '10/3/1988', 58);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Zita', 'Linck', '6/18/2019', 35);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Don', 'Speed', '10/17/1997', 43);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Hermann', 'Bengal', '11/7/2016', 73);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Hastings', 'Cavet', '11/1/2011', 6);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Jae', 'Gilogly', '9/30/1986', 64);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Maris', 'Wanklyn', '5/18/2020', 82);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Cherlyn', 'Eates', '10/8/2017', 31);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Arlin', 'Dyet', '5/9/1993', 39);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Valdemar', 'MacKnight', '11/27/1981', 75);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Sean', 'Ovendale', '1/3/1996', 99);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Dulcea', 'Carlisso', '12/2/1985', 15);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Vladimir', 'Gillan', '5/20/2007', 23);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Hubey', 'Gotmann', '9/3/1984', 85);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Demetris', 'Tomkowicz', '7/14/1987', 2);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Hugues', 'Bigadike', '10/22/1985', 92);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Kinsley', 'Cromer', '1/24/1998', 8);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Kandy', 'McElory', '7/4/1982', 66);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Meta', 'Arnald', '9/26/1988', 52);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Elladine', 'Teager', '1/7/2001', 71);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Nettie', 'Lansley', '7/29/2020', 1);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Cristin', 'Laurenty', '1/21/1991', 9);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Arie', 'Hallgarth', '10/4/1983', 39);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Alon', 'Astbery', '10/10/2013', 63);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Gus', 'Clapperton', '3/31/2002', 25);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Roobbie', 'Dibley', '11/20/2018', 55);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Delcine', 'Simmon', '6/30/1999', 55);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Shelley', 'Lemerie', '11/27/1989', 87);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Pearce', 'Brownbridge', '5/8/1994', 97);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Thorstein', 'MacLeod', '11/16/2010', 77);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Doralia', 'Kensy', '8/27/2004', 28);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Alphonso', 'Jenicek', '10/30/2001', 34);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Melisa', 'Gotcliff', '5/9/2017', 27);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Jordon', 'Clemett', '8/8/1985', 20);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Dorolice', 'Orsay', '8/20/2012', 11);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Erminie', 'Pilipets', '5/15/2002', 1);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Lorita', 'Ridgway', '2/26/1986', 93);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Allie', 'McIlraith', '2/27/2018', 24);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Giraud', 'Yurocjhin', '9/8/1997', 55);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Stephannie', 'Wethered', '11/13/1990', 70);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Helsa', 'Render', '6/25/2021', 33);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Tamarra', 'Addyman', '4/17/1986', 80);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Wade', 'Gurden', '9/4/2019', 48);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Loretta', 'Ghest', '6/2/1981', 75);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Daryl', 'Crumley', '4/3/1985', 19);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Eddy', 'Ennever', '9/27/2009', 4);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Shari', 'Dyster', '4/23/2010', 55);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Ellie', 'McTrusty', '11/11/1988', 12);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Harrison', 'MacKessock', '3/16/2001', 38);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Glynis', 'Ragless', '8/10/2003', 23);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Jarvis', 'Klich', '11/28/1985', 80);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Giffard', 'Lundie', '11/25/1981', 48);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Gottfried', 'Robjents', '10/13/2021', 93);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Lauraine', 'Diss', '11/26/2005', 79);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Page', 'Cambden', '7/13/1995', 5);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Leelah', 'Lamperd', '3/30/2005', 21);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Northrup', 'Fillgate', '8/21/2004', 3);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Blaire', 'Bosward', '12/2/1985', 60);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Torrin', 'Blunn', '2/17/1985', 41);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Xenia', 'Mordan', '1/2/1997', 57);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Teodoro', 'Elmes', '2/15/2005', 90);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Pennie', 'Budnk', '1/23/1991', 42);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Murdock', 'Gullan', '2/18/2001', 24);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Geoffrey', 'Margerison', '1/28/2019', 19);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Lenora', 'Troy', '3/12/1983', 54);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Loise', 'Stack', '2/26/1992', 56);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Laureen', 'Ropp', '11/10/2003', 31);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Rock', 'Gillison', '5/26/2002', 60);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Bernita', 'Klainer', '12/4/1994', 76);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Timmi', 'Joysey', '9/27/2021', 68);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Cheri', 'Robertot', '7/24/2004', 73);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Frannie', 'Gareisr', '4/23/1999', 53);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Monique', 'Elijah', '12/21/1996', 6);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Leilah', 'Whiscard', '4/25/1986', 28);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Patricia', 'Allinson', '2/14/1984', 73);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Brandie', 'Broz', '4/11/1992', 75);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Olvan', 'Lauderdale', '10/31/1985', 75);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Merissa', 'Cabral', '12/22/2010', 25);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Billie', 'Bownass', '5/14/1986', 78);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Demetra', 'Di Napoli', '2/2/2002', 27);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Alyssa', 'Moisey', '1/4/2016', 78);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Vernen', 'Masi', '5/26/1991', 97);
insert into goalkeepers (first_name, last_name, birth_date, tshirt_number) values ('Sherman', 'Purkiss', '9/27/1982', 84);

insert into clubs (city, club_name, date_of_formation, club_value) values ('Cayambe', 'Cayambe Town', '10/22/1998', 252391073);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Podgortsy', 'Podgortsy County', '1/18/1997', 861583797);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Jiatou', 'Jiatou ﻿Athletic', '8/4/2009', 280272077);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Simpang', 'Simpang United', '6/29/2018', 528356184);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Jinping', 'Jinping ﻿Athletic', '9/16/2013', 836984457);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Qŭrghonteppa', 'Qŭrghonteppa Forest', '5/17/1991', 233279464);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Cinco Saltos', 'Cinco Saltos ﻿Athletic', '8/19/2020', 367003054);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Várzea', 'Várzea ﻿Athletic', '4/22/2000', 270589044);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Orong', 'Orong Villa', '3/26/2007', 863708013);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Badāmā', 'Badāmā United', '6/15/2008', 849250029);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Klampis', 'Klampis Forest', '4/16/2014', 244598952);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Maradi', 'Maradi Forest', '4/15/2016', 217205142);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Kampokpok', 'Kampokpok Town', '5/7/2008', 276195213);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Boksitogorsk', 'Boksitogorsk City', '8/24/2007', 239070060);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Sincé', 'Sincé United', '11/6/2017', 203790457);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Chai Nat', 'Chai Nat Forest', '8/19/2019', 828951572);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Huaidao', 'Huaidao Forest', '12/4/2001', 564076715);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Le Lamentin', 'Le Lamentin Villa', '5/28/2009', 459184563);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Zalishchyky', 'Zalishchyky County', '10/1/1992', 598364217);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Svoboda nad Úpou', 'Svoboda nad Úpou Town', '4/6/2018', 394079588);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Kuteynykove', 'Kuteynykove Town', '8/22/2010', 691115705);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Yur’yev-Pol’skiy', 'Yur’yev-Pol’skiy City', '12/28/2009', 178439863);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Grenoble', 'Grenoble County', '12/6/2004', 142692355);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Golubinci', 'Golubinci Forest', '3/30/2000', 832460330);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Jiangduo', 'Jiangduo ﻿Athletic', '4/19/2007', 467843702);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Tambaksumur', 'Tambaksumur United', '9/23/1994', 672421586);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Mundri', 'Mundri United', '6/26/2003', 782609741);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Pochinki', 'Pochinki City', '1/21/1992', 279663611);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Napoli', 'Napoli County', '7/15/2007', 907386093);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Cola', 'Cola Forest', '2/18/2015', 478176175);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Klatakan', 'Klatakan County', '11/27/2017', 849647744);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Ādīs Zemen', 'Ādīs Zemen United', '7/7/1994', 650302492);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Kobylí', 'Kobylí ﻿Athletic', '8/11/2011', 512737076);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Harrismith', 'Harrismith County', '4/3/1991', 833942467);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Belajen', 'Belajen ﻿Athletic', '10/23/1990', 230139161);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Satowebrang', 'Satowebrang Forest', '12/22/2003', 809461347);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Rentung', 'Rentung Town', '10/8/2005', 823279195);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Malakwal City', 'Malakwal City Villa', '5/3/2000', 278735572);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Shaheying', 'Shaheying Villa', '7/1/1993', 430678720);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Samut Prakan', 'Samut Prakan County', '4/18/2005', 841372763);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Tando Jām', 'Tando Jām City', '8/8/2001', 476852043);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Humble', 'Humble Forest', '12/11/2019', 732120052);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Obanazawa', 'Obanazawa ﻿Athletic', '12/16/1999', 176488241);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Vetrino', 'Vetrino United', '8/5/1995', 807176700);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Jenang Selatan', 'Jenang Selatan ﻿Athletic', '5/22/1999', 541021877);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Almargem do Bispo', 'Almargem do Bispo Town', '7/7/2019', 128140430);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Loshnitsa', 'Loshnitsa City', '8/30/1993', 622493661);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Shenglilu', 'Shenglilu United', '10/17/2001', 815884650);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Ning’an', 'Ning’an Forest', '11/3/1995', 400312213);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Pajé', 'Pajé Forest', '6/18/2012', 920988409);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Simpang', 'Simpang ﻿Athletic', '5/17/2006', 466030996);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Montgomery', 'Montgomery United', '5/22/2021', 152208352);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Chotcza', 'Chotcza Forest', '3/23/2015', 146143026);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Surcubamba', 'Surcubamba United', '5/26/2006', 537511922);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Balagon', 'Balagon City', '3/30/1992', 636493990);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Duzhou', 'Duzhou Town', '7/27/2011', 459466604);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Dieppe', 'Dieppe United', '3/2/2007', 479750305);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Nggelok', 'Nggelok County', '9/9/2012', 710085646);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Vila Franca de Xira', 'Vila Franca de Xira City', '5/18/2008', 126602518);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Shevchenkove', 'Shevchenkove ﻿Athletic', '10/15/1999', 735690707);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Tandel', 'Tandel ﻿Athletic', '8/14/2018', 886030016);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Enköping', 'Enköping ﻿Athletic', '7/29/1992', 778231579);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Sanxi', 'Sanxi Villa', '9/9/2011', 746898100);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Al Ḩarajah', 'Al Ḩarajah City', '12/6/2002', 658281550);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Kurmuk', 'Kurmuk City', '10/6/1990', 252188677);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Huangjing', 'Huangjing Forest', '5/8/2006', 393425228);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Berbera', 'Berbera County', '6/30/1999', 957069664);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Xieba', 'Xieba ﻿Athletic', '10/15/2011', 760826413);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Mlandizi', 'Mlandizi ﻿Athletic', '5/7/1991', 107698839);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Candon', 'Candon Town', '3/3/2006', 258819567);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Waipawa', 'Waipawa Forest', '4/30/2006', 467878759);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Zhonghekou', 'Zhonghekou County', '10/14/2000', 744960066);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Maputi', 'Maputi United', '5/2/2012', 736922748);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Oslo', 'Oslo United', '4/18/1990', 880269822);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Akropong', 'Akropong City', '2/12/2015', 734916507);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Jīma', 'Jīma Forest', '2/1/2001', 775139565);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Kristiansand S', 'Kristiansand S Town', '12/21/1999', 183729433);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Dongla', 'Dongla United', '12/25/1991', 704245578);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Meïganga', 'Meïganga ﻿Athletic', '5/14/1990', 478517468);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Philadelphia', 'Philadelphia Villa', '7/31/2017', 808950434);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Usuki', 'Usuki County', '8/26/1999', 126680037);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Arboga', 'Arboga United', '4/9/2007', 467212166);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Qiaotou', 'Qiaotou United', '9/1/2010', 799255147);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Stenungsund', 'Stenungsund Forest', '1/20/2009', 933820330);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Timba Lauk', 'Timba Lauk Villa', '5/15/1996', 949854659);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Saint John’s', 'Saint John’s City', '12/17/2011', 581029455);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Tha Wang Pha', 'Tha Wang Pha County', '11/18/2010', 229316803);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Bagiktinggang', 'Bagiktinggang Villa', '9/23/1995', 659097639);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Petite Anse', 'Petite Anse City', '11/7/1991', 280509123);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Beskolen', 'Beskolen Forest', '11/29/1993', 524951484);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Kebonan', 'Kebonan Villa', '1/11/2012', 928787857);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Zafar', 'Zafar Forest', '7/31/2001', 338301740);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Jantake', 'Jantake ﻿Athletic', '11/13/1995', 564649628);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Vaitogi', 'Vaitogi County', '8/14/2011', 413843582);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Sofiyivka', 'Sofiyivka ﻿Athletic', '2/22/2002', 644591131);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Sarakhs', 'Sarakhs Villa', '1/24/2012', 114425640);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Gakem', 'Gakem Villa', '12/21/2000', 675634867);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Tiebiancheng', 'Tiebiancheng United', '7/28/1994', 540385922);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Itatiba', 'Itatiba County', '11/24/2018', 691620745);
insert into clubs (city, club_name, date_of_formation, club_value) values ('Huangdu', 'Huangdu Villa', '10/9/2012', 769766878);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


INSERT INTO games_played_for (goalkeeper_id, club_name, home_game, goals_saved)
(SELECT 
	*, 
	random() > 0.5 AS home_game,
	floor(random() * 4)::int AS goals_saved
FROM (
	SELECT goalkeeper_id, club_name
	FROM goalkeepers, clubs
	ORDER BY random() LIMIT 1000
) as a);

