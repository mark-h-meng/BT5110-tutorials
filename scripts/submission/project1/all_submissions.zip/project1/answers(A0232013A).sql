/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for SQLite */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* The setting is in 1984Land. People in this country are constantly 
monitored, having microchips embedding in them so the government, or Big 
Brother, can constantly track where they go. This data is constantly pinged 
to the government servers and stored in the tables below. Due to space 
constraints, they are only able to store daily visitation data. This visitation
data is then processed by their algorithmn to determine if they are 
closely afflicated with the resistance movement. Once the algorithm deems 
them to be part of the resistance, they will be erased, or become 
"unpersons".

Recently, with the out break of COVID-19, they have found a new use for 
this tracking system. Using their location logs, they seek to determine 
who infected people have been in contact with to predict new clusters.
They call this "TraceTogether".

In this database:
- E1 is the citizen table. The fields are generally self explanatory, 
and to explain some of the less obvious ones: vaccine_taken refers to the
brand of vaccine that the citizen has been injected with. 
suspected_resistance is a value from 1 to 5, where 1 means that the 
citizen is not suspicious, and 5 is a citizen highly suspicious of being 
in the resistance movement, which acts against the government.
- E2 is the locations table. place and postal_code are self explanatory, 
and the dynamic_threat_level is a number from 0 to 9, with 0 meaning 
that the location is not at all suspicious, and with 9 making reference
to a location that is heavily affiliated with the resistance.
- R is the has_visted table. It shows where citizens have visited in the
10 days from 2021-12-12 to 2021-12-21.
*/


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS citizen (
	citizen_id VARCHAR(10) PRIMARY KEY NOT NULL,
	first_name VARCHAR(50) NOT NULL,
	last_name VARCHAR(50) NOT NULL,
	email VARCHAR(50) NOT NULL,
	gender VARCHAR(50) NOT NULL,
	mobile_number VARCHAR(50) NOT NULL,
	vaccine_taken VARCHAR(64) NOT NULL,
	suspected_resistance VARCHAR(1) NOT NULL
);

CREATE TABLE IF NOT EXISTS locations (
	place VARCHAR(64) NOT NULL,
	postal_code CHAR(12) NOT NULL,
	dynamic_threat_level VARCHAR(1) NOT NULL,
	PRIMARY KEY (place, postal_code)
);

CREATE TABLE IF NOT EXISTS has_visited (
	citizen_id VARCHAR(10) NOT NULL REFERENCES citizen (citizen_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
	place VARCHAR(64) NOT NULL,
	postal_code VARCHAR(12) NOT NULL,
	date_visited DATE NOT NULL,
	PRIMARY KEY (citizen_id, place, postal_code, date_visited),
	FOREIGN KEY (place, postal_code) REFERENCES locations (place, postal_code) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED
);


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (1, 'Andy', 'Hakonsen', 'ahakonsen0@ezinearticles.com', 'F', '80704878', 'Pfizer-BioNTech', 2);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (2, 'Torr', 'Children', 'tchildren1@t-online.de', 'M', '87041840', 'EpiVacCorona', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (3, 'Adel', 'Presdie', 'apresdie2@hatena.ne.jp', 'F', '94905085', 'Chinese Academy of Medical Sciences', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (4, 'Sky', 'Lockier', 'slockier3@multiply.com', 'M', '92073763', 'Abdala', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (5, 'Angy', 'Taig', 'ataig4@soup.io', 'F', '87341496', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (6, 'Alena', 'Leddie', 'aleddie5@ifeng.com', 'F', '80157189', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (7, 'Gregorio', 'Gorden', 'ggorden6@wikimedia.org', 'M', '80021743', 'Pfizer-BioNTech', 2);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (8, 'Marta', 'Koenen', 'mkoenen7@opera.com', 'F', '97824840', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (9, 'Hannie', 'Chaman', 'hchaman8@theatlantic.com', 'F', '83143802', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (10, 'Sydel', 'Bon', 'sbon9@amazon.com', 'F', '81539947', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (11, 'Josefina', 'Le Claire', 'jleclairea@google.it', 'F', '84939333', 'Pfizer-BioNTech', 3);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (12, 'Anna-diana', 'Lesper', 'alesperb@networkadvertising.org', 'F', '94193498', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (13, 'Logan', 'Fernehough', 'lfernehoughc@bandcamp.com', 'M', '92609454', 'Moderna', 2);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (14, 'Harriet', 'Nockells', 'hnockellsd@domainmarket.com', 'F', '86644198', 'Johnson & Johnson/Janssen', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (15, 'Babette', 'McLese', 'bmclesee@census.gov', 'F', '93530376', 'Pfizer-BioNTech', 2);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (16, 'Fidel', 'Hitzschke', 'fhitzschkef@yelp.com', 'M', '84791904', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (17, 'Jaynell', 'Swire', 'jswireg@spiegel.de', 'F', '98335952', 'Abdala', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (18, 'Cecil', 'Cullrford', 'ccullrfordh@yale.edu', 'F', '91462568', 'Covivac', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (19, 'Sarette', 'Turneaux', 'sturneauxi@ehow.com', 'F', '98051726', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (20, 'Launce', 'Braiden', 'lbraidenj@miitbeian.gov.cn', 'M', '85421353', 'CoronaVac', 2);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (21, 'Tristan', 'Zoppie', 'tzoppiek@netlog.com', 'M', '82362580', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (22, 'Casandra', 'Hastelow', 'chastelowl@cisco.com', 'F', '85739728', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (23, 'Felike', 'Paolacci', 'fpaolaccim@bloomberg.com', 'M', '96877727', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (24, 'Gilbert', 'Jeafferson', 'gjeaffersonn@wikipedia.org', 'M', '84953392', 'Pfizer-BioNTech', 5);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (25, 'Gaston', 'Copeman', 'gcopemano@mashable.com', 'M', '84075873', 'Pfizer-BioNTech', 4);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (26, 'Kevin', 'Walsham', 'kwalshamp@mtv.com', 'M', '80533060', 'Pfizer-BioNTech', 2);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (27, 'Kimbell', 'Brockhurst', 'kbrockhurstq@addthis.com', 'M', '87534268', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (28, 'Abbie', 'Lodder', 'alodderr@last.fm', 'F', '90601668', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (29, 'Rena', 'Bony', 'rbonys@reference.com', 'F', '88879859', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (30, 'Alberta', 'Snoxall', 'asnoxallt@usa.gov', 'F', '88895926', 'Soverana 02', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (31, 'Esdras', 'Fairham', 'efairhamu@bloglines.com', 'M', '83508565', 'Not Taken', 3);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (32, 'Sebastien', 'Chaffyn', 'schaffynv@tinyurl.com', 'M', '96736416', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (33, 'Baily', 'von Hagt', 'bvonhagtw@liveinternet.ru', 'M', '82713727', 'ZyCov-D', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (34, 'Carola', 'Krollman', 'ckrollmanx@google.nl', 'F', '81115401', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (35, 'Lief', 'Cockerton', 'lcockertony@amazon.co.uk', 'M', '86531329', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (36, 'Fitzgerald', 'Simpkiss', 'fsimpkissz@boston.com', 'M', '84815510', 'Covaxin', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (37, 'Caritta', 'Episcopio', 'cepiscopio10@amazonaws.com', 'F', '86251825', 'Pfizer-BioNTech', 2);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (38, 'Bogart', 'Cuddehay', 'bcuddehay11@twitpic.com', 'M', '98356718', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (39, 'Rodolfo', 'Trayes', 'rtrayes12@mit.edu', 'M', '98246550', 'Johnson & Johnson/Janssen', 3);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (40, 'Aila', 'Canto', 'acanto13@harvard.edu', 'F', '87581906', 'Oxford-AstraZeneca', 2);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (41, 'Haven', 'Syres', 'hsyres14@springer.com', 'M', '92765750', 'EpiVacCorona', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (42, 'Colet', 'Weatherby', 'cweatherby15@php.net', 'M', '83468762', 'Medigen', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (43, 'Benjamen', 'Miranda', 'bmiranda16@nasa.gov', 'M', '81151837', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (44, 'Barth', 'Mellmoth', 'bmellmoth17@icq.com', 'M', '92448546', 'Johnson & Johnson/Janssen', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (45, 'Stanislas', 'Semiras', 'ssemiras18@creativecommons.org', 'M', '82264769', 'Oxford-AstraZeneca', 5);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (46, 'Daniella', 'Drury', 'ddrury19@github.io', 'F', '80163468', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (47, 'Carmella', 'Beswell', 'cbeswell1a@apple.com', 'F', '89226436', 'Oxford-AstraZeneca', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (48, 'Ab', 'Ribchester', 'aribchester1b@symantec.com', 'M', '94942992', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (49, 'Karney', 'Bartolacci', 'kbartolacci1c@biglobe.ne.jp', 'M', '80799838', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (50, 'Kari', 'McOmish', 'kmcomish1d@un.org', 'F', '85082697', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (51, 'Hernando', 'Sandiford', 'hsandiford1e@github.com', 'M', '83864310', 'Johnson & Johnson/Janssen', 4);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (52, 'Jany', 'Hallifax', 'jhallifax1f@linkedin.com', 'F', '88590446', 'Not Taken', 2);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (53, 'Della', 'Grundwater', 'dgrundwater1g@sphinn.com', 'F', '80881428', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (54, 'Stevana', 'Bonnor', 'sbonnor1h@parallels.com', 'F', '88031726', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (55, 'Viviyan', 'Senior', 'vsenior1i@issuu.com', 'F', '93917263', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (56, 'Wilfrid', 'Riehm', 'wriehm1j@livejournal.com', 'M', '99219775', 'ZyCov-D', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (57, 'Dexter', 'Beckensall', 'dbeckensall1k@engadget.com', 'M', '98325296', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (58, 'Norry', 'Farraway', 'nfarraway1l@mozilla.org', 'M', '85612283', 'Not Taken', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (59, 'Mirabel', 'Oxnam', 'moxnam1m@google.fr', 'F', '97088283', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (60, 'Catherine', 'L''Episcopi', 'clepiscopi1n@thetimes.co.uk', 'F', '86357782', 'Not Taken', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (61, 'Stephine', 'Maytom', 'smaytom1o@disqus.com', 'F', '82395751', 'Covivac', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (62, 'Francklyn', 'Weakley', 'fweakley1p@army.mil', 'M', '82412308', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (63, 'Paulina', 'Iaduccelli', 'piaduccelli1q@youku.com', 'F', '97064921', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (64, 'Shermie', 'Lambie', 'slambie1r@reuters.com', 'M', '86270653', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (65, 'Christie', 'Deverill', 'cdeverill1s@apple.com', 'M', '93609211', 'Johnson & Johnson/Janssen', 5);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (66, 'Nanette', 'Mongin', 'nmongin1t@mediafire.com', 'F', '98732990', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (67, 'Alvie', 'Jansson', 'ajansson1u@constantcontact.com', 'M', '89269393', 'Minhai', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (68, 'Gannie', 'Petto', 'gpetto1v@topsy.com', 'M', '95643959', 'Moderna', 2);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (69, 'Horton', 'Andrin', 'handrin1w@skyrock.com', 'M', '87162353', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (70, 'Conny', 'Genicke', 'cgenicke1x@mozilla.com', 'F', '90670778', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (71, 'Janey', 'Tole', 'jtole1y@wikispaces.com', 'F', '93847200', 'Covaxin', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (72, 'Ole', 'Gallego', 'ogallego1z@gnu.org', 'M', '84247173', 'Johnson & Johnson/Janssen', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (73, 'Oswald', 'Dulinty', 'odulinty20@hubpages.com', 'M', '82774171', 'Moderna', 3);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (74, 'Fitzgerald', 'Chatburn', 'fchatburn21@xrea.com', 'M', '98867024', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (75, 'Wendeline', 'Matashkin', 'wmatashkin22@youku.com', 'F', '82612949', 'Johnson & Johnson/Janssen', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (76, 'Prent', 'Marty', 'pmarty23@nifty.com', 'M', '95559445', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (77, 'Berna', 'Wardhaw', 'bwardhaw24@vkontakte.ru', 'F', '94962742', 'Pfizer-BioNTech', 3);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (78, 'Iosep', 'MacDunlevy', 'imacdunlevy25@marriott.com', 'M', '89526780', 'Chinese Academy of Medical Sciences', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (79, 'Leandra', 'Branson', 'lbranson26@parallels.com', 'F', '81165725', 'Not Taken', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (80, 'Chiquia', 'Hanselman', 'chanselman27@time.com', 'F', '90799711', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (81, 'Ted', 'Jemison', 'tjemison28@mapquest.com', 'F', '82775572', 'Johnson & Johnson/Janssen', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (82, 'Dyanne', 'Molyneaux', 'dmolyneaux29@de.vu', 'F', '89757584', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (83, 'Betsy', 'Drewett', 'bdrewett2a@blog.com', 'F', '85486214', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (84, 'Cosimo', 'Gornal', 'cgornal2b@scribd.com', 'M', '83448974', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (85, 'Chris', 'Scotchford', 'cscotchford2c@army.mil', 'M', '93797692', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (86, 'Chaim', 'Bennett', 'cbennett2d@deviantart.com', 'M', '83522479', 'Moderna', 5);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (87, 'Daphne', 'Labon', 'dlabon2e@weibo.com', 'F', '80860007', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (88, 'Eilis', 'Sanpher', 'esanpher2f@goo.ne.jp', 'F', '99420962', 'Oxford-AstraZeneca', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (89, 'Melinda', 'Stallworth', 'mstallworth2g@examiner.com', 'F', '90938544', 'Sinopharm-WIBP', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (90, 'Jolee', 'Abrahart', 'jabrahart2h@ebay.com', 'F', '89181224', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (91, 'Jimmie', 'Geck', 'jgeck2i@addthis.com', 'M', '99352295', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (92, 'Cordelia', 'Beveridge', 'cbeveridge2j@google.es', 'F', '88202646', 'Pfizer-BioNTech', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (93, 'Dee', 'Roake', 'droake2k@loc.gov', 'F', '80433071', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (94, 'Remus', 'Lodewick', 'rlodewick2l@shareasale.com', 'M', '98385986', 'Sputnik V', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (95, 'Broderic', 'Cavolini', 'bcavolini2m@state.gov', 'M', '97885207', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (96, 'Vincents', 'Crowth', 'vcrowth2n@slashdot.org', 'M', '84891736', 'Pfizer-BioNTech', 4);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (97, 'Arch', 'Goggin', 'agoggin2o@sfgate.com', 'M', '80949641', 'Moderna', 2);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (98, 'Berry', 'Corringham', 'bcorringham2p@businessweek.com', 'F', '82799375', 'Moderna', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (99, 'Anabel', 'Erat', 'aerat2q@whitehouse.gov', 'F', '86123015', 'Covaxin', 1);
insert into citizen (citizen_id, first_name, last_name, email, gender, mobile_number, vaccine_taken, suspected_resistance) values (100, 'Fan', 'Shere', 'fshere2r@seattletimes.com', 'F', '82567247', 'Pfizer-BioNTech', 1);

insert into locations (place, postal_code, dynamic_threat_level) values ('Skidoo', '195993', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Twinder', '063656', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Yata', '496893', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Fatz', '396126', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Zoomlounge', '766842', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Tagtune', '821220', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Yodel', '055814', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Skyba', '495666', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Gabvine', '799805', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Devshare', '806879', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Rhyloo', '156391', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Katz', '630476', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Twitterbridge', '945822', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Rhycero', '108518', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Babblestorm', '540252', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Pixope', '005260', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Meembee', '191654', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Kwimbee', '835376', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Trupe', '196891', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Eabox', '184349', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Feedfish', '235107', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Eire', '346857', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Eadel', '605724', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Fivespan', '386067', 5);
insert into locations (place, postal_code, dynamic_threat_level) values ('Meedoo', '654193', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Twinte', '812989', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Demivee', '097439', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Eadel', '797046', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Browsebug', '670943', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Twimm', '438953', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Realcube', '768354', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Dabjam', '583864', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Bubbletube', '996064', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Topiclounge', '124624', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Blogpad', '624001', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Dabtype', '661003', 1);
insert into locations (place, postal_code, dynamic_threat_level) values ('Aimbu', '823243', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Demivee', '170172', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Tagpad', '892958', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Kwimbee', '706725', 2);
insert into locations (place, postal_code, dynamic_threat_level) values ('Flashpoint', '733933', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Tazz', '286165', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Babbleblab', '543103', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Brainverse', '683339', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Latz', '659540', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Zoonder', '037290', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Zooveo', '644341', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Pixonyx', '049757', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Twinder', '021087', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Avamm', '113792', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Zoomcast', '887678', 2);
insert into locations (place, postal_code, dynamic_threat_level) values ('Yodo', '936757', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('FakeHQ', '195999', 8);
insert into locations (place, postal_code, dynamic_threat_level) values ('Kazio', '608365', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Dabjam', '993700', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Wordtune', '264725', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Gigazoom', '455509', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Lazz', '293448', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Wikido', '415888', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Youbridge', '932296', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Browsezoom', '218398', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('BlogXS', '433371', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Demivee', '145584', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Jaloo', '212107', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Lazzy', '763246', 5);
insert into locations (place, postal_code, dynamic_threat_level) values ('Brightbean', '772495', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Skynoodle', '119685', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Browsetype', '893310', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('NotSuspicious', '392730', 9);
insert into locations (place, postal_code, dynamic_threat_level) values ('DefinitelyNotSuspicious', '053153', 9);
insert into locations (place, postal_code, dynamic_threat_level) values ('Jabbertype', '806572', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Jabbercube', '381535', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Zoomdog', '216563', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Yodel', '718770', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Devcast', '995974', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Topicstorm', '970732', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Eadel', '826000', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Tagopia', '030562', 3);
insert into locations (place, postal_code, dynamic_threat_level) values ('Quaxo', '797698', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Jabbertype', '141613', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Kazu', '996841', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Snaptags', '969078', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Dynazzy', '858026', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Rhyloo', '751694', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Lajo', '106032', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Thoughtbridge', '520727', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Oyoyo', '908696', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Yakijo', '945062', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Midel', '312128', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Trunyx', '567641', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Yodo', '245172', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Topicware', '607764', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Realbuzz', '212670', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Flashdog', '882242', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Riffpedia', '535523', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Ozu', '606600', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Zoomlounge', '907996', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Shuffledrive', '760847', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Zazio', '847136', 0);
insert into locations (place, postal_code, dynamic_threat_level) values ('Centimia', '601357', 0);


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Here we create a dummy date table to randomly populate the 
relationship table, and delete it after. */

CREATE TABLE date_visit (
	date_visited DATE
);

insert into date_visit (date_visited) values ('2021-12-12');
insert into date_visit (date_visited) values ('2021-12-13');
insert into date_visit (date_visited) values ('2021-12-14');
insert into date_visit (date_visited) values ('2021-12-15');
insert into date_visit (date_visited) values ('2021-12-16');
insert into date_visit (date_visited) values ('2021-12-17');
insert into date_visit (date_visited) values ('2021-12-18');
insert into date_visit (date_visited) values ('2021-12-19');
insert into date_visit (date_visited) values ('2021-12-20');
insert into date_visit (date_visited) values ('2021-12-21');

INSERT INTO has_visited (citizen_id, place, postal_code, date_visited)
SELECT citizen_id, place, postal_code, date_visited FROM citizen, locations, date_visit
ORDER BY random() limit(1000);

DROP TABLE date_visit;



