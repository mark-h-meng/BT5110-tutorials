/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* The first table is called grocery_membership. 
It is a table that contains some information about a person that signed up as a member of the grocery shop.
Within the table, it contains information such as a members's name, email, age, birth country, gender, job title and shirt size. 
The purpose of having these information is for analytics purposes where it provides insights on certain interesting relationships. 
For example, is there a correlation between gender and the type of food they usually buy ? 
or is there a stronger correlation between the type of food they buy depending on their job title, etc
For this table, the primary key is the membership ID and a combination of first, last name and email should be unique in hope to ensure that a person can only have 1 membership

The second table is called grocery_shop.
It is a table that contains specific information on the available products within the shop. 
For example, it has the name of the product, where the product was imported from, what color is the packaging and when the product will be expired.
The primary key is set as the item ID because each item should have a unique code to identify what a customer/member had bought. 

The last table / relationship table is called historical_unique_buys.
This table captures the specific unique items being bought by each member.
The membership ID is a foreign key as it is being referenced to the membership table while item ID is a foreign key that references the shop table.
This means that registered members cannot delete their membership and their historical purchases can always been retrieved.
In addition, items that had been imported and sold within the shop can always be retrieved from historical information. 
Lastly, the primary key is a combination of both IDs. This is because we want to know the unique items that each member had bought before. 
Overall, the information within the relationship table is useful as it can help to provide insights on certain relationships.
For example, is there a trend that a member who works as an engineer has a higher chance of buying a product from China instead of Indonesia ?
Alternatively, is there a trend that a member who wears a shirt size of L has a higher preference to buy more meat products instead of vegetables ?
In sum, these analysis are interesting and meaningful for the grocery store as they can focus on marketing strategies and 
type of products they want to import to optimize their profits.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS grocery_membership (
	id INT,
	membership_id VARCHAR(50) UNIQUE PRIMARY KEY,
	first_name VARCHAR(50) NOT NULL,
	last_name VARCHAR(50) NOT NULL,
	email VARCHAR(50) UNIQUE NOT NULL,
	age_at_registration INT NOT NULL,
	birth_country VARCHAR(50) NOT NULL,
	gender VARCHAR(50) NOT NULL,
	job_title VARCHAR(50) NOT NULL,
	shirt_size VARCHAR(50) NOT NULL,
    UNIQUE (first_name, last_name, email)
);

CREATE TABLE IF NOT EXISTS grocery_shop (
	id INT NOT NULL,
	items VARCHAR(50) NOT NULL,
	shipment_origin VARCHAR(50) NOT NULL,
    item_id VARCHAR(100) UNIQUE PRIMARY KEY,
	packaging_color VARCHAR(50) NOT NULL,
	expiry_date DATE
);

CREATE TABLE IF NOT EXISTS historical_unique_buys (
	grocery_membership_membership_id VARCHAR(100) NOT NULL,
    grocery_shop_item_id VARCHAR(100) NOT NULL,
    PRIMARY KEY (grocery_membership_membership_id, grocery_shop_item_id),
    FOREIGN KEY (grocery_membership_membership_id) REFERENCES grocery_membership(membership_id) ON UPDATE CASCADE,
    FOREIGN KEY (grocery_shop_item_id) REFERENCES grocery_shop(item_id) ON UPDATE CASCADE
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (1, 'ci8PURD4b6G', 'Aurilia', 'Checkley', 'acheckley0@msu.edu', 54, 'Libya', 'Male', 'Senior Financial Analyst', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (2, 'vnOBzdWvT4', 'Tanitansy', 'Seignior', 'tseignior1@linkedin.com', 16, 'Russia', 'Female', 'Desktop Support Technician', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (3, 'cVUurr', 'Nina', 'Haworth', 'nhaworth2@chron.com', 27, 'Colombia', 'Female', 'Pharmacist', 'XS');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (4, 'wxbMo89MXyF', 'Lane', 'Elsip', 'lelsip3@pinterest.com', 18, 'France', 'Female', 'Nurse', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (5, 'KHcYuPG', 'Bil', 'Gyngell', 'bgyngell4@google.com.br', 2, 'Ukraine', 'Female', 'Programmer I', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (6, 'IaToJ6ECT4', 'Kerrie', 'Wedge', 'kwedge5@4shared.com', 57, 'China', 'Female', 'Biostatistician I', 'XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (7, '7rntJPfmwh5', 'Morgun', 'L''oiseau', 'mloiseau6@bluehost.com', 14, 'Ireland', 'Male', 'Research Nurse', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (8, 'SrxRS2', 'Dru', 'De Cruce', 'ddecruce7@indiegogo.com', 35, 'China', 'Male', 'Help Desk Technician', 'XS');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (9, '98TcbndoP0', 'Tracie', 'Defew', 'tdefew8@quantcast.com', 57, 'China', 'Male', 'Compensation Analyst', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (10, 'eO2MRYmAbm', 'Rhetta', 'Impey', 'rimpey9@vistaprint.com', 25, 'China', 'Male', 'Human Resources Manager', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (11, 'AIBW5HS', 'Willie', 'Stokes', 'wstokesa@zdnet.com', 25, 'Vietnam', 'Male', 'Technical Writer', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (12, 'FOAGKLo5mM', 'Sharon', 'Gallaher', 'sgallaherb@bloglines.com', 29, 'Tanzania', 'Male', 'Software Engineer II', 'XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (13, 'f68vQ2VCw', 'Ursola', 'Theseira', 'utheseirac@google.de', 7, 'Sweden', 'Female', 'Librarian', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (14, 'B3qAAx9PF0wN', 'Dale', 'Schanke', 'dschanked@g.co', 52, 'Afghanistan', 'Female', 'Pharmacist', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (15, 'NmPIs6QVa', 'Viola', 'MacGuffog', 'vmacguffoge@discuz.net', 40, 'Russia', 'Female', 'Sales Associate', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (16, 'uByvd66Xhdt', 'Wendi', 'McMeeking', 'wmcmeekingf@un.org', 24, 'Mongolia', 'Male', 'Librarian', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (17, 'ZSN01rYXp', 'Karina', 'Dell''Abbate', 'kdellabbateg@foxnews.com', 27, 'Canada', 'Female', 'Information Systems Manager', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (18, 'A0ntADmh', 'Doro', 'Commins', 'dcomminsh@reuters.com', 49, 'Sweden', 'Male', 'Business Systems Development Analyst', 'XS');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (19, 'VNVBYc', 'Carin', 'Lisciandro', 'clisciandroi@arizona.edu', 20, 'China', 'Female', 'Mechanical Systems Engineer', 'XS');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (20, 'BLRpdvQkT', 'Nial', 'Kearford', 'nkearfordj@opera.com', 64, 'Indonesia', 'Female', 'Environmental Tech', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (21, 'i3LR8wEsnQ5b', 'Coral', 'Serrurier', 'cserrurierk@miitbeian.gov.cn', 13, 'France', 'Female', 'Project Manager', 'XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (22, 'N6RZKKdwUB4', 'Hastie', 'De Angelo', 'hdeangelol@bloomberg.com', 41, 'Panama', 'Female', 'Actuary', 'XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (23, '1dRWgRJyKGgp', 'Charyl', 'Axup', 'caxupm@un.org', 63, 'Iraq', 'Female', 'Software Test Engineer I', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (24, 'odxX6hj0OPBP', 'Constancy', 'Murcutt', 'cmurcuttn@ted.com', 16, 'Poland', 'Male', 'Accounting Assistant III', 'XS');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (25, 'kmUEd5', 'Brandon', 'Mathieson', 'bmathiesono@mapy.cz', 47, 'China', 'Female', 'Computer Systems Analyst I', 'XS');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (26, 'ENjb0kzRM3', 'Paula', 'Bummfrey', 'pbummfreyp@wiley.com', 2, 'China', 'Female', 'Health Coach IV', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (27, 'HYxDVlv', 'Grace', 'Chippindall', 'gchippindallq@nba.com', 3, 'Belarus', 'Male', 'Biostatistician II', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (28, 'hePIXr6EJ3s', 'Anna-maria', 'Vowells', 'avowellsr@wufoo.com', 65, 'United States', 'Female', 'Financial Advisor', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (29, 'xLFR6qjW', 'Harlin', 'Tax', 'htaxs@yahoo.co.jp', 37, 'Lesotho', 'Male', 'Senior Quality Engineer', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (30, 'FSgn2Il2n5y', 'Josee', 'Sizey', 'jsizeyt@1und1.de', 25, 'Indonesia', 'Female', 'VP Marketing', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (31, '3ahYgG', 'Oswell', 'Crepin', 'ocrepinu@wikia.com', 8, 'Poland', 'Female', 'VP Accounting', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (32, '3OXIMdDNJKFQ', 'My', 'Beckerleg', 'mbeckerlegv@ameblo.jp', 50, 'Poland', 'Female', 'Quality Engineer', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (33, 'mMKFTDFP4rr', 'Doti', 'Barnsley', 'dbarnsleyw@icq.com', 51, 'Czech Republic', 'Male', 'VP Quality Control', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (34, 'BDRZt1u36', 'Jana', 'Swire', 'jswirex@msu.edu', 32, 'Russia', 'Female', 'Marketing Assistant', 'XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (35, 'oX5jlf327', 'Stormie', 'Junkison', 'sjunkisony@rambler.ru', 59, 'Japan', 'Female', 'Social Worker', 'XS');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (36, 'CkHEzh', 'Spence', 'Worshall', 'sworshallz@canalblog.com', 34, 'Panama', 'Male', 'Accounting Assistant II', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (37, 'YZR5I50BrBM8', 'Pegeen', 'Easun', 'peasun10@geocities.com', 12, 'China', 'Male', 'General Manager', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (38, 'CvRXWp', 'Brandy', 'Stollsteiner', 'bstollsteiner11@multiply.com', 54, 'Mexico', 'Female', 'Editor', 'XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (39, '1vjbsL9uJGO', 'Dulce', 'McKeggie', 'dmckeggie12@google.ru', 49, 'France', 'Female', 'Assistant Media Planner', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (40, 'L4HivPcru', 'Mina', 'Harniman', 'mharniman13@japanpost.jp', 18, 'Nigeria', 'Male', 'VP Quality Control', '2XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (41, 'e1WWYvkCe', 'Christy', 'Wooster', 'cwooster14@topsy.com', 15, 'China', 'Female', 'VP Marketing', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (42, 'kacsANlC5bNH', 'Kikelia', 'Haney', 'khaney15@dot.gov', 6, 'Indonesia', 'Female', 'Administrative Officer', 'XS');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (43, 'ye0yRR', 'Jabez', 'Hambric', 'jhambric16@blogger.com', 21, 'Philippines', 'Male', 'Recruiting Manager', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (44, 'gGokwDXiJ7w', 'Tad', 'Sinnatt', 'tsinnatt17@uol.com.br', 54, 'France', 'Male', 'Database Administrator IV', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (45, 'Vs8e4b91ak', 'Demetris', 'Rabl', 'drabl18@army.mil', 2, 'Armenia', 'Male', 'Mechanical Systems Engineer', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (46, 'O9iKcOERgR', 'Tessa', 'Leman', 'tleman19@state.gov', 5, 'China', 'Female', 'Engineer I', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (47, 'evNxa5EmPm', 'Sharlene', 'Negri', 'snegri1a@sina.com.cn', 24, 'Brazil', 'Male', 'Environmental Tech', 'XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (48, '3azGdN3', 'Abramo', 'Linsay', 'alinsay1b@zimbio.com', 9, 'Chile', 'Female', 'Paralegal', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (49, 'wIeHpZCcN', 'Chrystal', 'Mattsson', 'cmattsson1c@ifeng.com', 5, 'China', 'Male', 'Senior Sales Associate', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (50, 'JUi8E3', 'Germain', 'Schuck', 'gschuck1d@github.com', 46, 'Brazil', 'Female', 'Graphic Designer', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (51, '7RET8Hld7q', 'Chryste', 'Jewes', 'cjewes1e@examiner.com', 28, 'China', 'Male', 'Software Test Engineer II', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (52, 'Qg3zH3Rqk', 'Irena', 'Blurton', 'iblurton1f@accuweather.com', 12, 'Portugal', 'Male', 'Programmer Analyst III', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (53, 'AoaHhu9w08', 'Raye', 'Claessens', 'rclaessens1g@wikimedia.org', 50, 'Indonesia', 'Male', 'Mechanical Systems Engineer', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (54, 'lbtls9gT', 'Jill', 'Plastow', 'jplastow1h@artisteer.com', 6, 'Suriname', 'Male', 'Sales Associate', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (55, 'QRmK7oQk', 'Alexina', 'Coulton', 'acoulton1i@blogs.com', 26, 'Indonesia', 'Female', 'Nurse', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (56, 'nqp9ibJaTmm9', 'Flem', 'Grocutt', 'fgrocutt1j@jalbum.net', 40, 'Japan', 'Female', 'Administrative Officer', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (57, '1Mc31JfXbA', 'Pammi', 'Lempel', 'plempel1k@simplemachines.org', 17, 'Brazil', 'Male', 'Senior Quality Engineer', '2XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (58, 'KYVGUSuR', 'Adolphe', 'Gibbin', 'agibbin1l@jigsy.com', 49, 'China', 'Female', 'Speech Pathologist', 'XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (59, 'TrmfWb', 'Germain', 'Tizard', 'gtizard1m@spiegel.de', 65, 'Philippines', 'Male', 'Cost Accountant', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (60, 'w4wssnRj', 'Sydney', 'Raiker', 'sraiker1n@trellian.com', 64, 'Tanzania', 'Male', 'Account Executive', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (61, 'j90Sse', 'Bradney', 'Pfaffe', 'bpfaffe1o@alexa.com', 60, 'Portugal', 'Female', 'Civil Engineer', '2XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (62, 'HsY5HGXG', 'Clarisse', 'Congreve', 'ccongreve1p@cbsnews.com', 33, 'Kazakhstan', 'Male', 'Software Engineer III', '2XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (63, 'MDLAsEuc6afQ', 'Mag', 'Forrest', 'mforrest1q@acquirethisname.com', 9, 'China', 'Male', 'Project Manager', 'XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (64, 'ozwN854', 'Jessie', 'McAw', 'jmcaw1r@skype.com', 56, 'Azerbaijan', 'Male', 'Speech Pathologist', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (65, 'L2kA4nX', 'Swen', 'Romayn', 'sromayn1s@imageshack.us', 31, 'Mexico', 'Female', 'Software Consultant', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (66, 'dGxnCG', 'Krystyna', 'Marrable', 'kmarrable1t@ed.gov', 24, 'China', 'Male', 'Marketing Assistant', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (67, 'bROLvbC4', 'Bogey', 'Braisted', 'bbraisted1u@cam.ac.uk', 25, 'Poland', 'Female', 'Research Associate', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (68, 'ywAVO3f', 'Alexandros', 'Habbert', 'ahabbert1v@alexa.com', 3, 'Greece', 'Male', 'Editor', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (69, '47BFCfZ', 'Chryste', 'Offa', 'coffa1w@mapy.cz', 11, 'France', 'Female', 'VP Marketing', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (70, 'z7gkCZaiY', 'Heath', 'Venditto', 'hvenditto1x@plala.or.jp', 1, 'Indonesia', 'Male', 'Staff Scientist', 'XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (71, '5A5OrkKHxFP', 'Crissie', 'Tincey', 'ctincey1y@photobucket.com', 6, 'Portugal', 'Female', 'Accountant I', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (72, 'JcG9o5Q2v', 'Adolf', 'Paulino', 'apaulino1z@psu.edu', 13, 'Brazil', 'Male', 'Business Systems Development Analyst', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (73, 'mVmOuAv3', 'Rick', 'Atherley', 'ratherley20@smugmug.com', 65, 'Russia', 'Male', 'Recruiter', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (74, 'lEfBf8cXg', 'Bryant', 'Glayzer', 'bglayzer21@wordpress.com', 59, 'Indonesia', 'Female', 'Web Designer III', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (75, 'icZh9D9JYJty', 'Simone', 'Leband', 'sleband22@comcast.net', 18, 'Czech Republic', 'Male', 'Quality Control Specialist', '2XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (76, 'dvP42SE2l', 'Richardo', 'Siviour', 'rsiviour23@nyu.edu', 59, 'Czech Republic', 'Male', 'Desktop Support Technician', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (77, 'UKcqmY', 'Muriel', 'Burdin', 'mburdin24@ox.ac.uk', 25, 'Argentina', 'Male', 'Geological Engineer', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (78, 'LMCuskX', 'Marlowe', 'Windebank', 'mwindebank25@merriam-webster.com', 13, 'Finland', 'Female', 'Project Manager', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (79, 'Q9lalQhaK4W', 'Constance', 'Yggo', 'cyggo26@senate.gov', 45, 'Philippines', 'Female', 'Software Engineer IV', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (80, 'KYE9kF', 'Sargent', 'Trinder', 'strinder27@theatlantic.com', 41, 'Philippines', 'Male', 'Senior Financial Analyst', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (81, 'rYIhPIk', 'Ulberto', 'Snugg', 'usnugg28@taobao.com', 48, 'China', 'Male', 'Systems Administrator I', 'M');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (82, 'CmHBejOul', 'Johnath', 'Stoltz', 'jstoltz29@apache.org', 9, 'China', 'Male', 'VP Quality Control', 'XS');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (83, 'whQYLZQ4IrlG', 'Debra', 'Keir', 'dkeir2a@cbslocal.com', 59, 'China', 'Male', 'Assistant Manager', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (84, 'X6am23', 'Tymon', 'Dyte', 'tdyte2b@yale.edu', 43, 'Philippines', 'Male', 'Civil Engineer', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (85, 'cb5gxMXjP1', 'Ilaire', 'Graal', 'igraal2c@infoseek.co.jp', 3, 'Indonesia', 'Male', 'Payment Adjustment Coordinator', '2XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (86, 'zXxPrYr9oFql', 'Angelita', 'Westhofer', 'awesthofer2d@infoseek.co.jp', 51, 'Canada', 'Female', 'Dental Hygienist', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (87, 'XkrTnNSWFUx', 'Moll', 'Cottle', 'mcottle2e@xinhuanet.com', 35, 'Portugal', 'Female', 'Sales Representative', '2XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (88, 'g5efmRRajUqk', 'Layne', 'Domoni', 'ldomoni2f@army.mil', 58, 'Colombia', 'Female', 'Environmental Tech', '2XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (89, 'zC1yJEup', 'Isiahi', 'Allott', 'iallott2g@google.com.br', 65, 'Canada', 'Male', 'Senior Financial Analyst', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (90, 'ptVwZUYiCDCP', 'Jone', 'Postle', 'jpostle2h@digg.com', 33, 'Philippines', 'Male', 'Director of Sales', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (91, '5jpHBMc', 'Rhonda', 'MacMychem', 'rmacmychem2i@51.la', 25, 'China', 'Female', 'Internal Auditor', '3XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (92, 'z4aunF7', 'Herman', 'Gierardi', 'hgierardi2j@ask.com', 62, 'United States', 'Female', 'Media Manager I', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (93, 'kJ8ot9CUR99n', 'Francisca', 'Fynn', 'ffynn2k@sina.com.cn', 15, 'Russia', 'Male', 'VP Accounting', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (94, 'c7X5BIQ8', 'York', 'Prinett', 'yprinett2l@about.me', 64, 'Mongolia', 'Male', 'Sales Representative', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (95, '40kCiRbX5WJd', 'Shari', 'Laetham', 'slaetham2m@nifty.com', 3, 'France', 'Female', 'Statistician III', '2XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (96, 'Fulb82', 'De', 'Rolley', 'drolley2n@apple.com', 36, 'Indonesia', 'Female', 'Software Engineer II', 'S');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (97, 'UTSEtzJj', 'Gerardo', 'O''Bruen', 'gobruen2o@npr.org', 42, 'Albania', 'Female', 'Media Manager II', 'XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (98, '0UyISTnewa', 'Blisse', 'Jossel', 'bjossel2p@bravesites.com', 24, 'Brazil', 'Female', 'Research Assistant IV', 'L');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (99, '4uLLJPdmyQLU', 'Bailey', 'Eccleshare', 'beccleshare2q@bluehost.com', 9, 'United States', 'Male', 'VP Sales', '2XL');
insert into grocery_membership (id, membership_id, first_name, last_name, email, age_at_registration, birth_country, gender, job_title, shirt_size) values (100, 'clH4jYdU0t', 'Brook', 'Heaford', 'bheaford2r@bbc.co.uk', 45, 'Czech Republic', 'Female', 'Programmer III', 'M');

insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (1, 'Pork - Smoked Kassler', 'Democratic Republic of the Congo', 'Democratic Republic of the Congo Pork - Smoked Kassler', 'Turquoise', '7/25/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (2, 'Bread - Focaccia Quarter', 'Norfolk Island', 'Norfolk Island Bread - Focaccia Quarter', 'Turquoise', '7/20/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (3, 'Foam Cup 6 Oz', 'Portugal', 'Portugal Foam Cup 6 Oz', 'Goldenrod', '3/26/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (4, 'Wine - White, Lindemans Bin 95', 'Czech Republic', 'Czech Republic Wine - White, Lindemans Bin 95', 'Mauv', '5/8/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (5, 'Sponge Cake Mix - Chocolate', 'Poland', 'Poland Sponge Cake Mix - Chocolate', 'Orange', '8/1/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (6, 'Wine - Gato Negro Cabernet', 'Ukraine', 'Ukraine Wine - Gato Negro Cabernet', 'Violet', '1/21/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (7, 'Macaroons - Two Bite Choc', 'China', 'China Macaroons - Two Bite Choc', 'Teal', '5/3/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (8, 'Beef - Striploin', 'Indonesia', 'Indonesia Beef - Striploin', 'Orange', '9/23/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (9, 'Vinegar - Red Wine', 'Thailand', 'Thailand Vinegar - Red Wine', 'Turquoise', '10/27/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (10, 'Oil - Truffle, White', 'China', 'China Oil - Truffle, White', 'Violet', '3/23/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (11, 'Flavouring - Orange', 'United Kingdom', 'United Kingdom Flavouring - Orange', 'Red', '2/13/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (12, 'Wanton Wrap', 'Croatia', 'Croatia Wanton Wrap', 'Purple', '8/3/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (13, 'Octopus', 'China', 'China Octopus', 'Crimson', '7/15/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (14, 'Grenadine', 'France', 'France Grenadine', 'Pink', '3/24/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (15, 'Juice - Pineapple, 341 Ml', 'Portugal', 'Portugal Juice - Pineapple, 341 Ml', 'Green', '8/29/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (16, 'Sole - Fillet', 'Finland', 'Finland Sole - Fillet', 'Khaki', '4/20/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (17, 'Ice Cream Bar - Hageen Daz To', 'Brazil', 'Brazil Ice Cream Bar - Hageen Daz To', 'Mauv', '1/10/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (18, 'Wine - Baron De Rothschild', 'China', 'China Wine - Baron De Rothschild', 'Fuscia', '4/24/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (19, 'Oxtail - Cut', 'China', 'China Oxtail - Cut', 'Crimson', '7/16/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (20, 'Ice - Clear, 300 Lb For Carving', 'Bangladesh', 'Bangladesh Ice - Clear, 300 Lb For Carving', 'Pink', '9/6/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (21, 'Raspberries - Frozen', 'Italy', 'Italy Raspberries - Frozen', 'Goldenrod', '11/15/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (22, 'Bag - Bread, White, Plain', 'Russia', 'Russia Bag - Bread, White, Plain', 'Puce', '11/7/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (23, 'Cheese - Parmesan Grated', 'Philippines', 'Philippines Cheese - Parmesan Grated', 'Green', '8/26/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (24, 'Sauce - Black Current, Dry Mix', 'Philippines', 'Philippines Sauce - Black Current, Dry Mix', 'Fuscia', '3/6/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (25, 'Tomatoes - Yellow Hot House', 'China', 'China Tomatoes - Yellow Hot House', 'Maroon', '8/1/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (26, 'Longos - Burritos', 'Costa Rica', 'Costa Rica Longos - Burritos', 'Purple', '11/2/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (27, 'Ham - Black Forest', 'Philippines', 'Philippines Ham - Black Forest', 'Green', '8/5/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (28, 'Currants', 'China', 'China Currants', 'Yellow', '5/18/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (29, 'Pie Filling - Cherry', 'China', 'China Pie Filling - Cherry', 'Maroon', '10/18/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (30, 'Energy Drink - Franks Original', 'Russia', 'Russia Energy Drink - Franks Original', 'Orange', '4/4/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (31, 'Liners - Baking Cups', 'Afghanistan', 'Afghanistan Liners - Baking Cups', 'Teal', '6/26/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (32, 'Oil - Hazelnut', 'Indonesia', 'Indonesia Oil - Hazelnut', 'Yellow', '1/25/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (33, 'Salt - Rock, Course', 'China', 'China Salt - Rock, Course', 'Fuscia', '1/22/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (34, 'Water - Aquafina Vitamin', 'Indonesia', 'Indonesia Water - Aquafina Vitamin', 'Puce', '12/16/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (35, 'Sloe Gin - Mcguinness', 'Bolivia', 'Bolivia Sloe Gin - Mcguinness', 'Indigo', '9/29/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (36, 'Cheese - Ricotta', 'China', 'China Cheese - Ricotta', 'Yellow', '6/19/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (37, 'Cheese - Goat', 'Colombia', 'Colombia Cheese - Goat', 'Pink', '6/8/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (38, 'Potatoes - Pei 10 Oz', 'Mongolia', 'Mongolia Potatoes - Pei 10 Oz', 'Blue', '9/1/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (39, 'Pork - Liver', 'China', 'China Pork - Liver', 'Indigo', '1/2/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (40, 'Beans - Fava, Canned', 'United States', 'United States Beans - Fava, Canned', 'Indigo', '8/26/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (41, 'Wine - Red, Gamay Noir', 'China', 'China Wine - Red, Gamay Noir', 'Teal', '4/4/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (42, 'Sping Loaded Cup Dispenser', 'China', 'China Sping Loaded Cup Dispenser', 'Aquamarine', '7/15/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (43, 'Beef - Rouladin, Sliced', 'Vietnam', 'Vietnam Beef - Rouladin, Sliced', 'Teal', '5/3/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (44, 'Cheese - Comte', 'Russia', 'Russia Cheese - Comte', 'Teal', '2/22/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (45, 'Table Cloth 144x90 White', 'Lithuania', 'Lithuania Table Cloth 144x90 White', 'Orange', '2/15/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (46, 'Sauce - Soya, Dark', 'Kyrgyzstan', 'Kyrgyzstan Sauce - Soya, Dark', 'Indigo', '7/27/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (47, 'Rabbit - Saddles', 'China', 'China Rabbit - Saddles', 'Puce', '5/1/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (48, 'Soupfoamcont12oz 112con', 'Indonesia', 'Indonesia Soupfoamcont12oz 112con', 'Green', '9/21/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (49, 'Soup - Campbells, Classic Chix', 'Peru', 'Peru Soup - Campbells, Classic Chix', 'Blue', '8/25/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (50, 'Chickhen - Chicken Phyllo', 'Honduras', 'Honduras Chickhen - Chicken Phyllo', 'Aquamarine', '3/20/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (51, 'Coconut - Shredded, Unsweet', 'Mexico', 'Mexico Coconut - Shredded, Unsweet', 'Violet', '7/13/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (52, 'Mushroom - Oyster, Fresh', 'China', 'China Mushroom - Oyster, Fresh', 'Goldenrod', '8/9/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (53, 'Bread - Pumpernickle, Rounds', 'Mozambique', 'Mozambique Bread - Pumpernickle, Rounds', 'Green', '9/30/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (54, 'Cheese - Cheddar, Mild', 'Honduras', 'Honduras Cheese - Cheddar, Mild', 'Orange', '1/1/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (55, 'Glass - Wine, Plastic, Clear 5 Oz', 'China', 'China Glass - Wine, Plastic, Clear 5 Oz', 'Purple', '11/13/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (56, 'Bread - Petit Baguette', 'Greece', 'Greece Bread - Petit Baguette', 'Maroon', '8/25/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (57, 'Mustard - Dijon', 'Russia', 'Russia Mustard - Dijon', 'Yellow', '6/8/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (58, 'Juice - Mango', 'Bulgaria', 'Bulgaria Juice - Mango', 'Purple', '3/13/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (59, 'Chicken - Leg / Back Attach', 'Indonesia', 'Indonesia Chicken - Leg / Back Attach', 'Red', '11/14/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (60, 'Lettuce - Lambs Mash', 'Ukraine', 'Ukraine Lettuce - Lambs Mash', 'Blue', '2/8/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (61, 'Seabream Whole Farmed', 'Thailand', 'Thailand Seabream Whole Farmed', 'Indigo', '7/27/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (62, 'Wild Boar - Tenderloin', 'China', 'China Wild Boar - Tenderloin', 'Goldenrod', '1/20/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (63, 'Tahini Paste', 'Bulgaria', 'Bulgaria Tahini Paste', 'Orange', '5/9/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (64, 'Pepper - Red Thai', 'Indonesia', 'Indonesia Pepper - Red Thai', 'Crimson', '4/5/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (65, 'Rice - Jasmine Sented', 'Indonesia', 'Indonesia Rice - Jasmine Sented', 'Teal', '8/23/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (66, 'Flour - Strong', 'Indonesia', 'Indonesia Flour - Strong', 'Yellow', '4/12/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (67, 'Bagel - Ched Chs Presliced', 'Russia', 'Russia Bagel - Ched Chs Presliced', 'Khaki', '11/1/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (68, 'Duck - Whole', 'Saint Kitts and Nevis', 'Saint Kitts and Nevis Duck - Whole', 'Blue', '6/4/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (69, 'Tomatoes - Vine Ripe, Red', 'Angola', 'Angola Tomatoes - Vine Ripe, Red', 'Goldenrod', '10/12/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (70, 'Tomatoes - Heirloom', 'South Korea', 'South Korea Tomatoes - Heirloom', 'Purple', '6/25/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (71, 'Tea - Vanilla Chai', 'United States', 'United States Tea - Vanilla Chai', 'Red', '6/20/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (72, 'Pasta - Lasagne, Fresh', 'Peru', 'Peru Pasta - Lasagne, Fresh', 'Violet', '12/4/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (73, 'Napkin White', 'Armenia', 'Armenia Napkin White', 'Fuscia', '10/1/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (74, 'Arrowroot', 'Portugal', 'Portugal Arrowroot', 'Violet', '1/20/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (75, 'Potatoes - Idaho 80 Count', 'Colombia', 'Colombia Potatoes - Idaho 80 Count', 'Purple', '2/12/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (76, 'Wine - Barossa Valley Estate', 'Kazakhstan', 'Kazakhstan Wine - Barossa Valley Estate', 'Green', '8/29/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (77, 'Cookies - Fortune', 'Brazil', 'Brazil Cookies - Fortune', 'Puce', '7/27/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (78, 'Beef - Tenderloin - Aa', 'Japan', 'Japan Beef - Tenderloin - Aa', 'Red', '2/5/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (79, 'Spice - Onion Powder Granulated', 'Syria', 'Syria Spice - Onion Powder Granulated', 'Purple', '11/29/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (80, 'Oil - Coconut', 'China', 'China Oil - Coconut', 'Maroon', '10/20/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (81, 'Water - Mineral, Carbonated', 'France', 'France Water - Mineral, Carbonated', 'Aquamarine', '7/20/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (82, 'Garbage Bags - Black', 'Poland', 'Poland Garbage Bags - Black', 'Blue', '6/8/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (83, 'Mushroom - Porcini Frozen', 'Guatemala', 'Guatemala Mushroom - Porcini Frozen', 'Pink', '6/22/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (84, 'Carbonated Water - Blackcherry', 'Portugal', 'Portugal Carbonated Water - Blackcherry', 'Green', '7/27/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (85, 'Ham - Cooked', 'Colombia', 'Colombia Ham - Cooked', 'Goldenrod', '9/28/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (86, 'Cup Translucent 9 Oz', 'Canada', 'Canada Cup Translucent 9 Oz', 'Pink', '9/4/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (87, 'English Muffin', 'Indonesia', 'Indonesia English Muffin', 'Teal', '5/7/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (88, 'Capon - Breast, Wing On', 'Norway', 'Norway Capon - Breast, Wing On', 'Red', '7/19/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (89, 'Bread - Ciabatta Buns', 'China', 'China Bread - Ciabatta Buns', 'Orange', '6/27/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (90, 'Cheese - Ricotta', 'Philippines', 'Philippines Cheese - Ricotta', 'Blue', '4/17/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (91, 'Steampan Lid', 'China', 'China Steampan Lid', 'Maroon', '2/23/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (92, 'Butter Balls Salted', 'Russia', 'Russia Butter Balls Salted', 'Fuscia', '6/22/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (93, 'Bread Fig And Almond', 'Poland', 'Poland Bread Fig And Almond', 'Orange', '3/8/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (94, 'Oil - Peanut', 'Philippines', 'Philippines Oil - Peanut', 'Indigo', '1/27/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (95, 'Croissant, Raw - Mini', 'Philippines', 'Philippines Croissant, Raw - Mini', 'Aquamarine', '2/20/2023');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (96, 'Pastry - Butterscotch Baked', 'Germany', 'Germany Pastry - Butterscotch Baked', 'Maroon', '10/27/2021');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (97, 'Bagels Poppyseed', 'Indonesia', 'Indonesia Bagels Poppyseed', 'Red', '5/8/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (98, 'Lamb - Pieces, Diced', 'Sweden', 'Sweden Lamb - Pieces, Diced', 'Indigo', '11/30/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (99, 'Magnotta - Bel Paese White', 'Brazil', 'Brazil Magnotta - Bel Paese White', 'Mauv', '6/17/2022');
insert into grocery_shop (id, items, shipment_origin, item_id, packaging_color, expiry_date) values (100, 'Cheese - Bakers Cream Cheese', 'Peru', 'Peru Cheese - Bakers Cream Cheese', 'Fuscia', '10/27/2021');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO historical_unique_buys (grocery_membership_membership_id, grocery_shop_item_id)
SELECT  
    *
FROM
(
    SELECT
        *
    FROM
        (
        SELECT 
            grocery_membership.membership_id AS grocery_membership_membership_id, grocery_shop.item_id AS grocery_shop_item_id
        FROM
            grocery_membership, grocery_shop
        ORDER BY
            random()
        ) AS s0
    LIMIT
        1000 
) AS s1;