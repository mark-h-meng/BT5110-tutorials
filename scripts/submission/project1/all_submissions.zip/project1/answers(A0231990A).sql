/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
Student ID: A0231990A
Written for PostgreSQL 13

This example is for a streaming platform that is interested in looking at the list of movies which
their users have watched on the platform. 

The first table, 'customer', contains personal particulars of each user on the streaming platform. 
This includes their username, name, email, gender, contact number and date of birth.

The second table, 'movie', contains the list of movies currently available on the platform. This 
would include details such as the movie title, year of release, genre, duration and director.

The third table, 'watched', contains the list of movies that each user has watched on the platform.

Such information would be helpful to the streaming platform in understanding the types of movies 
their user base is interested in, which can help with planning for future content.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE customer (
	username VARCHAR(16) PRIMARY KEY,
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	email VARCHAR(64) UNIQUE NOT NULL,
	gender CHAR(1) NOT NULL,
	dob DATE NOT NULL,
	contact_no CHAR(13) NOT NULL
);

CREATE TABLE movie (
	movie_name VARCHAR(64),
	year_released SMALLINT,
	movie_genre VARCHAR(64) NOT NULL,
	duration_mins SMALLINT NOT NULL,
	director VARCHAR(64) NOT NULL,
	PRIMARY KEY (movie_name, year_released)
);

CREATE TABLE watched (
	username VARCHAR(16) REFERENCES customer(username)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED,
	movie_name VARCHAR(64),
	year_released SMALLINT,
	PRIMARY KEY (username, movie_name, year_released),
	FOREIGN KEY (movie_name, year_released) REFERENCES movie(movie_name, year_released)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO customer (
	username, 
	first_name, 
	last_name, 
	email, 
	gender, 
	dob, 
	contact_no
) 
VALUES 
	('akinnar0', 'Aldric', 'Kinnar', 'akinnar0@de.vu', 'M', '1971-09-20', '+65 8314 2661'),
	('smoyce1', 'Shel', 'Moyce', 'smoyce1@google.de', 'F', '1954-04-20', '+65 8291 9198'),
	('ibrittlebank2', 'Ive', 'Brittlebank', 'ibrittlebank2@craigslist.org', 'M', '1998-12-30', '+65 9614 1563'),
	('hgilogly3', 'Haskel', 'Gilogly', 'hgilogly3@github.com', 'M', '1964-10-07', '+65 9872 1688'),
	('dlabin4', 'Dana', 'Labin', 'dlabin4@jimdo.com', 'M', '1990-08-30', '+65 8967 4984'),
	('wfipp5', 'Wanids', 'Fipp', 'wfipp5@dell.com', 'F', '1960-04-15', '+65 9062 7956'),
	('kroskeilly6', 'Kahlil', 'Roskeilly', 'kroskeilly6@sun.com', 'M', '1995-07-03', '+65 8920 8754'),
	('jplan7', 'Jessamyn', 'Plan', 'jplan7@ucsd.edu', 'F', '1980-10-01', '+65 9396 5215'),
	('djehan8', 'Desdemona', 'Jehan', 'djehan8@nytimes.com', 'F', '1978-07-07', '+65 9122 2626'),
	('mpammenter9', 'Mariann', 'Pammenter', 'mpammenter9@com.com', 'F', '1966-01-29', '+65 8392 5281'),
	('mmckeaneya', 'Mayne', 'McKeaney', 'mmckeaneya@bloomberg.com', 'M', '1961-09-14', '+65 8915 9111'),
	('bfronczakb', 'Bordie', 'Fronczak', 'bfronczakb@myspace.com', 'M', '1999-02-28', '+65 8127 2417'),
	('dlevingtonc', 'Davin', 'Levington', 'dlevingtonc@exblog.jp', 'M', '1993-08-14', '+65 9504 3493'),
	('cseamond', 'Cris', 'Seamon', 'cseamond@dailymail.co.uk', 'M', '1990-05-27', '+65 8695 3383'),
	('bfreezore', 'Benjamin', 'Freezor', 'bfreezore@home.pl', 'M', '1983-07-29', '+65 8140 3831'),
	('aeustanchf', 'Alexis', 'Eustanch', 'aeustanchf@last.fm', 'M', '1987-12-18', '+65 9658 3001'),
	('bcreekg', 'Binny', 'Creek', 'bcreekg@unc.edu', 'F', '1956-02-27', '+65 8272 4972'),
	('blightollerh', 'Brooke', 'Lightoller', 'blightollerh@usatoday.com', 'M', '1994-06-30', '+65 8516 7416'),
	('egooderei', 'Erich', 'Goodere', 'egooderei@arstechnica.com', 'M', '2002-02-01', '+65 8224 4729'),
	('sbasillj', 'Sibby', 'Basill', 'sbasillj@ted.com', 'F', '2001-03-11', '+65 8872 6283'),
	('igiacopettik', 'Ike', 'Giacopetti', 'igiacopettik@dailymotion.com', 'M', '1990-04-25', '+65 9814 7485'),
	('swolstencroftl', 'Shanta', 'Wolstencroft', 'swolstencroftl@accuweather.com', 'F', '1981-12-11', '+65 8953 1624'),
	('zsnedenm', 'Zahara', 'Sneden', 'zsnedenm@dropbox.com', 'F', '1981-07-13', '+65 8640 4799'),
	('asheehann', 'Arch', 'Sheehan', 'asheehann@un.org', 'M', '1968-10-04', '+65 9833 4320'),
	('npendergrasto', 'Nichole', 'Pendergrast', 'npendergrasto@who.int', 'M', '1990-04-08', '+65 8445 9579'),
	('myemmp', 'Maryellen', 'Yemm', 'myemmp@smh.com.au', 'F', '1990-12-19', '+65 8902 6357'),
	('duridgeq', 'Denver', 'Uridge', 'duridgeq@friendfeed.com', 'M', '1988-12-03', '+65 9936 8383'),
	('edaymentr', 'Ellswerth', 'Dayment', 'edaymentr@house.gov', 'M', '2003-06-26', '+65 9765 3173'),
	('gwaldies', 'Gardner', 'Waldie', 'gwaldies@woothemes.com', 'M', '1998-04-13', '+65 9818 0940'),
	('djerokt', 'Dona', 'Jerok', 'djerokt@bluehost.com', 'F', '1985-08-16', '+65 8161 6784'),
	('dfuchsu', 'Donall', 'Fuchs', 'dfuchsu@tamu.edu', 'M', '1989-11-04', '+65 8667 0473'),
	('mmeasev', 'Mandi', 'Mease', 'mmeasev@de.vu', 'F', '1961-03-23', '+65 9077 1179'),
	('ggudemanw', 'Gilda', 'Gudeman', 'ggudemanw@usnews.com', 'F', '1979-04-22', '+65 8628 4905'),
	('khylandsx', 'Katee', 'Hylands', 'khylandsx@shinystat.com', 'F', '1953-03-13', '+65 8119 5252'),
	('tskipy', 'Tarrah', 'Skip', 'tskipy@chron.com', 'F', '1975-02-21', '+65 8330 7088'),
	('lblantz', 'Lin', 'Blant', 'lblantz@google.pl', 'M', '2000-10-04', '+65 8806 0504'),
	('qmacfarlan10', 'Quincy', 'MacFarlan', 'qmacfarlan10@elpais.com', 'M', '1992-11-06', '+65 8369 6553'),
	('sivankin11', 'Sheff', 'Ivankin', 'sivankin11@hugedomains.com', 'M', '1975-01-05', '+65 8535 6800'),
	('dsibborn12', 'Dale', 'Sibborn', 'dsibborn12@si.edu', 'M', '1980-08-19', '+65 9656 3783'),
	('schina13', 'Selby', 'China', 'schina13@stanford.edu', 'M', '1992-07-05', '+65 9577 2932'),
	('bpeniman14', 'Baily', 'Peniman', 'bpeniman14@behance.net', 'M', '2003-03-27', '+65 8183 6949'),
	('mfoskew15', 'Madlin', 'Foskew', 'mfoskew15@deviantart.com', 'F', '1988-05-31', '+65 8116 6807'),
	('phanretty16', 'Pippo', 'Hanretty', 'phanretty16@time.com', 'M', '1977-12-29', '+65 8066 9785'),
	('tpummell17', 'Tarrance', 'Pummell', 'tpummell17@imageshack.us', 'M', '1976-03-02', '+65 8239 3794'),
	('ggeertz18', 'Granthem', 'Geertz', 'ggeertz18@technorati.com', 'M', '2002-12-21', '+65 8151 3019'),
	('dpudden19', 'Daisy', 'Pudden', 'dpudden19@godaddy.com', 'F', '1965-08-24', '+65 8640 1665'),
	('mmedway1a', 'Malinda', 'Medway', 'mmedway1a@squarespace.com', 'F', '1995-06-19', '+65 8342 4172'),
	('kstpaul1b', 'Kathryn', 'St. Paul', 'kstpaul1b@vkontakte.ru', 'F', '1999-05-03', '+65 9568 9033'),
	('athorley1c', 'Alejandro', 'Thorley', 'athorley1c@rediff.com', 'M', '1988-07-31', '+65 9032 7243'),
	('lbassilashvili1d', 'Laura', 'Bassilashvili', 'lbassilashvili1d@wikispaces.com', 'F', '1968-11-12', '+65 8045 6515'),
	('dheadingham1e', 'Dare', 'Headingham', 'dheadingham1e@parallels.com', 'M', '1963-11-14', '+65 8137 7942'),
	('gpolleye1f', 'Grant', 'Polleye', 'gpolleye1f@phpbb.com', 'M', '1992-05-15', '+65 8127 9876'),
	('bpierpoint1g', 'Birk', 'Pierpoint', 'bpierpoint1g@indiegogo.com', 'M', '1999-03-11', '+65 9513 8979'),
	('nnewsham1h', 'Nicky', 'Newsham', 'nnewsham1h@stanford.edu', 'F', '1994-01-30', '+65 8628 8072'),
	('pabsalom1i', 'Padgett', 'Absalom', 'pabsalom1i@gmpg.org', 'M', '1969-11-27', '+65 9025 1125'),
	('ddodding1j', 'Dieter', 'Dodding', 'ddodding1j@mozilla.com', 'M', '1953-05-11', '+65 8768 8466'),
	('rgarfoot1k', 'Rosina', 'Garfoot', 'rgarfoot1k@eventbrite.com', 'F', '1971-10-19', '+65 9511 7126'),
	('mmeasey1l', 'Maybelle', 'Measey', 'mmeasey1l@artisteer.com', 'F', '1953-01-29', '+65 8549 9444'),
	('ebroinlich1m', 'Elisabeth', 'Broinlich', 'ebroinlich1m@virginia.edu', 'F', '1968-11-26', '+65 9947 0760'),
	('ntutin1n', 'Nathanael', 'Tutin', 'ntutin1n@mail.ru', 'M', '1979-01-17', '+65 8582 2066'),
	('tbenne1o', 'Tarrah', 'Benne', 'tbenne1o@newsvine.com', 'F', '2003-07-05', '+65 9059 5132'),
	('wjoost1p', 'Warren', 'Joost', 'wjoost1p@acquirethisname.com', 'M', '1954-09-04', '+65 9243 1234'),
	('pburner1q', 'Perry', 'Burner', 'pburner1q@drupal.org', 'F', '1969-02-06', '+65 8355 0609'),
	('dsarney1r', 'Dante', 'Sarney', 'dsarney1r@baidu.com', 'M', '1988-11-12', '+65 9402 7910'),
	('mfarans1s', 'Maryanne', 'Farans', 'mfarans1s@odnoklassniki.ru', 'F', '1986-06-23', '+65 9749 4916'),
	('astothard1t', 'Abbott', 'Stothard', 'astothard1t@nba.com', 'M', '1967-01-13', '+65 9683 3821'),
	('mleverette1u', 'Matteo', 'Leverette', 'mleverette1u@biblegateway.com', 'M', '1990-05-08', '+65 9896 2934'),
	('pacory1v', 'Pieter', 'Acory', 'pacory1v@slate.com', 'M', '1957-12-04', '+65 8888 2900'),
	('cmealing1w', 'Candis', 'Mealing', 'cmealing1w@cdc.gov', 'F', '1954-08-10', '+65 9881 6940'),
	('bvernazza1x', 'Billi', 'Vernazza', 'bvernazza1x@homestead.com', 'F', '1979-05-22', '+65 8488 4579'),
	('hplayhill1y', 'Hillel', 'Playhill', 'hplayhill1y@nature.com', 'M', '1982-03-02', '+65 8960 4681'),
	('mspreag1z', 'Mathilde', 'Spreag', 'mspreag1z@cisco.com', 'F', '1951-09-04', '+65 9101 1372'),
	('bemmanuele20', 'Bastien', 'Emmanuele', 'bemmanuele20@independent.co.uk', 'M', '2000-01-03', '+65 9931 4288'),
	('amathie21', 'Alyssa', 'Mathie', 'amathie21@mapquest.com', 'F', '1968-09-02', '+65 9727 3012'),
	('sdurno22', 'Sven', 'Durno', 'sdurno22@who.int', 'M', '1967-10-01', '+65 8649 8798'),
	('bdurrant23', 'Bianka', 'Durrant', 'bdurrant23@angelfire.com', 'F', '1952-04-13', '+65 9894 0583'),
	('ntoffoletto24', 'Nicko', 'Toffoletto', 'ntoffoletto24@ebay.co.uk', 'M', '1963-06-20', '+65 9652 5980'),
	('vligerton25', 'Vlad', 'Ligerton', 'vligerton25@va.gov', 'M', '1958-06-30', '+65 9382 9076'),
	('agirod26', 'Artur', 'Girod', 'agirod26@sohu.com', 'M', '1982-05-15', '+65 9983 5163'),
	('cvedeniktov27', 'Cleopatra', 'Vedeniktov', 'cvedeniktov27@omniture.com', 'F', '1959-05-09', '+65 8494 8253'),
	('cirnis28', 'Corny', 'Irnis', 'cirnis28@home.pl', 'F', '1991-12-26', '+65 8644 6884'),
	('ehutchinges29', 'Erna', 'Hutchinges', 'ehutchinges29@fotki.com', 'F', '1953-11-18', '+65 9030 4639'),
	('revenett2a', 'Rubin', 'Evenett', 'revenett2a@tiny.cc', 'M', '1971-06-03', '+65 8248 5331'),
	('sshippam2b', 'Stormi', 'Shippam', 'sshippam2b@icq.com', 'F', '1993-11-07', '+65 9143 4534'),
	('jbradley2c', 'Jess', 'Bradley', 'jbradley2c@nps.gov', 'F', '1967-12-03', '+65 8580 8194'),
	('erosie2d', 'Englebert', 'Rosie', 'erosie2d@uiuc.edu', 'M', '1970-11-27', '+65 8569 4173'),
	('ghearon2e', 'Gabriele', 'Hearon', 'ghearon2e@blogger.com', 'M', '1997-07-29', '+65 9513 4417'),
	('gcoldman2f', 'Godfrey', 'Coldman', 'gcoldman2f@surveymonkey.com', 'M', '1957-10-31', '+65 9692 9869'),
	('ktetford2g', 'Katlin', 'Tetford', 'ktetford2g@virginia.edu', 'F', '1989-11-19', '+65 8880 1175'),
	('dsimner2h', 'Dawna', 'Simner', 'dsimner2h@delicious.com', 'F', '1994-04-29', '+65 9324 0916'),
	('cmccahey2i', 'Conni', 'McCahey', 'cmccahey2i@squidoo.com', 'F', '1997-02-09', '+65 9665 8068'),
	('oebenezer2j', 'Ossie', 'Ebenezer', 'oebenezer2j@cpanel.net', 'M', '1956-08-16', '+65 8040 0864'),
	('gsimoneton2k', 'Gay', 'Simoneton', 'gsimoneton2k@parallels.com', 'M', '1978-02-25', '+65 9164 7756'),
	('pconnechie2l', 'Paulo', 'Connechie', 'pconnechie2l@t.co', 'M', '1968-12-30', '+65 8429 1838'),
	('skleint2m', 'Saleem', 'Kleint', 'skleint2m@instagram.com', 'M', '1995-04-14', '+65 9256 5173'),
	('ksturridge2n', 'Kalindi', 'Sturridge', 'ksturridge2n@fema.gov', 'F', '1983-12-12', '+65 8000 5436'),
	('wsuddell2o', 'Winthrop', 'Suddell', 'wsuddell2o@jiathis.com', 'M', '1971-12-03', '+65 9372 9557'),
	('wmeugens2p', 'Waldo', 'Meugens', 'wmeugens2p@irs.gov', 'M', '1953-10-24', '+65 8534 7620'),
	('ddannel2q', 'Damara', 'Dannel', 'ddannel2q@cam.ac.uk', 'F', '1952-11-07', '+65 9193 6178'),
	('ogoricke2r', 'Onofredo', 'Goricke', 'ogoricke2r@timesonline.co.uk', 'M', '1993-08-19', '+65 8927 9710');

INSERT INTO movie (
	movie_name, 
	year_released, 
	movie_genre, 
	duration_mins, 
	director
) 
VALUES 
	('Reeker', 1994, 'Horror|Mystery', 106, 'Sybila Kobisch'),
	('Cremator, The', 2005, 'Comedy|Drama|Horror|Thriller', 164, 'Shayla Brotherick'),
	('Man from London, The', 2003, 'Crime|Drama|Mystery', 79, 'Alaine Lamplough'),
	('Pearls of the Deep', 1990, 'Comedy', 72, 'Doroteya Iannazzi'),
	('Unintentional Kidnapping of Mrs. Elfriede Ott, The', 2004, 'Comedy', 89, 'Shirley Gilston'),
	('Rosemary''s Baby', 2010, 'Horror|Thriller', 143, 'Kyle Szwandt'),
	('Torpedo Run', 2001, 'Drama|War', 164, 'Fern Noddle'),
	('Assembly', 1999, 'Action|Drama|War', 92, 'Dyna Rendall'),
	('The Brave Little Toaster Goes to Mars', 1992, 'Animation|Children', 105, 'Rae Ros'),
	('Ice Age 2: The Meltdown', 2010, 'Adventure|Animation|Children|Comedy', 77, 'Mychal Burborough'),
	('Where the Boys Are ''84', 1993, 'Comedy', 103, 'Lisabeth Stelljes'),
	('Ex-Girlfriends', 2006, 'Comedy|Drama', 115, 'Ruperto Piotrkowski'),
	('Oklahoma Crude', 1989, 'Comedy|Drama|Western', 115, 'Marshal Hallums'),
	('Tarzan and His Mate', 1968, 'Action|Adventure', 122, 'Nicoli Scarce'),
	('Wrong Turn 4', 1984, 'Action|Horror|Thriller', 155, 'Jolee Baglin'),
	('Sinbad and the Eye of the Tiger', 1996, 'Adventure|Fantasy', 92, 'Baldwin Crofthwaite'),
	('Watch the Birdie', 2007, 'Comedy|Crime|Romance', 94, 'Merilee Longmaid'),
	('Tom Sawyer', 2010, 'Adventure|Children|Musical', 163, 'Rustie Panyer'),
	('Dawn Patrol, The', 2002, 'Drama|War', 102, 'Cyb Mateos'),
	('Katt Williams: Priceless: Afterlife', 2004, 'Comedy', 90, 'Flora Mapp'),
	('Batman', 2000, 'Action|Crime|Thriller', 155, 'Glennis Scotchmore'),
	('Paradise', 2008, 'Romance', 116, 'Editha Scolli'),
	('To Be or Not to Be', 2008, 'Comedy|Romance|War', 88, 'Morten Lorait'),
	('Die Another Day', 1988, 'Action|Adventure|Thriller', 168, 'Artemus Gerb'),
	('Golem', 2004, 'Drama|Mystery|Sci-Fi', 147, 'Mirabella Mowbury'),
	('Passenger, The (Professione: reporter)', 2003, 'Drama', 126, 'Wilt Brighouse'),
	('Big Boys Gone Bananas!*', 1987, 'Documentary', 79, 'Angie Robart'),
	('Jackass 2.5', 1993, 'Comedy|Documentary', 153, 'Kinnie Airs'),
	('Scalphunters, The', 1999, 'Comedy|Western', 94, 'Blithe MacFadzean'),
	('House of Fools', 2004, 'Drama|Romance|War', 110, 'Bobbye Bazley'),
	('East Meets West (Dung sing sai tsau 2011)', 1999, 'Comedy', 96, 'Georgine Duckering'),
	('Joe Somebody', 1967, 'Comedy|Drama|Romance', 84, 'Giselbert Eadington'),
	('Austenland', 2011, 'Comedy|Romance', 164, 'Daven Baltzar'),
	('Today You Die', 1991, 'Action|Crime', 163, 'Caldwell Nassau'),
	('Sun on the Horizon', 2010, 'Documentary', 98, 'Margery Grimsdale'),
	('Only the Strong Survive - A Celebration of Soul', 1999, 'Documentary|Musical', 126, 'Kai Musla'),
	('Hole, The', 1995, 'Crime|Drama|Horror|Mystery|Thriller', 100, 'Hillery Klampk'),
	('Apple, The (Sib)', 2006, 'Drama', 97, 'Remington Mattusevich'),
	('Hulk Vs.', 1998, 'Animation', 114, 'Alon Hanks'),
	('Bride Flight', 1995, 'Drama', 152, 'Alvy Strelitzer'),
	('Psycho', 2012, 'Crime|Horror', 136, 'Rosita Holehouse'),
	('Brighton Rock', 2008, 'Crime|Drama|Thriller', 106, 'Mignonne Nurny'),
	('Nothing''s All Bad', 1998, 'Drama', 81, 'Arv Legerton'),
	('Oh, Woe Is Me', 1990, 'Comedy|Drama', 157, 'Murvyn Mathen'),
	('Joshua', 2006, 'Drama', 151, 'Livia Aleksandrikin'),
	('Anne of Green Gables', 1985, 'Children|Drama', 98, 'Regan Kelson'),
	('Soft Fruit', 2006, 'Comedy|Drama', 93, 'Lissy Gascoyen'),
	('As You Like It', 2005, 'Comedy', 139, 'Walker Morris'),
	('Brewster''s Millions', 2001, 'Comedy', 166, 'Brenden Deinert'),
	('Blue Smoke', 2010, 'Drama|Romance|Thriller', 156, 'Obed Simkins'),
	('Private', 1993, 'Drama|War', 158, 'Winna Pauling'),
	('Dragons Forever', 1999, 'Action|Comedy|Romance', 135, 'Xenia Ziehm'),
	('Tarnation', 2004, 'Documentary', 144, 'Karrah Boseley'),
	('Baarìa', 2006, 'Comedy|Drama|War', 105, 'Lazare Warry'),
	('Salomè', 1990, 'Drama', 118, 'Hollie Geockle'),
	('Pool Without Water, A (Mizu no nai puuru)', 1992, 'Crime|Drama', 168, 'Rowney Lincey'),
	('New York Minute', 1994, 'Action|Adventure|Comedy', 163, 'Waylan Piechnik'),
	('Wake in Providence, A', 2004, 'Comedy', 85, 'Farrel Cocking'),
	('Smokin'' Aces', 1995, 'Action|Crime|Drama|Thriller', 158, 'Gerald Seth'),
	('Lonely Place to Die, A', 2008, 'Adventure|Crime|Thriller', 76, 'Wiley Faulkener'),
	('Dark Tide', 1992, 'Adventure|Drama|Thriller', 168, 'Sarena Kelling'),
	('How to Make an American Quilt', 2003, 'Drama|Romance', 137, 'Erskine Gillmore'),
	('She-Wolf of London', 1995, 'Action|Drama|Horror|Mystery', 97, 'Salome Cootes'),
	('Mystery Train', 2004, 'Comedy|Drama', 111, 'Nicoli Hamer'),
	('Huey P. Newton Story, A', 2009, 'Documentary', 89, 'Ofella Bradfield'),
	('Living and the Dead, The', 2006, 'Drama|Horror|Mystery', 130, 'Glenn Lamey'),
	('Pelicanman (Pelikaanimies)', 2006, 'Adventure|Children|Fantasy', 73, 'Reinhard Lomond'),
	('Memories of Me', 1993, 'Comedy|Drama', 122, 'Nicol Greser'),
	('Substance of Fire, The', 2003, 'Drama', 85, 'Tiphani Wogden'),
	('Summer Magic', 1999, 'Children|Comedy|Musical', 78, 'Bethena Hammon'),
	('Under Siege 2: Dark Territory', 2011, 'Action', 161, 'Midge Reagan'),
	('Designated Mourner, The', 1985, 'Drama', 152, 'Sibylla Crosio'),
	('Real McCoy, The', 1992, 'Action|Crime|Drama|Thriller', 89, 'Orel Learmonth'),
	('My Week with Marilyn', 2000, 'Drama', 133, 'Klaus Coney'),
	('King Kong Lives', 1996, 'Adventure|Sci-Fi', 113, 'Ashlee Cashin'),
	('Slaughterhouse', 2013, 'Comedy|Horror', 164, 'Kamillah Pretor'),
	('Wind Across the Everglades', 2006, 'Drama|Romance', 96, 'Prudy Bachmann'),
	('The Merry Widow', 2005, 'Comedy|Drama', 102, 'Cecilio Middiff'),
	('Musikanten', 1986, '(no genres listed)', 134, 'Massimiliano Van De Cappelle'),
	('Bulworth', 1991, 'Comedy|Drama|Romance', 153, 'Brunhilda Lenglet'),
	('The Uncommon Making of Petulia', 1990, 'Documentary', 101, 'Wittie Tayt'),
	('New Jack City', 1996, 'Action|Crime|Drama', 94, 'Gusta Konrad'),
	('E Ai... Comeu?', 1988, 'Comedy', 85, 'Kenton Colleymore'),
	('Panic in the Streets', 2010, 'Crime|Drama|Film-Noir|Thriller', 82, 'Venus Beavington'),
	('Bright Victory', 2006, 'Drama', 150, 'Saw Tarbin'),
	('36 Quai des Orfevres (Department 36)', 1998, 'Action|Crime|Drama|Thriller', 84, 'Dare Mocher'),
	('Good Vibrations', 2002, 'Drama|Musical', 106, 'Kent Bodemeaid'),
	('For the Bible Tells Me So', 2012, 'Documentary', 88, 'Rogers Andreou'),
	('Tartuffe (Herr Tartüff)', 2006, 'Drama', 118, 'Neron Kreutzer'),
	('13th Letter, The', 2006, 'Film-Noir', 81, 'Bryna Vasyatkin'),
	('Descendants, The', 1988, 'Comedy|Drama', 95, 'Bernadine McCrostie'),
	('Down and Out in Beverly Hills', 2000, 'Comedy', 146, 'Darby Bonhomme'),
	('WW III: World War III (Der 3. Weltkrieg)', 1999, 'Documentary|War', 153, 'Svend Vsanelli'),
	('One Small Hitch', 1998, 'Comedy|Romance', 164, 'Lu Bissiker'),
	('The Uncommon Making of Petulia', 2006, 'Documentary', 148, 'Lindy Risdall'),
	('Drunks', 2007, 'Drama', 112, 'Brock Aust'),
	('Goofy Movie, A', 2006, 'Animation|Children|Comedy|Romance', 91, 'Aleksandr Bacop'),
	('We Are Legion: The Story of the Hacktivists', 2003, 'Documentary', 81, 'Elle MacQuaker'),
	('Just Between Friends', 2007, 'Drama', 131, 'Pace Pikett'),
	('Torrid Zone', 1986, 'Action|Adventure|Comedy', 79, 'Teodora Piggens');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO watched (
	username, 
	movie_name, 
	year_released
)
	SELECT 
		c.username, 
		m.movie_name, 
		m.year_released
	FROM 
		customer as c, 
		movie as m
	ORDER BY random()
	LIMIT 1000;
