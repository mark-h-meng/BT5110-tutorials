/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/
--Yumeng Xing A0232194J

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */

/* The code is written for SQLite */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* I am writing with SQLite. The three tables I created are Patients, Purchases, and Drugs.
The table Patients is basically some personal information about patients, and the table Drugs contains some drug information.
The table Purchases records what kind of drug each patient purchased.
For Patients, the attributes are id, full_name, email, gender, ssn,and country.
For Drugs, the attributes are id, drug_name, drug_brand, and drug_company.
For Purchases, the attibutes are patient_ssn and drug_id.
Part (c) is just creating three tables and seeting constraint and type for each attribute.
Pard (d) is inserting records into the table Patients and Durgs, using data generated from mockaroo.
Part (e) is doing a cross join of table Patients and Drugs to get data for Purchases, and then introduce a random column, break up the initial order of data and choose 10% of the rows at random.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE Patients (
id INT,
full_name VARCHAR(50) NOT NULL,
email VARCHAR(50) NOT NULL,
gender VARCHAR(50) NOT NULL,
ssn VARCHAR(50) PRIMARY KEY,
country VARCHAR(50) NOT NULL
);

CREATE TABLE Drugs (
id INT Primary Key,
drug_name VARCHAR(50),
drug_brand VARCHAR(50),
drug_company VARCHAR(50)
);

CREATE TABLE Purchases (
patient_ssn VARCHAR(50),
drug_id INT
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (1, 'Patricio O''Loughnan', 'poloughnan0@php.net', 'Male', '402-03-6274', 'Poland');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (2, 'Pavla Annwyl', 'pannwyl1@dailymail.co.uk', 'Male', '434-95-8480', 'South Africa');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (3, 'Wye McElane', 'wmcelane2@sitemeter.com', 'Male', '493-17-6490', 'Afghanistan');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (4, 'Glendon Seamen', 'gseamen3@npr.org', 'Male', '507-17-2861', 'Sweden');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (5, 'Francoise Bog', 'fbog4@jigsy.com', 'Female', '437-65-8564', 'Indonesia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (6, 'Paco Naisbitt', 'pnaisbitt5@census.gov', 'Male', '667-97-2392', 'Poland');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (7, 'Helenelizabeth Vaulkhard', 'hvaulkhard6@bloomberg.com', 'Female', '540-62-7096', 'Czech Republic');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (8, 'Alvera Kremer', 'akremer7@economist.com', 'Male', '508-50-4956', 'Indonesia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (9, 'Julio Love', 'jlove8@netlog.com', 'Male', '494-66-8555', 'Poland');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (10, 'Des Karlolczak', 'dkarlolczak9@histats.com', 'Male', '355-53-5587', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (11, 'Jdavie Landa', 'jlandaa@berkeley.edu', 'Female', '570-80-9311', 'Luxembourg');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (12, 'Sampson Hazell', 'shazellb@amazon.co.uk', 'Female', '523-17-2909', 'Russia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (13, 'Briney Vayne', 'bvaynec@pen.io', 'Male', '410-66-8150', 'Ukraine');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (14, 'Codie Blemings', 'cblemingsd@histats.com', 'Female', '381-12-5828', 'Indonesia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (15, 'Johannah Yosifov', 'jyosifove@creativecommons.org', 'Female', '127-28-3693', 'Indonesia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (16, 'Maia Reuben', 'mreubenf@spotify.com', 'Male', '444-66-3222', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (17, 'Kandace Simonds', 'ksimondsg@surveymonkey.com', 'Female', '461-38-3288', 'Ethiopia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (18, 'Timofei McRuvie', 'tmcruvieh@dot.gov', 'Male', '163-27-2823', 'Latvia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (19, 'Jodee Nissle', 'jnisslei@g.co', 'Male', '477-67-7914', 'Philippines');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (20, 'Candra Maddyson', 'cmaddysonj@hugedomains.com', 'Female', '158-48-8960', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (21, 'Garrik Propper', 'gpropperk@japanpost.jp', 'Female', '228-26-0148', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (22, 'Henka Neve', 'hnevel@admin.ch', 'Male', '231-46-5663', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (23, 'Terra Kinleyside', 'tkinleysidem@moonfruit.com', 'Male', '734-64-5660', 'Indonesia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (24, 'Luella Bispo', 'lbispon@behance.net', 'Male', '391-88-9880', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (25, 'Merv Brewood', 'mbrewoodo@youtube.com', 'Male', '462-68-7644', 'Malawi');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (26, 'Neala McKinley', 'nmckinleyp@theglobeandmail.com', 'Female', '482-06-1162', 'Venezuela');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (27, 'Collie D''Elias', 'cdeliasq@behance.net', 'Male', '753-39-5233', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (28, 'Shaun Rachuig', 'srachuigr@elpais.com', 'Female', '572-92-0087', 'Russia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (29, 'Bianka Goozee', 'bgoozees@opensource.org', 'Female', '722-61-6784', 'France');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (30, 'Stephine Boij', 'sboijt@cam.ac.uk', 'Male', '580-93-0885', 'Sweden');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (31, 'Byrle Shawl', 'bshawlu@xing.com', 'Female', '534-34-7097', 'France');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (32, 'Andromache Gallaccio', 'agallacciov@unblog.fr', 'Male', '250-83-4452', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (33, 'Lucienne Behr', 'lbehrw@people.com.cn', 'Male', '249-35-9826', 'Indonesia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (34, 'Dagny Koop', 'dkoopx@rambler.ru', 'Female', '578-47-1741', 'Finland');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (35, 'Whitney Vyse', 'wvysey@indiegogo.com', 'Female', '155-18-7390', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (36, 'Stoddard McEachern', 'smceachernz@timesonline.co.uk', 'Female', '330-28-4865', 'Indonesia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (37, 'Caroljean Pitman', 'cpitman10@harvard.edu', 'Female', '276-11-9124', 'Costa Rica');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (38, 'Cele Bilbey', 'cbilbey11@dailymail.co.uk', 'Male', '324-14-7529', 'Czech Republic');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (39, 'Cassandra Jedrzejkiewicz', 'cjedrzejkiewicz12@csmonitor.com', 'Female', '103-95-5467', 'Jordan');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (40, 'Isaiah Partner', 'ipartner13@chron.com', 'Female', '814-43-5819', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (41, 'Shamus Gottelier', 'sgottelier14@cnet.com', 'Female', '539-83-5141', 'Norway');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (42, 'Selinda Amberson', 'samberson15@npr.org', 'Male', '272-99-1737', 'Greece');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (43, 'Claudianus Dangl', 'cdangl16@shareasale.com', 'Male', '206-95-3520', 'Dominican Republic');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (44, 'Belicia Willgrass', 'bwillgrass17@imgur.com', 'Male', '338-12-1836', 'Sweden');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (45, 'Ddene Drowsfield', 'ddrowsfield18@home.pl', 'Male', '544-34-1164', 'Poland');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (46, 'Ari Wooder', 'awooder19@deviantart.com', 'Male', '487-11-6542', 'Saint Kitts and Nevis');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (47, 'Audi Ding', 'ading1a@privacy.gov.au', 'Female', '878-21-3084', 'Greece');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (48, 'Perri Kliche', 'pkliche1b@usgs.gov', 'Female', '561-46-0594', 'Tunisia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (49, 'Kelley Wybrow', 'kwybrow1c@smugmug.com', 'Female', '392-10-2438', 'Yemen');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (50, 'Franciska Facey', 'ffacey1d@mac.com', 'Female', '433-36-8682', 'Ukraine');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (51, 'Liam Bard', 'lbard1e@blogtalkradio.com', 'Male', '209-27-6581', 'Brazil');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (52, 'Vassily Kernaghan', 'vkernaghan1f@umn.edu', 'Male', '742-60-1322', 'Czech Republic');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (53, 'Tripp Benmore', 'tbenmore1g@omniture.com', 'Female', '543-95-6617', 'Ireland');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (54, 'Gilles Chuney', 'gchuney1h@networksolutions.com', 'Male', '710-76-6902', 'France');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (55, 'Sergent McLeish', 'smcleish1i@cyberchimps.com', 'Female', '553-83-1888', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (56, 'Terza Gelardi', 'tgelardi1j@boston.com', 'Female', '793-59-1286', 'Finland');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (57, 'Billy Druhan', 'bdruhan1k@t-online.de', 'Male', '879-32-5546', 'Madagascar');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (58, 'Clare Lally', 'clally1l@accuweather.com', 'Male', '179-29-3141', 'Philippines');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (59, 'Leland Embleton', 'lembleton1m@ted.com', 'Male', '897-97-3182', 'Brazil');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (60, 'Dasha Lafont', 'dlafont1n@bloglines.com', 'Male', '297-67-0057', 'Norway');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (61, 'Galina Cowdray', 'gcowdray1o@4shared.com', 'Female', '701-94-9296', 'France');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (62, 'Katya Bortolazzi', 'kbortolazzi1p@eventbrite.com', 'Male', '183-91-7556', 'Poland');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (63, 'Sena MacVanamy', 'smacvanamy1q@alibaba.com', 'Female', '667-09-7172', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (64, 'Bayard Kaveney', 'bkaveney1r@addthis.com', 'Male', '573-36-7414', 'Russia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (65, 'Steffen Sellstrom', 'ssellstrom1s@marketwatch.com', 'Female', '415-37-3952', 'Yemen');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (66, 'Clarisse Dering', 'cdering1t@japanpost.jp', 'Male', '257-72-9460', 'Brazil');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (67, 'Cesaro Walbrook', 'cwalbrook1u@i2i.jp', 'Male', '786-93-8189', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (68, 'Cristobal Nussgen', 'cnussgen1v@addthis.com', 'Female', '518-38-8059', 'Slovenia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (69, 'Tove Hovel', 'thovel1w@gmpg.org', 'Female', '638-37-3442', 'United States');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (70, 'Herc Anelay', 'hanelay1x@bloomberg.com', 'Female', '451-17-1961', 'Russia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (71, 'Celina Crosston', 'ccrosston1y@census.gov', 'Male', '584-02-7989', 'Indonesia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (72, 'Harald De Paoli', 'hde1z@google.fr', 'Male', '472-57-6935', 'Mexico');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (73, 'Willabella Pottinger', 'wpottinger20@barnesandnoble.com', 'Female', '696-47-7060', 'France');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (74, 'Krishnah Townsend', 'ktownsend21@ycombinator.com', 'Male', '365-96-6928', 'Poland');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (75, 'Maire MacCaull', 'mmaccaull22@yale.edu', 'Male', '422-82-4881', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (76, 'Marlane De Ruggiero', 'mde23@flavors.me', 'Male', '445-81-2099', 'Vietnam');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (77, 'Ford Greschik', 'fgreschik24@freewebs.com', 'Female', '537-82-7069', 'Vietnam');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (78, 'Kelbee Footer', 'kfooter25@feedburner.com', 'Female', '873-01-5361', 'United States');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (79, 'Biddy Stanmore', 'bstanmore26@i2i.jp', 'Male', '545-52-5455', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (80, 'Patton Bachura', 'pbachura27@prnewswire.com', 'Male', '753-60-6569', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (81, 'Robin Ferrieroi', 'rferrieroi28@marriott.com', 'Male', '646-70-6652', 'Indonesia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (82, 'Quinta Enderby', 'qenderby29@mediafire.com', 'Male', '103-20-2876', 'Cuba');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (83, 'Huntington Brymham', 'hbrymham2a@mit.edu', 'Male', '255-55-1326', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (84, 'Joane Faudrie', 'jfaudrie2b@google.cn', 'Male', '393-28-9241', 'Colombia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (85, 'Bengt Brophy', 'bbrophy2c@bloglovin.com', 'Male', '151-12-0173', 'Canada');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (86, 'Margi Seson', 'mseson2d@adobe.com', 'Female', '739-09-4025', 'Portugal');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (87, 'Melony Mabbett', 'mmabbett2e@howstuffworks.com', 'Male', '864-46-4768', 'Indonesia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (88, 'Thain Coleiro', 'tcoleiro2f@unicef.org', 'Male', '223-47-7196', 'Indonesia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (89, 'Aldric Chalke', 'achalke2g@marriott.com', 'Female', '193-24-3438', 'Sweden');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (90, 'Kerstin Greenrod', 'kgreenrod2h@bbb.org', 'Female', '732-99-1821', 'China');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (91, 'Tonie Joisce', 'tjoisce2i@sphinn.com', 'Female', '203-85-5155', 'Indonesia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (92, 'Sonnie Daulby', 'sdaulby2j@google.co.uk', 'Male', '567-61-7122', 'Indonesia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (93, 'Yvor O''Breen', 'yobreen2k@unesco.org', 'Male', '450-38-3952', 'Kenya');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (94, 'Giffer Dowtry', 'gdowtry2l@parallels.com', 'Female', '633-59-5396', 'Netherlands');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (95, 'Ave Dods', 'adods2m@dailymotion.com', 'Male', '650-77-0324', 'Slovenia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (96, 'Wesley Catterell', 'wcatterell2n@vk.com', 'Male', '833-10-2101', 'Portugal');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (97, 'Hamlen Shaxby', 'hshaxby2o@angelfire.com', 'Female', '757-51-1887', 'Philippines');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (98, 'Gerhard Karolewski', 'gkarolewski2p@dailymail.co.uk', 'Female', '216-69-8228', 'Indonesia');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (99, 'Jedidiah Harbison', 'jharbison2q@meetup.com', 'Male', '793-97-4876', 'Brazil');
INSERT INTO Patients (id, full_name, email, gender, ssn, country) VALUES (100, 'Genia Doak', 'gdoak2r@github.io', 'Male', '540-60-4468', 'Brazil');

INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (1, 'etidronate disodium', 'Etidronate Disodium', 'Mylan Pharmaceuticals Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (2, 'Omeprazole', 'Omeprazole', 'Apotex Corp');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (3, 'Warfarin Sodium', 'Jantoven', 'Upsher-Smith Laboratories, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (4, 'BENZTROPINE MESYLATE', 'BENZTROPINE MESYLATE', 'REMEDYREPACK INC.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (5, 'Methenamine, Sodium Phosphate, Monobasic, Monohydrate, Phenyl Salicylate, Methylene Blue, and Hyoscyamine Sulfate', 'Urimar-T', 'Marnel Pharmaceutical, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (6, 'meclizine hydrochloride', 'Meclizine Hydrochloride', 'NCS HealthCare of KY, Inc dba Vangard Labs');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (7, 'METFORMIN HYDROCHLORIDE', 'METFORMIN HYDROCHLORIDE', 'Aidarex Pharmaceuticals LLC');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (8, 'Verapamil Hydrochloride', 'Verapamil Hydrochloride', 'PD-Rx Pharmaceuticals, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (9, 'Tramadol Hydrochloride', 'Tramadol Hydrochloride', 'Physicians Total Care, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (10, 'Acetaminophen, Dextromethorphan Hydrobromide, Phenylephrine Hydrochloride', 'equate daytime', 'Wal-Mart Stores Inc');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (11, 'Avobenzone, Homosalate, Octisalate, Octocrylene, and Oxybenzone', 'Neutrogena Ultra Sheer Dry Touch Sunscreen', 'Neutrogena Corporation');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (12, '1,4-BENZOQUINONE - ARNICA MONTANA - OXYTOCIN - BARIUM CARBONATE - BARIUM OXALOSUCCINATE - CORTICOTROPIN - LEAD - LEVOTHYROXINE - LUTRELIN - MALIC ACID - MELATONIN - NEUROTROPHIN-3 - NEUROTROPHIN-4 - P', 'GUNA-GERIATRICS', 'Guna spa');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (13, 'SALICYLIC ACID', 'Equate Cleansing Pads', 'Wal-Mart Stores Inc');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (14, 'Chloroxylenol', 'Saniwash Antimicrobial Foaming Hand', 'Safetec of America, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (15, 'OCTINOXATE and TITANIUM DIOXIDE', 'SHISEIDO RADIANT LIFTING FOUNDATION', 'SHISEIDO AMERICA INC.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (16, 'Diphenhydramine HCl', 'Sleep Aid', 'P and L Development of New York Corporation (ReadyInCase)');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (17, 'Lithium Carbonate', 'Lithium Carbonate', 'West-Ward Pharmaceutical Corp');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (18, 'Dextromethorphan Hydrobromide and Phenylephrine Hydrochloride', 'Assured Day time Cold and Cough', 'Bio-Pharm, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (19, 'Bupropion Hydrochloride', 'Bupropion Hydrochloride', 'KAISER FOUNDATION HOSPITALS');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (20, 'Finasteride', 'Finasteride', 'NorthStar Rx LLC');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (21, 'Naproxen Sodium', 'All Day', 'Cardinal Health (Leader) 49781');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (22, 'Strawberry Fragaria chiloensis', 'Food - Plant Source, Strawberry Fragaria chiloensis', 'Jubilant HollisterStier LLC');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (23, 'Naproxen', 'Naproxen', 'Amneal Pharmaceuticals');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (24, 'cefepime hydrochloride', 'Cefepime', 'Sagent Pharmaceuticals');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (25, 'Acetaminophen, DIPHENHYDRAMINE HYDROCHLORIDE, PHENYLEPHRINE HYDROCHLORIDE', 'Flu Relief Therapy Night Time', 'Topco Associates LLC');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (26, 'zinc oxide', 'Dynashield', 'Dynarex Corporation');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (27, 'Dobutamine Hydrochloride', 'Dobutamine Hydrochloride in Dextrose', 'Baxter Healthcare Corporation');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (28, 'Acetaminophen, Dextromethorphan HBr, Doxylamine succinate', 'nighttime cold and flu relief', 'Rite Aid Corporation');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (29, 'Arsenicum album, Phosphorus, Pulsatilla, Sepia, Alternaria tenuis, Aspergillus niger, Rhizopus nigricans,', 'Mold Mix Antigens', 'Apotheca Company');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (30, 'Bisoprolol Fumarate and Hydrochlorothiazide', 'Bisoprolol Fumarate and Hydrochlorothiazide', 'Eon Labs, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (31, 'carbidopa, levodopa and entacapone', 'carbidopa, levodopa and entacapone', 'Wockhardt Limited');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (32, 'Hydrocodone Bitartrate And Acetaminophen', 'Hydrocodone Bitartrate And Acetaminophen', 'Aphena Pharma Solutions - Tennessee, LLC');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (33, 'Donepezil Hydrochloride', 'Donepezil Hydrochloride', 'Physicians Total Care, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (34, 'Chlorpheniramine Maleate', 'Sun Mark Allergy', 'McKesson');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (35, 'Dextromethorphan HBr, Guaifenesin', 'Tussin', 'Kroger Company');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (36, 'hydrocortisone', 'Duane Reade', 'Duane Reade');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (37, 'candida albicans', 'Pleo San Cand', 'Sanum-Kehlbeck GmbH & Co. KG');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (38, 'tazarotene', 'TAZORAC', 'Allergan, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (39, 'Methenamine, Sodium Salicylate', 'Cystex', 'DSE Healthcare Solutions, LLC');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (40, 'Rat Epithelium', 'Rat Epithelium', 'Nelco Laboratories, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (41, 'ISOPROPYL ALCOHOL', 'COGHLANS SURVIVAL IN A CAN', 'Coghlan''s Ltd.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (42, 'Octinoxate and Titanium dioxide', 'SHISEIDO THE MAKEUP PERFECT SMOOTHING COMPACT FOUNDATION (Refill)', 'SHISEIDO CO., LTD.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (43, 'White Petroleum', 'Baby Petroleum', 'Singhfam Corporation');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (44, 'TROSPIUM CHLORIDE', 'TROSPIUM CHLORIDE', 'Apotex Corp.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (45, 'Acetaminophen', 'Pain Reliever', 'Cardinal Health');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (46, 'Alprostadil', 'MUSE', 'Meda Pharmaceuticals Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (47, 'Avobenzone and Octinoxate', 'Dynamic Skin Recovery', 'Dermalogica, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (48, 'clove', 'Letomint', 'H&C 21 America Inc');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (49, 'methscopolamine bromide', 'Methscopolamine Bromide', 'E. Fougera & Co. a division of Fougera Pharmaceuticals Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (50, 'Herpes Simplex I, Herpes Simplex II', 'Herpes Simplex Remedy', 'Deseret Biologicals, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (51, 'POTASSIUM CHLORIDE', 'Potassium Chloride', 'Baxter Healthcare Corporation');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (52, 'Morphine Sulfate', 'Morphine Sulfate', 'ETHEX Corporation');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (53, 'meclizine hydrochloride', 'Zentrip', 'Sato Pharmaceutical Co., Ltd.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (54, 'PREGABALIN', 'Lyrica', 'Aphena Pharma Solutions - Tennessee, LLC');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (55, 'Juglans Regia, Myosotis Arvensis, Scrophularia Nodosa, Teucrium Scorodonia, Veronica Officinalis, Equisetum Hyemale', 'Sore Throat', 'Deseret Biologicals, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (56, 'Polyethylene Glycol 3350', 'ShopRite Clear Laxative', 'Wakefern Food Corporation');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (57, 'Zinc Oxide, Titanium Dioxide', 'GOONG SECRET MILD SUN', '0to7 Inc');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (58, 'ziprasidone hydrochloride', 'ziprasidone hydrochloride', 'REMEDYREPACK INC.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (59, 'Pramipexole Dihydrochloride', 'Pramipexole Dihydrochloride', 'Aurobindo Pharma Limited');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (60, 'Purified Water', 'Eye Irrigating', 'A-S Medication Solutions LLC');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (61, 'Mandragora e rad. 2', 'Mandragora e rad. 2', 'Uriel Pharmacy Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (62, 'Valacyclovir Hydrochloride', 'Valacyclovir Hydrochloride', 'Dr. Reddys Laboratories Limited');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (63, 'pyrithione zinc', 'Lucky', 'Delta Brands Inc');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (64, 'Octinoxate 7.5%', 'Sei Bella Age-Defying Liquid Foundation', 'Melaleuca Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (65, 'Acetaminophen, Dextromethorphan Hydrobromide, Diphenhydramine Hydrochloride, Guaifenesin, and Phenylephrine Hydrochloride', 'Mucinex Fast-Max Day Time Severe Cold and Mucinex Fast-Max Night Time Cold and Flu', 'Reckitt Benckiser LLC');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (66, 'Furosemide', 'Furosemide', 'General Injectables & Vaccines, Inc');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (67, 'Anticoagulant Citrate Phosphate Dextrose (CPD) AND AS-5 Red Cell Preservative', 'TERUFLEX Blood Bag System with Blood Sampling Arm Anticoagulant Citrate Phosphate Dextrose (CPD) AND OPTISOL (AS-5) Red Cell Preservative', 'Terumo Corporation');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (68, 'Gabapentin', 'Gabapentin', 'REMEDYREPACK INC.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (69, 'Celecoxib', 'CELEBREX', 'Rebel Distributors Corp.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (70, 'Ethyl Alcohol', 'XtraCare Instant Hand Sanitizer', 'China Ningbo Shangge Cosmetic Technology Corp');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (71, 'Simvastatin', 'Simvastatin', 'Aphena Pharma Solutions - Tennessee, LLC');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (72, 'NITROGLYCERIN', 'Minitran', 'Medicis Pharmaceutical Corp');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (73, 'Warfarin Sodium', 'Warfarin Sodium', 'Lake Erie Medical DBA Quality Care Products LLC');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (74, 'Acetaminophen', 'pain and fever', 'Meijer Distribution Inc');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (75, 'SODIUM MONOFLUOROPHOSPHATE, SODIUM FLUORIDE', 'PROPOLIS', 'ATOMY CO., LTD.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (76, 'CALCIUM PHOSPHATE, IRON, POTASSIUM PHOSPHATE, UNSPECIFIED FORM, MAGNESIUM PHOSPHATE, DIBASIC TRIHYDRATE, and SODIUM PHOSPHATE', 'NERVE TONIC STRESS RELIEF', 'Hyland''s');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (77, 'BENZALKONIUM CHLORIDE', 'PF ANTI-BACTERIAL HAND SANITIZING WIPES', 'Premium Formulations LLC');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (78, 'Pyrithione Zinc', 'Bioxsine Series', 'B''IOTA Laboratories');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (79, 'cough suppressant topical analgesic', 'CVS Medicated Chest Rub', 'CVS Pharmacy Inc');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (80, 'One Step Clear Wart Remover', 'Salicylic Acid', 'Cardinal Health');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (81, 'Hydralazine', 'Hydralazine', 'Cardinal Health');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (82, 'triamcinolone acetonide', 'triamcinolone acetonide', 'Rebel Distributors Corp');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (83, 'TITANIUM DIOXIDE', 'CLARINS Broad Spectrum SPF 15 Sunscreen Extra-Firming Foundation Tint 113', 'Laboratoires Clarins S.A.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (84, 'Salicylic Acid', 'Garnier Clean Blackhead Eliminating Scrub', 'L''Oreal USA Products Inc');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (85, 'ZINC OXIDE', 'BABYS BUTT AID', 'GREENBRIER INTERNATIONAL INC');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (86, 'Alteplase', 'Activase', 'Genentech, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (87, 'Pantoprazole Sodium', 'Pantoprazole Sodium', 'American Health Packaging');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (88, 'Nicotine Polacrilex', 'Nicotine Polacrilex, Coated Mint Flavor', 'Chain Drug Marketing Association Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (89, 'Avobenzone, Homosalate, Octisalate, Octocrylene and Oxybenzone', 'LOreal Paris Advanced Suncare Silky Sheer 30 Broad Spectrum SPF 30 Sunscreen', 'L''Oreal USA Products Inc');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (90, 'OCTINOXATE and TITANIUM DIOXIDE', 'VITALUMIERE AQUA', 'CHANEL PARFUMS BEAUTE');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (91, 'Yeast Saccharomyces cerevisiae', 'SACCHAROMYCES CEREVISIAE', 'ALK-Abello, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (92, 'Black Birch', 'Black Birch', 'Nelco Laboratories, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (93, 'drospirenone and ethinyl estradiol', 'Yasmin', 'Physicians Total Care, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (94, 'DIPYRIDAMOLE', 'DIPYRIDAMOLE', 'Rising Pharmaceuticals, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (95, 'Ketoconazole', 'Ketoconazole', 'Rebel Distributors Corp');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (96, 'Dextroamphetamine Saccharate, Amphetamine Aspartate, Dextroamphetamine Sulfate, and Amphetamine Sulfate', 'Adderall', 'Teva Select Brands');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (97, 'Ceftriaxone Sodium', 'Ceftriaxone Sodium', 'Sandoz Inc');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (98, 'Tacrolimus', 'Tacrolimus', 'Sandoz Inc');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (99, 'Oat Smut', 'Oat Smut', 'Nelco Laboratories, Inc.');
INSERT INTO Drugs (id, drug_name, drug_brand, drug_company) VALUES (100, 'isotretinoin', 'Claravis', 'Physicians Total Care, Inc.');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO Purchases (patient_ssn, drug_id)
SELECT 
 	--COUNT(*)
 	ssn,
 	drug_id
FROM
(
SELECT
 	p.ssn AS ssn,
 	d.id AS drug_id,
 	random() AS random 
FROM
 	Patients AS p
CROSS JOIN
 	Drugs AS d
ORDER BY random -- breakup the initial order of the selected values with cross join
LIMIT 1000 -- choose 10% rows
);
