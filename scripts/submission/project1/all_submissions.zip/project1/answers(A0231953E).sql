/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/* Student Name: Nanhai Zhong    Student ID: A0231953E                  */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for SQLite*/

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* The code is written for SQLite*/

/*
This example is based on the Electronic Road Pricing System of Singapore, 
which is used to alleviate road congestions by charging owners of the 
vehicles according to their driving during specific time period on 
specific roads. Therefore, in order to store the data of the charging 
records, this database contains three tables: vehicle_ownershp,ERP and 
charging_records.*/

/*
Vehicle_ownership table shows the detailed information of each vehicle 
and provides the link between each vehicle and its owner, by including 6 
attributes: license plate number, owner's identification number, vehicle 
identification number, car make, car model and car model year. Because 
what monitors only can get is the license plate number, the license_plate_no 
is chosen to be the primary key. Considering that someone could own more 
than one vehicles, the owner_id is not unique but is not null. In addition, 
since vehicle identification numbers can identify each car, the car_vin 
is unique and not null, while the other attributes could be null.*/

/*
ERP table demonstrates the charging rules of the specific roads at specific
times, by including 5 attributes: period (weekdays or saturdays), time 
period number (from 1 to 93, divided each 30 minutes into 3 pieces from 
7:00am to 22:30pm), road name, road type (Orchard Cordon and Rest of CBD, 
Arterial Roads or Expressways) and ERP rate (the charging fee). Among all 
the attibutes, period, time period number, road name and ERP rate consist 
the primary key so that there will be only one charging rule for each 
situation.*/

/*
Charging_records table is used to record the charging history of ERP System.
There are 8 attributes in this table. The first one is record number. The 
second is license plate number to show which vehicle should be charged 
referring to the one in vehicle_ownership table. The third to the sixth are 
the features in the primary key of ERP table. The seventh is a binary  
feature, driving, which will be 1 if the vehicle has driving on this road 
at the corresponding time period and will be 0 if not. The final is also a 
binary feature, unpaied, which shows the paying status. If the owner has 
already paied the bill, it will be 0. Otherwise, it will be 1. Since those 
who haven't driving on this road at this time don't need to pay, so the 
driving feature and unpaid feature should never be both 0. The license plate 
number, period, time period number and road name consist the primary key so 
that each record can link to only one vehicle's only one driving action.*/

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* Create vehicle_ownership table: */
CREATE TABLE vehicle_ownership (
license_plate_no CHAR(8) NOT NULL PRIMARY KEY,
owner_id CHAR(9) NOT NULL,
car_vin VARCHAR(17) UNIQUE NOT NULL,
car_make VARCHAR(32),
car_model VARCHAR(32),
car_year YEAR(4));

/* Create ERP table: */
CREATE TABLE ERP (
period VARCHAR(10) NOT NULL,
time_no INT(2) NOT NULL CHECK (time_no <= 93 and time_no > 0),
road_name VARCHAR(512) NOT NULL,
road_type VARCHAR(54) NOT NULL,
rate DECIMAL(4,2) NOT NULL DEFAULT 0.00,
PRIMARY KEY (period, time_no, road_name, rate));

/* Create charging_records table: */
CREATE TABLE charging_records (
record_no VARCHAR(24) NOT NULL,
license_plate_no CHAR(8) REFERENCES vehicle_ownership(license_plate_no)
    ON UPDATE CASCADE
    DEFERRABLE INITIALLY DEFERRED,
period VARCHAR(10),
time_no INT(2),
road_name VARCHAR(512),
rate DECIMAL(4,2),
driving BOOLEAN NOT NULL DEFAULT 1,
unpaid BOOLEAN NOT NULL DEFAULT 1 CHECK (driving + unpaid <> 0),
FOREIGN KEY (period, time_no, road_name, rate) REFERENCES ERP(period, time_no, road_name, rate)
    ON UPDATE CASCADE
    DEFERRABLE INITIALLY DEFERRED,
PRIMARY KEY (license_plate_no, period, time_no, road_name));


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* Insert into vehicle_ownership table: */
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA7870I', 'S5706370J', '2C3CCAGG7CH636058', 'Lexus', 'HS', 2011);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA7306T', 'S4705238H', '1G4GG5E34DF403939', 'Toyota', 'Sienna', 1998);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA2170E', 'S1606966X', 'WBA3F9C54FK738918', 'Infiniti', 'QX56', 2009);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA5696H', 'S6227397H', 'WBAUN1C51CV133760', 'Ford', 'F250', 2004);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA6401G', 'S3738560Y', 'KM8JT3AB7DU334386', 'Chevrolet', 'Silverado 1500', 2008);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA2992M', 'S3836901K', '4F2CY0C79BK941484', 'Pontiac', 'Parisienne', 1985);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA1586A', 'S4646216J', '2B3CJ4DVXAH043301', 'Nissan', 'Pathfinder', 1993);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA7036T', 'S5994922S', 'JTDKN3DPXF3607985', 'Lexus', 'GS', 2010);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA5532H', 'S2473695L', '5NPDH4AE3DH253446', 'Pontiac', 'Sunfire', 2000);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA0117P', 'S4218298B', '4T1BK3DB9BU929787', 'Pontiac', 'GTO', 2004);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA6627B', 'S7521987P', 'WP0AB2A87CU003795', 'Toyota', 'Corolla', 2011);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA3463Q', 'S4351571G', 'KMHFC4DDXAA237771', 'Mitsubishi', 'Outlander Sport', 2012);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA6615B', 'S1051288V', 'WBA3B3C52EF661160', 'Volkswagen', 'Jetta', 2012);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA5908W', 'S0974078A', 'WAU2GAFC1FN260038', 'Pontiac', 'Bonneville', 1967);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA7647F', 'S6355274F', 'YV4902DZ6E2397962', 'Chevrolet', 'Impala', 2004);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA1667G', 'S6113127G', '2C3CDXHGXDH570802', 'Jaguar', 'S-Type', 2002);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA9962N', 'S9488253W', '3MZBM1U76EM476961', 'Suzuki', 'SX4', 2009);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA1638C', 'S5136282G', '5NPDH4AEXDH883111', 'Chevrolet', 'Cavalier', 2004);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA0104M', 'S6521627B', 'WAUEFAFL1DA155486', 'Mazda', 'MX-5', 2001);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA1441V', 'S2558135E', '5N1AN0NU8BC438070', 'Mazda', 'B-Series', 2000);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA0498Y', 'S5835362K', 'JM1NC2LF3D0449803', 'Ford', 'E150', 2005);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA3963U', 'S3136433F', 'WP0AB2A88CU628139', 'BMW', '3 Series', 1996);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA9255C', 'S2214066S', 'SCFAB42381K131360', 'Buick', 'Century', 2005);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA4243U', 'S1743543N', 'WBAAW33461E944423', 'Mitsubishi', 'Truck', 1989);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA0377Q', 'S2726252C', '2HNYD2H47CH462625', 'GMC', 'Rally Wagon 3500', 1994);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA3417A', 'S4053984N', '1D4SD6GT7BC584451', 'Mazda', 'MX-6', 1997);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA3475I', 'S3870991U', '5GAKVAKD5EJ182541', 'Mitsubishi', 'Lancer', 2010);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA6472A', 'S0677033O', '1HGCR2E50FA649420', 'Mercedes-Benz', 'M-Class', 2004);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA6808X', 'S0310630A', '2C3CDZBT8FH626188', 'Chrysler', 'Imperial', 1993);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA8658Q', 'S9001304O', '5XXGM4A77EG978491', 'Chrysler', 'LeBaron', 1994);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA2420G', 'S6418067P', 'WBAFR1C55BD952546', 'GMC', 'Savana 2500', 2009);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA8068B', 'S9613705N', 'WBANV13579B271219', 'Jeep', 'Compass', 2011);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA1670Y', 'S3465487Z', 'WBA3R1C57EK750973', 'Dodge', 'Grand Caravan', 1992);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA2595G', 'S8643323M', 'WAUBFAFL4CA431659', 'Buick', 'Skylark', 1985);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA4063H', 'S0468349A', 'WAUKH68D71A060832', 'Dodge', 'Shadow', 1992);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA8252M', 'S8024223D', 'WBAUU3C57CA885355', 'Peugeot', '207', 2006);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA6735Y', 'S6776058Q', 'WA1KK98R59A516270', 'Honda', 'Fit', 2010);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA3564S', 'S3465924V', '5J6TF2H55EL886615', 'Mercedes-Benz', 'SL-Class', 1993);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA1919L', 'S5957055Q', '1YVHZ8BH9C5219051', 'Lexus', 'LS', 2009);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA2798Y', 'S7373461H', 'WAULT58E45A591384', 'Hyundai', 'Elantra', 2006);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA7630Z', 'S1484488C', 'WBAEW53433P743616', 'Aston Martin', 'V8 Vantage', 2006);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA1374A', 'S0376433U', 'WVWAP7ANXDE216806', 'Dodge', 'Ram', 2008);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA1593S', 'S1513487O', 'WBAKG1C52BE278886', 'Nissan', 'Quest', 2007);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA7446R', 'S1705618B', 'WAUEH74F07N426299', 'Ford', 'E-Series', 2003);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA3058C', 'S7037651X', '3C6LD4AT6CG468856', 'Chrysler', 'PT Cruiser', 2007);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA0093C', 'S8945654H', 'JN8AZ1MU7DW220837', 'Toyota', 'Celica', 2002);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA2995G', 'S3118456E', '55SWF4JBXFU200358', 'Volkswagen', 'GTI', 1986);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA4583B', 'S9200393B', '1GTN1TEX8DZ548193', 'Chrysler', 'Concorde', 1996);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA7615Y', 'S2102205N', 'WBAXA5C55ED108997', 'Chevrolet', 'Suburban 1500', 2012);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA9846A', 'S5570079C', '4T1BF1FK5DU468645', 'Hummer', 'H3', 2009);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA5256P', 'S2325637H', '5FPYK1F2XEB303413', 'Toyota', 'Celica', 1994);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA3285C', 'S2480269B', '1G6DC1ED3B0361061', 'Saab', '900', 1988);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA9526E', 'S9039824C', '2G61P5S36E9512835', 'Chevrolet', 'Metro', 2000);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA1777Q', 'S1600102L', 'SCFEBBBK6BG683702', 'Audi', 'A6', 2004);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA5935P', 'S6386977A', '1GYFK438X8R480501', 'Volvo', 'V70', 2001);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA0296R', 'S9728580M', 'WAULD64B23N412067', 'Volkswagen', 'Touareg', 2010);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA5532S', 'S0791550W', 'WAUKF78E17A438916', 'Audi', 'S4', 2004);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA7048P', 'S4614104S', 'WAUEV94F57N618760', 'Ford', 'Explorer Sport', 2002);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA5987J', 'S6387189X', '1GD311CG0FF416365', 'Suzuki', 'Grand Vitara', 2004);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA7782B', 'S1980339O', 'WBAWC73539E853054', 'Mazda', 'MX-5', 1991);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA7269T', 'S5422113V', 'SCBDC47L79C623422', 'Porsche', 'Panamera', 2012);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA0235W', 'S2273926H', 'WBABW33486P085805', 'Toyota', 'Yaris', 2006);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA1162O', 'S1050642Y', '1FTSX2B56AE996835', 'Dodge', 'Neon', 1996);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA6761W', 'S4191794F', '1GKS1GEJ5BR253219', 'Audi', 'A8', 1998);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA5805V', 'S6368946O', 'WAUSGAFCXCN758735', 'Honda', 'Prelude', 1992);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA4791L', 'S4130773J', '5NPDH4AE2EH553660', 'Toyota', '4Runner', 2009);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA6338K', 'S9020988H', '1FMJK1F55AE907721', 'Lincoln', 'LS', 2000);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA6291Y', 'S0293608B', 'WBAEV53403K235426', 'Chevrolet', 'Caprice Classic', 1995);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA8436C', 'S5603268L', '5NPEB4AC4CH627243', 'Volkswagen', 'Cabriolet', 1989);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA7256W', 'S2729417X', 'JN8AF5MR7CT109720', 'Chevrolet', 'Impala', 2006);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA2131J', 'S4900509C', 'JN8AZ2KR2ET699207', 'Jaguar', 'XJ', 2010);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA2284D', 'S1363179Q', '1G6AG5RX0E0396907', 'Ford', 'Laser', 1987);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA9034L', 'S1153496A', '1C3CCBBBXEN957569', 'Bentley', 'Brooklands', 2009);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA4024J', 'S8430833D', 'WBAUN93518V181569', 'Ford', 'E250', 2008);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA2211J', 'S1627156H', 'JH4CL96946C371862', 'GMC', 'Savana 3500', 2012);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA4605I', 'S0934028Y', '1G6AU5S89E0522693', 'Cadillac', 'Seville', 1992);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA3498G', 'S7376012I', '2V4RW3DG1BR200351', 'MINI', 'Cooper', 2007);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA5699Q', 'S7093655A', 'JN8AE2KP9D9410815', 'Aston Martin', 'Virage', 2012);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA4578H', 'S7681228E', 'JN1CV6AP1CM340609', 'Chevrolet', 'Cavalier', 2001);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA9318Z', 'S9968130H', 'SCFAB02A56G260674', 'Mercury', 'Grand Marquis', 1999);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA9743F', 'F3324037I', '1G6KE54Y55U607229', 'Mercedes-Benz', '400SEL', 1993);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA6883Q', 'F9351973U', 'WBAHN03558D650780', 'Nissan', 'Xterra', 2004);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA8519U', 'F2982000S', 'WAULFAFH5EN629808', 'Land Rover', 'Discovery', 2006);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA9968H', 'F8467568I', 'JH4DC53833C503806', 'Maybach', '57', 2007);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA7308M', 'F9279597J', 'JN1AZ4EH1AM629926', 'Ford', 'Tempo', 1986);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA0507R', 'F4229107O', 'WBAGL83555D062745', 'Mitsubishi', 'Mirage', 2002);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA2614J', 'F0190023Q', '1GYFK56219R319081', 'Chevrolet', 'Astro', 1995);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA1161T', 'F0613410X', 'WAUBFCFL2CN892766', 'Mercury', 'Montego', 2007);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA2064P', 'F0082318T', 'SCBLC37F86C710659', 'Chevrolet', 'Corvette', 1999);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA8316H', 'F2871114M', '3C3CFFJH7ET248537', 'BMW', 'X5', 2012);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA7100X', 'F6016569X', 'KMHTC6AD9FU977692', 'Buick', 'Riviera', 1990);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA6224B', 'F5889893D', '5NPDH4AE1DH295047', 'Lexus', 'LX', 2008);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA7265K', 'F9781543A', 'WA1CGCFE3BD416286', 'Audi', 'A6', 1998);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA0231V', 'F1532641O', '1ZVBP8JZ8E5587040', 'Hyundai', 'Elantra', 1996);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA4782O', 'F9873790N', '1FTSW2B51AE996440', 'Audi', 'Coupe GT', 1987);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA2558W', 'G0574122R', '1GKMCCE37AR267960', 'Subaru', 'Legacy', 2008);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA6376G', 'G2955176Z', '5TDBK3EH2DS258932', 'Ford', 'Mustang', 2013);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA6683S', 'G0968589M', '1FTSW2B57AE340372', 'Chevrolet', 'Vega', 1971);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA6400O', 'G7479940P', 'SALAG2D40DA783581', 'Mercedes-Benz', 'CL65 AMG', 2009);
insert into vehicle_ownership (license_plate_no, owner_id, car_vin, car_make, car_model, car_year) values ('SBA0535P', 'G4290782J', '5TDBM5G19CS934071', 'Hyundai', 'Tucson', 2006);


/* Insert into ERP table: */
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 49, '6820 Wayridge Point', 'Expressways', 2.09);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 26, '4453 5th Plaza', 'Arterial Roads', 1.63);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 55, '8 Walton Avenue', 'Arterial Roads', 1.29);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 85, '9 Schiller Parkway', 'Expressways', 2.65);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 86, '5 Lakeland Avenue', 'Arterial Roads', 1.54);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 84, '6949 Erie Avenue', 'Arterial Roads', 1.36);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 25, '7155 Lakewood Road', 'Orchard Cordon and Rest of CBD', 1.91);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 51, '8 Vera Hill', 'Orchard Cordon and Rest of CBD', 1.3);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 70, '3 Kensington Drive', 'Orchard Cordon and Rest of CBD', 2.38);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 8, '0 Mandrake Junction', 'Orchard Cordon and Rest of CBD', 1.9);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 79, '8 Artisan Pass', 'Orchard Cordon and Rest of CBD', 0.88);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 50, '871 New Castle Crossing', 'Arterial Roads', 0.99);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 78, '68475 Fairview Street', 'Expressways', 0.49);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 42, '4707 Cody Junction', 'Expressways', 2.41);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 2, '8 Northfield Point', 'Expressways', 0.75);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 88, '37 Emmet Point', 'Expressways', 1.57);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 29, '76476 Hollow Ridge Park', 'Expressways', 2.17);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 60, '41 Tennyson Center', 'Orchard Cordon and Rest of CBD', 1.41);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 47, '8 Monterey Trail', 'Expressways', 0.83);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 22, '532 Upham Avenue', 'Expressways', 2.99);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 10, '3782 Hazelcrest Trail', 'Expressways', 0.62);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 16, '5 Ohio Hill', 'Arterial Roads', 0.48);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 17, '7 3rd Way', 'Expressways', 1.63);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 65, '0640 Dovetail Trail', 'Arterial Roads', 1.67);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 43, '24009 Mayer Road', 'Expressways', 1.73);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 59, '43520 David Drive', 'Orchard Cordon and Rest of CBD', 0.53);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 64, '289 Lawn Drive', 'Arterial Roads', 1.45);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 44, '4 Eggendart Way', 'Arterial Roads', 2.25);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 49, '1955 Dakota Point', 'Orchard Cordon and Rest of CBD', 1.19);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 74, '2 Helena Lane', 'Orchard Cordon and Rest of CBD', 0.85);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 4, '66 Warrior Lane', 'Orchard Cordon and Rest of CBD', 2.05);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 34, '6801 Northland Way', 'Expressways', 1.42);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 86, '903 Waxwing Alley', 'Expressways', 0.49);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 39, '656 Fieldstone Center', 'Orchard Cordon and Rest of CBD', 2.27);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 70, '7 Crownhardt Trail', 'Arterial Roads', 2.36);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 48, '1 Scott Point', 'Arterial Roads', 2.51);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 67, '6 Valley Edge Junction', 'Expressways', 0.16);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 38, '887 Morrow Street', 'Orchard Cordon and Rest of CBD', 1.87);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 33, '4 Lyons Center', 'Expressways', 2.95);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 61, '9887 Pierstorff Center', 'Arterial Roads', 2.08);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 44, '44 Summerview Road', 'Expressways', 2.49);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 76, '78582 Macpherson Point', 'Arterial Roads', 0.85);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 13, '653 Bartelt Alley', 'Expressways', 0.49);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 52, '61 Sundown Court', 'Orchard Cordon and Rest of CBD', 1.55);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 81, '365 Memorial Plaza', 'Arterial Roads', 0.64);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 67, '33 Kenwood Crossing', 'Arterial Roads', 1.69);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 22, '391 Heffernan Trail', 'Orchard Cordon and Rest of CBD', 1.65);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 21, '23128 Vermont Crossing', 'Expressways', 1.39);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 61, '68859 Washington Hill', 'Expressways', 2.85);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 47, '39820 East Street', 'Expressways', 1.52);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 52, '25 Vernon Drive', 'Expressways', 2.87);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 78, '1 Anhalt Street', 'Expressways', 1.79);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 15, '6524 Summer Ridge Street', 'Orchard Cordon and Rest of CBD', 0.15);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 39, '18370 Gulseth Street', 'Orchard Cordon and Rest of CBD', 2.3);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 71, '775 Mcguire Terrace', 'Arterial Roads', 0.65);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 59, '75375 Michigan Road', 'Orchard Cordon and Rest of CBD', 1.64);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 79, '3 Havey Trail', 'Orchard Cordon and Rest of CBD', 0.73);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 69, '5877 Acker Place', 'Arterial Roads', 2.14);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 43, '2524 Rockefeller Drive', 'Arterial Roads', 1.61);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 24, '40 Sundown Road', 'Arterial Roads', 1.51);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 43, '346 Merry Alley', 'Orchard Cordon and Rest of CBD', 1.06);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 69, '37241 Mandrake Road', 'Arterial Roads', 2.29);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 2, '10039 Elmside Trail', 'Orchard Cordon and Rest of CBD', 1.49);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 37, '4 Novick Way', 'Expressways', 1.65);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 7, '57966 Hooker Junction', 'Orchard Cordon and Rest of CBD', 1.26);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 47, '50496 Stuart Point', 'Expressways', 2.78);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 28, '98734 Rowland Junction', 'Expressways', 1.05);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 36, '454 Gale Lane', 'Expressways', 2.65);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 69, '7 American Ash Way', 'Arterial Roads', 1.39);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 24, '9 Debs Circle', 'Expressways', 0.01);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 33, '961 Upham Terrace', 'Expressways', 0.05);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 72, '6 Hoepker Plaza', 'Orchard Cordon and Rest of CBD', 0.88);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 14, '6780 Mayfield Hill', 'Expressways', 1.97);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 75, '77 Coolidge Road', 'Arterial Roads', 1.15);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 5, '071 Vahlen Lane', 'Orchard Cordon and Rest of CBD', 0.96);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 1, '7 Fairfield Center', 'Arterial Roads', 2.94);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 51, '7 Lake View Terrace', 'Expressways', 1.99);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 18, '9 Green Point', 'Arterial Roads', 2.47);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 30, '2700 Anzinger Terrace', 'Expressways', 1.84);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 40, '148 Lillian Alley', 'Expressways', 2.16);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 44, '618 Derek Road', 'Arterial Roads', 2.58);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 16, '47 Bartelt Park', 'Arterial Roads', 0.71);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 66, '7 Gale Parkway', 'Expressways', 1.37);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 3, '1421 Welch Plaza', 'Expressways', 1.06);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 24, '62488 Anniversary Circle', 'Expressways', 1.42);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 7, '19 Pearson Park', 'Expressways', 2.35);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 77, '20640 Artisan Street', 'Orchard Cordon and Rest of CBD', 0.03);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 9, '26 Reinke Junction', 'Arterial Roads', 2.43);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 34, '2 Monica Center', 'Arterial Roads', 0.73);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 44, '77535 Meadow Valley Street', 'Orchard Cordon and Rest of CBD', 1.89);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 5, '645 Chive Road', 'Orchard Cordon and Rest of CBD', 0.41);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 48, '436 Parkside Way', 'Arterial Roads', 2.43);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 60, '30 Clove Center', 'Arterial Roads', 0.7);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 85, '572 Butterfield Pass', 'Arterial Roads', 1.38);
insert into ERP (period, time_no, road_name, road_type, rate) values ('weekdays', 51, '5512 Thierer Hill', 'Arterial Roads', 2.94);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 47, '8 Paget Alley', 'Expressways', 0.96);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 27, '40476 Portage Way', 'Expressways', 0.16);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 56, '51 Oak Valley Trail', 'Expressways', 0.29);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 23, '65 Reinke Crossing', 'Arterial Roads', 1.76);
insert into ERP (period, time_no, road_name, road_type, rate) values ('saturdays', 5, '9446 Westerfield Place', 'Orchard Cordon and Rest of CBD', 0.57);



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* Insert into charging_records: */
INSERT INTO charging_records (record_no, license_plate_no, period, time_no, road_name, rate, driving)
SELECT DISTINCT random() as record_no, license_plate_no, period, time_no, road_name, rate, abs(random()) % 2 as driving
FROM vehicle_ownership, ERP
ORDER BY random()
LIMIT 1000;
