/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */
/*                                                                      */
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*                                                                      */
-- This application involves setting up 3 tables for a registry of
-- endangered animals linked to individuals who are licensed to foster them.
-- This is inspired by a federal white paper in USA which is considering 
-- issuing permits for applicants who want to help enhance breeding  
-- and survival of endangered animals.
/*                                                                      */
-- E1: The first table (animals) contains the animal details (4 columns). 
-- These are the scientific_name, common_name, endangered_status and 
-- license_needed columns. The primary key is the scientific_name of the 
-- animal which is unique to every species. 
-- There are 4 unique endangered_status (vulnerable, endangered, 
-- critically endangered and extinct in wild). License_needed is coded as 
-- true/false and only the vulnerable status does not require a license 
-- to own (i.e. false). This is enforced via CHECK constraints.
-- In addtion, endangered_status and license_needed have a NOT NULL constraint.
/*                                                                      */
-- E2: The second table (licensed_owners) contains details of licensed owners of 
-- endangered animals (7 columns). These are license_num, first_name, last_name,
-- email_address, address, us_city and us_state which are details that would be 
-- typically collected during a license application process. 
-- The primary key is the license_num as this is a unique number issued to 
-- all individuals who have been licensed. 
-- NOT NULL constraints are applied to email_address and first_name to ensure
-- that the table captures sufficient detail to reach out to owners.
/* 
-- R: Assuming the government has implemented mandatory registration each time 
-- owners want to foster more endangered animals (excluding the 'vulnerable'
-- status for which a license is not required), this table captures species 
-- registered to each license. Each entry represents the registration of 
-- 1 animal in that species (scientific_name) to each license holder (license_num).
-- Both fields (scientific_name and license_num) are foreign keys
-- to ensure that all registrations are for animals that exist in the
-- endangered animals table and that the registration applicant has a valid
-- license in the licensed_owners table.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

START TRANSACTION;

CREATE TABLE IF NOT EXISTS animals (
    scientific_name VARCHAR(256) PRIMARY KEY,
    common_name VARCHAR(256),
    endangered_status VARCHAR(64) NOT NULL, 
    license_needed VARCHAR(32) NOT NULL,
    CONSTRAINT status_restriction
        CHECK(endangered_status in ('vulnerable', 'endangered', 'critically endangered', 'extinct in wild')
        ),
    CONSTRAINT license_needed_if
        CHECK(
            (endangered_status = 'vulnerable' AND license_needed = 'False') OR
            (endangered_status != 'vulerable' AND license_needed = 'True')
        )
);

CREATE TABLE IF NOT EXISTS licensed_owners (
    license_num INT PRIMARY KEY,
    first_name VARCHAR(32) NOT NULL,
    last_name VARCHAR(32),
    email_address VARCHAR(256) NOT NULL,
    address VARCHAR(256),
    us_city VARCHAR(32),
    us_state VARCHAR(32)
);

CREATE TABLE IF NOT EXISTS register (
    scientific_name VARCHAR(256) REFERENCES animals(scientific_name) DEFERRABLE INITIALLY DEFERRED, 
    license_num INT REFERENCES licensed_owners(license_num) DEFERRABLE INITIALLY DEFERRED
);

COMMIT; 

/* do not cascade FK updates, don't want undetected deletions of data */

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* Populating the animals table */
START TRANSACTION;

INSERT INTO animals VALUES ('melursus ursinus','bear, sloth','endangered','True');
INSERT INTO animals VALUES ('amazona sp.','amazon parrot (unidentified)','extinct in wild','True');
INSERT INTO animals VALUES ('axis axis','chital','endangered','True');
INSERT INTO animals VALUES ('oxybelis sp.','vine snake (unidentified)','critically endangered','True');
INSERT INTO animals VALUES ('vulpes vulpes','fox, north american red','extinct in wild','True');
INSERT INTO animals VALUES ('herpestes javanicus','javan gold-spotted mongoose','extinct in wild','True');
INSERT INTO animals VALUES ('suricata suricatta','suricate','extinct in wild','True');
INSERT INTO animals VALUES ('ictonyx striatus','polecat, african','extinct in wild','True');
INSERT INTO animals VALUES ('helogale undulata','eastern dwarf mongoose','extinct in wild','True');
INSERT INTO animals VALUES ('geochelone radiata','radiated tortoise','endangered','True');
INSERT INTO animals VALUES ('boa constrictor mexicana','boa, mexican','endangered','True');
INSERT INTO animals VALUES ('stenella coeruleoalba','striped dolphin','endangered','True');
INSERT INTO animals VALUES ('lasiorhinus latifrons','wombat, southern hairy-nosed','critically endangered','True');
INSERT INTO animals VALUES ('corythornis cristata','malachite kingfisher','endangered','True');
INSERT INTO animals VALUES ('capreolus capreolus','deer, roe','extinct in wild','True');
INSERT INTO animals VALUES ('catharacta skua','skua, great','endangered','True');
INSERT INTO animals VALUES ('oreamnos americanus','goat, mountain','extinct in wild','True');
INSERT INTO animals VALUES ('lama pacos','alpaca','vulnerable','False');
INSERT INTO animals VALUES ('zenaida galapagoensis','galapagos dove','endangered','True');
INSERT INTO animals VALUES ('lamprotornis sp.','glossy starling (unidentified)','critically endangered','True');
INSERT INTO animals VALUES ('streptopelia decipiens','mourning collared dove','endangered','True');
INSERT INTO animals VALUES ('dolichitus patagonum','mara','extinct in wild','True');
INSERT INTO animals VALUES ('pteropus rufus','madagascar fruit bat','endangered','True');
INSERT INTO animals VALUES ('gabianus pacificus','gull, pacific','critically endangered','True');
INSERT INTO animals VALUES ('bradypus tridactylus','sloth, pale-throated three-toed','vulnerable','False');
INSERT INTO animals VALUES ('sylvilagus floridanus','rabbit, eastern cottontail','endangered','True');
INSERT INTO animals VALUES ('meleagris gallopavo','turkey, common','critically endangered','True');
INSERT INTO animals VALUES ('agkistrodon piscivorus','moccasin, water','endangered','True');
INSERT INTO animals VALUES ('sterna paradisaea','tern, arctic','endangered','True');
INSERT INTO animals VALUES ('nannopterum harrisi','flightless cormorant','endangered','True');
INSERT INTO animals VALUES ('crotalus adamanteus','rattlesnake, eastern diamondback','critically endangered','True');
INSERT INTO animals VALUES ('zalophus californicus','galapagos sea lion','endangered','True');
INSERT INTO animals VALUES ('coluber constrictor foxii','blue racer','critically endangered','True');
INSERT INTO animals VALUES ('melanerpes erythrocephalus','woodpecker, red-headed','critically endangered','True');
INSERT INTO animals VALUES ('phalaropus fulicarius','phalarope, grey','critically endangered','True');
INSERT INTO animals VALUES ('propithecus verreauxi','verreaux''s sifaka','critically endangered','True');
INSERT INTO animals VALUES ('alcelaphus buselaphus caama','hartebeest, red','extinct in wild','True');
INSERT INTO animals VALUES ('vanellus armatus','blacksmith plover','extinct in wild','True');
INSERT INTO animals VALUES ('eremophila alpestris','horned lark','endangered','True');
INSERT INTO animals VALUES ('haematopus ater','blackish oystercatcher','extinct in wild','True');
INSERT INTO animals VALUES ('milvago chimachima','caracara, yellow-headed','endangered','True');
INSERT INTO animals VALUES ('sceloporus magister','lizard, desert spiny','critically endangered','True');
INSERT INTO animals VALUES ('falco peregrinus','peregrine falcon','vulnerable','False');
INSERT INTO animals VALUES ('mycteria ibis','stork, yellow-billed','extinct in wild','True');
INSERT INTO animals VALUES ('corvus albus','crow, pied','vulnerable','False');
INSERT INTO animals VALUES ('trachyphonus vaillantii','barbet, crested','extinct in wild','True');
INSERT INTO animals VALUES ('damaliscus lunatus','tsessebe','vulnerable','False');
INSERT INTO animals VALUES ('tragelaphus angasi','nyala','endangered','True');
INSERT INTO animals VALUES ('felis libyca','cape wild cat','extinct in wild','True');
INSERT INTO animals VALUES ('spermophilus tridecemlineatus','thirteen-lined squirrel','critically endangered','True');
INSERT INTO animals VALUES ('panthera leo','african lion','vulnerable','False');
INSERT INTO animals VALUES ('snycerus caffer','buffalo, african','endangered','True');
INSERT INTO animals VALUES ('antidorcas marsupialis','springbuck','extinct in wild','True');
INSERT INTO animals VALUES ('phalaropus lobatus','phalarope, red-necked','critically endangered','True');
INSERT INTO animals VALUES ('otocyon megalotis','bat-eared fox','extinct in wild','True');
INSERT INTO animals VALUES ('microcavia australis','cuis','extinct in wild','True');
INSERT INTO animals VALUES ('eubalaena australis','southern right whale','critically endangered','True');
INSERT INTO animals VALUES ('spermophilus lateralis','squirrel, golden-mantled ground','extinct in wild','True');
INSERT INTO animals VALUES ('ourebia ourebi','oribi','endangered','True');
INSERT INTO animals VALUES ('lepus townsendii','jackrabbit, white-tailed','extinct in wild','True');
INSERT INTO animals VALUES ('panthera tigris','tiger','extinct in wild','True');
INSERT INTO animals VALUES ('procyon lotor','common raccoon','extinct in wild','True');
INSERT INTO animals VALUES ('motacilla aguimp','wagtail, african pied','extinct in wild','True');
INSERT INTO animals VALUES ('branta canadensis','canada goose','critically endangered','True');
INSERT INTO animals VALUES ('anhinga rufa','african darter','extinct in wild','True');
INSERT INTO animals VALUES ('ara macao','macaw, scarlet','critically endangered','True');
INSERT INTO animals VALUES ('oreotragus oreotragus','klipspringer','vulnerable','False');
INSERT INTO animals VALUES ('myrmecobius fasciatus','numbat','critically endangered','True');
INSERT INTO animals VALUES ('mellivora capensis','honey badger','vulnerable','False');
INSERT INTO animals VALUES ('corvus albicollis','cape raven','critically endangered','True');
INSERT INTO animals VALUES ('porphyrio porphyrio','moorhen, purple','critically endangered','True');
INSERT INTO animals VALUES ('limnocorax flavirostra','african black crake','vulnerable','False');
INSERT INTO animals VALUES ('pelecanus occidentalis','pelican, brown','extinct in wild','True');
INSERT INTO animals VALUES ('macropus giganteus','kangaroo, eastern grey','extinct in wild','True');
INSERT INTO animals VALUES ('diceros bicornis','rhinoceros, black','vulnerable','False');
INSERT INTO animals VALUES ('vanellus sp.','lapwing (unidentified)','critically endangered','True');
INSERT INTO animals VALUES ('mazama americana','red brocket','critically endangered','True');
INSERT INTO animals VALUES ('chauna torquata','screamer, southern','endangered','True');
INSERT INTO animals VALUES ('morelia spilotes variegata','python, carpet','vulnerable','False');
INSERT INTO animals VALUES ('charadrius tricollaris','three-banded plover','extinct in wild','True');
INSERT INTO animals VALUES ('choriotis kori','bustard, kori','vulnerable','False');
INSERT INTO animals VALUES ('lycaon pictus','african wild dog','endangered','True');
INSERT INTO animals VALUES ('leptoptilos crumeniferus','marabou stork','critically endangered','True');
INSERT INTO animals VALUES ('neotoma sp.','woodrat (unidentified)','critically endangered','True');
INSERT INTO animals VALUES ('haliaeetus leucocephalus','bald eagle','vulnerable','False');
INSERT INTO animals VALUES ('sula nebouxii','blue-footed booby','extinct in wild','True');
INSERT INTO animals VALUES ('dasypus septemcincus','seven-banded armadillo','vulnerable','False');
INSERT INTO animals VALUES ('pterocles gutturalis','yellow-throated sandgrouse','critically endangered','True');
INSERT INTO animals VALUES ('canis aureus','indian jackal','extinct in wild','True');
INSERT INTO animals VALUES ('phacochoerus aethiopus','warthog','extinct in wild','True');
INSERT INTO animals VALUES ('vulpes chama','silver-backed fox','extinct in wild','True');
INSERT INTO animals VALUES ('iguana iguana','iguana, common green','extinct in wild','True');
INSERT INTO animals VALUES ('eira barbata','tayra','vulnerable','False');
INSERT INTO animals VALUES ('taxidea taxus','american badger','extinct in wild','True');
INSERT INTO animals VALUES ('smithopsis crassicaudata','fat-tailed dunnart','endangered','True');
INSERT INTO animals VALUES ('didelphis virginiana','opossum, american virginia','extinct in wild','True');
INSERT INTO animals VALUES ('alopex lagopus','fox, blue','extinct in wild','True');
INSERT INTO animals VALUES ('anas platyrhynchos','mallard','endangered','True');
INSERT INTO animals VALUES ('erinaceus frontalis','hedgehog, south african','critically endangered','True');
INSERT INTO animals VALUES ('anas punctata','teal, hottentot','vulnerable','False');

/* Populating the licensed_owners table */
INSERT INTO licensed_owners VALUES (340349267,'Milt','Frain','mfrain7o@homestead.com','82 Mendota Junction','Washington','District of Columbia');
INSERT INTO licensed_owners VALUES (830306052,'Dottie','Ambresin','dambresinpc@networkadvertising.org','2 Waxwing Junction','Sacramento','California');
INSERT INTO licensed_owners VALUES (545745034,'Sissy','Grund','sgrundfx@google.es','325 Center Place','Decatur','Georgia');
INSERT INTO licensed_owners VALUES (665821811,'Feodor','Muncaster','fmuncaster3a@sciencedaily.com','824 Everett Center','Glendale','Arizona');
INSERT INTO licensed_owners VALUES (182084270,'Hurlee','Riddich','hriddichj7@ox.ac.uk','35 Stephen Drive','Austin','Texas');
INSERT INTO licensed_owners VALUES (624858867,'Alia','Lemmen','alemmen8o@ustream.tv','8607 Morning Hill','Jacksonville','Florida');
INSERT INTO licensed_owners VALUES (867633004,'Lindi','Guillou','lguilloui1@ebay.co.uk','15810 Boyd Place','Greenville','South Carolina');
INSERT INTO licensed_owners VALUES (846716513,'Guthrey','January 1st','gjanuarystgm@amazon.de','233 Becker Court','Boulder','Colorado');
INSERT INTO licensed_owners VALUES (118127222,'Georgetta','Forster','gforsterfr@de.vu','5 Charing Cross Pass','Dallas','Texas');
INSERT INTO licensed_owners VALUES (944424596,'Bink','Pedron','bpedronha@stumbleupon.com','6686 Loftsgordon Way','San Bernardino','California');
INSERT INTO licensed_owners VALUES (267991745,'Melodee','Bownd','mbowndlo@slideshare.net','62143 Old Shore Avenue','Kansas City','Missouri');
INSERT INTO licensed_owners VALUES (598307534,'Barbra','Fagence','bfagence3m@hostgator.com','9833 Dawn Center','Sacramento','California');
INSERT INTO licensed_owners VALUES (641398130,'Jenelle','Gates','jgatesga@narod.ru','16 Jenifer Way','Chesapeake','Virginia');
INSERT INTO licensed_owners VALUES (539292343,'Henriette','Rickersy','hrickersykh@e-recht24.de','71 Tennyson Court','Columbus','Ohio');
INSERT INTO licensed_owners VALUES (946015780,'Hayes','McMorland','hmcmorland32@hostgator.com','02 La Follette Avenue','San Francisco','California');
INSERT INTO licensed_owners VALUES (113657146,'Reuben','Stanlick','rstanlickqm@ucsd.edu','2823 Fordem Lane','Washington','District of Columbia');
INSERT INTO licensed_owners VALUES (703819408,'Madeleine','Banthorpe','mbanthorpeda@wix.com','60784 Fairview Terrace','Fairfield','Connecticut');
INSERT INTO licensed_owners VALUES (497283289,'Katharine','McGee','kmcgee5w@wiley.com','471 Redwing Street','Akron','Ohio');
INSERT INTO licensed_owners VALUES (931215049,'Ailina','Norwich','anorwichpa@home.pl','408 Hoffman Center','Danbury','Connecticut');
INSERT INTO licensed_owners VALUES (527286598,'Rivalee','Smouten','rsmoutengh@google.it','16337 Kinsman Alley','San Francisco','California');
INSERT INTO licensed_owners VALUES (693209108,'Rowe','Glazier','rglaziero4@archive.org','7922 Walton Way','Tulsa','Oklahoma');
INSERT INTO licensed_owners VALUES (223718693,'Ulrika','Tutsell','ututsellaj@printfriendly.com','0052 Merchant Parkway','Springfield','Illinois');
INSERT INTO licensed_owners VALUES (241015861,'Holt','Korejs','hkorejs9l@amazon.de','03214 Garrison Park','Phoenix','Arizona');
INSERT INTO licensed_owners VALUES (922563378,'Erl','Alban','ealbank1@cargocollective.com','0684 Dorton Court','Lawrenceville','Georgia');
INSERT INTO licensed_owners VALUES (913683690,'Maire','Verrillo','mverrilloke@un.org','5 Norway Maple Trail','Sioux City','Iowa');
INSERT INTO licensed_owners VALUES (591974987,'Katya','Oxshott','koxshottkm@photobucket.com','14633 Hoard Terrace','Las Vegas','Nevada');
INSERT INTO licensed_owners VALUES (112427449,'Reece','Parkhouse','rparkhouser9@cmu.edu','7 Schiller Hill','Washington','District of Columbia');
INSERT INTO licensed_owners VALUES (45601341,'Leonie','Whittlesee','lwhittleseegs@ted.com','48 Carberry Pass','San Diego','California');
INSERT INTO licensed_owners VALUES (789982906,'Franni','Cheak','fcheakai@bing.com','403 Esch Way','Kansas City','Missouri');
INSERT INTO licensed_owners VALUES (23907917,'Fabien','Yerson','fyerson6j@aol.com','28 Mitchell Pass','Shreveport','Louisiana');
INSERT INTO licensed_owners VALUES (162195482,'Courtenay','Backwell','cbackwell9r@issuu.com','990 Clarendon Terrace','Tallahassee','Florida');
INSERT INTO licensed_owners VALUES (156554526,'Mathew','Snowdon','msnowdonjf@oakley.com','27667 Pankratz Parkway','Boise','Idaho');
INSERT INTO licensed_owners VALUES (570270534,'Christel','Cardinal','ccardinalk2@smugmug.com','8 Mandrake Park','Atlanta','Georgia');
INSERT INTO licensed_owners VALUES (916605386,'Blayne','Punshon','bpunshon1l@jalbum.net','8768 Basil Crossing','Chicago','Illinois');
INSERT INTO licensed_owners VALUES (923710997,'Steffi','Jahnel','sjahnel4v@tumblr.com','5 Delladonna Terrace','Winter Haven','Florida');
INSERT INTO licensed_owners VALUES (189007886,'Kary','Sawyer','ksawyerle@marriott.com','6 Northland Street','Arlington','Virginia');
INSERT INTO licensed_owners VALUES (954089867,'Ara','Jarred','ajarred1c@cbc.ca','7 Schiller Park','Spring','Texas');
INSERT INTO licensed_owners VALUES (28213776,'Perry','Larby','plarby1t@dagondesign.com','51 Amoth Street','Dallas','Texas');
INSERT INTO licensed_owners VALUES (797622661,'Jane','Edgerly','jedgerlyny@liveinternet.ru','41784 Harbort Point','Tacoma','Washington');
INSERT INTO licensed_owners VALUES (891044816,'Elysee','Ludlamme','eludlamme4z@elpais.com','13114 Darwin Center','Fort Lauderdale','Florida');
INSERT INTO licensed_owners VALUES (121830979,'Phelia','Roycraft','proycraftil@dailymail.co.uk','23 Florence Lane','Orlando','Florida');
INSERT INTO licensed_owners VALUES (74663027,'Marilin','Hallahan','mhallahanjv@weebly.com','1 Arizona Terrace','Pompano Beach','Florida');
INSERT INTO licensed_owners VALUES (963156756,'Moise','Seckington','mseckingtonpk@dropbox.com','6646 Algoma Center','Washington','District of Columbia');
INSERT INTO licensed_owners VALUES (870375755,'Susanna','Farragher','sfarragherm9@chron.com','9041 Village Green Center','Washington','District of Columbia');
INSERT INTO licensed_owners VALUES (850273295,'Andree','Kingsnoad','akingsnoaddn@berkeley.edu','25 Oak Circle','Salt Lake City','Utah');
INSERT INTO licensed_owners VALUES (447884394,'Sonny','Schankelborg','sschankelborgr1@usatoday.com','0 Florence Pass','Vienna','Virginia');
INSERT INTO licensed_owners VALUES (588124623,'Antonio','Tomsa','atomsa86@techcrunch.com','2 Scott Park','Cincinnati','Ohio');
INSERT INTO licensed_owners VALUES (636642177,'Michaella','Jobling','mjoblingfo@hostgator.com','160 Mallory Alley','Kansas City','Kansas');
INSERT INTO licensed_owners VALUES (873732716,'Innis','Haug','ihaugcp@smh.com.au','2 Killdeer Junction','Arlington','Texas');
INSERT INTO licensed_owners VALUES (528041343,'Norris','Swyne','nswyned6@deviantart.com','8 Russell Road','Albuquerque','New Mexico');
INSERT INTO licensed_owners VALUES (424045494,'Rodrick','Vaggs','rvaggsl0@un.org','7 Merrick Park','Minneapolis','Minnesota');
INSERT INTO licensed_owners VALUES (308843263,'Cahra','Blazewicz','cblazewiczac@nyu.edu','0 2nd Center','San Antonio','Texas');
INSERT INTO licensed_owners VALUES (364688052,'Lucilia','Lindenblatt','llindenblatt35@xrea.com','29984 Debs Point','Wilmington','Delaware');
INSERT INTO licensed_owners VALUES (615744839,'Leonie','Fernier','lferniergk@buzzfeed.com','25553 Buell Junction','Worcester','Massachusetts');
INSERT INTO licensed_owners VALUES (473510090,'Yves','Davidson','ydavidsonaa@github.com','4 Schmedeman Plaza','Longview','Texas');
INSERT INTO licensed_owners VALUES (307957673,'Joelle','Do','jdoen@tamu.edu','1 Vahlen Street','Scottsdale','Arizona');
INSERT INTO licensed_owners VALUES (255317871,'Milty','Mathie','mmathieff@flavors.me','35 Scoville Trail','Macon','Georgia');
INSERT INTO licensed_owners VALUES (102094158,'Veronika','Belfrage','vbelfrageat@nbcnews.com','612 Myrtle Center','Lansing','Michigan');
INSERT INTO licensed_owners VALUES (523473227,'Louisa','Servis','lservisi7@europa.eu','86 Anniversary Hill','Dayton','Ohio');
INSERT INTO licensed_owners VALUES (360028952,'Karon','Nosworthy','knosworthynh@apple.com','002 Eagle Crest Way','Waterloo','Iowa');
INSERT INTO licensed_owners VALUES (490033196,'Anestassia','Stonelake','astonelakems@ucoz.com','19 Fairfield Pass','Saint Louis','Missouri');
INSERT INTO licensed_owners VALUES (525579511,'Tomas','Castagnone','tcastagnoneg8@arstechnica.com','17062 Chinook Terrace','Bethesda','Maryland');
INSERT INTO licensed_owners VALUES (996484096,'Jsandye','Hellin','jhellinev@networksolutions.com','4672 Columbus Trail','Omaha','Nebraska');
INSERT INTO licensed_owners VALUES (624776802,'Lynn','Bengochea','lbengochea8g@tinyurl.com','5790 Warrior Parkway','Montgomery','Alabama');
INSERT INTO licensed_owners VALUES (295967332,'Florina','Habergham','fhaberghamz@senate.gov','9760 Haas Crossing','Dallas','Texas');
INSERT INTO licensed_owners VALUES (235740965,'Justin','Greenan','jgreenanhe@last.fm','9814 American Parkway','Rochester','New York');
INSERT INTO licensed_owners VALUES (108602282,'Alyssa','Sellen','asellen2j@cdc.gov','54692 Heffernan Junction','Houston','Texas');
INSERT INTO licensed_owners VALUES (339698053,'Dimitri','Woolford','dwoolfordrl@rediff.com','70 Hudson Trail','Sioux City','Iowa');
INSERT INTO licensed_owners VALUES (93249597,'Elbertine','Tongs','etongsc3@hao123.com','09 Continental Way','Pittsburgh','Pennsylvania');
INSERT INTO licensed_owners VALUES (594565104,'Ash','Ogan','aogan51@mayoclinic.com','5491 High Crossing Alley','Newark','New Jersey');
INSERT INTO licensed_owners VALUES (916955525,'Gustavus','Dimmick','gdimmickjw@flickr.com','7 Sundown Hill','Oklahoma City','Oklahoma');
INSERT INTO licensed_owners VALUES (18923880,'Kenon','Braund','kbraund33@google.pl','23944 Towne Road','Ann Arbor','Michigan');
INSERT INTO licensed_owners VALUES (485635754,'Suzanna','Simkins','ssimkinsnp@hugedomains.com','6 Chinook Place','Winston Salem','North Carolina');
INSERT INTO licensed_owners VALUES (751417162,'Francis','Ledrane','fledrane7d@booking.com','59132 Fisk Place','Lakeland','Florida');
INSERT INTO licensed_owners VALUES (510351671,'Ingaborg','Lebrun','ilebrunea@delicious.com','9863 Kings Street','Houston','Texas');
INSERT INTO licensed_owners VALUES (577874870,'Constantin','Sauniere','csaunieref1@earthlink.net','0 Spenser Road','Florence','South Carolina');
INSERT INTO licensed_owners VALUES (854828825,'Davine','Parsall','dparsalld4@edublogs.org','131 Basil Trail','Brooklyn','New York');
INSERT INTO licensed_owners VALUES (952116892,'Esta','Rosbrough','erosbrough62@flickr.com','5 Petterle Drive','Irvine','California');
INSERT INTO licensed_owners VALUES (871208808,'Erminia','Langabeer','elangabeerb1@skyrock.com','77782 Service Circle','Arlington','Texas');
INSERT INTO licensed_owners VALUES (542105724,'Gabby','Birchenhead','gbirchenheadbb@jalbum.net','86 Autumn Leaf Pass','Denver','Colorado');
INSERT INTO licensed_owners VALUES (154028808,'Cy','Casella','ccasella77@prnewswire.com','0788 Milwaukee Parkway','Salt Lake City','Utah');
INSERT INTO licensed_owners VALUES (937101423,'Egor','Bucklan','ebucklancz@yellowbook.com','2 Gulseth Center','Fort Worth','Texas');
INSERT INTO licensed_owners VALUES (300325812,'Kris','Immings','kimmingsdr@php.net','08942 Becker Lane','Tallahassee','Florida');
INSERT INTO licensed_owners VALUES (668322926,'Saundra','McCathy','smccathyg@google.pl','6665 Delladonna Terrace','Fargo','North Dakota');
INSERT INTO licensed_owners VALUES (183492077,'Gilbertine','Sexcey','gsexceyb5@instagram.com','63 Reindahl Terrace','Columbia','South Carolina');
INSERT INTO licensed_owners VALUES (755389752,'Giuditta','Rockhall','grockhallc0@flavors.me','45523 Morningstar Street','New Haven','Connecticut');
INSERT INTO licensed_owners VALUES (598995324,'Anson','Sich','asichdu@google.co.jp','5 Briar Crest Way','Minneapolis','Minnesota');
INSERT INTO licensed_owners VALUES (304390646,'Odille','Yardy','oyardyhb@cornell.edu','4843 Service Point','Santa Barbara','California');
INSERT INTO licensed_owners VALUES (78974901,'Ned','Brunotti','nbrunotti7w@cyberchimps.com','123 Brown Parkway','San Bernardino','California');
INSERT INTO licensed_owners VALUES (709006912,'Piotr','Girardez','pgirardez64@nifty.com','45 Farmco Court','Dallas','Texas');
INSERT INTO licensed_owners VALUES (217584673,'Winfield','Rouby','wroubyjd@networkadvertising.org','951 Clarendon Court','Metairie','Louisiana');
INSERT INTO licensed_owners VALUES (540161275,'Huntlee','De la Zenne','hdelazenne1b@unesco.org','80201 Ridge Oak Point','Waterbury','Connecticut');
INSERT INTO licensed_owners VALUES (461703526,'Audrye','Levicount','alevicount55@google.it','88670 Pawling Road','Salt Lake City','Utah');
INSERT INTO licensed_owners VALUES (664692389,'Haroun','Solon','hsolon4e@europa.eu','5 Iowa Drive','Reston','Virginia');
INSERT INTO licensed_owners VALUES (824346026,'Ruperta','Manns','rmannsn0@ed.gov','162 Sachtjen Court','Cape Coral','Florida');
INSERT INTO licensed_owners VALUES (771044500,'Raoul','Faichnie','rfaichnieqj@redcross.org','433 Forster Circle','New Orleans','Louisiana');
INSERT INTO licensed_owners VALUES (95845868,'Dyan','Dimock','ddimockhr@google.com.hk','67791 Novick Lane','Dayton','Ohio');
INSERT INTO licensed_owners VALUES (281061878,'Evelyn','Koba','ekobaku@csmonitor.com','34597 Canary Court','Omaha','Nebraska');
INSERT INTO licensed_owners VALUES (961478332,'Sande','Woolsey','swoolseyrb@nasa.gov','67 Hollow Ridge Pass','El Paso','Texas');
INSERT INTO licensed_owners VALUES (88775196,'Germain','Sparhawk','gsparhawke9@oakley.com','7978 Oakridge Parkway','Sacramento','California');

COMMIT;

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* Populating the register table with 1 SQL INSERT statement with random() */
START TRANSACTION;

INSERT INTO register 
    SELECT an.scientific_name, lo.license_num
    FROM animals an , licensed_owners lo
    WHERE an.endangered_status != 'vulnerable' 
    ORDER BY random()
    LIMIT 1000;

COMMIT;
