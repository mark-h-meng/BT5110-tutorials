/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* 
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* Suppose we want to manage the data of online food delivery service in Singapore for further 
route optimization. We store information of customers such as their name, gender, telephone 
number and address in the first table. In the second table, there are shop name, postcode 
and address,and we conbain shop name and postcode as identification. Then we have to remember 
which customer orders a meal in which shop. So we create the relationship set associating 
customer and the shop. The address information is important for later optimization, so it 
need to be inserted into the relationship table.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE customers (
    customerid VARCHAR(64) PRIMARY KEY,
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	gender CHAR(1),
	telephone VARCHAR(64) UNIQUE NOT NULL,
	address VARCHAR(64) NOT NULL);
	
CREATE TABLE shops (
	name VARCHAR(32) NOT NULL,
	blk char(6) NOT NULL,
	shopaddress VARCHAR(64) NOT NULL,
	PRIMARY KEY (name,blk));
	
CREATE TABLE orders (
	customerid VARCHAR(64) REFERENCES customers(customerid),
	address VARCHAR(64) ,
	name VARCHAR(32) NOT NULL,
	blk char(6) NOT NULL,
	shopaddress VARCHAR(64) NOT NULL,
	FOREIGN KEY (name,blk) REFERENCES shops(name,blk),
	PRIMARY KEY(customerid, name, blk));

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (1, 'Michel', 'Tumbridge', 'M', '152-371-0321', '63 Washington Way');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (2, 'Edyth', 'Blogg', 'F', '869-183-7411', '1 Crest Line Trail');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (3, 'Allsun', 'Sails', 'F', '628-501-8002', '3 Hoard Hill');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (4, 'Jacklyn', 'Gauld', 'F', '129-215-6655', '02065 Superior Circle');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (5, 'Tiffani', 'Dyett', 'F', '791-148-8978', '073 Algoma Point');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (6, 'Rozanne', 'Barszczewski', 'F', '467-901-6078', '1326 Gina Court');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (7, 'Tracie', 'Aron', 'M', '626-391-0051', '540 Lukken Circle');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (8, 'Deonne', 'Surgey', 'F', '954-558-4294', '61 Londonderry Terrace');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (9, 'Brandtr', 'Meechan', 'M', '559-229-9841', '770 International Street');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (10, 'Jania', 'Adame', 'F', '600-528-6519', '02 Cherokee Terrace');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (11, 'Lacie', 'Gavan', 'F', '252-625-5968', '370 Maple Center');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (12, 'Sherrie', 'Laydel', 'F', '112-230-1593', '2243 Division Hill');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (13, 'Georas', 'Shilito', 'M', '809-793-9340', '368 Ohio Circle');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (14, 'Lissie', 'Lewsley', 'F', '991-316-2217', '34067 Lunder Court');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (15, 'Jocelin', 'Perle', 'F', '801-220-5909', '90897 Maple Road');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (16, 'Arden', 'De Gregoli', 'F', '509-393-1833', '4571 Caliangt Trail');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (17, 'Vinson', 'Chagg', 'M', '431-546-8754', '19247 Schiller Road');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (18, 'Alano', 'Scotson', 'M', '674-267-3627', '35624 Mockingbird Street');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (19, 'Lombard', 'Blunt', 'M', '923-223-3763', '5 Sage Junction');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (20, 'Owen', 'Randall', 'M', '568-268-3649', '543 Kenwood Trail');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (21, 'Laurella', 'Jaycock', 'F', '159-450-3280', '09133 Charing Cross Center');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (22, 'Maddy', 'Filon', 'F', '743-818-4625', '2 Coolidge Place');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (23, 'Correy', 'Shynn', 'F', '425-523-4281', '769 Northridge Park');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (24, 'Jackie', 'Hampton', 'F', '955-935-4441', '02587 Main Alley');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (25, 'Kort', 'Rove', 'M', '625-746-8283', '42332 Hovde Way');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (26, 'Lois', 'Naulty', 'F', '907-817-4195', '8 Glendale Avenue');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (27, 'Gates', 'Dwight', 'F', '693-729-2873', '4742 Dakota Road');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (28, 'Jocelyne', 'Evered', 'F', '401-174-4963', '29132 Charing Cross Street');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (29, 'Edwina', 'Mindenhall', 'F', '659-848-6460', '9595 Hanover Alley');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (30, 'Brannon', 'Reinbeck', 'M', '223-274-8111', '8431 Carberry Plaza');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (31, 'Casey', 'Manuel', 'M', '608-463-8550', '10045 Butternut Terrace');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (32, 'Yuri', 'Strickland', 'M', '408-434-2322', '92118 West Lane');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (33, 'Catharine', 'Guess', 'F', '762-178-5415', '853 Blaine Plaza');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (34, 'Lazar', 'Gripton', 'M', '212-816-7738', '48785 Cardinal Center');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (35, 'Caresse', 'O''Kerin', 'F', '562-216-9016', '69 Express Street');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (36, 'Pebrook', 'Ledgerton', 'M', '577-130-0315', '74 Mesta Point');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (37, 'Morse', 'Faltin', 'M', '698-626-8063', '75909 Mockingbird Park');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (38, 'Boniface', 'Swaden', 'M', '245-497-3197', '3 Mcbride Park');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (39, 'Lucius', 'Syrett', 'M', '365-874-5279', '006 Ruskin Crossing');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (40, 'Jacquelyn', 'Laslett', 'F', '120-226-4276', '405 Sugar Street');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (41, 'Giffer', 'Ianittello', 'M', '614-827-3780', '3395 Florence Avenue');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (42, 'Rosabella', 'Learned', 'F', '298-130-5664', '8 Tennessee Plaza');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (43, 'Launce', 'McCunn', 'M', '894-165-1711', '801 Chinook Terrace');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (44, 'Jo-ann', 'Figliovanni', 'F', '916-846-2601', '0 Kropf Court');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (45, 'Penrod', 'Franck', 'M', '204-776-3793', '2 Florence Park');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (46, 'Francesco', 'Newell', 'M', '239-469-3507', '60085 Village Park');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (47, 'Leta', 'Limpkin', 'F', '258-217-3481', '94 Sullivan Street');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (48, 'Fania', 'Grievson', 'F', '355-853-3936', '2130 Washington Plaza');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (49, 'Aidan', 'Gunston', 'F', '918-620-4267', '19 Cardinal Pass');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (50, 'Paquito', 'Thormwell', 'M', '875-773-7611', '00273 Upham Park');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (51, 'Salvador', 'Caccavale', 'M', '266-998-1776', '6803 Lake View Center');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (52, 'Corabel', 'Rozzier', 'F', '416-875-8352', '1937 Emmet Road');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (53, 'Hamlen', 'Ratazzi', 'M', '856-794-9782', '630 New Castle Drive');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (54, 'Flo', 'MacAscaidh', 'F', '358-263-9164', '163 Ohio Crossing');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (55, 'Lionello', 'Olyff', 'M', '105-528-2873', '5 4th Park');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (56, 'Stormy', 'Sutter', 'F', '463-108-7244', '7 Stoughton Pass');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (57, 'Guillermo', 'Shimon', 'M', '844-675-2568', '02 Saint Paul Point');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (58, 'Elianora', 'Milthorpe', 'F', '761-237-3710', '97 Prairieview Avenue');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (59, 'Berna', 'Brobyn', 'F', '201-885-9490', '88060 Oxford Alley');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (60, 'Aundrea', 'Wedderburn', 'F', '620-588-0970', '79 Sullivan Lane');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (61, 'Sibeal', 'Binion', 'F', '409-545-2833', '40550 Stang Lane');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (62, 'Mada', 'Gemlett', 'F', '985-608-2885', '71009 School Street');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (63, 'Daffi', 'Jillard', 'F', '953-911-1363', '3769 Maple Point');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (64, 'Nicoli', 'Moulster', 'F', '556-753-4394', '997 Rowland Avenue');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (65, 'Oswald', 'Maciejewski', 'M', '371-262-1197', '9315 Northview Point');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (66, 'Susette', 'Braine', 'F', '122-648-9019', '804 Maple Hill');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (67, 'Chrystal', 'Cattlow', 'F', '941-194-0119', '9 Dixon Parkway');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (68, 'Napoleon', 'Sacase', 'M', '335-701-4054', '3 Ramsey Crossing');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (69, 'Sawyere', 'Rainsden', 'M', '629-527-3212', '53577 Buhler Alley');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (70, 'Jakob', 'Drayn', 'M', '284-115-7275', '55 Ilene Center');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (71, 'Adelbert', 'Pykerman', 'M', '214-611-5101', '8 Golf View Avenue');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (72, 'Sly', 'Durrett', 'M', '910-302-3673', '05 Anhalt Trail');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (73, 'Bobinette', 'Hatto', 'F', '748-742-5572', '5165 Sommers Alley');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (74, 'Peadar', 'Hucks', 'M', '756-891-0668', '39 Coolidge Pass');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (75, 'Robbyn', 'Fullstone', 'F', '523-172-2214', '07 Loftsgordon Terrace');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (76, 'Vito', 'Spilsted', 'M', '944-875-9351', '815 Hanover Junction');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (77, 'Nathaniel', 'Smidmore', 'M', '963-123-4693', '69270 Linden Parkway');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (78, 'Zonnya', 'Stanton', 'F', '707-754-5126', '114 Sachs Alley');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (79, 'Rainer', 'Steels', 'M', '183-305-8402', '16187 Mayer Street');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (80, 'Reese', 'Nurdin', 'M', '159-860-5110', '28 Cody Avenue');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (81, 'Hagan', 'Schiefersten', 'M', '474-587-2123', '314 Swallow Way');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (82, 'Foster', 'Gibbieson', 'M', '307-256-6742', '1800 Fisk Place');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (83, 'Garret', 'Ryhorovich', 'M', '257-679-8733', '144 Superior Circle');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (84, 'Eulalie', 'Seleway', 'F', '633-191-2815', '2176 Tennessee Court');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (85, 'Barr', 'Eouzan', 'M', '121-442-8911', '2620 Blue Bill Park Place');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (86, 'Durand', 'Turnpenny', 'M', '346-519-8436', '0 Maple Road');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (87, 'Layton', 'Pepin', 'M', '651-543-7379', '66497 Vermont Alley');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (88, 'Erie', 'Grimwad', 'M', '445-462-6168', '82 Schurz Trail');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (89, 'Bradney', 'Richards', 'M', '309-808-9649', '64 Eggendart Park');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (90, 'Gwenni', 'Ranshaw', 'F', '945-376-9359', '42118 Loftsgordon Parkway');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (91, 'Fanchette', 'Yarker', 'F', '400-825-0147', '11 Drewry Avenue');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (92, 'Con', 'Serjent', 'F', '553-406-2732', '08555 Artisan Street');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (93, 'Taddeusz', 'Fresson', 'M', '618-220-3448', '906 Schmedeman Street');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (94, 'Ronica', 'Nehl', 'F', '366-557-8776', '7 5th Pass');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (95, 'Web', 'Gauch', 'M', '325-519-6753', '0368 Sachtjen Place');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (96, 'Michell', 'McKeller', 'F', '652-858-6500', '24169 Spaight Lane');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (97, 'Enrica', 'Rippin', 'F', '184-262-6933', '3 Hagan Point');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (98, 'Garv', 'Godbolt', 'M', '693-114-3026', '59 Schlimgen Court');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (99, 'Eric', 'Winterson', 'M', '380-928-1167', '49 Grover Avenue');
insert into customers (customerid, first_name, last_name, gender, telephone, address) values (100, 'Darcey', 'Engelbrecht', 'F', '181-939-2783', '10 Manufacturers Junction');

insert into shops (name, blk, shopaddress) values ('hbraybrooks0', 569417, '0607 Browning Street');
insert into shops (name, blk, shopaddress) values ('kallbrook1', 876989, '37767 Warrior Junction');
insert into shops (name, blk, shopaddress) values ('mabazi2', 893026, '6 Lunder Road');
insert into shops (name, blk, shopaddress) values ('kdrohun3', 468795, '310 Goodland Pass');
insert into shops (name, blk, shopaddress) values ('ggirke4', 878141, '31970 Eagle Crest Avenue');
insert into shops (name, blk, shopaddress) values ('omaliphant5', 658791, '3801 Sommers Lane');
insert into shops (name, blk, shopaddress) values ('aferreras6', 863677, '15 Miller Street');
insert into shops (name, blk, shopaddress) values ('jburgum7', 292637, '6063 Roxbury Parkway');
insert into shops (name, blk, shopaddress) values ('flowseley8', 582936, '9560 Clove Court');
insert into shops (name, blk, shopaddress) values ('gballingal9', 377282, '47 Laurel Crossing');
insert into shops (name, blk, shopaddress) values ('areillya', 178538, '584 Esch Park');
insert into shops (name, blk, shopaddress) values ('apaceyb', 615415, '64 Brickson Park Plaza');
insert into shops (name, blk, shopaddress) values ('toaktonc', 823281, '8 Ridge Oak Road');
insert into shops (name, blk, shopaddress) values ('smacsweeneyd', 941136, '197 Lien Parkway');
insert into shops (name, blk, shopaddress) values ('hcodee', 840490, '03 Reinke Terrace');
insert into shops (name, blk, shopaddress) values ('sbaythropf', 192002, '16042 Emmet Crossing');
insert into shops (name, blk, shopaddress) values ('sfirbankg', 872577, '19254 Blackbird Lane');
insert into shops (name, blk, shopaddress) values ('agailh', 303058, '53 Dwight Road');
insert into shops (name, blk, shopaddress) values ('aextili', 941829, '8470 Hoffman Lane');
insert into shops (name, blk, shopaddress) values ('ehenrionj', 128451, '87616 Westend Court');
insert into shops (name, blk, shopaddress) values ('rdormerk', 911001, '7 Vera Road');
insert into shops (name, blk, shopaddress) values ('lorsmanl', 954617, '83 Manitowish Alley');
insert into shops (name, blk, shopaddress) values ('nnoonanm', 923051, '2 Summit Drive');
insert into shops (name, blk, shopaddress) values ('agroutn', 117713, '3 Everett Lane');
insert into shops (name, blk, shopaddress) values ('lmacgiollao', 789206, '51 Grasskamp Circle');
insert into shops (name, blk, shopaddress) values ('vlebournp', 813385, '02 Beilfuss Parkway');
insert into shops (name, blk, shopaddress) values ('kduddridgeq', 419614, '670 Steensland Way');
insert into shops (name, blk, shopaddress) values ('tdamsellr', 891365, '11 Annamark Court');
insert into shops (name, blk, shopaddress) values ('ghanrettys', 793052, '8 Thompson Lane');
insert into shops (name, blk, shopaddress) values ('pblownt', 382364, '5629 Loftsgordon Alley');
insert into shops (name, blk, shopaddress) values ('wambresinu', 492660, '937 Becker Junction');
insert into shops (name, blk, shopaddress) values ('ashorthillv', 749871, '735 Ludington Point');
insert into shops (name, blk, shopaddress) values ('cgethynw', 753296, '940 Westport Drive');
insert into shops (name, blk, shopaddress) values ('gmcronaldx', 977423, '2 Victoria Crossing');
insert into shops (name, blk, shopaddress) values ('ptrumpetery', 277085, '91 Dwight Trail');
insert into shops (name, blk, shopaddress) values ('gtrewhittz', 281031, '249 Bluestem Center');
insert into shops (name, blk, shopaddress) values ('vkinny10', 364285, '3 Scofield Place');
insert into shops (name, blk, shopaddress) values ('tthrussell11', 685156, '7491 Grasskamp Terrace');
insert into shops (name, blk, shopaddress) values ('hfriskey12', 568543, '77023 Farwell Point');
insert into shops (name, blk, shopaddress) values ('msimons13', 472048, '1 Fair Oaks Lane');
insert into shops (name, blk, shopaddress) values ('vjosephy14', 583369, '596 Oak Lane');
insert into shops (name, blk, shopaddress) values ('ecolly15', 563770, '94345 Dunning Terrace');
insert into shops (name, blk, shopaddress) values ('rgartland16', 285337, '785 Bartelt Parkway');
insert into shops (name, blk, shopaddress) values ('twann17', 190232, '13608 Sunbrook Parkway');
insert into shops (name, blk, shopaddress) values ('adanks18', 866203, '230 Stone Corner Hill');
insert into shops (name, blk, shopaddress) values ('hstaining19', 475158, '99 Hermina Terrace');
insert into shops (name, blk, shopaddress) values ('mkellar1a', 863307, '9 Waubesa Center');
insert into shops (name, blk, shopaddress) values ('mlescop1b', 397656, '84315 Grayhawk Terrace');
insert into shops (name, blk, shopaddress) values ('ccostin1c', 124295, '960 Mariners Cove Point');
insert into shops (name, blk, shopaddress) values ('kdmitrievski1d', 575720, '669 Everett Drive');
insert into shops (name, blk, shopaddress) values ('rsimkovich1e', 882451, '6253 Westend Parkway');
insert into shops (name, blk, shopaddress) values ('nbannard1f', 246941, '93037 Buell Drive');
insert into shops (name, blk, shopaddress) values ('mgalpin1g', 344688, '51 Dexter Street');
insert into shops (name, blk, shopaddress) values ('wlowthorpe1h', 536846, '14 Gerald Junction');
insert into shops (name, blk, shopaddress) values ('gmccombe1i', 532168, '06 Corben Plaza');
insert into shops (name, blk, shopaddress) values ('kelph1j', 438727, '9277 Ludington Avenue');
insert into shops (name, blk, shopaddress) values ('mhamper1k', 857249, '55178 Fallview Park');
insert into shops (name, blk, shopaddress) values ('tmindenhall1l', 311720, '5 Lighthouse Bay Road');
insert into shops (name, blk, shopaddress) values ('kpighills1m', 607605, '59 Leroy Terrace');
insert into shops (name, blk, shopaddress) values ('adaffern1n', 391221, '37 Bunting Court');
insert into shops (name, blk, shopaddress) values ('utolossi1o', 431427, '4800 Melby Circle');
insert into shops (name, blk, shopaddress) values ('boene1p', 317822, '321 Blue Bill Park Parkway');
insert into shops (name, blk, shopaddress) values ('paguilar1q', 370350, '13651 Northview Hill');
insert into shops (name, blk, shopaddress) values ('rdowsett1r', 501936, '99 Pierstorff Alley');
insert into shops (name, blk, shopaddress) values ('ggoneau1s', 207458, '28015 Tony Circle');
insert into shops (name, blk, shopaddress) values ('ktoner1t', 380446, '43 Lukken Avenue');
insert into shops (name, blk, shopaddress) values ('jlomis1u', 374275, '8 Cottonwood Pass');
insert into shops (name, blk, shopaddress) values ('rwiggall1v', 775700, '9927 Dorton Way');
insert into shops (name, blk, shopaddress) values ('rmeineking1w', 518367, '65488 Brickson Park Court');
insert into shops (name, blk, shopaddress) values ('jkemmett1x', 874758, '52 Hanover Parkway');
insert into shops (name, blk, shopaddress) values ('lmatiashvili1y', 626686, '2278 Monument Court');
insert into shops (name, blk, shopaddress) values ('msimakov1z', 754787, '2733 Prentice Park');
insert into shops (name, blk, shopaddress) values ('msybbe20', 851948, '04 Ryan Road');
insert into shops (name, blk, shopaddress) values ('eziemke21', 863034, '588 Kings Point');
insert into shops (name, blk, shopaddress) values ('milem22', 936035, '4 Forest Point');
insert into shops (name, blk, shopaddress) values ('sglisenan23', 398113, '933 Village Green Park');
insert into shops (name, blk, shopaddress) values ('qclampett24', 825261, '03065 Norway Maple Street');
insert into shops (name, blk, shopaddress) values ('wsilverthorn25', 828175, '61562 Calypso Hill');
insert into shops (name, blk, shopaddress) values ('gbirdall26', 360113, '99572 Eastwood Point');
insert into shops (name, blk, shopaddress) values ('iwringe27', 924643, '128 Debs Circle');
insert into shops (name, blk, shopaddress) values ('rrix28', 532159, '0 Nova Road');
insert into shops (name, blk, shopaddress) values ('kleal29', 805360, '8 Knutson Trail');
insert into shops (name, blk, shopaddress) values ('ochaff2a', 868335, '88 Burrows Park');
insert into shops (name, blk, shopaddress) values ('kvanlint2b', 977767, '241 Service Drive');
insert into shops (name, blk, shopaddress) values ('mstreeton2c', 989571, '298 Alpine Center');
insert into shops (name, blk, shopaddress) values ('ftrematick2d', 347223, '95704 Randy Avenue');
insert into shops (name, blk, shopaddress) values ('jyannikov2e', 447723, '68 Coleman Point');
insert into shops (name, blk, shopaddress) values ('jbaynon2f', 929607, '8672 Cascade Trail');
insert into shops (name, blk, shopaddress) values ('tgritton2g', 634306, '8246 Farmco Plaza');
insert into shops (name, blk, shopaddress) values ('tpanchen2h', 567661, '461 Clarendon Alley');
insert into shops (name, blk, shopaddress) values ('flefever2i', 941622, '4 Elmside Court');
insert into shops (name, blk, shopaddress) values ('kmcgilvray2j', 563801, '02603 Heath Pass');
insert into shops (name, blk, shopaddress) values ('sdavidge2k', 984436, '0393 Bay Alley');
insert into shops (name, blk, shopaddress) values ('dwhittlesee2l', 712045, '57141 Garrison Hill');
insert into shops (name, blk, shopaddress) values ('cpachta2m', 870054, '3126 Union Court');
insert into shops (name, blk, shopaddress) values ('sroubeix2n', 491585, '06476 Melody Terrace');
insert into shops (name, blk, shopaddress) values ('mmarzellano2o', 707454, '62 School Drive');
insert into shops (name, blk, shopaddress) values ('ejopp2p', 991684, '26767 Shopko Plaza');
insert into shops (name, blk, shopaddress) values ('csnead2q', 904667, '8538 Judy Road');
insert into shops (name, blk, shopaddress) values ('ajubert2r', 434800, '34713 Shelley Road');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO orders (customerid,address,name,blk,shopaddress) 
SELECT c.customerid, c.address, s.name, s.blk, s.shopaddress
FROM customers c, shops s
ORDER BY random()
limit 1000;
