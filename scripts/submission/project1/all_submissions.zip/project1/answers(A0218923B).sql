/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/

/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */

/*
Chinese Autumn festival is going to happen soon around 21st Sep 2021. Many families are planning for a short term trip across some areas in China but may have limited budget.
This scenario was based on above and created 3 tables for one famous traveling plan website that you could bookmark travel plans with your email address. While there is price reduction, you would be able to received email to book the plan immediately. 
According to bookmark popularity, the website can plan for promotions and send updates through user email.

Entity set E1 to be t_user, including system generated user_id (as primary key) and user information last_name, first_name, email (Not Null & Unique), gender and age. 
Entity set E2 to be t_plan, for counrty & travel plan price information, including country_id(as primary key), country_name, city_name as well as price_total and travel_days_total.
Many-to-many relationship set R to be t_bookmark, which was stored the information of which user has bookmarked into wishlist for the combination of travel places. 

*/


/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* Entity set 1 - t_user table */

CREATE TABLE IF NOT EXISTS t_user(
    user_id INT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(50) UNIQUE NOT NULL,
    gender VARCHAR(50) NOT NULL,
    age INT NOT NULL
    );

/* Entity set 2 - t_plan table */
CREATE TABLE IF NOT EXISTS t_plan (
	plan_id INT PRIMARY KEY,
	country_name VARCHAR(50) NOT NULL,
	city_name VARCHAR(50) NOT NULL,
	price_total VARCHAR(50) NOT NULL,
	travel_days_total INT NOT NULL
);

/* M-M relationship - t_bookmark table */
CREATE TABLE IF NOT EXISTS t_bookmark (
    user_id INT REFERENCES t_user (user_id) DEFERRABLE,
    plan_id INT,
    PRIMARY KEY (user_id , plan_id),
    FOREIGN KEY (plan_id) REFERENCES t_plan(plan_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE
);

/************************************************************************/
/*                                                                      */ 
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* E1 t_user table insert */
insert into t_user (user_id, first_name, last_name, email, gender, age) values (1, 'Chane', 'Levesley', 'clevesley0@instagram.com', 'Male', 16);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (2, 'Joe', 'Kemet', 'jkemet1@yandex.ru', 'Male', 53);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (3, 'Rockie', 'Mazzilli', 'rmazzilli2@google.com', 'Male', 51);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (4, 'Dorine', 'Yellowlea', 'dyellowlea3@dailymotion.com', 'Female', 36);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (5, 'Cherie', 'Penner', 'cpenner4@si.edu', 'Male', 23);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (6, 'Penny', 'MacClure', 'pmacclure5@1688.com', 'Male', 38);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (7, 'Katharina', 'Adams', 'kadams6@e-recht24.de', 'Male', 33);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (8, 'Christie', 'Denis', 'cdenis7@prweb.com', 'Male', 51);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (9, 'Constantine', 'Fairlam', 'cfairlam8@artisteer.com', 'Male', 43);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (10, 'Cinda', 'Van Salzberger', 'cvansalzberger9@joomla.org', 'Female', 37);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (11, 'Syd', 'Fowler', 'sfowlera@lulu.com', 'Female', 23);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (12, 'Arlinda', 'Worthington', 'aworthingtonb@alexa.com', 'Male', 60);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (13, 'Aguste', 'Korb', 'akorbc@illinois.edu', 'Female', 58);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (14, 'Grange', 'Meikle', 'gmeikled@imdb.com', 'Female', 18);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (15, 'Ingemar', 'Hammett', 'ihammette@eepurl.com', 'Male', 37);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (16, 'Darby', 'Kingdon', 'dkingdonf@angelfire.com', 'Female', 44);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (17, 'Bary', 'De Antoni', 'bdeantonig@boston.com', 'Female', 57);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (18, 'Roxy', 'Clymer', 'rclymerh@merriam-webster.com', 'Male', 55);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (19, 'Nevil', 'Benedito', 'nbeneditoi@ucoz.ru', 'Male', 55);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (20, 'Blanca', 'Michell', 'bmichellj@feedburner.com', 'Female', 51);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (21, 'Abe', 'Sartain', 'asartaink@plala.or.jp', 'Male', 62);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (22, 'Lola', 'McCahey', 'lmccaheyl@home.pl', 'Male', 67);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (23, 'Kristal', 'Parvin', 'kparvinm@t-online.de', 'Male', 53);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (24, 'Roz', 'Haythornthwaite', 'rhaythornthwaiten@nbcnews.com', 'Male', 56);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (25, 'Dario', 'Summerbell', 'dsummerbello@dailymail.co.uk', 'Female', 53);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (26, 'Ryann', 'Shellsheere', 'rshellsheerep@cnet.com', 'Female', 58);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (27, 'Riki', 'Giffin', 'rgiffinq@elpais.com', 'Male', 57);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (28, 'Cob', 'Staig', 'cstaigr@rambler.ru', 'Male', 71);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (29, 'Cornelia', 'Lohde', 'clohdes@smugmug.com', 'Male', 36);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (30, 'Bron', 'Bennen', 'bbennent@slate.com', 'Male', 16);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (31, 'Tabina', 'Elcum', 'telcumu@xing.com', 'Male', 73);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (32, 'Theodosia', 'McRae', 'tmcraev@princeton.edu', 'Male', 71);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (33, 'Janis', 'Learmonth', 'jlearmonthw@typepad.com', 'Female', 27);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (34, 'Donica', 'Brabham', 'dbrabhamx@vkontakte.ru', 'Female', 40);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (35, 'Dorris', 'Bonniface', 'dbonnifacey@go.com', 'Male', 41);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (36, 'Misha', 'Mintram', 'mmintramz@slideshare.net', 'Female', 39);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (37, 'Hillard', 'Moneti', 'hmoneti10@fastcompany.com', 'Female', 22);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (38, 'Kellen', 'Baskeyfield', 'kbaskeyfield11@hp.com', 'Female', 19);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (39, 'Jaquith', 'Rilings', 'jrilings12@networkadvertising.org', 'Male', 69);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (40, 'Babbie', 'Puttnam', 'bputtnam13@over-blog.com', 'Female', 36);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (41, 'Rollie', 'Dibden', 'rdibden14@comcast.net', 'Male', 52);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (42, 'Freddie', 'Seakes', 'fseakes15@xinhuanet.com', 'Male', 35);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (43, 'Melantha', 'Giacobini', 'mgiacobini16@hugedomains.com', 'Male', 23);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (44, 'Eilis', 'Gorringe', 'egorringe17@de.vu', 'Male', 29);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (45, 'Arri', 'Parkyns', 'aparkyns18@wix.com', 'Female', 38);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (46, 'Myles', 'St. Aubyn', 'mstaubyn19@patch.com', 'Male', 47);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (47, 'Elden', 'Hurling', 'ehurling1a@samsung.com', 'Male', 45);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (48, 'Lura', 'Ikin', 'likin1b@biblegateway.com', 'Female', 32);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (49, 'Drugi', 'MacRitchie', 'dmacritchie1c@twitter.com', 'Female', 66);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (50, 'Pammie', 'Heninghem', 'pheninghem1d@ycombinator.com', 'Female', 28);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (51, 'Bev', 'Bidder', 'bbidder1e@unc.edu', 'Male', 25);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (52, 'Aeriell', 'Hoble', 'ahoble1f@ted.com', 'Male', 35);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (53, 'Marjorie', 'Stute', 'mstute1g@networksolutions.com', 'Male', 53);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (54, 'Stephi', 'Jagels', 'sjagels1h@liveinternet.ru', 'Female', 37);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (55, 'Laurens', 'Frowd', 'lfrowd1i@yandex.ru', 'Male', 71);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (56, 'Coletta', 'Fessier', 'cfessier1j@washingtonpost.com', 'Male', 53);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (57, 'Edan', 'Del Monte', 'edelmonte1k@artisteer.com', 'Male', 33);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (58, 'Claire', 'Buncher', 'cbuncher1l@quantcast.com', 'Female', 64);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (59, 'Lindon', 'Ferrucci', 'lferrucci1m@house.gov', 'Female', 65);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (60, 'Lucienne', 'Sedgmond', 'lsedgmond1n@example.com', 'Male', 36);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (61, 'Taryn', 'Aronov', 'taronov1o@theglobeandmail.com', 'Male', 69);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (62, 'Gerhard', 'Sibylla', 'gsibylla1p@home.pl', 'Male', 25);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (63, 'Nikos', 'Groundwator', 'ngroundwator1q@1688.com', 'Female', 31);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (64, 'Keven', 'Richardet', 'krichardet1r@ted.com', 'Male', 42);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (65, 'Arie', 'Tissier', 'atissier1s@miibeian.gov.cn', 'Male', 18);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (66, 'Joana', 'Caseri', 'jcaseri1t@bloglovin.com', 'Male', 40);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (67, 'Lucie', 'Osban', 'losban1u@blogtalkradio.com', 'Male', 36);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (68, 'Berky', 'Raiman', 'braiman1v@netscape.com', 'Female', 48);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (69, 'El', 'Bodycomb', 'ebodycomb1w@ibm.com', 'Male', 21);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (70, 'Alain', 'Althorpe', 'aalthorpe1x@newyorker.com', 'Male', 57);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (71, 'Sylvia', 'Southby', 'ssouthby1y@jimdo.com', 'Female', 56);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (72, 'Currie', 'Reveland', 'creveland1z@creativecommons.org', 'Female', 38);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (73, 'Lonnard', 'O''Mara', 'lomara20@uiuc.edu', 'Female', 56);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (74, 'Lynnet', 'Yansons', 'lyansons21@latimes.com', 'Female', 54);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (75, 'Tabb', 'Kolakowski', 'tkolakowski22@tiny.cc', 'Female', 59);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (76, 'Bartel', 'Naptine', 'bnaptine23@home.pl', 'Male', 58);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (77, 'George', 'Habbema', 'ghabbema24@bloglovin.com', 'Female', 48);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (78, 'Livy', 'Atto', 'latto25@cdbaby.com', 'Female', 50);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (79, 'Ole', 'Witheford', 'owitheford26@cbslocal.com', 'Female', 19);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (80, 'Arvin', 'Juniper', 'ajuniper27@amazon.de', 'Female', 42);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (81, 'Garey', 'McElrea', 'gmcelrea28@who.int', 'Female', 32);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (82, 'Lawry', 'Doorbar', 'ldoorbar29@cloudflare.com', 'Male', 36);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (83, 'Devora', 'Maydway', 'dmaydway2a@myspace.com', 'Male', 70);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (84, 'Rivi', 'Sterrie', 'rsterrie2b@webs.com', 'Male', 47);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (85, 'Casar', 'Warkup', 'cwarkup2c@businesswire.com', 'Male', 30);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (86, 'Janine', 'Kerridge', 'jkerridge2d@sfgate.com', 'Male', 17);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (87, 'Bobbette', 'Friary', 'bfriary2e@multiply.com', 'Female', 19);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (88, 'Alice', 'Winteringham', 'awinteringham2f@homestead.com', 'Female', 49);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (89, 'Kris', 'Hackley', 'khackley2g@purevolume.com', 'Male', 21);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (90, 'Myrlene', 'Durtnal', 'mdurtnal2h@boston.com', 'Male', 66);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (91, 'Shalna', 'Harget', 'sharget2i@google.com.hk', 'Female', 52);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (92, 'Seka', 'Spores', 'sspores2j@ameblo.jp', 'Male', 43);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (93, 'Gusella', 'Renshaw', 'grenshaw2k@cnet.com', 'Male', 51);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (94, 'Willy', 'Merriday', 'wmerriday2l@amazon.co.jp', 'Male', 45);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (95, 'Tilda', 'Fellows', 'tfellows2m@blogger.com', 'Female', 63);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (96, 'Alonzo', 'Greville', 'agreville2n@youtu.be', 'Male', 52);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (97, 'Karla', 'Pichan', 'kpichan2o@slashdot.org', 'Female', 30);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (98, 'Bastien', 'Loakes', 'bloakes2p@artisteer.com', 'Female', 49);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (99, 'Tris', 'Deboick', 'tdeboick2q@pinterest.com', 'Female', 58);
insert into t_user (user_id, first_name, last_name, email, gender, age) values (100, 'Marten', 'Thombleson', 'mthombleson2r@tuttocitta.it', 'Male', 24);

/* E2 t_plan table insert */
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (1, 'China', 'Sancha', '¥3185.57', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (2, 'China', 'Liurenba', '¥2601.27', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (3, 'China', 'Daming', '¥2526.52', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (4, 'China', 'Fengchuan', '¥4942.28', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (5, 'China', 'Renxian', '¥2371.87', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (6, 'China', 'Yecun', '¥4471.52', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (7, 'China', 'Dongyong', '¥4313.18', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (8, 'China', 'Yangchengzhuang', '¥3482.85', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (9, 'China', 'Tangwei', '¥2950.63', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (10, 'China', 'Yanjiang', '¥2591.07', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (11, 'China', 'Guomaying', '¥3115.27', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (12, 'China', 'Jiazhuyuan', '¥2601.32', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (13, 'China', 'Xinminxiang', '¥2099.19', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (14, 'China', 'Suqin Huimin', '¥4468.80', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (15, 'China', 'Anjia', '¥3841.39', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (16, 'China', 'Hekou', '¥3140.64', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (17, 'China', 'Shangjie', '¥2465.32', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (18, 'China', 'Nangxian', '¥2613.65', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (19, 'China', 'Ruixi', '¥3195.73', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (20, 'China', 'Guangsheng', '¥2153.61', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (21, 'China', 'Yong’an', '¥4577.99', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (22, 'China', 'Changzheng', '¥2102.68', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (23, 'China', 'Chonghe', '¥2276.77', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (24, 'China', 'Changtan', '¥3218.20', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (25, 'China', 'Yuyao', '¥2420.22', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (26, 'China', 'Duanshen', '¥3304.92', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (27, 'China', 'Shiyaogou', '¥2317.08', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (28, 'China', 'Meicheng', '¥3782.82', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (29, 'China', 'Sidu', '¥2569.68', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (30, 'China', 'Bijia', '¥4132.67', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (31, 'China', 'Liangzeng', '¥3745.53', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (32, 'China', 'Changlu', '¥4493.01', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (33, 'China', 'Qiaobian', '¥4965.74', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (34, 'China', 'Qingyang', '¥2777.33', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (35, 'China', 'Baokou', '¥3498.40', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (36, 'China', 'Bayan Hure', '¥3244.73', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (37, 'China', 'Rencun', '¥3977.54', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (38, 'China', 'Yitang', '¥2324.48', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (39, 'China', 'Litian', '¥4696.88', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (40, 'China', 'Jiangcun', '¥4519.34', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (41, 'China', 'Wanbu', '¥4500.84', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (42, 'China', 'Liulin', '¥2395.73', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (43, 'China', 'Yukou', '¥2074.13', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (44, 'China', 'Gangtun', '¥4613.72', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (45, 'China', 'Huazangsi', '¥4729.92', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (46, 'China', 'Beijiang', '¥4578.00', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (47, 'China', 'Hanjia', '¥3368.17', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (48, 'China', 'Shuibian', '¥3941.06', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (49, 'China', 'Nanjin', '¥3602.20', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (50, 'China', 'Yangyu', '¥2520.64', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (51, 'China', 'Huangmei', '¥3413.50', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (52, 'China', 'Lingyang', '¥2662.80', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (53, 'China', 'Longxian Chengguanzhen', '¥2698.52', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (54, 'China', 'Lugu', '¥2575.74', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (55, 'China', 'Yaozhuang', '¥4523.92', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (56, 'China', 'Qiucun', '¥4876.07', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (57, 'China', 'Dongkeng', '¥3477.58', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (58, 'China', 'Jinchang', '¥2201.77', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (59, 'China', 'Gaogongdao', '¥2061.17', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (60, 'China', 'Cheqiao', '¥4324.78', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (61, 'China', 'Reshui', '¥2038.05', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (62, 'China', 'Xilanqi', '¥4704.63', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (63, 'China', 'Baoquanshan', '¥4108.57', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (64, 'China', 'Luyang', '¥3894.19', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (65, 'China', 'Dapeng', '¥4527.65', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (66, 'China', 'Xinfu', '¥2948.75', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (67, 'China', 'Taipingzhuang', '¥2262.52', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (68, 'China', 'Jiuting', '¥2892.87', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (69, 'China', 'Shangchewan', '¥3640.63', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (70, 'China', 'Shishang', '¥3770.63', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (71, 'China', 'Tielou', '¥4244.37', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (72, 'China', 'Jingjiang', '¥4250.84', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (73, 'China', 'Heshang', '¥4948.62', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (74, 'China', 'Garmo', '¥3278.29', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (75, 'China', 'Qiaotou', '¥4090.47', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (76, 'China', 'Longcang', '¥3355.47', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (77, 'China', 'Fudian', '¥2372.60', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (78, 'China', 'Xiaoying', '¥2116.60', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (79, 'China', 'Yunxi', '¥3341.99', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (80, 'China', 'Jin’an', '¥2786.01', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (81, 'China', 'Lubei', '¥3697.47', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (82, 'China', 'Wadi', '¥2107.09', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (83, 'China', 'Zhenzhushan', '¥3251.85', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (84, 'China', 'Fuxing', '¥4140.04', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (85, 'China', 'Liuhe', '¥3147.67', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (86, 'China', 'Wenfang', '¥3125.78', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (87, 'China', 'Jiucaizhuang', '¥4122.29', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (88, 'China', 'Changsha', '¥2730.88', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (89, 'China', 'Xichang', '¥4900.37', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (90, 'China', 'Baiquesi', '¥4753.87', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (91, 'China', 'Fangxian', '¥2756.43', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (92, 'China', 'Dalongtan', '¥4860.58', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (93, 'China', 'Daliu', '¥4142.07', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (94, 'China', 'Jinping', '¥2914.77', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (95, 'China', 'Jiangyin', '¥4613.95', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (96, 'China', 'Guanyinsi', '¥2661.76', 3);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (97, 'China', 'Damatou', '¥4222.21', 2);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (98, 'China', 'Shuangzhong', '¥4443.02', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (99, 'China', 'Jianrao', '¥2228.73', 1);
insert into t_plan (plan_id, country_name, city_name, price_total, travel_days_total) values (100, 'China', 'Qingjiang', '¥3509.23', 2);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into t_bookmark select u.user_id, p.plan_id from t_user u cross join t_plan p where random() <=0.1 limit 1000;
