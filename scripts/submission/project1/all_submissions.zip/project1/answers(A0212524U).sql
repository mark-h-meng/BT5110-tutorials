 /************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/

-- KE MA
-- A0212524U
-- BT5110
-- Aug 24

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/*The code is written for PostgreSQL*/

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*

##A simple Schema is shown below, which shows the basic design idea.

E1: employee(e_id(P), e_name, first_year, depart ) <-- R: advise(i_id(F), e_id(F), me_date) 
--> E2: instructor(i_id(P), i_name, job_title, depart)

##Tables and attributes:

E1: employee
e_id(P):    varchar,    employee ID which is a primary key.
e_name:     varchar,    employee names
first_year: boolean,    whether this employee is in first year or not.
depart:     varchar,    department of the employee

E2: instructor
i_id(P):    varchar,    instructor/mentor's ID
i_name:     varchar,    instructor/mentor's name
job_title   varchar,    instructor/mentor's job title
depart      varchar,    department of the instructor

R: advise
i_id(F)     varchar,    instructor/mentor's ID
e_id(F)     varcahr,    employee ID
me_date     date,       the date that cartain advise record creates.
   
In the COMPANY Ltd., mentor culture is prevalent here. Each entry level 
employee will be assigned with a mentor who are from middle or high posions 
and willing to periodically offer a face-to-face meeting with those fresh 
birds, giving advise or sharing their experience. 

Now the company creates a database called mentor to save the meeting records 
as well as personal info of employees and instructors. Table 'advise' is a 
relational table link E1,E2.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* create 3 tables */
CREATE TABLE employee(
    e_id varchar(20) PRIMARY KEY,
    e_name varchar(20),
    first_year bool,
    depart varchar(30));
    
CREATE TABLE instructor(
    i_id varchar(20) PRIMARY KEY,
    i_name varchar(20),
    job_title varchar(50),
    depart varchar(30));

CREATE TABLE advise(
    i_id varchar(20) NOT NULL 
        REFERENCES instructor (i_id)
        ON DELETE SET NULL,
    e_id varchar(20) NOT NULL,
    me_date date,
    FOREIGN KEY (e_id) 
        REFERENCES employee (e_id)
        ON DELETE cascade);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* populate table employee */
insert into employee (e_id, e_name, first_year, depart) values ('0904-6098', 'Brynne Durtnell', false, 'Training');
insert into employee (e_id, e_name, first_year, depart) values ('42411-022', 'Bevan Maiden', false, 'Product Management');
insert into employee (e_id, e_name, first_year, depart) values ('50383-803', 'Lorain Andrelli', false, 'Engineering');
insert into employee (e_id, e_name, first_year, depart) values ('68747-6031', 'Herta Aspland', false, 'Research and Development');
insert into employee (e_id, e_name, first_year, depart) values ('58479-006', 'Leslie Akrigg', false, 'Services');
insert into employee (e_id, e_name, first_year, depart) values ('41167-1000', 'Hasty Duddin', true, 'Research and Development');
insert into employee (e_id, e_name, first_year, depart) values ('27495-013', 'Robinia Baynard', true, 'Sales');
insert into employee (e_id, e_name, first_year, depart) values ('13537-117', 'Natalie Waddup', true, 'Support');
insert into employee (e_id, e_name, first_year, depart) values ('50563-161', 'Heindrick Kenrick', false, 'Research and Development');
insert into employee (e_id, e_name, first_year, depart) values ('54473-225', 'Tabatha Coal', true, 'Engineering');
insert into employee (e_id, e_name, first_year, depart) values ('16714-297', 'Borden Cubberley', true, 'Accounting');
insert into employee (e_id, e_name, first_year, depart) values ('11673-612', 'Reinald Alday', false, 'Human Resources');
insert into employee (e_id, e_name, first_year, depart) values ('17433-9884', 'Joelynn Turfus', false, 'Accounting');
insert into employee (e_id, e_name, first_year, depart) values ('13537-513', 'Tiebout O''Lunney', false, 'Accounting');
insert into employee (e_id, e_name, first_year, depart) values ('66336-687', 'Melva Hellikes', true, 'Support');
insert into employee (e_id, e_name, first_year, depart) values ('49852-012', 'Cornall Harcase', false, 'Research and Development');
insert into employee (e_id, e_name, first_year, depart) values ('0121-0775', 'Brady Brabbins', true, 'Training');
insert into employee (e_id, e_name, first_year, depart) values ('64942-1106', 'Tessy Deakes', true, 'Accounting');
insert into employee (e_id, e_name, first_year, depart) values ('61442-171', 'Immanuel Duester', true, 'Business Development');
insert into employee (e_id, e_name, first_year, depart) values ('58414-8321', 'Drake Kynforth', true, 'Legal');
insert into employee (e_id, e_name, first_year, depart) values ('63629-4888', 'Alan Gwyn', true, 'Human Resources');
insert into employee (e_id, e_name, first_year, depart) values ('50845-0034', 'Fransisco Danbi', false, 'Legal');
insert into employee (e_id, e_name, first_year, depart) values ('33342-047', 'Jacquelin Urvoy', false, 'Engineering');
insert into employee (e_id, e_name, first_year, depart) values ('21695-944', 'Mariel Brinkworth', false, 'Marketing');
insert into employee (e_id, e_name, first_year, depart) values ('0186-1095', 'Urson Oakenfield', true, 'Marketing');
insert into employee (e_id, e_name, first_year, depart) values ('79596-090', 'Michael Dreossi', true, 'Business Development');
insert into employee (e_id, e_name, first_year, depart) values ('54973-2043', 'Flori Andrys', true, 'Marketing');
insert into employee (e_id, e_name, first_year, depart) values ('55863-431', 'Charyl Senescall', false, 'Research and Development');
insert into employee (e_id, e_name, first_year, depart) values ('61727-303', 'Barbabas Village', false, 'Engineering');
insert into employee (e_id, e_name, first_year, depart) values ('53329-940', 'Robby Aymer', false, 'Training');
insert into employee (e_id, e_name, first_year, depart) values ('52763-501', 'Biddie Croft', true, 'Human Resources');
insert into employee (e_id, e_name, first_year, depart) values ('62242-010', 'Cordie Arnot', false, 'Business Development');
insert into employee (e_id, e_name, first_year, depart) values ('49999-599', 'Abran Bowery', false, 'Human Resources');
insert into employee (e_id, e_name, first_year, depart) values ('42361-005', 'Frederick Cohrs', true, 'Marketing');
insert into employee (e_id, e_name, first_year, depart) values ('51785-921', 'Patty McInility', false, 'Support');
insert into employee (e_id, e_name, first_year, depart) values ('0363-4490', 'Neille Lago', true, 'Training');
insert into employee (e_id, e_name, first_year, depart) values ('64942-1216', 'Fina Wimmers', true, 'Accounting');
insert into employee (e_id, e_name, first_year, depart) values ('68788-9747', 'Dolly Greder', true, 'Business Development');
insert into employee (e_id, e_name, first_year, depart) values ('10096-0241', 'Fifine Grolle', false, 'Support');
insert into employee (e_id, e_name, first_year, depart) values ('61786-016', 'Brita Alliott', false, 'Research and Development');
insert into employee (e_id, e_name, first_year, depart) values ('13537-536', 'Clare Rivenzon', false, 'Marketing');
insert into employee (e_id, e_name, first_year, depart) values ('13985-014', 'Matthieu O''Neal', false, 'Services');
insert into employee (e_id, e_name, first_year, depart) values ('52854-036', 'Geoffry McCambrois', true, 'Engineering');
insert into employee (e_id, e_name, first_year, depart) values ('42549-569', 'Cyndi McGloughlin', true, 'Accounting');
insert into employee (e_id, e_name, first_year, depart) values ('51079-699', 'Kath Demaine', false, 'Product Management');
insert into employee (e_id, e_name, first_year, depart) values ('0615-1511', 'Ellen Werrett', false, 'Marketing');
insert into employee (e_id, e_name, first_year, depart) values ('30142-914', 'Ilario Pierse', true, 'Product Management');
insert into employee (e_id, e_name, first_year, depart) values ('51824-164', 'Karna Stoodale', false, 'Accounting');
insert into employee (e_id, e_name, first_year, depart) values ('50425-011', 'Antonella Shury', false, 'Accounting');
insert into employee (e_id, e_name, first_year, depart) values ('52410-6141', 'Lindon Trosdall', false, 'Product Management');
insert into employee (e_id, e_name, first_year, depart) values ('59779-483', 'Wang Vegas', true, 'Training');
insert into employee (e_id, e_name, first_year, depart) values ('49035-024', 'Zorine Hamm', false, 'Training');
insert into employee (e_id, e_name, first_year, depart) values ('0904-5736', 'Mattie Dumphreys', false, 'Product Management');
insert into employee (e_id, e_name, first_year, depart) values ('60505-0751', 'Osbourn Wilshin', true, 'Legal');
insert into employee (e_id, e_name, first_year, depart) values ('61047-831', 'Parke Cammell', true, 'Services');
insert into employee (e_id, e_name, first_year, depart) values ('54973-0624', 'Willard Foynes', false, 'Support');
insert into employee (e_id, e_name, first_year, depart) values ('60760-334', 'Cecilius Ferreri', true, 'Support');
insert into employee (e_id, e_name, first_year, depart) values ('63730-220', 'Alejoa Pitts', false, 'Services');
insert into employee (e_id, e_name, first_year, depart) values ('61657-0971', 'Sophia Meek', false, 'Engineering');
insert into employee (e_id, e_name, first_year, depart) values ('41268-437', 'Feliks Robker', true, 'Human Resources');
insert into employee (e_id, e_name, first_year, depart) values ('53346-1329', 'Randi Jaggs', false, 'Engineering');
insert into employee (e_id, e_name, first_year, depart) values ('13811-614', 'Jorey Borrett', false, 'Human Resources');
insert into employee (e_id, e_name, first_year, depart) values ('60505-0117', 'Adrian Torbett', true, 'Human Resources');
insert into employee (e_id, e_name, first_year, depart) values ('43419-020', 'Maggi Hollingsby', true, 'Research and Development');
insert into employee (e_id, e_name, first_year, depart) values ('41250-678', 'Kirbee Jennings', false, 'Services');
insert into employee (e_id, e_name, first_year, depart) values ('36987-3238', 'Sloan MacNeely', true, 'Support');
insert into employee (e_id, e_name, first_year, depart) values ('52642-006', 'Shelton McClancy', false, 'Legal');
insert into employee (e_id, e_name, first_year, depart) values ('52731-7026', 'Wylma Morston', false, 'Sales');
insert into employee (e_id, e_name, first_year, depart) values ('49288-0396', 'Andria Sander', false, 'Services');
insert into employee (e_id, e_name, first_year, depart) values ('63029-644', 'Dana Rehn', true, 'Services');
insert into employee (e_id, e_name, first_year, depart) values ('54868-0191', 'Tova Husbands', false, 'Product Management');
insert into employee (e_id, e_name, first_year, depart) values ('11523-0544', 'Gaye Biasini', false, 'Accounting');
insert into employee (e_id, e_name, first_year, depart) values ('21695-219', 'Viole Negal', true, 'Accounting');
insert into employee (e_id, e_name, first_year, depart) values ('0268-6643', 'Kristal Liddall', true, 'Human Resources');
insert into employee (e_id, e_name, first_year, depart) values ('61096-0033', 'Sutherland Vanichev', true, 'Support');
insert into employee (e_id, e_name, first_year, depart) values ('20276-161', 'Sibeal Hopewell', true, 'Human Resources');
insert into employee (e_id, e_name, first_year, depart) values ('0615-7639', 'Gusty Stapylton', false, 'Training');
insert into employee (e_id, e_name, first_year, depart) values ('75870-008', 'Dionne Pyzer', false, 'Accounting');
insert into employee (e_id, e_name, first_year, depart) values ('0268-6787', 'Don Housecroft', false, 'Training');
insert into employee (e_id, e_name, first_year, depart) values ('17156-021', 'Isaak Treske', false, 'Marketing');
insert into employee (e_id, e_name, first_year, depart) values ('58118-7169', 'Oates Twine', true, 'Engineering');
insert into employee (e_id, e_name, first_year, depart) values ('0603-5916', 'Orelie Rabbitt', true, 'Training');
insert into employee (e_id, e_name, first_year, depart) values ('13733-070', 'Cybill Spaldin', false, 'Accounting');
insert into employee (e_id, e_name, first_year, depart) values ('57955-1904', 'Lilia Standeven', true, 'Product Management');
insert into employee (e_id, e_name, first_year, depart) values ('69092-001', 'Tarra Hatch', true, 'Support');
insert into employee (e_id, e_name, first_year, depart) values ('52125-355', 'Caresse Bentote', false, 'Product Management');
insert into employee (e_id, e_name, first_year, depart) values ('50436-9971', 'Jimmie Nucciotti', false, 'Marketing');
insert into employee (e_id, e_name, first_year, depart) values ('59898-121', 'Rochelle Wigan', false, 'Business Development');
insert into employee (e_id, e_name, first_year, depart) values ('37000-845', 'Clarance Sergeaunt', true, 'Legal');
insert into employee (e_id, e_name, first_year, depart) values ('0562-7805', 'Karlan Shoemark', true, 'Legal');
insert into employee (e_id, e_name, first_year, depart) values ('0268-3057', 'Maud Gedney', true, 'Sales');
insert into employee (e_id, e_name, first_year, depart) values ('64578-0089', 'Ollie Fletcher', true, 'Product Management');
insert into employee (e_id, e_name, first_year, depart) values ('41190-590', 'Dorthea McCurlye', false, 'Sales');
insert into employee (e_id, e_name, first_year, depart) values ('61957-9401', 'Judd Mullender', true, 'Marketing');
insert into employee (e_id, e_name, first_year, depart) values ('68016-285', 'Elyn Zellmer', false, 'Product Management');
insert into employee (e_id, e_name, first_year, depart) values ('0220-1106', 'Ty Exer', true, 'Marketing');
insert into employee (e_id, e_name, first_year, depart) values ('61727-311', 'Janessa Michurin', true, 'Sales');
insert into employee (e_id, e_name, first_year, depart) values ('0409-7809', 'Cynthie Baudino', false, 'Engineering');
insert into employee (e_id, e_name, first_year, depart) values ('53440-005', 'Pattie Beaby', false, 'Sales');
insert into employee (e_id, e_name, first_year, depart) values ('58503-025', 'Cecilia Thew', false, 'Accounting');
insert into employee (e_id, e_name, first_year, depart) values ('57520-0150', 'Theodor Jenicke', true, 'Product Management');
insert into employee (e_id, e_name, first_year, depart) values ('42254-031', 'Inness Quiney', true, 'Human Resources');
insert into employee (e_id, e_name, first_year, depart) values ('54569-0392', 'Blondy Ebhardt', true, 'Sales');
insert into employee (e_id, e_name, first_year, depart) values ('53329-143', 'Thorndike Dabels', true, 'Product Management');
insert into employee (e_id, e_name, first_year, depart) values ('0071-1014', 'Patrice Zuppa', true, 'Marketing');
insert into employee (e_id, e_name, first_year, depart) values ('57627-153', 'Augustus Maestrini', true, 'Marketing');
insert into employee (e_id, e_name, first_year, depart) values ('54569-1585', 'Jervis Glenton', true, 'Business Development');
insert into employee (e_id, e_name, first_year, depart) values ('49288-0001', 'Felisha Fulkes', false, 'Product Management');
insert into employee (e_id, e_name, first_year, depart) values ('0603-3897', 'Fran Iorio', false, 'Sales');
insert into employee (e_id, e_name, first_year, depart) values ('0363-4013', 'Dukie Paradis', true, 'Accounting');
insert into employee (e_id, e_name, first_year, depart) values ('51525-5901', 'Irita Urwen', false, 'Support');
insert into employee (e_id, e_name, first_year, depart) values ('13630-0037', 'Alair Banane', false, 'Support');
insert into employee (e_id, e_name, first_year, depart) values ('55056-0808', 'Avictor Bartlett', true, 'Business Development');
insert into employee (e_id, e_name, first_year, depart) values ('50795-3001', 'Stavro Vasyutin', true, 'Services');
insert into employee (e_id, e_name, first_year, depart) values ('57237-054', 'Edmund Loweth', true, 'Research and Development');
insert into employee (e_id, e_name, first_year, depart) values ('50474-804', 'Ludvig Daens', false, 'Engineering');
insert into employee (e_id, e_name, first_year, depart) values ('51079-169', 'Alejandrina Suttill', false, 'Legal');
insert into employee (e_id, e_name, first_year, depart) values ('55154-4749', 'Melinde Rennick', false, 'Research and Development');
insert into employee (e_id, e_name, first_year, depart) values ('24385-924', 'Ricky Grinsdale', false, 'Product Management');
insert into employee (e_id, e_name, first_year, depart) values ('21695-698', 'Katuscha Manley', false, 'Services');

/* populate table instructor */
insert into instructor (i_id, i_name, job_title, depart) values ('40032-551', 'Sarita Fotherby', 'Web Developer II', 'Legal');
insert into instructor (i_id, i_name, job_title, depart) values ('0944-2841', 'Fowler Nolleau', 'Product Engineer', 'Business Development');
insert into instructor (i_id, i_name, job_title, depart) values ('10885-002', 'Madella Sorrell', 'Dental Hygienist', 'Engineering');
insert into instructor (i_id, i_name, job_title, depart) values ('55312-110', 'Rafaelita Coppenhall', 'Data Coordiator', 'Human Resources');
insert into instructor (i_id, i_name, job_title, depart) values ('63323-476', 'Catherin Siret', 'VP Accounting', 'Product Management');
insert into instructor (i_id, i_name, job_title, depart) values ('0363-0420', 'Latrena Borland', 'Senior Developer', 'Accounting');
insert into instructor (i_id, i_name, job_title, depart) values ('50988-194', 'Val Woolam', 'VP Sales', 'Engineering');
insert into instructor (i_id, i_name, job_title, depart) values ('68258-3053', 'Atalanta Jermy', 'Compensation Analyst', 'Training');
insert into instructor (i_id, i_name, job_title, depart) values ('0591-3551', 'Euphemia Hunnicutt', 'Assistant Professor', 'Human Resources');
insert into instructor (i_id, i_name, job_title, depart) values ('53441-346', 'Modestine Meachen', 'Recruiting Manager', 'Human Resources');
insert into instructor (i_id, i_name, job_title, depart) values ('43598-410', 'Lissa Matuschek', 'Actuary', 'Training');
insert into instructor (i_id, i_name, job_title, depart) values ('49614-361', 'Abner Pouck', 'Account Executive', 'Human Resources');
insert into instructor (i_id, i_name, job_title, depart) values ('20536-322', 'Josepha Rosten', 'Junior Executive', 'Training');
insert into instructor (i_id, i_name, job_title, depart) values ('62032-131', 'Crista Cuell', 'Senior Developer', 'Support');
insert into instructor (i_id, i_name, job_title, depart) values ('63629-5075', 'Derrek Kleynermans', 'GIS Technical Architect', 'Training');
insert into instructor (i_id, i_name, job_title, depart) values ('52083-601', 'Stephanie Moxted', 'Software Test Engineer IV', 'Accounting');
insert into instructor (i_id, i_name, job_title, depart) values ('10370-214', 'Jo ann Dahmel', 'Sales Representative', 'Services');
insert into instructor (i_id, i_name, job_title, depart) values ('55910-852', 'Hurleigh Godlip', 'Recruiter', 'Engineering');
insert into instructor (i_id, i_name, job_title, depart) values ('43406-0043', 'Farlee Pittham', 'Sales Associate', 'Sales');
insert into instructor (i_id, i_name, job_title, depart) values ('50845-0017', 'Mischa Fontin', 'Dental Hygienist', 'Marketing');
insert into instructor (i_id, i_name, job_title, depart) values ('24090-720', 'Atalanta Lathan', 'Actuary', 'Support');
insert into instructor (i_id, i_name, job_title, depart) values ('60429-024', 'Waylin Rappoport', 'Payment Adjustment Coordinator', 'Training');
insert into instructor (i_id, i_name, job_title, depart) values ('58232-0748', 'Estevan Blayd', 'Human Resources Manager', 'Business Development');
insert into instructor (i_id, i_name, job_title, depart) values ('61957-0110', 'Corabel Piscopo', 'Payment Adjustment Coordinator', 'Support');
insert into instructor (i_id, i_name, job_title, depart) values ('63941-473', 'Valentina Riseam', 'Project Manager', 'Services');
insert into instructor (i_id, i_name, job_title, depart) values ('76237-193', 'Neel Lurcock', 'Graphic Designer', 'Human Resources');
insert into instructor (i_id, i_name, job_title, depart) values ('54416-002', 'Gabriellia Pillinger', 'Computer Systems Analyst I', 'Business Development');
insert into instructor (i_id, i_name, job_title, depart) values ('11523-4326', 'Maryanne Gibbett', 'Human Resources Manager', 'Legal');
insert into instructor (i_id, i_name, job_title, depart) values ('64942-1140', 'Freeland Heditch', 'Account Coordinator', 'Training');
insert into instructor (i_id, i_name, job_title, depart) values ('31722-712', 'Milena Wickens', 'Analyst Programmer', 'Accounting');
insert into instructor (i_id, i_name, job_title, depart) values ('49288-0022', 'Hadria Zamora', 'Information Systems Manager', 'Research and Development');
insert into instructor (i_id, i_name, job_title, depart) values ('49288-0420', 'Xylina Skouling', 'Nurse', 'Sales');
insert into instructor (i_id, i_name, job_title, depart) values ('65954-584', 'Ashby Bonn', 'Social Worker', 'Product Management');
insert into instructor (i_id, i_name, job_title, depart) values ('43063-443', 'Vitia Konneke', 'Legal Assistant', 'Marketing');
insert into instructor (i_id, i_name, job_title, depart) values ('48951-5038', 'Vin Orrill', 'VP Sales', 'Accounting');
insert into instructor (i_id, i_name, job_title, depart) values ('0781-3174', 'Homerus Hunting', 'VP Accounting', 'Engineering');
insert into instructor (i_id, i_name, job_title, depart) values ('61957-0101', 'Isidor Toon', 'Actuary', 'Accounting');
insert into instructor (i_id, i_name, job_title, depart) values ('54868-6288', 'Wilbert Aveling', 'Chief Design Engineer', 'Sales');
insert into instructor (i_id, i_name, job_title, depart) values ('49884-578', 'Traver Muddicliffe', 'Database Administrator IV', 'Support');
insert into instructor (i_id, i_name, job_title, depart) values ('50730-3001', 'Charlot McCurdy', 'Junior Executive', 'Marketing');
insert into instructor (i_id, i_name, job_title, depart) values ('51141-0240', 'Ed Littleproud', 'Internal Auditor', 'Human Resources');
insert into instructor (i_id, i_name, job_title, depart) values ('68151-4071', 'Zerk Hartzogs', 'Media Manager III', 'Training');
insert into instructor (i_id, i_name, job_title, depart) values ('37205-223', 'Brina Dudden', 'Accounting Assistant IV', 'Product Management');
insert into instructor (i_id, i_name, job_title, depart) values ('0527-1372', 'Aurlie Bacon', 'Financial Analyst', 'Engineering');
insert into instructor (i_id, i_name, job_title, depart) values ('63629-3646', 'Millisent Vickarman', 'Teacher', 'Research and Development');
insert into instructor (i_id, i_name, job_title, depart) values ('37012-526', 'Eliza Dockray', 'Statistician IV', 'Product Management');
insert into instructor (i_id, i_name, job_title, depart) values ('52125-229', 'Gilles Bruckenthal', 'Director of Sales', 'Engineering');
insert into instructor (i_id, i_name, job_title, depart) values ('68428-036', 'Sergent Rhead', 'Staff Scientist', 'Marketing');
insert into instructor (i_id, i_name, job_title, depart) values ('68084-174', 'Fianna Conring', 'Sales Associate', 'Product Management');
insert into instructor (i_id, i_name, job_title, depart) values ('11084-539', 'Ellsworth Paddell', 'Social Worker', 'Sales');
insert into instructor (i_id, i_name, job_title, depart) values ('54838-144', 'Rodd Stranio', 'Geological Engineer', 'Human Resources');
insert into instructor (i_id, i_name, job_title, depart) values ('48951-8171', 'Zelda O''Kynsillaghe', 'Librarian', 'Support');
insert into instructor (i_id, i_name, job_title, depart) values ('60764-011', 'Malina Cauthra', 'Dental Hygienist', 'Product Management');
insert into instructor (i_id, i_name, job_title, depart) values ('44224-1030', 'Edd Worcester', 'Account Representative IV', 'Human Resources');
insert into instructor (i_id, i_name, job_title, depart) values ('49348-852', 'Emlyn Weems', 'Assistant Professor', 'Training');
insert into instructor (i_id, i_name, job_title, depart) values ('49999-779', 'Haskel Callf', 'Clinical Specialist', 'Services');
insert into instructor (i_id, i_name, job_title, depart) values ('61715-075', 'Gradeigh Peinke', 'VP Product Management', 'Support');
insert into instructor (i_id, i_name, job_title, depart) values ('43063-182', 'Shanda Haggas', 'Information Systems Manager', 'Training');
insert into instructor (i_id, i_name, job_title, depart) values ('49967-671', 'Lucina Biaggiotti', 'Research Nurse', 'Training');
insert into instructor (i_id, i_name, job_title, depart) values ('52125-603', 'Raff Bate', 'Business Systems Development Analyst', 'Marketing');
insert into instructor (i_id, i_name, job_title, depart) values ('76237-316', 'Tammy Reuben', 'Biostatistician II', 'Research and Development');
insert into instructor (i_id, i_name, job_title, depart) values ('54868-5132', 'Celisse Benstead', 'Analog Circuit Design manager', 'Business Development');
insert into instructor (i_id, i_name, job_title, depart) values ('54569-0813', 'Janenna Cana', 'Account Executive', 'Sales');
insert into instructor (i_id, i_name, job_title, depart) values ('0054-0063', 'Skelly Barthelme', 'Executive Secretary', 'Support');
insert into instructor (i_id, i_name, job_title, depart) values ('21695-968', 'Shela Masding', 'Engineer II', 'Legal');
insert into instructor (i_id, i_name, job_title, depart) values ('10096-0243', 'Tristan Garland', 'Business Systems Development Analyst', 'Human Resources');
insert into instructor (i_id, i_name, job_title, depart) values ('36800-079', 'Berty Redmond', 'Nurse', 'Human Resources');
insert into instructor (i_id, i_name, job_title, depart) values ('54859-512', 'Miriam Haggas', 'Food Chemist', 'Human Resources');
insert into instructor (i_id, i_name, job_title, depart) values ('61722-181', 'Chicky Josephoff', 'Electrical Engineer', 'Sales');
insert into instructor (i_id, i_name, job_title, depart) values ('10631-206', 'Bartholomeo Daine', 'Physical Therapy Assistant', 'Accounting');
insert into instructor (i_id, i_name, job_title, depart) values ('60505-0034', 'Welby Hammell', 'Research Associate', 'Business Development');
insert into instructor (i_id, i_name, job_title, depart) values ('48951-2058', 'Ramsay Warnock', 'GIS Technical Architect', 'Product Management');
insert into instructor (i_id, i_name, job_title, depart) values ('24909-161', 'Ardisj Rowland', 'Safety Technician I', 'Engineering');
insert into instructor (i_id, i_name, job_title, depart) values ('33261-797', 'Karil Rymour', 'GIS Technical Architect', 'Product Management');
insert into instructor (i_id, i_name, job_title, depart) values ('0071-0220', 'Seana Arter', 'Legal Assistant', 'Product Management');
insert into instructor (i_id, i_name, job_title, depart) values ('68196-124', 'Joycelin Freddi', 'Media Manager II', 'Research and Development');
insert into instructor (i_id, i_name, job_title, depart) values ('31722-267', 'Sloan Conochie', 'Senior Editor', 'Services');
insert into instructor (i_id, i_name, job_title, depart) values ('64380-726', 'Lemar Koschek', 'Senior Cost Accountant', 'Research and Development');
insert into instructor (i_id, i_name, job_title, depart) values ('60429-307', 'Dolorita Rawcliff', 'Senior Quality Engineer', 'Engineering');
insert into instructor (i_id, i_name, job_title, depart) values ('24488-003', 'Benyamin Esseby', 'Physical Therapy Assistant', 'Marketing');
insert into instructor (i_id, i_name, job_title, depart) values ('37808-897', 'Tanya Mynett', 'Senior Editor', 'Research and Development');
insert into instructor (i_id, i_name, job_title, depart) values ('63323-382', 'Gillie Ead', 'Technical Writer', 'Legal');
insert into instructor (i_id, i_name, job_title, depart) values ('16590-026', 'Benedetto Upstell', 'Quality Engineer', 'Legal');
insert into instructor (i_id, i_name, job_title, depart) values ('21695-615', 'Dedie O''Longain', 'Information Systems Manager', 'Legal');
insert into instructor (i_id, i_name, job_title, depart) values ('57893-300', 'Sheelagh Lethieulier', 'Clinical Specialist', 'Accounting');
insert into instructor (i_id, i_name, job_title, depart) values ('41250-368', 'Nancey Donaldson', 'Dental Hygienist', 'Business Development');
insert into instructor (i_id, i_name, job_title, depart) values ('48951-2045', 'Rollin Lucien', 'Research Nurse', 'Marketing');
insert into instructor (i_id, i_name, job_title, depart) values ('68084-359', 'Emlyn Hugle', 'Research Associate', 'Research and Development');
insert into instructor (i_id, i_name, job_title, depart) values ('39822-1201', 'Melina Fontin', 'Mechanical Systems Engineer', 'Product Management');
insert into instructor (i_id, i_name, job_title, depart) values ('59898-160', 'Clarette Mokes', 'Staff Scientist', 'Research and Development');
insert into instructor (i_id, i_name, job_title, depart) values ('0268-0705', 'Janel Stowe', 'Environmental Specialist', 'Support');
insert into instructor (i_id, i_name, job_title, depart) values ('11673-390', 'Duane Edridge', 'Professor', 'Product Management');
insert into instructor (i_id, i_name, job_title, depart) values ('49404-103', 'Chic Veevers', 'Social Worker', 'Training');
insert into instructor (i_id, i_name, job_title, depart) values ('54868-4474', 'Cherri Staden', 'Senior Developer', 'Engineering');
insert into instructor (i_id, i_name, job_title, depart) values ('36800-205', 'Margie Gini', 'Systems Administrator IV', 'Product Management');
insert into instructor (i_id, i_name, job_title, depart) values ('55154-2367', 'Brook McCaw', 'Data Coordiator', 'Training');
insert into instructor (i_id, i_name, job_title, depart) values ('55154-3226', 'Zebulon Cortin', 'Geologist III', 'Product Management');
insert into instructor (i_id, i_name, job_title, depart) values ('49349-213', 'Nike Tant', 'Staff Scientist', 'Business Development');
insert into instructor (i_id, i_name, job_title, depart) values ('0363-0010', 'Rickey Exell', 'Nurse', 'Training');
insert into instructor (i_id, i_name, job_title, depart) values ('49778-001', 'Chelsey Haffner', 'Senior Quality Engineer', 'Support');
insert into instructor (i_id, i_name, job_title, depart) values ('49035-872', 'Hedda De Lorenzo', 'Staff Scientist', 'Human Resources');
insert into instructor (i_id, i_name, job_title, depart) values ('13537-061', 'Brooks Gillooly', 'Help Desk Operator', 'Training');
insert into instructor (i_id, i_name, job_title, depart) values ('51769-105', 'Pierce Dicty', 'Research Associate', 'Support');
insert into instructor (i_id, i_name, job_title, depart) values ('43857-0309', 'Ki Schurcke', 'Software Test Engineer II', 'Human Resources');
insert into instructor (i_id, i_name, job_title, depart) values ('36987-1401', 'Kirk Chasmoor', 'GIS Technical Architect', 'Engineering');
insert into instructor (i_id, i_name, job_title, depart) values ('42507-829', 'Mollee Tukesby', 'Chemical Engineer', 'Human Resources');
insert into instructor (i_id, i_name, job_title, depart) values ('55289-020', 'Emiline McCarry', 'Environmental Tech', 'Sales');
insert into instructor (i_id, i_name, job_title, depart) values ('24338-656', 'Sarita McCormack', 'Research Assistant III', 'Business Development');
insert into instructor (i_id, i_name, job_title, depart) values ('36800-054', 'Kean Odgers', 'Automation Specialist IV', 'Legal');
insert into instructor (i_id, i_name, job_title, depart) values ('55714-2221', 'Guillermo Hulks', 'Media Manager IV', 'Legal');
insert into instructor (i_id, i_name, job_title, depart) values ('0121-4721', 'Saraann Alloisi', 'Accountant III', 'Business Development');
insert into instructor (i_id, i_name, job_title, depart) values ('63629-1792', 'Lisa Hazart', 'Food Chemist', 'Legal');
insert into instructor (i_id, i_name, job_title, depart) values ('63998-575', 'Cloris Muzzullo', 'Recruiting Manager', 'Accounting');
insert into instructor (i_id, i_name, job_title, depart) values ('50436-6665', 'Judd Gifkins', 'Financial Advisor', 'Support');
insert into instructor (i_id, i_name, job_title, depart) values ('12090-0040', 'Webster Jonke', 'Structural Engineer', 'Research and Development');
insert into instructor (i_id, i_name, job_title, depart) values ('66184-505', 'Dalston Waterstone', 'Internal Auditor', 'Research and Development');
insert into instructor (i_id, i_name, job_title, depart) values ('76237-108', 'Claretta Baudinelli', 'Staff Accountant III', 'Business Development');
insert into instructor (i_id, i_name, job_title, depart) values ('98132-888', 'Salmon Cholerton', 'Project Manager', 'Legal');
insert into instructor (i_id, i_name, job_title, depart) values ('55316-302', 'Fransisco Borne', 'Senior Developer', 'Accounting');
insert into instructor (i_id, i_name, job_title, depart) values ('49035-291', 'Gunar Niave', 'Sales Associate', 'Legal');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/*Create table date for randomly selecting and interting into met_date columne.*/
CREATE TABLE date(
    met_date date);
insert into date (met_date) values ('2020-10-01');
insert into date (met_date) values ('2021-03-29');
insert into date (met_date) values ('2021-04-30');
insert into date (met_date) values ('2021-02-02');
insert into date (met_date) values ('2021-05-20');
insert into date (met_date) values ('2020-07-18');
insert into date (met_date) values ('2020-07-06');
insert into date (met_date) values ('2020-10-28');
insert into date (met_date) values ('2020-08-19');
insert into date (met_date) values ('2021-01-22');
insert into date (met_date) values ('2021-02-08');
insert into date (met_date) values ('2021-01-25');
insert into date (met_date) values ('2020-09-16');
insert into date (met_date) values ('2020-08-08');
insert into date (met_date) values ('2021-07-11');
insert into date (met_date) values ('2021-05-16');
insert into date (met_date) values ('2020-09-19');
insert into date (met_date) values ('2020-11-07');
insert into date (met_date) values ('2021-06-29');
insert into date (met_date) values ('2020-09-20');
insert into date (met_date) values ('2020-11-05');
insert into date (met_date) values ('2020-10-26');
insert into date (met_date) values ('2021-05-04');
insert into date (met_date) values ('2021-06-04');
insert into date (met_date) values ('2021-01-25');
insert into date (met_date) values ('2020-09-17');
insert into date (met_date) values ('2021-04-25');
insert into date (met_date) values ('2021-05-03');
insert into date (met_date) values ('2020-07-07');
insert into date (met_date) values ('2020-07-09');
insert into date (met_date) values ('2021-06-23');
insert into date (met_date) values ('2021-04-21');
insert into date (met_date) values ('2020-10-19');
insert into date (met_date) values ('2020-07-21');
insert into date (met_date) values ('2021-01-24');
insert into date (met_date) values ('2021-06-28');
insert into date (met_date) values ('2020-11-18');
insert into date (met_date) values ('2021-06-25');
insert into date (met_date) values ('2021-02-21');
insert into date (met_date) values ('2021-06-07');
insert into date (met_date) values ('2020-11-05');
insert into date (met_date) values ('2021-06-06');
insert into date (met_date) values ('2020-10-26');
insert into date (met_date) values ('2021-05-28');
insert into date (met_date) values ('2020-10-13');
insert into date (met_date) values ('2021-01-23');
insert into date (met_date) values ('2021-03-03');
insert into date (met_date) values ('2021-01-20');
insert into date (met_date) values ('2021-05-18');
insert into date (met_date) values ('2021-06-26');
insert into date (met_date) values ('2020-11-07');
insert into date (met_date) values ('2021-06-09');
insert into date (met_date) values ('2020-10-07');
insert into date (met_date) values ('2020-11-06');
insert into date (met_date) values ('2021-06-11');
insert into date (met_date) values ('2021-07-27');
insert into date (met_date) values ('2021-06-03');
insert into date (met_date) values ('2020-10-03');
insert into date (met_date) values ('2020-09-22');
insert into date (met_date) values ('2020-09-22');
insert into date (met_date) values ('2020-12-06');
insert into date (met_date) values ('2020-12-06');
insert into date (met_date) values ('2021-05-08');
insert into date (met_date) values ('2021-03-16');
insert into date (met_date) values ('2021-05-30');
insert into date (met_date) values ('2020-11-23');
insert into date (met_date) values ('2021-02-03');
insert into date (met_date) values ('2021-03-07');
insert into date (met_date) values ('2021-03-04');
insert into date (met_date) values ('2021-02-01');
insert into date (met_date) values ('2021-06-21');
insert into date (met_date) values ('2021-01-22');
insert into date (met_date) values ('2020-08-18');
insert into date (met_date) values ('2021-05-02');
insert into date (met_date) values ('2021-06-11');
insert into date (met_date) values ('2021-04-19');
insert into date (met_date) values ('2021-02-13');
insert into date (met_date) values ('2021-03-28');
insert into date (met_date) values ('2020-09-13');
insert into date (met_date) values ('2020-07-01');
insert into date (met_date) values ('2020-09-01');
insert into date (met_date) values ('2021-07-16');
insert into date (met_date) values ('2020-07-10');
insert into date (met_date) values ('2020-10-15');
insert into date (met_date) values ('2020-07-14');
insert into date (met_date) values ('2020-12-21');
insert into date (met_date) values ('2021-01-19');
insert into date (met_date) values ('2020-08-11');
insert into date (met_date) values ('2021-07-03');
insert into date (met_date) values ('2021-06-11');
insert into date (met_date) values ('2020-11-15');
insert into date (met_date) values ('2021-06-15');
insert into date (met_date) values ('2021-05-17');
insert into date (met_date) values ('2020-07-13');
insert into date (met_date) values ('2021-06-22');
insert into date (met_date) values ('2021-05-08');
insert into date (met_date) values ('2021-03-23');
insert into date (met_date) values ('2021-05-31');
insert into date (met_date) values ('2020-09-12');
insert into date (met_date) values ('2021-03-26');
insert into date (met_date) values ('2020-10-27');
insert into date (met_date) values ('2020-09-25');
insert into date (met_date) values ('2020-11-22');
insert into date (met_date) values ('2021-07-04');
insert into date (met_date) values ('2020-11-13');
insert into date (met_date) values ('2021-07-08');
insert into date (met_date) values ('2020-12-07');
insert into date (met_date) values ('2020-11-03');
insert into date (met_date) values ('2020-10-20');
insert into date (met_date) values ('2020-10-01');
insert into date (met_date) values ('2021-01-16');
insert into date (met_date) values ('2021-05-29');
insert into date (met_date) values ('2021-04-25');
insert into date (met_date) values ('2020-11-08');
insert into date (met_date) values ('2021-07-10');
insert into date (met_date) values ('2020-12-29');
insert into date (met_date) values ('2021-05-01');
insert into date (met_date) values ('2021-04-12');
insert into date (met_date) values ('2020-07-17');
insert into date (met_date) values ('2020-12-06');

/*Randomly select instructors, employees and meeting dates. And inset 
1000 rows into table advise.*/
INSERT INTO advise(i_id, e_id, me_date)
SELECT i_id,e_id,met_date FROM instructor, employee, date
ORDER BY random()
LIMIT 1000;

-- Drop temp table date.
DROP TABLE date;