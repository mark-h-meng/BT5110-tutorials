/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* This is a database to store online language modules registration records.
Define entity set E1 to be students, entity set E2 to be modules, 
many-to-many relationship set R to be registrations. 
For table students, it stores fields studentID, student name,
date of birth and email address.
For table modules, it stores fields moduleID, module name, credit unit for each module.
For table registrations, it stores fields studentID and moduleID
to associate each student to language modules they registered.
Code written for following questions is for PostgreSQL.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS students (
studentid VARCHAR (16) PRIMARY KEY,
student_name VARCHAR (64) NOT NULL,
dob DATE NOT NULL,
email VARCHAR(64) UNIQUE NOT NULL);

CREATE TABLE IF NOT EXISTS modules (
moduleid VARCHAR (16) PRIMARY KEY,
module_name VARCHAR (64) NOT NULL,
credit_unit INT NOT NULL);

CREATE TABLE registrations (
studentid VARCHAR(16),
moduleid VARCHAR(16),
FOREIGN KEY (studentid) REFERENCES students(studentid)
	ON UPDATE CASCADE,
FOREIGN KEY (moduleid) REFERENCES modules(moduleid)
	ON UPDATE CASCADE,
PRIMARY KEY(studentid, moduleid));

/*************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into students (studentid, student_name, dob, email) values ('v09555587t', 'Bucky Metzke', '10/30/1938', 'bmetzke0@google.it');
insert into students (studentid, student_name, dob, email) values ('i48155351w', 'Montague Andreev', '08/01/1914', 'mandreev1@java.com');
insert into students (studentid, student_name, dob, email) values ('q61136286h', 'Juan Greetland', '02/19/1992', 'jgreetland2@seattletimes.com');
insert into students (studentid, student_name, dob, email) values ('w45670466z', 'Peta Thunderman', '06/14/1925', 'pthunderman3@51.la');
insert into students (studentid, student_name, dob, email) values ('f02857922y', 'Shaun Trenbey', '11/12/1966', 'strenbey4@ucsd.edu');
insert into students (studentid, student_name, dob, email) values ('i66498152w', 'Pace Hyde-Chambers', '10/14/2002', 'phydechambers5@pinterest.com');
insert into students (studentid, student_name, dob, email) values ('v87714443h', 'Daren Gorges', '01/17/1906', 'dgorges6@hostgator.com');
insert into students (studentid, student_name, dob, email) values ('h92057210z', 'Bart Summerson', '08/15/1984', 'bsummerson7@amazon.co.uk');
insert into students (studentid, student_name, dob, email) values ('q16692166p', 'Casandra Scole', '03/05/1980', 'cscole8@ameblo.jp');
insert into students (studentid, student_name, dob, email) values ('n51663458o', 'Skip Feirn', '07/20/1915', 'sfeirn9@cargocollective.com');
insert into students (studentid, student_name, dob, email) values ('c59589378w', 'Gerick Garner', '01/21/1972', 'ggarnera@cornell.edu');
insert into students (studentid, student_name, dob, email) values ('m82806740g', 'Anetta Sauvan', '12/16/1947', 'asauvanb@vkontakte.ru');
insert into students (studentid, student_name, dob, email) values ('t68694399y', 'Kassandra Kibard', '03/25/1900', 'kkibardc@feedburner.com');
insert into students (studentid, student_name, dob, email) values ('z63841344a', 'Haroun Major', '07/27/2010', 'hmajord@spiegel.de');
insert into students (studentid, student_name, dob, email) values ('p37861008q', 'Beth Rainbird', '11/17/1994', 'brainbirde@yahoo.co.jp');
insert into students (studentid, student_name, dob, email) values ('u81904067g', 'Alejoa Emett', '10/30/1946', 'aemettf@nih.gov');
insert into students (studentid, student_name, dob, email) values ('o84732047q', 'Schuyler Sellner', '02/20/1934', 'ssellnerg@washington.edu');
insert into students (studentid, student_name, dob, email) values ('t55618714r', 'Rici Kilcoyne', '02/27/1998', 'rkilcoyneh@furl.net');
insert into students (studentid, student_name, dob, email) values ('j27318024f', 'Oliviero McElane', '01/10/2020', 'omcelanei@toplist.cz');
insert into students (studentid, student_name, dob, email) values ('y54170225y', 'Gipsy McShirie', '08/17/1924', 'gmcshiriej@oracle.com');
insert into students (studentid, student_name, dob, email) values ('h81481221y', 'Tynan Bishopp', '03/22/2014', 'tbishoppk@abc.net.au');
insert into students (studentid, student_name, dob, email) values ('e24973203l', 'Egbert McGown', '05/24/1948', 'emcgownl@theglobeandmail.com');
insert into students (studentid, student_name, dob, email) values ('v51765905s', 'Hynda Spatarul', '08/20/1970', 'hspatarulm@parallels.com');
insert into students (studentid, student_name, dob, email) values ('d13137464s', 'Rey Lezemere', '03/27/1986', 'rlezemeren@tinyurl.com');
insert into students (studentid, student_name, dob, email) values ('z96290818k', 'Livvie Garment', '09/08/1968', 'lgarmento@friendfeed.com');
insert into students (studentid, student_name, dob, email) values ('w28803355c', 'Carolyn Skingley', '10/19/1908', 'cskingleyp@tinypic.com');
insert into students (studentid, student_name, dob, email) values ('w18248663x', 'Lynnell Pamment', '05/09/1965', 'lpammentq@ca.gov');
insert into students (studentid, student_name, dob, email) values ('f62174133t', 'Gibby Sarra', '05/08/1993', 'gsarrar@engadget.com');
insert into students (studentid, student_name, dob, email) values ('e80274243z', 'Katuscha Hanbury', '08/25/2014', 'khanburys@nasa.gov');
insert into students (studentid, student_name, dob, email) values ('n62122289y', 'Clement Stannislawski', '02/28/1920', 'cstannislawskit@miibeian.gov.cn');
insert into students (studentid, student_name, dob, email) values ('a84148173o', 'Richy Feron', '11/11/1958', 'rferonu@desdev.cn');
insert into students (studentid, student_name, dob, email) values ('b74322086h', 'Hagan Cappel', '10/18/2003', 'hcappelv@wisc.edu');
insert into students (studentid, student_name, dob, email) values ('j74339044b', 'Bryana Siemandl', '10/15/1947', 'bsiemandlw@ftc.gov');
insert into students (studentid, student_name, dob, email) values ('f18567200j', 'Olivero Thomerson', '12/19/1946', 'othomersonx@about.com');
insert into students (studentid, student_name, dob, email) values ('t56951983b', 'Lavinie Rickwood', '10/05/2015', 'lrickwoody@dagondesign.com');
insert into students (studentid, student_name, dob, email) values ('p70211250a', 'Aila MacAlpyne', '01/08/1949', 'amacalpynez@slate.com');
insert into students (studentid, student_name, dob, email) values ('s32899619u', 'Grayce Millan', '05/17/1922', 'gmillan10@mediafire.com');
insert into students (studentid, student_name, dob, email) values ('u99493646j', 'Katuscha Priscott', '12/05/1940', 'kpriscott11@washingtonpost.com');
insert into students (studentid, student_name, dob, email) values ('q24966710k', 'Denny Anstey', '05/10/1961', 'danstey12@google.com.br');
insert into students (studentid, student_name, dob, email) values ('g01294289v', 'Whitman Mackneis', '06/27/1981', 'wmackneis13@list-manage.com');
insert into students (studentid, student_name, dob, email) values ('m72298461n', 'Illa Frentz', '06/07/2018', 'ifrentz14@ning.com');
insert into students (studentid, student_name, dob, email) values ('a68054181w', 'Wrennie Dodgshun', '08/01/1928', 'wdodgshun15@cbc.ca');
insert into students (studentid, student_name, dob, email) values ('n09295994o', 'Townsend Challoner', '09/24/1932', 'tchalloner16@nps.gov');
insert into students (studentid, student_name, dob, email) values ('e98972464h', 'Bren Jukubczak', '05/12/2020', 'bjukubczak17@elpais.com');
insert into students (studentid, student_name, dob, email) values ('k33270332o', 'Eugenius Poker', '10/04/1911', 'epoker18@vinaora.com');
insert into students (studentid, student_name, dob, email) values ('d45430810r', 'Sonya Matusovsky', '06/07/1948', 'smatusovsky19@ed.gov');
insert into students (studentid, student_name, dob, email) values ('s23125832z', 'Tiffani Jurewicz', '07/25/1931', 'tjurewicz1a@vk.com');
insert into students (studentid, student_name, dob, email) values ('e02992775n', 'Bernadine Newlyn', '03/28/1973', 'bnewlyn1b@reference.com');
insert into students (studentid, student_name, dob, email) values ('e98262595v', 'Janene Crookshanks', '07/10/1906', 'jcrookshanks1c@hc360.com');
insert into students (studentid, student_name, dob, email) values ('r42869904z', 'Lyon Woods', '03/23/1999', 'lwoods1d@ameblo.jp');
insert into students (studentid, student_name, dob, email) values ('o71173326j', 'Gonzalo Vinsen', '12/26/1985', 'gvinsen1e@dmoz.org');
insert into students (studentid, student_name, dob, email) values ('z93075672l', 'Cleavland Battyll', '08/31/2008', 'cbattyll1f@taobao.com');
insert into students (studentid, student_name, dob, email) values ('r25538653m', 'Sharon Crowter', '05/06/1906', 'scrowter1g@businessweek.com');
insert into students (studentid, student_name, dob, email) values ('h13951510v', 'Grete Wadmore', '09/23/1978', 'gwadmore1h@mail.ru');
insert into students (studentid, student_name, dob, email) values ('k63602964n', 'Merry Baxstar', '05/23/2012', 'mbaxstar1i@abc.net.au');
insert into students (studentid, student_name, dob, email) values ('b48682429y', 'Auroora Bransden', '06/29/1916', 'abransden1j@si.edu');
insert into students (studentid, student_name, dob, email) values ('y68943445s', 'Stafford Hollindale', '11/13/1942', 'shollindale1k@unblog.fr');
insert into students (studentid, student_name, dob, email) values ('x85943430i', 'Ingrim Akess', '09/16/1907', 'iakess1l@columbia.edu');
insert into students (studentid, student_name, dob, email) values ('k14932792p', 'Tracey Daenen', '11/10/2004', 'tdaenen1m@abc.net.au');
insert into students (studentid, student_name, dob, email) values ('h28050636e', 'Maddi Menham', '10/22/1972', 'mmenham1n@de.vu');
insert into students (studentid, student_name, dob, email) values ('s28723537q', 'Arny Clinnick', '06/09/2019', 'aclinnick1o@sbwire.com');
insert into students (studentid, student_name, dob, email) values ('f65805457z', 'Melva Rosling', '09/04/2009', 'mrosling1p@g.co');
insert into students (studentid, student_name, dob, email) values ('d62966497u', 'Lola Yitzowitz', '11/27/1944', 'lyitzowitz1q@house.gov');
insert into students (studentid, student_name, dob, email) values ('c73406880w', 'Padraic Camerana', '09/16/1914', 'pcamerana1r@sciencedaily.com');
insert into students (studentid, student_name, dob, email) values ('c18778840n', 'Marylynne Jeanequin', '09/06/2016', 'mjeanequin1s@google.com.hk');
insert into students (studentid, student_name, dob, email) values ('w00754601w', 'Davide Ogglebie', '08/30/2008', 'dogglebie1t@arstechnica.com');
insert into students (studentid, student_name, dob, email) values ('l08119503l', 'Rhea Paulin', '08/13/1993', 'rpaulin1u@sciencedirect.com');
insert into students (studentid, student_name, dob, email) values ('c11191676t', 'Whitby Hanssmann', '10/19/1969', 'whanssmann1v@blogs.com');
insert into students (studentid, student_name, dob, email) values ('i94907900n', 'Dru Warin', '02/27/1982', 'dwarin1w@miitbeian.gov.cn');
insert into students (studentid, student_name, dob, email) values ('j19020304l', 'Jethro Al Hirsi', '02/28/1976', 'jal1x@g.co');
insert into students (studentid, student_name, dob, email) values ('f06417287b', 'Forester Kennicott', '12/04/1952', 'fkennicott1y@google.de');
insert into students (studentid, student_name, dob, email) values ('r03603537t', 'Lonee Guirardin', '06/08/1916', 'lguirardin1z@ow.ly');
insert into students (studentid, student_name, dob, email) values ('g17881488g', 'Delia Broxis', '04/22/1954', 'dbroxis20@163.com');
insert into students (studentid, student_name, dob, email) values ('x04104364h', 'Bel Vidgen', '02/11/2012', 'bvidgen21@rediff.com');
insert into students (studentid, student_name, dob, email) values ('z26069242j', 'Benni McCleverty', '04/27/1976', 'bmccleverty22@nasa.gov');
insert into students (studentid, student_name, dob, email) values ('p42371475w', 'Deerdre Kubatsch', '01/17/1950', 'dkubatsch23@sakura.ne.jp');
insert into students (studentid, student_name, dob, email) values ('x95110924b', 'Vivie Najera', '04/22/1908', 'vnajera24@technorati.com');
insert into students (studentid, student_name, dob, email) values ('l38201979e', 'Carolynn Wallice', '08/10/1979', 'cwallice25@creativecommons.org');
insert into students (studentid, student_name, dob, email) values ('r74675263b', 'Derry Brigge', '09/02/1925', 'dbrigge26@about.me');
insert into students (studentid, student_name, dob, email) values ('w46711773j', 'Debby Watsham', '11/14/1928', 'dwatsham27@facebook.com');
insert into students (studentid, student_name, dob, email) values ('t83637233l', 'Rosaline Richemond', '10/09/1941', 'rrichemond28@youtu.be');
insert into students (studentid, student_name, dob, email) values ('n24323779c', 'Wylie MacKomb', '03/11/1905', 'wmackomb29@mapquest.com');
insert into students (studentid, student_name, dob, email) values ('k92494740l', 'Ingrim Pinckstone', '11/30/1931', 'ipinckstone2a@webnode.com');
insert into students (studentid, student_name, dob, email) values ('y57718306i', 'Arliene Uc', '10/23/1927', 'auc2b@dedecms.com');
insert into students (studentid, student_name, dob, email) values ('n99706759r', 'Avictor Cleeton', '06/19/1928', 'acleeton2c@e-recht24.de');
insert into students (studentid, student_name, dob, email) values ('a78873832n', 'Marylynne Nickoll', '01/15/1996', 'mnickoll2d@trellian.com');
insert into students (studentid, student_name, dob, email) values ('a06940033z', 'Jolynn Dealy', '04/22/2018', 'jdealy2e@go.com');
insert into students (studentid, student_name, dob, email) values ('q58070094a', 'Chico Girardin', '01/14/1931', 'cgirardin2f@behance.net');
insert into students (studentid, student_name, dob, email) values ('w91890942l', 'Kai Maxfield', '05/27/2001', 'kmaxfield2g@slate.com');
insert into students (studentid, student_name, dob, email) values ('e63635353r', 'Leroy Seville', '06/03/1984', 'lseville2h@deliciousdays.com');
insert into students (studentid, student_name, dob, email) values ('i97463477c', 'Leola Chilcott', '02/26/1978', 'lchilcott2i@msu.edu');
insert into students (studentid, student_name, dob, email) values ('y93373306g', 'Conni Esser', '08/08/2000', 'cesser2j@loc.gov');
insert into students (studentid, student_name, dob, email) values ('f98121447q', 'Nowell Learie', '03/16/2014', 'nlearie2k@simplemachines.org');
insert into students (studentid, student_name, dob, email) values ('z97253450g', 'Aland Harding', '02/02/1959', 'aharding2l@digg.com');
insert into students (studentid, student_name, dob, email) values ('b99068646w', 'Tommy McAlarney', '04/03/1917', 'tmcalarney2m@nymag.com');
insert into students (studentid, student_name, dob, email) values ('c44497974f', 'Martita Redshaw', '03/21/1961', 'mredshaw2n@dion.ne.jp');
insert into students (studentid, student_name, dob, email) values ('v28517127x', 'Carl Cockhill', '02/13/1941', 'ccockhill2o@mediafire.com');
insert into students (studentid, student_name, dob, email) values ('n57589248h', 'Hildagarde Barkworth', '08/24/1913', 'hbarkworth2p@dropbox.com');
insert into students (studentid, student_name, dob, email) values ('u64179452z', 'Sabine Aisman', '07/20/1969', 'saisman2q@adobe.com');
insert into students (studentid, student_name, dob, email) values ('b83560379q', 'Lenee Cicculi', '01/01/1943', 'lcicculi2r@telegraph.co.uk');

insert into modules (moduleid, module_name, credit_unit) values ('qx2528', 'West Frisian', 4);
insert into modules (moduleid, module_name, credit_unit) values ('qb3588', 'Belarusian', 4);
insert into modules (moduleid, module_name, credit_unit) values ('ho1504', 'Estonian', 2);
insert into modules (moduleid, module_name, credit_unit) values ('yu8339', 'Kashmiri', 6);
insert into modules (moduleid, module_name, credit_unit) values ('cx1021', 'Haitian Creole', 3);
insert into modules (moduleid, module_name, credit_unit) values ('jk8650', 'Punjabi', 4);
insert into modules (moduleid, module_name, credit_unit) values ('te9813', 'Montenegrin', 6);
insert into modules (moduleid, module_name, credit_unit) values ('gr7047', 'Tajik', 3);
insert into modules (moduleid, module_name, credit_unit) values ('lt3515', 'Ndebele', 6);
insert into modules (moduleid, module_name, credit_unit) values ('sl0918', 'Icelandic', 5);
insert into modules (moduleid, module_name, credit_unit) values ('kh4799', 'Moldovan', 2);
insert into modules (moduleid, module_name, credit_unit) values ('iw1246', 'Korean', 4);
insert into modules (moduleid, module_name, credit_unit) values ('mv4988', 'Italian', 5);
insert into modules (moduleid, module_name, credit_unit) values ('eu1399', 'Catalan', 5);
insert into modules (moduleid, module_name, credit_unit) values ('wq6885', 'Papiamento', 6);
insert into modules (moduleid, module_name, credit_unit) values ('de3683', 'Malayalam', 5);
insert into modules (moduleid, module_name, credit_unit) values ('sh4269', 'Zulu', 2);
insert into modules (moduleid, module_name, credit_unit) values ('zv4095', 'Gagauz', 4);
insert into modules (moduleid, module_name, credit_unit) values ('us3785', 'Dari', 4);
insert into modules (moduleid, module_name, credit_unit) values ('uz0327', 'Dutch', 3);
insert into modules (moduleid, module_name, credit_unit) values ('id6574', 'Oriya', 2);
insert into modules (moduleid, module_name, credit_unit) values ('os0929', 'New Zealand Sign Language', 5);
insert into modules (moduleid, module_name, credit_unit) values ('nk2904', 'Macedonian', 6);
insert into modules (moduleid, module_name, credit_unit) values ('jf1737', 'Bislama', 4);
insert into modules (moduleid, module_name, credit_unit) values ('zc0728', 'Belarusian', 2);
insert into modules (moduleid, module_name, credit_unit) values ('mc6769', 'Kannada', 2);
insert into modules (moduleid, module_name, credit_unit) values ('ch8966', 'Lao', 5);
insert into modules (moduleid, module_name, credit_unit) values ('mo1853', 'Northern Sotho', 2);
insert into modules (moduleid, module_name, credit_unit) values ('sm4098', 'Kashmiri', 4);
insert into modules (moduleid, module_name, credit_unit) values ('yd3462', 'Aymara', 2);
insert into modules (moduleid, module_name, credit_unit) values ('xx0816', 'Portuguese', 6);
insert into modules (moduleid, module_name, credit_unit) values ('wi5847', 'New Zealand Sign Language', 6);
insert into modules (moduleid, module_name, credit_unit) values ('zn8608', 'Haitian Creole', 2);
insert into modules (moduleid, module_name, credit_unit) values ('el3666', 'Malay', 6);
insert into modules (moduleid, module_name, credit_unit) values ('mc0863', 'Luxembourgish', 5);
insert into modules (moduleid, module_name, credit_unit) values ('xk6613', 'Amharic', 3);
insert into modules (moduleid, module_name, credit_unit) values ('ub7840', 'Korean', 3);
insert into modules (moduleid, module_name, credit_unit) values ('fi2339', 'Catalan', 4);
insert into modules (moduleid, module_name, credit_unit) values ('sb7496', 'Tswana', 3);
insert into modules (moduleid, module_name, credit_unit) values ('xo1929', 'Nepali', 2);
insert into modules (moduleid, module_name, credit_unit) values ('ag9679', 'Albanian', 2);
insert into modules (moduleid, module_name, credit_unit) values ('kz8612', 'Papiamento', 2);
insert into modules (moduleid, module_name, credit_unit) values ('jm0806', 'Northern Sotho', 5);
insert into modules (moduleid, module_name, credit_unit) values ('ps1147', 'Irish Gaelic', 4);
insert into modules (moduleid, module_name, credit_unit) values ('pr1995', 'Dari', 5);
insert into modules (moduleid, module_name, credit_unit) values ('fq2837', 'Assamese', 2);
insert into modules (moduleid, module_name, credit_unit) values ('vr9875', 'Montenegrin', 5);
insert into modules (moduleid, module_name, credit_unit) values ('tf0165', 'Swahili', 6);
insert into modules (moduleid, module_name, credit_unit) values ('ws2028', 'Malay', 6);
insert into modules (moduleid, module_name, credit_unit) values ('vx5778', 'Dari', 5);
insert into modules (moduleid, module_name, credit_unit) values ('oj4570', 'Spanish', 2);
insert into modules (moduleid, module_name, credit_unit) values ('rm7639', 'Georgian', 4);
insert into modules (moduleid, module_name, credit_unit) values ('nu1465', 'Italian', 3);
insert into modules (moduleid, module_name, credit_unit) values ('el5299', 'Catalan', 3);
insert into modules (moduleid, module_name, credit_unit) values ('iv3095', 'Catalan', 3);
insert into modules (moduleid, module_name, credit_unit) values ('at5974', 'Polish', 5);
insert into modules (moduleid, module_name, credit_unit) values ('ou2407', 'Korean', 5);
insert into modules (moduleid, module_name, credit_unit) values ('nb8892', 'Croatian', 2);
insert into modules (moduleid, module_name, credit_unit) values ('dj6030', 'Somali', 4);
insert into modules (moduleid, module_name, credit_unit) values ('rv5783', 'Armenian', 2);
insert into modules (moduleid, module_name, credit_unit) values ('fk0602', 'Chinese', 5);
insert into modules (moduleid, module_name, credit_unit) values ('if4680', 'Sotho', 6);
insert into modules (moduleid, module_name, credit_unit) values ('ax2930', 'Indonesian', 2);
insert into modules (moduleid, module_name, credit_unit) values ('fr2993', 'New Zealand Sign Language', 6);
insert into modules (moduleid, module_name, credit_unit) values ('oy7871', 'Thai', 3);
insert into modules (moduleid, module_name, credit_unit) values ('cs1052', 'Afrikaans', 4);
insert into modules (moduleid, module_name, credit_unit) values ('wm0054', 'Hungarian', 3);
insert into modules (moduleid, module_name, credit_unit) values ('yv4129', 'Bengali', 3);
insert into modules (moduleid, module_name, credit_unit) values ('py3854', 'Belarusian', 5);
insert into modules (moduleid, module_name, credit_unit) values ('co4924', 'Khmer', 6);
insert into modules (moduleid, module_name, credit_unit) values ('zx7684', 'Assamese', 5);
insert into modules (moduleid, module_name, credit_unit) values ('dz3365', 'Dari', 4);
insert into modules (moduleid, module_name, credit_unit) values ('cr2500', 'Portuguese', 6);
insert into modules (moduleid, module_name, credit_unit) values ('gn8936', 'German', 4);
insert into modules (moduleid, module_name, credit_unit) values ('qa8260', 'Catalan', 4);
insert into modules (moduleid, module_name, credit_unit) values ('zk1186', 'Icelandic', 5);
insert into modules (moduleid, module_name, credit_unit) values ('wj1615', 'Papiamento', 2);
insert into modules (moduleid, module_name, credit_unit) values ('eb8368', 'Bengali', 3);
insert into modules (moduleid, module_name, credit_unit) values ('wa6833', 'Quechua', 6);
insert into modules (moduleid, module_name, credit_unit) values ('am6226', 'Estonian', 6);
insert into modules (moduleid, module_name, credit_unit) values ('gf4138', 'Punjabi', 3);
insert into modules (moduleid, module_name, credit_unit) values ('pu1039', 'Somali', 6);
insert into modules (moduleid, module_name, credit_unit) values ('jd8766', 'Māori', 6);
insert into modules (moduleid, module_name, credit_unit) values ('df3880', 'Malagasy', 6);
insert into modules (moduleid, module_name, credit_unit) values ('zn6632', 'Malay', 2);
insert into modules (moduleid, module_name, credit_unit) values ('tv3652', 'Albanian', 5);
insert into modules (moduleid, module_name, credit_unit) values ('jw2339', 'Bosnian', 6);
insert into modules (moduleid, module_name, credit_unit) values ('wk0687', 'Indonesian', 6);
insert into modules (moduleid, module_name, credit_unit) values ('ez2558', 'Punjabi', 4);
insert into modules (moduleid, module_name, credit_unit) values ('ka4127', 'Hindi', 3);
insert into modules (moduleid, module_name, credit_unit) values ('eq4434', 'Lithuanian', 5);
insert into modules (moduleid, module_name, credit_unit) values ('nm0532', 'Lithuanian', 2);
insert into modules (moduleid, module_name, credit_unit) values ('we7734', 'Kurdish', 6);
insert into modules (moduleid, module_name, credit_unit) values ('rb8535', 'Kashmiri', 6);
insert into modules (moduleid, module_name, credit_unit) values ('rm9844', 'Portuguese', 3);
insert into modules (moduleid, module_name, credit_unit) values ('km3520', 'Punjabi', 5);
insert into modules (moduleid, module_name, credit_unit) values ('gu1352', 'Bulgarian', 4);
insert into modules (moduleid, module_name, credit_unit) values ('ue4923', 'Arabic', 4);
insert into modules (moduleid, module_name, credit_unit) values ('rj2391', 'Gujarati', 4);
insert into modules (moduleid, module_name, credit_unit) values ('nq3615', 'Portuguese', 6);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO registrations
SELECT c.studentid, m.moduleid
from students c CROSS JOIN modules m
ORDER BY random() <= 0.1
LIMIT 1000;


