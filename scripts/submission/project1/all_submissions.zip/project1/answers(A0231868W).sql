/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for SQLite */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
First of all, the following codes are written for SQLite.

Introduction:
Suppose that in the near future, a global basketball league has been established
around the world. Players from all countries can join basketball clubs all over
the world and then participate in basketball games.

An important part of this event is the university student player draft, that is,
university rookies from all over the world participate in the player draft,so as
to join basketball clubs all over the world.

Based on this background, we assume E1 is the rookie table(named draft_rookies),
which contains the name, age, nationality, university, height and weight of 100 rookies;
Suppose E2 is the club table(named draft_clubs), including the name of 100 draft clubs
and their countries and cities;
Suppose R is the contract table(named contracts), indicating which club(s) each rookie
received a contract from, including the name of the rookie and the interested club.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS draft_rookies (
	rookie_id INT,
	name VARCHAR(50) PRIMARY KEY,
	age INT NOT NULL,
	nationality VARCHAR(50) NOT NULL,
	university VARCHAR(50) NOT NULL,
	height_cm INT NOT NULL,
	weight_kg DECIMAL(4,1) NOT NULL
);

CREATE TABLE IF NOT EXISTS draft_clubs (
	club_id INT,
	club_name VARCHAR(50) PRIMARY KEY,
	country VARCHAR(50) NOT NULL,
	city VARCHAR(50) NOT NULL
);

CREATE TABLE contracts (
  rookie_name VARCHAR(50) REFERENCES draft_rookies(name)
    ON UPDATE CASCADE
		ON DELETE CASCADE
    DEFERRABLE INITIALLY DEFERRED,
  club_name VARCHAR(50) REFERENCES draft_clubs(club_name)
    ON UPDATE CASCADE
		ON DELETE CASCADE
    DEFERRABLE INITIALLY DEFERRED,
  PRIMARY KEY (rookie_name, club_name)
);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (1, 'Shanna Nealey', 18, 'Sweden', 'Kalmar University College', 228, 125.9);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (2, 'Nikaniki Pearton', 22, 'Vietnam', 'Vietnam National University Hanoi', 198, 149.7);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (3, 'Abagail Gavaran', 23, 'Finland', 'University of Jyväskylä', 225, 64.0);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (4, 'Ward Bortolozzi', 25, 'Hong Kong', 'Hong Kong University of Science and Technology', 183, 102.7);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (5, 'Patty McKelloch', 25, 'Indonesia', 'Politeknik Negeri Padang', 209, 147.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (6, 'Andre Straun', 18, 'Indonesia', 'Universitas Negeri Makassar', 210, 122.7);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (7, 'Lenora McTrustey', 22, 'China', 'Guangxi University for Nationalities', 225, 82.0);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (8, 'Halley Duchatel', 21, 'Poland', 'French Institute of Management', 182, 90.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (9, 'Enriqueta Kurten', 19, 'Comoros', 'Universitas Cenderawasih', 202, 117.6);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (10, 'Shanna Murthwaite', 21, 'China', 'Beijing University of Aeronautics and Astronautics', 185, 83.8);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (11, 'Findlay Stood', 25, 'Indonesia', 'Universitas Tunas Pembangunan', 223, 89.3);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (12, 'Anetta Reast', 18, 'Luxembourg', 'University of Luxemburg', 202, 135.4);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (13, 'Lief Blasl', 22, 'China', 'Renmin University of China', 180, 85.8);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (14, 'Amargo Childers', 21, 'Philippines', 'Our Lady of Fatima University', 186, 119.9);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (15, 'Roxana Iacoviello', 18, 'Egypt', 'Kafr El-Sheikh University', 207, 140.7);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (16, 'Ania Shellcross', 18, 'Brazil', 'Universidade de Alfenas', 204, 111.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (17, 'Christel Barents', 21, 'New Zealand', 'University of Otago', 189, 72.6);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (18, 'Darbie Colin', 21, 'Indonesia', 'Universitas Sarjanawiyata Tamansiswa', 189, 149.9);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (19, 'Elyn Penhaligon', 19, 'Bulgaria', 'University of Forestry Sofia', 200, 140.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (20, 'Esmeralda Jobbings', 18, 'Mexico', 'Universidad del Noroeste', 202, 76.5);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (21, 'Morey Shepherdson', 19, 'Spain', 'Universidad Internacional de Andalucía, Sede Antonio Machado de Baeza', 205, 81.8);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (22, 'Miller Hatzar', 22, 'Portugal', 'Instituto Superior de Saúde do Alto Ave', 198, 98.9);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (23, 'Mellie Bointon', 24, 'Russia', 'Gnesins Russian Academy of Music', 208, 143.3);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (24, 'Chen McConnell', 24, 'China', 'Northeast University at Qinhuangdao Campus', 191, 83.6);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (25, 'Desmond Beckenham', 21, 'Kenya', 'Multimedia University of Kenya', 208, 69.0);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (26, 'Welch Innwood', 24, 'Brazil', 'Universidade Vale do Rio Doce', 212, 67.6);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (27, 'Casandra Dennis', 20, 'Portugal', 'Escola Nautica Infante D. Henrique', 214, 100.0);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (28, 'Meagan Mahaddie', 24, 'France', 'Institut Supérieur d''Agriculture Lille', 208, 75.3);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (29, 'Sinclair Puckett', 23, 'Poland', 'Technical University of Kielce', 216, 64.5);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (30, 'Aubrie Diable', 23, 'China', 'Huizhou University', 222, 99.6);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (31, 'Sabra McGrey', 25, 'Poland', 'Medical Academy in Lublin', 225, 102.6);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (32, 'Yasmeen Hatwells', 25, 'China', 'Hebei University of Science and Technology', 225, 90.7);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (33, 'Prince Falck', 18, 'United States', 'Millersville University of Pennsylvania', 216, 86.1);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (34, 'Ad Yanez', 22, 'China', 'Shanghai University of Science and Technology', 211, 123.3);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (35, 'Debi Slixby', 25, 'Philippines', 'Far Eastern University', 181, 135.7);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (36, 'Adelice Ockwell', 18, 'Indonesia', 'Institut Teknologi Bandung', 205, 119.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (37, 'Horacio Clarey', 18, 'Greece', 'Ionian University Corfu', 226, 65.5);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (38, 'Fania Covet', 19, 'Greece', 'Technological Education Institute of Athens', 218, 126.8);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (39, 'Myrlene Ivanchov', 18, 'Russia', 'Moscow International Higher Business School (MIRBIS)', 224, 80.8);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (40, 'Clint Sivill', 19, 'Belgium', 'Katholieke Hogeschool Leuven', 186, 126.1);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (41, 'Ronald Sewter', 24, 'China', 'Yangzhou University', 228, 95.6);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (42, 'Even McArley', 22, 'United States', 'Westwood College', 202, 121.3);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (43, 'Isa Gelderd', 22, 'Philippines', 'Adamson University', 217, 70.0);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (44, 'Bendicty Lamputt', 21, 'Madagascar', 'Université de Fianarantsoa', 205, 148.7);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (45, 'Yuri Rubica', 22, 'Argentina', 'Universidad Católica de Santiago del Estero', 207, 129.8);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (46, 'Lin Dimitru', 24, 'Uganda', 'Central Buganda University', 217, 113.8);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (47, 'Phoebe Wadge', 20, 'China', 'Beijing University of Posts and Telecommunications', 225, 66.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (48, 'Nikki Hazle', 20, 'Brazil', 'Universidade Federal do Amapá', 188, 97.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (49, 'Alika Eddoes', 18, 'China', 'Zhejiang University', 219, 104.9);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (50, 'Fleurette Fink', 24, 'Ghana', 'Presbyterian University College', 223, 148.3);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (51, 'Abbi Isham', 23, 'Malaysia', 'Shahputra College', 220, 88.4);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (52, 'Camey Elphick', 22, 'Nigeria', 'Polytechnic Ibadan', 187, 126.0);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (53, 'Goran Chaplin', 18, 'Russia', 'Tyumen State University of Gas and Oil', 198, 120.6);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (54, 'Markus Duigenan', 21, 'Bulgaria', 'Agricultural University of Plovdiv', 187, 69.8);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (55, 'Vassily Kyrkeman', 18, 'Afghanistan', 'Faryab Higher Education Institute', 196, 149.5);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (56, 'Becka Hales', 25, 'France', 'Université Henri Poincaré (Nancy I)', 199, 143.9);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (57, 'Bunni Bonsall', 25, 'Russia', 'Marij State Technical University', 220, 118.7);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (58, 'Mile Semorad', 18, 'China', 'Chongqing Normal University Foreign Trade and Business College', 214, 74.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (59, 'Tabitha Strongitharm', 21, 'Nigeria', 'Joseph Ayo Babalola University', 204, 95.8);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (60, 'Dorie Maskell', 20, 'Jordan', 'Irbid National University', 189, 70.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (61, 'Claudette Stovin', 19, 'Thailand', 'Payap University Chaiang Mai', 192, 148.9);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (62, 'Malvina Gouldstone', 21, 'Finland', 'Academy of Fine Arts', 184, 114.4);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (63, 'Angy Hegarty', 20, 'Indonesia', 'Universitas Lancang Kuning', 203, 97.6);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (64, 'Berny Tuffin', 21, 'Poland', 'Technical University of Opole', 191, 147.3);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (65, 'Andreas Pybworth', 21, 'Thailand', 'Lampang College of Commerce and Technology', 215, 126.3);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (66, 'Levon Innocent', 21, 'Ukraine', 'State Pedagogical University in Kryvyi Rih', 218, 104.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (67, 'Valina Stickels', 18, 'Russia', 'Omsk State University', 199, 75.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (68, 'Caron Breffit', 21, 'Armenia', 'Eurasia International University', 199, 92.3);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (69, 'Cassaundra Pindell', 25, 'Kazakhstan', 'Kostanai State University', 218, 128.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (70, 'Leanora Menham', 18, 'China', 'Ningbo University of Technology', 228, 114.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (71, 'Edgar MacKereth', 22, 'Macedonia', 'University for Information Science and Technology  "St. Paul The Apostle" ', 212, 116.8);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (72, 'Corliss Laurens', 23, 'Brazil', 'Universidade Estadual de Maringá', 206, 97.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (73, 'Carmella Littler', 21, 'Honduras', 'Universidad Tecnológica de Honduras', 192, 124.0);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (74, 'Rodolfo Stockle', 18, 'Brazil', 'Universidade Ibirapuera', 225, 68.9);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (75, 'Jammie Leming', 18, 'Indonesia', 'Universitas Proklamasi 45', 199, 121.8);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (76, 'Taite Kays', 25, 'Isle of Man', 'Universitas Pembangunan Nasional "Veteran" East Java', 186, 147.5);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (77, 'Kaylyn Norway', 21, 'Guatemala', 'Universidad Rafael Landívar', 221, 78.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (78, 'Theresa Lynds', 23, 'Portugal', 'Universidade Autónoma de Lisboa Luís de Camoes', 208, 115.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (79, 'Dorice Newson', 21, 'Cuba', 'Universidad Pedagógica "José Martí", Camagüey', 223, 146.5);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (80, 'Christiano Euston', 21, 'Ukraine', 'Dneprodzerzhinsk State Technical University', 193, 94.8);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (81, 'Saloma Gerant', 21, 'Tanzania', 'Kilimanjaro Christian Medical College', 196, 125.0);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (82, 'Milt Boote', 20, 'Indonesia', 'Universitas Mataram', 206, 93.9);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (83, 'Denna Meus', 20, 'Japan', 'Hirosaki University', 202, 103.0);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (84, 'Ronnie Vidineev', 21, 'Poland', 'Academy of Humanities and Economics in Lodz', 198, 127.8);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (85, 'Wilek Pedrollo', 22, 'Finland', 'Satakunta University Of Applied Scinces', 181, 95.6);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (86, 'Burty Lepope', 19, 'China', 'Harbin Institute of Technology', 187, 106.3);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (87, 'Lissa Andriveaux', 25, 'United States', 'Maine College of Art', 204, 99.8);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (88, 'Johny Weinham', 22, 'Sweden', 'Mälardalen University', 185, 148.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (89, 'Jill Spain', 20, 'Jamaica', 'University of the West Indies, Mona', 195, 87.4);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (90, 'Fabio Whitlow', 21, 'China', 'Jiangxi University of Finance and Economics', 202, 66.1);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (91, 'Sibeal Mangin', 23, 'China', 'Shaanxi Normal University', 208, 92.6);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (92, 'Terencio Skeene', 23, 'Indonesia', 'Universitas Muhammadiyah Makassar', 205, 124.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (93, 'Rickey Caughte', 25, 'Argentina', 'Universidad Nacional de General Sarmiento', 193, 136.5);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (94, 'Suzanna Farlowe', 22, 'Russia', 'Belgorod State University', 202, 83.1);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (95, 'Hewie Harman', 19, 'China', 'China University of Mining Technology - Xuzhou', 188, 87.5);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (96, 'Hedvig Wreakes', 18, 'Gabon', 'Université Omar Bongo', 183, 64.5);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (97, 'Janetta Fomichkin', 20, 'China', 'China youth college for political science', 222, 96.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (98, 'Hastings Alyonov', 23, 'Peru', 'Universidad Nacional de Piura', 200, 114.2);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (99, 'Carmina Dugall', 23, 'Armenia', 'Yerevan Haibusak University', 216, 116.3);
insert into draft_rookies (rookie_id, name, age, nationality, university, height_cm, weight_kg) values (100, 'Mathew Byneth', 22, 'Austria', 'Universität für Musik und darstellende Kunst  Wien', 224, 136.4);


  insert into draft_clubs (club_id, club_name, country, city) values (1, 'Batz-Tromp', 'Poland', 'Frydrychowice');
  insert into draft_clubs (club_id, club_name, country, city) values (2, 'Dooley, Klein and Mosciski', 'Portugal', 'Aldeia de Além');
  insert into draft_clubs (club_id, club_name, country, city) values (3, 'Schmeler-Rath', 'Russia', 'Voloshka');
  insert into draft_clubs (club_id, club_name, country, city) values (4, 'Padberg-Stoltenberg', 'New Zealand', 'Brooklyn');
  insert into draft_clubs (club_id, club_name, country, city) values (5, 'Russel and Sons', 'Portugal', 'Parada de Pinhão');
  insert into draft_clubs (club_id, club_name, country, city) values (6, 'Lind Inc', 'Belarus', 'Brahin');
  insert into draft_clubs (club_id, club_name, country, city) values (7, 'Botsford, Paucek and Balistreri', 'Portugal', 'Aroeira');
  insert into draft_clubs (club_id, club_name, country, city) values (8, 'Kub, Upton and Stroman', 'Indonesia', 'Lebak');
  insert into draft_clubs (club_id, club_name, country, city) values (9, 'Barton Inc', 'Greece', 'Empório');
  insert into draft_clubs (club_id, club_name, country, city) values (10, 'Walker-Wolf', 'Albania', 'Gjoçaj');
  insert into draft_clubs (club_id, club_name, country, city) values (11, 'Lueilwitz-Trantow', 'Sweden', 'Johanneshov');
  insert into draft_clubs (club_id, club_name, country, city) values (12, 'Wolff-Huels', 'China', 'Pendiqing');
  insert into draft_clubs (club_id, club_name, country, city) values (13, 'Breitenberg-Shanahan', 'China', 'Hedian');
  insert into draft_clubs (club_id, club_name, country, city) values (14, 'Orn Inc', 'Argentina', 'Jesús María');
  insert into draft_clubs (club_id, club_name, country, city) values (15, 'Langosh-Lesch', 'Russia', 'Neftegorsk');
  insert into draft_clubs (club_id, club_name, country, city) values (16, 'Mayert-Leffler', 'United States', 'Houston');
  insert into draft_clubs (club_id, club_name, country, city) values (17, 'Murazik Inc', 'China', 'Gar');
  insert into draft_clubs (club_id, club_name, country, city) values (18, 'Parisian, Hirthe and Douglas', 'Gabon', 'Lékoni');
  insert into draft_clubs (club_id, club_name, country, city) values (19, 'Wolff-Fay', 'Canada', 'Mercier');
  insert into draft_clubs (club_id, club_name, country, city) values (20, 'Cartwright-Lesch', 'Sweden', 'Solna');
  insert into draft_clubs (club_id, club_name, country, city) values (21, 'Ledner-Hudson', 'Azerbaijan', 'Shamkhor');
  insert into draft_clubs (club_id, club_name, country, city) values (22, 'Stiedemann, Mante and Lowe', 'Sweden', 'Göteborg');
  insert into draft_clubs (club_id, club_name, country, city) values (23, 'O''Kon-Mayer', 'Indonesia', 'Pakuwon');
  insert into draft_clubs (club_id, club_name, country, city) values (24, 'Weber, Tromp and Feest', 'China', 'Bayan Huxu');
  insert into draft_clubs (club_id, club_name, country, city) values (25, 'Hodkiewicz-Kerluke', 'Russia', 'Pyatovskiy');
  insert into draft_clubs (club_id, club_name, country, city) values (26, 'Wehner, Lang and Williamson', 'Mexico', 'Vicente Guerrero');
  insert into draft_clubs (club_id, club_name, country, city) values (27, 'Boehm Group', 'Brazil', 'Videira');
  insert into draft_clubs (club_id, club_name, country, city) values (28, 'Leannon-Halvorson', 'Portugal', 'Teixoso');
  insert into draft_clubs (club_id, club_name, country, city) values (29, 'Sporer, Wiza and Bergnaum', 'Uzbekistan', 'Mŭynoq');
  insert into draft_clubs (club_id, club_name, country, city) values (30, 'Murphy, McCullough and Balistreri', 'Russia', 'Saint Petersburg');
  insert into draft_clubs (club_id, club_name, country, city) values (31, 'Lynch-Davis', 'Indonesia', 'Bombu');
  insert into draft_clubs (club_id, club_name, country, city) values (32, 'Grimes Inc', 'China', 'Yujia’ao');
  insert into draft_clubs (club_id, club_name, country, city) values (33, 'Goyette, Johnston and Franecki', 'Indonesia', 'Suwalan');
  insert into draft_clubs (club_id, club_name, country, city) values (34, 'Wiza LLC', 'Indonesia', 'Kadugedong');
  insert into draft_clubs (club_id, club_name, country, city) values (35, 'Hauck Group', 'Portugal', 'Cortezia');
  insert into draft_clubs (club_id, club_name, country, city) values (36, 'Johnston Inc', 'Colombia', 'Nuquí');
  insert into draft_clubs (club_id, club_name, country, city) values (37, 'Swift-Durgan', 'Bosnia and Herzegovina', 'Barice');
  insert into draft_clubs (club_id, club_name, country, city) values (38, 'Pollich Inc', 'China', 'Xiaocun');
  insert into draft_clubs (club_id, club_name, country, city) values (39, 'Hartmann, Quigley and Grant', 'Philippines', 'Tigbaw');
  insert into draft_clubs (club_id, club_name, country, city) values (40, 'Blanda, Kilback and Fadel', 'China', 'Nanyang');
  insert into draft_clubs (club_id, club_name, country, city) values (41, 'Marvin LLC', 'China', 'Liancheng');
  insert into draft_clubs (club_id, club_name, country, city) values (42, 'Pagac and Sons', 'Russia', 'Verkhniy Avzyan');
  insert into draft_clubs (club_id, club_name, country, city) values (43, 'Casper-Gutkowski', 'Portugal', 'Almada');
  insert into draft_clubs (club_id, club_name, country, city) values (44, 'Trantow LLC', 'China', 'Xintian');
  insert into draft_clubs (club_id, club_name, country, city) values (45, 'O''Kon, Lang and VonRueden', 'Afghanistan', 'Qarah Bāgh Bāzār');
  insert into draft_clubs (club_id, club_name, country, city) values (46, 'Torp-Waters', 'France', 'Vesoul');
  insert into draft_clubs (club_id, club_name, country, city) values (47, 'Kulas, Grant and Mitchell', 'China', 'Dapeng');
  insert into draft_clubs (club_id, club_name, country, city) values (48, 'Stehr-Osinski', 'China', 'Chengzihe');
  insert into draft_clubs (club_id, club_name, country, city) values (49, 'Leannon and Sons', 'France', 'Châteauroux');
  insert into draft_clubs (club_id, club_name, country, city) values (50, 'Hermiston-Daniel', 'China', 'Shigutang');
  insert into draft_clubs (club_id, club_name, country, city) values (51, 'Lubowitz, Hackett and Considine', 'Portugal', 'Lajeosa');
  insert into draft_clubs (club_id, club_name, country, city) values (52, 'Raynor-Lebsack', 'South Korea', 'Gapyeong');
  insert into draft_clubs (club_id, club_name, country, city) values (53, 'Wolf-Crist', 'Sweden', 'Kiruna');
  insert into draft_clubs (club_id, club_name, country, city) values (54, 'Hirthe, Krajcik and Schneider', 'Indonesia', 'Datarnangka');
  insert into draft_clubs (club_id, club_name, country, city) values (55, 'Lockman, Heathcote and O''Keefe', 'Indonesia', 'Sungai Raya');
  insert into draft_clubs (club_id, club_name, country, city) values (56, 'Rutherford, Denesik and Ernser', 'Japan', 'Kushiro');
  insert into draft_clubs (club_id, club_name, country, city) values (57, 'Schaden, Blanda and Schamberger', 'Indonesia', 'Timba Timuk');
  insert into draft_clubs (club_id, club_name, country, city) values (58, 'Moore, Buckridge and Torp', 'Brazil', 'Barra Mansa');
  insert into draft_clubs (club_id, club_name, country, city) values (59, 'Nolan Group', 'Honduras', 'San Marcos de Colón');
  insert into draft_clubs (club_id, club_name, country, city) values (60, 'Okuneva LLC', 'Iran', 'Hashtgerd');
  insert into draft_clubs (club_id, club_name, country, city) values (61, 'Rolfson, Ondricka and Blanda', 'Russia', 'Altuf’yevskiy');
  insert into draft_clubs (club_id, club_name, country, city) values (62, 'Wolff, Dickinson and Miller', 'Portugal', 'Castro Daire');
  insert into draft_clubs (club_id, club_name, country, city) values (63, 'Cruickshank-Armstrong', 'China', 'Haishan');
  insert into draft_clubs (club_id, club_name, country, city) values (64, 'Beier, Mraz and Heathcote', 'United States', 'New York City');
  insert into draft_clubs (club_id, club_name, country, city) values (65, 'West-Bayer', 'Indonesia', 'Nagrog Wetan');
  insert into draft_clubs (club_id, club_name, country, city) values (66, 'Ebert, Beier and Bartell', 'Central African Republic', 'Bria');
  insert into draft_clubs (club_id, club_name, country, city) values (67, 'Buckridge, Cruickshank and Kihn', 'Brazil', 'Uruçuca');
  insert into draft_clubs (club_id, club_name, country, city) values (68, 'Baumbach-Schmeler', 'Poland', 'Paniówki');
  insert into draft_clubs (club_id, club_name, country, city) values (69, 'Durgan and Sons', 'Serbia', 'Ilandža');
  insert into draft_clubs (club_id, club_name, country, city) values (70, 'Walter-Bednar', 'China', 'Magang');
  insert into draft_clubs (club_id, club_name, country, city) values (71, 'CCC Inc', 'Russia', 'Shkurinskaya');
  insert into draft_clubs (club_id, club_name, country, city) values (72, 'Breitenberg, Wolff and Leffler', 'Ireland', 'Adare');
  insert into draft_clubs (club_id, club_name, country, city) values (73, 'Lowe-MacGyver', 'Argentina', 'Nueve de Julio');
  insert into draft_clubs (club_id, club_name, country, city) values (74, 'Wiza, Murphy and Hintz', 'Philippines', 'Guihulñgan');
  insert into draft_clubs (club_id, club_name, country, city) values (75, 'Kessler Group', 'Peru', 'Cocachacra');
  insert into draft_clubs (club_id, club_name, country, city) values (76, 'Donnelly and Sons', 'Russia', 'Sukkozero');
  insert into draft_clubs (club_id, club_name, country, city) values (77, 'Thiel, Trantow and Kshlerin', 'Serbia', 'Šid');
  insert into draft_clubs (club_id, club_name, country, city) values (78, 'Smith, Bins and Macejkovic', 'Ukraine', 'Radekhiv');
  insert into draft_clubs (club_id, club_name, country, city) values (79, 'Bosco, Bednar and D''Amore', 'Indonesia', 'Glugur Krajan');
  insert into draft_clubs (club_id, club_name, country, city) values (80, 'Tillman, Hansen and Batz', 'Greece', 'Níkiti');
  insert into draft_clubs (club_id, club_name, country, city) values (81, 'Cassin and Sons', 'Philippines', 'Lunas');
  insert into draft_clubs (club_id, club_name, country, city) values (82, 'Gulgowski-Herzog', 'Poland', 'Rzepiennik Strzyżewski');
  insert into draft_clubs (club_id, club_name, country, city) values (83, 'Little-Romaguera', 'Peru', 'Alca');
  insert into draft_clubs (club_id, club_name, country, city) values (84, 'Rowe, Metz and Quigley', 'Poland', 'Węgliniec');
  insert into draft_clubs (club_id, club_name, country, city) values (85, 'Vandervort-Goodwin', 'Portugal', 'Belos Ares');
  insert into draft_clubs (club_id, club_name, country, city) values (86, 'Legros-Streich', 'Thailand', 'Mayo');
  insert into draft_clubs (club_id, club_name, country, city) values (87, 'Jerde-Zemlak', 'Indonesia', 'Elat');
  insert into draft_clubs (club_id, club_name, country, city) values (88, 'Grant-Schamberger', 'Ecuador', 'Manta');
  insert into draft_clubs (club_id, club_name, country, city) values (89, 'Kuhn-Bashirian', 'China', 'Shisandaogou');
  insert into draft_clubs (club_id, club_name, country, city) values (90, 'Gusikowski LLC', 'United States', 'Los Angeles');
  insert into draft_clubs (club_id, club_name, country, city) values (91, 'Gibson-Waters', 'Japan', 'Kagoshima-shi');
  insert into draft_clubs (club_id, club_name, country, city) values (92, 'Green-Lakin', 'Argentina', 'Famaillá');
  insert into draft_clubs (club_id, club_name, country, city) values (93, 'Zboncak-Glover', 'Indonesia', 'Caloue');
  insert into draft_clubs (club_id, club_name, country, city) values (94, 'Funk-Nicolas', 'Ireland', 'Gweedore');
  insert into draft_clubs (club_id, club_name, country, city) values (95, 'Steuber, Walker and Witting', 'United States', 'Des Moines');
  insert into draft_clubs (club_id, club_name, country, city) values (96, 'Balistreri Group', 'China', 'Xiaolongmen');
  insert into draft_clubs (club_id, club_name, country, city) values (97, 'Beer, McLaughlin and Predovic', 'Russia', 'Vyshneye Dolgoye');
  insert into draft_clubs (club_id, club_name, country, city) values (98, 'Volkman-Abernathy', 'Niger', 'Madaoua');
  insert into draft_clubs (club_id, club_name, country, city) values (99, 'Runte', 'Colombia', 'Obando');
  insert into draft_clubs (club_id, club_name, country, city) values (100, 'Kohler-Connelly', 'Russia', 'Vysotsk');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO contracts
SELECT r.name, c.club_name
FROM draft_rookies r, draft_clubs c
ORDER BY random()
LIMIT 1000;
