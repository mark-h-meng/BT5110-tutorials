/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
In this example, we create a database to store information on the pokemons
caught by the trainers. Specifically, we create three tables, namely:
- trainer, which contains information on pokemon trainers in the Kanto region
- pokemon, which contains information on the 166 identified pokemons
- caught_by, which associate the type of pokemon caught by the trainers
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS trainers (
	trainer_id VARCHAR(16) PRIMARY KEY,
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	date_of_birth DATE NOT NULL,
	gender VARCHAR(16) NOT NULL,
	badge_count NUMERIC NOT NULL
);

CREATE TABLE IF NOT EXISTS pokemons (
	pokemon_id VARCHAR(16) PRIMARY KEY,
	species VARCHAR(64) UNIQUE NOT NULL,
	type_1 VARCHAR(64) NOT NULL,
	type_2 VARCHAR(64),
	legendary VARCHAR(16) NOT NULL
);

CREATE TABLE IF NOT EXISTS caught_by (
	trainer_id VARCHAR(16) REFERENCES trainers(trainer_id)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED,
	pokemon_id VARCHAR(16),
	date_caught DATE NOT NULL,
	level_when_caught NUMERIC NOT NULL,
	FOREIGN KEY(pokemon_id) REFERENCES pokemons(pokemon_id)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
SET datestyle TO PostgreSQL,US;
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (1,'Bulbasaur','Grass','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (2,'Ivysaur','Grass','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (3,'Venusaur','Grass','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (4,'Mega Venusaur','Grass','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (5,'Charmander','Fire',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (6,'Charmeleon','Fire',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (7,'Charizard','Fire','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (8,'Mega Charizard X','Fire','Dragon',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (9,'Mega Charizard Y','Fire','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (10,'Squirtle','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (11,'Wartortle','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (12,'Blastoise','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (13,'Mega Blastoise','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (14,'Caterpie','Bug',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (15,'Metapod','Bug',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (16,'Butterfree','Bug','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (17,'Weedle','Bug','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (18,'Kakuna','Bug','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (19,'Beedrill','Bug','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (20,'Mega Beedrill','Bug','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (21,'Pidgey','Normal','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (22,'Pidgeotto','Normal','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (23,'Pidgeot','Normal','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (24,'Mega Pidgeot','Normal','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (25,'Rattata','Normal',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (26,'Raticate','Normal',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (27,'Spearow','Normal','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (28,'Fearow','Normal','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (29,'Ekans','Poison',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (30,'Arbok','Poison',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (31,'Pikachu','Electric',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (32,'Raichu','Electric',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (33,'Sandshrew','Ground',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (34,'Sandslash','Ground',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (35,'Nidoran♀','Poison',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (36,'Nidorina','Poison',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (37,'Nidoqueen','Poison','Ground',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (38,'Nidoran♂','Poison',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (39,'Nidorino','Poison',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (40,'Nidoking','Poison','Ground',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (41,'Clefairy','Fairy',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (42,'Clefable','Fairy',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (43,'Vulpix','Fire',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (44,'Ninetales','Fire',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (45,'Jigglypuff','Normal','Fairy',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (46,'Wigglytuff','Normal','Fairy',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (47,'Zubat','Poison','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (48,'Golbat','Poison','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (49,'Oddish','Grass','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (50,'Gloom','Grass','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (51,'Vileplume','Grass','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (52,'Paras','Bug','Grass',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (53,'Parasect','Bug','Grass',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (54,'Venonat','Bug','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (55,'Venomoth','Bug','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (56,'Diglett','Ground',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (57,'Dugtrio','Ground',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (58,'Meowth','Normal',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (59,'Persian','Normal',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (60,'Psyduck','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (61,'Golduck','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (62,'Mankey','Fighting',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (63,'Primeape','Fighting',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (64,'Growlithe','Fire',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (65,'Arcanine','Fire',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (66,'Poliwag','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (67,'Poliwhirl','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (68,'Poliwrath','Water','Fighting',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (69,'Abra','Psychic',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (70,'Kadabra','Psychic',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (71,'Alakazam','Psychic',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (72,'Mega Alakazam','Psychic',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (73,'Machop','Fighting',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (74,'Machoke','Fighting',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (75,'Machamp','Fighting',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (76,'Bellsprout','Grass','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (77,'Weepinbell','Grass','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (78,'Victreebel','Grass','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (79,'Tentacool','Water','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (80,'Tentacruel','Water','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (81,'Geodude','Rock','Ground',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (82,'Graveler','Rock','Ground',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (83,'Golem','Rock','Ground',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (84,'Ponyta','Fire',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (85,'Rapidash','Fire',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (86,'Slowpoke','Water','Psychic',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (87,'Slowbro','Water','Psychic',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (88,'Mega Slowbro','Water','Psychic',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (89,'Magnemite','Electric','Steel',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (90,'Magneton','Electric','Steel',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (91,'Farfetch''d','Normal','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (92,'Doduo','Normal','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (93,'Dodrio','Normal','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (94,'Seel','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (95,'Dewgong','Water','Ice',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (96,'Grimer','Poison',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (97,'Muk','Poison',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (98,'Shellder','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (99,'Cloyster','Water','Ice',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (100,'Gastly','Ghost','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (101,'Haunter','Ghost','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (102,'Gengar','Ghost','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (103,'Mega Gengar','Ghost','Poison',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (104,'Onix','Rock','Ground',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (105,'Drowzee','Psychic',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (106,'Hypno','Psychic',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (107,'Krabby','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (108,'Kingler','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (109,'Voltorb','Electric',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (110,'Electrode','Electric',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (111,'Exeggcute','Grass','Psychic',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (112,'Exeggutor','Grass','Psychic',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (113,'Cubone','Ground',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (114,'Marowak','Ground',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (115,'Hitmonlee','Fighting',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (116,'Hitmonchan','Fighting',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (117,'Lickitung','Normal',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (118,'Koffing','Poison',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (119,'Weezing','Poison',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (120,'Rhyhorn','Ground','Rock',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (121,'Rhydon','Ground','Rock',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (122,'Chansey','Normal',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (123,'Tangela','Grass',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (124,'Kangaskhan','Normal',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (125,'Mega Kangaskhan','Normal',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (126,'Horsea','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (127,'Seadra','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (128,'Goldeen','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (129,'Seaking','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (130,'Staryu','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (131,'Starmie','Water','Psychic',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (132,'Mr. Mime','Psychic','Fairy',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (133,'Scyther','Bug','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (134,'Jynx','Ice','Psychic',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (135,'Electabuzz','Electric',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (136,'Magmar','Fire',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (137,'Pinsir','Bug',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (138,'Mega Pinsir','Bug','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (139,'Tauros','Normal',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (140,'Magikarp','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (141,'Gyarados','Water','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (142,'Mega Gyarados','Water','Dark',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (143,'Lapras','Water','Ice',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (144,'Ditto','Normal',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (145,'Eevee','Normal',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (146,'Vaporeon','Water',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (147,'Jolteon','Electric',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (148,'Flareon','Fire',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (149,'Porygon','Normal',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (150,'Omanyte','Rock','Water',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (151,'Omastar','Rock','Water',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (152,'Kabuto','Rock','Water',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (153,'Kabutops','Rock','Water',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (154,'Aerodactyl','Rock','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (155,'Mega Aerodactyl','Rock','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (156,'Snorlax','Normal',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (157,'Articuno','Ice','Flying',TRUE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (158,'Zapdos','Electric','Flying',TRUE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (159,'Moltres','Fire','Flying',TRUE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (160,'Dratini','Dragon',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (161,'Dragonair','Dragon',NULL,FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (162,'Dragonite','Dragon','Flying',FALSE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (163,'Mewtwo','Psychic',NULL,TRUE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (164,'Mega Mewtwo X','Psychic','Fighting',TRUE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (165,'Mega Mewtwo Y','Psychic',NULL,TRUE);
INSERT INTO pokemons (pokemon_id,species,type_1,type_2,legendary) VALUES (166,'Mew','Psychic',NULL,FALSE);

INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (1, 'Nicole', 'Throughton', '11/6/1980', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (2, 'Odelle', 'Kingaby', '11/11/1979', 'Male', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (3, 'Ailis', 'Guidi', '5/27/1961', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (4, 'Tasha', 'Philipp', '9/8/1997', 'Female', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (5, 'Allin', 'Kerbey', '6/23/1977', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (6, 'Sawyere', 'Garlick', '2/6/1968', 'Male', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (7, 'Austin', 'Beaudry', '1/10/1966', 'Female', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (8, 'Murdock', 'Cardo', '5/13/1974', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (9, 'Inez', 'Eslie', '5/4/1990', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (10, 'Rand', 'McLernon', '6/5/2007', 'Female', 4);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (11, 'Barthel', 'Attarge', '9/14/1951', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (12, 'Vic', 'McCallam', '7/16/1965', 'Male', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (13, 'Cale', 'O''Deoran', '3/27/1966', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (14, 'Norry', 'Drinan', '5/16/1969', 'Female', 0);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (15, 'Demott', 'Campey', '8/2/1975', 'Male', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (16, 'Hortensia', 'McCaughey', '5/20/1961', 'Male', 4);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (17, 'Binni', 'Jirasek', '5/11/1964', 'Female', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (18, 'Raina', 'Lipgens', '8/14/2006', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (19, 'Cyrille', 'Satch', '3/30/1982', 'Female', 4);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (20, 'Nev', 'Henrot', '12/16/1966', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (21, 'Randi', 'Camps', '10/22/1974', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (22, 'Rani', 'Weight', '12/2/1989', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (23, 'Raddie', 'Tipling', '7/17/1977', 'Male', 5);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (24, 'Marcus', 'Royston', '5/16/2002', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (25, 'Myrna', 'Rolf', '9/8/2004', 'Male', 0);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (26, 'Bernard', 'Connikie', '10/25/1967', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (27, 'Jasen', 'Ketchell', '12/27/1994', 'Female', 0);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (28, 'Guthrey', 'Pickaver', '6/29/1977', 'Male', 0);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (29, 'Anallise', 'Veysey', '12/6/2006', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (30, 'Simonne', 'Swadlinge', '12/17/1978', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (31, 'Dall', 'Paulus', '6/25/1966', 'Female', 5);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (32, 'Nathalie', 'Osinin', '8/1/1984', 'Female', 0);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (33, 'Darla', 'Bonass', '2/28/2004', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (34, 'Filberto', 'Vispo', '1/11/1957', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (35, 'Gale', 'Gaber', '2/24/2004', 'Male', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (36, 'Allie', 'Jiroutka', '7/14/1999', 'Male', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (37, 'Brady', 'Baldam', '8/1/1988', 'Female', 0);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (38, 'Cyndi', 'Isbell', '12/9/1974', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (39, 'Garrett', 'Petto', '6/2/1983', 'Female', 5);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (40, 'Kermit', 'Piens', '7/25/1988', 'Female', 4);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (41, 'Ulric', 'Barosch', '6/17/1989', 'Female', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (42, 'Leola', 'Vallery', '10/13/1994', 'Male', 0);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (43, 'Melisa', 'Sapir', '12/13/1961', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (44, 'Tadeo', 'Goad', '1/28/1972', 'Male', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (45, 'Ralph', 'O''Mannion', '2/2/1996', 'Female', 0);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (46, 'Willabella', 'Aronovich', '12/24/1980', 'Male', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (47, 'Dell', 'De Malchar', '3/3/1969', 'Male', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (48, 'Geoffry', 'Hargie', '6/20/1989', 'Female', 0);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (49, 'Jasmina', 'Patrono', '4/21/1950', 'Female', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (50, 'Amie', 'Houlridge', '7/15/1960', 'Male', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (51, 'Emera', 'Jozwiak', '8/27/1993', 'Female', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (52, 'Elna', 'McGeechan', '4/7/1954', 'Male', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (53, 'Geno', 'Cridlin', '1/12/1977', 'Male', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (54, 'Nevile', 'Dowears', '3/15/1967', 'Male', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (55, 'Gypsy', 'Rooper', '1/15/1980', 'Male', 0);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (56, 'Ronalda', 'Clausen-Thue', '12/15/1989', 'Female', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (57, 'Catarina', 'Frederick', '9/27/2004', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (58, 'Vachel', 'Manifold', '5/16/1990', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (59, 'Wanda', 'Barriball', '8/30/1990', 'Female', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (60, 'Megen', 'Ovitz', '1/27/1991', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (61, 'Lyda', 'Shildrake', '8/1/1997', 'Male', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (62, 'Nerita', 'Roels', '9/5/1961', 'Female', 6);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (63, 'Erminia', 'Willgrass', '6/28/1973', 'Male', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (64, 'Scotty', 'Ferrettini', '2/28/1959', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (65, 'Frederik', 'Wiburn', '9/16/1975', 'Female', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (66, 'Julieta', 'Elsley', '3/8/1998', 'Male', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (67, 'Shepherd', 'Gullifant', '3/22/2004', 'Male', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (68, 'Ripley', 'Arch', '6/21/1999', 'Female', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (69, 'Orsa', 'Jervoise', '12/4/1967', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (70, 'Alena', 'Jailler', '5/20/1985', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (71, 'Berrie', 'Purkins', '11/22/1960', 'Female', 7);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (72, 'Murielle', 'Bullimore', '12/30/1975', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (73, 'Nefen', 'Cuvley', '12/14/1975', 'Female', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (74, 'Mozelle', 'Janous', '1/15/1985', 'Male', 6);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (75, 'Edmund', 'Ridgwell', '10/6/1955', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (76, 'Karina', 'Cadd', '1/27/1960', 'Male', 5);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (77, 'Danette', 'Gatecliffe', '2/7/1982', 'Male', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (78, 'Donalt', 'Harvett', '7/18/2005', 'Female', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (79, 'Linoel', 'Elcum', '4/30/2001', 'Female', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (80, 'Claire', 'Edmenson', '10/5/1977', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (81, 'Dalia', 'Fairclough', '1/22/2011', 'Male', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (82, 'Erna', 'Baroch', '8/22/1989', 'Male', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (83, 'Myrtle', 'Breacher', '6/28/1996', 'Male', 0);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (84, 'West', 'Stolworthy', '6/12/1958', 'Female', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (85, 'Trixy', 'Zuker', '10/19/2010', 'Female', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (86, 'Nikki', 'Ormesher', '10/28/1992', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (87, 'Chanda', 'Pass', '11/19/1977', 'Female', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (88, 'Emile', 'Morrow', '6/22/1984', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (89, 'Montgomery', 'Plaice', '5/2/2010', 'Male', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (90, 'Christoforo', 'Britton', '10/23/1952', 'Female', 4);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (91, 'Adams', 'Vickarman', '8/13/1969', 'Male', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (92, 'Dagny', 'Cattow', '5/4/1953', 'Female', 7);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (93, 'Matias', 'Phillput', '1/20/2004', 'Female', 1);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (94, 'Caty', 'Hofler', '7/23/1951', 'Male', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (95, 'Benjie', 'Backhouse', '9/18/2011', 'Female', 0);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (96, 'Estella', 'Videler', '8/17/1975', 'Female', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (97, 'Oates', 'Bantham', '9/8/1989', 'Female', 6);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (98, 'Jeremiah', 'Phillcock', '8/25/1968', 'Male', 2);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (99, 'Herby', 'Hucks', '3/29/1993', 'Female', 3);
INSERT INTO trainers (trainer_id, first_name, last_name, date_of_birth, gender, badge_count) values (100, 'Eleonore', 'Charpling', '8/23/2000', 'Female', 2);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO caught_by(trainer_id, pokemon_id, date_caught, level_when_caught)
VALUES
   (87, 149, '12/10/2020', 26),
   (79, 33, '5/8/2021', 95),
   (52, 11, '7/17/2020', 79),
   (34, 25, '11/30/2020', 37),
   (47, 160, '10/5/2020', 63),
   (32, 95, '5/15/2020', 29),
   (70, 109, '6/20/2020', 98),
   (38, 123, '6/11/2020', 16),
   (82, 14, '5/5/2020', 66),
   (59, 61, '7/28/2021', 60),
   (85, 94, '11/6/2020', 19),
   (75, 117, '5/13/2020', 28),
   (98, 23, '4/6/2021', 69),
   (91, 153, '4/23/2020', 96),
   (90, 141, '3/15/2021', 51),
   (44, 150, '10/21/2020', 60),
   (12, 97, '6/11/2020', 6),
   (89, 73, '3/11/2020', 70),
   (81, 154, '5/11/2021', 26),
   (92, 138, '5/10/2021', 47),
   (6, 15, '3/15/2021', 50),
   (20, 40, '5/6/2020', 16),
   (75, 81, '7/9/2020', 43),
   (74, 138, '7/25/2020', 99),
   (45, 103, '10/21/2020', 51),
   (1, 46, '3/8/2021', 16),
   (1, 3, '5/15/2020', 22),
   (68, 113, '4/4/2020', 77),
   (99, 10, '2/13/2020', 82),
   (10, 101, '2/6/2021', 100),
   (54, 59, '1/18/2020', 53),
   (90, 3, '8/29/2020', 70),
   (23, 118, '2/14/2021', 14),
   (63, 53, '12/30/2020', 79),
   (97, 51, '7/26/2020', 26),
   (46, 102, '3/2/2021', 42),
   (49, 114, '7/26/2021', 56),
   (78, 54, '1/24/2020', 6),
   (75, 61, '2/6/2020', 58),
   (93, 23, '6/9/2020', 22),
   (56, 46, '5/30/2020', 54),
   (96, 29, '6/9/2020', 3),
   (100, 28, '5/3/2021', 45),
   (23, 109, '9/29/2020', 89),
   (83, 76, '8/4/2020', 58),
   (35, 64, '2/7/2021', 13),
   (71, 37, '10/20/2020', 5),
   (26, 136, '7/30/2021', 57),
   (32, 76, '7/12/2020', 65),
   (64, 36, '1/16/2021', 24),
   (75, 127, '5/25/2021', 66),
   (69, 65, '7/21/2021', 6),
   (94, 93, '8/9/2021', 96),
   (88, 140, '8/18/2021', 60),
   (24, 87, '9/14/2020', 8),
   (96, 81, '5/21/2021', 65),
   (77, 42, '3/15/2020', 92),
   (73, 15, '4/17/2020', 92),
   (22, 25, '7/12/2021', 72),
   (68, 87, '5/24/2021', 18),
   (51, 38, '7/29/2021', 49),
   (44, 20, '5/27/2021', 96),
   (13, 55, '8/11/2021', 98),
   (74, 83, '6/7/2020', 98),
   (75, 95, '2/10/2021', 53),
   (87, 78, '3/18/2020', 11),
   (22, 136, '9/6/2020', 19),
   (11, 63, '10/31/2020', 81),
   (45, 72, '5/2/2020', 42),
   (67, 68, '5/13/2020', 69),
   (57, 136, '11/5/2020', 76),
   (41, 68, '3/27/2020', 76),
   (49, 29, '5/26/2021', 66),
   (6, 6, '2/16/2020', 92),
   (32, 133, '8/16/2020', 3),
   (6, 90, '4/30/2020', 80),
   (61, 112, '7/18/2021', 81),
   (25, 41, '6/20/2020', 78),
   (17, 93, '2/21/2021', 5),
   (43, 59, '12/30/2020', 86),
   (94, 43, '2/13/2020', 1),
   (57, 84, '11/29/2020', 6),
   (1, 49, '5/31/2021', 32),
   (44, 126, '7/7/2021', 98),
   (58, 136, '6/1/2021', 11),
   (23, 19, '5/12/2021', 40),
   (54, 67, '9/12/2020', 5),
   (93, 39, '9/19/2020', 80),
   (66, 115, '5/8/2021', 70),
   (5, 152, '7/6/2020', 30),
   (65, 12, '5/12/2021', 56),
   (72, 9, '1/26/2020', 17),
   (62, 99, '7/9/2021', 43),
   (70, 89, '8/19/2020', 27),
   (51, 98, '10/31/2020', 84),
   (15, 133, '3/12/2020', 29),
   (25, 138, '6/17/2020', 90),
   (54, 13, '11/13/2020', 6),
   (93, 133, '1/3/2020', 98),
   (42, 80, '4/28/2021', 97),
   (37, 25, '11/2/2020', 92),
   (39, 137, '12/1/2020', 61),
   (70, 82, '7/7/2020', 47),
   (61, 136, '4/2/2021', 27),
   (73, 138, '8/31/2020', 87),
   (2, 93, '9/6/2020', 63),
   (90, 87, '1/30/2021', 84),
   (52, 91, '6/10/2020', 76),
   (77, 102, '1/13/2020', 96),
   (78, 70, '10/21/2020', 27),
   (3, 152, '3/31/2021', 91),
   (12, 159, '1/7/2020', 100),
   (90, 97, '6/13/2021', 83),
   (69, 136, '12/22/2020', 72),
   (59, 78, '9/16/2020', 99),
   (53, 56, '4/3/2021', 15),
   (19, 80, '3/4/2021', 12),
   (52, 98, '2/23/2021', 10),
   (27, 82, '8/31/2020', 22),
   (20, 36, '8/28/2020', 53),
   (94, 64, '4/9/2021', 55),
   (35, 26, '5/10/2020', 2),
   (25, 85, '4/2/2021', 92),
   (65, 141, '1/7/2020', 94),
   (36, 92, '8/4/2020', 42),
   (75, 18, '7/8/2021', 63),
   (19, 41, '2/24/2021', 61),
   (93, 126, '2/17/2021', 11),
   (1, 96, '3/27/2021', 44),
   (76, 148, '7/19/2020', 66),
   (21, 10, '3/25/2021', 33),
   (62, 142, '7/4/2020', 49),
   (54, 24, '2/14/2021', 16),
   (49, 39, '8/20/2020', 75),
   (28, 73, '5/6/2020', 65),
   (60, 99, '3/10/2020', 44),
   (20, 148, '8/6/2021', 16),
   (49, 75, '5/3/2021', 14),
   (72, 125, '3/23/2020', 35),
   (55, 158, '7/23/2021', 34),
   (66, 21, '3/30/2021', 52),
   (94, 58, '10/26/2020', 68),
   (1, 137, '6/20/2020', 71),
   (61, 57, '6/23/2020', 47),
   (94, 62, '2/2/2020', 89),
   (18, 101, '11/15/2020', 30),
   (81, 135, '10/13/2020', 20),
   (31, 103, '4/4/2021', 6),
   (2, 62, '8/2/2020', 95),
   (10, 37, '1/24/2020', 87),
   (29, 138, '5/30/2020', 24),
   (35, 119, '6/28/2020', 13),
   (41, 138, '6/30/2021', 42),
   (48, 14, '4/6/2021', 81),
   (87, 149, '5/3/2021', 27),
   (47, 99, '6/25/2021', 32),
   (71, 95, '6/26/2020', 8),
   (45, 70, '7/17/2021', 64),
   (17, 3, '5/31/2021', 49),
   (67, 160, '4/23/2021', 5),
   (34, 81, '1/1/2021', 17),
   (52, 154, '8/17/2021', 50),
   (60, 52, '7/1/2021', 13),
   (61, 157, '7/20/2021', 80),
   (33, 49, '2/10/2020', 23),
   (4, 148, '11/9/2020', 74),
   (78, 108, '9/10/2020', 64),
   (62, 91, '1/26/2021', 82),
   (15, 129, '8/30/2020', 90),
   (37, 84, '5/25/2021', 51),
   (52, 101, '2/23/2021', 24),
   (11, 29, '9/30/2020', 97),
   (67, 128, '8/9/2020', 39),
   (73, 57, '2/26/2020', 67),
   (81, 13, '3/18/2020', 92),
   (71, 119, '3/25/2021', 82),
   (33, 52, '10/18/2020', 99),
   (35, 90, '5/20/2021', 42),
   (21, 155, '11/23/2020', 16),
   (72, 111, '11/9/2020', 44),
   (63, 104, '7/9/2020', 73),
   (38, 16, '5/19/2020', 77),
   (89, 14, '2/22/2021', 77),
   (56, 48, '4/14/2021', 49),
   (33, 143, '7/12/2021', 40),
   (14, 96, '6/23/2021', 87),
   (82, 66, '10/21/2020', 78),
   (71, 101, '2/3/2020', 12),
   (96, 92, '2/29/2020', 7),
   (3, 100, '3/30/2021', 15),
   (6, 92, '1/11/2020', 45),
   (6, 24, '7/25/2020', 70),
   (50, 56, '11/13/2020', 49),
   (97, 113, '11/9/2020', 70),
   (25, 87, '3/29/2021', 56),
   (29, 158, '7/27/2020', 83),
   (22, 106, '2/7/2020', 35),
   (63, 4, '12/18/2020', 52),
   (37, 88, '7/15/2020', 67),
   (68, 7, '11/6/2020', 48),
   (30, 33, '11/4/2020', 7),
   (25, 93, '7/15/2021', 25),
   (78, 143, '6/22/2020', 4),
   (20, 30, '9/22/2020', 93),
   (47, 50, '6/25/2020', 28),
   (7, 98, '6/10/2020', 37),
   (39, 123, '6/28/2021', 36),
   (78, 36, '6/14/2020', 79),
   (61, 121, '2/26/2020', 2),
   (70, 159, '1/5/2020', 31),
   (62, 35, '12/30/2020', 70),
   (32, 82, '3/5/2021', 27),
   (63, 27, '3/17/2021', 3),
   (60, 89, '4/26/2021', 88),
   (23, 138, '1/19/2021', 65),
   (57, 13, '1/3/2021', 79),
   (56, 162, '7/30/2021', 84),
   (95, 91, '12/31/2020', 38),
   (39, 123, '2/25/2021', 28),
   (65, 74, '6/5/2020', 51),
   (53, 6, '8/3/2020', 26),
   (63, 96, '1/16/2021', 99),
   (94, 42, '11/17/2020', 15),
   (98, 107, '10/1/2020', 77),
   (83, 96, '9/19/2020', 79),
   (50, 116, '7/11/2020', 11),
   (91, 17, '1/26/2021', 99),
   (82, 23, '2/7/2021', 44),
   (85, 62, '6/26/2020', 27),
   (10, 19, '2/17/2021', 92),
   (60, 38, '7/1/2021', 49),
   (61, 113, '7/7/2020', 99),
   (45, 100, '6/2/2021', 18),
   (23, 112, '7/30/2021', 72),
   (61, 146, '2/11/2021', 85),
   (65, 142, '5/18/2020', 20),
   (56, 4, '5/13/2021', 21),
   (89, 129, '8/6/2021', 40),
   (64, 93, '2/7/2021', 63),
   (43, 53, '7/16/2021', 44),
   (36, 132, '7/19/2020', 95),
   (55, 118, '9/23/2020', 49),
   (50, 76, '3/23/2021', 84),
   (64, 62, '2/10/2020', 68),
   (20, 91, '11/2/2020', 3),
   (37, 140, '7/5/2021', 61),
   (41, 6, '6/4/2021', 47),
   (36, 130, '4/17/2021', 57),
   (79, 18, '3/15/2021', 93),
   (85, 67, '2/4/2021', 35),
   (49, 113, '9/10/2020', 78),
   (80, 89, '7/12/2021', 99),
   (99, 1, '11/18/2020', 27),
   (45, 35, '10/22/2020', 53),
   (12, 7, '7/2/2021', 57),
   (44, 156, '4/22/2020', 12),
   (40, 45, '3/16/2020', 47),
   (38, 67, '2/3/2020', 90),
   (32, 3, '11/22/2020', 86),
   (97, 58, '8/30/2020', 57),
   (77, 71, '10/23/2020', 3),
   (94, 138, '4/11/2020', 32),
   (100, 137, '11/3/2020', 13),
   (3, 43, '4/16/2020', 68),
   (89, 160, '4/25/2020', 45),
   (71, 136, '2/9/2021', 41),
   (87, 126, '8/3/2020', 64),
   (26, 69, '12/17/2020', 10),
   (79, 34, '5/1/2021', 10),
   (71, 111, '4/23/2021', 17),
   (23, 61, '4/24/2021', 49),
   (42, 126, '6/4/2021', 5),
   (15, 116, '11/12/2020', 28),
   (24, 22, '4/1/2021', 5),
   (69, 24, '5/4/2020', 21),
   (52, 108, '11/23/2020', 50),
   (37, 60, '5/24/2020', 54),
   (11, 41, '12/11/2020', 13),
   (26, 26, '3/18/2020', 69),
   (42, 9, '1/4/2020', 10),
   (50, 17, '4/16/2021', 86),
   (95, 88, '5/24/2021', 96),
   (10, 91, '1/7/2020', 98),
   (37, 99, '2/16/2021', 67),
   (11, 112, '7/11/2020', 13),
   (89, 151, '2/18/2021', 17),
   (16, 24, '11/14/2020', 14),
   (71, 16, '8/20/2020', 97),
   (51, 147, '2/27/2020', 34),
   (1, 34, '1/21/2020', 96),
   (53, 52, '8/30/2020', 99),
   (38, 34, '9/9/2020', 95),
   (51, 147, '6/20/2020', 6),
   (13, 55, '7/4/2020', 50),
   (90, 130, '11/1/2020', 57),
   (65, 4, '4/2/2020', 5),
   (75, 149, '7/4/2021', 39),
   (32, 77, '1/19/2020', 52),
   (4, 156, '8/9/2020', 96),
   (10, 103, '9/8/2020', 83),
   (71, 42, '12/30/2020', 52),
   (73, 117, '10/19/2020', 84),
   (20, 111, '10/20/2020', 29),
   (17, 89, '3/18/2020', 66),
   (11, 106, '10/25/2020', 5),
   (67, 106, '8/12/2021', 40),
   (3, 120, '12/29/2020', 37),
   (48, 126, '10/18/2020', 32),
   (26, 156, '3/26/2021', 72),
   (11, 110, '4/2/2020', 42),
   (37, 65, '7/6/2020', 75),
   (63, 123, '1/14/2021', 29),
   (88, 5, '7/12/2021', 20),
   (39, 124, '6/20/2020', 16),
   (93, 67, '10/7/2020', 56),
   (13, 117, '8/2/2021', 19),
   (38, 89, '8/12/2020', 8),
   (96, 91, '4/23/2020', 48),
   (61, 80, '5/29/2021', 45),
   (6, 144, '5/24/2020', 73),
   (70, 20, '6/23/2020', 44),
   (36, 36, '3/26/2020', 79),
   (53, 32, '8/25/2020', 54),
   (33, 1, '7/29/2021', 86),
   (86, 45, '2/1/2021', 39),
   (96, 112, '4/8/2021', 72),
   (11, 155, '5/12/2020', 41),
   (22, 96, '3/6/2020', 60),
   (90, 87, '4/20/2020', 61),
   (27, 74, '12/12/2020', 75),
   (35, 160, '8/12/2020', 43),
   (78, 152, '7/31/2021', 25),
   (60, 106, '1/2/2021', 91),
   (88, 27, '4/5/2021', 29),
   (7, 150, '5/9/2021', 38),
   (21, 153, '6/2/2020', 88),
   (17, 130, '2/4/2021', 66),
   (63, 30, '4/18/2021', 56),
   (64, 60, '7/15/2021', 38),
   (80, 156, '1/28/2021', 62),
   (3, 82, '6/15/2021', 60),
   (66, 158, '6/19/2021', 17),
   (51, 124, '4/1/2021', 11),
   (2, 95, '8/7/2021', 34),
   (24, 26, '6/3/2020', 2),
   (4, 20, '10/28/2020', 12),
   (43, 116, '3/31/2020', 12),
   (19, 137, '8/23/2020', 27),
   (66, 10, '3/5/2021', 94),
   (36, 132, '6/18/2021', 26),
   (85, 114, '3/13/2021', 12),
   (94, 43, '8/17/2020', 76),
   (45, 47, '4/13/2020', 69),
   (30, 66, '7/4/2020', 29),
   (37, 143, '3/4/2020', 81),
   (47, 152, '2/20/2021', 18),
   (10, 101, '2/25/2020', 50),
   (50, 101, '10/13/2020', 35),
   (47, 31, '8/13/2020', 81),
   (9, 57, '1/15/2021', 26),
   (72, 4, '5/2/2021', 68),
   (86, 110, '1/9/2021', 44),
   (28, 142, '9/8/2020', 70),
   (17, 137, '6/4/2021', 72),
   (54, 114, '6/22/2020', 95),
   (1, 23, '3/5/2021', 41),
   (65, 12, '10/16/2020', 94),
   (66, 110, '2/24/2021', 74),
   (25, 158, '9/27/2020', 7),
   (71, 27, '2/17/2021', 37),
   (37, 60, '2/2/2020', 10),
   (89, 79, '9/17/2020', 16),
   (13, 32, '12/21/2020', 81),
   (97, 64, '8/3/2021', 15),
   (56, 79, '7/5/2020', 19),
   (26, 126, '6/11/2020', 22),
   (52, 27, '7/1/2021', 29),
   (93, 106, '6/11/2020', 86),
   (84, 68, '5/13/2020', 42),
   (57, 123, '4/15/2021', 23),
   (18, 51, '7/9/2020', 5),
   (82, 8, '10/4/2020', 19),
   (100, 23, '6/7/2020', 79),
   (45, 35, '10/29/2020', 16),
   (11, 29, '11/1/2020', 44),
   (70, 11, '2/4/2020', 97),
   (9, 127, '7/23/2020', 73),
   (65, 76, '8/17/2020', 94),
   (47, 127, '7/18/2021', 30),
   (70, 80, '3/13/2021', 26),
   (39, 18, '4/6/2021', 18),
   (78, 160, '9/2/2020', 54),
   (30, 61, '8/7/2021', 98),
   (64, 140, '2/9/2021', 48),
   (67, 50, '4/30/2020', 92),
   (43, 122, '6/19/2021', 63),
   (39, 35, '4/3/2020', 75),
   (9, 13, '4/18/2021', 3),
   (50, 13, '7/11/2021', 48),
   (82, 60, '6/16/2020', 54),
   (32, 120, '3/16/2020', 6),
   (22, 63, '11/11/2020', 58),
   (15, 38, '2/1/2021', 14),
   (45, 15, '3/20/2020', 9),
   (78, 70, '8/13/2021', 5),
   (11, 120, '1/16/2021', 23),
   (62, 49, '1/21/2020', 34),
   (27, 43, '1/16/2020', 37),
   (22, 18, '3/24/2021', 93),
   (40, 51, '5/21/2021', 18),
   (82, 27, '4/8/2020', 83),
   (15, 25, '7/5/2021', 10),
   (67, 104, '5/24/2021', 28),
   (61, 28, '3/25/2020', 78),
   (27, 77, '3/20/2021', 53),
   (82, 93, '9/27/2020', 78),
   (33, 64, '9/29/2020', 73),
   (65, 27, '1/10/2020', 61),
   (65, 90, '2/26/2020', 87),
   (65, 17, '3/21/2021', 79),
   (83, 4, '12/22/2020', 34),
   (45, 134, '3/5/2020', 41),
   (26, 39, '1/28/2020', 72),
   (43, 128, '4/20/2021', 59),
   (70, 133, '4/8/2021', 16),
   (1, 162, '6/27/2020', 14),
   (11, 136, '3/16/2020', 6),
   (56, 48, '11/7/2020', 67),
   (13, 31, '9/22/2020', 11),
   (61, 150, '3/14/2020', 19),
   (24, 129, '11/10/2020', 55),
   (18, 43, '2/9/2021', 26),
   (60, 51, '1/7/2020', 16),
   (83, 50, '5/14/2021', 43),
   (88, 99, '12/19/2020', 90),
   (2, 116, '8/27/2020', 61),
   (78, 56, '1/10/2020', 66),
   (60, 161, '4/30/2020', 43),
   (14, 138, '5/12/2021', 36),
   (80, 28, '5/12/2021', 37),
   (55, 70, '3/5/2020', 26),
   (14, 26, '6/9/2021', 60),
   (13, 32, '6/12/2020', 37),
   (99, 133, '5/24/2021', 23),
   (72, 44, '6/1/2020', 30),
   (38, 60, '5/15/2021', 15),
   (7, 93, '1/22/2021', 75),
   (94, 42, '8/10/2021', 15),
   (83, 48, '8/11/2021', 74),
   (84, 127, '4/16/2020', 100),
   (78, 66, '6/5/2020', 79),
   (43, 158, '1/2/2020', 99),
   (75, 64, '6/9/2021', 49),
   (96, 2, '6/20/2020', 14),
   (43, 143, '8/15/2021', 24),
   (16, 113, '9/8/2020', 4),
   (54, 74, '2/2/2021', 38),
   (46, 149, '1/10/2020', 76),
   (87, 22, '1/10/2020', 22),
   (51, 74, '6/17/2020', 71),
   (99, 44, '1/8/2021', 100),
   (86, 133, '4/9/2020', 6),
   (100, 132, '4/13/2021', 40),
   (3, 85, '4/2/2020', 35),
   (53, 141, '12/3/2020', 54),
   (34, 104, '8/2/2020', 99),
   (96, 39, '2/25/2020', 64),
   (98, 33, '10/2/2020', 59),
   (69, 76, '5/8/2020', 83),
   (82, 24, '11/29/2020', 91),
   (98, 42, '9/19/2020', 46),
   (99, 54, '6/16/2020', 87),
   (9, 154, '11/6/2020', 39),
   (2, 5, '7/11/2020', 44),
   (76, 32, '4/26/2021', 54),
   (25, 69, '11/8/2020', 33),
   (74, 98, '12/18/2020', 2),
   (66, 98, '12/29/2020', 51),
   (94, 26, '5/22/2021', 28),
   (14, 95, '5/9/2020', 86),
   (92, 54, '4/15/2020', 70),
   (19, 148, '5/22/2021', 15),
   (83, 117, '5/10/2020', 14),
   (49, 20, '2/1/2020', 45),
   (90, 104, '11/19/2020', 34),
   (73, 128, '1/5/2021', 32),
   (29, 33, '1/24/2021', 5),
   (69, 126, '3/11/2020', 76),
   (86, 63, '11/2/2020', 8),
   (5, 150, '3/24/2021', 45),
   (21, 17, '11/1/2020', 87),
   (36, 20, '12/31/2020', 71),
   (64, 149, '4/13/2020', 17),
   (27, 63, '4/29/2020', 33),
   (97, 54, '6/22/2021', 96),
   (16, 25, '2/12/2021', 52),
   (15, 111, '6/13/2020', 48),
   (30, 121, '1/26/2021', 69),
   (32, 137, '11/26/2020', 38),
   (34, 28, '8/3/2020', 36),
   (90, 107, '4/10/2020', 100),
   (97, 95, '4/7/2021', 29),
   (30, 43, '10/3/2020', 30),
   (63, 66, '8/22/2020', 56),
   (90, 24, '2/15/2020', 73),
   (32, 75, '9/25/2020', 15),
   (15, 56, '5/4/2021', 20),
   (83, 153, '6/2/2021', 58),
   (90, 12, '6/24/2020', 75),
   (94, 143, '1/31/2021', 7),
   (40, 23, '2/5/2021', 71),
   (8, 129, '2/20/2020', 80),
   (22, 84, '5/16/2021', 44),
   (34, 44, '3/17/2021', 41),
   (13, 150, '4/12/2020', 73),
   (66, 79, '1/16/2020', 17),
   (86, 63, '12/16/2020', 97),
   (29, 115, '5/12/2020', 29),
   (3, 79, '3/17/2020', 19),
   (51, 34, '5/16/2020', 71),
   (11, 70, '2/8/2021', 45),
   (95, 119, '5/22/2020', 4),
   (30, 43, '10/20/2020', 74),
   (1, 110, '8/4/2020', 55),
   (67, 132, '6/27/2020', 59),
   (24, 26, '10/15/2020', 38),
   (64, 21, '3/4/2020', 55),
   (58, 139, '3/17/2021', 69),
   (90, 43, '7/13/2020', 14),
   (66, 72, '8/31/2020', 44),
   (6, 24, '6/7/2021', 61),
   (22, 25, '4/24/2021', 10),
   (50, 154, '6/25/2020', 65),
   (59, 128, '8/2/2020', 47),
   (35, 21, '5/26/2020', 54),
   (10, 44, '2/26/2020', 96),
   (67, 18, '8/3/2021', 69),
   (78, 140, '3/9/2021', 9),
   (100, 124, '7/26/2021', 61),
   (91, 114, '11/20/2020', 5),
   (97, 133, '10/30/2020', 50),
   (1, 99, '10/31/2020', 33),
   (53, 56, '2/5/2020', 60),
   (52, 13, '10/28/2020', 35),
   (72, 3, '12/18/2020', 59),
   (35, 11, '6/29/2020', 81),
   (24, 101, '12/11/2020', 83),
   (29, 113, '2/15/2021', 41),
   (49, 34, '6/30/2021', 24),
   (3, 20, '8/29/2020', 80),
   (25, 110, '6/18/2021', 97),
   (98, 36, '11/18/2020', 30),
   (2, 63, '3/4/2020', 64),
   (65, 27, '8/21/2020', 67),
   (51, 79, '8/4/2020', 86),
   (69, 50, '8/12/2020', 44),
   (1, 127, '3/21/2020', 44),
   (81, 96, '3/2/2021', 87),
   (20, 105, '2/9/2020', 42),
   (49, 113, '3/11/2021', 16),
   (75, 116, '10/18/2020', 51),
   (28, 70, '12/27/2020', 90),
   (86, 116, '7/10/2020', 28),
   (73, 160, '7/29/2020', 58),
   (26, 45, '5/6/2021', 44),
   (72, 47, '10/14/2020', 98),
   (90, 110, '2/1/2020', 4),
   (65, 141, '5/21/2020', 28),
   (74, 108, '12/24/2020', 51),
   (16, 68, '5/7/2020', 19),
   (16, 31, '1/29/2021', 88),
   (36, 45, '5/16/2020', 89),
   (37, 113, '7/28/2021', 94),
   (94, 112, '4/29/2020', 47),
   (67, 145, '7/27/2021', 30),
   (32, 156, '7/15/2020', 56),
   (60, 75, '1/26/2020', 27),
   (78, 30, '4/16/2020', 16),
   (41, 59, '1/22/2020', 55),
   (4, 158, '12/5/2020', 28),
   (91, 46, '2/19/2021', 28),
   (81, 9, '12/8/2020', 34),
   (41, 28, '12/17/2020', 30),
   (93, 138, '8/24/2020', 17),
   (91, 79, '10/12/2020', 6),
   (8, 23, '2/10/2021', 57),
   (33, 134, '9/28/2020', 83),
   (30, 133, '7/5/2020', 55),
   (57, 105, '3/13/2021', 86),
   (100, 109, '5/26/2020', 64),
   (82, 44, '9/30/2020', 51),
   (71, 121, '5/7/2020', 48),
   (63, 140, '1/15/2020', 25),
   (64, 61, '6/28/2021', 96),
   (23, 139, '4/26/2020', 87),
   (85, 14, '11/5/2020', 98),
   (30, 33, '4/18/2021', 100),
   (83, 92, '8/25/2020', 15),
   (89, 94, '8/17/2021', 69),
   (91, 144, '2/25/2020', 42),
   (64, 112, '8/16/2020', 26),
   (35, 64, '6/8/2021', 58),
   (68, 9, '6/29/2020', 67),
   (93, 111, '10/7/2020', 86),
   (79, 159, '11/9/2020', 59),
   (6, 103, '10/15/2020', 10),
   (46, 48, '10/24/2020', 8),
   (62, 77, '7/29/2021', 25),
   (17, 46, '7/15/2020', 55),
   (66, 124, '1/13/2021', 100),
   (1, 158, '4/25/2020', 69),
   (100, 143, '8/1/2021', 70),
   (79, 17, '7/30/2020', 5),
   (86, 105, '1/15/2021', 75),
   (31, 46, '1/8/2020', 63),
   (60, 152, '1/15/2020', 25),
   (55, 73, '12/13/2020', 32),
   (51, 101, '7/18/2020', 80),
   (88, 127, '7/9/2020', 45),
   (86, 72, '2/10/2021', 96),
   (77, 57, '5/12/2021', 95),
   (16, 85, '6/9/2020', 88),
   (61, 81, '5/29/2021', 54),
   (81, 26, '4/29/2020', 14),
   (19, 64, '9/23/2020', 87),
   (23, 40, '8/23/2020', 96),
   (56, 2, '10/28/2020', 54),
   (23, 9, '4/8/2020', 17),
   (50, 128, '2/23/2021', 18),
   (58, 123, '6/9/2020', 68),
   (100, 160, '8/18/2020', 6),
   (44, 31, '11/9/2020', 93),
   (4, 46, '5/4/2021', 22),
   (19, 62, '5/19/2020', 72),
   (77, 87, '3/7/2021', 11),
   (1, 19, '10/19/2020', 53),
   (38, 152, '3/9/2021', 14),
   (71, 68, '4/21/2021', 85),
   (57, 22, '11/1/2020', 13),
   (48, 22, '6/14/2021', 80),
   (73, 27, '4/8/2020', 2),
   (4, 90, '12/17/2020', 59),
   (69, 9, '8/26/2020', 66),
   (92, 80, '11/16/2020', 3),
   (30, 135, '3/17/2021', 78),
   (79, 75, '1/28/2020', 98),
   (81, 7, '3/2/2020', 8),
   (88, 81, '1/11/2021', 97),
   (76, 9, '1/7/2021', 65),
   (16, 25, '2/7/2021', 40),
   (54, 15, '11/23/2020', 55),
   (6, 161, '1/30/2020', 70),
   (68, 16, '1/28/2021', 48),
   (46, 42, '9/2/2020', 35),
   (70, 2, '6/17/2021', 35),
   (32, 31, '12/6/2020', 99),
   (76, 86, '5/6/2020', 43),
   (73, 28, '3/26/2021', 5),
   (56, 45, '6/4/2021', 89),
   (62, 97, '11/29/2020', 19),
   (90, 99, '9/15/2020', 41),
   (68, 86, '3/17/2020', 95),
   (52, 89, '11/22/2020', 56),
   (27, 86, '4/12/2020', 38),
   (18, 136, '1/17/2021', 53),
   (50, 150, '8/7/2021', 5),
   (41, 64, '1/20/2021', 93),
   (89, 150, '5/31/2021', 29),
   (11, 76, '11/19/2020', 23),
   (18, 81, '1/12/2021', 29),
   (71, 53, '6/6/2020', 67),
   (38, 75, '3/21/2021', 100),
   (87, 109, '5/9/2021', 59),
   (83, 16, '4/20/2021', 88),
   (8, 33, '8/3/2021', 54),
   (64, 13, '2/21/2021', 18),
   (4, 141, '3/1/2020', 21),
   (45, 30, '6/3/2020', 94),
   (50, 1, '5/15/2021', 2),
   (56, 130, '4/3/2020', 5),
   (61, 50, '3/23/2021', 83),
   (24, 154, '10/18/2020', 97),
   (7, 79, '10/21/2020', 98),
   (99, 81, '11/14/2020', 75),
   (9, 24, '11/20/2020', 5),
   (34, 30, '9/18/2020', 86),
   (20, 133, '5/4/2020', 11),
   (80, 120, '11/30/2020', 11),
   (1, 98, '8/12/2020', 22),
   (70, 34, '6/29/2021', 69),
   (57, 67, '4/7/2021', 82),
   (61, 68, '1/23/2021', 46),
   (7, 12, '1/28/2020', 93),
   (99, 25, '2/28/2021', 74),
   (14, 108, '4/18/2021', 40),
   (43, 151, '7/31/2021', 92),
   (36, 140, '8/6/2020', 24),
   (46, 81, '7/27/2020', 49),
   (29, 119, '5/5/2021', 39),
   (36, 57, '4/24/2020', 69),
   (77, 143, '11/28/2020', 49),
   (49, 66, '1/5/2020', 36),
   (5, 11, '10/13/2020', 4),
   (77, 58, '6/3/2020', 45),
   (9, 45, '4/1/2020', 62),
   (74, 55, '3/31/2021', 27),
   (93, 120, '4/2/2020', 56),
   (78, 137, '1/26/2021', 70),
   (89, 143, '4/4/2021', 36),
   (26, 68, '4/19/2021', 12),
   (2, 77, '3/25/2020', 67),
   (52, 161, '11/11/2020', 43),
   (12, 6, '11/28/2020', 23),
   (75, 31, '5/1/2021', 87),
   (92, 146, '11/27/2020', 59),
   (12, 99, '3/28/2020', 98),
   (68, 104, '1/11/2020', 48),
   (5, 132, '5/16/2020', 37),
   (63, 133, '5/11/2020', 76),
   (53, 95, '6/16/2020', 32),
   (26, 43, '7/10/2021', 48),
   (84, 101, '6/25/2020', 62),
   (27, 51, '12/31/2020', 87),
   (69, 33, '2/10/2021', 92),
   (96, 93, '3/11/2020', 24),
   (61, 84, '10/28/2020', 6),
   (5, 146, '6/14/2020', 55),
   (42, 10, '11/6/2020', 100),
   (53, 159, '6/11/2021', 95),
   (50, 38, '5/18/2021', 69),
   (48, 70, '8/15/2020', 81),
   (55, 143, '1/3/2020', 76),
   (68, 39, '6/19/2020', 39),
   (91, 74, '7/29/2020', 3),
   (36, 89, '5/13/2021', 21),
   (36, 136, '4/1/2021', 9),
   (42, 15, '5/18/2021', 55),
   (30, 75, '7/22/2021', 44),
   (28, 143, '5/31/2021', 81),
   (55, 119, '1/10/2021', 64),
   (79, 127, '12/18/2020', 78),
   (96, 30, '3/24/2020', 50),
   (82, 24, '9/6/2020', 12),
   (88, 73, '2/24/2020', 23),
   (25, 50, '2/20/2020', 14),
   (1, 159, '9/18/2020', 56),
   (82, 16, '1/28/2021', 76),
   (34, 103, '6/16/2020', 37),
   (97, 35, '7/6/2020', 94),
   (53, 69, '3/7/2020', 36),
   (82, 13, '3/13/2021', 45),
   (8, 6, '7/8/2020', 74),
   (56, 158, '8/20/2020', 19),
   (72, 46, '8/27/2020', 53),
   (44, 122, '10/30/2020', 40),
   (49, 36, '7/8/2021', 39),
   (85, 12, '4/2/2020', 60),
   (66, 54, '1/15/2020', 34),
   (75, 47, '4/20/2020', 48),
   (88, 118, '4/4/2021', 61),
   (7, 89, '12/29/2020', 7),
   (15, 47, '5/8/2020', 59),
   (63, 55, '9/30/2020', 14),
   (69, 62, '7/15/2021', 84),
   (87, 129, '6/30/2020', 4),
   (43, 21, '8/6/2021', 1),
   (81, 78, '6/28/2020', 76),
   (83, 133, '9/8/2020', 86),
   (6, 102, '5/2/2021', 37),
   (55, 67, '6/2/2021', 36),
   (60, 72, '2/17/2021', 65),
   (37, 142, '8/13/2021', 44),
   (10, 92, '12/4/2020', 6),
   (79, 43, '9/5/2020', 7),
   (15, 146, '2/25/2020', 92),
   (68, 34, '4/1/2021', 86),
   (75, 113, '1/27/2020', 45),
   (37, 31, '6/26/2021', 22),
   (49, 108, '6/3/2020', 74),
   (1, 66, '12/16/2020', 25),
   (13, 124, '12/31/2020', 78),
   (27, 30, '7/5/2021', 86),
   (61, 130, '3/11/2021', 50),
   (53, 131, '5/7/2021', 24),
   (19, 64, '2/19/2020', 61),
   (87, 32, '1/25/2020', 48),
   (59, 28, '3/22/2020', 42),
   (63, 85, '11/1/2020', 75),
   (44, 118, '1/27/2020', 31),
   (71, 37, '4/22/2020', 8),
   (27, 61, '1/28/2021', 67),
   (83, 96, '1/27/2021', 76),
   (98, 23, '10/9/2020', 34),
   (80, 9, '1/24/2020', 18),
   (77, 95, '5/11/2020', 1),
   (36, 122, '7/20/2021', 58),
   (24, 157, '4/14/2020', 30),
   (81, 126, '10/16/2020', 98),
   (35, 49, '3/8/2021', 82),
   (91, 18, '4/13/2020', 1),
   (100, 43, '5/6/2020', 76),
   (50, 135, '1/23/2020', 57),
   (51, 87, '12/10/2020', 85),
   (7, 116, '3/18/2020', 21),
   (83, 152, '7/27/2021', 23),
   (46, 66, '12/12/2020', 76),
   (51, 152, '9/1/2020', 78),
   (3, 57, '1/2/2021', 75),
   (3, 135, '5/15/2020', 33),
   (78, 154, '8/30/2020', 96),
   (95, 12, '3/20/2021', 83),
   (3, 53, '9/2/2020', 24),
   (10, 48, '2/8/2020', 15),
   (67, 61, '7/2/2020', 32),
   (1, 1, '5/16/2021', 78),
   (98, 78, '2/26/2021', 9),
   (3, 112, '6/17/2021', 79),
   (46, 54, '7/1/2021', 78),
   (30, 13, '6/11/2020', 46),
   (90, 98, '6/11/2020', 30),
   (63, 151, '11/29/2020', 23),
   (42, 138, '8/10/2020', 21),
   (86, 93, '5/8/2021', 44),
   (33, 64, '6/18/2021', 67),
   (83, 128, '5/30/2021', 14),
   (56, 14, '5/23/2021', 37),
   (54, 17, '5/24/2021', 38),
   (87, 51, '3/12/2020', 1),
   (44, 10, '6/26/2020', 27),
   (44, 64, '11/19/2020', 34),
   (64, 68, '5/30/2021', 20),
   (32, 26, '5/26/2021', 80),
   (6, 37, '5/18/2020', 66),
   (46, 88, '6/22/2021', 91),
   (60, 74, '12/30/2020', 10),
   (72, 61, '2/2/2020', 2),
   (88, 21, '7/11/2020', 1),
   (76, 37, '9/21/2020', 62),
   (12, 69, '10/29/2020', 29),
   (60, 37, '7/21/2021', 12),
   (71, 38, '2/1/2020', 84),
   (59, 95, '5/9/2021', 92),
   (51, 55, '6/5/2021', 33),
   (41, 45, '3/3/2021', 82),
   (70, 5, '3/19/2020', 54),
   (86, 7, '11/6/2020', 76),
   (96, 79, '6/28/2021', 100),
   (79, 134, '10/28/2020', 42),
   (33, 80, '12/21/2020', 19),
   (15, 131, '2/11/2020', 70),
   (60, 119, '7/6/2021', 67),
   (90, 48, '10/31/2020', 71),
   (19, 66, '6/17/2020', 19),
   (40, 136, '9/15/2020', 63),
   (74, 81, '8/31/2020', 85),
   (88, 66, '4/27/2021', 60),
   (63, 52, '12/12/2020', 76),
   (51, 98, '4/4/2020', 62),
   (71, 4, '3/18/2020', 23),
   (40, 95, '1/24/2021', 77),
   (78, 159, '8/1/2021', 64),
   (70, 137, '2/27/2021', 38),
   (50, 162, '10/9/2020', 86),
   (8, 151, '8/18/2020', 46),
   (78, 75, '7/27/2020', 97),
   (23, 131, '2/24/2021', 52),
   (68, 60, '11/11/2020', 36),
   (80, 77, '4/26/2021', 80),
   (10, 99, '4/11/2021', 89),
   (61, 77, '6/14/2021', 76),
   (58, 137, '4/10/2021', 77),
   (80, 82, '7/19/2021', 67),
   (19, 46, '7/21/2021', 11),
   (82, 121, '3/23/2020', 50),
   (88, 149, '5/18/2020', 87),
   (47, 112, '4/16/2021', 17),
   (31, 120, '8/24/2020', 77),
   (7, 56, '1/8/2020', 74),
   (60, 85, '11/23/2020', 10),
   (65, 75, '3/31/2020', 59),
   (35, 47, '9/10/2020', 100),
   (45, 121, '5/21/2021', 94),
   (98, 94, '5/19/2020', 76),
   (49, 37, '6/30/2021', 63),
   (1, 39, '3/6/2021', 93),
   (55, 12, '8/13/2020', 20),
   (100, 26, '4/11/2021', 21),
   (21, 87, '2/2/2020', 74),
   (77, 127, '11/25/2020', 21),
   (54, 93, '3/20/2021', 34),
   (37, 69, '6/13/2020', 91),
   (31, 93, '2/13/2021', 91),
   (37, 45, '12/27/2020', 52),
   (58, 24, '3/25/2021', 24),
   (69, 13, '6/22/2021', 7),
   (33, 132, '12/19/2020', 47),
   (67, 80, '4/19/2020', 65),
   (26, 131, '1/21/2021', 41),
   (71, 44, '8/21/2020', 3),
   (72, 6, '9/13/2020', 46),
   (76, 161, '8/1/2020', 8),
   (81, 55, '6/6/2020', 93),
   (60, 5, '4/23/2021', 62),
   (96, 51, '5/12/2020', 90),
   (56, 83, '9/16/2020', 17),
   (1, 58, '11/2/2020', 7),
   (11, 109, '2/15/2021', 48),
   (39, 121, '1/25/2020', 65),
   (35, 123, '5/22/2020', 7),
   (66, 145, '7/10/2020', 21),
   (68, 43, '12/26/2020', 40),
   (94, 11, '8/24/2020', 38),
   (9, 63, '5/29/2020', 78),
   (33, 5, '12/29/2020', 11),
   (26, 73, '5/8/2021', 85),
   (5, 42, '3/10/2020', 100),
   (33, 158, '1/4/2021', 76),
   (11, 108, '9/27/2020', 87),
   (58, 57, '4/28/2020', 33),
   (46, 21, '7/10/2020', 36),
   (2, 45, '11/17/2020', 16),
   (20, 89, '6/28/2020', 55),
   (90, 41, '4/10/2020', 19),
   (17, 151, '4/24/2020', 35),
   (90, 153, '4/17/2021', 78),
   (58, 74, '7/2/2021', 60),
   (32, 54, '1/23/2020', 1),
   (34, 55, '6/23/2020', 69),
   (38, 33, '6/8/2020', 82),
   (44, 77, '8/1/2021', 81),
   (24, 89, '12/11/2020', 70),
   (43, 112, '7/30/2021', 2),
   (23, 114, '12/23/2020', 50),
   (49, 32, '7/11/2021', 92),
   (92, 117, '6/25/2020', 63),
   (57, 65, '2/20/2021', 10),
   (72, 38, '5/28/2021', 41),
   (59, 115, '6/13/2020', 12),
   (84, 70, '4/13/2021', 18),
   (40, 25, '5/27/2020', 45),
   (97, 131, '3/14/2021', 48),
   (89, 154, '7/17/2021', 33),
   (85, 161, '3/13/2021', 47),
   (12, 149, '9/22/2020', 37),
   (94, 2, '9/20/2020', 69),
   (68, 135, '3/4/2021', 4),
   (63, 160, '12/7/2020', 73),
   (34, 157, '5/9/2020', 92),
   (27, 96, '3/12/2021', 54),
   (57, 107, '9/9/2020', 50),
   (68, 15, '1/3/2021', 77),
   (21, 34, '3/15/2020', 30),
   (3, 20, '1/25/2020', 40),
   (12, 159, '5/22/2021', 76),
   (71, 36, '3/27/2021', 18),
   (10, 96, '4/12/2021', 22),
   (51, 3, '8/10/2020', 15),
   (49, 37, '2/15/2021', 40),
   (23, 114, '7/31/2021', 69),
   (66, 86, '3/3/2020', 43),
   (96, 73, '6/27/2021', 3),
   (91, 123, '4/10/2021', 85),
   (24, 86, '5/13/2020', 50),
   (9, 134, '7/21/2020', 27),
   (35, 123, '4/29/2021', 95),
   (17, 90, '1/21/2021', 83),
   (33, 102, '9/14/2020', 31),
   (51, 158, '3/28/2021', 7),
   (83, 87, '6/26/2021', 65),
   (18, 33, '10/20/2020', 16),
   (98, 52, '8/16/2020', 89),
   (23, 54, '6/6/2020', 49),
   (55, 63, '1/16/2020', 3),
   (7, 85, '1/12/2020', 76),
   (55, 134, '3/31/2021', 97),
   (94, 120, '7/27/2021', 57),
   (67, 129, '9/13/2020', 70),
   (98, 154, '6/29/2021', 33),
   (100, 102, '4/21/2020', 92),
   (64, 56, '12/12/2020', 56),
   (45, 2, '3/10/2021', 57),
   (62, 78, '6/22/2021', 53),
   (15, 52, '1/29/2020', 3),
   (29, 13, '7/2/2020', 72),
   (96, 140, '1/13/2021', 27),
   (2, 57, '12/27/2020', 79),
   (48, 5, '2/7/2020', 54),
   (58, 85, '10/16/2020', 10),
   (86, 73, '7/10/2021', 60),
   (38, 159, '2/14/2021', 67),
   (85, 159, '11/8/2020', 55),
   (92, 2, '3/3/2020', 59),
   (49, 51, '10/13/2020', 83),
   (65, 83, '4/11/2020', 99),
   (70, 59, '3/6/2021', 85),
   (7, 55, '1/6/2021', 22),
   (45, 148, '12/4/2020', 30),
   (65, 50, '5/14/2020', 42),
   (27, 57, '6/29/2021', 11),
   (53, 10, '1/21/2021', 59);