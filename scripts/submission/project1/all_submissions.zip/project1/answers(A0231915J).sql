/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                     */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* the entity set E1 to be NETFLIX memberships, the entity set E2 to be 
NETFLIX online film and television works, and the relationship set R to be 
the record of which membership playing which video.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS memberships(
	fisrt_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	membership_id VARCHAR(16) PRIMARY KEY,
	email CHAR(64) UNIQUE NOT NULL);


CREATE TABLE IF NOT EXISTS film_and_television_works(
	work_name VARCHAR(128) PRIMARY KEY,
	work_id VARCHAR(16) UNIQUE NOT NULL,
	since DATE NOT NULL,
	rating DECIMAL(3,1) NOT NULL);

CREATE TABLE IF NOT EXISTS videos_play(
	membership_id VARCHAR(16)
	REFERENCES memberships(membership_id)
		ON UPDATE CASCADE
		ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED,
	video_name VARCHAR(128)
	REFERENCES film_and_television_works(work_name)
		ON UPDATE CASCADE
		ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED);
		

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Dimitri', 'Granger', '23-106-7189', 'dgrangerl0@intel.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Aluino', 'Rubroe', '16-891-2685', 'arubroe1@storify.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Jaquelyn', 'McElory', '22-580-8446', 'jmcelory2@shinystat.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Liesa', 'Woolland', '38-217-4576', 'lwoolland3@wiley.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Edlin', 'Ibbett', '93-246-4240', 'eibbett4@hud.gov');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Binny', 'Crisp', '84-245-0606', 'bcrisp5@icq.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Raleigh', 'Lagne', '93-039-3401', 'rlagne6@businessweek.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Joell', 'Robertucci', '53-242-1374', 'jrobertucci7@oracle.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Andreana', 'Crann', '52-429-7259', 'acrann8@mediafire.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Blinni', 'Lerner', '68-397-2239', 'blerner9@blogspot.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Reuben', 'Paddington', '43-630-3875', 'rpaddingtona@reddit.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Nataline', 'Hlavecek', '59-241-7554', 'nhlavecekb@nih.gov');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Annabelle', 'Featherby', '02-079-2934', 'afeatherbyc@drupal.org');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Costa', 'Cordaroy', '13-440-4928', 'ccordaroyd@eventbrite.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Trumann', 'Macartney', '00-355-6452', 'tmacartneye@over-blog.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Hobart', 'Plascott', '48-226-5321', 'hplascottf@usnews.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Bernetta', 'Snadden', '09-331-5887', 'bsnaddeng@dell.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Janenna', 'Bladen', '87-782-2785', 'jbladenh@weather.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Craig', 'd'' Elboux', '99-603-3129', 'cdelbouxi@issuu.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Avictor', 'Rubinovici', '11-117-8928', 'arubinovicij@cbsnews.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('David', 'Antoniewski', '21-613-8516', 'dantoniewskik@wufoo.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Brock', 'Lambrick', '62-164-1602', 'blambrickl@jiathis.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Nanice', 'Mc Ilwrick', '94-513-3861', 'nmcilwrickm@yale.edu');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Dur', 'Derrick', '31-207-5554', 'dderrickn@cbc.ca');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Carole', 'Bellefonte', '76-343-1515', 'cbellefonteo@chron.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Ethelda', 'Goodreid', '56-252-0312', 'egoodreidp@apache.org');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Inglebert', 'Casel', '58-892-2593', 'icaselq@google.ca');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Caitrin', 'Eagles', '70-234-7961', 'ceaglesr@umich.edu');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Tove', 'Twiddell', '56-811-3706', 'ttwiddells@weather.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Doreen', 'Tresise', '13-073-0653', 'dtresiset@google.nl');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Kizzee', 'Layhe', '51-131-1470', 'klayheu@linkedin.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Mathilda', 'Dimmne', '89-727-3561', 'mdimmnev@forbes.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Zaneta', 'Batalle', '40-257-0992', 'zbatallew@xinhuanet.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Marcella', 'McLugish', '70-730-5864', 'mmclugishx@networkadvertising.org');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Quent', 'Dashper', '34-048-7791', 'qdashpery@360.cn');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Ninnetta', 'Honisch', '73-954-2876', 'nhonischz@telegraph.co.uk');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Ginevra', 'Ewbanks', '90-622-9639', 'gewbanks10@cloudflare.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Otes', 'Thornally', '80-915-3581', 'othornally11@mail.ru');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Wendeline', 'Samwayes', '35-629-4307', 'wsamwayes12@nature.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Gratiana', 'Calafate', '30-996-9442', 'gcalafate13@illinois.edu');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Abra', 'Egleton', '89-695-4913', 'aegleton14@uiuc.edu');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Beret', 'Vian', '71-548-7548', 'bvian15@vinaora.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Joela', 'Cattanach', '25-261-9411', 'jcattanach16@nsw.gov.au');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Brenden', 'Venners', '29-250-3799', 'bvenners17@theatlantic.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Forster', 'While', '89-848-2785', 'fwhile18@t-online.de');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Staford', 'Winslet', '36-673-5765', 'swinslet19@webs.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Carmella', 'Rounds', '85-712-4828', 'crounds1a@bbb.org');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Janie', 'Jozsef', '87-201-0814', 'jjozsef1b@ehow.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Theobald', 'Northridge', '55-821-3600', 'tnorthridge1c@dmoz.org');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Electra', 'Newlands', '24-567-3577', 'enewlands1d@multiply.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Matthieu', 'Croley', '27-182-9196', 'mcroley1e@comsenz.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Lanie', 'Banasik', '60-157-1516', 'lbanasik1f@friendfeed.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Arv', 'Grzegorczyk', '18-639-9547', 'agrzegorczyk1g@mayoclinic.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Rianon', 'Crepin', '16-769-5505', 'rcrepin1h@chronoengine.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Lisa', 'Coverlyn', '39-600-6804', 'lcoverlyn1i@nbcnews.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Hube', 'Holdall', '95-110-8407', 'hholdall1j@tinypic.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Reggie', 'Stelfox', '61-340-0453', 'rstelfox1k@theatlantic.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Katerina', 'Cottem', '47-080-5395', 'kcottem1l@mapy.cz');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Delcina', 'Robertazzi', '88-317-0115', 'drobertazzi1m@360.cn');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Warden', 'Jedrzej', '17-951-8497', 'wjedrzej1n@jigsy.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Umberto', 'Elson', '34-785-8376', 'uelson1o@ebay.co.uk');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Allys', 'Short', '59-396-9188', 'ashort1p@tinypic.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Suki', 'McArley', '60-971-1636', 'smcarley1q@hhs.gov');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Ricki', 'Leversha', '42-857-8699', 'rleversha1r@skyrock.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Webb', 'Nutbrown', '61-688-4786', 'wnutbrown1s@oracle.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Alexis', 'Standen', '50-279-5657', 'astanden1t@netlog.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Dorothea', 'Bradfield', '41-667-5661', 'dbradfield1u@github.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Alisander', 'Balden', '24-673-9301', 'abalden1v@mysql.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Buck', 'Huck', '60-744-5407', 'bhuck1w@harvard.edu');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Goldi', 'Templeton', '46-841-3303', 'gtempleton1x@odnoklassniki.ru');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Donavon', 'Esgate', '97-735-9618', 'desgate1y@census.gov');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Lira', 'Cristobal', '09-611-7324', 'lcristobal1z@wp.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Farleigh', 'Robbings', '53-101-6590', 'frobbings20@toplist.cz');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Gwenore', 'Malim', '51-104-4624', 'gmalim21@dmoz.org');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Aleta', 'Ends', '37-393-5500', 'aends22@wordpress.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Raddie', 'Stobbie', '68-013-5957', 'rstobbie23@posterous.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Dot', 'Stapels', '99-415-4021', 'dstapels24@nymag.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Berk', 'Ferro', '92-548-7150', 'bferro25@free.fr');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Emlen', 'Budnik', '18-858-5814', 'ebudnik26@goo.ne.jp');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Adriano', 'McNaughton', '02-123-8344', 'amcnaughton27@tmall.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Merla', 'Wharmby', '46-012-4575', 'mwharmby28@discovery.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Jacklyn', 'Grzegorzewski', '82-601-8061', 'jgrzegorzewski29@sogou.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Case', 'Grundwater', '58-737-9413', 'cgrundwater2a@cpanel.net');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Arnold', 'de Quincey', '64-530-9305', 'adequincey2b@smugmug.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Antonella', 'Batrop', '82-489-9519', 'abatrop2c@yale.edu');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Marget', 'Peddersen', '51-118-7428', 'mpeddersen2d@ihg.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Webster', 'Shovel', '08-228-3244', 'wshovel2e@loc.gov');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Fanchette', 'Prangle', '89-918-8501', 'fprangle2f@salon.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Deina', 'Farnon', '76-986-0022', 'dfarnon2g@google.ru');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Romy', 'Avard', '80-612-0896', 'ravard2h@phoca.cz');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Peggi', 'Oxford', '95-086-7226', 'poxford2i@cbslocal.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Emlen', 'Hunday', '07-433-5118', 'ehunday2j@miitbeian.gov.cn');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Crysta', 'Brotherhed', '17-829-8187', 'cbrotherhed2k@deviantart.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Samantha', 'Titterrell', '51-659-2846', 'stitterrell2l@alexa.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Gary', 'Boards', '74-017-4268', 'gboards2m@devhub.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Aharon', 'Harding', '92-208-6628', 'aharding2n@ebay.co.uk');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Reba', 'Martinie', '86-677-3904', 'rmartinie2o@si.edu');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Lyndell', 'Couch', '46-528-2097', 'lcouch2p@indiegogo.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Mata', 'Halvorsen', '55-356-2190', 'mhalvorsen2q@dailymotion.com');
insert into memberships (fisrt_name, last_name, membership_id, email) values ('Drucill', 'Hairsine', '56-937-4023', 'dhairsine2r@archive.org');

insert into film_and_television_works (work_name, work_id, since, rating) values ('Facing Windows (Finestra di fronte, La)', '7838164427', '2015-04-08', 8.6);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Diary of a Shinjuku Thief (Shinjuku dorobo nikki)', '7749209948', '2019-03-27', 0.5);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Captive, The (Prisonnière, La)', '2106937148', '2018-01-21', 7.7);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Cold Moon (Lune froide)', '1263800610', '2018-07-05', 4.2);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Beaches', '6437504749', '2021-06-12', 1.0);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Intimidation', '2723591883', '2019-09-16', 1.1);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Oki''s Movie (Ok-hui-ui yeonghwa)', '5426677255', '2018-09-22', 5.1);
insert into film_and_television_works (work_name, work_id, since, rating) values ('If Only', '6727400032', '2019-10-14', 1.4);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Black Sunday', '2667293541', '2017-05-27', 5.1);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Street Trash', '3458429980', '2015-10-20', 1.7);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Tommy', '0942770846', '2019-05-12', 5.6);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Restless (Levottomat)', '2540529259', '2018-07-20', 4.5);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Hunt for Red October, The', '5888354015', '2016-08-12', 3.9);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Thing About My Folks, The', '3977435310', '2016-12-04', 2.3);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Beautiful Lies (De vrais mensonges) (Full Treatment)', '6351484146', '2018-01-16', 9.3);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Silent Rage', '2725579139', '2015-11-16', 9.5);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Puppet Master: The Legacy (Puppet Master 8)', '6097185154', '2021-05-10', 1.8);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Wedding Party, The (Die Bluthochzeit)', '8490524319', '2017-02-09', 1.0);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Beloved/Friend (a.k.a. Amigo/Amado) (Amic/Amat)', '0710244371', '2018-06-12', 3.1);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Way Ahead, The (a.k.a. The Immortal Battalion)', '0346192749', '2015-07-13', 1.2);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Madigan', '4787904949', '2021-07-26', 5.0);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Party Girl', '8876198512', '2017-06-13', 2.5);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Cement Garden, The', '9623028415', '2018-11-09', 2.5);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Orgazmo', '3208425147', '2021-04-21', 5.4);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Ninth Gate, The', '9861830197', '2016-01-15', 1.7);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Day of the Crows, The (Le jour des corneilles)', '2357510412', '2015-04-20', 5.7);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Ankur (The Seedling)', '2616596725', '2019-02-20', 7.6);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Sweeney Todd: The Demon Barber of Fleet Street', '2114686280', '2018-02-21', 8.1);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Great Bank Hoax, The', '6488233734', '2021-02-18', 2.7);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Twice Upon a Time', '2973725348', '2016-06-07', 0.1);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Carnage', '6046862086', '2015-03-16', 2.0);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Breed Apart, A', '4474262352', '2021-08-05', 8.9);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Thief of Bagdad, The', '7518782839', '2015-01-11', 6.6);
insert into film_and_television_works (work_name, work_id, since, rating) values ('African Queen, The', '1547643374', '2018-07-06', 1.0);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Reap the Wild Wind', '7288534790', '2015-12-30', 1.5);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Swamp, The (Ciénaga, La)', '3394292629', '2020-01-28', 1.9);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Go', '4875913532', '2020-05-13', 9.5);
insert into film_and_television_works (work_name, work_id, since, rating) values ('The Wedding Ringer', '6557751026', '2018-07-01', 2.4);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Go Get Some Rosemary (Daddy Longlegs)', '5014676375', '2020-04-15', 5.4);
insert into film_and_television_works (work_name, work_id, since, rating) values ('It Came from Outer Space', '8571188521', '2016-01-27', 6.8);
insert into film_and_television_works (work_name, work_id, since, rating) values ('In Bloom (Grzeli nateli dgeebi)', '0388313331', '2015-01-08', 4.9);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Grotesque', '6150561186', '2021-01-17', 2.8);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Bob Saget: That Ain''t Right', '4203340209', '2020-11-16', 5.0);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Boy and the Pirates, The', '2220874907', '2015-08-31', 8.6);
insert into film_and_television_works (work_name, work_id, since, rating) values ('The Hire: Star, The', '0807958271', '2016-09-25', 0.1);
insert into film_and_television_works (work_name, work_id, since, rating) values ('CrissCross', '0246579021', '2016-03-26', 7.5);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Mezzo Forte', '0000559423', '2019-09-15', 4.3);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Dark Touch', '3462710117', '2016-02-24', 8.7);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Brainstorm (Bicho de Sete Cabeças)', '8033549173', '2018-04-10', 8.0);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Che: Part One', '7878865000', '2015-12-25', 0.9);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Training Day', '8862131003', '2015-11-20', 1.0);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Coach Carter', '6896828099', '2020-10-16', 4.2);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Yolki', '1877748889', '2015-09-28', 0.8);
insert into film_and_television_works (work_name, work_id, since, rating) values ('In Country', '5697065124', '2017-07-03', 1.0);
insert into film_and_television_works (work_name, work_id, since, rating) values ('My Brother Tom', '0435971964', '2019-03-17', 4.4);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Four Sons', '2977843221', '2020-03-14', 6.0);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Hot Lead and Cold Feet', '1876364831', '2015-11-07', 5.5);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Frozen Ground, The', '8208706507', '2016-04-12', 7.7);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Cry ''Havoc''', '7269600791', '2018-04-30', 2.3);
insert into film_and_television_works (work_name, work_id, since, rating) values ('As Cool As I Am', '8920076472', '2020-05-11', 4.2);
insert into film_and_television_works (work_name, work_id, since, rating) values ('True Story of Jesse James, The', '0269001328', '2020-12-25', 6.2);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Farsan', '4516954265', '2018-12-26', 4.9);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Sesame Street Presents Follow That Bird', '9931635541', '2019-10-31', 5.8);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Murderous Maids (Blessures assassines, Les)', '7266268265', '2016-02-29', 7.0);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Barbarian Queen II: The Empress Strikes Back', '2459205619', '2015-04-05', 7.7);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Revenge of the Nerds', '6011129390', '2020-01-14', 4.1);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Mondo Hollywood', '8195860001', '2015-08-29', 0.7);
insert into film_and_television_works (work_name, work_id, since, rating) values ('From Dusk Till Dawn 2: Texas Blood Money ', '6562512913', '2015-03-21', 1.1);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Little Monsters', '5295236145', '2016-04-05', 5.8);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Children of the Living Dead', '5483318439', '2019-12-19', 2.0);
insert into film_and_television_works (work_name, work_id, since, rating) values ('50 First Dates', '2221052498', '2018-04-10', 5.1);
insert into film_and_television_works (work_name, work_id, since, rating) values ('American Horror House (Sorority Horror House)', '8807630478', '2016-04-18', 3.5);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Dr. Seuss'' The Lorax', '3755572826', '2017-04-06', 1.9);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Trick or Treat', '8495198584', '2020-06-27', 5.6);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Defense of the Realm', '8085710579', '2018-05-13', 0.6);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Get Well Soon', '5874336923', '2015-06-19', 0.7);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Kept Husbands', '4298034062', '2016-04-18', 0.5);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Final, The', '4120020436', '2021-02-12', 5.1);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Many Adventures of Winnie the Pooh, The', '2269719573', '2021-08-11', 2.9);
insert into film_and_television_works (work_name, work_id, since, rating) values ('How the West Was Won', '7416119642', '2020-04-14', 2.9);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Friday the 13th Part VIII: Jason Takes Manhattan', '5935348624', '2019-11-22', 8.6);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Before Night Falls', '9388127404', '2017-11-14', 0.5);
insert into film_and_television_works (work_name, work_id, since, rating) values ('The Mayor of Casterbridge', '3194791427', '2021-07-15', 8.2);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Sapphire', '9455128292', '2020-04-27', 5.7);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Biker Boyz', '5638566880', '2017-06-06', 4.3);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Outpost', '0074500473', '2019-03-08', 9.5);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Babes in Arms', '8762581198', '2020-03-28', 9.9);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Iceman, The', '4090782597', '2016-10-05', 7.3);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Mercy ', '2419763130', '2020-04-06', 4.5);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Amityville Horror, The', '4921090491', '2020-12-17', 1.4);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Presidentintekijät', '7206843972', '2019-09-05', 0.2);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Deadly Circuit (Mortelle randonnée)', '6276341649', '2018-09-25', 3.9);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Margaret''s Museum', '2956181963', '2015-10-19', 1.1);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Life of Oharu, The (Saikaku ichidai onna)', '4471883658', '2018-04-06', 8.4);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Wackness, The', '0663217466', '2019-02-11', 1.1);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Santa''s Pocket Watch', '1895457386', '2016-11-13', 8.4);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Belle and Sebastien (Belle et Sébastien)', '5027161336', '2016-03-01', 8.1);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Fifty Shades of Grey', '1213402557', '2018-07-25', 2.6);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Phantom of the Opera, The', '5392222838', '2018-01-18', 7.9);
insert into film_and_television_works (work_name, work_id, since, rating) values ('Reclaim', '3935167725', '2015-11-11', 1.9);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into videos_play
select memberships.membership_id,film_and_television_works.work_name 
from(select cast((random()*50)as int) as join_key,membership_id from memberships)
memberships inner join
(select cast((random()*50)as int) as join_key,work_name from film_and_television_works)
film_and_television_works
on memberships.join_key=film_and_television_works.join_key
limit 101;

select *
from videos_play;











