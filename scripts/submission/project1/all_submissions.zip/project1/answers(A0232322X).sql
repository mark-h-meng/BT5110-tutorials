/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The Central Intelligence Agency (CIA) has a database comprising records of 100 individuals, who are prospects of being a spy.  
The database contains the following tables, which have the attributes as mentioned below along-side each table:
1. Table ‘spy’:  Contains details of the individual such as first name, last name and email ID (as the primary key)
2. Table ‘website’:  Contains the URL most viewed by the individual/ prospective spy and IP address (as the primary key) through which it is viewed 
3. Table ‘viewed’ (relationship table): Associates the email ID (foreign key) of the prospect with his/ her system’s IP address (foreign key)

The task is to create the aforementioned entity tables 'spy', 'website' and the relationship table 'viewed'. 
The entity tables will contain 100 records each while the relationship table 'viewed' will generate records 
through the relationship between two entity tables (10% chosen at random, of the possible relationships). 

The code for the following questions has been written in PostgreSQL.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

DROP 
  TABLE IF EXISTS spy, 
  website, 
  viewed;
CREATE TABLE spy(
  first_name VARCHAR(64) NOT NULL, 
  last_name VARCHAR(64) NOT NULL, 
  email VARCHAR(32) PRIMARY KEY
);
CREATE TABLE website(
  url VARCHAR(100) NOT NULL, 
  ipaddress VARCHAR(32) PRIMARY KEY
);
CREATE TABLE viewed(
  email VARCHAR(32) REFERENCES spy(email), 
  ipaddress VARCHAR(32) REFERENCES website(ipaddress)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* Inserting records into 'spy' table: */

insert into spy (first_name, last_name, email) values ('Shannen', 'Daniely', 'sdaniely0@yahoo.com');
insert into spy (first_name, last_name, email) values ('Leonard', 'Gypps', 'lgypps1@unesco.org');
insert into spy (first_name, last_name, email) values ('Jedediah', 'Freeman', 'jfreeman2@fotki.com');
insert into spy (first_name, last_name, email) values ('Zacharie', 'Vobes', 'zvobes3@4shared.com');
insert into spy (first_name, last_name, email) values ('Mallory', 'Cornelis', 'mcornelis4@dell.com');
insert into spy (first_name, last_name, email) values ('Polly', 'Friend', 'pfriend5@google.fr');
insert into spy (first_name, last_name, email) values ('Cobbie', 'Innerstone', 'cinnerstone6@wordpress.org');
insert into spy (first_name, last_name, email) values ('Si', 'Errichi', 'serrichi7@google.nl');
insert into spy (first_name, last_name, email) values ('Jami', 'Thireau', 'jthireau8@mapquest.com');
insert into spy (first_name, last_name, email) values ('Stillman', 'Pettigrew', 'spettigrew9@bluehost.com');
insert into spy (first_name, last_name, email) values ('Courtney', 'Gaukrodge', 'cgaukrodgea@posterous.com');
insert into spy (first_name, last_name, email) values ('Maure', 'Dinan', 'mdinanb@cbc.ca');
insert into spy (first_name, last_name, email) values ('Lek', 'Robinson', 'lrobinsonc@nba.com');
insert into spy (first_name, last_name, email) values ('Grier', 'Flanagan', 'gflanagand@telegraph.co.uk');
insert into spy (first_name, last_name, email) values ('Brenn', 'Ebrall', 'bebralle@vk.com');
insert into spy (first_name, last_name, email) values ('Galven', 'Kingsnod', 'gkingsnodf@examiner.com');
insert into spy (first_name, last_name, email) values ('Nicoline', 'Cardero', 'ncarderog@trellian.com');
insert into spy (first_name, last_name, email) values ('Torre', 'Fonzone', 'tfonzoneh@marketwatch.com');
insert into spy (first_name, last_name, email) values ('Sherri', 'Cooley', 'scooleyi@ebay.co.uk');
insert into spy (first_name, last_name, email) values ('Lulu', 'Jerrams', 'ljerramsj@instagram.com');
insert into spy (first_name, last_name, email) values ('Payton', 'Britner', 'pbritnerk@constantcontact.com');
insert into spy (first_name, last_name, email) values ('Milka', 'Kubicka', 'mkubickal@seattletimes.com');
insert into spy (first_name, last_name, email) values ('Borg', 'Lukianov', 'blukianovm@blogger.com');
insert into spy (first_name, last_name, email) values ('Hillyer', 'Bartolic', 'hbartolicn@smugmug.com');
insert into spy (first_name, last_name, email) values ('Zondra', 'Clist', 'zclisto@csmonitor.com');
insert into spy (first_name, last_name, email) values ('Francyne', 'Colliver', 'fcolliverp@bravesites.com');
insert into spy (first_name, last_name, email) values ('Nat', 'Janowicz', 'njanowiczq@nbcnews.com');
insert into spy (first_name, last_name, email) values ('Tiff', 'Aharoni', 'taharonir@plala.or.jp');
insert into spy (first_name, last_name, email) values ('Leroi', 'Bruneton', 'lbrunetons@studiopress.com');
insert into spy (first_name, last_name, email) values ('Angela', 'Levine', 'alevinet@alibaba.com');
insert into spy (first_name, last_name, email) values ('Aindrea', 'Durdy', 'adurdyu@state.tx.us');
insert into spy (first_name, last_name, email) values ('Ingunna', 'Copestick', 'icopestickv@google.co.uk');
insert into spy (first_name, last_name, email) values ('Marthe', 'Winstone', 'mwinstonew@jigsy.com');
insert into spy (first_name, last_name, email) values ('Monte', 'Cram', 'mcramx@nps.gov');
insert into spy (first_name, last_name, email) values ('Wash', 'Nellen', 'wnelleny@blogspot.com');
insert into spy (first_name, last_name, email) values ('Sandor', 'Grinin', 'sgrininz@answers.com');
insert into spy (first_name, last_name, email) values ('Romola', 'Menpes', 'rmenpes10@canalblog.com');
insert into spy (first_name, last_name, email) values ('Jerrilee', 'Sekulla', 'jsekulla11@constantcontact.com');
insert into spy (first_name, last_name, email) values ('Amata', 'Gemmell', 'agemmell12@umn.edu');
insert into spy (first_name, last_name, email) values ('Wilona', 'Vasyagin', 'wvasyagin13@ucla.edu');
insert into spy (first_name, last_name, email) values ('Jeffry', 'Weal', 'jweal14@icio.us');
insert into spy (first_name, last_name, email) values ('Angy', 'Petley', 'apetley15@spiegel.de');
insert into spy (first_name, last_name, email) values ('Kristine', 'Leeder', 'kleeder16@statcounter.com');
insert into spy (first_name, last_name, email) values ('Elijah', 'Moehle', 'emoehle17@bbb.org');
insert into spy (first_name, last_name, email) values ('Lanny', 'Tate', 'ltate18@parallels.com');
insert into spy (first_name, last_name, email) values ('Richard', 'Grealy', 'rgrealy19@ted.com');
insert into spy (first_name, last_name, email) values ('Benoite', 'McParland', 'bmcparland1a@wikipedia.org');
insert into spy (first_name, last_name, email) values ('Ferrell', 'Tranter', 'ftranter1b@nhs.uk');
insert into spy (first_name, last_name, email) values ('Johan', 'Semble', 'jsemble1c@indiegogo.com');
insert into spy (first_name, last_name, email) values ('Rosamund', 'Lathwell', 'rlathwell1d@1und1.de');
insert into spy (first_name, last_name, email) values ('Kenneth', 'Farny', 'kfarny1e@reference.com');
insert into spy (first_name, last_name, email) values ('Harry', 'Morsley', 'hmorsley1f@tmall.com');
insert into spy (first_name, last_name, email) values ('Nerte', 'Buckberry', 'nbuckberry1g@amazon.co.jp');
insert into spy (first_name, last_name, email) values ('Modestine', 'Bage', 'mbage1h@google.it');
insert into spy (first_name, last_name, email) values ('Pauli', 'Mithan', 'pmithan1i@who.int');
insert into spy (first_name, last_name, email) values ('Eduardo', 'Giovanetti', 'egiovanetti1j@reverbnation.com');
insert into spy (first_name, last_name, email) values ('Lorine', 'Dring', 'ldring1k@ft.com');
insert into spy (first_name, last_name, email) values ('Spense', 'Castles', 'scastles1l@godaddy.com');
insert into spy (first_name, last_name, email) values ('Padraig', 'Bonicelli', 'pbonicelli1m@i2i.jp');
insert into spy (first_name, last_name, email) values ('Humfrey', 'Bockh', 'hbockh1n@unicef.org');
insert into spy (first_name, last_name, email) values ('Burl', 'Vickers', 'bvickers1o@examiner.com');
insert into spy (first_name, last_name, email) values ('Pasquale', 'Woodland', 'pwoodland1p@dropbox.com');
insert into spy (first_name, last_name, email) values ('Catarina', 'Schirak', 'cschirak1q@163.com');
insert into spy (first_name, last_name, email) values ('Sinclare', 'Jemmison', 'sjemmison1r@domainmarket.com');
insert into spy (first_name, last_name, email) values ('Robbin', 'Bruneton', 'rbruneton1s@example.com');
insert into spy (first_name, last_name, email) values ('Alfy', 'Haselgrove', 'ahaselgrove1t@drupal.org');
insert into spy (first_name, last_name, email) values ('Claudian', 'Katz', 'ckatz1u@skyrock.com');
insert into spy (first_name, last_name, email) values ('Saw', 'Rennick', 'srennick1v@wiley.com');
insert into spy (first_name, last_name, email) values ('Martica', 'Renfree', 'mrenfree1w@businesswire.com');
insert into spy (first_name, last_name, email) values ('Jennilee', 'Bartrap', 'jbartrap1x@miitbeian.gov.cn');
insert into spy (first_name, last_name, email) values ('Niki', 'Strase', 'nstrase1y@so-net.ne.jp');
insert into spy (first_name, last_name, email) values ('Reuven', 'Brugmann', 'rbrugmann1z@goo.ne.jp');
insert into spy (first_name, last_name, email) values ('Raimund', 'Zanre', 'rzanre20@wix.com');
insert into spy (first_name, last_name, email) values ('Hamlin', 'Lambillion', 'hlambillion21@amazon.co.uk');
insert into spy (first_name, last_name, email) values ('Edee', 'De Micoli', 'edemicoli22@miibeian.gov.cn');
insert into spy (first_name, last_name, email) values ('Prudence', 'Simionescu', 'psimionescu23@histats.com');
insert into spy (first_name, last_name, email) values ('Paolo', 'Harmon', 'pharmon24@nps.gov');
insert into spy (first_name, last_name, email) values ('Sheffield', 'Shardlow', 'sshardlow25@myspace.com');
insert into spy (first_name, last_name, email) values ('Evvy', 'Remnant', 'eremnant26@ucoz.com');
insert into spy (first_name, last_name, email) values ('Porty', 'Leneham', 'pleneham27@smh.com.au');
insert into spy (first_name, last_name, email) values ('Mia', 'Hassey', 'mhassey28@nps.gov');
insert into spy (first_name, last_name, email) values ('Ad', 'Mead', 'amead29@opensource.org');
insert into spy (first_name, last_name, email) values ('Kittie', 'Springtorp', 'kspringtorp2a@oakley.com');
insert into spy (first_name, last_name, email) values ('Storm', 'Haydon', 'shaydon2b@omniture.com');
insert into spy (first_name, last_name, email) values ('Currey', 'Ilyinski', 'cilyinski2c@hp.com');
insert into spy (first_name, last_name, email) values ('Adelind', 'Dailly', 'adailly2d@php.net');
insert into spy (first_name, last_name, email) values ('Eldin', 'Rigardeau', 'erigardeau2e@histats.com');
insert into spy (first_name, last_name, email) values ('Jennine', 'Ciementini', 'jciementini2f@ebay.co.uk');
insert into spy (first_name, last_name, email) values ('Cammie', 'Millthorpe', 'cmillthorpe2g@cbc.ca');
insert into spy (first_name, last_name, email) values ('Dallon', 'Bruin', 'dbruin2h@gov.uk');
insert into spy (first_name, last_name, email) values ('Dag', 'Canto', 'dcanto2i@icio.us');
insert into spy (first_name, last_name, email) values ('Cassandry', 'Elsley', 'celsley2j@jigsy.com');
insert into spy (first_name, last_name, email) values ('Chrissie', 'Josefowicz', 'cjosefowicz2k@amazon.co.uk');
insert into spy (first_name, last_name, email) values ('Althea', 'Penas', 'apenas2l@ow.ly');
insert into spy (first_name, last_name, email) values ('Neville', 'Sussams', 'nsussams2m@slideshare.net');
insert into spy (first_name, last_name, email) values ('Nickolaus', 'Viccary', 'nviccary2n@stanford.edu');
insert into spy (first_name, last_name, email) values ('Claudian', 'Braithwait', 'cbraithwait2o@bluehost.com');
insert into spy (first_name, last_name, email) values ('Georgetta', 'Gruszczak', 'ggruszczak2p@wikipedia.org');
insert into spy (first_name, last_name, email) values ('Ellyn', 'Riddett', 'eriddett2q@aol.com');
insert into spy (first_name, last_name, email) values ('Benoite', 'Durtnel', 'bdurtnel2r@cornell.edu');

/* Inserting records into 'website' table: */

insert into website (url, ipaddress) values ('https://ycombinator.com/cubilia/curae/nulla/dapibus/dolor/vel/est.jpg', '116.32.72.189');
insert into website (url, ipaddress) values ('https://redcross.org/non.jpg', '104.30.178.9');
insert into website (url, ipaddress) values ('http://barnesandnoble.com/mauris/eget/massa.js', '229.99.58.106');
insert into website (url, ipaddress) values ('http://upenn.edu/posuere/felis/sed/lacus/morbi/sem.png', '191.28.26.112');
insert into website (url, ipaddress) values ('http://arstechnica.com/morbi/vestibulum/velit/id.json', '36.109.189.23');
insert into website (url, ipaddress) values ('https://list-manage.com/nam/ultrices/libero/non.png', '138.16.118.96');
insert into website (url, ipaddress) values ('https://time.com/nulla/suscipit/ligula/in/lacus/curabitur/at.js', '188.166.63.43');
insert into website (url, ipaddress) values ('http://ebay.com/convallis.aspx', '62.10.250.104');
insert into website (url, ipaddress) values ('http://wsj.com/felis/sed/interdum/venenatis/turpis.jsp', '201.94.77.160');
insert into website (url, ipaddress) values ('https://netlog.com/tellus/nisi/eu/orci/mauris/lacinia/sapien.jsp', '32.141.168.78');
insert into website (url, ipaddress) values ('https://zimbio.com/aenean/auctor/gravida/sem/praesent/id.jsp', '141.205.86.133');
insert into website (url, ipaddress) values ('http://weather.com/ac/nulla/sed/vel/enim/sit/amet.json', '220.71.236.57');
insert into website (url, ipaddress) values ('http://nyu.edu/vel/ipsum/praesent.html', '128.53.206.61');
insert into website (url, ipaddress) values ('http://4shared.com/ipsum/aliquam/non/mauris/morbi/non/lectus.js', '38.23.28.195');
insert into website (url, ipaddress) values ('https://elpais.com/etiam/pretium/iaculis/justo/in.jsp', '59.52.59.98');
insert into website (url, ipaddress) values ('http://umich.edu/neque/sapien/placerat.jpg', '254.255.191.68');
insert into website (url, ipaddress) values ('https://loc.gov/posuere.png', '104.223.87.61');
insert into website (url, ipaddress) values ('http://nasa.gov/diam/id/ornare.aspx', '25.148.94.217');
insert into website (url, ipaddress) values ('https://statcounter.com/arcu/sed/augue/aliquam/erat/volutpat/in.jsp', '206.247.87.250');
insert into website (url, ipaddress) values ('http://amazonaws.com/amet/erat/nulla/tempus/vivamus/in.html', '199.15.65.75');
insert into website (url, ipaddress) values ('http://unicef.org/proin.png', '161.145.67.204');
insert into website (url, ipaddress) values ('https://fda.gov/risus.html', '73.117.111.202');
insert into website (url, ipaddress) values ('https://gov.uk/nunc/rhoncus.json', '111.244.177.65');
insert into website (url, ipaddress) values ('https://about.me/sit/amet.xml', '157.243.212.94');
insert into website (url, ipaddress) values ('http://elegantthemes.com/varius.js', '192.92.7.79');
insert into website (url, ipaddress) values ('http://va.gov/velit/donec/diam/neque/vestibulum.png', '222.171.72.134');
insert into website (url, ipaddress) values ('http://dyndns.org/luctus/et.jsp', '98.126.75.111');
insert into website (url, ipaddress) values ('https://stumbleupon.com/natoque.png', '175.246.173.90');
insert into website (url, ipaddress) values ('http://mysql.com/eget/eros/elementum/pellentesque/quisque.jpg', '221.178.197.234');
insert into website (url, ipaddress) values ('http://blogtalkradio.com/nisi.json', '216.96.97.113');
insert into website (url, ipaddress) values ('http://hibu.com/enim.aspx', '196.161.238.36');
insert into website (url, ipaddress) values ('http://jiathis.com/neque/aenean/auctor.json', '213.16.170.144');
insert into website (url, ipaddress) values ('http://nydailynews.com/maecenas.jsp', '70.64.68.87');
insert into website (url, ipaddress) values ('http://hubpages.com/erat/nulla/tempus/vivamus/in/felis.png', '114.11.100.247');
insert into website (url, ipaddress) values ('http://youku.com/sit/amet/sem/fusce/consequat/nulla/nisl.js', '50.3.93.179');
insert into website (url, ipaddress) values ('https://merriam-webster.com/enim/lorem/ipsum/dolor/sit/amet.jsp', '115.54.178.15');
insert into website (url, ipaddress) values ('http://squarespace.com/odio/curabitur/convallis/duis.jsp', '56.26.137.250');
insert into website (url, ipaddress) values ('https://bloomberg.com/lobortis/vel/dapibus/at/diam/nam.aspx', '206.7.220.120');
insert into website (url, ipaddress) values ('https://youku.com/augue/quam.xml', '202.199.249.161');
insert into website (url, ipaddress) values ('http://acquirethisname.com/est/congue/elementum/in/hac/habitasse/platea.js', '117.14.24.57');
insert into website (url, ipaddress) values ('http://zimbio.com/tincidunt/eu/felis/fusce/posuere.xml', '212.29.121.183');
insert into website (url, ipaddress) values ('http://opera.com/hac/habitasse/platea.png', '184.168.97.135');
insert into website (url, ipaddress) values ('http://engadget.com/primis/in/faucibus.xml', '115.139.42.212');
insert into website (url, ipaddress) values ('https://yellowpages.com/mattis/egestas/metus/aenean.json', '158.97.109.253');
insert into website (url, ipaddress) values ('http://hhs.gov/natoque/penatibus/et/magnis/dis.js', '103.137.148.103');
insert into website (url, ipaddress) values ('https://chicagotribune.com/turpis/eget/elit/sodales/scelerisque.aspx', '172.89.145.207');
insert into website (url, ipaddress) values ('http://pinterest.com/tortor/sollicitudin/mi/sit/amet.aspx', '88.174.194.13');
insert into website (url, ipaddress) values ('https://wired.com/cubilia/curae/donec/pharetra/magna/vestibulum.jsp', '130.146.249.38');
insert into website (url, ipaddress) values ('http://dedecms.com/augue/vestibulum/ante/ipsum/primis.json', '247.2.178.21');
insert into website (url, ipaddress) values ('http://shareasale.com/morbi/ut.json', '144.152.255.65');
insert into website (url, ipaddress) values ('https://springer.com/bibendum/imperdiet/nullam/orci/pede/venenatis.jsp', '188.154.141.125');
insert into website (url, ipaddress) values ('http://arizona.edu/pede/venenatis.html', '72.87.21.150');
insert into website (url, ipaddress) values ('https://cocolog-nifty.com/pede/ullamcorper/augue/a/suscipit/nulla/elit.js', '102.77.229.115');
insert into website (url, ipaddress) values ('http://cbslocal.com/potenti/nullam.html', '5.127.23.54');
insert into website (url, ipaddress) values ('https://ocn.ne.jp/nulla/ultrices/aliquet/maecenas/leo/odio.xml', '162.43.70.48');
insert into website (url, ipaddress) values ('https://devhub.com/maecenas/leo.png', '63.96.26.140');
insert into website (url, ipaddress) values ('https://seattletimes.com/consequat/lectus/in/est/risus/auctor/sed.json', '62.62.147.214');
insert into website (url, ipaddress) values ('http://blinklist.com/tortor/sollicitudin.json', '105.17.134.160');
insert into website (url, ipaddress) values ('http://soundcloud.com/laoreet/ut/rhoncus/aliquet/pulvinar/sed/nisl.jpg', '214.171.116.28');
insert into website (url, ipaddress) values ('https://chronoengine.com/mollis/molestie/lorem/quisque/ut.json', '62.145.203.200');
insert into website (url, ipaddress) values ('http://over-blog.com/fringilla/rhoncus.js', '123.121.19.79');
insert into website (url, ipaddress) values ('http://nifty.com/neque.png', '197.155.81.61');
insert into website (url, ipaddress) values ('http://pbs.org/est/lacinia/nisi/venenatis/tristique/fusce/congue.png', '194.64.19.233');
insert into website (url, ipaddress) values ('https://home.pl/consequat/in/consequat/ut/nulla/sed/accumsan.aspx', '18.91.72.33');
insert into website (url, ipaddress) values ('http://loc.gov/velit/eu/est/congue/elementum.jsp', '204.68.184.54');
insert into website (url, ipaddress) values ('http://slate.com/sit/amet.js', '243.165.78.134');
insert into website (url, ipaddress) values ('http://friendfeed.com/magnis/dis/parturient/montes/nascetur/ridiculus.png', '154.227.81.20');
insert into website (url, ipaddress) values ('https://economist.com/curae/nulla.aspx', '63.113.229.203');
insert into website (url, ipaddress) values ('http://blogtalkradio.com/iaculis/justo/in/hac/habitasse/platea.html', '200.185.212.196');
insert into website (url, ipaddress) values ('https://wordpress.org/elementum/ligula/vehicula/consequat/morbi/a.jsp', '230.249.226.177');
insert into website (url, ipaddress) values ('https://cafepress.com/ut/at/dolor.aspx', '247.153.124.154');
insert into website (url, ipaddress) values ('http://indiatimes.com/mattis/pulvinar/nulla/pede/ullamcorper/augue/a.html', '32.46.187.59');
insert into website (url, ipaddress) values ('http://smugmug.com/in/magna/bibendum/imperdiet/nullam/orci.html', '164.138.71.16');
insert into website (url, ipaddress) values ('http://phpbb.com/augue/luctus.js', '187.9.103.31');
insert into website (url, ipaddress) values ('https://sohu.com/odio/curabitur.json', '28.71.154.246');
insert into website (url, ipaddress) values ('https://ebay.com/nisl.json', '154.184.222.13');
insert into website (url, ipaddress) values ('http://cnbc.com/felis/ut/at/dolor.aspx', '70.196.165.26');
insert into website (url, ipaddress) values ('https://posterous.com/integer/aliquet/massa/id/lobortis/convallis.xml', '127.131.12.97');
insert into website (url, ipaddress) values ('http://ifeng.com/diam/erat/fermentum/justo/nec.jpg', '99.118.11.78');
insert into website (url, ipaddress) values ('https://devhub.com/accumsan/felis/ut/at/dolor.html', '67.31.48.219');
insert into website (url, ipaddress) values ('https://go.com/ultrices/erat.json', '204.58.90.92');
insert into website (url, ipaddress) values ('https://paypal.com/aenean/sit.jsp', '60.7.251.59');
insert into website (url, ipaddress) values ('http://globo.com/suspendisse.jsp', '202.24.164.215');
insert into website (url, ipaddress) values ('https://people.com.cn/commodo/vulputate/justo/in.html', '176.135.254.146');
insert into website (url, ipaddress) values ('https://webmd.com/erat/volutpat/in/congue.json', '89.58.172.134');
insert into website (url, ipaddress) values ('http://amazon.co.uk/eget/tincidunt/eget/tempus/vel/pede/morbi.jpg', '0.237.163.133');
insert into website (url, ipaddress) values ('https://acquirethisname.com/vitae/ipsum/aliquam/non/mauris.jpg', '250.209.116.103');
insert into website (url, ipaddress) values ('https://symantec.com/gravida/nisi/at/nibh.xml', '138.215.211.107');
insert into website (url, ipaddress) values ('http://stumbleupon.com/vel/nulla/eget/eros/elementum.aspx', '132.157.225.154');
insert into website (url, ipaddress) values ('https://wikimedia.org/semper.xml', '69.78.84.35');
insert into website (url, ipaddress) values ('http://wix.com/primis/in/faucibus/orci.jsp', '98.192.26.228');
insert into website (url, ipaddress) values ('https://joomla.org/sapien/ut.json', '192.9.93.169');
insert into website (url, ipaddress) values ('https://sakura.ne.jp/duis/faucibus/accumsan/odio/curabitur/convallis.aspx', '97.106.90.109');
insert into website (url, ipaddress) values ('http://purevolume.com/consequat/morbi/a/ipsum.png', '126.200.22.186');
insert into website (url, ipaddress) values ('http://comsenz.com/varius/nulla.jpg', '76.35.7.221');
insert into website (url, ipaddress) values ('https://opensource.org/eleifend/donec/ut/dolor.jsp', '40.11.77.167');
insert into website (url, ipaddress) values ('http://si.edu/felis/ut/at/dolor/quis/odio.aspx', '184.50.216.0');
insert into website (url, ipaddress) values ('http://amazon.co.jp/donec/vitae.jpg', '4.250.49.223');
insert into website (url, ipaddress) values ('http://blog.com/velit/eu.js', '71.87.56.68');
insert into website (url, ipaddress) values ('https://pagesperso-orange.fr/nisi/volutpat/eleifend/donec/ut/dolor.jsp', '6.131.149.90');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO viewed(email, ipaddress) 
SELECT 
  s.email, 
  w.ipaddress 
FROM 
  spy s, 
  website w 
ORDER BY 
  RANDOM() 
LIMIT 
  1000;

