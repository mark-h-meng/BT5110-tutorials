/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */
/* 

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* 
Table Audiences contains the information of audiences who have watched different
movies online. The information contains audiences' first_name, last_name, gender, 
nationality, and the ip_address, where they use to watch the movies. In this case,
since ip_address is unique, we use it as our primary key.

Table Movies contains the information of different movies. The information contains
the movies' title, genres, and director,which will be shown in full name. Since we 
cannot have two movies with same title and same director, we can use title and 
director as our primary key. 

Table Watched is the relationship between table Audience and table Movie. The table
Watched correspond the ip_address of Audience with the title and director of Movie 
to represent that such an audience has already watched the movie. Each movie can be 
watched by many audiences, and each audience can also watch a lot of movies.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS Audiences (
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	gender VARCHAR(16),
	nationality VARCHAR(64),
	ip_address VARCHAR(256) PRIMARY KEY
	);

CREATE TABLE IF NOT EXISTS Movies (
	title VARCHAR(64) NOT NULL,
	genres VARCHAR(64),
	director VARCHAR(64) NOT NULL,
	PRIMARY KEY (title, director)
	);

CREATE TABLE Watched (
	ip_address VARCHAR(256) REFERENCES Audiences(ip_address),
	title VARCHAR(64),
	director VARCHAR(64),
	PRIMARY KEY (ip_address, title, director),
	FOREIGN KEY (title, director) REFERENCES Movies(title, director)
	);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Humfrid', 'Avraam', 'Bigender', 'China', '64.56.251.33');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Hillie', 'Wardlow', 'Female', 'Tanzania', '42.44.77.15');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Elianora', 'Ivankovic', 'Agender', 'Indonesia', '201.193.228.252');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Franklyn', 'Sabban', 'Female', 'Ukraine', '241.217.153.106');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Valentia', 'Wyllcocks', 'Polygender', 'China', '106.63.108.217');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Ynez', 'Surfleet', 'Non-binary', 'China', '161.205.255.165');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Valida', 'Cool', 'Agender', 'Colombia', '252.180.227.36');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Nyssa', 'Petts', 'Agender', 'Portugal', '47.243.14.252');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Opalina', 'Carnier', 'Genderfluid', 'France', '106.53.166.250');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Lesya', 'Healings', 'Polygender', 'Madagascar', '169.40.203.253');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Job', 'Grodden', 'Agender', 'Indonesia', '245.252.84.42');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Abbie', 'Mion', 'Agender', 'Philippines', '84.157.97.157');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Sorcha', 'Lunk', 'Non-binary', 'Albania', '100.62.138.77');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Wilfred', 'Pascoe', 'Genderqueer', 'Mexico', '57.90.88.97');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Jaine', 'Anfosso', 'Non-binary', 'Belarus', '81.170.137.60');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Pietra', 'Hargreves', 'Female', 'Peru', '168.241.209.41');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Trudey', 'Trayes', 'Genderfluid', 'Portugal', '180.253.20.204');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Goldi', 'Greated', 'Agender', 'France', '19.185.53.46');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Boycey', 'Bibb', 'Genderfluid', 'Nigeria', '129.212.239.126');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Clementine', 'Brookhouse', 'Agender', 'Philippines', '204.240.103.197');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Talbot', 'Cinelli', 'Male', 'Germany', '5.164.173.27');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Hermy', 'Danelet', 'Non-binary', 'China', '57.186.22.1');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Carree', 'Farge', 'Male', 'United States', '47.231.194.77');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Kippar', 'Chin', 'Non-binary', 'Indonesia', '165.44.108.211');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Aubrie', 'Richemond', 'Genderqueer', 'Poland', '54.173.129.224');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Gladi', 'Aseef', 'Non-binary', 'Greece', '99.52.132.208');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Belva', 'Gloster', 'Polygender', 'Paraguay', '207.208.198.210');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Tricia', 'Cassells', 'Male', 'Indonesia', '173.30.22.233');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Martainn', 'Guthrie', 'Non-binary', 'Palestinian Territory', '35.180.98.236');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Benedetta', 'Gooch', 'Genderfluid', 'Czech Republic', '31.25.240.73');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Reeta', 'Jenton', 'Bigender', 'France', '16.181.51.95');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Burr', 'Tomczynski', 'Male', 'Netherlands', '8.151.197.23');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Paola', 'D''Andrea', 'Non-binary', 'Brazil', '57.58.146.183');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Olenolin', 'Bollini', 'Male', 'Thailand', '166.145.102.161');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Hilliard', 'Fagg', 'Female', 'Russia', '116.16.158.41');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Lenee', 'Wrankmore', 'Genderfluid', 'Indonesia', '136.185.119.161');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Nikos', 'Warrell', 'Female', 'China', '29.77.8.98');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Carmella', 'Poole', 'Genderfluid', 'Albania', '216.42.119.64');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Donelle', 'Older', 'Polygender', 'Philippines', '84.199.128.9');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Cherye', 'Bim', 'Genderfluid', 'China', '206.8.252.88');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Nataniel', 'Earthfield', 'Bigender', 'China', '55.106.106.129');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Rickie', 'Kail', 'Male', 'China', '105.107.81.118');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Ginelle', 'Yakuntzov', 'Polygender', 'China', '115.240.45.44');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Curry', 'Mountstephen', 'Agender', 'Japan', '30.172.19.164');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Candra', 'Hischke', 'Polygender', 'Indonesia', '169.163.117.182');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Nicol', 'Ogbourne', 'Male', 'Afghanistan', '28.102.171.155');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Denver', 'Stampe', 'Male', 'Bangladesh', '122.221.167.239');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Ezmeralda', 'Garbert', 'Female', 'Brazil', '95.54.230.203');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Mureil', 'Bunclark', 'Genderfluid', 'Brazil', '179.53.98.9');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Andreana', 'Stenett', 'Bigender', 'China', '207.12.155.184');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Jo', 'Ordish', 'Agender', 'Sweden', '249.205.29.43');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Petey', 'Bouzan', 'Polygender', 'Poland', '142.129.225.152');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Dionysus', 'Denisovich', 'Polygender', 'China', '163.33.160.2');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Henka', 'Wimbury', 'Male', 'China', '184.126.22.149');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Cordey', 'Bolding', 'Bigender', 'Argentina', '234.198.141.57');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Meghan', 'Mulqueen', 'Agender', 'Russia', '127.229.53.95');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Cloe', 'Lofthouse', 'Polygender', 'Brazil', '7.141.214.61');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Dyna', 'Heamus', 'Non-binary', 'China', '122.87.154.94');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Marianne', 'Smeath', 'Polygender', 'Mexico', '204.138.62.95');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Reynolds', 'Yurocjhin', 'Genderfluid', 'China', '200.153.241.19');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Stillmann', 'Slingsby', 'Bigender', 'Norway', '27.131.251.227');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Stacy', 'Korbmaker', 'Male', 'China', '146.24.90.221');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Ferdy', 'Giroldi', 'Genderfluid', 'Portugal', '107.91.143.160');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Ingaborg', 'Hooks', 'Polygender', 'France', '254.95.224.240');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Celka', 'Krysztofiak', 'Agender', 'Japan', '17.144.14.255');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Hazel', 'Parken', 'Polygender', 'Ukraine', '149.66.101.62');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Virge', 'Vahl', 'Genderfluid', 'France', '174.253.162.66');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Lyell', 'Wellfare', 'Agender', 'Sweden', '254.76.89.173');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Jessa', 'Sange', 'Polygender', 'Indonesia', '77.166.236.146');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Zora', 'Orr', 'Female', 'Indonesia', '72.35.166.251');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Carmelle', 'Pull', 'Genderqueer', 'China', '66.210.112.160');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Fabien', 'Arnopp', 'Male', 'Belarus', '201.245.199.163');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Jeanelle', 'Haylands', 'Male', 'Israel', '67.138.107.69');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Mal', 'Musgrave', 'Female', 'China', '171.225.234.203');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Cordy', 'Orpen', 'Female', 'China', '200.195.40.255');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Sherlock', 'Skyrm', 'Bigender', 'Indonesia', '215.132.216.175');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Denny', 'Leblanc', 'Genderfluid', 'Indonesia', '153.214.136.241');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Angie', 'Gibb', 'Genderfluid', 'Bulgaria', '188.219.70.15');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Bartlett', 'Wisson', 'Non-binary', 'Jordan', '78.176.116.187');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Nichols', 'Wittrington', 'Polygender', 'China', '94.251.106.105');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Abner', 'Ollie', 'Bigender', 'Cambodia', '125.246.146.212');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Cindi', 'Champion', 'Female', 'China', '3.110.57.127');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Martyn', 'Scard', 'Non-binary', 'Russia', '245.212.132.167');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Denver', 'McCrystal', 'Genderqueer', 'Indonesia', '122.6.174.31');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Diane', 'Dennant', 'Male', 'Cambodia', '80.19.249.142');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Rochester', 'Primarolo', 'Genderqueer', 'Australia', '185.207.47.68');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Elston', 'Minchindon', 'Genderqueer', 'Sweden', '103.25.56.196');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Ceciley', 'Kernell', 'Agender', 'Australia', '247.117.63.76');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Rae', 'O''Currine', 'Male', 'Panama', '207.199.79.231');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Langston', 'Lyfield', 'Polygender', 'Indonesia', '175.189.9.20');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Celka', 'Dietsche', 'Agender', 'Japan', '4.207.151.219');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Paulita', 'Blomfield', 'Agender', 'China', '144.56.188.57');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Tedda', 'Humpherson', 'Agender', 'Portugal', '145.188.36.138');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Lorena', 'Dowman', 'Non-binary', 'Indonesia', '161.42.185.122');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Lionello', 'Thornthwaite', 'Bigender', 'Russia', '14.173.151.132');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Eirena', 'Clougher', 'Bigender', 'Czech Republic', '92.223.52.71');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Ora', 'Vlasyev', 'Agender', 'Poland', '26.85.162.138');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Ric', 'Pallasch', 'Genderfluid', 'Indonesia', '93.4.187.40');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Marigold', 'Diggell', 'Polygender', 'Indonesia', '47.35.146.52');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Irina', 'Buddle', 'Polygender', 'China', '94.37.139.123');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Leonelle', 'Lancashire', 'Male', 'Russia', '45.10.131.193');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Sascha', 'Brownrigg', 'Female', 'Indonesia', '85.50.34.72');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Ulrich', 'Hauxley', 'Female', 'Switzerland', '174.241.41.189');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Otha', 'Shatliffe', 'Female', 'China', '45.248.175.246');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Mariana', 'Bumpass', 'Agender', 'Brazil', '81.157.231.98');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Ozzy', 'Smalles', 'Male', 'Oman', '22.155.139.208');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Carmina', 'Kryzhov', 'Agender', 'Indonesia', '60.250.174.253');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Bogart', 'Woodfine', 'Non-binary', 'Vietnam', '157.71.86.193');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Paige', 'McGiveen', 'Genderqueer', 'Bangladesh', '243.33.49.235');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Gennie', 'Kuhne', 'Male', 'Ukraine', '236.94.201.97');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Rees', 'Jurries', 'Male', 'Russia', '142.139.198.172');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Madelyn', 'Greeve', 'Genderqueer', 'Portugal', '223.159.67.110');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Fidela', 'Furley', 'Bigender', 'China', '248.104.196.213');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Gerek', 'Blasoni', 'Genderfluid', 'Ireland', '106.23.33.92');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Alphonso', 'McCumskay', 'Non-binary', 'Indonesia', '154.77.246.198');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Abbe', 'Askin', 'Agender', 'New Zealand', '227.231.15.137');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Hilario', 'Ody', 'Polygender', 'Russia', '100.243.69.44');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Cathee', 'Hinder', 'Genderqueer', 'China', '27.179.2.151');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Leeanne', 'Edwinson', 'Agender', 'Czech Republic', '175.148.150.140');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Sonnie', 'Woolham', 'Non-binary', 'Panama', '132.140.7.178');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Issiah', 'Maberley', 'Polygender', 'North Korea', '153.209.166.1');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Tiphany', 'Dixcey', 'Non-binary', 'Russia', '15.126.145.200');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Lionel', 'Mattys', 'Agender', 'Ukraine', '37.117.85.79');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Betsy', 'Petrenko', 'Genderfluid', 'Philippines', '170.145.6.4');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Arlen', 'Blasdale', 'Genderqueer', 'Indonesia', '92.127.188.67');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Any', 'Skyram', 'Polygender', 'France', '84.32.209.53');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Linnet', 'Vanyatin', 'Agender', 'Venezuela', '136.74.209.86');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Otho', 'Beswick', 'Genderfluid', 'China', '49.230.221.222');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Silvester', 'O''Shavlan', 'Bigender', 'Dominican Republic', '184.29.149.173');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Alistair', 'Hellen', 'Genderfluid', 'China', '186.135.94.4');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Caresa', 'Scoullar', 'Polygender', 'Cameroon', '97.225.81.22');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Ellen', 'Huikerby', 'Non-binary', 'Indonesia', '202.12.171.91');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Chaddy', 'Merry', 'Genderfluid', 'Mexico', '165.61.67.232');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Alex', 'Vockings', 'Polygender', 'Honduras', '15.94.136.123');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Ardenia', 'Tamas', 'Male', 'Philippines', '152.125.225.218');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Olivia', 'Allans', 'Agender', 'Russia', '154.227.204.236');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Munroe', 'Corsor', 'Male', 'Indonesia', '56.59.112.71');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Christiana', 'Childers', 'Genderqueer', 'France', '210.190.169.102');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Georgena', 'Airy', 'Non-binary', 'Mexico', '89.81.199.82');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Lucas', 'Hissett', 'Genderfluid', 'Chile', '69.205.5.176');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Addy', 'Bohan', 'Non-binary', 'Indonesia', '208.169.168.83');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Rori', 'Ellings', 'Bigender', 'Canada', '60.42.49.188');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Inessa', 'Gurnay', 'Bigender', 'South Africa', '77.217.11.29');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Joli', 'Lerven', 'Polygender', 'Brazil', '132.177.254.37');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Carlie', 'Czajka', 'Bigender', 'Albania', '1.34.10.94');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Caitlin', 'Blackshaw', 'Agender', 'Indonesia', '66.160.26.194');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Nertie', 'Gatrell', 'Genderfluid', 'Argentina', '200.41.25.169');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Armin', 'Towey', 'Polygender', 'China', '154.38.28.42');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Maison', 'Baumler', 'Bigender', 'Peru', '55.211.87.250');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Leland', 'Crosher', 'Male', 'Philippines', '0.104.110.38');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('James', 'Tootal', 'Genderqueer', 'Brazil', '217.165.214.244');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Heidi', 'Chritchley', 'Agender', 'Sweden', '168.112.195.229');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Evyn', 'Haspineall', 'Non-binary', 'Lithuania', '87.218.24.112');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Goldia', 'Biaggetti', 'Male', 'Czech Republic', '93.75.1.77');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Clayborn', 'Lippingwell', 'Genderfluid', 'Indonesia', '67.12.7.42');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Halley', 'Stollmeier', 'Polygender', 'Russia', '205.9.196.53');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Valry', 'Kilgallen', 'Female', 'Bosnia and Herzegovina', '122.50.37.164');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('L;urette', 'Cregan', 'Polygender', 'South Korea', '140.8.75.8');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Danni', 'Nowlan', 'Male', 'Brazil', '51.74.202.125');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Mic', 'Gladdifh', 'Bigender', 'Philippines', '67.211.196.179');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Freddie', 'Pender', 'Polygender', 'Sweden', '164.27.144.35');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Thomasa', 'Vowden', 'Male', 'Philippines', '49.1.255.166');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Michale', 'Cutten', 'Genderfluid', 'China', '81.175.115.242');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Auberon', 'McCleod', 'Genderfluid', 'Greece', '230.14.70.207');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Orel', 'Stubbins', 'Polygender', 'Indonesia', '159.14.57.107');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Donaugh', 'Pymm', 'Agender', 'Afghanistan', '203.225.255.152');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Julie', 'Nurden', 'Agender', 'Kazakhstan', '30.33.77.243');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Odo', 'Mallison', 'Female', 'China', '59.81.203.39');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Drucie', 'Tungay', 'Genderqueer', 'Syria', '196.40.156.130');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Nahum', 'Walpole', 'Female', 'Philippines', '64.130.101.7');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Cristian', 'Vereker', 'Genderfluid', 'Norway', '3.232.57.213');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Brande', 'Follet', 'Male', 'France', '215.143.241.25');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Mathian', 'Hallitt', 'Bigender', 'Poland', '162.255.153.167');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Barney', 'Harbord', 'Agender', 'South Africa', '135.136.152.143');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Roanna', 'Stanmore', 'Non-binary', 'Thailand', '217.76.189.6');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Rori', 'Bricket', 'Male', 'Indonesia', '61.175.215.85');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Elissa', 'Trustie', 'Genderqueer', 'South Korea', '238.199.144.62');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Rachelle', 'Meeron', 'Non-binary', 'Ecuador', '9.204.81.40');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Lydon', 'Symonds', 'Agender', 'Mexico', '65.56.177.120');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Herta', 'Coslitt', 'Male', 'China', '43.32.114.181');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Manon', 'Pennetta', 'Female', 'China', '6.100.84.226');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Jimmy', 'McKiernan', 'Female', 'Comoros', '167.131.7.250');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Izaak', 'Antonoczyk', 'Genderfluid', 'Finland', '67.152.166.180');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Pall', 'Messitt', 'Bigender', 'China', '249.195.139.123');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Valene', 'Ghost', 'Genderfluid', 'China', '176.174.194.243');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Letti', 'Bunston', 'Genderqueer', 'Guatemala', '100.55.104.7');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Garret', 'Curtoys', 'Non-binary', 'Brazil', '127.217.47.29');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Hilary', 'Qualtrough', 'Agender', 'Guatemala', '128.125.156.230');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Jillie', 'Priditt', 'Genderqueer', 'Russia', '60.71.253.138');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Kaleena', 'Mattusevich', 'Genderqueer', 'Peru', '134.67.194.23');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Goldarina', 'Arling', 'Genderqueer', 'Indonesia', '166.134.82.129');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Estel', 'Tabourel', 'Non-binary', 'Indonesia', '1.209.191.82');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Aluino', 'Davidsohn', 'Genderfluid', 'Indonesia', '71.60.209.200');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Gertrude', 'O''Donovan', 'Polygender', 'Tanzania', '234.94.122.40');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Sharona', 'Connechy', 'Agender', 'Poland', '113.182.176.249');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Angelia', 'McKechnie', 'Non-binary', 'United States', '206.151.197.61');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Helli', 'Challenor', 'Agender', 'Brazil', '74.124.207.227');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Sofie', 'Leighton', 'Agender', 'Indonesia', '242.41.219.76');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Nevin', 'Westmorland', 'Agender', 'Russia', '117.29.95.169');
insert into Audiences (first_name, last_name, gender, nationality, ip_address) values ('Robinia', 'Corkan', 'Genderqueer', 'Japan', '2.182.93.21');

insert into Movies (title, genres, director) values ('Moonrise', 'Drama|Film-Noir', 'Lonnard Becket');
insert into Movies (title, genres, director) values ('Full Eclipse', 'Crime|Horror|Sci-Fi', 'Tedman Malafe');
insert into Movies (title, genres, director) values ('Arthur 2: On the Rocks', 'Comedy|Romance', 'Joan Cossar');
insert into Movies (title, genres, director) values ('Resurrecting the Champ', 'Drama', 'Lia Stears');
insert into Movies (title, genres, director) values ('Foreign Letters', 'Comedy|Drama', 'Betty Conner');
insert into Movies (title, genres, director) values ('Bicycle, Spoon, Apple (Bicicleta, cullera, poma)', 'Documentary', 'Caroljean Hennemann');
insert into Movies (title, genres, director) values ('Return to Homs, The', 'Documentary', 'Katrina Polhill');
insert into Movies (title, genres, director) values ('Steam Experiment, The', 'Drama|Thriller', 'Tarrah Kuschek');
insert into Movies (title, genres, director) values ('Forks Over Knives', 'Documentary', 'Vernor Mablestone');
insert into Movies (title, genres, director) values ('Breaking the Girls ', 'Crime|Thriller', 'Antonina McCrudden');
insert into Movies (title, genres, director) values ('Cabiria', 'Adventure|Drama|War', 'Merry Pomphrett');
insert into Movies (title, genres, director) values ('Slam Dunk Ernest', 'Children|Comedy', 'Ragnar Karpeev');
insert into Movies (title, genres, director) values ('Freeze Frame', 'Crime|Drama|Thriller', 'Kylen Swancott');
insert into Movies (title, genres, director) values ('Tyler Perry''s A Madea Christmas', 'Comedy|Drama', 'Leontine Ticksall');
insert into Movies (title, genres, director) values ('Silent World, The (Le monde du silence)', 'Documentary', 'Dorian Castellucci');
insert into Movies (title, genres, director) values ('Female Agents (Les femmes de l''ombre)', 'Drama|War', 'Richmound Hradsky');
insert into Movies (title, genres, director) values ('Breach, The (Rupture, La)', 'Drama|Thriller', 'Hank McNiff');
insert into Movies (title, genres, director) values ('Shaggy D.A., The', 'Children|Comedy', 'Renee Avery');
insert into Movies (title, genres, director) values ('Boys (Drenge)', 'Drama', 'Barr Cowderay');
insert into Movies (title, genres, director) values ('Johnny Was', 'Action|Crime|Drama|Thriller', 'Gael Francescuccio');
insert into Movies (title, genres, director) values ('Urusei Yatsura Movie 2: Beautiful Dreamer (Urusei Yatsura 2: Byûtifuru dorîmâ)', 'Animation|Comedy|Fantasy', 'Angie Hallward');
insert into Movies (title, genres, director) values ('Season of the Witch (Hungry Wives) (Jack''s Wife)', 'Drama|Horror', 'Mil Nern');
insert into Movies (title, genres, director) values ('It Happened on Fifth Avenue', 'Comedy|Romance', 'Edyth Cardiff');
insert into Movies (title, genres, director) values ('Colombiana', 'Action|Adventure|Drama|Thriller', 'Nichole Maber');
insert into Movies (title, genres, director) values ('Moonlighting', 'Drama', 'Cloris Lethbrig');
insert into Movies (title, genres, director) values ('Fire Within, The (Feu follet, Le)', 'Drama', 'Gratia Callum');
insert into Movies (title, genres, director) values ('The Salt of the Earth', 'Documentary', 'Thebault Warricker');
insert into Movies (title, genres, director) values ('Rink, The', 'Comedy', 'Lyndsey Bernardos');
insert into Movies (title, genres, director) values ('McCabe & Mrs. Miller', 'Drama|Western', 'Phoebe Diperaus');
insert into Movies (title, genres, director) values ('Friends with Benefits', 'Comedy|Romance', 'Clara Dresche');
insert into Movies (title, genres, director) values ('And While We Were Here', 'Drama', 'Chloette Antunez');
insert into Movies (title, genres, director) values ('Lilla Jönssonligan och Cornflakeskuppen', 'Children|Comedy', 'Sheela Whiting');
insert into Movies (title, genres, director) values ('9to5: Days in Porn (a.k.a. 9 to 5: Days in Porn)', 'Documentary', 'Jessey Walczynski');
insert into Movies (title, genres, director) values ('Beauty #2', 'Drama', 'Sutherlan Jackett');
insert into Movies (title, genres, director) values ('Words and Pictures', 'Comedy|Drama|Romance', 'Pippo Ragge');
insert into Movies (title, genres, director) values ('Love Bites', 'Comedy|Romance', 'Ramona de Wilde');
insert into Movies (title, genres, director) values ('Party 2, The (Boum 2, La)', 'Comedy|Romance', 'Bamby Kay');
insert into Movies (title, genres, director) values ('Ghetto (Vilniaus Getas)', 'War', 'Vera Berendsen');
insert into Movies (title, genres, director) values ('Longest Yard, The', 'Comedy', 'Talyah Blakeborough');
insert into Movies (title, genres, director) values ('Smiling Lieutenant, The', 'Comedy|Musical|Romance', 'Lethia Pilipyak');
insert into Movies (title, genres, director) values ('Isadora', 'Drama', 'Onfre Yegorshin');
insert into Movies (title, genres, director) values ('Dead, The', 'Drama', 'Teddy Swallow');
insert into Movies (title, genres, director) values ('Roots', 'Drama|War', 'Jammie Thripp');
insert into Movies (title, genres, director) values ('Lost Horizon', 'Adventure|Drama|Fantasy|Musical|Romance', 'Calley Seiler');
insert into Movies (title, genres, director) values ('Drag Me to Hell', 'Comedy|Horror', 'Jaquenetta Rene');
insert into Movies (title, genres, director) values ('Animal Factory', 'Crime|Drama', 'Myrtie Gilchriest');
insert into Movies (title, genres, director) values ('Swimmer, The', 'Drama', 'Callida Marcham');
insert into Movies (title, genres, director) values ('Peace, Propaganda & the Promised Land', 'Documentary', 'Rex Bance');
insert into Movies (title, genres, director) values ('Cotton Mary', 'Drama', 'Shae Brickell');
insert into Movies (title, genres, director) values ('Karate Kid, Part II, The', 'Action|Adventure|Drama', 'Tamas Mickan');
insert into Movies (title, genres, director) values ('Vanquished, The (I vinti)', 'Drama', 'Alvinia Aim');
insert into Movies (title, genres, director) values ('About Schmidt', 'Comedy|Drama', 'Martyn Manzell');
insert into Movies (title, genres, director) values ('Final Cut', 'Drama', 'Darin Matisse');
insert into Movies (title, genres, director) values ('Unholy Wife, The', 'Crime|Drama', 'Vasili Issitt');
insert into Movies (title, genres, director) values ('Blues Brothers 2000', 'Action|Comedy|Musical', 'Howey Alam');
insert into Movies (title, genres, director) values ('Feel the Noise', 'Drama', 'Hedy Whatson');
insert into Movies (title, genres, director) values ('Sudden Impact', 'Crime|Thriller', 'Anny Higgoe');
insert into Movies (title, genres, director) values ('Pawn', 'Crime|Thriller', 'Alice Scutts');
insert into Movies (title, genres, director) values ('Below the Belt', 'Action|Comedy|Drama', 'Kacy Airds');
insert into Movies (title, genres, director) values ('All I Want for Christmas', 'Children|Comedy', 'Binni Charleston');
insert into Movies (title, genres, director) values ('My Friend Flicka', 'Children|Western', 'Lavina Dron');
insert into Movies (title, genres, director) values ('Big Eyes', 'Drama', 'Kamila Tweedle');
insert into Movies (title, genres, director) values ('Go Go Tales', 'Comedy|Drama', 'Kay Giacomo');
insert into Movies (title, genres, director) values ('Games', 'Thriller', 'Demott Forsdike');
insert into Movies (title, genres, director) values ('Homage', 'Drama', 'Filbert Nazareth');
insert into Movies (title, genres, director) values ('Dog Day Afternoon', 'Crime|Drama', 'Kirsteni Bembrick');
insert into Movies (title, genres, director) values ('Ballad of Narayama, The (Narayama bushiko)', 'Drama', 'Fred Campsall');
insert into Movies (title, genres, director) values ('Valley of the Bees (Údolí vcel)', 'Drama', 'Tailor Hacker');
insert into Movies (title, genres, director) values ('Deeper Shade of Blue, A', 'Documentary', 'Emalee Champkin');
insert into Movies (title, genres, director) values ('Hart''s War', 'Drama|War', 'Adams Gini');
insert into Movies (title, genres, director) values ('Wuthering Heights', 'Drama', 'Daphna Pentercost');
insert into Movies (title, genres, director) values ('Sword of Desperation (Hisshiken torisashi)', 'Action|Drama', 'Kliment Jarrette');
insert into Movies (title, genres, director) values ('Cheech and Chong''s Animated Movie', 'Animation|Comedy', 'Marsiella Wixey');
insert into Movies (title, genres, director) values ('Maria, ihm schmeckt''s nicht! (Maria, He Doesn''t Like It)', 'Comedy', 'Alfons MacAfee');
insert into Movies (title, genres, director) values ('Pepi, Luci, Bom (Pepi, Luci, Bom y Otras Chicas del Montón)', 'Comedy', 'Minda Holburn');
insert into Movies (title, genres, director) values ('Jimmy''s Hall', 'Drama', 'Trevor Rosten');
insert into Movies (title, genres, director) values ('Death in Buenos Aires (Muerte en Buenos Aires)', 'Crime|Drama|Romance', 'Allsun Knyvett');
insert into Movies (title, genres, director) values ('Sergeant Körmy and the Underwater Vehicles (Vääpeli Körmy ja vetenalaiset vehkeet)', 'Comedy', 'Catina Sergeant');
insert into Movies (title, genres, director) values ('Limits of Control, The', 'Crime|Drama|Film-Noir', 'Renaldo Rosendall');
insert into Movies (title, genres, director) values ('Miss Firecracker', 'Comedy', 'Banky Van Velden');
insert into Movies (title, genres, director) values ('Demonic', 'Horror|Thriller', 'Gabby Charon');
insert into Movies (title, genres, director) values ('International, The', 'Drama|Thriller', 'Curcio Crean');
insert into Movies (title, genres, director) values ('Cure, The', 'Drama', 'Brooke Bowyer');
insert into Movies (title, genres, director) values ('Black Sheep', 'Comedy', 'Mavra Corstan');
insert into Movies (title, genres, director) values ('Dust Factory, The', 'Adventure|Children|Romance', 'Bobinette Dinwoodie');
insert into Movies (title, genres, director) values ('Fatal Attraction', 'Drama|Thriller', 'Jillana Stringman');
insert into Movies (title, genres, director) values ('Seduced and Abandoned (Sedotta e abbandonata)', 'Comedy|Drama', 'Gloriane O''Spillane');
insert into Movies (title, genres, director) values ('One for the Money', 'Action|Comedy|Crime', 'Vergil Struis');
insert into Movies (title, genres, director) values ('St. George Shoots the Dragon (Sveti Georgije ubiva azdahu)', 'Drama|War', 'Lucine Schade');
insert into Movies (title, genres, director) values ('Little Stiff, A', 'Comedy', 'Rosemarie Cocksedge');
insert into Movies (title, genres, director) values ('Absolon', 'Action|Sci-Fi|Thriller', 'Kip Wisher');
insert into Movies (title, genres, director) values ('Monsters, Inc.', 'Adventure|Animation|Children|Comedy|Fantasy', 'Kennett Nicol');
insert into Movies (title, genres, director) values ('They Might Be Giants', 'Comedy|Mystery|Romance', 'Bert Bracci');
insert into Movies (title, genres, director) values ('Behind the Candelabra', 'Drama', 'Kylie Cordsen');
insert into Movies (title, genres, director) values ('Cinderella Liberty', 'Drama|Romance', 'Natalya Nolda');
insert into Movies (title, genres, director) values ('Generation Kill', 'Drama|War', 'Brand McKeaveney');
insert into Movies (title, genres, director) values ('Chungking Express (Chung Hing sam lam)', 'Drama|Mystery|Romance', 'Aldous Websdale');
insert into Movies (title, genres, director) values ('Kismet', 'Adventure|Comedy|Fantasy|Musical|Romance', 'Lay Jiricka');
insert into Movies (title, genres, director) values ('Longford', 'Crime|Drama', 'Caterina Dietz');
insert into Movies (title, genres, director) values ('Singing Nun, The', 'Comedy|Drama', 'Lorant Hargraves');
insert into Movies (title, genres, director) values ('Marksman, The', 'Action|Adventure|Thriller|War', 'Lindsey Keeping');
insert into Movies (title, genres, director) values ('Jack Brooks: Monster Slayer', 'Action|Comedy|Horror', 'Peria Birchenough');
insert into Movies (title, genres, director) values ('Best of the Best 3: No Turning Back', 'Action', 'Celestyna Gamblin');
insert into Movies (title, genres, director) values ('Alien Space Avenger', 'Comedy|Horror|Sci-Fi', 'Mendie Pegrum');
insert into Movies (title, genres, director) values ('Midnight Man', 'Action|Drama|Thriller', 'Jory Calcutt');
insert into Movies (title, genres, director) values ('Big Nothing', 'Comedy|Crime|Thriller', 'Avery Cammomile');
insert into Movies (title, genres, director) values ('Cowboys, The', 'Western', 'Kynthia Quare');
insert into Movies (title, genres, director) values ('Spooky House', 'Children', 'Win Adolphine');
insert into Movies (title, genres, director) values ('Liar, The (Valehtelija)', 'Comedy|Drama', 'Gerome Meake');
insert into Movies (title, genres, director) values ('When Brendan Met Trudy', 'Comedy|Romance', 'Harcourt Stanley');
insert into Movies (title, genres, director) values ('Bite the Bullet', 'Action|Adventure|Western', 'Estevan Elflain');
insert into Movies (title, genres, director) values ('Ice Age 2: The Meltdown', 'Adventure|Animation|Children|Comedy', 'Corey Chominski');
insert into Movies (title, genres, director) values ('Woman''s Tale, A', 'Drama', 'Rouvin Keune');
insert into Movies (title, genres, director) values ('Package, The', 'Action|Thriller', 'Fred Lamonby');
insert into Movies (title, genres, director) values ('Imagine I''m Beautiful', 'Drama', 'Hildegarde Gluyas');
insert into Movies (title, genres, director) values ('That Hamilton Woman', 'Drama|Romance|War', 'Lynnell Kindon');
insert into Movies (title, genres, director) values ('Dance Party, USA', 'Drama', 'Sophronia Eglise');
insert into Movies (title, genres, director) values ('Class of 1984', 'Action|Drama|Thriller', 'Willem Heminsley');
insert into Movies (title, genres, director) values ('Steel Toes', 'Crime|Drama', 'Florrie Du Plantier');
insert into Movies (title, genres, director) values ('Red Sorghum (Hong gao liang)', 'Drama|War', 'Sadye Woodger');
insert into Movies (title, genres, director) values ('Come Blow Your Horn', 'Comedy', 'Kaela Fabbri');
insert into Movies (title, genres, director) values ('Louise-Michel', 'Comedy', 'Nadya Willingale');
insert into Movies (title, genres, director) values ('He Ran All the Way', 'Crime|Drama|Film-Noir', 'Pietro Hudel');
insert into Movies (title, genres, director) values ('Yellow Cab Man, The', 'Comedy|Drama|Romance', 'Geri Auty');
insert into Movies (title, genres, director) values ('Electric Dreams', 'Comedy|Drama|Romance|Sci-Fi', 'Glen Kingsworth');
insert into Movies (title, genres, director) values ('Kaboom', 'Comedy|Sci-Fi', 'Tess Espinet');
insert into Movies (title, genres, director) values ('Intimacy', 'Drama', 'Pegeen Slevin');
insert into Movies (title, genres, director) values ('Gun Crazy (a.k.a. Deadly Is the Female)', 'Crime|Drama|Film-Noir', 'Giorgio Vlach');
insert into Movies (title, genres, director) values ('Orgy of the Dead', 'Horror', 'Shawna Doyle');
insert into Movies (title, genres, director) values ('They Died with Their Boots On', 'Drama|Romance|War|Western', 'Anetta Cancott');
insert into Movies (title, genres, director) values ('Tentacles (Tentacoli)', 'Horror|Sci-Fi|Thriller', 'Tiertza Franses');
insert into Movies (title, genres, director) values ('Pebble and the Penguin, The', 'Animation|Musical', 'Allard Paterno');
insert into Movies (title, genres, director) values ('Abbott and Costello Meet Captain Kidd', 'Adventure|Comedy|Musical', 'Huntington Giff');
insert into Movies (title, genres, director) values ('My Father the Hero (Mon père, ce héros.)', 'Comedy|Drama', 'Neron Mylechreest');
insert into Movies (title, genres, director) values ('Flock, The', 'Crime|Drama|Mystery|Thriller', 'Rutherford Grendon');
insert into Movies (title, genres, director) values ('Quitting (Zuotian)', 'Drama', 'Yolande Blackney');
insert into Movies (title, genres, director) values ('Mummy Returns, The', 'Action|Adventure|Comedy|Thriller', 'Wash Joincey');
insert into Movies (title, genres, director) values ('Scent of a Woman', 'Drama', 'Saudra Greystock');
insert into Movies (title, genres, director) values ('Caine (Shark!)', 'Action|Adventure|Thriller', 'Minnnie Lumley');
insert into Movies (title, genres, director) values ('Bad Seed, The', 'Drama|Thriller', 'Brandea Abadam');
insert into Movies (title, genres, director) values ('Carry on Cabby', 'Adventure|Comedy|Romance', 'Cordelia Hoble');
insert into Movies (title, genres, director) values ('Danton', 'Drama', 'Cointon Campione');
insert into Movies (title, genres, director) values ('Close', 'Drama', 'Darrelle Mitchel');
insert into Movies (title, genres, director) values ('Redline', 'Action', 'Cory Tythacott');
insert into Movies (title, genres, director) values ('Adventures of Huckleberry Finn, The', 'Adventure|Children', 'Julietta MacNamee');
insert into Movies (title, genres, director) values ('Broken Windows', 'Drama', 'Mina Kalderon');
insert into Movies (title, genres, director) values ('Rocketship X-M', 'Sci-Fi', 'Hoyt Baribal');
insert into Movies (title, genres, director) values ('Bound', 'Crime|Drama|Romance|Thriller', 'Emmy Torrie');
insert into Movies (title, genres, director) values ('Close', 'Drama', 'Duky Casaccio');
insert into Movies (title, genres, director) values ('Facing Windows (Finestra di fronte, La)', 'Drama|Romance', 'Devland Hames');
insert into Movies (title, genres, director) values ('Progression', 'Adventure|Documentary', 'Charley Gionettitti');
insert into Movies (title, genres, director) values ('Supporting Characters', 'Comedy|Romance', 'Griffith Dunkinson');
insert into Movies (title, genres, director) values ('Wild About Harry', 'Comedy|Drama|Romance', 'Mariya Tustin');
insert into Movies (title, genres, director) values ('Center Stage (Ruan Lingyu) (Actress, The) (New China Woman, The)', 'Drama|Romance', 'Kevina De Fraine');
insert into Movies (title, genres, director) values ('Xanadu', 'Fantasy|Musical|Romance', 'Birch Dimitriades');
insert into Movies (title, genres, director) values ('Conspiracy, The', 'Horror|Thriller', 'Terrie Spedroni');
insert into Movies (title, genres, director) values ('Beyond (Svinalängorna)', 'Drama', 'Lynnett Cumesky');
insert into Movies (title, genres, director) values ('Canciones de amor en Lolita''s Club', 'Drama', 'Natty Heyworth');
insert into Movies (title, genres, director) values ('Nowhere to Hide (Injeong sajeong bol geot eobtda)', 'Action|Comedy|Crime|Thriller', 'Sascha Belhome');
insert into Movies (title, genres, director) values ('Burt''s Buzz', 'Documentary', 'Roberta Wareing');
insert into Movies (title, genres, director) values ('Pilgrimage', 'Drama', 'Cherilyn Goldring');
insert into Movies (title, genres, director) values ('Hiding Cot (Piilopirtti)', 'Comedy', 'Tally Ballard');
insert into Movies (title, genres, director) values ('Weekend (a.k.a. Le Week-end) (Week End)', 'Drama', 'Collin Traves');
insert into Movies (title, genres, director) values ('400 Blows, The (Les quatre cents coups)', 'Crime|Drama', 'Simonette McGraith');
insert into Movies (title, genres, director) values ('Sweepers', 'Action|Adventure|Drama', 'Leonora Frearson');
insert into Movies (title, genres, director) values ('Any Which Way You Can', 'Comedy', 'Clement Piolli');
insert into Movies (title, genres, director) values ('Last Man Standing', 'Action|Crime|Drama|Thriller', 'Kip Lanbertoni');
insert into Movies (title, genres, director) values ('Ashes and Diamonds (Popiól i diament)', 'Drama|War', 'Reece Boken');
insert into Movies (title, genres, director) values ('Devil''s Carnival, The', 'Horror|Musical', 'Gerick Arboine');
insert into Movies (title, genres, director) values ('Yatterman (Yattâman)', 'Action|Comedy|Fantasy', 'Kingston Winscomb');
insert into Movies (title, genres, director) values ('Queen Christina', 'Drama|Romance', 'Adam Carrivick');
insert into Movies (title, genres, director) values ('Minion, The', 'Action|Fantasy|Horror', 'Barbabra Domerq');
insert into Movies (title, genres, director) values ('Susana (Devil and the Flesh, The)', 'Drama|Romance', 'Simona Juszczak');
insert into Movies (title, genres, director) values ('Predestination', 'Sci-Fi|Thriller', 'Janey Maffioletti');
insert into Movies (title, genres, director) values ('Donkey Skin (Peau d''âne)', 'Children|Drama|Fantasy|Musical|Romance', 'Modestia Sendley');
insert into Movies (title, genres, director) values ('Feast III: The Happy Finish', 'Action|Comedy|Horror', 'Kara-lynn Ellacombe');
insert into Movies (title, genres, director) values ('Abbott and Costello Meet the Killer, Boris Karloff', 'Comedy|Mystery|Thriller', 'Steffie Benoit');
insert into Movies (title, genres, director) values ('Same River Twice, The', 'Documentary', 'Margeaux Franks');
insert into Movies (title, genres, director) values ('Big Momma''s House 2', 'Action|Comedy|Crime', 'Sharia Mersh');
insert into Movies (title, genres, director) values ('Master of the Flying Guillotine (Du bi quan wang da po xue di zi)', 'Action', 'Nanice Blaylock');
insert into Movies (title, genres, director) values ('My First War', 'Documentary', 'Cammie Grichukhanov');
insert into Movies (title, genres, director) values ('I Heart Huckabees', 'Comedy', 'Emilie Fleury');
insert into Movies (title, genres, director) values ('Bob Saget: That Ain''t Right', 'Comedy', 'Glenda Loverock');
insert into Movies (title, genres, director) values ('Slither', 'Comedy|Horror|Sci-Fi', 'Mikaela Howerd');
insert into Movies (title, genres, director) values ('Fine Mess, A', 'Comedy', 'Cari De Mattei');
insert into Movies (title, genres, director) values ('Dead in the Water', 'Crime|Thriller', 'Lorri Imlock');
insert into Movies (title, genres, director) values ('Sins', 'Drama|Romance', 'Nettle Halfpenny');
insert into Movies (title, genres, director) values ('Alan Smithee Film: Burn Hollywood Burn, An', 'Comedy', 'Catriona Westfield');
insert into Movies (title, genres, director) values ('Change of Address (Changement d''adresse)', 'Comedy', 'Jamison McLeoid');
insert into Movies (title, genres, director) values ('If God Is Willing and da Creek Don''t Rise', 'Documentary', 'Celle Ramble');
insert into Movies (title, genres, director) values ('Batman: Gotham Knight', 'Action|Animation|Crime', 'Barbaraanne Suggey');
insert into Movies (title, genres, director) values ('Love Letters', 'Drama|Mystery|Romance', 'Merill Constantinou');
insert into Movies (title, genres, director) values ('Never Met Picasso', 'Romance', 'Seward Sheed');
insert into Movies (title, genres, director) values ('Tale of Tales (Skazka skazok)', 'Animation', 'Tiebout Leonardi');
insert into Movies (title, genres, director) values ('Three Wise Fools', 'Comedy|Drama', 'Billi Pontin');
insert into Movies (title, genres, director) values ('Mr. 3000', 'Comedy|Drama', 'Florian Jirzik');
insert into Movies (title, genres, director) values ('Black Dahlia, The', 'Crime|Drama|Mystery|Thriller', 'Corby Lill');
insert into Movies (title, genres, director) values ('Starred Up', 'Drama', 'Padraig Martonfi');
insert into Movies (title, genres, director) values ('Man I Love, The', 'Crime|Drama|Thriller', 'Emelen Vye');
insert into Movies (title, genres, director) values ('The White Haired Witch of Lunar Kingdom', 'Action|Fantasy', 'Tully Fawbert');


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into Watched (ip_address, title, director)
select ip_address
from Audiences
select title, director
from Movies
order by random()
limit 1000;

