/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */

/* All of the code is written for PostgreSQL

Our use case is that of a video streaming service with its subscribers. 
Our key goal is to identify which movies the subscribers have watched in order to recommend the next movie to watch.

The three tables are as follows:
1. Movies (Entity 1)
As each movie is uploaded to the service, it is assigned a MovieID which is unique and shall be used as our Primary Key.
We introduced a constraint to verify if the StreamingRights to the movie is 'Available' or 'Expired'.
A Subscriber will not be able to watch a film that has expired StreamingRights.

2. Subscriber (Entity 2)
As each subscriber joins our service, they are assigned a unique UserID that shall be used as our Primary Key although their email addresses could be also an alternative.
We introduced a constraint to verify if a Subscriber has an Active status (paid fees) to continue watching movies.

3. WatchedMovies (Relationship)
This table stores the record of which viewer has seen which movie. 
This can then be used in a recommendation model to suggest films that clients have not watched.
We have used a composite of Viewer and Movie as the primary key as we only aim to capture if a subscriber has seen a film.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS Movies (
Title VARCHAR(256) NOT NULL,
Genre VARCHAR (256) NOT NULL,
Duration INT NOT NULL,
MovieID INT PRIMARY KEY,
Rating INT NOT NULL, 
StreamingRights VARCHAR(256) CONSTRAINT StreamingRights CHECK(StreamingRights = 'Available' OR StreamingRights='Expired')
);

CREATE TABLE IF NOT EXISTS Subscriber (
Firstname VARCHAR(32) NOT NULL,
Lastname VARCHAR(32) NOT NULL,
Email VARCHAR(256) NOT NULL UNIQUE,
Address VARCHAR(256) NOT NULL,
Joined DATE NOT NULL,
UserID INT PRIMARY KEY,
Status VARCHAR(256) CONSTRAINT Status CHECK(Status = 'Active' OR Status='Expired')
);

CREATE TABLE IF NOT EXISTS WatchedMovies (
Viewer INT REFERENCES Subscriber(UserID) DEFERRABLE,
Movie INT REFERENCES Movies(MovieID) DEFERRABLE,
PRIMARY KEY (Viewer, Movie)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('The Confessions of Bernhard Goetz', 'Crime|Documentary', 49, '100001', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('El Dorado', 'Western', 183, '100002', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Birthday Girl', 'Drama|Romance', 61, '100003', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Boys Town', 'Drama', 220, '100004', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Dead Man''s Letters (Pisma myortvogo cheloveka)', 'Drama|Film-Noir', 196, '100005', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Lumumba', 'Drama', 58, '100006', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('2 Become 1 (Tin sun yut dui)', 'Comedy|Drama|Romance', 177, '100007', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Honeymoons', 'Comedy', 161, '100008', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Lost Missile, The', 'Sci-Fi', 160, '100009', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Raspberry Boat Refugee', 'Comedy', 211, '100010', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Princess and the Pirate, The', 'Adventure|Comedy|Romance', 119, '100011', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Rio Bravo', 'Western', 46, '100012', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Keeper, The', 'Crime|Drama|Thriller', 199, '100013', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('R.I.P.D.', 'Action|Comedy|Fantasy', 241, '100014', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Honey', 'Drama|Romance', 62, '100015', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Buried Alive', 'Film-Noir|Horror|Thriller', 84, '100016', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Cold Steel', 'Action|Thriller', 63, '100017', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Hart''s War', 'Drama|War', 105, '100018', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Dungeons & Dragons', 'Adventure|Fantasy', 191, '100019', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Eva', 'Drama|Fantasy|Sci-Fi', 180, '100020', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Man and a Woman, A (Un homme et une femme)', 'Drama|Romance', 218, '100021', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('3 Ring Circus', 'Comedy', 98, '100022', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Lakeboat', 'Comedy', 211, '100023', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('American Gothic', 'Horror', 166, '100024', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Passionada', 'Comedy|Romance', 97, '100025', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Svensson, Svensson - I nöd och lust', 'Comedy', 164, '100026', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Tooth & Nail', 'Drama|Horror|Sci-Fi', 52, '100027', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Never Say... Never! (Il ne faut jurer... de rien!)', 'Comedy', 93, '100028', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Camille', 'Comedy|Drama|Romance', 224, '100029', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Strapped', 'Action|Drama', 197, '100030', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('See the Sea', 'Thriller', 241, '100031', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Mummy, The', 'Horror|Romance', 197, '100032', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Winter Break', 'Comedy|Drama', 218, '100033', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Starfighters, The', 'Drama', 57, '100034', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Smiley', 'Horror', 244, '100035', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Rebound, The', 'Comedy|Romance', 223, '100036', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Girl 6', 'Comedy|Drama', 55, '100037', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Big Man Japan (Dai-Nihonjin)', 'Comedy|Sci-Fi', 157, '100038', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Lady Chatterley', 'Drama|Romance', 126, '100039', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Skin I Live In, The (La piel que habito)', 'Drama', 40, '100040', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Bad Medicine', 'Comedy', 247, '100041', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Bears', 'Documentary', 208, '100042', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Last Run, The', 'Action|Crime|Drama|Thriller', 95, '100043', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Heartbreak Kid, The', 'Comedy|Romance', 226, '100044', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Burn', 'Documentary', 121, '100045', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Wolf', 'Crime|Drama|Thriller', 143, '100046', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Female Convict Scorpion: Jailhouse 41 (Joshuu sasori: Dai-41 zakkyo-bô)', 'Crime|Drama|Thriller', 157, '100047', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Next Door (Naboer)', 'Horror|Mystery|Thriller', 150, '100048', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Chump at Oxford, A', 'Comedy', 222, '100049', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Beauty and the Beast (La belle et la bête)', 'Drama|Fantasy', 46, '100050', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Deadly Companions, The', 'Western', 64, '100051', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('400 Blows, The (Les quatre cents coups)', 'Crime|Drama', 40, '100052', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('The Bronze', 'Comedy|Drama', 49, '100053', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Violeta Went to Heaven (Violeta se fue a los cielos)', 'Drama', 58, '100054', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Psychosis', 'Crime|Horror|Mystery', 197, '100055', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Place Beyond the Pines, The', 'Crime|Drama', 140, '100056', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Ranma ½: Nihao My Concubine (Ranma ½: Kessen Tôgenkyô! Hanayome o torimodose!!)', 'Action|Adventure|Comedy|Fantasy|Romance', 221, '100057', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Liberty Kid', 'Drama', 58, '100058', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Zone Troopers', 'Action|Sci-Fi|War', 177, '100059', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('The White Sister', 'Drama|Romance', 247, '100060', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('King Kong vs. Godzilla (Kingukongu tai Gojira)', 'Action|Sci-Fi', 62, '100061', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Day the Earth Stood Still, The', 'Drama|Sci-Fi|Thriller', 62, '100062', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Hard Word, The', 'Comedy|Crime|Drama|Thriller', 223, '100063', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Love Affair', 'Drama|Romance', 63, '100064', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Sinister', 'Horror|Thriller', 175, '100065', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Typhoon (Tae-poong)', 'Action|Drama|Thriller', 221, '100066', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Kelly & Cal', 'Comedy|Drama', 132, '100067', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Demon Seed', 'Horror|Sci-Fi|Thriller', 149, '100068', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Waco: A New Revelation', 'Documentary', 183, '100069', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Police, Adjective (Politist, adj.)', 'Comedy|Crime|Drama', 217, '100070', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Dead Space: Downfall', 'Action|Animation|Sci-Fi', 116, '100071', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Night of the Zombies (a.k.a. Hell of the Living Dead) (Virus)', 'Action|Horror|Thriller', 160, '100072', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Second Woman, The', 'Drama|Film-Noir|Mystery', 138, '100073', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Raven, The', 'Comedy|Horror', 213, '100074', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Sweetwater', 'Thriller|Western', 146, '100075', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Coffee Town', 'Comedy', 136, '100076', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Love in the Time of Hysteria (Sólo con tu pareja)', 'Comedy|Romance', 183, '100077', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Offside', 'Comedy|Drama', 200, '100078', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('LEGO DC Comics Super Heroes: Justice League vs. Bizarro League', 'Action|Adventure|Animation|Children', 215, '100079', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('History of Kim Skov (Historien om Kim Skov)', 'Documentary|Drama', 111, '100080', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Tsotsi', 'Crime|Drama', 238, '100081', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Autumn Ball (Sügisball)', 'Drama', 41, '100082', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Monkeybone', 'Animation|Comedy|Fantasy', 221, '100083', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('7th Cavalry (Seventh Cavalry)', 'Western', 146, '100084', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Born to Win', 'Drama', 151, '100085', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Manchurian Candidate, The', 'Thriller', 142, '100086', 2, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Barry Munday', 'Comedy', 127, '100087', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Rock School', 'Documentary', 90, '100088', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Cookie', 'Comedy|Crime', 216, '100089', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Remonstrance', '(no genres listed)', 170, '100090', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Shattered', 'Mystery|Thriller', 90, '100091', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('American Ninja', 'Action|Adventure', 160, '100092', 1, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('All American Orgy (Cummings Farm)', 'Comedy', 197, '100093', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Rage, The', 'Horror|Sci-Fi', 180, '100094', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Raajneeti', 'Crime|Drama|Romance', 195, '100095', 4, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Winged Migration (Peuple migrateur, Le)', 'Documentary', 248, '100096', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Magic Gloves, The (Los guantes mágicos)', 'Comedy|Drama', 83, '100097', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Up in the Wind', 'Comedy', 132, '100098', 3, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Ten Canoes', 'Adventure|Comedy|Drama|War', 221, '100099', 5, 'Available');
insert into movies (Title, Genre, Duration, MovieID, Rating, StreamingRights) values ('Happy Birthday to Me', 'Horror|Mystery', 242, '100100', 4, 'Available');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Vergil', 'Ingray', 'vingray0@pcworld.com', '0 Welch Terrace', '02/06/2006', '810001', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Robby', 'Fielding', 'rfielding1@rambler.ru', '28 Rusk Street', '10/06/2017', '810002', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Aldric', 'Ayerst', 'aayerst2@sourceforge.net', '5 Arrowood Crossing', '24/08/2015', '810003', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Pansie', 'Lindroos', 'plindroos3@salon.com', '9 Clarendon Junction', '15/05/2009', '810004', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Estevan', 'Tidd', 'etidd4@sakura.ne.jp', '7641 Alpine Crossing', '05/06/2021', '810005', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Doralynn', 'Guerreru', 'dguerreru5@bbb.org', '33 Sutherland Way', '15/02/2016', '810006', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Babbette', 'Skully', 'bskully6@tripod.com', '43993 Golf Avenue', '25/06/2012', '810007', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Korry', 'Murkitt', 'kmurkitt7@g.co', '43 Golf View Junction', '05/05/2005', '810008', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Barnebas', 'Sired', 'bsired8@istockphoto.com', '59 Thackeray Point', '20/05/2019', '810009', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Eunice', 'Marjanovic', 'emarjanovic9@virginia.edu', '62 Bluestem Hill', '04/12/2010', '810010', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Gil', 'Jirasek', 'gjiraseka@vimeo.com', '9 Norway Maple Park', '05/12/2015', '810011', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Tami', 'Kinnerley', 'tkinnerleyb@mediafire.com', '560 Oriole Park', '18/04/2018', '810012', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Ashbey', 'Comerford', 'acomerfordc@smugmug.com', '44981 Jackson Park', '22/05/2020', '810013', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Law', 'MacQuaker', 'lmacquakerd@devhub.com', '0 Myrtle Hill', '13/06/2021', '810014', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Chrystel', 'Speeks', 'cspeekse@behance.net', '53 Atwood Park', '04/10/2014', '810015', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Gates', 'Swatten', 'gswattenf@odnoklassniki.ru', '74683 Delladonna Park', '03/07/2021', '810016', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Katrine', 'Oakly', 'koaklyg@example.com', '52 Old Gate Parkway', '27/01/2016', '810017', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Yasmeen', 'Seaman', 'yseamanh@illinois.edu', '886 Veith Alley', '21/12/2003', '810018', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Dagny', 'Kingsnod', 'dkingsnodi@paypal.com', '234 Waubesa Parkway', '18/02/2002', '810019', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Iain', 'Creavin', 'icreavinj@npr.org', '14273 Lien Junction', '22/06/2016', '810020', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Mendy', 'Lamar', 'mlamark@xing.com', '59 Glacier Hill Drive', '27/08/2017', '810021', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Hilarius', 'Keyzman', 'hkeyzmanl@moonfruit.com', '592 Acker Alley', '11/11/2007', '810022', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Noami', 'Rentelll', 'nrentelllm@github.io', '09 Drewry Plaza', '17/12/2016', '810023', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Freddie', 'Goodwins', 'fgoodwinsn@blog.com', '9 West Hill', '18/09/2009', '810024', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Zed', 'McColl', 'zmccollo@booking.com', '07 Declaration Alley', '05/04/2013', '810025', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Scotty', 'Stickings', 'sstickingsp@msu.edu', '676 Stoughton Place', '25/05/2003', '810026', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Corella', 'Skirving', 'cskirvingq@yellowpages.com', '0 Eggendart Park', '02/08/2005', '810027', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Xylina', 'Callingham', 'xcallinghamr@hostgator.com', '39 Buhler Junction', '31/08/2003', '810028', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Natalya', 'Kondrat', 'nkondrats@uiuc.edu', '685 Sunbrook Circle', '09/10/2019', '810029', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Hube', 'Cheng', 'hchengt@discuz.net', '1748 Maple Wood Junction', '26/04/2003', '810030', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Ericka', 'Dowell', 'edowellu@freewebs.com', '6 Hansons Lane', '07/06/2014', '810031', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Cherilynn', 'Dobrowski', 'cdobrowskiv@cloudflare.com', '391 Russell Lane', '12/06/2014', '810032', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Nikolos', 'Dettmar', 'ndettmarw@businessweek.com', '48 Lake View Place', '02/04/2004', '810033', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Joni', 'Lowbridge', 'jlowbridgex@amazon.co.jp', '76 Sunbrook Street', '07/01/2017', '810034', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Daryle', 'Scurr', 'dscurry@oaic.gov.au', '30 Mccormick Drive', '09/05/2007', '810035', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Leland', 'Casillas', 'lcasillasz@hibu.com', '643 Susan Circle', '15/08/2007', '810036', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Wade', 'Crosswaite', 'wcrosswaite10@seesaa.net', '949 Elka Terrace', '20/09/2019', '810037', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Egor', 'Flack', 'eflack11@edublogs.org', '3744 Wayridge Hill', '23/12/2016', '810038', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Idelle', 'Donne', 'idonne12@cbsnews.com', '4 Superior Plaza', '19/05/2018', '810039', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Milicent', 'Bourdice', 'mbourdice13@seesaa.net', '697 Prairie Rose Trail', '22/07/2001', '810040', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Meade', 'Alston', 'malston14@hibu.com', '16730 Independence Trail', '20/01/2020', '810041', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Bailey', 'Quigley', 'bquigley15@cmu.edu', '1 Namekagon Hill', '01/06/2020', '810042', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Rachele', 'Withey', 'rwithey16@virginia.edu', '1258 Graceland Parkway', '10/06/2017', '810043', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Huntington', 'Grievson', 'hgrievson17@nymag.com', '2667 Cascade Circle', '21/03/2005', '810044', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Ham', 'Meriet', 'hmeriet18@engadget.com', '14818 Daystar Court', '25/02/2004', '810045', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Ella', 'Golton', 'egolton19@yellowbook.com', '5 Transport Circle', '16/11/2004', '810046', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Hamilton', 'Kilmurry', 'hkilmurry1a@livejournal.com', '6724 Arizona Drive', '22/03/2009', '810047', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Guntar', 'Torvey', 'gtorvey1b@miitbeian.gov.cn', '5966 Old Gate Terrace', '09/09/2018', '810048', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Jourdain', 'Diggar', 'jdiggar1c@uol.com.br', '12 Nova Crossing', '25/01/2003', '810049', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Benedetto', 'Taylour', 'btaylour1d@gmpg.org', '082 Spohn Junction', '15/03/2014', '810050', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Donella', 'Keysall', 'dkeysall1e@mashable.com', '2 Golden Leaf Point', '26/05/2009', '810051', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Lynelle', 'Clifton', 'lclifton1f@sbwire.com', '24 Johnson Street', '05/05/2021', '810052', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Leela', 'Jacomb', 'ljacomb1g@wikia.com', '5 Kensington Trail', '08/06/2017', '810053', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Ulrikaumeko', 'Knuckles', 'uknuckles1h@whitehouse.gov', '923 Rutledge Lane', '17/07/2019', '810054', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Laird', 'Illingsworth', 'lillingsworth1i@blinklist.com', '274 Welch Circle', '25/06/2018', '810055', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Normie', 'Gleder', 'ngleder1j@bbb.org', '0 Sunnyside Way', '28/01/2008', '810056', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Josie', 'Torresi', 'jtorresi1k@seattletimes.com', '3573 Hazelcrest Parkway', '14/05/2007', '810057', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Jourdain', 'Smardon', 'jsmardon1l@biblegateway.com', '67837 Bartillon Trail', '05/07/2008', '810058', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Lynsey', 'Dahmke', 'ldahmke1m@yahoo.com', '91777 Mayfield Pass', '11/07/2014', '810059', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Emmy', 'Gabbetis', 'egabbetis1n@livejournal.com', '28 Saint Paul Point', '28/08/2008', '810060', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Aldo', 'Sans', 'asans1o@woothemes.com', '9 Rutledge Road', '10/05/2017', '810061', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Maxy', 'Boulter', 'mboulter1p@aboutads.info', '2 Crownhardt Way', '15/02/2021', '810062', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Sibylla', 'Plummer', 'splummer1q@examiner.com', '53287 Glendale Point', '07/01/2011', '810063', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Maggy', 'Glamart', 'mglamart1r@buzzfeed.com', '410 Mcbride Pass', '09/07/2008', '810064', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Aubrie', 'Wagon', 'awagon1s@drupal.org', '3 Debs Plaza', '21/06/2012', '810065', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Orelie', 'Enochsson', 'oenochsson1t@themeforest.net', '2136 Schurz Alley', '15/05/2016', '810066', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Stacie', 'Kerr', 'skerr1u@bloglines.com', '80 Bartelt Parkway', '16/11/2013', '810067', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Vernen', 'Kinsella', 'vkinsella1v@goo.gl', '5 Gateway Lane', '04/03/2014', '810068', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Carlye', 'Innman', 'cinnman1w@google.ru', '13313 Larry Plaza', '19/06/2010', '810069', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Ruby', 'Sebyer', 'rsebyer1x@answers.com', '94 Esch Way', '02/02/2008', '810070', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Fiann', 'Guitte', 'fguitte1y@mediafire.com', '3087 Macpherson Way', '29/02/2012', '810071', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Emmanuel', 'Deeks', 'edeeks1z@utexas.edu', '9715 Granby Place', '24/05/2010', '810072', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Mikel', 'Kasbye', 'mkasbye20@vimeo.com', '251 Emmet Terrace', '04/10/2008', '810073', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Annecorinne', 'Conlon', 'aconlon21@newyorker.com', '1793 Katie Lane', '25/12/2016', '810074', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Loralie', 'Bramble', 'lbramble22@trellian.com', '2 Briar Crest Court', '01/10/2017', '810075', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Dorelle', 'Capponeer', 'dcapponeer23@parallels.com', '6375 Westerfield Park', '23/10/2010', '810076', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Hurleigh', 'Jude', 'hjude24@opera.com', '3096 Carey Center', '01/01/2009', '810077', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Tera', 'Illing', 'tilling25@amazonaws.com', '246 Surrey Road', '01/10/2011', '810078', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Sauncho', 'Duffree', 'sduffree26@ucla.edu', '7 Fuller Plaza', '24/08/2015', '810079', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Joyous', 'Gionettitti', 'jgionettitti27@eventbrite.com', '00 Scoville Pass', '29/02/2004', '810080', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Melisse', 'Mapis', 'mmapis28@intel.com', '42236 Oakridge Terrace', '18/11/2010', '810081', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Joellyn', 'Hansmann', 'jhansmann29@nsw.gov.au', '099 Bultman Hill', '14/08/2012', '810082', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Priscilla', 'Furbank', 'pfurbank2a@intel.com', '9 Karstens Trail', '14/08/2005', '810083', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Dorita', 'Peltzer', 'dpeltzer2b@jugem.jp', '4191 Bellgrove Court', '20/03/2021', '810084', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Maryann', 'Rubenov', 'mrubenov2c@ibm.com', '178 Londonderry Plaza', '23/08/2007', '810085', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Gustavo', 'Stockin', 'gstockin2d@nyu.edu', '7 Express Hill', '23/07/2017', '810086', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Gaile', 'Capner', 'gcapner2e@weibo.com', '75198 Kipling Point', '25/12/2002', '810087', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Lexine', 'Ilyasov', 'lilyasov2f@dell.com', '460 Russell Park', '01/07/2004', '810088', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Jeffy', 'Franek', 'jfranek2g@topsy.com', '226 Talmadge Hill', '24/02/2013', '810089', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Jacynth', 'Twinbourne', 'jtwinbourne2h@simplemachines.org', '923 Spenser Hill', '04/10/2007', '810090', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Kellia', 'Hoogendorp', 'khoogendorp2i@harvard.edu', '30191 Lillian Plaza', '21/06/2003', '810091', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Bradney', 'Denne', 'bdenne2j@tinyurl.com', '26765 Loftsgordon Drive', '16/09/2006', '810092', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Raynor', 'Faux', 'rfaux2k@flickr.com', '450 School Point', '20/08/2001', '810093', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Vick', 'Itschakov', 'vitschakov2l@aboutads.info', '4697 Meadow Ridge Way', '26/12/2017', '810094', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Tomlin', 'Hemphrey', 'themphrey2m@hhs.gov', '4 Hanover Road', '06/08/2019', '810095', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Carmen', 'Haslehurst', 'chaslehurst2n@yolasite.com', '8 Forest Dale Place', '16/08/2010', '810096', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Maurizio', 'Alibone', 'malibone2o@facebook.com', '94 Anzinger Parkway', '30/08/2016', '810097', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Yardley', 'Tabourel', 'ytabourel2p@va.gov', '73821 Warrior Trail', '25/12/2020', '810098', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Ferdinand', 'McIlvaney', 'fmcilvaney2q@alexa.com', '908 Memorial Plaza', '16/02/2001', '810099', 'Active');
insert into subscriber (Firstname, Lastname, Email, Address, Joined, UserID, Status) values ('Gustie', 'Wickins', 'gwickins2r@ning.com', '036 Maryland Junction', '27/10/2012', '810100', 'Active');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO watchedmovies(Viewer, Movie)
SELECT a.UserID, b.MovieID
FROM Subscriber a, Movies b
WHERE a.status = 'Active' AND b.StreamingRights = 'Available'
ORDER BY RANDOM()
LIMIT 1000
;