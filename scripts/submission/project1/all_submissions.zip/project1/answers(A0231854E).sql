/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/* Mingxuan Yang/E0709109@u.nus.edu                                     */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/

/* The code is written for PostgreSQL. */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/

/*
The content of the three tables is first, a buyers table (entity set E1), containing 
buyer information such as buyer ID, gender, e-mail, and their credit card type (if 
they used credit card when making the purchase). The other table, cars (entity set E2),
is a table containing car purchased information related information including model, 
color, and price. The many-to-many relationship set R, table name preferences, associates 
the buyers' ID with their purchased car model and color. This table seems like it could 
be used in attempt to examine buyers' preferences in terms of car models and colors.

The following questions are written for PostgreSQL.
*/

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS buyers (
	buyerid VARCHAR(64) PRIMARY KEY,
	gender VARCHAR(16) NOT NULL,
	email VARCHAR(64) UNIQUE NOT NULL,
	card VARCHAR(50) 
);

CREATE TABLE IF NOT EXISTS cars (
	model VARCHAR(64) NOT NULL,
	color VARCHAR(64) NOT NULL,
	price VARCHAR(64) NOT NULL,
	primary key (model, color)
);

CREATE TABLE IF NOT EXISTS preferences (
	buyerid VARCHAR(64) REFERENCES buyers(buyerid),
	model VARCHAR(64),
	color VARCHAR(64),
	PRIMARY KEY (buyerid, model, color),
	FOREIGN KEY (model, color) REFERENCES cars(model, color)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/*POPULATE THE NAMES TABLE*/
insert into buyers (buyerid, gender, email, card) values ('tkeig0', 'Agender', 'abothen0@ucoz.com', null);
insert into buyers (buyerid, gender, email, card) values ('fsigg1', 'Bigender', 'cscotchford1@gravatar.com', 'americanexpress');
insert into buyers (buyerid, gender, email, card) values ('hglavis2', 'Female', 'gollivierre2@answers.com', null);
insert into buyers (buyerid, gender, email, card) values ('sklugel3', 'Female', 'candree3@bandcamp.com', 'americanexpress');
insert into buyers (buyerid, gender, email, card) values ('hlozano4', 'Agender', 'cranken4@go.com', null);
insert into buyers (buyerid, gender, email, card) values ('chowerd5', 'Bigender', 'jhalsey5@patch.com', null);
insert into buyers (buyerid, gender, email, card) values ('ktuplin6', 'Genderqueer', 'ilambird6@ycombinator.com', null);
insert into buyers (buyerid, gender, email, card) values ('vcasier7', 'Polygender', 'bbowld7@booking.com', null);
insert into buyers (buyerid, gender, email, card) values ('scuree8', 'Male', 'escripture8@oakley.com', null);
insert into buyers (buyerid, gender, email, card) values ('klynagh9', 'Genderfluid', 'blinnane9@vinaora.com', null);
insert into buyers (buyerid, gender, email, card) values ('pacastera', 'Female', 'iloudwella@berkeley.edu', null);
insert into buyers (buyerid, gender, email, card) values ('mchrishopb', 'Non-binary', 'pworgeb@slate.com', null);
insert into buyers (buyerid, gender, email, card) values ('vcanedoc', 'Male', 'chaycroftc@netscape.com', null);
insert into buyers (buyerid, gender, email, card) values ('edmiterkod', 'Female', 'acholomind@amazon.co.uk', null);
insert into buyers (buyerid, gender, email, card) values ('dschermee', 'Non-binary', 'aspellinge@adobe.com', null);
insert into buyers (buyerid, gender, email, card) values ('hwyburnf', 'Male', 'imarklundf@wp.com', null);
insert into buyers (buyerid, gender, email, card) values ('tshivling', 'Female', 'lgalileeg@harvard.edu', null);
insert into buyers (buyerid, gender, email, card) values ('caddeycotth', 'Genderfluid', 'ecoenh@cnbc.com', null);
insert into buyers (buyerid, gender, email, card) values ('rballami', 'Polygender', 'apinardi@ocn.ne.jp', null);
insert into buyers (buyerid, gender, email, card) values ('rfetterj', 'Agender', 'sgreystokej@cdc.gov', null);
insert into buyers (buyerid, gender, email, card) values ('abreitlerk', 'Non-binary', 'ugammettk@istockphoto.com', 'americanexpress');
insert into buyers (buyerid, gender, email, card) values ('pmeffanl', 'Agender', 'acooplandl@t-online.de', null);
insert into buyers (buyerid, gender, email, card) values ('dprestedgem', 'Polygender', 'wmquhargem@topsy.com', null);
insert into buyers (buyerid, gender, email, card) values ('jcanetn', 'Bigender', 'scullumn@hhs.gov', null);
insert into buyers (buyerid, gender, email, card) values ('ootuohyo', 'Female', 'baherneo@goo.gl', null);
insert into buyers (buyerid, gender, email, card) values ('kisakowiczp', 'Non-binary', 'wgrummittp@sitemeter.com', null);
insert into buyers (buyerid, gender, email, card) values ('jcradeyq', 'Agender', 'jpretsellq@shutterfly.com', null);
insert into buyers (buyerid, gender, email, card) values ('hhanr', 'Non-binary', 'gmitchelhillr@stanford.edu', null);
insert into buyers (buyerid, gender, email, card) values ('ptattersfields', 'Bigender', 'bbowkleys@taobao.com', null);
insert into buyers (buyerid, gender, email, card) values ('mgosst', 'Agender', 'aduftont@friendfeed.com', 'americanexpress');
insert into buyers (buyerid, gender, email, card) values ('tmaclaigu', 'Genderfluid', 'grochesteru@dedecms.com', null);
insert into buyers (buyerid, gender, email, card) values ('sfaltskogv', 'Genderqueer', 'agriffinv@weebly.com', null);
insert into buyers (buyerid, gender, email, card) values ('fmcclarenw', 'Genderqueer', 'cbruntw@themeforest.net', 'americanexpress');
insert into buyers (buyerid, gender, email, card) values ('smichelottix', 'Agender', 'sleaknerx@flavors.me', null);
insert into buyers (buyerid, gender, email, card) values ('ldwerryhousey', 'Male', 'jnilesy@plala.or.jp', null);
insert into buyers (buyerid, gender, email, card) values ('despinetz', 'Non-binary', 'debunoluwaz@usnews.com', null);
insert into buyers (buyerid, gender, email, card) values ('dsarfatti10', 'Genderfluid', 'lellacott10@odnoklassniki.ru', null);
insert into buyers (buyerid, gender, email, card) values ('mbeddie11', 'Non-binary', 'obrecknock11@4shared.com', null);
insert into buyers (buyerid, gender, email, card) values ('sallmark12', 'Male', 'cwhiles12@china.com.cn', null);
insert into buyers (buyerid, gender, email, card) values ('ksandbatch13', 'Genderfluid', 'kruffey13@harvard.edu', null);
insert into buyers (buyerid, gender, email, card) values ('bbilbrook14', 'Female', 'kstichel14@tripadvisor.com', null);
insert into buyers (buyerid, gender, email, card) values ('grisby15', 'Female', 'eclemmey15@free.fr', null);
insert into buyers (buyerid, gender, email, card) values ('skelberer16', 'Male', 'mgascoine16@wikispaces.com', null);
insert into buyers (buyerid, gender, email, card) values ('awhittington17', 'Polygender', 'mgiacaponi17@privacy.gov.au', 'mastercard');
insert into buyers (buyerid, gender, email, card) values ('wvondrach18', 'Bigender', 'pjunifer18@latimes.com', null);
insert into buyers (buyerid, gender, email, card) values ('ctogher19', 'Male', 'bkeers19@plala.or.jp', 'mastercard');
insert into buyers (buyerid, gender, email, card) values ('celph1a', 'Polygender', 'tspelman1a@bbb.org', null);
insert into buyers (buyerid, gender, email, card) values ('hshorie1b', 'Non-binary', 'dbeck1b@disqus.com', null);
insert into buyers (buyerid, gender, email, card) values ('randriss1c', 'Female', 'hsimak1c@comcast.net', 'mastercard');
insert into buyers (buyerid, gender, email, card) values ('vlindsell1d', 'Genderfluid', 'bbiggerstaff1d@phpbb.com', null);
insert into buyers (buyerid, gender, email, card) values ('abeardshall1e', 'Polygender', 'dosherin1e@telegraph.co.uk', null);
insert into buyers (buyerid, gender, email, card) values ('ejanse1f', 'Bigender', 'arosenwasser1f@senate.gov', 'americanexpress');
insert into buyers (buyerid, gender, email, card) values ('arabier1g', 'Non-binary', 'cdugood1g@w3.org', null);
insert into buyers (buyerid, gender, email, card) values ('hbodleigh1h', 'Female', 'fstation1h@discuz.net', null);
insert into buyers (buyerid, gender, email, card) values ('msaw1i', 'Non-binary', 'mdunlop1i@tripod.com', null);
insert into buyers (buyerid, gender, email, card) values ('hbucklee1j', 'Non-binary', 'wroom1j@yale.edu', 'americanexpress');
insert into buyers (buyerid, gender, email, card) values ('mcatterick1k', 'Male', 'blamzed1k@patch.com', 'mastercard');
insert into buyers (buyerid, gender, email, card) values ('imccafferty1l', 'Genderqueer', 'pgumm1l@mapy.cz', null);
insert into buyers (buyerid, gender, email, card) values ('shallitt1m', 'Non-binary', 'sbirkett1m@xing.com', 'americanexpress');
insert into buyers (buyerid, gender, email, card) values ('dwhitmore1n', 'Bigender', 'lsamber1n@wikispaces.com', null);
insert into buyers (buyerid, gender, email, card) values ('gwoodley1o', 'Bigender', 'asollis1o@buzzfeed.com', null);
insert into buyers (buyerid, gender, email, card) values ('aollerton1p', 'Female', 'jstille1p@wikia.com', null);
insert into buyers (buyerid, gender, email, card) values ('bmelia1q', 'Bigender', 'mbrussels1q@photobucket.com', null);
insert into buyers (buyerid, gender, email, card) values ('rbalchen1r', 'Non-binary', 'ewingeat1r@pagesperso-orange.fr', null);
insert into buyers (buyerid, gender, email, card) values ('rguppie1s', 'Non-binary', 'efranzolini1s@samsung.com', null);
insert into buyers (buyerid, gender, email, card) values ('lnerval1t', 'Polygender', 'dcockerill1t@livejournal.com', null);
insert into buyers (buyerid, gender, email, card) values ('cboundley1u', 'Non-binary', 'hholdworth1u@scientificamerican.com', null);
insert into buyers (buyerid, gender, email, card) values ('bdulanty1v', 'Bigender', 'jyakunin1v@timesonline.co.uk', null);
insert into buyers (buyerid, gender, email, card) values ('fgilliatt1w', 'Female', 'igittins1w@hatena.ne.jp', null);
insert into buyers (buyerid, gender, email, card) values ('jmaseyk1x', 'Non-binary', 'cvere1x@bandcamp.com', null);
insert into buyers (buyerid, gender, email, card) values ('womeara1y', 'Genderfluid', 'jbracknell1y@fastcompany.com', null);
insert into buyers (buyerid, gender, email, card) values ('dpepineaux1z', 'Male', 'asywell1z@harvard.edu', null);
insert into buyers (buyerid, gender, email, card) values ('sflanaghan20', 'Genderfluid', 'cguillford20@ifeng.com', null);
insert into buyers (buyerid, gender, email, card) values ('hneller21', 'Female', 'sjozsa21@economist.com', null);
insert into buyers (buyerid, gender, email, card) values ('mjarred22', 'Genderfluid', 'frobbe22@time.com', null);
insert into buyers (buyerid, gender, email, card) values ('scaughte23', 'Polygender', 'llazer23@hp.com', null);
insert into buyers (buyerid, gender, email, card) values ('cblakeman24', 'Non-binary', 'ralvarez24@mtv.com', null);
insert into buyers (buyerid, gender, email, card) values ('ydyball25', 'Bigender', 'cjarrold25@washington.edu', 'americanexpress');
insert into buyers (buyerid, gender, email, card) values ('hbladesmith26', 'Bigender', 'bgulberg26@g.co', null);
insert into buyers (buyerid, gender, email, card) values ('kturville27', 'Bigender', 'drenols27@newsvine.com', null);
insert into buyers (buyerid, gender, email, card) values ('asalvati28', 'Genderfluid', 'opyer28@tuttocitta.it', null);
insert into buyers (buyerid, gender, email, card) values ('gegleofgermany29', 'Agender', 'cborsi29@imageshack.us', null);
insert into buyers (buyerid, gender, email, card) values ('stinsey2a', 'Genderqueer', 'rjakubovicz2a@whitehouse.gov', null);
insert into buyers (buyerid, gender, email, card) values ('rbedminster2b', 'Non-binary', 'ivaney2b@businessinsider.com', null);
insert into buyers (buyerid, gender, email, card) values ('akabsch2c', 'Male', 'mwoolvett2c@ning.com', null);
insert into buyers (buyerid, gender, email, card) values ('csinncock2d', 'Female', 'gcains2d@tuttocitta.it', null);
insert into buyers (buyerid, gender, email, card) values ('rlindborg2e', 'Female', 'kmacenelly2e@wired.com', null);
insert into buyers (buyerid, gender, email, card) values ('joakwell2f', 'Genderqueer', 'dwathey2f@si.edu', null);
insert into buyers (buyerid, gender, email, card) values ('dvalentine2g', 'Genderqueer', 'hrivallant2g@seesaa.net', 'americanexpress');
insert into buyers (buyerid, gender, email, card) values ('jtimmes2h', 'Genderfluid', 'siacopini2h@cloudflare.com', null);
insert into buyers (buyerid, gender, email, card) values ('ilongman2i', 'Bigender', 'vbeetham2i@tuttocitta.it', null);
insert into buyers (buyerid, gender, email, card) values ('afairlie2j', 'Male', 'stingcomb2j@themeforest.net', null);
insert into buyers (buyerid, gender, email, card) values ('mannice2k', 'Genderfluid', 'rrennebeck2k@tripadvisor.com', null);
insert into buyers (buyerid, gender, email, card) values ('gmapplethorpe2l', 'Female', 'mramey2l@t.co', null);
insert into buyers (buyerid, gender, email, card) values ('lcornford2m', 'Agender', 'csemrad2m@census.gov', null);
insert into buyers (buyerid, gender, email, card) values ('bvenner2n', 'Bigender', 'nranklin2n@webeden.co.uk', null);
insert into buyers (buyerid, gender, email, card) values ('lwarner2o', 'Non-binary', 'tunion2o@canalblog.com', 'americanexpress');
insert into buyers (buyerid, gender, email, card) values ('fkroger2p', 'Agender', 'bfoakes2p@amazon.co.uk', null);
insert into buyers (buyerid, gender, email, card) values ('jwastling2q', 'Female', 'wfossey2q@opera.com', null);
insert into buyers (buyerid, gender, email, card) values ('mhugnet2r', 'Male', 'jojeda2r@uol.com.br', 'mastercard');

insert into cars (model, color, price) values ('Azera', 'Goldenrod', '$99432.10');
insert into cars (model, color, price) values ('F250', 'Teal', '$65845.94');
insert into cars (model, color, price) values ('Explorer Sport Trac', 'Blue', '$156460.44');
insert into cars (model, color, price) values ('DeVille', 'Crimson', '$180768.28');
insert into cars (model, color, price) values ('Wrangler', 'Red', '$117864.79');
insert into cars (model, color, price) values ('M-Class', 'Purple', '$106572.45');
insert into cars (model, color, price) values ('R8', 'Teal', '$74475.51');
insert into cars (model, color, price) values ('Freestyle', 'Crimson', '$94139.83');
insert into cars (model, color, price) values ('XJ Series', 'Purple', '$85440.93');
insert into cars (model, color, price) values ('911', 'Red', '$191005.49');
insert into cars (model, color, price) values ('E-Class', 'Purple', '$72178.53');
insert into cars (model, color, price) values ('MPV', 'Aquamarine', '$164918.81');
insert into cars (model, color, price) values ('Mighty Max Macro', 'Indigo', '$192540.61');
insert into cars (model, color, price) values ('Boxster', 'Orange', '$126644.40');
insert into cars (model, color, price) values ('Continental GT', 'Indigo', '$80476.66');
insert into cars (model, color, price) values ('GranTurismo', 'Goldenrod', '$76521.89');
insert into cars (model, color, price) values ('TT', 'Blue', '$164012.96');
insert into cars (model, color, price) values ('QX', 'Aquamarine', '$171884.34');
insert into cars (model, color, price) values ('RL', 'Pink', '$139229.87');
insert into cars (model, color, price) values ('Silverado 3500', 'Yellow', '$59120.15');
insert into cars (model, color, price) values ('Savana', 'Goldenrod', '$68719.67');
insert into cars (model, color, price) values ('Grand Prix', 'Goldenrod', '$62959.95');
insert into cars (model, color, price) values ('Silverado 1500', 'Indigo', '$120661.50');
insert into cars (model, color, price) values ('Grand Prix', 'Maroon', '$136993.21');
insert into cars (model, color, price) values ('D150', 'Indigo', '$178718.30');
insert into cars (model, color, price) values ('Integra', 'Yellow', '$41883.54');
insert into cars (model, color, price) values ('Expedition EL', 'Yellow', '$194410.82');
insert into cars (model, color, price) values ('B-Series', 'Indigo', '$90486.17');
insert into cars (model, color, price) values ('Range Rover', 'Turquoise', '$44829.66');
insert into cars (model, color, price) values ('Spectra', 'Aquamarine', '$29449.54');
insert into cars (model, color, price) values ('Corvette', 'Blue', '$190281.09');
insert into cars (model, color, price) values ('Durango', 'Fuscia', '$41596.97');
insert into cars (model, color, price) values ('Bonneville', 'Violet', '$65174.86');
insert into cars (model, color, price) values ('SVX', 'Mauv', '$84147.78');
insert into cars (model, color, price) values ('Sentra', 'Maroon', '$37349.59');
insert into cars (model, color, price) values ('Wrangler', 'Green', '$44996.31');
insert into cars (model, color, price) values ('TSX', 'Aquamarine', '$176282.13');
insert into cars (model, color, price) values ('Cooper', 'Aquamarine', '$33716.60');
insert into cars (model, color, price) values ('Tacoma', 'Yellow', '$160367.75');
insert into cars (model, color, price) values ('Forester', 'Maroon', '$149370.90');
insert into cars (model, color, price) values ('Laser', 'Yellow', '$59383.69');
insert into cars (model, color, price) values ('XC70', 'Mauv', '$100973.99');
insert into cars (model, color, price) values ('Dakota Club', 'Violet', '$68775.23');
insert into cars (model, color, price) values ('Defender 90', 'Khaki', '$110092.95');
insert into cars (model, color, price) values ('D250 Club', 'Fuscia', '$34671.35');
insert into cars (model, color, price) values ('QX', 'Yellow', '$141322.43');
insert into cars (model, color, price) values ('CR-V', 'Purple', '$84768.70');
insert into cars (model, color, price) values ('G-Class', 'Teal', '$32921.88');
insert into cars (model, color, price) values ('MX-3', 'Red', '$175072.73');
insert into cars (model, color, price) values ('Custom Cruiser', 'Green', '$162621.04');
insert into cars (model, color, price) values ('FJ Cruiser', 'Aquamarine', '$145051.50');
insert into cars (model, color, price) values ('Caravan', 'Orange', '$103265.47');
insert into cars (model, color, price) values ('S-Series', 'Purple', '$183806.46');
insert into cars (model, color, price) values ('Freelander', 'Goldenrod', '$140046.38');
insert into cars (model, color, price) values ('Space', 'Puce', '$101969.53');
insert into cars (model, color, price) values ('Pathfinder', 'Yellow', '$78650.75');
insert into cars (model, color, price) values ('Ram Wagon B250', 'Pink', '$106374.70');
insert into cars (model, color, price) values ('Phantom', 'Maroon', '$77910.70');
insert into cars (model, color, price) values ('GTI', 'Violet', '$24323.44');
insert into cars (model, color, price) values ('XJ Series', 'Blue', '$51898.81');
insert into cars (model, color, price) values ('Thunderbird', 'Aquamarine', '$149662.80');
insert into cars (model, color, price) values ('Grand Am', 'Crimson', '$45741.96');
insert into cars (model, color, price) values ('V8', 'Indigo', '$51344.32');
insert into cars (model, color, price) values ('Miata MX-5', 'Green', '$92343.26');
insert into cars (model, color, price) values ('Q', 'Aquamarine', '$191826.46');
insert into cars (model, color, price) values ('Concorde', 'Red', '$38137.28');
insert into cars (model, color, price) values ('Scoupe', 'Maroon', '$86626.04');
insert into cars (model, color, price) values ('Cayenne', 'Teal', '$187724.13');
insert into cars (model, color, price) values ('Savana 2500', 'Teal', '$176668.11');
insert into cars (model, color, price) values ('Thunderbird', 'Green', '$119147.56');
insert into cars (model, color, price) values ('Pathfinder', 'Pink', '$50986.47');
insert into cars (model, color, price) values ('Prelude', 'Teal', '$151578.18');
insert into cars (model, color, price) values ('Ram 2500', 'Goldenrod', '$24977.80');
insert into cars (model, color, price) values ('Impreza', 'Orange', '$171017.36');
insert into cars (model, color, price) values ('Econoline E350', 'Crimson', '$160441.22');
insert into cars (model, color, price) values ('Sable', 'Pink', '$30415.15');
insert into cars (model, color, price) values ('Entourage', 'Blue', '$176534.91');
insert into cars (model, color, price) values ('XL7', 'Mauv', '$23184.45');
insert into cars (model, color, price) values ('Regal', 'Violet', '$143399.27');
insert into cars (model, color, price) values ('Corvette', 'Crimson', '$35600.89');
insert into cars (model, color, price) values ('9-5', 'Pink', '$25964.64');
insert into cars (model, color, price) values ('Camry', 'Fuscia', '$113127.56');
insert into cars (model, color, price) values ('B2000', 'Goldenrod', '$42217.17');
insert into cars (model, color, price) values ('Land Cruiser', 'Mauv', '$100358.99');
insert into cars (model, color, price) values ('Alcyone SVX', 'Yellow', '$196026.43');
insert into cars (model, color, price) values ('H3', 'Blue', '$93108.15');
insert into cars (model, color, price) values ('Ranger', 'Violet', '$179579.85');
insert into cars (model, color, price) values ('9000', 'Aquamarine', '$98255.36');
insert into cars (model, color, price) values ('LeMans', 'Mauv', '$70585.39');
insert into cars (model, color, price) values ('RX Hybrid', 'Turquoise', '$137342.42');
insert into cars (model, color, price) values ('Econoline E150', 'Indigo', '$120460.50');
insert into cars (model, color, price) values ('Mustang', 'Orange', '$66177.57');
insert into cars (model, color, price) values ('Santa Fe', 'Indigo', '$132533.05');
insert into cars (model, color, price) values ('XT', 'Violet', '$171545.42');
insert into cars (model, color, price) values ('Continental', 'Indigo', '$32265.08');
insert into cars (model, color, price) values ('7 Series', 'Green', '$106317.06');
insert into cars (model, color, price) values ('911', 'Goldenrod', '$97066.85');
insert into cars (model, color, price) values ('940', 'Maroon', '$73635.05');
insert into cars (model, color, price) values ('Town & Country', 'Khaki', '$144727.46');
insert into cars (model, color, price) values ('Corvette', 'Fuscia', '$94424.60');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO preferences
SELECT a.buyerid, b.model, b.color
FROM buyers a, cars b
order by random()
limit 1000;