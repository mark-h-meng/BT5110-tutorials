/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*

CASE DESCRIPTION:

Buyers and Sellers of properties want to be well-versed with agents and agencies avialble
in the market for providing assistance in real estate/property transactions. 
My company, Housing Estate Pvt Ltd, identifies this demand as Data as a Service(DaaS) opportunity. 
We provide UK Real Estate Residential Transactions data as a service. 
For all 4 states of UK, we record information about real estate individual agents, 
real estate agencies and property transactions they have performed, in collaboration, 
over the past 25 years. 

As per UK law, individual real estate agents/brokers do not require a license for 
facilitating real estate transactions. Mostly, individual agents/brokers collaborate with 
real estate agencies for acquiring clients and facilitating property transactions. 
The commission is split between the agents and the agencies on a successful transaction.

For each agent, the database records the name, email, phone number(UK based +44), 
state in which the agent resides(among the 4 states of UK namely - 
England, Wales, Northern Ireland, Scotland). 
Each agent is identified by their email in the system. 
The specialization of the agent in either Commercial or Residential sector is also recorded.
(Mockaroo link to Schema: https://mockaroo.com/7dc18f80)

For each agency, the database records the agency name, company registration number, 
email, phone number(UK based +44), street address, state and website. 
Each agency is identified by their registration_number(unique ID obtained from the 
Companies House UK: https://www.gov.uk/limited-company-formation/register-your-company).
(Mockaroo link to Schema: https://mockaroo.com/7720f300)

For each residential transaction, the database records transaction unique identifier(
generated using MD5 Hash Function), date of transfer (ranging over the last 25 years 
from current date_time) and maps the collaboration between agent and 
agencies involved in the transaction.


REFERENCES:
1. UK Firms/Agencies Database: https://www.rdmarketing.co.uk/post/2018/07/25/uk-estate-agents-database
2. UK Residential Transaction Database:  https://www.gov.uk/guidance/about-the-price-paid-data#explanations-of-column-headers-in-the-ppd

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


CREATE TABLE IF NOT EXISTS agents(
 name VARCHAR(64) NOT NULL,
 email VARCHAR(64) PRIMARY KEY,
 phone VARCHAR(50) UNIQUE NOT NULL,
 specialization VARCHAR(20) NOT NULL CONSTRAINT specialization CHECK(specialization = 'Residential' OR specialization = 'Commercial'),
 state VARCHAR(64) NOT NULL
);
	
CREATE TABLE IF NOT EXISTS agencies(
 agency_name VARCHAR(50) NOT NULL,
 registration_number VARCHAR(50) PRIMARY KEY,
 email VARCHAR(50) UNIQUE NOT NULL,
 phone VARCHAR(50) NOT NULL,
 address VARCHAR(50) NOT NULL,
 state VARCHAR(50) NOT NULL,
 website VARCHAR(50) NOT NULL
);
  
CREATE TABLE IF NOT EXISTS transactions(
 transaction_UID VARCHAR(64) PRIMARY KEY,
 date_of_transfer DATE NOT NULL,
 agent_email VARCHAR(64) REFERENCES agents(email) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
 agency_registration_number VARCHAR(50) NOT NULL,
 FOREIGN KEY (agency_registration_number) REFERENCES agencies(registration_number) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED
);


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/************************************************************************/
/*                                                                      */
/* Agents Table Insert statements generated from mockaroo.com           */
/* https://mockaroo.com/7dc18f80                                        */
/*                                                                      */
/************************************************************************/

INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Jorey Giraudeau', '+44 5560 049500', 'jgiraudeau0@bing.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Web Olivella', '+44 5031 896708', 'wolivella1@unblog.fr', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Thomasa Vink', '+44 2626 365553', 'tvink2@elegantthemes.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Kendricks Farress', '+44 6254 469170', 'kfarress3@joomla.org', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Tammie Sausman', '+44 4517 177185', 'tsausman4@alexa.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Terence Simak', '+44 3996 491546', 'tsimak5@vistaprint.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Boothe Vedekhov', '+44 9838 951170', 'bvedekhov6@csmonitor.com', 'Residential', 'Scotland');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Bron MacColgan', '+44 3949 383197', 'bmaccolgan7@domainmarket.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Ferne Dondon', '+44 5442 220757', 'fdondon8@bigcartel.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Cathi Hagyard', '+44 0629 888359', 'chagyard9@ehow.com', 'Residential', 'Scotland');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Constancy O''Hare', '+44 0601 603802', 'coharea@cocolog-nifty.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Maddi Furst', '+44 9630 421956', 'mfurstb@deviantart.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Coral Coghill', '+44 6827 212509', 'ccoghillc@webnode.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Swen Sloss', '+44 3432 083013', 'sslossd@chronoengine.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Chelsy Antonignetti', '+44 2152 645905', 'cantonignettie@soundcloud.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Fee Giffaut', '+44 9990 454280', 'fgiffautf@bing.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Marleen Futter', '+44 7488 892080', 'mfutterg@linkedin.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Jacquetta Frotton', '+44 8795 652701', 'jfrottonh@reverbnation.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Alfreda Mandres', '+44 3670 818533', 'amandresi@eventbrite.com', 'Residential', 'Wales');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Brianna Handslip', '+44 0364 482995', 'bhandslipj@jalbum.net', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Raven Barabich', '+44 6693 853388', 'rbarabichk@zimbio.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('De witt Schulze', '+44 9359 396923', 'dwittl@domainmarket.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Klemens Purdy', '+44 6054 520822', 'kpurdym@blinklist.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Bevvy Warbey', '+44 7619 666628', 'bwarbeyn@huffingtonpost.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Rollin Icke', '+44 0426 126843', 'rickeo@seesaa.net', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Monica Ruggiero', '+44 1032 396209', 'mruggierop@thetimes.co.uk', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Ingrid Dearlove', '+44 8115 154314', 'idearloveq@bizjournals.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Vivie Burnage', '+44 8979 060838', 'vburnager@oracle.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Eustace Pettendrich', '+44 1220 525497', 'epettendrichs@ow.ly', 'Residential', 'Scotland');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Adair Cheer', '+44 3069 295892', 'acheert@narod.ru', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Bartlet Crassweller', '+44 5988 952448', 'bcrasswelleru@adobe.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Piggy Coltart', '+44 4259 288967', 'pcoltartv@geocities.jp', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Clifford Aymerich', '+44 9320 890477', 'caymerichw@abc.net.au', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Tremaine McGlynn', '+44 1757 900063', 'tmcglynnx@wired.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Ignacio Knowles', '+44 5147 077806', 'iknowlesy@vkontakte.ru', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Wells Enston', '+44 9333 614383', 'wenstonz@webmd.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Yvonne Dufaire', '+44 7913 854834', 'ydufaire10@washingtonpost.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Kip Clue', '+44 2816 798912', 'kclue11@mit.edu', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Romonda Hourihane', '+44 2620 201810', 'rhourihane12@techcrunch.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Nanette Cody', '+44 6658 094085', 'ncody13@telegraph.co.uk', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Wilma Daffey', '+44 5275 809411', 'wdaffey14@nhs.uk', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Doll Briar', '+44 7007 449317', 'dbriar15@google.com.au', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Mohandas Trase', '+44 7929 918502', 'mtrase16@accuweather.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Bryce Proschek', '+44 9809 969848', 'bproschek17@deliciousdays.com', 'Commercial', 'Scotland');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Kori Dungee', '+44 2927 848812', 'kdungee18@plala.or.jp', 'Commercial', 'Northern Ireland');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Alanson Mitchenson', '+44 5136 471400', 'amitchenson19@kickstarter.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Lotte Bantock', '+44 4011 902310', 'lbantock1a@woothemes.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Leslie Charlson', '+44 5421 822375', 'lcharlson1b@baidu.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Alyss Yanyshev', '+44 2840 159132', 'ayanyshev1c@jigsy.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Leigh Brack', '+44 1869 985473', 'lbrack1d@tinypic.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Alameda Iddons', '+44 1070 813957', 'aiddons1e@nature.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Deeann Ridewood', '+44 6355 241471', 'dridewood1f@instagram.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Brittan Ritter', '+44 2290 531117', 'britter1g@addthis.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Emmy Girdwood', '+44 3505 353262', 'egirdwood1h@webnode.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Nariko Gadsdon', '+44 4219 959035', 'ngadsdon1i@admin.ch', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Carolina Woofendell', '+44 4545 763627', 'cwoofendell1j@de.vu', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Mathias Ouldcott', '+44 6225 599739', 'mouldcott1k@twitpic.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Otis Capp', '+44 9150 463979', 'ocapp1l@time.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Selma Theaker', '+44 1403 014814', 'stheaker1m@marriott.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Damaris Surgood', '+44 1747 704772', 'dsurgood1n@timesonline.co.uk', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Christye Wildblood', '+44 6208 733115', 'cwildblood1o@theatlantic.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Issiah Sunshine', '+44 9280 720297', 'isunshine1p@weebly.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Mariel Carloni', '+44 7380 885834', 'mcarloni1q@imdb.com', 'Commercial', 'Scotland');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Tabbi Vasyukhin', '+44 6989 131858', 'tvasyukhin1r@skype.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Ryun Ousley', '+44 0570 500970', 'rousley1s@jigsy.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Corri Cowey', '+44 6934 483328', 'ccowey1t@guardian.co.uk', 'Commercial', 'Scotland');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Ahmed Sigge', '+44 5638 122533', 'asigge1u@dailymail.co.uk', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Cori Bercevelo', '+44 6513 357206', 'cbercevelo1v@yolasite.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Giulio Brecknock', '+44 3853 127983', 'gbrecknock1w@nsw.gov.au', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Effie Tullett', '+44 7412 839213', 'etullett1x@photobucket.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Maren Eric', '+44 3421 881158', 'meric1y@abc.net.au', 'Commercial', 'Scotland');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Gale Garrelts', '+44 0374 350973', 'ggarrelts1z@admin.ch', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Markos Wellesley', '+44 5714 782755', 'mwellesley20@skyrock.com', 'Commercial', 'Scotland');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Bertine Reah', '+44 1079 116270', 'breah21@narod.ru', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Glynn Comley', '+44 1202 678201', 'gcomley22@ovh.net', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Swen Aiers', '+44 6014 921868', 'saiers23@edublogs.org', 'Commercial', 'Scotland');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Teresita Glasman', '+44 2758 207956', 'tglasman24@dailymail.co.uk', 'Residential', 'Scotland');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Starlene Dalton', '+44 4432 139891', 'sdalton25@fotki.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Lucita Callf', '+44 6201 803020', 'lcallf26@nba.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Ursuline Zylberdik', '+44 2913 784080', 'uzylberdik27@slate.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Margeaux Attree', '+44 8923 365747', 'mattree28@house.gov', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Ambrosio Slocombe', '+44 1522 882026', 'aslocombe29@princeton.edu', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Abeu Tingey', '+44 0725 473161', 'atingey2a@desdev.cn', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Robinia Daal', '+44 5556 293703', 'rdaal2b@angelfire.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Brian Pakes', '+44 8981 303475', 'bpakes2c@washington.edu', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Mitch Kleine', '+44 5950 926785', 'mkleine2d@weather.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Layne Cadney', '+44 1691 418231', 'lcadney2e@w3.org', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Bernarr Stoeckle', '+44 9795 467681', 'bstoeckle2f@cnn.com', 'Commercial', 'Northern Ireland');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Grantley Hatterslay', '+44 8001 522654', 'ghatterslay2g@qq.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Boote Clohisey', '+44 3243 082966', 'bclohisey2h@icio.us', 'Commercial', 'Scotland');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Paulie Clelland', '+44 3495 787686', 'pclelland2i@archive.org', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Gina Freddi', '+44 4336 004532', 'gfreddi2j@omniture.com', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Herbert Enticott', '+44 6542 684179', 'henticott2k@comcast.net', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Janene Kelland', '+44 7228 987654', 'jkelland2l@typepad.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Aurelea Jannequin', '+44 9674 691294', 'ajannequin2m@google.com.au', 'Residential', 'Scotland');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Kelci Ferier', '+44 2566 822655', 'kferier2n@dagondesign.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Kermit Dranfield', '+44 6976 338138', 'kdranfield2o@vimeo.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Suellen Chishull', '+44 5918 167197', 'schishull2p@washington.edu', 'Commercial', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Avis Mellmer', '+44 8849 095222', 'amellmer2q@webs.com', 'Residential', 'England');
INSERT INTO agents (name, phone, email, specialization, state) VALUES ('Lenard Rosenbarg', '+44 1519 624922', 'lrosenbarg2r@newyorker.com', 'Residential', 'England');
/************************************************************************/
/*                                                                      */
/* Agencies Table Insert statements generated from mockaroo.com         */
/* https://mockaroo.com/7720f300                                        */
/*                                                                      */
/************************************************************************/

INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Kozey LLC', '81-953-8842', 'aarlott0@mit.edu', '+44 3565 930890', '66892 Lindbergh Place', 'Scotland', 'google.ru');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Wunsch, Haley and Lubowitz', '84-710-7244', 'jgundrey1@wisc.edu', '+44 4856 330541', '72621 Gina Plaza', 'England', 'wikipedia.org');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Leffler, Hamill and Runolfsdottir', '96-886-2827', 'cbarrs2@hubpages.com', '+44 3228 907677', '6 Nancy Plaza', 'Scotland', 'shop-pro.jp');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Zboncak LLC', '50-504-2728', 'mitskovitz3@acquirethisname.com', '+44 9683 248519', '2214 Burrows Lane', 'England', 'salon.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Zboncak and Sons', '04-026-3798', 'ncufley4@wisc.edu', '+44 4887 410826', '704 Merry Place', 'England', '123-reg.co.uk');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Hilpert, Bergstrom and Brakus', '77-268-3324', 'pdavydychev5@google.co.uk', '+44 0763 438465', '77 Delladonna Circle', 'Scotland', 'instagram.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Grady-Kassulke', '80-303-8177', 'oblackney6@bing.com', '+44 4945 935649', '8 Farragut Center', 'England', 'miitbeian.gov.cn');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Nienow, Thiel and Keebler', '42-240-0120', 'bvenmore7@topsy.com', '+44 2078 520224', '6154 Texas Center', 'Scotland', 'telegraph.co.uk');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('McGlynn Group', '94-612-3100', 'aveltman8@webnode.com', '+44 9611 128198', '452 Thompson Avenue', 'Scotland', 'vk.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Ledner and Sons', '60-060-6102', 'apoundford9@bing.com', '+44 0459 735556', '98 Shelley Circle', 'England', 'zdnet.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Bruen, McKenzie and Nolan', '99-838-6465', 'ahudsona@stanford.edu', '+44 5550 328231', '939 New Castle Street', 'England', 'printfriendly.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Lynch, Fay and Towne', '51-515-5184', 'kjeduchb@blog.com', '+44 3363 498574', '3816 Westport Center', 'Northern Ireland', 'ask.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Mitchell-Kihn', '49-953-7981', 'hbunnc@google.co.jp', '+44 2754 651762', '90 New Castle Street', 'England', 'ifeng.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Kutch Inc', '96-906-4827', 'vduerdind@nps.gov', '+44 5787 986892', '207 Oak Valley Way', 'Wales', '1688.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Frami-Mayer', '33-454-0049', 'fsmewine@ca.gov', '+44 9928 279106', '378 Namekagon Place', 'England', 'paginegialle.it');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Hintz LLC', '54-178-0434', 'olooneyf@sina.com.cn', '+44 7353 119928', '314 Fairfield Terrace', 'England', 'arizona.edu');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Jerde LLC', '09-468-4595', 'chartzenbergg@sina.com.cn', '+44 0067 902108', '509 Kensington Pass', 'England', 'cbc.ca');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Robel LLC', '20-267-9331', 'wjeaycockh@google.ca', '+44 1706 094507', '714 Express Plaza', 'Scotland', 'ox.ac.uk');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Schmidt, Kub and Weissnat', '12-780-0273', 'hwimmeri@mysql.com', '+44 3296 509496', '6909 Twin Pines Park', 'England', 'reverbnation.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Roob, Bailey and Hettinger', '61-899-3195', 'caphalej@sitemeter.com', '+44 4950 060571', '27280 Schlimgen Way', 'England', 'digg.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Gerhold, Wolff and Kunde', '06-005-9154', 'lmottk@umich.edu', '+44 8996 749074', '9 Walton Place', 'Scotland', 'soup.io');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Olson Inc', '58-466-9327', 'aphythianl@google.de', '+44 8385 853554', '2 Memorial Trail', 'Scotland', 'aol.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Denesik Inc', '21-844-7098', 'tloosleym@hao123.com', '+44 7828 271952', '60 Express Center', 'England', 'si.edu');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Stamm-Wiza', '14-934-0049', 'smarslandn@ca.gov', '+44 1294 312659', '604 Shoshone Center', 'England', 'drupal.org');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Lueilwitz-Bailey', '97-066-4495', 'cforesighto@google.fr', '+44 8946 754359', '83065 Jenna Court', 'England', 'nytimes.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Beer-Nicolas', '71-137-8412', 'lstarbuckp@sphinn.com', '+44 3237 184894', '4 Merchant Park', 'Scotland', 'accuweather.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Jast and Sons', '87-568-5987', 'bizattq@nih.gov', '+44 9400 221558', '4960 Badeau Center', 'England', 'istockphoto.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Romaguera-Russel', '33-778-1634', 'dbarthodr@state.tx.us', '+44 0999 166100', '199 Dahle Crossing', 'England', 'lycos.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Abbott, Harvey and McGlynn', '79-010-1480', 'mhullys@dagondesign.com', '+44 3065 400351', '9775 Sycamore Pass', 'England', 'wix.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Reichert, Halvorson and Smith', '45-263-7294', 'wcovottit@123-reg.co.uk', '+44 4116 446370', '201 6th Park', 'England', 'wp.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Volkman-Hickle', '88-490-2769', 'sfeareu@networksolutions.com', '+44 8409 600708', '83 Hollow Ridge Road', 'England', 'constantcontact.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Breitenberg, Langworth and Kertzmann', '09-786-3717', 'avuittev@cocolog-nifty.com', '+44 2720 190355', '50128 Shelley Terrace', 'England', 'goo.gl');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Daugherty, Leannon and Lemke', '12-730-6426', 'mpenningtonw@cafepress.com', '+44 1389 917520', '3 Atwood Avenue', 'Scotland', 'privacy.gov.au');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Schultz-Rogahn', '64-732-1418', 'kclaydenx@wsj.com', '+44 5376 190544', '7 Vera Alley', 'England', 'reference.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Bradtke Inc', '11-291-3451', 'pcleverlyy@hc360.com', '+44 4594 090283', '2800 Shoshone Circle', 'England', 'ox.ac.uk');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Kris LLC', '48-299-0708', 'hbearhamz@google.de', '+44 7125 251475', '4594 Westend Center', 'Northern Ireland', 'trellian.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('McCullough, Beatty and Effertz', '56-544-0647', 'lmingaye10@i2i.jp', '+44 6976 359064', '5103 Golf Course Park', 'Scotland', 'naver.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Sanford Group', '48-270-4312', 'sansett11@chronoengine.com', '+44 7498 415480', '68 Erie Circle', 'England', 'spiegel.de');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('McLaughlin-Rau', '62-442-3424', 'dsisselot12@chicagotribune.com', '+44 2740 090131', '034 Raven Alley', 'England', 'printfriendly.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Rath, Wilderman and Greenholt', '43-252-7149', 'tpollicott13@hibu.com', '+44 7615 896496', '4767 Graedel Drive', 'Wales', 'utexas.edu');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Rau and Sons', '94-163-5086', 'syarrall14@bravesites.com', '+44 3156 252679', '3 Hoffman Point', 'England', 'si.edu');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Walter, Mertz and Rohan', '18-638-3569', 'eyare15@angelfire.com', '+44 7804 415415', '0478 Northridge Center', 'England', 'so-net.ne.jp');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Stiedemann, DuBuque and Kihn', '38-223-9067', 'lhanalan16@archive.org', '+44 4008 599748', '24 Gina Crossing', 'England', 'bbc.co.uk');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('O''Conner Group', '85-905-4020', 'tnewis17@vinaora.com', '+44 4616 586974', '71668 Charing Cross Avenue', 'England', 'youtu.be');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Cummings-Heaney', '45-800-2573', 'hfilipczynski18@arstechnica.com', '+44 7800 203179', '25 Hauk Road', 'England', 'photobucket.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Altenwerth-Morissette', '46-076-7652', 'avamplew19@nydailynews.com', '+44 8874 617439', '35 Green Avenue', 'England', 'businessinsider.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Corwin-Hickle', '80-558-2144', 'pbyres1a@epa.gov', '+44 1466 557894', '0 Laurel Alley', 'England', 'yahoo.co.jp');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Koch LLC', '34-516-3323', 'cwick1b@forbes.com', '+44 8355 235005', '42652 Moulton Crossing', 'England', 'forbes.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Padberg Inc', '51-369-2217', 'cgarroch1c@redcross.org', '+44 8110 866608', '7138 Pennsylvania Point', 'England', 'bluehost.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Krajcik, Bogisich and Stark', '46-336-6699', 'jwilprecht1d@loc.gov', '+44 4970 918373', '54 Mendota Lane', 'England', 'acquirethisname.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Renner, Braun and Luettgen', '19-158-9115', 'ereddings1e@cisco.com', '+44 1153 344597', '7 Lyons Park', 'England', 'unesco.org');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Wunsch-Wyman', '38-377-2155', 'jkienle1f@amazon.co.jp', '+44 1204 250562', '1 Kenwood Center', 'Scotland', 'vk.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Bednar and Sons', '65-159-5985', 'ccastelin1g@spotify.com', '+44 3390 877183', '579 Orin Point', 'England', 'mtv.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Price, Ritchie and Murazik', '62-367-8170', 'bmcairt1h@vinaora.com', '+44 1196 735674', '8059 Manufacturers Parkway', 'England', 'alexa.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Bahringer-Moen', '46-601-8347', 'npeterkin1i@irs.gov', '+44 5377 200451', '95 Bluestem Crossing', 'England', 'cyberchimps.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Wuckert LLC', '90-989-6917', 'ghusselbee1j@hostgator.com', '+44 7670 655837', '751 Jenifer Court', 'Scotland', 'auda.org.au');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Volkman, Homenick and Lowe', '30-872-9469', 'vrochester1k@surveymonkey.com', '+44 1052 230284', '2811 Longview Alley', 'England', 'msu.edu');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Buckridge-Bayer', '40-405-8494', 'jtowson1l@zimbio.com', '+44 1341 592545', '22 Sherman Trail', 'England', 'wsj.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('McCullough, Murray and Rath', '04-771-3907', 'lboyan1m@ucla.edu', '+44 8864 345154', '91192 Lawn Point', 'England', 'sakura.ne.jp');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Feil, Funk and Conn', '99-730-1063', 'rlawtey1n@mac.com', '+44 2429 867775', '5755 Buell Park', 'England', 'chron.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Cummerata-Braun', '46-442-4722', 'wberzin1o@ftc.gov', '+44 8287 125071', '8445 Hermina Alley', 'Scotland', 'storify.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Rolfson-Maggio', '54-794-6022', 'jdavaux1p@clickbank.net', '+44 6784 470034', '7 Dawn Junction', 'England', 'infoseek.co.jp');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Torphy, Breitenberg and Roberts', '82-691-2645', 'amitchel1q@mail.ru', '+44 5387 999952', '8853 Fallview Court', 'Scotland', 'aboutads.info');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Brown-Rau', '71-487-2330', 'ghardacre1r@go.com', '+44 8029 184870', '1 Oak Valley Parkway', 'England', 'si.edu');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Streich Inc', '50-917-9220', 'gogdahl1s@google.co.jp', '+44 1431 745480', '39631 Moland Center', 'England', 'wikipedia.org');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Nicolas Group', '87-728-6533', 'awardle1t@tuttocitta.it', '+44 0991 440445', '2 Dayton Court', 'England', 'slideshare.net');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Haley Inc', '97-124-0391', 'cfilipic1u@flavors.me', '+44 2505 617040', '3 Hoepker Terrace', 'England', 'skype.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Fritsch, Brown and Smith', '85-381-1653', 'gmorison1v@state.gov', '+44 3581 582998', '57 Ilene Lane', 'England', 'networksolutions.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Oberbrunner, Marks and Goodwin', '01-753-5746', 'fheasman1w@yellowpages.com', '+44 1578 718227', '912 Evergreen Parkway', 'England', 'china.com.cn');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Johnston, Jerde and Murray', '21-258-8592', 'fpobjoy1x@google.it', '+44 0491 749812', '487 Bultman Center', 'Scotland', 'nasa.gov');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Nicolas-Jacobs', '76-039-5723', 'fbraznell1y@globo.com', '+44 0257 484290', '6416 Mallard Street', 'Northern Ireland', 'latimes.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Howe, Kshlerin and Barton', '03-975-4865', 'bsandercroft1z@ucla.edu', '+44 2145 322377', '84644 Sommers Parkway', 'England', 'rambler.ru');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Hane Inc', '19-064-5944', 'elingfoot20@ovh.net', '+44 1241 493603', '2468 Southridge Place', 'England', 'tumblr.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Fahey and Sons', '94-891-4650', 'tfraanchyonok21@prlog.org', '+44 0702 312549', '2869 Ohio Alley', 'Scotland', 'yale.edu');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Nader, Rohan and Windler', '25-601-1947', 'fagnew22@usgs.gov', '+44 1919 616154', '8 Reindahl Pass', 'England', 'photobucket.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Funk, Vandervort and Harris', '71-491-3146', 'achevalier23@1688.com', '+44 0493 655041', '199 Buell Junction', 'England', 'behance.net');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Lynch-Bauch', '92-771-4428', 'hhearn24@privacy.gov.au', '+44 6779 216487', '2 Loomis Drive', 'Scotland', 'webnode.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Gislason, Grant and Kemmer', '73-528-1495', 'amunson25@sciencedaily.com', '+44 4162 975603', '795 Memorial Center', 'England', 'sitemeter.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Marquardt and Sons', '39-272-6775', 'ldoleman26@g.co', '+44 2571 866514', '9937 Dapin Hill', 'Scotland', 'photobucket.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Harber, Dicki and Bailey', '79-252-0714', 'ekagan27@cnbc.com', '+44 3517 080477', '44 Dayton Terrace', 'England', 'yolasite.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Leffler-Feil', '98-881-3034', 'adupre28@cnn.com', '+44 0173 465155', '49679 Nevada Circle', 'England', 'europa.eu');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Fisher, McLaughlin and White', '16-713-9200', 'llennarde29@msn.com', '+44 9116 438137', '0259 Granby Junction', 'England', 'cbslocal.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Ernser-Murazik', '39-499-6812', 'lbryden2a@webnode.com', '+44 3466 580216', '8991 Lotheville Point', 'England', 'hugedomains.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('McClure LLC', '83-952-1895', 'dsanbrook2b@surveymonkey.com', '+44 4014 982595', '36 Morning Trail', 'England', 'house.gov');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('McKenzie, Predovic and Ward', '73-052-6122', 'lstable2c@china.com.cn', '+44 1234 539529', '06 Manufacturers Pass', 'Scotland', 'usnews.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Herzog Inc', '66-057-3522', 'kfunnell2d@netvibes.com', '+44 3153 640137', '95 Crescent Oaks Pass', 'England', 'mapquest.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Hahn LLC', '03-291-7983', 'ekarolowski2e@plala.or.jp', '+44 1910 655184', '5446 Charing Cross Pass', 'England', 'usnews.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Kiehn Inc', '04-238-9962', 'dclaw2f@wiley.com', '+44 0585 343668', '520 Hoard Point', 'England', 't.co');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Marvin Inc', '76-733-5162', 'lborthe2g@desdev.cn', '+44 4040 843481', '63 Oneill Street', 'England', 'jalbum.net');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Wilderman, Hauck and Dach', '74-898-2320', 'lrissen2h@feedburner.com', '+44 8755 921166', '62024 Kropf Plaza', 'England', 'opensource.org');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Ebert Group', '31-341-1851', 'jgarthside2i@oracle.com', '+44 5856 072669', '21930 Ramsey Parkway', 'England', 'google.pl');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Ferry-Luettgen', '67-256-9025', 'plendon2j@cocolog-nifty.com', '+44 3853 103874', '187 Knutson Plaza', 'England', 'tinypic.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Hintz-Schamberger', '48-006-6738', 'kcrosseland2k@columbia.edu', '+44 9659 553854', '2 Moulton Street', 'England', 'ifeng.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Keeling Inc', '85-592-5564', 'aerley2l@chronoengine.com', '+44 4977 300902', '9759 Nelson Street', 'Scotland', 'toplist.cz');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Kuhlman-Dare', '44-907-7499', 'smollene2m@mozilla.org', '+44 6808 821062', '697 Dryden Avenue', 'England', 't-online.de');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Schultz-Cummerata', '77-309-9259', 'mformie2n@shareasale.com', '+44 6001 452537', '15874 Dahle Court', 'England', 'msu.edu');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Ebert-Nikolaus', '76-168-6376', 'bstelli2o@answers.com', '+44 2207 884967', '5203 Menomonie Street', 'England', 'tinyurl.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Crona-Reilly', '01-190-9924', 'bmeriel2p@virginia.edu', '+44 8515 116990', '184 Buena Vista Lane', 'England', 'pinterest.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Muller-Goldner', '95-539-5409', 'eonge2q@elpais.com', '+44 2017 923629', '768 Carey Court', 'England', 'sciencedaily.com');
INSERT INTO agencies (agency_name, registration_number, email, phone, address, state, website) VALUES ('Lemke-Blick', '13-230-8054', 'dtilby2r@webeden.co.uk', '+44 4342 404228', '81 Comanche Hill', 'England', 'bloomberg.com');


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


INSERT INTO TRANSACTIONS (
    transaction_uid, date_of_transfer, 
    agent_email, agency_registration_number)
SELECT MD5( random()::text ) AS transaction_uid,
       NOW() - (random() * (interval '25 years')) AS date_of_transfer,
       agents.email AS agent_email,
       agencies.registration_number AS agency_registration_number
FROM agents,
     agencies
ORDER BY random()
LIMIT 1000;