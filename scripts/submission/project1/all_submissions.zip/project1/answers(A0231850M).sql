/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* I choose the entity set E1 to be person, the entity set	E2 to be movie,
and the relation set R to be watched. E1 has three attributes, full_name,
email, and gender. E2 has five attributes, movie_id, title, director, genre and release_time.
R associating the emails of persons to the id of the movie they have watched.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE person (
	full_name VARCHAR(64),
	email VARCHAR(64) PRIMARY KEY,
	gender VARCHAR(32));
CREATE TABLE movie (
	movie_id VARCHAR(32) PRIMARY KEY,
	title VARCHAR(255) NOT NULL,
	director VARCHAR(64),
	genre VARCHAR(64),
	release_time VARCHAR(32));
CREATE TABLE watched (
	email VARCHAR(64) REFERENCES person (email),
	movie_id VARCHAR(32) REFERENCES movie (movie_id));
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into person (full_name, email, gender) values ('Ida Talbot', 'italbot0@shop-pro.jp', 'Male');
insert into person (full_name, email, gender) values ('Binny Gallyon', 'bgallyon1@google.it', 'Male');
insert into person (full_name, email, gender) values ('Rutger Stapford', 'rstapford2@de.vu', 'Female');
insert into person (full_name, email, gender) values ('Garald McClosh', 'gmcclosh3@friendfeed.com', 'Male');
insert into person (full_name, email, gender) values ('Valentina Ribeiro', 'vribeiro4@ezinearticles.com', 'Male');
insert into person (full_name, email, gender) values ('Everard Pattlel', 'epattlel5@histats.com', 'Female');
insert into person (full_name, email, gender) values ('Ches Stuchburie', 'cstuchburie6@hugedomains.com', 'Female');
insert into person (full_name, email, gender) values ('Morgana Mityushkin', 'mmityushkin7@etsy.com', 'Female');
insert into person (full_name, email, gender) values ('Orelie Peplaw', 'opeplaw8@comcast.net', 'Female');
insert into person (full_name, email, gender) values ('Dexter Benedite', 'dbenedite9@census.gov', 'Female');
insert into person (full_name, email, gender) values ('Bradford Lavrick', 'blavricka@abc.net.au', 'Female');
insert into person (full_name, email, gender) values ('Calla Pedlow', 'cpedlowb@tumblr.com', 'Female');
insert into person (full_name, email, gender) values ('Pauline Allawy', 'pallawyc@altervista.org', 'Female');
insert into person (full_name, email, gender) values ('Silvanus Prangley', 'sprangleyd@xrea.com', 'Female');
insert into person (full_name, email, gender) values ('Evonne Kohrding', 'ekohrdinge@is.gd', 'Male');
insert into person (full_name, email, gender) values ('Andra MacLaren', 'amaclarenf@irs.gov', 'Female');
insert into person (full_name, email, gender) values ('Roxie Jessop', 'rjessopg@ifeng.com', 'Male');
insert into person (full_name, email, gender) values ('Austin Behan', 'abehanh@google.ca', 'Female');
insert into person (full_name, email, gender) values ('Yurik Comini', 'ycominii@mozilla.org', 'Female');
insert into person (full_name, email, gender) values ('Peri Crowson', 'pcrowsonj@europa.eu', 'Female');
insert into person (full_name, email, gender) values ('Gustavo Auten', 'gautenk@marketwatch.com', 'Female');
insert into person (full_name, email, gender) values ('Rosalie Domel', 'rdomell@bloomberg.com', 'Female');
insert into person (full_name, email, gender) values ('Donnamarie Cornwall', 'dcornwallm@ucla.edu', 'Male');
insert into person (full_name, email, gender) values ('Darelle Pitrasso', 'dpitrasson@cnbc.com', 'Male');
insert into person (full_name, email, gender) values ('Wilhelmina Muehler', 'wmuehlero@google.co.jp', 'Female');
insert into person (full_name, email, gender) values ('Winni Woolatt', 'wwoolattp@google.it', 'Female');
insert into person (full_name, email, gender) values ('Trudy Tippin', 'ttippinq@discuz.net', 'Male');
insert into person (full_name, email, gender) values ('Clo Canet', 'ccanetr@mit.edu', 'Male');
insert into person (full_name, email, gender) values ('Dianemarie Lorenz', 'dlorenzs@linkedin.com', 'Female');
insert into person (full_name, email, gender) values ('Carmelia Quenby', 'cquenbyt@ucoz.com', 'Female');
insert into person (full_name, email, gender) values ('William Skeermer', 'wskeermeru@quantcast.com', 'Male');
insert into person (full_name, email, gender) values ('Osbert Ducarne', 'oducarnev@answers.com', 'Male');
insert into person (full_name, email, gender) values ('Lorettalorna Hainey`', 'lhaineyw@simplemachines.org', 'Male');
insert into person (full_name, email, gender) values ('Murdock Yoselevitch', 'myoselevitchx@themeforest.net', 'Female');
insert into person (full_name, email, gender) values ('Yancey Poli', 'ypoliy@netscape.com', 'Male');
insert into person (full_name, email, gender) values ('Lilias Souttar', 'lsouttarz@cisco.com', 'Male');
insert into person (full_name, email, gender) values ('Kalvin Illesley', 'killesley10@ow.ly', 'Male');
insert into person (full_name, email, gender) values ('Lindie Letterick', 'lletterick11@phpbb.com', 'Female');
insert into person (full_name, email, gender) values ('Brew McInteer', 'bmcinteer12@cam.ac.uk', 'Male');
insert into person (full_name, email, gender) values ('Florida Crudge', 'fcrudge13@shutterfly.com', 'Male');
insert into person (full_name, email, gender) values ('Salvidor Leatherbarrow', 'sleatherbarrow14@kickstarter.com', 'Female');
insert into person (full_name, email, gender) values ('Frasquito Mayworth', 'fmayworth15@smugmug.com', 'Male');
insert into person (full_name, email, gender) values ('Benedicta Negus', 'bnegus16@pen.io', 'Male');
insert into person (full_name, email, gender) values ('Collie Meaddowcroft', 'cmeaddowcroft17@sbwire.com', 'Male');
insert into person (full_name, email, gender) values ('Viola Norquay', 'vnorquay18@constantcontact.com', 'Female');
insert into person (full_name, email, gender) values ('Millisent Ewers', 'mewers19@aol.com', 'Male');
insert into person (full_name, email, gender) values ('Marjory Watmough', 'mwatmough1a@ibm.com', 'Male');
insert into person (full_name, email, gender) values ('Moses Silversmidt', 'msilversmidt1b@imdb.com', 'Male');
insert into person (full_name, email, gender) values ('Celestia Wardell', 'cwardell1c@digg.com', 'Female');
insert into person (full_name, email, gender) values ('Nadine Grice', 'ngrice1d@clickbank.net', 'Male');
insert into person (full_name, email, gender) values ('Rockwell Orris', 'rorris1e@php.net', 'Male');
insert into person (full_name, email, gender) values ('Archie Alleway', 'aalleway1f@chronoengine.com', 'Male');
insert into person (full_name, email, gender) values ('Niall Filyushkin', 'nfilyushkin1g@chronoengine.com', 'Female');
insert into person (full_name, email, gender) values ('Henrie Tarren', 'htarren1h@soup.io', 'Female');
insert into person (full_name, email, gender) values ('Tammie Sargent', 'tsargent1i@ning.com', 'Female');
insert into person (full_name, email, gender) values ('Alina Tattam', 'atattam1j@buzzfeed.com', 'Male');
insert into person (full_name, email, gender) values ('Rory Clayden', 'rclayden1k@infoseek.co.jp', 'Female');
insert into person (full_name, email, gender) values ('Tiler Lyste', 'tlyste1l@ifeng.com', 'Male');
insert into person (full_name, email, gender) values ('Roxane Englishby', 'renglishby1m@imdb.com', 'Female');
insert into person (full_name, email, gender) values ('Antin de Keep', 'ade1n@amazon.de', 'Female');
insert into person (full_name, email, gender) values ('Benny Camilletti', 'bcamilletti1o@sbwire.com', 'Female');
insert into person (full_name, email, gender) values ('Almire Bindon', 'abindon1p@weather.com', 'Male');
insert into person (full_name, email, gender) values ('Cheryl Lenaghen', 'clenaghen1q@cnn.com', 'Male');
insert into person (full_name, email, gender) values ('Courtney Aylin', 'caylin1r@altervista.org', 'Female');
insert into person (full_name, email, gender) values ('Nicholle Otridge', 'notridge1s@usatoday.com', 'Male');
insert into person (full_name, email, gender) values ('Ermentrude Madgin', 'emadgin1t@google.fr', 'Male');
insert into person (full_name, email, gender) values ('Gerianna Morsey', 'gmorsey1u@nhs.uk', 'Female');
insert into person (full_name, email, gender) values ('Kienan Tidmarsh', 'ktidmarsh1v@posterous.com', 'Male');
insert into person (full_name, email, gender) values ('Monro Wemm', 'mwemm1w@studiopress.com', 'Female');
insert into person (full_name, email, gender) values ('Jesse Challender', 'jchallender1x@comcast.net', 'Female');
insert into person (full_name, email, gender) values ('Jewell Pendre', 'jpendre1y@reference.com', 'Female');
insert into person (full_name, email, gender) values ('Haven Youle', 'hyoule1z@sakura.ne.jp', 'Female');
insert into person (full_name, email, gender) values ('Rita Haycox', 'rhaycox20@about.me', 'Male');
insert into person (full_name, email, gender) values ('Veda Stockney', 'vstockney21@histats.com', 'Female');
insert into person (full_name, email, gender) values ('Lonee Wolfendale', 'lwolfendale22@parallels.com', 'Female');
insert into person (full_name, email, gender) values ('Brit Kibard', 'bkibard23@naver.com', 'Male');
insert into person (full_name, email, gender) values ('Lorenza Colles', 'lcolles24@hc360.com', 'Male');
insert into person (full_name, email, gender) values ('Xenia Wesley', 'xwesley25@forbes.com', 'Male');
insert into person (full_name, email, gender) values ('Rab Villaret', 'rvillaret26@mac.com', 'Female');
insert into person (full_name, email, gender) values ('Shannah Whimp', 'swhimp27@economist.com', 'Female');
insert into person (full_name, email, gender) values ('Corbett Local', 'clocal28@ed.gov', 'Female');
insert into person (full_name, email, gender) values ('Kimball Red', 'kred29@comcast.net', 'Male');
insert into person (full_name, email, gender) values ('Tammie Chapelhow', 'tchapelhow2a@taobao.com', 'Male');
insert into person (full_name, email, gender) values ('Si Matthieson', 'smatthieson2b@nytimes.com', 'Female');
insert into person (full_name, email, gender) values ('Edouard Doohan', 'edoohan2c@instagram.com', 'Male');
insert into person (full_name, email, gender) values ('Ninetta Heeley', 'nheeley2d@aboutads.info', 'Female');
insert into person (full_name, email, gender) values ('Hildagard Rainsden', 'hrainsden2e@taobao.com', 'Female');
insert into person (full_name, email, gender) values ('Cyndie Spearing', 'cspearing2f@apple.com', 'Male');
insert into person (full_name, email, gender) values ('Bob Morad', 'bmorad2g@pinterest.com', 'Male');
insert into person (full_name, email, gender) values ('Pattie Mulvaney', 'pmulvaney2h@google.de', 'Female');
insert into person (full_name, email, gender) values ('Wendeline Fildes', 'wfildes2i@hud.gov', 'Male');
insert into person (full_name, email, gender) values ('Olin Witnall', 'owitnall2j@economist.com', 'Male');
insert into person (full_name, email, gender) values ('Worth Lghan', 'wlghan2k@psu.edu', 'Male');
insert into person (full_name, email, gender) values ('Victoria Bestwerthick', 'vbestwerthick2l@devhub.com', 'Female');
insert into person (full_name, email, gender) values ('Loella Mollison', 'lmollison2m@rambler.ru', 'Male');
insert into person (full_name, email, gender) values ('Tobin Syfax', 'tsyfax2n@weather.com', 'Male');
insert into person (full_name, email, gender) values ('Agustin Lelliott', 'alelliott2o@shop-pro.jp', 'Male');
insert into person (full_name, email, gender) values ('Joela Pawlik', 'jpawlik2p@wordpress.org', 'Female');
insert into person (full_name, email, gender) values ('Kleon Hiscocks', 'khiscocks2q@unblog.fr', 'Female');
insert into person (full_name, email, gender) values ('Mariel Sillars', 'msillars2r@pagesperso-orange.fr', 'Female');
insert into movie (movie_id, title, director, genre, release_time) values (1, 'Trigun: Badlands Rumble', 'Zola Gobat', 'Action|Animation|Sci-Fi|Western', '3/13/2016');
insert into movie (movie_id, title, director, genre, release_time) values (2, 'Die, Monster, Die!', 'Sher Rattrie', 'Horror|Mystery|Sci-Fi', '2/21/1996');
insert into movie (movie_id, title, director, genre, release_time) values (3, 'Bellissima', 'Olag O''Halleghane', 'Drama', '10/31/1998');
insert into movie (movie_id, title, director, genre, release_time) values (4, 'To Do List, The', 'Aindrea Hinksen', 'Comedy', '7/9/2021');
insert into movie (movie_id, title, director, genre, release_time) values (5, 'Harishchandrachi Factory', 'Shelley Hamel', 'Comedy|Drama', '2/18/1985');
insert into movie (movie_id, title, director, genre, release_time) values (6, 'Death Defying Acts', 'Woodie Jerisch', 'Drama|Romance|Thriller', '7/18/2009');
insert into movie (movie_id, title, director, genre, release_time) values (7, 'First Knight', 'Fan Facchini', 'Action|Drama|Romance', '3/13/2021');
insert into movie (movie_id, title, director, genre, release_time) values (8, 'Taste of Cherry (Ta''m e guilass)', 'Lenee Arnull', 'Drama', '11/30/2009');
insert into movie (movie_id, title, director, genre, release_time) values (9, 'Jack the Giant Slayer', 'Donielle Dewes', 'Adventure|Fantasy|IMAX', '2/3/2001');
insert into movie (movie_id, title, director, genre, release_time) values (10, 'Bucktown', 'Rivalee Peaple', 'Crime|Drama', '7/11/1998');
insert into movie (movie_id, title, director, genre, release_time) values (11, 'King Rat', 'Esme Mesnard', 'Drama|War', '5/3/2021');
insert into movie (movie_id, title, director, genre, release_time) values (12, 'Barfi!', 'Spense Dallman', 'Comedy|Drama|Romance', '4/29/2019');
insert into movie (movie_id, title, director, genre, release_time) values (13, 'Uptown Saturday Night', 'Karlen Mackstead', 'Comedy', '4/9/1987');
insert into movie (movie_id, title, director, genre, release_time) values (14, 'Bears', 'Kermit Pallant', 'Documentary', '3/16/2021');
insert into movie (movie_id, title, director, genre, release_time) values (15, 'Deluge, The (Potop)', 'Caprice McIlwain', 'Adventure|War', '2/1/1982');
insert into movie (movie_id, title, director, genre, release_time) values (16, 'Klitschko', 'Bernelle Drewet', 'Documentary', '2/19/2020');
insert into movie (movie_id, title, director, genre, release_time) values (17, 'Daydreams', 'Yolane Pikesley', 'Comedy', '10/18/1989');
insert into movie (movie_id, title, director, genre, release_time) values (18, 'Alone in the Wilderness', 'Cleve Samwyse', 'Documentary', '5/13/2008');
insert into movie (movie_id, title, director, genre, release_time) values (19, 'Sunset Blvd. (a.k.a. Sunset Boulevard)', 'Thorin Trunchion', 'Drama|Film-Noir|Romance', '7/1/1982');
insert into movie (movie_id, title, director, genre, release_time) values (20, 'Suck', 'Krista Frazer', 'Comedy|Horror|Musical', '11/4/2007');
insert into movie (movie_id, title, director, genre, release_time) values (21, 'Puppet Master: The Legacy (Puppet Master 8)', 'Jeffry Dimbylow', 'Horror', '7/3/1997');
insert into movie (movie_id, title, director, genre, release_time) values (22, 'Return of Frank Cannon, The', 'Stavro Varnam', 'Action|Crime|Drama|Mystery|Thriller', '9/18/2014');
insert into movie (movie_id, title, director, genre, release_time) values (23, 'Age of Consent', 'Travers Dreinan', 'Comedy|Drama|Romance', '5/18/2015');
insert into movie (movie_id, title, director, genre, release_time) values (24, 'Man Who Saw Tomorrow, The', 'Marsiella Petranek', 'Documentary', '6/9/1995');
insert into movie (movie_id, title, director, genre, release_time) values (25, 'Lush Life', 'Rosabelle Aynsley', 'Drama|Musical', '2/8/1997');
insert into movie (movie_id, title, director, genre, release_time) values (26, 'It''s Love I''m After', 'Eartha Vink', 'Comedy', '1/29/1998');
insert into movie (movie_id, title, director, genre, release_time) values (27, 'Diggers', 'Bar Gooden', 'Comedy|Drama', '9/21/1993');
insert into movie (movie_id, title, director, genre, release_time) values (28, 'Smoking/No Smoking', 'Edith Scholz', 'Comedy', '3/1/1995');
insert into movie (movie_id, title, director, genre, release_time) values (29, 'Conversations with Other Women', 'Abbi Hallut', 'Comedy|Drama|Romance', '1/8/2000');
insert into movie (movie_id, title, director, genre, release_time) values (30, 'Un Piede in paradiso', 'Casi Vidyapin', 'Comedy', '7/23/2021');
insert into movie (movie_id, title, director, genre, release_time) values (31, 'Christmas at Pee Wee''s Playhouse (a.k.a. Pee-Wee''s Playhouse Christmas Special)', 'Penny Diggons', 'Children|Comedy|Musical', '8/13/1987');
insert into movie (movie_id, title, director, genre, release_time) values (32, 'Janie Jones', 'Brier Chace', 'Drama|Musical', '1/20/1997');
insert into movie (movie_id, title, director, genre, release_time) values (33, 'Ghidorah, the Three-Headed Monster (San daikaijû: Chikyû saidai no kessen)', 'Elberta McEntagart', 'Action|Adventure|Fantasy|Sci-Fi', '4/3/1994');
insert into movie (movie_id, title, director, genre, release_time) values (34, 'Turn the River', 'Haley Parades', 'Drama', '6/10/2021');
insert into movie (movie_id, title, director, genre, release_time) values (35, 'The Care Bears Adventure in Wonderland', 'Tilda Beament', 'Animation|Children|Comedy', '12/6/2000');
insert into movie (movie_id, title, director, genre, release_time) values (36, 'Liberty Heights', 'Roger Aleixo', 'Drama', '9/12/2001');
insert into movie (movie_id, title, director, genre, release_time) values (37, 'Funhouse, The', 'Noella MacKean', 'Horror', '3/9/2008');
insert into movie (movie_id, title, director, genre, release_time) values (38, 'Irony of Fate, or Enjoy Your Bath! (Ironiya sudby, ili S legkim parom!)', 'Niki Mathivet', 'Comedy|Drama|Romance', '9/21/2008');
insert into movie (movie_id, title, director, genre, release_time) values (39, 'Claim, The', 'Maryann Seacroft', 'Romance|Western', '12/2/2019');
insert into movie (movie_id, title, director, genre, release_time) values (40, 'Swimmer, The', 'Rosana Grayham', 'Drama', '8/28/1994');
insert into movie (movie_id, title, director, genre, release_time) values (41, 'Bride of the Monster', 'Adelle Mattschas', 'Horror|Sci-Fi', '10/3/2008');
insert into movie (movie_id, title, director, genre, release_time) values (42, 'Antoine and Colette (Antoine et Colette)', 'Kesley Wooles', 'Comedy|Drama', '8/17/1990');
insert into movie (movie_id, title, director, genre, release_time) values (43, 'Chuck Norris vs Communism', 'Ellswerth Motte', 'Documentary', '3/17/1996');
insert into movie (movie_id, title, director, genre, release_time) values (44, 'Polar Express, The', 'Judye Trehearn', 'Adventure|Animation|Children|Fantasy|IMAX', '1/10/1996');
insert into movie (movie_id, title, director, genre, release_time) values (45, 'Visit to a Small Planet', 'Pat Seckington', 'Comedy|Sci-Fi', '7/30/1983');
insert into movie (movie_id, title, director, genre, release_time) values (46, 'Mystics in Bali (Leák)', 'Rockwell Rouzet', 'Fantasy|Horror|Thriller', '10/27/1999');
insert into movie (movie_id, title, director, genre, release_time) values (47, 'Map of the World, A', 'Bibby Beakes', 'Drama', '5/2/2018');
insert into movie (movie_id, title, director, genre, release_time) values (48, 'Bad Sleep Well, The (Warui yatsu hodo yoku nemuru)', 'Ky Keatch', 'Drama|Thriller', '11/3/2008');
insert into movie (movie_id, title, director, genre, release_time) values (49, 'Alice Upside Down (Alice)', 'Rosalinda Beckenham', 'Adventure|Children|Comedy|Drama', '9/30/2003');
insert into movie (movie_id, title, director, genre, release_time) values (50, 'Devil Hunter (El caníbal)', 'Celisse Marle', 'Horror', '12/15/1987');
insert into movie (movie_id, title, director, genre, release_time) values (51, 'Student of the Year', 'Arnuad Luebbert', 'Comedy|Romance', '7/1/1987');
insert into movie (movie_id, title, director, genre, release_time) values (52, 'You Were Never Lovelier', 'Kiah Geater', 'Comedy|Musical|Romance', '5/25/1993');
insert into movie (movie_id, title, director, genre, release_time) values (53, 'Beautiful Boxer', 'Novelia Wellfare', 'Action|Drama', '10/14/2018');
insert into movie (movie_id, title, director, genre, release_time) values (54, 'Team America: World Police', 'Diena Weiss', 'Action|Adventure|Animation|Comedy', '5/12/2010');
insert into movie (movie_id, title, director, genre, release_time) values (55, 'Rules of Single Life (Sinkkuelämän säännöt)', 'Melessa Scahill', 'Documentary', '8/9/1987');
insert into movie (movie_id, title, director, genre, release_time) values (56, 'Cyborg 2: Glass Shadow', 'Lyndy Gherardi', 'Action|Sci-Fi|Thriller', '11/22/1998');
insert into movie (movie_id, title, director, genre, release_time) values (57, 'Glass House, The', 'Annmarie Colvin', 'Drama', '10/29/2001');
insert into movie (movie_id, title, director, genre, release_time) values (58, 'Scarecrow', 'Jamil Ransley', 'Drama', '1/21/2000');
insert into movie (movie_id, title, director, genre, release_time) values (59, 'Nothing Like the Holidays', 'Marja Keppel', 'Comedy|Drama|Romance', '8/1/2010');
insert into movie (movie_id, title, director, genre, release_time) values (60, 'Zero Theorem, The', 'Stanwood Sivill', 'Drama|Fantasy|Sci-Fi', '11/1/2007');
insert into movie (movie_id, title, director, genre, release_time) values (61, 'The Skinny', 'Otto Willerstone', 'Comedy|Drama|Romance', '1/14/1990');
insert into movie (movie_id, title, director, genre, release_time) values (62, 'Franklyn', 'Sherie McMahon', 'Drama|Fantasy|Romance|Thriller', '8/14/2010');
insert into movie (movie_id, title, director, genre, release_time) values (63, 'Gypsy Moths, The', 'Arlene Durbyn', 'Drama', '7/22/1998');
insert into movie (movie_id, title, director, genre, release_time) values (64, 'Things I Like, Things I Don''t Like (Foutaises)', 'Dahlia Potzold', 'Comedy', '6/23/1986');
insert into movie (movie_id, title, director, genre, release_time) values (65, 'Burmese Harp, The (Biruma no tategoto)', 'Pavla Carcas', 'Drama|War', '7/24/2014');
insert into movie (movie_id, title, director, genre, release_time) values (66, 'Chinese Take-Out (Chinese Take-Away) (Un cuento chino)', 'Austin McFeate', 'Comedy', '4/1/2005');
insert into movie (movie_id, title, director, genre, release_time) values (67, 'Bizarre, Bizarre (Drôle de drame ou L''étrange aventure de Docteur Molyneux)', 'Dianna Bisp', 'Comedy', '4/1/1985');
insert into movie (movie_id, title, director, genre, release_time) values (68, 'Rose, The', 'Hercules Basill', 'Drama', '11/2/2011');
insert into movie (movie_id, title, director, genre, release_time) values (69, 'Why Don''t You Play In Hell? (Jigoku de naze warui)', 'Lelah Earle', 'Action|Drama', '1/26/1998');
insert into movie (movie_id, title, director, genre, release_time) values (70, 'Mugger, The (El asaltante)', 'Ritchie Greatbank', 'Drama', '1/29/1992');
insert into movie (movie_id, title, director, genre, release_time) values (71, 'Dolphin Tale', 'Milt Jeffers', 'Children|Drama', '12/14/1988');
insert into movie (movie_id, title, director, genre, release_time) values (72, 'Khartoum', 'Selena Dunstall', 'Action|Adventure|Drama|War', '12/18/1981');
insert into movie (movie_id, title, director, genre, release_time) values (73, 'Bikini Carwash Company, The', 'Marthena Rapo', 'Comedy', '9/20/1998');
insert into movie (movie_id, title, director, genre, release_time) values (74, 'Execution of P, The (Kinatay)', 'Dulce Maseres', 'Crime|Thriller', '7/11/1985');
insert into movie (movie_id, title, director, genre, release_time) values (75, 'The Intruders', 'Emmye Rivlin', 'Thriller', '8/10/2000');
insert into movie (movie_id, title, director, genre, release_time) values (76, 'State of Grace', 'Charis Barefoot', 'Crime|Drama|Thriller', '2/18/1992');
insert into movie (movie_id, title, director, genre, release_time) values (77, 'Pearls of the Deep (Perlicky na dne)', 'Tully Kiefer', 'Comedy', '6/5/2015');
insert into movie (movie_id, title, director, genre, release_time) values (78, 'Goyokin', 'Curtice Gowanson', 'Action|Drama', '12/25/2004');
insert into movie (movie_id, title, director, genre, release_time) values (79, 'Notorious', 'Lazare Maxwaile', 'Film-Noir|Romance|Thriller', '2/25/2018');
insert into movie (movie_id, title, director, genre, release_time) values (80, 'Terrorizers, The (Kong bu fen zi)', 'Park Elsmor', 'Drama', '11/15/1998');
insert into movie (movie_id, title, director, genre, release_time) values (81, 'Investigation of a Citizen Above Suspicion (Indagine su un cittadino al di sopra di ogni sospetto)', 'Win Wooler', 'Crime|Drama|Thriller', '6/22/2004');
insert into movie (movie_id, title, director, genre, release_time) values (82, 'The Hatchet Man', 'Joseito Witcomb', 'Crime|Drama', '9/8/1994');
insert into movie (movie_id, title, director, genre, release_time) values (83, 'Saw', 'Darci Ivanishev', 'Horror|Mystery|Thriller', '9/29/2005');
insert into movie (movie_id, title, director, genre, release_time) values (84, 'Mail Order Bride', 'Caryl Breit', 'Comedy|Western', '3/8/1985');
insert into movie (movie_id, title, director, genre, release_time) values (85, 'More Wild Wild West', 'Kenyon Banner', 'Adventure|Comedy|Sci-Fi|Western', '2/7/2015');
insert into movie (movie_id, title, director, genre, release_time) values (86, 'Bloody Pit of Horror (Il boia scarlatto) (Virgins for the Hangman)', 'Hamid Rodge', 'Horror', '6/11/2009');
insert into movie (movie_id, title, director, genre, release_time) values (87, 'On the Ice', 'Nelie Jedrzejkiewicz', 'Drama|Thriller', '7/25/2013');
insert into movie (movie_id, title, director, genre, release_time) values (88, 'Sansa', 'Juliane O''Dowd', 'Drama', '11/10/1996');
insert into movie (movie_id, title, director, genre, release_time) values (89, 'Rasputin and the Empress', 'Lauritz Rabl', 'Drama', '9/22/1993');
insert into movie (movie_id, title, director, genre, release_time) values (90, 'Jolson Sings Again', 'Pincus Banting', 'Musical', '3/29/1994');
insert into movie (movie_id, title, director, genre, release_time) values (91, 'Mr Hublot', 'Sol Tytler', 'Animation|Comedy', '6/7/1986');
insert into movie (movie_id, title, director, genre, release_time) values (92, 'Hocus Pocus', 'Allen Cabral', 'Children|Comedy|Fantasy|Horror', '11/21/1994');
insert into movie (movie_id, title, director, genre, release_time) values (93, 'Meet the Applegates', 'Rollo Baxter', 'Comedy', '2/22/1998');
insert into movie (movie_id, title, director, genre, release_time) values (94, 'Aquí llega Condemor, el pecador de la pradera', 'Ariadne Merrgan', 'Comedy|Western', '10/22/2002');
insert into movie (movie_id, title, director, genre, release_time) values (95, 'Pulse (Kairo)', 'Tara Pover', 'Horror|Mystery|Thriller', '4/29/1981');
insert into movie (movie_id, title, director, genre, release_time) values (96, 'Nobody Lives Forever', 'Madelin Hedgecock', 'Crime|Drama|Film-Noir', '7/16/1983');
insert into movie (movie_id, title, director, genre, release_time) values (97, 'The Italian Connection', 'Shaine Duddle', 'Crime|Drama', '5/19/1997');
insert into movie (movie_id, title, director, genre, release_time) values (98, 'Unforgotten: Twenty-Five Years After Willowbrook', 'Emelda De Bruijn', 'Documentary', '12/5/1990');
insert into movie (movie_id, title, director, genre, release_time) values (99, 'Nun, The (La religieuse)', 'Kial Krienke', 'Drama', '2/7/1998');
insert into movie (movie_id, title, director, genre, release_time) values (100, 'Vacuum-Cleaner Salesmen (Pölynimurikauppiaat)', 'Kris Donat', 'Documentary', '1/3/1982');
/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO watched
SELECT email, movie_id FROM person, movie ORDER BY RANDOM() LIMIT 1000;

