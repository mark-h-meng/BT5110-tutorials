/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/* Student Li Zongxian, Student No.:A0232193L                           */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*I'd like to choose PostgreSQL to design my database.
The three tables I design are as follows.
E1 is called 'device'. It contains some attributes about device numbers, which is called 'userid'.
To be specific, each 'userid' has attributes, including its production date 'date', its owner's gender 'gender', its owner's nationality 'country', its owner's race 'race', and its owner's usage situation 'usage_freq'.
E2 is called 'app_info'. It contains many apps' names 'name', their versions 'version' and their founders' nationality 'country'.
R is called 'install'. It contains the app names each device has installed in the past 30 days. It associates the 'userid' of the device to the names of apps they have installed 'name'.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Create table device(E1) */
create table device (
	userid INT NOT NULL PRIMARY KEY,
	date DATE NOT NULL,
	gender VARCHAR(50) NOT NULL,
	country VARCHAR(50) NOT NULL,
	race VARCHAR(50) NOT NULL,
	usage_freq VARCHAR(50) NOT NULL
);
/* Create table app_info(E2) */
create table app_info (
	name VARCHAR(50) NOT NULL PRIMARY KEY,
	version VARCHAR(50) NOT NULL,
	country VARCHAR(50) NOT NULL
);
/* Create table install(R) */
create table install(
    userid INT REFERENCES device(userid),
    name VARCHAR(50) REFERENCES app_info(name),
    PRIMARY KEY(userid, name)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Insert data into table device */
insert into device (userid, date, gender, country, race, usage_freq) values (1, '2020-12-14', 'Male', 'Indonesia', 'Sri Lankan', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (2, '2020-09-02', 'Male', 'Uzbekistan', 'Apache', 'Daily');
insert into device (userid, date, gender, country, race, usage_freq) values (3, '2020-02-03', 'Male', 'Haiti', 'Honduran', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (4, '2020-12-13', 'Male', 'Canada', 'Iroquois', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (5, '2020-10-31', 'Female', 'Japan', 'Asian Indian', 'Never');
insert into device (userid, date, gender, country, race, usage_freq) values (6, '2020-01-04', 'Female', 'Philippines', 'Asian Indian', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (7, '2020-12-25', 'Male', 'Russia', 'Puget Sound Salish', 'Monthly');
insert into device (userid, date, gender, country, race, usage_freq) values (8, '2020-05-26', 'Male', 'Japan', 'Spaniard', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (9, '2020-02-20', 'Male', 'Malta', 'Dominican (Dominican Republic)', 'Weekly');
insert into device (userid, date, gender, country, race, usage_freq) values (10, '2020-01-30', 'Female', 'China', 'Ute', 'Weekly');
insert into device (userid, date, gender, country, race, usage_freq) values (11, '2020-07-06', 'Male', 'Russia', 'Sioux', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (12, '2020-09-30', 'Male', 'Philippines', 'Latin American Indian', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (13, '2020-11-22', 'Female', 'Argentina', 'Alaska Native', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (14, '2020-10-28', 'Female', 'China', 'Panamanian', 'Weekly');
insert into device (userid, date, gender, country, race, usage_freq) values (15, '2020-09-13', 'Female', 'China', 'Tohono O''Odham', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (16, '2020-09-21', 'Male', 'Ukraine', 'Pakistani', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (17, '2020-10-26', 'Male', 'Japan', 'Lumbee', 'Daily');
insert into device (userid, date, gender, country, race, usage_freq) values (18, '2020-07-18', 'Male', 'France', 'Malaysian', 'Seldom');
insert into device (userid, date, gender, country, race, usage_freq) values (19, '2020-04-29', 'Male', 'Georgia', 'Colville', 'Never');
insert into device (userid, date, gender, country, race, usage_freq) values (20, '2020-09-19', 'Female', 'Czech Republic', 'Cheyenne', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (21, '2020-10-23', 'Female', 'Iran', 'Kiowa', 'Seldom');
insert into device (userid, date, gender, country, race, usage_freq) values (22, '2020-04-08', 'Female', 'China', 'Polynesian', 'Daily');
insert into device (userid, date, gender, country, race, usage_freq) values (23, '2020-04-04', 'Male', 'China', 'Taiwanese', 'Never');
insert into device (userid, date, gender, country, race, usage_freq) values (24, '2020-03-22', 'Female', 'China', 'Cheyenne', 'Monthly');
insert into device (userid, date, gender, country, race, usage_freq) values (25, '2020-03-20', 'Male', 'Sweden', 'Latin American Indian', 'Daily');
insert into device (userid, date, gender, country, race, usage_freq) values (26, '2020-05-22', 'Female', 'Pakistan', 'White', 'Never');
insert into device (userid, date, gender, country, race, usage_freq) values (27, '2020-10-10', 'Male', 'Poland', 'Samoan', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (28, '2020-06-26', 'Female', 'Sweden', 'Cambodian', 'Daily');
insert into device (userid, date, gender, country, race, usage_freq) values (29, '2020-06-18', 'Male', 'China', 'South American', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (30, '2020-06-10', 'Male', 'Philippines', 'Eskimo', 'Never');
insert into device (userid, date, gender, country, race, usage_freq) values (31, '2020-04-01', 'Male', 'Canada', 'Yakama', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (32, '2020-06-17', 'Female', 'Vietnam', 'Potawatomi', 'Never');
insert into device (userid, date, gender, country, race, usage_freq) values (33, '2020-09-13', 'Male', 'Burundi', 'Apache', 'Daily');
insert into device (userid, date, gender, country, race, usage_freq) values (34, '2020-01-08', 'Male', 'Portugal', 'Native Hawaiian and Other Pacific Islander (NHPI)', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (35, '2020-02-27', 'Female', 'Russia', 'Peruvian', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (36, '2020-08-26', 'Female', 'Indonesia', 'Tohono O''Odham', 'Monthly');
insert into device (userid, date, gender, country, race, usage_freq) values (37, '2020-10-20', 'Male', 'Philippines', 'Chamorro', 'Daily');
insert into device (userid, date, gender, country, race, usage_freq) values (38, '2020-11-06', 'Male', 'Philippines', 'Bangladeshi', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (39, '2020-05-18', 'Female', 'Libya', 'Shoshone', 'Seldom');
insert into device (userid, date, gender, country, race, usage_freq) values (40, '2020-01-04', 'Male', 'China', 'Cree', 'Weekly');
insert into device (userid, date, gender, country, race, usage_freq) values (41, '2020-12-27', 'Male', 'Mongolia', 'Apache', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (42, '2020-10-31', 'Female', 'Czech Republic', 'Bangladeshi', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (43, '2020-01-24', 'Female', 'Canada', 'Black or African American', 'Monthly');
insert into device (userid, date, gender, country, race, usage_freq) values (44, '2020-07-30', 'Male', 'Sweden', 'Latin American Indian', 'Daily');
insert into device (userid, date, gender, country, race, usage_freq) values (45, '2020-11-21', 'Male', 'Armenia', 'Paiute', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (46, '2020-06-20', 'Female', 'China', 'Tongan', 'Never');
insert into device (userid, date, gender, country, race, usage_freq) values (47, '2020-03-10', 'Female', 'Chile', 'Apache', 'Never');
insert into device (userid, date, gender, country, race, usage_freq) values (48, '2020-12-24', 'Female', 'Brazil', 'Ottawa', 'Seldom');
insert into device (userid, date, gender, country, race, usage_freq) values (49, '2020-11-14', 'Female', 'Brazil', 'Black or African American', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (50, '2020-12-04', 'Female', 'Brunei', 'Cheyenne', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (51, '2020-08-09', 'Male', 'China', 'Seminole', 'Seldom');
insert into device (userid, date, gender, country, race, usage_freq) values (52, '2020-05-06', 'Female', 'Greece', 'Black or African American', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (53, '2020-11-17', 'Male', 'Mauritius', 'Aleut', 'Monthly');
insert into device (userid, date, gender, country, race, usage_freq) values (54, '2020-11-01', 'Female', 'Indonesia', 'Black or African American', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (55, '2020-05-10', 'Male', 'Colombia', 'Malaysian', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (56, '2020-08-20', 'Male', 'Mexico', 'Alaskan Athabascan', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (57, '2020-08-28', 'Male', 'Malaysia', 'Tongan', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (58, '2020-11-01', 'Male', 'France', 'Colville', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (59, '2020-05-20', 'Female', 'Yemen', 'Cuban', 'Monthly');
insert into device (userid, date, gender, country, race, usage_freq) values (60, '2020-04-20', 'Male', 'China', 'Yakama', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (61, '2020-04-04', 'Male', 'Mauritius', 'Samoan', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (62, '2020-02-17', 'Female', 'Georgia', 'Navajo', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (63, '2020-12-20', 'Male', 'Uzbekistan', 'Guatemalan', 'Monthly');
insert into device (userid, date, gender, country, race, usage_freq) values (64, '2020-02-28', 'Female', 'Lithuania', 'Chamorro', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (65, '2020-07-18', 'Male', 'Philippines', 'Delaware', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (66, '2020-07-10', 'Female', 'Sweden', 'Salvadoran', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (67, '2020-09-17', 'Female', 'Peru', 'Eskimo', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (68, '2020-10-26', 'Female', 'United Kingdom', 'Pueblo', 'Never');
insert into device (userid, date, gender, country, race, usage_freq) values (69, '2020-03-30', 'Male', 'Saint Lucia', 'Indonesian', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (70, '2020-05-13', 'Male', 'Indonesia', 'Thai', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (71, '2020-02-28', 'Female', 'North Korea', 'Malaysian', 'Seldom');
insert into device (userid, date, gender, country, race, usage_freq) values (72, '2020-03-23', 'Female', 'Peru', 'Japanese', 'Weekly');
insert into device (userid, date, gender, country, race, usage_freq) values (73, '2020-04-08', 'Female', 'Argentina', 'Shoshone', 'Seldom');
insert into device (userid, date, gender, country, race, usage_freq) values (74, '2020-04-18', 'Male', 'Sweden', 'Sioux', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (75, '2020-05-09', 'Female', 'China', 'Thai', 'Monthly');
insert into device (userid, date, gender, country, race, usage_freq) values (76, '2020-07-29', 'Male', 'Czech Republic', 'Vietnamese', 'Daily');
insert into device (userid, date, gender, country, race, usage_freq) values (77, '2020-08-02', 'Male', 'Philippines', 'Apache', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (78, '2020-11-10', 'Male', 'Libya', 'Kiowa', 'Seldom');
insert into device (userid, date, gender, country, race, usage_freq) values (79, '2020-01-12', 'Male', 'Sweden', 'Lumbee', 'Daily');
insert into device (userid, date, gender, country, race, usage_freq) values (80, '2020-03-15', 'Male', 'China', 'Cherokee', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (81, '2020-12-30', 'Female', 'Malawi', 'Melanesian', 'Monthly');
insert into device (userid, date, gender, country, race, usage_freq) values (82, '2020-06-24', 'Male', 'Indonesia', 'Ottawa', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (83, '2020-04-01', 'Female', 'Syria', 'Houma', 'Monthly');
insert into device (userid, date, gender, country, race, usage_freq) values (84, '2020-02-18', 'Male', 'Macedonia', 'Dominican (Dominican Republic)', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (85, '2020-06-24', 'Female', 'Indonesia', 'Crow', 'Weekly');
insert into device (userid, date, gender, country, race, usage_freq) values (86, '2020-07-27', 'Male', 'Philippines', 'Samoan', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (87, '2020-05-30', 'Male', 'Japan', 'Sioux', 'Seldom');
insert into device (userid, date, gender, country, race, usage_freq) values (88, '2020-09-13', 'Male', 'Indonesia', 'Creek', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (89, '2020-06-15', 'Male', 'China', 'Puget Sound Salish', 'Yearly');
insert into device (userid, date, gender, country, race, usage_freq) values (90, '2020-02-03', 'Female', 'Croatia', 'Ute', 'Weekly');
insert into device (userid, date, gender, country, race, usage_freq) values (91, '2020-11-24', 'Male', 'China', 'Menominee', 'Never');
insert into device (userid, date, gender, country, race, usage_freq) values (92, '2020-01-24', 'Female', 'Argentina', 'Native Hawaiian and Other Pacific Islander (NHPI)', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (93, '2020-12-16', 'Male', 'Indonesia', 'Colombian', 'Seldom');
insert into device (userid, date, gender, country, race, usage_freq) values (94, '2020-08-05', 'Male', 'China', 'Bangladeshi', 'Monthly');
insert into device (userid, date, gender, country, race, usage_freq) values (95, '2020-03-01', 'Male', 'Saudi Arabia', 'Cree', 'Daily');
insert into device (userid, date, gender, country, race, usage_freq) values (96, '2020-02-10', 'Female', 'Indonesia', 'Thai', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (97, '2020-09-29', 'Male', 'Poland', 'Asian Indian', 'Often');
insert into device (userid, date, gender, country, race, usage_freq) values (98, '2020-11-22', 'Male', 'Chad', 'Cree', 'Once');
insert into device (userid, date, gender, country, race, usage_freq) values (99, '2020-08-14', 'Female', 'Norway', 'Uruguayan', 'Never');
insert into device (userid, date, gender, country, race, usage_freq) values (100, '2020-06-23', 'Male', 'Russia', 'Paraguayan', 'Seldom');

/* insert data into table app_info */
insert into app_info (name, version, country) values ('com.elpais.Home Ing', '0.86', 'China');
insert into app_info (name, version, country) values ('net.discuz.Span', '0.36', 'Portugal');
insert into app_info (name, version, country) values ('com.hostgator.Tampflex', '0.1.8', 'Senegal');
insert into app_info (name, version, country) values ('com.technorati.Cardify', '6.40', 'France');
insert into app_info (name, version, country) values ('com.printfriendly.Konklab', '1.1.7', 'Indonesia');
insert into app_info (name, version, country) values ('uk.gov.It', '0.6.1', 'Indonesia');
insert into app_info (name, version, country) values ('com.nymag.Tampflex', '4.6', 'Laos');
insert into app_info (name, version, country) values ('au.com.smh.Bitwolf', '8.1', 'United States');
insert into app_info (name, version, country) values ('net.furl.Opela', '1.9.8', 'China');
insert into app_info (name, version, country) values ('jp.japanpost.Daltfresh', '0.24', 'Albania');
insert into app_info (name, version, country) values ('com.sbwire.Quo Lux', '4.5', 'United States');
insert into app_info (name, version, country) values ('com.posterous.Andalax', '0.22', 'Thailand');
insert into app_info (name, version, country) values ('com.dagondesign.Toughjoyfax', '3.5.0', 'Brazil');
insert into app_info (name, version, country) values ('com.fastcompany.Mat Lam Tam', '0.16', 'Russia');
insert into app_info (name, version, country) values ('com.artisteer.Ventosanzap', '2.2.3', 'United States');
insert into app_info (name, version, country) values ('vu.de.Alphazap', '5.1', 'Armenia');
insert into app_info (name, version, country) values ('com.cnn.Lotstring', '9.0.4', 'Sierra Leone');
insert into app_info (name, version, country) values ('com.sfgate.Zontrax', '0.8.8', 'Brazil');
insert into app_info (name, version, country) values ('uk.co.independent.Asoka', '0.3.0', 'Indonesia');
insert into app_info (name, version, country) values ('com.tinyurl.Holdlamis', '4.6.0', 'Poland');
insert into app_info (name, version, country) values ('com.hao123.Zoolab', '0.71', 'Brazil');
insert into app_info (name, version, country) values ('net.comcast.Namfix', '7.83', 'China');
insert into app_info (name, version, country) values ('com.live.Gembucket', '4.20', 'Egypt');
insert into app_info (name, version, country) values ('au.gov.privacy.Subin', '0.8.8', 'Brazil');
insert into app_info (name, version, country) values ('com.msn.Duobam', '3.53', 'Latvia');
insert into app_info (name, version, country) values ('com.alibaba.Zamit', '4.9.6', 'Russia');
insert into app_info (name, version, country) values ('org.craigslist.Lotlux', '2.3', 'Ukraine');
insert into app_info (name, version, country) values ('com.sbwire.Lotlux', '6.16', 'Japan');
insert into app_info (name, version, country) values ('com.issuu.Lotstring', '6.2', 'Portugal');
insert into app_info (name, version, country) values ('com.newyorker.Solarbreeze', '4.3', 'China');
insert into app_info (name, version, country) values ('org.unesco.Quo Lux', '5.6', 'Russia');
insert into app_info (name, version, country) values ('com.parallels.It', '2.1', 'Sweden');
insert into app_info (name, version, country) values ('com.salon.Gembucket', '0.7.7', 'China');
insert into app_info (name, version, country) values ('com.weather.Tempsoft', '0.8.7', 'Paraguay');
insert into app_info (name, version, country) values ('com.sohu.Quo Lux', '4.6', 'China');
insert into app_info (name, version, country) values ('com.spotify.Tampflex', '2.4', 'Philippines');
insert into app_info (name, version, country) values ('com.theguardian.Rank', '7.15', 'Sweden');
insert into app_info (name, version, country) values ('com.nifty.Tempsoft', '5.0.1', 'Palestinian Territory');
insert into app_info (name, version, country) values ('gov.fema.Solarbreeze', '2.4', 'Brazil');
insert into app_info (name, version, country) values ('com.wsj.Transcof', '0.90', 'Macedonia');
insert into app_info (name, version, country) values ('com.slate.Prodder', '8.9.4', 'China');
insert into app_info (name, version, country) values ('gd.is.Opela', '0.58', 'Colombia');
insert into app_info (name, version, country) values ('com.xrea.Flexidy', '9.98', 'Chile');
insert into app_info (name, version, country) values ('com.cnbc.Sub-Ex', '1.19', 'Portugal');
insert into app_info (name, version, country) values ('com.photobucket.Pannier', '0.64', 'Brazil');
insert into app_info (name, version, country) values ('com.lycos.Bitwolf', '0.5.7', 'Croatia');
insert into app_info (name, version, country) values ('org.craigslist.Subin', '7.9', 'Ukraine');
insert into app_info (name, version, country) values ('com.github.Ventosanzap', '2.5.7', 'China');
insert into app_info (name, version, country) values ('net.clickbank.Lotstring', '0.70', 'China');
insert into app_info (name, version, country) values ('com.marriott.Domainer', '6.17', 'Portugal');
insert into app_info (name, version, country) values ('com.nba.Veribet', '0.56', 'Indonesia');
insert into app_info (name, version, country) values ('it.google.Andalax', '0.11', 'Latvia');
insert into app_info (name, version, country) values ('com.jigsy.It', '2.9.1', 'Sweden');
insert into app_info (name, version, country) values ('net.seesaa.Cookley', '8.7', 'Indonesia');
insert into app_info (name, version, country) values ('com.zdnet.Lotlux', '6.6.4', 'Norway');
insert into app_info (name, version, country) values ('com.chron.Bitchip', '0.6.9', 'Indonesia');
insert into app_info (name, version, country) values ('com.digg.Rank', '0.5.2', 'Germany');
insert into app_info (name, version, country) values ('com.moonfruit.Bigtax', '8.5.9', 'Brazil');
insert into app_info (name, version, country) values ('cn.gov.miitbeian.Bytecard', '5.2', 'Armenia');
insert into app_info (name, version, country) values ('nl.google.Transcof', '5.3', 'Indonesia');
insert into app_info (name, version, country) values ('com.merriam-webster.Vagram', '2.5', 'China');
insert into app_info (name, version, country) values ('com.gizmodo.Matsoft', '8.8', 'Japan');
insert into app_info (name, version, country) values ('com.boston.Gembucket', '7.0.9', 'Ukraine');
insert into app_info (name, version, country) values ('edu.umn.Y-Solowarm', '1.12', 'Peru');
insert into app_info (name, version, country) values ('com.fotki.Zontrax', '4.3', 'Pakistan');
insert into app_info (name, version, country) values ('org.simplemachines.Fixflex', '0.9.4', 'China');
insert into app_info (name, version, country) values ('org.altervista.Rank', '8.7', 'Nigeria');
insert into app_info (name, version, country) values ('com.woothemes.Tin', '3.95', 'China');
insert into app_info (name, version, country) values ('be.youtu.Subin', '1.1', 'Norway');
insert into app_info (name, version, country) values ('org.altervista.Y-find', '0.30', 'Germany');
insert into app_info (name, version, country) values ('com.indiatimes.Bigtax', '9.95', 'United States');
insert into app_info (name, version, country) values ('jp.ameblo.It', '0.5.9', 'Malaysia');
insert into app_info (name, version, country) values ('io.pen.Regrant', '0.7.2', 'Mexico');
insert into app_info (name, version, country) values ('com.dailymotion.Asoka', '3.35', 'Finland');
insert into app_info (name, version, country) values ('ru.odnoklassniki.Wrapsafe', '7.8', 'Greece');
insert into app_info (name, version, country) values ('gov.cdc.Greenlam', '0.6.8', 'Portugal');
insert into app_info (name, version, country) values ('gov.hud.Stronghold', '0.34', 'Thailand');
insert into app_info (name, version, country) values ('com.eventbrite.Y-Solowarm', '0.90', 'Indonesia');
insert into app_info (name, version, country) values ('com.tumblr.Wrapsafe', '3.2.6', 'Portugal');
insert into app_info (name, version, country) values ('com.studiopress.Tresom', '1.4.2', 'Canada');
insert into app_info (name, version, country) values ('net.themeforest.Subin', '0.2.4', 'China');
insert into app_info (name, version, country) values ('com.scribd.Greenlam', '9.0', 'Poland');
insert into app_info (name, version, country) values ('com.sciencedirect.Konklab', '5.99', 'Burkina Faso');
insert into app_info (name, version, country) values ('tv.ustream.Overhold', '4.01', 'Indonesia');
insert into app_info (name, version, country) values ('com.wunderground.Viva', '8.68', 'Portugal');
insert into app_info (name, version, country) values ('com.wired.Daltfresh', '3.89', 'Estonia');
insert into app_info (name, version, country) values ('gd.is.Keylex', '3.7.5', 'China');
insert into app_info (name, version, country) values ('gov.nih.Voltsillam', '0.6.8', 'Laos');
insert into app_info (name, version, country) values ('com.apple.Wrapsafe', '2.6', 'Saint Vincent and the Grenadines');
insert into app_info (name, version, country) values ('com.smugmug.Rank', '2.4.7', 'Bulgaria');
insert into app_info (name, version, country) values ('ru.rambler.Home Ing', '0.36', 'Brazil');
insert into app_info (name, version, country) values ('edu.cornell.Voyatouch', '5.0.3', 'Indonesia');
insert into app_info (name, version, country) values ('hk.com.google.Tempsoft', '7.45', 'Portugal');
insert into app_info (name, version, country) values ('ru.liveinternet.Konklab', '1.1', 'Indonesia');
insert into app_info (name, version, country) values ('au.com.smh.Tempsoft', '0.8.5', 'Thailand');
insert into app_info (name, version, country) values ('com.instagram.Sonair', '7.8.0', 'Bangladesh');
insert into app_info (name, version, country) values ('edu.washington.Cookley', '0.11', 'Russia');
insert into app_info (name, version, country) values ('com.wp.Zaam-Dox', '9.1', 'Jamaica');
insert into app_info (name, version, country) values ('com.intel.Flexidy', '6.07', 'Poland');
insert into app_info (name, version, country) values ('co.g.Cardguard', '3.7', 'Madagascar');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Insert combined data into table install */
insert into install
select a.userid, b.name
from device a, app_info b
order by random()
limit 1000;