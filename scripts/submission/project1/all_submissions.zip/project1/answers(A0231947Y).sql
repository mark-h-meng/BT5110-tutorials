/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/* Student Name: TSAO, KAI-TING                                         */
/* Student Number: A0231947Y                                            */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* I would like to develop an application for managing the data of my 
customers' stocks. The first entity set E1, 'users', shows several customers' 
information, and includes their userid, first name, last name, email, 
password and their country. The second entity set E2, 'stock', is used to 
manage the list of stocks and consists of stock market, stock symbol, 
stock name and its sector. Finally, the table 'portfolio' associates 
the userid of the customers with the stock symbol and stock name which 
the customers buy and own. The quantity of customers' stocks
can also be found in this table.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS users (
	userid VARCHAR(16) PRIMARY KEY,
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	email VARCHAR(64) UNIQUE NOT NULL,
	password_no VARCHAR(16) NOT NULL,
	country VARCHAR(16) NOT NULL);

CREATE TABLE IF NOT EXISTS stock (
	stock_market VARCHAR(16) NOT NULL,
	stock_symbol VARCHAR(16),
	stock_name VARCHAR(64),
	stock_sector VARCHAR(32) NOT NULL,
	PRIMARY KEY(stock_symbol, stock_name));

CREATE TABLE portfolio(
	userid VARCHAR(16) REFERENCES users(userid)
	ON UPDATE CASCADE ON DELETE CASCADE
	DEFERRABLE INITIALLY DEFERRED,
	stock_symbol VARCHAR(16),
	stock_name VARCHAR(64),
	PRIMARY KEY(userid, stock_symbol, stock_name),
	FOREIGN KEY (stock_symbol, stock_name) REFERENCES stock (stock_symbol, stock_name)
	ON UPDATE CASCADE ON DELETE CASCADE
	DEFERRABLE INITIALLY DEFERRED,
	share_quantity INTEGER);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into users (userid, first_name, last_name, email, password_no, country) values ('jhuitt0', 'Jaine', 'Huitt', 'jhuitt0@answers.com', 'kmbwKN1en5yU', 'Hong Kong');
insert into users (userid, first_name, last_name, email, password_no, country) values ('mpridgeon1', 'Maia', 'Pridgeon', 'mpridgeon1@mysql.com', 'g2rRCf933', 'South Korea');
insert into users (userid, first_name, last_name, email, password_no, country) values ('robruen2', 'Ros', 'O''Bruen', 'robruen2@godaddy.com', 'epAo66BMT', 'Russia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('ntingly3', 'Nathanil', 'Tingly', 'ntingly3@php.net', 'It1uX73', 'Japan');
insert into users (userid, first_name, last_name, email, password_no, country) values ('slankham4', 'Shae', 'Lankham', 'slankham4@marriott.com', 'B4CxnBA', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('lbetho5', 'Luciana', 'Betho', 'lbetho5@narod.ru', 'VlgDPucsTPn', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('rarblaster6', 'Remy', 'Arblaster', 'rarblaster6@shutterfly.com', 'kw3rGZ9xQuCw', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('spetrello7', 'Steffie', 'Petrello', 'spetrello7@furl.net', 'MoRUhyKbVrs', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('dboldock8', 'Derk', 'Boldock', 'dboldock8@slideshare.net', 'Cky4QXz', 'Thailand');
insert into users (userid, first_name, last_name, email, password_no, country) values ('ebrowning9', 'Emmi', 'Browning', 'ebrowning9@merriam-webster.com', '2MrxeJrwscg', 'France');
insert into users (userid, first_name, last_name, email, password_no, country) values ('gscortona', 'Gallagher', 'Scorton', 'gscortona@cpanel.net', 'jx8CANP1o3z8', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('mmatteottib', 'Margalit', 'Matteotti', 'mmatteottib@networkadvertising.org', 'MX6DgV0lYj8m', 'Russia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('chedinghamc', 'Casar', 'Hedingham', 'chedinghamc@barnesandnoble.com', '3hmulcu', 'Thailand');
insert into users (userid, first_name, last_name, email, password_no, country) values ('klumlyd', 'Klaus', 'Lumly', 'klumlyd@guardian.co.uk', '5SJpl1', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('cwhippe', 'Charmian', 'Whipp', 'cwhippe@photobucket.com', 'Rt72DOG', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('efewtrellf', 'Edgar', 'Fewtrell', 'efewtrellf@redcross.org', 'paWEo7uEtvV', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('bclayg', 'Brig', 'Clay', 'bclayg@narod.ru', 'n8IKO9A14', 'Philippines');
insert into users (userid, first_name, last_name, email, password_no, country) values ('awakelingh', 'Anastassia', 'Wakeling', 'awakelingh@storify.com', 'G7wc7TK', 'Sweden');
insert into users (userid, first_name, last_name, email, password_no, country) values ('egofforthi', 'Esmaria', 'Gofforth', 'egofforthi@hhs.gov', 'NeVRWanH', 'Philippines');
insert into users (userid, first_name, last_name, email, password_no, country) values ('lmelbertj', 'Levy', 'Melbert', 'lmelbertj@tmall.com', 'mtNn2E08', 'Russia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('mjoskowiczk', 'Mathilda', 'Joskowicz', 'mjoskowiczk@rambler.ru', 'Q35KsS', 'Vietnam');
insert into users (userid, first_name, last_name, email, password_no, country) values ('lbeertl', 'Lianne', 'Beert', 'lbeertl@fotki.com', 'jcLFcnq3', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('sdrawmerm', 'Sunshine', 'Drawmer', 'sdrawmerm@hugedomains.com', 'QMggUnnlsV09', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('socarneyn', 'Sandi', 'O''Carney', 'socarneyn@yandex.ru', 'YJA228F', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('tdeleono', 'Tomaso', 'de Leon', 'tdeleono@bizjournals.com', '1ZycXcCc7NS', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('dmannsp', 'Doti', 'Manns', 'dmannsp@cnn.com', 'pDj5tuSJ', 'Portugal');
insert into users (userid, first_name, last_name, email, password_no, country) values ('dslyvesterq', 'Darnall', 'Slyvester', 'dslyvesterq@wordpress.com', '2ZUB25', 'France');
insert into users (userid, first_name, last_name, email, password_no, country) values ('lcolvillr', 'Lauryn', 'Colvill', 'lcolvillr@smh.com.au', 'JnsgiFT', 'Philippines');
insert into users (userid, first_name, last_name, email, password_no, country) values ('aquerrees', 'Amby', 'Querree', 'aquerrees@sbwire.com', '9e93urKZvmLf', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('dablewhitet', 'Debor', 'Ablewhite', 'dablewhitet@shutterfly.com', 'UFr1JQC', 'South Korea');
insert into users (userid, first_name, last_name, email, password_no, country) values ('jantoniu', 'Jeremiah', 'Antoni', 'jantoniu@weather.com', '03MlvYK6', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('thazelhurstv', 'Tod', 'Hazelhurst', 'thazelhurstv@odnoklassniki.ru', 'cWPFLTBhz9', 'Russia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('bbrehautw', 'Brocky', 'Brehaut', 'bbrehautw@altervista.org', 'MYFPAgqeFs', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('gmccutcheonx', 'Gwendolen', 'McCutcheon', 'gmccutcheonx@army.mil', 'UgxtQvjS5I', 'Philippines');
insert into users (userid, first_name, last_name, email, password_no, country) values ('equadrioy', 'Eve', 'Quadrio', 'equadrioy@china.com.cn', 'LUtepUA4Y', 'Japan');
insert into users (userid, first_name, last_name, email, password_no, country) values ('rsteinorz', 'Raleigh', 'Steinor', 'rsteinorz@friendfeed.com', 'lPa9qM', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('rkerin10', 'Rip', 'Kerin', 'rkerin10@ihg.com', 'Tu5WODH', 'Vietnam');
insert into users (userid, first_name, last_name, email, password_no, country) values ('equillinane11', 'Eldin', 'Quillinane', 'equillinane11@freewebs.com', '8xcMJuLt4J', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('gcapinetti12', 'Gunilla', 'Capinetti', 'gcapinetti12@4shared.com', '9RR8nYP3BVGV', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('dcommander13', 'Dorree', 'Commander', 'dcommander13@altervista.org', '0sNnuv4f874m', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('hbellas14', 'Hubert', 'Bellas', 'hbellas14@t.co', 'yuQ4X4Qy', 'France');
insert into users (userid, first_name, last_name, email, password_no, country) values ('kconstanza15', 'Kym', 'Constanza', 'kconstanza15@domainmarket.com', 'aIZs6JSGwG9L', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('fgadney16', 'Forster', 'Gadney', 'fgadney16@tinypic.com', 'JFVVMCuI', 'Philippines');
insert into users (userid, first_name, last_name, email, password_no, country) values ('ajessep17', 'Alix', 'Jessep', 'ajessep17@fc2.com', 'hCqcwcED', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('tstaples18', 'Teddie', 'Staples', 'tstaples18@odnoklassniki.ru', 'ahy5ar4ZRxP', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('rilyenko19', 'Rhodie', 'Ilyenko', 'rilyenko19@miibeian.gov.cn', 'Of4TUsRxdqag', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('aambroz1a', 'Alicia', 'Ambroz', 'aambroz1a@domainmarket.com', '4jLRtH8BZnT', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('ttredget1b', 'Tammie', 'Tredget', 'ttredget1b@telegraph.co.uk', 'n8KSemIObCb4', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('fcresar1c', 'Frederigo', 'Cresar', 'fcresar1c@latimes.com', 'OA0K0Sgsh', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('eskacel1d', 'Etti', 'Skacel', 'eskacel1d@apache.org', 'kxJLdw', 'Mexico');
insert into users (userid, first_name, last_name, email, password_no, country) values ('cfernley1e', 'Carmina', 'Fernley', 'cfernley1e@reddit.com', 'gerPAklhdQ', 'Russia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('rphipp1f', 'Reynolds', 'Phipp', 'rphipp1f@cisco.com', 'DcEL1or', 'Sweden');
insert into users (userid, first_name, last_name, email, password_no, country) values ('fdoncaster1g', 'Florette', 'Doncaster', 'fdoncaster1g@plala.or.jp', 'vym3fzy', 'Philippines');
insert into users (userid, first_name, last_name, email, password_no, country) values ('acady1h', 'Atlante', 'Cady', 'acady1h@arizona.edu', 'B7LCYf4xLK', 'Sweden');
insert into users (userid, first_name, last_name, email, password_no, country) values ('pclemencet1i', 'Philly', 'Clemencet', 'pclemencet1i@360.cn', 'BmDOY8Xj8', 'Japan');
insert into users (userid, first_name, last_name, email, password_no, country) values ('omacvaugh1j', 'Odetta', 'MacVaugh', 'omacvaugh1j@dailymail.co.uk', '9fhfDj', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('edawks1k', 'Emelina', 'Dawks', 'edawks1k@dyndns.org', 'L7hzWsXlOJJ', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('ncramphorn1l', 'Nonna', 'Cramphorn', 'ncramphorn1l@craigslist.org', 'gp6b9mfajmME', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('tlarkworthy1m', 'Turner', 'Larkworthy', 'tlarkworthy1m@odnoklassniki.ru', 'rrVPmoIdgg', 'Portugal');
insert into users (userid, first_name, last_name, email, password_no, country) values ('ekalkofer1n', 'Ethe', 'Kalkofer', 'ekalkofer1n@flickr.com', 'NhJ9pGlBCp', 'Mexico');
insert into users (userid, first_name, last_name, email, password_no, country) values ('sdean1o', 'Selestina', 'Dean', 'sdean1o@bbc.co.uk', 'U0e3BHyv', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('tgronowe1p', 'Terrel', 'Gronowe', 'tgronowe1p@japanpost.jp', 'aX8joP', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('hbradwell1q', 'Hort', 'Bradwell', 'hbradwell1q@pcworld.com', 'neuNUJ2', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('cmeecher1r', 'Cosimo', 'Meecher', 'cmeecher1r@nasa.gov', 'I9Q09GH', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('bsimonelli1s', 'Bunnie', 'Simonelli', 'bsimonelli1s@wikia.com', 'SZQAVvd5n', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('mprendeville1t', 'Marwin', 'Prendeville', 'mprendeville1t@last.fm', 'Jx5EnPQ', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('jtrowle1u', 'Jamey', 'Trowle', 'jtrowle1u@umn.edu', '5MNQGCQGJ', 'United States');
insert into users (userid, first_name, last_name, email, password_no, country) values ('camps1v', 'Cliff', 'Amps', 'camps1v@constantcontact.com', 'pvhmc7SR', 'France');
insert into users (userid, first_name, last_name, email, password_no, country) values ('otregona1w', 'Ozzie', 'Tregona', 'otregona1w@biblegateway.com', 'FAHZ5Oj8DZMW', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('fbritney1x', 'Field', 'Britney', 'fbritney1x@miibeian.gov.cn', 'gGDS6eb4BIsD', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('ucudworth1y', 'Ula', 'Cudworth', 'ucudworth1y@usgs.gov', 'xKvuDHinAC', 'Japan');
insert into users (userid, first_name, last_name, email, password_no, country) values ('iperrone1z', 'Ingunna', 'Perrone', 'iperrone1z@i2i.jp', '7Mn3P0qPEBzr', 'France');
insert into users (userid, first_name, last_name, email, password_no, country) values ('iphuprate20', 'Isa', 'Phuprate', 'iphuprate20@xinhuanet.com', 'Bnwhucj3', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('dmcrobbie21', 'Danika', 'McRobbie', 'dmcrobbie21@businessweek.com', 'SLJ5PhT', 'Spain');
insert into users (userid, first_name, last_name, email, password_no, country) values ('jcornill22', 'Jeffy', 'Cornill', 'jcornill22@barnesandnoble.com', '7ruO9aS9', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('arunacres23', 'Alvie', 'Runacres', 'arunacres23@kickstarter.com', 'd2w7fCR', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('coskehan24', 'Christalle', 'O''Skehan', 'coskehan24@prweb.com', 'olfzKXv', 'Sweden');
insert into users (userid, first_name, last_name, email, password_no, country) values ('hmanthorpe25', 'Hillel', 'Manthorpe', 'hmanthorpe25@wikia.com', 'cSWiU74s3n', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('lgiorgio26', 'Lyndell', 'Giorgio', 'lgiorgio26@telegraph.co.uk', 'lPWfFrpauve', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('jsleeman27', 'Jaymie', 'Sleeman', 'jsleeman27@desdev.cn', 'eSHhkw', 'Canada');
insert into users (userid, first_name, last_name, email, password_no, country) values ('amariot28', 'Arney', 'Mariot', 'amariot28@oakley.com', 'bhvRXk6ea', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('crenfree29', 'Corney', 'Renfree', 'crenfree29@indiegogo.com', 'e0ER752HoVU', 'France');
insert into users (userid, first_name, last_name, email, password_no, country) values ('afitter2a', 'Aurora', 'Fitter', 'afitter2a@tamu.edu', '3DHYeANXhq', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('rallabush2b', 'Raven', 'Allabush', 'rallabush2b@creativecommons.org', 'ruAzuSG', 'Spain');
insert into users (userid, first_name, last_name, email, password_no, country) values ('swenzel2c', 'Sosanna', 'Wenzel', 'swenzel2c@rediff.com', 'hIU1wCj74FD', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('koffen2d', 'Karly', 'Offen', 'koffen2d@unicef.org', '2o2IEImDs', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('aranscomb2e', 'Adan', 'Ranscomb', 'aranscomb2e@cnbc.com', 'PKnpvPh3i', 'Russia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('bkilalea2f', 'Beverie', 'Kilalea', 'bkilalea2f@jugem.jp', 'WWAbsu', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('ebarnwille2g', 'Erwin', 'Barnwille', 'ebarnwille2g@drupal.org', 'somy3lU', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('wrowes2h', 'Wain', 'Rowes', 'wrowes2h@zimbio.com', 'lPjyi26', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('tbarribal2i', 'Tonia', 'Barribal', 'tbarribal2i@com.com', 'oXAd4bDl', 'Thailand');
insert into users (userid, first_name, last_name, email, password_no, country) values ('emclean2j', 'Emanuele', 'McLean', 'emclean2j@disqus.com', 'tQrQocX50a', 'Sweden');
insert into users (userid, first_name, last_name, email, password_no, country) values ('vdri2k', 'Valencia', 'Dri', 'vdri2k@google.com.au', '0k1cIUro', 'Philippines');
insert into users (userid, first_name, last_name, email, password_no, country) values ('fjeger2l', 'Freddie', 'Jeger', 'fjeger2l@quantcast.com', '3b0izphtiEQF', 'Indonesia');
insert into users (userid, first_name, last_name, email, password_no, country) values ('taldridge2m', 'Tim', 'Aldridge', 'taldridge2m@wisc.edu', 'G4kuZrg5', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('wcasaletto2n', 'Willamina', 'Casaletto', 'wcasaletto2n@statcounter.com', 'Jurq38', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('dmcswan2o', 'Doretta', 'McSwan', 'dmcswan2o@smh.com.au', 'hEHgIHr', 'Portugal');
insert into users (userid, first_name, last_name, email, password_no, country) values ('bcordie2p', 'Boigie', 'Cordie', 'bcordie2p@berkeley.edu', '6SHWuF', 'Portugal');
insert into users (userid, first_name, last_name, email, password_no, country) values ('lraden2q', 'Lusa', 'Raden', 'lraden2q@goodreads.com', 'cLYQ8YX', 'China');
insert into users (userid, first_name, last_name, email, password_no, country) values ('mbowller2r', 'Marty', 'Bowller', 'mbowller2r@fc2.com', 'pozcAihg6', 'China');

insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'DLR^H', 'Digital Realty Trust, Inc.', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'ASX', 'Advanced Semiconductor Engineering, Inc.', 'Technology');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'BIDU', 'Baidu, Inc.', 'Technology');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'BSAC', 'Banco Santander Chile', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'ADMP', 'Adamis Pharmaceuticals Corporation', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'PSCT', 'PowerShares S&P SmallCap Information Technology Portfolio', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'VZA', 'Verizon Communications Inc.', 'Public Utilities');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'JSMD', 'Janus Henderson Small/Mid Cap Growth Alpha ETF', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'NM', 'Navios Maritime Holdings Inc.', 'Transportation');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'APPF', 'AppFolio, Inc.', 'Technology');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'TPX', 'Tempur Sealy International, Inc.', 'Consumer Durables');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'BPFHP', 'Boston Private Financial Holdings, Inc.', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'JE', 'Just Energy Group, Inc.', 'Public Utilities');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'PRGO', 'Perrigo Company', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'ESES', 'Eco-Stim Energy Solutions, Inc.', 'Energy');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'SXT', 'Sensient Technologies Corporation', 'Basic Industries');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'EFF', 'Eaton vance Floating-Rate Income Plus Fund', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'JOF', 'Japan Smaller Capitalization Fund Inc', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'WCST', 'Wecast Network, Inc.', 'Consumer Services');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'PPX', 'PPL Capital Funding, Inc.', 'Public Utilities');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'KMPR', 'Kemper Corporation', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'LBF', 'Scudder Global High Income Fund, Inc.', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'IBCP', 'Independent Bank Corporation', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'FICO', 'Fair Isaac Corporation', 'Miscellaneous');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'ACHN', 'Achillion Pharmaceuticals, Inc.', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'TGTX', 'TG Therapeutics, Inc.', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'RPXC', 'RPX Corporation', 'Miscellaneous');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'AGX', 'Argan, Inc.', 'Basic Industries');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'EFR', 'Eaton Vance Senior Floating-Rate Fund', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'BNJ', 'BlackRock New Jersey Municipal Income Trust', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'PBSK', 'Poage Bankshares, Inc.', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'VTRB', 'Ventas Realty, Limited Partnership // Ventas Capital Corporati', 'Consumer Services');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'AGRX', 'Agile Therapeutics, Inc.', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'VNCE', 'Vince Holding Corp.', 'Consumer Services');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'WEYS', 'Weyco Group, Inc.', 'Consumer Non-Durables');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'PBT', 'Permian Basin Royalty Trust', 'Energy');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'OXBRW', 'Oxbridge Re Holdings Limited', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'PSB', 'PS Business Parks, Inc.', 'Consumer Services');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'SCM', 'Stellus Capital Investment Corporation', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'NTG', 'Tortoise MLP Fund, Inc.', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'CERC', 'Cerecor Inc.', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'ALL^F', 'Allstate Corporation (The)', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'WFBI', 'WashingtonFirst Bankshares Inc', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'GTIM', 'Good Times Restaurants Inc.', 'Consumer Services');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'BMA', 'Macro Bank Inc.', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'JMM', 'Nuveen Multi-Market Income Fund', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'CVEO', 'Civeo Corporation', 'Consumer Services');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'ROL', 'Rollins, Inc.', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'RPAI', 'Retail Properties of America, Inc.', 'Consumer Services');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'AMH', 'American Homes 4 Rent', 'Consumer Services');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'KDMN', 'Kadmon Holdings, Inc.', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'DXPS', 'WisdomTree United Kingdom Hedged Equity Fund', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'BRX', 'Brixmor Property Group Inc.', 'Consumer Services');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'ARA', 'American Renal Associates Holdings, Inc', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'TLGT', 'Teligent, Inc.', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'INSI', 'Insight Select Income Fund', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'SFE', 'Safeguard Scientifics, Inc.', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'CUBE', 'CubeSmart', 'Consumer Services');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'TWN', 'Taiwan Fund, Inc. (The)', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'FWP', 'Forward Pharma A/S', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'SYT', 'Syngenta AG', 'Basic Industries');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'STBZ', 'State Bank Financial Corporation.', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'CDL', 'VictoryShares US Large Cap High Div Volatility Wtd ETF', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'OHAI', 'OHA Investment Corporation', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'ASYS', 'Amtech Systems, Inc.', 'Technology');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'RXIIW', 'RXi Pharmaceuticals Corporation', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'FTEK', 'Fuel Tech, Inc.', 'Capital Goods');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'MP^D', 'Mississippi Power Company', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'PRE^F', 'PartnerRe Ltd.', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'ELVT', 'Elevate Credit, Inc.', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'MUH', 'Blackrock MuniHoldings Fund II, Inc.', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'CAPR', 'Capricor Therapeutics, Inc.', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'WPRT', 'Westport Fuel Systems Inc', 'Energy');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'OFG^B', 'OFG Bancorp', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'EQFN', 'Equitable Financial Corp.', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'SYPR', 'Sypris Solutions, Inc.', 'Capital Goods');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'DGLT', 'Digiliti Money Group, Inc.', 'Technology');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'BNS', 'Bank of Nova Scotia (The)', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'AAXN', 'Axon Enterprise, Inc.', 'Capital Goods');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'LNDC', 'Landec Corporation', 'Basic Industries');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'CNC', 'Centene Corporation', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'SHLO', 'Shiloh Industries, Inc.', 'Capital Goods');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'LENS', 'Presbia PLC', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'APOG', 'Apogee Enterprises, Inc.', 'Capital Goods');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'TESO', 'Tesco Corporation', 'Energy');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'LFUS', 'Littelfuse, Inc.', 'Consumer Durables');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'PGEM', 'Ply Gem Holdings, Inc.', 'Basic Industries');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'BLPH', 'Bellerophon Therapeutics, Inc.', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'SPWR', 'SunPower Corporation', 'Technology');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'NEP', 'NextEra Energy Partners, LP', 'Public Utilities');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'GPAC', 'Global Partner Acquisition Corp.', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'DHG', 'DWS High Income Opportunities Fund, Inc.', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'AWF', 'Alliance World Dollar Government Fund II', 'n/a');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'MPLX', 'MPLX LP', 'Energy');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'XBIO', 'Xenetic Biosciences, Inc.', 'Health Care');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'TTD', 'The Trade Desk, Inc.', 'Technology');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'RYAAY', 'Ryanair Holdings plc', 'Transportation');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'USCR', 'U S Concrete, Inc.', 'Capital Goods');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NASDAQ', 'ANDA', 'Andina Acquisition Corp. II', 'Finance');
insert into stock (stock_market, stock_symbol, stock_name, stock_sector) values ('NYSE', 'FIX', 'Comfort Systems USA, Inc.', 'Capital Goods');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into portfolio SELECT users.userid, stock.stock_symbol, stock.stock_name, INT4(random()*1000+0.5) FROM users, stock order by random() limit 1000;
