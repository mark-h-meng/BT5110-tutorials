/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
I want to create a database to capture a company’s shipment data. Specifically, I am interested to understand from which site to which customer the company is shipping how many pallets on which date. With this information, I will be able to prepare a centre-of-gravity study and analyse improvement opportunities in the company’s supply chain network.
The database consists of 3 tables: site, customer, and shipment. The site and customer tables contain address details such as name, street address, city, postal code, country, as well as unique site and customer IDs. The shipment table contains transactional shipment information such as number of pallets, dispatch date, and the transport provider’s unique shipment ID.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

DROP TABLE IF EXISTS shipment;
DROP TABLE IF EXISTS site;
DROP TABLE IF EXISTS customer;

CREATE TABLE IF NOT EXISTS site (
name VARCHAR(64) NOT NULL,
street_address VARCHAR(64) NOT NULL,
city VARCHAR(64) NOT NULL,
postal_code VARCHAR(64) NOT NULL,
country_code CHAR(2) NOT NULL,
site_id CHAR(4) PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS customer (
name VARCHAR(64) NOT NULL,
street_address VARCHAR(64) NOT NULL,
city VARCHAR(64) NOT NULL,
postal_code VARCHAR(64) NOT NULL,
country_code CHAR(2) NOT NULL,
customer_id CHAR(4) PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS shipment (
site_id CHAR(4) REFERENCES site(site_id) ON DELETE CASCADE DEFERRABLE,
customer_id CHAR(8) REFERENCES customer(customer_id) ON DELETE CASCADE DEFERRABLE,
number_of_pallets INT CHECK(number_of_pallets>0),
dispatch_date DATE NOT NULL,
shipment_id VARCHAR(16) PRIMARY KEY
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries BR', '0043 Schlimgen Road','Guaçuí','29560-000','BR','s1');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries CR', '696 Derek Hill','Ángeles','40504','CR','s2');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries CZ', '7 Heath Road','Boršice','687 10','CZ','s3');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries MX', '44591 Springview Court','Santa Clara','50090','MX','s4');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries NL', '3537 1st Parkway','Leiden','2304','NL','s5');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries JP', '90037 Oriole Crossing','Shimokizukuri','802-0015','JP','s6');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '3 Commercial Hill','Masipi West','3328','PH','s7');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries NO', '20624 Schurz Place','Oslo','512','NO','s8');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries HR', '86171 Coleman Parkway','Zagreb','10020','HR','s9');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PT', '821 Eastlawn Alley','Baraçais','2540-557','PT','s10');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries BD', '4 Iowa Road','Pirojpur','1811','BD','s11');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries BR', '22207 Susan Crossing','Picos','64600-000','BR','s12');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries TH', '9 Memorial Lane','Kaeng Khro','36150','TH','s13');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries FR', '375 Golf Course Way','Labège','31673 CEDEX','FR','s14');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries MX', '2626 Crowley Court','San Martin','56199','MX','s15');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '16 Schiller Parkway','Limbalod','9407','PH','s16');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries AR', '5 Nancy Plaza','Coronda','2240','AR','s17');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries IE', '9657 Independence Center','Whitegate','D15','IE','s18');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries FR', '9356 Dovetail Junction','Alençon','61004 CEDEX','FR','s19');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries JP', '4 Carpenter Circle','Yoshii','952-1203','JP','s20');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries BR', '3742 Corry Lane','Governador Valadares','35000-000','BR','s21');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '5644 Golf Park','Camindangan','7015','PH','s22');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PT', '9969 Merchant Trail','Amadora','2610-006','PT','s23');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries ZA', '9 Oriole Center','Ulundi','3838','ZA','s24');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries AR', '370 Acker Alley','Comodoro Rivadavia','9000','AR','s25');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries RU', '847 Bunker Hill Avenue','Priyutovo','452189','RU','s26');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PL', '49821 Cascade Trail','Jejkowice','44-290','PL','s27');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries FR', '2689 8th Park','Décines-Charpieu','69154 CEDEX','FR','s28');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries BR', '18220 Logan Point','Goiás','76600-000','BR','s29');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries DE', '79 Bellgrove Crossing','Dresden','1462','DE','s30');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries SE', '47 Hansons Junction','Trollhättan','461 58','SE','s31');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries BR', '7 Sage Junction','Arroio do Meio','95940-000','BR','s32');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries SE', '4350 Messerschmidt Drive','Stockholm','102 52','SE','s33');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries BR', '35 Lighthouse Bay Crossing','Igarapé Miri','46825-000','BR','s34');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PT', '8 Little Fleur Center','Boavista','5030-304','PT','s35');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PT', '48 Heath Hill','Sarrazola','3800-596','PT','s36');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '986 Mitchell Street','Toledo','6038','PH','s37');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries RU', '264 Prairie Rose Circle','Kamenka','241011','RU','s38');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries MD', '5 Schurz Trail','Cimişlia','MD-4112','MD','s39');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PT', '70 Straubel Hill','Telheira','4650-669','PT','s40');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries MY', '47 Warner Crossing','Melaka','75586','MY','s41');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries HR', '9 Center Alley','Negoslavci','32239','HR','s42');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PT', '8370 Barnett Point','Casal Novo','2440-024','PT','s43');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries MX', '464 Farragut Circle','Revolucion Verde','87445','MX','s44');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PL', '6503 Reinke Way','Wisznice','21-580','PL','s45');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries SI', '7140 Bunting Lane','Cankova','9261','SI','s46');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '34 Oriole Parkway','Dalumangcob','6022','PH','s47');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries JP', '09 Leroy Drive','Ōmachi','399-8604','JP','s48');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PL', '27 High Crossing Terrace','Osięciny','88-220','PL','s49');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries BG', '89129 Vera Circle','Dimovo','3759','BG','s50');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '8 Donald Road','Guijalo','7113','PH','s51');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries US', '73234 Glacier Hill Center','New Hyde Park','11044','US','s52');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '23 School Circle','Macayug','5417','PH','s53');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PT', '8 Burrows Circle','Veiga','4650-226','PT','s54');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PT', '920 Commercial Pass','Boavista','4690-696','PT','s55');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries SE', '561 Sycamore Hill','Linköping','580 07','SE','s56');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PL', '4 Eliot Pass','Jasienica Rosielna','36-220','PL','s57');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries HR', '73488 Lerdahl Way','Karlobag','53288','HR','s58');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries RU', '7 Golf Street','Tygda','676150','RU','s59');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PL', '2417 Kenwood Hill','Jednorożec','06-323','PL','s60');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries BR', '49 Kings Center','Mariana','35420-000','BR','s61');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PT', '28437 Calypso Lane','Lemenhe','4775-404','PT','s62');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '9404 Grasskamp Place','Pang','4103','PH','s63');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries RU', '9088 Schlimgen Parkway','Adygeysk','385202','RU','s64');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries DK', '29385 Goodland Point','Frederiksberg','1865','DK','s65');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '0 Ramsey Parkway','Tampakan','9507','PH','s66');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries ZA', '54332 Erie Street','Koppies','9540','ZA','s67');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries CA', '5 Sunbrook Plaza','Bells Corners','K2R','CA','s68');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries ZA', '38402 Kensington Junction','Emnambithi-Ladysmith','3384','ZA','s69');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries LU', '088 Talmadge Hill','Boevange-sur-Attert','L-8711','LU','s70');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries SE', '1061 Hagan Point','Strömstad','452 24','SE','s71');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '94157 Mcbride Crossing','Gatbo','4419','PH','s72');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PL', '15889 Heffernan Point','Góra Kalwaria','05-530','PL','s73');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries CZ', '3839 Hagan Park','Teplice','415 01','CZ','s74');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries TH', '5 Summit Center','Uthai Thani','81140','TH','s75');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '2 Hanover Junction','Tandayag','6203','PH','s76');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries SE', '976 Service Crossing','Ljungby','341 70','SE','s77');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries NC', '78327 Buell Circle','Pouébo','98824','NC','s78');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries SE', '72 Fairfield Court','Bollnäs','821 41','SE','s79');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries BG', '405 Tennessee Alley','Sitovo','7662','BG','s80');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries DE', '9829 Schlimgen Pass','Hamburg Bramfeld','22179','DE','s81');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '7477 Kinsman Drive','Arcangel','5602','PH','s82');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PK', '4299 Lillian Junction','Garhi Khairo','79050','PK','s83');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries FI', '039 Utah Hill','Enonkoski','58175','FI','s84');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries FI', '00898 Bay Drive','Hartola','19601','FI','s85');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries MY', '013 Shoshone Pass','Kota Kinabalu','88512','MY','s86');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries BR', '44523 Del Sol Alley','Barras','64100-000','BR','s87');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '073 Hoepker Alley','Tanay','1980','PH','s88');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries HR', '9 Morrow Street','Tisno','22240','HR','s89');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries SE', '9 Hoard Parkway','Saltsjö-Boo','132 30','SE','s90');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '469 Waubesa Parkway','Tagoloan','9222','PH','s91');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries FI', '9506 Northland Place','Joutsa','19651','FI','s92');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '149 Hanson Hill','Rizal','7104','PH','s93');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries SE', '9 Lawn Plaza','Timrå','861 83','SE','s94');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries FR', '7 Dayton Avenue','Quimper','29102 CEDEX','FR','s95');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PT', '57987 8th Park','Breia','4950-284','PT','s96');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PH', '4783 Moose Hill','Bakung','7505','PH','s97');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries US', '3 Pearson Drive','New Orleans','70116','US','s98');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries JP', '5800 Moose Court','Togitsu','859-0416','JP','s99');
INSERT INTO site (name, street_address, city, postal_code, country_code, site_id) VALUES ('Alex Industries PL', '02 Londonderry Hill','Rudna Mała','36-062','PL','s100');

INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Meezzy', '29 Morningstar Pass','Norrtälje','761 51','SE','c1');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Thoughtstorm', '18 Buell Road','Brandsen','1981','AR','c2');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Gevee', '6063 Alpine Center','Tsushima','979-1757','JP','c3');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Centimia', '54 Packers Plaza','Alvito','7920-015','PT','c4');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Kazio', '5254 Dawn Court','Içara','88820-000','BR','c5');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Skivee', '2 David Lane','Timmins','P4P','CA','c6');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Quaxo', '42065 Birchwood Center','Rączna','32-060','PL','c7');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('DabZ', '85 Melby Plaza','Odintsovo','143082','RU','c8');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Tagchat', '83726 Meadow Vale Drive','Biały Bór','78-425','PL','c9');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Feedspan', '1033 Lunder Junction','Nong Bun Nak','42130','TH','c10');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Centidel', '7 Chinook Crossing','Mambulo','4407','PH','c11');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Yabox', '93 Elgar Drive','Proletarskiy','601465','RU','c12');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Yambee', '841 Starling Center','Lansing','48930','US','c13');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Tekfly', '09 3rd Place','Berlin','10179','DE','c14');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Dabvine', '3054 Butternut Parkway','Buckland','CT16','GB','c15');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Kwimbee', '90492 Acker Pass','Guarujá','11400-000','BR','c16');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Shuffletag', '84 Longview Avenue','Wisła','43-460','PL','c17');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Dabvine', '30 Fairfield Street','Palpalá','4612','AR','c18');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Yodo', '60642 Beilfuss Trail','La Romana','11518','DO','c19');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Chatterbridge', '3457 Florence Point','Tembisa','1693','ZA','c20');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Riffwire', '4427 Merrick Road','Poggio di Chiesanuova','47894','SM','c21');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Wikivu', '42 Union Place','Åkersberga','184 23','SE','c22');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Thoughtblab', '0 Morrow Center','Voiron','38504 CEDEX','FR','c23');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Tambee', '58 Reinke Way','Whittier','90610','US','c24');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Buzzdog', '356 Meadow Ridge Plaza','Villanueva','130537','CO','c25');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Feednation', '56950 Talmadge Way','Hyrynsalmi','89401','FI','c26');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Skyvu', '30 Village Crossing','Montes','2460-825','PT','c27');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Trilia', '260 Colorado Court','Cergy-Pontoise','95611 CEDEX','FR','c28');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Quinu', '909 Northridge Parkway','Winnipeg','R3L','CA','c29');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Zoombox', '05 Daystar Street','Breda','4819','NL','c30');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Eazzy', '6 Northland Trail','Moulins','03006 CEDEX','FR','c31');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Gabspot', '7 Dennis Circle','Göteborg','415 22','SE','c32');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Photobug', '6996 Anzinger Way','Raciąż','09-140','PL','c33');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Meevee', '55 Wayridge Park','Pasrūr','51480','PK','c34');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Centidel', '761 Texas Way','Kerkrade','6464','NL','c35');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Bubblemix', '86 Steensland Alley','Selnica','49246','HR','c36');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Oozz', '0246 Blackbird Lane','Kladno','539 01','CZ','c37');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Jatri', '7489 Dayton Avenue','Loimaan Kunta','32560','FI','c38');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Dablist', '746 Washington Trail','Negotino','1440','MK','c39');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Skyble', '67 Atwood Place','Västra Frölunda','426 52','SE','c40');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Ntag', '5 Melrose Street','Itum-Kali','366404','RU','c41');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Oloo', '480 Sherman Street','Motomiya','520-0804','JP','c42');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Tagcat', '76277 Evergreen Park','Granville','50404 CEDEX','FR','c43');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Voomm', '16 Northfield Park','Perštejn','431 63','CZ','c44');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Minyx', '57144 Grover Street','El Cantón de San Pablo','55448','CO','c45');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Realbridge', '6277 Blue Bill Park Point','Norrköping','603 52','SE','c46');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Thoughtstorm', '524 Elka Alley','København','1349','DK','c47');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Bluejam', '15144 Randy Center','Capilla del Monte','5184','AR','c48');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Devpoint', '90225 Esker Avenue','Lajedo','55385-000','BR','c49');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Divanoodle', '280 Morrow Pass','Granja','4690-711','PT','c50');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Yadel', '947 Twin Pines Junction','Masoli','6525','PH','c51');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Kimia', '01921 Golden Leaf Center','Minuwangoda','11550','LK','c52');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Meezzy', '4 Armistice Parkway','Tidaholm','522 24','SE','c53');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Realfire', '750 Mifflin Parkway','Serrinha','4620-400','PT','c54');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('InnoZ', '9 Alpine Park','Barcelona','8075','ES','c55');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Twimbo', '52431 Eagan Park','Gislaved','332 24','SE','c56');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Jayo', '005 Monument Pass','Nantes','44019 CEDEX 1','FR','c57');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Jabbertype', '2 Pond Place','Borek Wielkopolski','63-810','PL','c58');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Browsebug', '226 Goodland Plaza','Palmar de Varela','83087','CO','c59');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Vinte', '872 Wayridge Point','Armenia','5401','PH','c60');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Roomm', '0 Summerview Plaza','Jardín','56057','CO','c61');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Thoughtstorm', '21779 Pankratz Place','Ifanes','5210-105','PT','c62');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Dabjam', '72315 Anthes Alley','Miguel Calmon','44720-000','BR','c63');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Devshare', '54 Graceland Court','Surup','5504','PH','c64');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Brightdog', '949 Warner Street','Labney','2437','PH','c65');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Twinder', '099 Messerschmidt Place','Camachile','2103','PH','c66');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Skyndu', '170 Marquette Drive','Komsomolsk-on-Amur','681008','RU','c67');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Flashdog', '89865 Kipling Street','Newbiggin','NE46','GB','c68');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Skidoo', '53158 Fieldstone Plaza','Ishikawa','960-1476','JP','c69');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Dabtype', '73 Lerdahl Circle','Kranjska Gora','4280','SI','c70');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Mycat', '03596 Waubesa Junction','Pisarzowice','49-314','PL','c71');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Dynabox', '13550 Forest Street','Letovice','679 61','CZ','c72');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Jabbertype', '9 Warbler Place','Zimovniki','347460','RU','c73');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Thoughtsphere', '96 Rowland Trail','Kingston','E5S','CA','c74');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Twitterbridge', '75729 Westport Road','Ballitoville','4430','ZA','c75');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Wordtune', '440 Merchant Trail','Ibaraki','649-1211','JP','c76');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Gabspot', '00 Nancy Circle','Yacimiento Río Turbio','1649','AR','c77');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Edgewire', '0 Schiller Avenue','Hat Yai','90110','TH','c78');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Zoozzy', '2 Kenwood Lane','Oslo','487','NO','c79');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Eare', '04037 Melody Court','Kitsuki','873-0001','JP','c80');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Twimbo', '58 Declaration Street','Söderköping','614 31','SE','c81');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Eayo', '4 Ilene Junction','Lyon','69239 CEDEX 02','FR','c82');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Chatterbridge', '5 Maywood Center','Kuragaki-kosugi','939-2759','JP','c83');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Fivespan', '46692 Schiller Drive','Burgeo','N9A','CA','c84');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Quatz', '9 Melby Place','Borås','504 37','SE','c85');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Oozz', '41639 Tennyson Center','Šardice','696 13','CZ','c86');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Thoughtstorm', '2618 Stang Trail','Macapá','68900-000','BR','c87');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Skinix', '3351 Thompson Place','Summerside','C1N','CA','c88');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Roombo', '78012 Jay Center','Sydney','1171','AU','c89');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Oyope', '380 Schlimgen Place','Sąspów','32-082','PL','c90');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Feedbug', '26 Portage Hill','Oleszyce','37-630','PL','c91');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Tagpad', '234 Lake View Pass','Gus’-Khrustal’nyy','601508','RU','c92');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Vidoo', '06 Loftsgordon Parkway','Cookshire-Eaton','M4C','CA','c93');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Dazzlesphere', '59 Corry Way','Melaka','75503','MY','c94');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Demimbu', '24738 Basil Street','Järna','153 31','SE','c95');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Zoomdog', '21365 Eliot Alley','Palkovice','739 41','CZ','c96');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Skaboo', '088 Cottonwood Crossing','San Fernando de Monte Cristi','11509','DO','c97');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Vinder', '7882 Hudson Center','Pinhal General','2865-193','PT','c98');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Kwideo', '895 Farragut Street','Göteborg','411 00','SE','c99');
INSERT INTO customer (name, street_address, city, postal_code, country_code, customer_id) VALUES ('Yombu', '71 Schiller Lane','Goianésia','76380-000','BR','c100');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO shipment (site_id, customer_id, number_of_pallets, dispatch_date, shipment_id)
SELECT 
's' || FLOOR(RANDOM()*(100-0)+1),
'c' || FLOOR(RANDOM()*(100-0)+1),
FLOOR(RANDOM()*(100-1)+1),
TIMESTAMP '2020-01-01' + RANDOM() * (TIMESTAMP '2020-12-31' - TIMESTAMP '2020-01-01'),
't' || generate_series(1,1000);
