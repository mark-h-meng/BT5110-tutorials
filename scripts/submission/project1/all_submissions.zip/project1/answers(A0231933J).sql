/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*

In university A, the students are taught by several professors. Three tables are created for this many-to-many
relationship between students and professors. These three tables include table 'student', table 'professor' 
and table 'taughtby'. The table 'student' contains the information about 100 students' first name, last name 
and email and the students' email is the unique value. The table 'professor' contains 100 professors' id, 
first_name, last_name and gender and the professors' id is the unique value. The table 'taughtby' connects the
above two tables, which includes students' email from the table 'student' and professor id from the table 
'professor'. It contains the many-to-many relationship between the students and professors. This table has 
1000 relationships between the students and professors, which are random selected from the all the possible 
relationships. PostgreSQL is written for the following questions.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE student (
first_name VARCHAR(64) NOT NULL,
last_name VARCHAR(64) NOT NULL,
email VARCHAR(64) PRIMARY KEY
);

CREATE TABLE professor (
professor_id VARCHAR(64) PRIMARY KEY,
first_name VARCHAR(64) NOT NULL,
last_name VARCHAR(64) NOT NULL,
gender VARCHAR(64) NOT NULL
);

CREATE TABLE taughtby (
student_email VARCHAR(64) NOT NULL,
professor_id VARCHAR(64) NOT NULL,
foreign key(student_email) references student(email),
foreign key(professor_id) references professor(professor_id)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into student (first_name, last_name, email) values ('Robbie', 'Ratnage', 'rratnage0@sciencedirect.com');
insert into student (first_name, last_name, email) values ('Nana', 'Scholl', 'nscholl1@ning.com');
insert into student (first_name, last_name, email) values ('Cheryl', 'Izacenko', 'cizacenko2@youtu.be');
insert into student (first_name, last_name, email) values ('Engelbert', 'Gettone', 'egettone3@biblegateway.com');
insert into student (first_name, last_name, email) values ('Thane', 'Infante', 'tinfante4@google.it');
insert into student (first_name, last_name, email) values ('Donni', 'Carnalan', 'dcarnalan5@washington.edu');
insert into student (first_name, last_name, email) values ('Gayel', 'Bjorkan', 'gbjorkan6@odnoklassniki.ru');
insert into student (first_name, last_name, email) values ('Shannen', 'Aked', 'saked7@last.fm');
insert into student (first_name, last_name, email) values ('Maible', 'Davers', 'mdavers8@amazon.co.jp');
insert into student (first_name, last_name, email) values ('Hurley', 'Biford', 'hbiford9@boston.com');
insert into student (first_name, last_name, email) values ('Sharline', 'Swynfen', 'sswynfena@lycos.com');
insert into student (first_name, last_name, email) values ('Carree', 'Kieff', 'ckieffb@scientificamerican.com');
insert into student (first_name, last_name, email) values ('Bertrando', 'De Ambrosis', 'bdeambrosisc@hubpages.com');
insert into student (first_name, last_name, email) values ('Georgi', 'Tallis', 'gtallisd@joomla.org');
insert into student (first_name, last_name, email) values ('Alvina', 'Rosedale', 'arosedalee@csmonitor.com');
insert into student (first_name, last_name, email) values ('Raye', 'Woliter', 'rwoliterf@artisteer.com');
insert into student (first_name, last_name, email) values ('Bailey', 'Althrope', 'balthropeg@cnbc.com');
insert into student (first_name, last_name, email) values ('Marcela', 'Waples', 'mwaplesh@accuweather.com');
insert into student (first_name, last_name, email) values ('Milicent', 'Laws', 'mlawsi@marriott.com');
insert into student (first_name, last_name, email) values ('Prudi', 'Patridge', 'ppatridgej@godaddy.com');
insert into student (first_name, last_name, email) values ('Reg', 'Litzmann', 'rlitzmannk@phpbb.com');
insert into student (first_name, last_name, email) values ('Irv', 'Broddle', 'ibroddlel@feedburner.com');
insert into student (first_name, last_name, email) values ('Calypso', 'Jillard', 'cjillardm@myspace.com');
insert into student (first_name, last_name, email) values ('Andrew', 'Stollenberg', 'astollenbergn@surveymonkey.com');
insert into student (first_name, last_name, email) values ('Kathlin', 'Baroux', 'kbarouxo@chicagotribune.com');
insert into student (first_name, last_name, email) values ('Clayson', 'Betser', 'cbetserp@utexas.edu');
insert into student (first_name, last_name, email) values ('Alfonse', 'Lighterness', 'alighternessq@salon.com');
insert into student (first_name, last_name, email) values ('Bari', 'Duchesne', 'bduchesner@google.co.jp');
insert into student (first_name, last_name, email) values ('Oliy', 'Orgee', 'oorgees@seattletimes.com');
insert into student (first_name, last_name, email) values ('Ric', 'Puttnam', 'rputtnamt@sitemeter.com');
insert into student (first_name, last_name, email) values ('Teodoro', 'Brisset', 'tbrissetu@chicagotribune.com');
insert into student (first_name, last_name, email) values ('Ermina', 'Surgener', 'esurgenerv@exblog.jp');
insert into student (first_name, last_name, email) values ('Margaretta', 'Blackster', 'mblacksterw@pbs.org');
insert into student (first_name, last_name, email) values ('Tonya', 'Tallowin', 'ttallowinx@netlog.com');
insert into student (first_name, last_name, email) values ('Mimi', 'Champkin', 'mchampkiny@mlb.com');
insert into student (first_name, last_name, email) values ('Enos', 'Lestor', 'elestorz@a8.net');
insert into student (first_name, last_name, email) values ('Vitia', 'Morrel', 'vmorrel10@baidu.com');
insert into student (first_name, last_name, email) values ('Fedora', 'Ickovitz', 'fickovitz11@mozilla.com');
insert into student (first_name, last_name, email) values ('Paulita', 'Jakubovics', 'pjakubovics12@meetup.com');
insert into student (first_name, last_name, email) values ('Sybilla', 'Kassel', 'skassel13@marriott.com');
insert into student (first_name, last_name, email) values ('Christina', 'Mulliss', 'cmulliss14@fema.gov');
insert into student (first_name, last_name, email) values ('Bekki', 'Pala', 'bpala15@paypal.com');
insert into student (first_name, last_name, email) values ('Modesta', 'Walcher', 'mwalcher16@ocn.ne.jp');
insert into student (first_name, last_name, email) values ('Eolanda', 'Fearon', 'efearon17@homestead.com');
insert into student (first_name, last_name, email) values ('Celestia', 'Measham', 'cmeasham18@blog.com');
insert into student (first_name, last_name, email) values ('Pascal', 'Sunter', 'psunter19@alexa.com');
insert into student (first_name, last_name, email) values ('Winn', 'Hatchard', 'whatchard1a@wikia.com');
insert into student (first_name, last_name, email) values ('Chilton', 'McIlenna', 'cmcilenna1b@livejournal.com');
insert into student (first_name, last_name, email) values ('Eachelle', 'Coombe', 'ecoombe1c@ted.com');
insert into student (first_name, last_name, email) values ('Dallas', 'Pryor', 'dpryor1d@usgs.gov');
insert into student (first_name, last_name, email) values ('Heywood', 'Maddocks', 'hmaddocks1e@unblog.fr');
insert into student (first_name, last_name, email) values ('Athena', 'Melin', 'amelin1f@rakuten.co.jp');
insert into student (first_name, last_name, email) values ('Paulie', 'Brailey', 'pbrailey1g@vimeo.com');
insert into student (first_name, last_name, email) values ('Natalya', 'Rummery', 'nrummery1h@issuu.com');
insert into student (first_name, last_name, email) values ('Karyn', 'Dowthwaite', 'kdowthwaite1i@ihg.com');
insert into student (first_name, last_name, email) values ('Dennis', 'Larciere', 'dlarciere1j@cbslocal.com');
insert into student (first_name, last_name, email) values ('Kristine', 'Quiney', 'kquiney1k@hud.gov');
insert into student (first_name, last_name, email) values ('Maximilianus', 'Purbrick', 'mpurbrick1l@google.it');
insert into student (first_name, last_name, email) values ('Kelsey', 'Fellini', 'kfellini1m@jiathis.com');
insert into student (first_name, last_name, email) values ('Heriberto', 'Howell', 'hhowell1n@com.com');
insert into student (first_name, last_name, email) values ('Wilden', 'Coverlyn', 'wcoverlyn1o@hatena.ne.jp');
insert into student (first_name, last_name, email) values ('Juliana', 'Kalderon', 'jkalderon1p@usnews.com');
insert into student (first_name, last_name, email) values ('Stearne', 'Domini', 'sdomini1q@upenn.edu');
insert into student (first_name, last_name, email) values ('Archibold', 'Lappine', 'alappine1r@hc360.com');
insert into student (first_name, last_name, email) values ('Cecelia', 'Briscow', 'cbriscow1s@nydailynews.com');
insert into student (first_name, last_name, email) values ('Bernadette', 'Ritmeyer', 'britmeyer1t@dagondesign.com');
insert into student (first_name, last_name, email) values ('Maridel', 'Pagelsen', 'mpagelsen1u@amazonaws.com');
insert into student (first_name, last_name, email) values ('Corey', 'Kuhnert', 'ckuhnert1v@msn.com');
insert into student (first_name, last_name, email) values ('Vivianne', 'Seawright', 'vseawright1w@list-manage.com');
insert into student (first_name, last_name, email) values ('Delaney', 'Orr', 'dorr1x@chicagotribune.com');
insert into student (first_name, last_name, email) values ('Lorrayne', 'Newis', 'lnewis1y@ox.ac.uk');
insert into student (first_name, last_name, email) values ('Cyrille', 'Mole', 'cmole1z@upenn.edu');
insert into student (first_name, last_name, email) values ('Janetta', 'Galbraith', 'jgalbraith20@amazon.co.uk');
insert into student (first_name, last_name, email) values ('Hyacinthie', 'Thomen', 'hthomen21@bigcartel.com');
insert into student (first_name, last_name, email) values ('Amber', 'Yetton', 'ayetton22@rediff.com');
insert into student (first_name, last_name, email) values ('Shantee', 'Laughlan', 'slaughlan23@google.com.hk');
insert into student (first_name, last_name, email) values ('Babette', 'Franchi', 'bfranchi24@meetup.com');
insert into student (first_name, last_name, email) values ('Raquela', 'Kenwood', 'rkenwood25@storify.com');
insert into student (first_name, last_name, email) values ('Livvy', 'Noorwood', 'lnoorwood26@sbwire.com');
insert into student (first_name, last_name, email) values ('Robbie', 'Licciardello', 'rlicciardello27@independent.co.uk');
insert into student (first_name, last_name, email) values ('Hillary', 'Kalkofen', 'hkalkofen28@boston.com');
insert into student (first_name, last_name, email) values ('Verile', 'Matusiak', 'vmatusiak29@shutterfly.com');
insert into student (first_name, last_name, email) values ('Tory', 'Hubach', 'thubach2a@upenn.edu');
insert into student (first_name, last_name, email) values ('Luca', 'Form', 'lform2b@dion.ne.jp');
insert into student (first_name, last_name, email) values ('Dwight', 'Vassman', 'dvassman2c@wikispaces.com');
insert into student (first_name, last_name, email) values ('Blaine', 'Coburn', 'bcoburn2d@discuz.net');
insert into student (first_name, last_name, email) values ('Miguela', 'Kleszinski', 'mkleszinski2e@cpanel.net');
insert into student (first_name, last_name, email) values ('Rae', 'Sultan', 'rsultan2f@utexas.edu');
insert into student (first_name, last_name, email) values ('Cloe', 'Haucke', 'chaucke2g@webeden.co.uk');
insert into student (first_name, last_name, email) values ('Vitoria', 'Gummow', 'vgummow2h@php.net');
insert into student (first_name, last_name, email) values ('Lexy', 'Mander', 'lmander2i@cyberchimps.com');
insert into student (first_name, last_name, email) values ('Cicily', 'Habbergham', 'chabbergham2j@mlb.com');
insert into student (first_name, last_name, email) values ('Barron', 'Bomb', 'bbomb2k@nasa.gov');
insert into student (first_name, last_name, email) values ('Kelwin', 'Hagland', 'khagland2l@biblegateway.com');
insert into student (first_name, last_name, email) values ('Fidole', 'Very', 'fvery2m@pinterest.com');
insert into student (first_name, last_name, email) values ('Alyse', 'Avrahamoff', 'aavrahamoff2n@1688.com');
insert into student (first_name, last_name, email) values ('Jay', 'Ship', 'jship2o@huffingtonpost.com');
insert into student (first_name, last_name, email) values ('Thomasina', 'Limerick', 'tlimerick2p@1und1.de');
insert into student (first_name, last_name, email) values ('Hale', 'Grieger', 'hgrieger2q@microsoft.com');
insert into student (first_name, last_name, email) values ('Farrell', 'Pirot', 'fpirot2r@flavors.me');

insert into professor (professor_id, first_name, last_name, gender) values (1, 'Meg', 'Snead', 'Female');
insert into professor (professor_id, first_name, last_name, gender) values (2, 'Nickey', 'Dillon', 'Bigender');
insert into professor (professor_id, first_name, last_name, gender) values (3, 'Norene', 'Machon', 'Non-binary');
insert into professor (professor_id, first_name, last_name, gender) values (4, 'Olivier', 'Yielding', 'Genderqueer');
insert into professor (professor_id, first_name, last_name, gender) values (5, 'Carline', 'Scrimshire', 'Non-binary');
insert into professor (professor_id, first_name, last_name, gender) values (6, 'Isobel', 'Fitzackerley', 'Agender');
insert into professor (professor_id, first_name, last_name, gender) values (7, 'Shauna', 'Valentino', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (8, 'Casi', 'Rosenbusch', 'Genderfluid');
insert into professor (professor_id, first_name, last_name, gender) values (9, 'Lyn', 'Fairhead', 'Male');
insert into professor (professor_id, first_name, last_name, gender) values (10, 'Griselda', 'Sussex', 'Non-binary');
insert into professor (professor_id, first_name, last_name, gender) values (11, 'Haze', 'Coyett', 'Agender');
insert into professor (professor_id, first_name, last_name, gender) values (12, 'Wenonah', 'Dorricott', 'Female');
insert into professor (professor_id, first_name, last_name, gender) values (13, 'Scott', 'Larimer', 'Agender');
insert into professor (professor_id, first_name, last_name, gender) values (14, 'Carlin', 'Haggart', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (15, 'Harrietta', 'Skirling', 'Agender');
insert into professor (professor_id, first_name, last_name, gender) values (16, 'Shena', 'O''Hederscoll', 'Genderqueer');
insert into professor (professor_id, first_name, last_name, gender) values (17, 'Leonanie', 'Ritson', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (18, 'Brena', 'Sandyford', 'Female');
insert into professor (professor_id, first_name, last_name, gender) values (19, 'Lexine', 'Alejandre', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (20, 'Georgia', 'Passey', 'Female');
insert into professor (professor_id, first_name, last_name, gender) values (21, 'Hannis', 'April', 'Genderfluid');
insert into professor (professor_id, first_name, last_name, gender) values (22, 'Giacopo', 'Shortland', 'Bigender');
insert into professor (professor_id, first_name, last_name, gender) values (23, 'Nero', 'Dyott', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (24, 'Eudora', 'Brayn', 'Genderqueer');
insert into professor (professor_id, first_name, last_name, gender) values (25, 'Carmelina', 'D''Errico', 'Bigender');
insert into professor (professor_id, first_name, last_name, gender) values (26, 'Harper', 'Ciciura', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (27, 'Nadia', 'Sanz', 'Female');
insert into professor (professor_id, first_name, last_name, gender) values (28, 'Jany', 'Simononsky', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (29, 'Vania', 'Aasaf', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (30, 'Ines', 'Pencost', 'Female');
insert into professor (professor_id, first_name, last_name, gender) values (31, 'Wendye', 'Bever', 'Bigender');
insert into professor (professor_id, first_name, last_name, gender) values (32, 'Arabele', 'Ownsworth', 'Male');
insert into professor (professor_id, first_name, last_name, gender) values (33, 'Tamra', 'Maass', 'Agender');
insert into professor (professor_id, first_name, last_name, gender) values (34, 'Skylar', 'Arndtsen', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (35, 'Shay', 'Patrie', 'Bigender');
insert into professor (professor_id, first_name, last_name, gender) values (36, 'Belicia', 'Gregoletti', 'Genderqueer');
insert into professor (professor_id, first_name, last_name, gender) values (37, 'Steffie', 'Maroney', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (38, 'Ichabod', 'Tubb', 'Non-binary');
insert into professor (professor_id, first_name, last_name, gender) values (39, 'Eldridge', 'Lovekin', 'Genderfluid');
insert into professor (professor_id, first_name, last_name, gender) values (40, 'Bobbe', 'Keinrat', 'Male');
insert into professor (professor_id, first_name, last_name, gender) values (41, 'Mary', 'Millin', 'Genderqueer');
insert into professor (professor_id, first_name, last_name, gender) values (42, 'Collete', 'Ackerley', 'Agender');
insert into professor (professor_id, first_name, last_name, gender) values (43, 'Bucky', 'Kemery', 'Non-binary');
insert into professor (professor_id, first_name, last_name, gender) values (44, 'Ange', 'Enoch', 'Non-binary');
insert into professor (professor_id, first_name, last_name, gender) values (45, 'Bernarr', 'Fearnyough', 'Genderqueer');
insert into professor (professor_id, first_name, last_name, gender) values (46, 'Claudette', 'Gunthorp', 'Bigender');
insert into professor (professor_id, first_name, last_name, gender) values (47, 'Biron', 'McFayden', 'Bigender');
insert into professor (professor_id, first_name, last_name, gender) values (48, 'Rawley', 'Agass', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (49, 'Johnathan', 'Chasle', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (50, 'Jenica', 'Wathan', 'Agender');
insert into professor (professor_id, first_name, last_name, gender) values (51, 'Sheridan', 'McGougan', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (52, 'Marylin', 'Cowp', 'Female');
insert into professor (professor_id, first_name, last_name, gender) values (53, 'Shurwood', 'Beinke', 'Genderfluid');
insert into professor (professor_id, first_name, last_name, gender) values (54, 'Siobhan', 'Landsborough', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (55, 'Gloria', 'McColgan', 'Female');
insert into professor (professor_id, first_name, last_name, gender) values (56, 'Hastie', 'Lackham', 'Genderfluid');
insert into professor (professor_id, first_name, last_name, gender) values (57, 'Iris', 'Norsworthy', 'Bigender');
insert into professor (professor_id, first_name, last_name, gender) values (58, 'Gilbertina', 'Pierro', 'Female');
insert into professor (professor_id, first_name, last_name, gender) values (59, 'Filberto', 'Pinchon', 'Genderfluid');
insert into professor (professor_id, first_name, last_name, gender) values (60, 'Arthur', 'Thain', 'Genderfluid');
insert into professor (professor_id, first_name, last_name, gender) values (61, 'Katleen', 'Dellenty', 'Non-binary');
insert into professor (professor_id, first_name, last_name, gender) values (62, 'Sherwin', 'Mannakee', 'Female');
insert into professor (professor_id, first_name, last_name, gender) values (63, 'Royall', 'Spivie', 'Genderqueer');
insert into professor (professor_id, first_name, last_name, gender) values (64, 'Arabele', 'Blondelle', 'Bigender');
insert into professor (professor_id, first_name, last_name, gender) values (65, 'Alika', 'Archdeckne', 'Genderqueer');
insert into professor (professor_id, first_name, last_name, gender) values (66, 'Fitz', 'Scanterbury', 'Agender');
insert into professor (professor_id, first_name, last_name, gender) values (67, 'Warde', 'Canty', 'Female');
insert into professor (professor_id, first_name, last_name, gender) values (68, 'Monte', 'Castro', 'Bigender');
insert into professor (professor_id, first_name, last_name, gender) values (69, 'Lorne', 'Willas', 'Non-binary');
insert into professor (professor_id, first_name, last_name, gender) values (70, 'Merry', 'Cockell', 'Non-binary');
insert into professor (professor_id, first_name, last_name, gender) values (71, 'Elvera', 'Rooms', 'Genderqueer');
insert into professor (professor_id, first_name, last_name, gender) values (72, 'Rayner', 'Terrington', 'Genderqueer');
insert into professor (professor_id, first_name, last_name, gender) values (73, 'Llywellyn', 'Eslinger', 'Non-binary');
insert into professor (professor_id, first_name, last_name, gender) values (74, 'Courtenay', 'Elston', 'Male');
insert into professor (professor_id, first_name, last_name, gender) values (75, 'Domenico', 'Turpie', 'Female');
insert into professor (professor_id, first_name, last_name, gender) values (76, 'Rutledge', 'Casford', 'Agender');
insert into professor (professor_id, first_name, last_name, gender) values (77, 'Vivyan', 'Pudney', 'Genderqueer');
insert into professor (professor_id, first_name, last_name, gender) values (78, 'Sander', 'Finlaison', 'Agender');
insert into professor (professor_id, first_name, last_name, gender) values (79, 'Claudian', 'Gallier', 'Genderfluid');
insert into professor (professor_id, first_name, last_name, gender) values (80, 'Marlene', 'Quare', 'Genderfluid');
insert into professor (professor_id, first_name, last_name, gender) values (81, 'Johnnie', 'Hollingshead', 'Bigender');
insert into professor (professor_id, first_name, last_name, gender) values (82, 'Chrystel', 'Rebeiro', 'Genderfluid');
insert into professor (professor_id, first_name, last_name, gender) values (83, 'Patrizio', 'Boulton', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (84, 'Shelton', 'Lapslie', 'Non-binary');
insert into professor (professor_id, first_name, last_name, gender) values (85, 'Kennie', 'Mordan', 'Bigender');
insert into professor (professor_id, first_name, last_name, gender) values (86, 'Lacy', 'Bonett', 'Genderqueer');
insert into professor (professor_id, first_name, last_name, gender) values (87, 'Elvina', 'Gilding', 'Male');
insert into professor (professor_id, first_name, last_name, gender) values (88, 'Nathalia', 'Kilfeather', 'Male');
insert into professor (professor_id, first_name, last_name, gender) values (89, 'Kellie', 'Holstein', 'Agender');
insert into professor (professor_id, first_name, last_name, gender) values (90, 'Glen', 'Breckell', 'Female');
insert into professor (professor_id, first_name, last_name, gender) values (91, 'Georgie', 'Pettit', 'Bigender');
insert into professor (professor_id, first_name, last_name, gender) values (92, 'Steve', 'Coker', 'Genderqueer');
insert into professor (professor_id, first_name, last_name, gender) values (93, 'Oralia', 'Galia', 'Polygender');
insert into professor (professor_id, first_name, last_name, gender) values (94, 'Hymie', 'Jellico', 'Male');
insert into professor (professor_id, first_name, last_name, gender) values (95, 'Tammara', 'Baalham', 'Non-binary');
insert into professor (professor_id, first_name, last_name, gender) values (96, 'Hashim', 'Birkwood', 'Bigender');
insert into professor (professor_id, first_name, last_name, gender) values (97, 'Yolanthe', 'Devine', 'Female');
insert into professor (professor_id, first_name, last_name, gender) values (98, 'Robin', 'Burgess', 'Genderqueer');
insert into professor (professor_id, first_name, last_name, gender) values (99, 'Celestyn', 'Rippingall', 'Genderfluid');
insert into professor (professor_id, first_name, last_name, gender) values (100, 'Karen', 'Filpi', 'Agender');


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into taughtby (student_email,professor_id)
SELECT  
    *
FROM
(
    SELECT
        *
    FROM
        (
        SELECT 
            student.email AS student_email, professor.professor_id AS professor_id
        FROM
            student CROSS JOIN professor
        ORDER BY
            random()
        ) AS s0
    LIMIT
        1000 
) AS s1
ORDER BY
    student_email, professor_id;

