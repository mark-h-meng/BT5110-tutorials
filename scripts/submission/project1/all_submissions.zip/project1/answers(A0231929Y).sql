/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/

Name: He Gong
Student ID: A0231929Y

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL 
/* The code is written for SQLite */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
In this project, I plan to create a case about the usage of mobile applications. 
This example contains three tables: 'users', 'app', and 'usage'
The 'users' table and the 'app' table correspond to the two entity sets;
The 'usage' table is related to the relationship.
The content of these tables is following:

E1: users, attributes: name, phone, email, and job
'name' represents the name of each user, 
'phone' represents the phone number of each user,
'email' represents the email address of each user,
'job' represents the occupation of each user. 
Primary key is (name, phone)

E2: apps, attributes: app_name, app_id, version, and price
'app_name' represents the name of each application, 
'app_id' represents a specific ID of each application, 
'version' represents the version of each application, 
'price' represents the price of each application.
Primary key is (app_id, version)

R: usage, attributes: name, phone, app_id, version
'name' represents the name of each user, 
'phone' represents the phone number of each user,
'app_id' represents a specific ID of each application,
'version' represents the version of each application,
Primary key is (name, phone, app_id, version)

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
## Table users
CREATE TABLE IF NOT EXISTS users (
name VARCHAR(64) NOT NULL, 
phone NUMERIC NOT NULL,
email VARCHAR(64) UNIQUE NOT NULL,
job VARCHAR(64) NOT NULL,
PRIMARY KEY (name, phone));

## Table apps
CREATE TABLE IF NOT EXISTS apps (
app_name VARCHAR(64) NOT NULL, 
app_id VARCHAR(50) NOT NULL,
version VARCHAR(50) NOT NULL,
price DECIMAL(2, 2),
PRIMARY KEY (app_id, version));

## Table usage
CREATE TABLE IF NOT EXISTS usage (
name VARCHAR(64) NOT NULL REFERENCES users(name),
phone NUMERIC NOT NULL REFERENCES users(phone),
app_id VARCHAR(50) NOT NULL,
version CHAR(3) NOT NULL,
PRIMARY KEY (name, phone, app_id, version),
FOREIGN KEY (app_id, version) REFERENCES apps (app_id, version));

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
## Populate table users
INSERT INTO users (name, phone, email, job) values ('Fayette Bastin', '8258124107', 'fbastin0@mtv.com', 'Food Chemist');
INSERT INTO users (name, phone, email, job) values ('Mirabel Howford', '1196327573', 'mhowford1@phpbb.com', 'Staff Accountant IV');
INSERT INTO users (name, phone, email, job) values ('Lexy Walter', '7138606677', 'lwalter2@tumblr.com', 'Teacher');
INSERT INTO users (name, phone, email, job) values ('Oby Janata', '8203902653', 'ojanata3@slashdot.org', 'Software Engineer II');
INSERT INTO users (name, phone, email, job) values ('Hanny Whaymand', '7805676513', 'hwhaymand4@prweb.com', 'Staff Accountant I');
INSERT INTO users (name, phone, email, job) values ('Tommy Churcher', '9363112054', 'tchurcher5@jalbum.net', 'Account Representative II');
INSERT INTO users (name, phone, email, job) values ('Rich Bousfield', '5536600904', 'rbousfield6@twitter.com', 'Food Chemist');
INSERT INTO users (name, phone, email, job) values ('Aline Lilburn', '2391785539', 'alilburn7@hubpages.com', 'Accounting Assistant III');
INSERT INTO users (name, phone, email, job) values ('Rozella Vallentin', '9387564136', 'rvallentin8@webmd.com', 'Recruiter');
INSERT INTO users (name, phone, email, job) values ('Immanuel Morgan', '4356662818', 'imorgan9@printfriendly.com', 'Help Desk Operator');
INSERT INTO users (name, phone, email, job) values ('Reeva Swaden', '6923301467', 'rswadena@pcworld.com', 'Business Systems Development Analyst');
INSERT INTO users (name, phone, email, job) values ('Wandis Bawles', '8781072263', 'wbawlesb@amazon.de', 'Media Manager III');
INSERT INTO users (name, phone, email, job) values ('Marwin Zukierman', '8527839508', 'mzukiermanc@salon.com', 'Engineer I');
INSERT INTO users (name, phone, email, job) values ('Dwight Mowle', '2023736897', 'dmowled@photobucket.com', 'Accounting Assistant I');
INSERT INTO users (name, phone, email, job) values ('Marlyn Fairweather', '1119631346', 'mfairweathere@loc.gov', 'Senior Financial Analyst');
INSERT INTO users (name, phone, email, job) values ('Maryann Wadworth', '2544495093', 'mwadworthf@discovery.com', 'Software Test Engineer I');
INSERT INTO users (name, phone, email, job) values ('Ryann O''Cannovane', '2459819359', 'rocannovaneg@java.com', 'Media Manager IV');
INSERT INTO users (name, phone, email, job) values ('Nerte Kemsley', '9071516415', 'nkemsleyh@godaddy.com', 'Operator');
INSERT INTO users (name, phone, email, job) values ('Zabrina Pirt', '8118938625', 'zpirti@123-reg.co.uk', 'Software Test Engineer I');
INSERT INTO users (name, phone, email, job) values ('Sharia Kynaston', '5457365417', 'skynastonj@cam.ac.uk', 'Administrative Assistant II');
INSERT INTO users (name, phone, email, job) values ('Orazio Rouchy', '2027966241', 'orouchyk@oracle.com', 'Assistant Media Planner');
INSERT INTO users (name, phone, email, job) values ('Maddie Carmichael', '3187208389', 'mcarmichaell@berkeley.edu', 'Media Manager II');
INSERT INTO users (name, phone, email, job) values ('Cleavland O''Breen', '5407398628', 'cobreenm@parallels.com', 'Research Assistant III');
INSERT INTO users (name, phone, email, job) values ('Ashla Shaddick', '5552050944', 'ashaddickn@loc.gov', 'Business Systems Development Analyst');
INSERT INTO users (name, phone, email, job) values ('Erminia Bestall', '6921855265', 'ebestallo@ow.ly', 'Community Outreach Specialist');
INSERT INTO users (name, phone, email, job) values ('Court Sackur', '5561360517', 'csackurp@cnet.com', 'Paralegal');
INSERT INTO users (name, phone, email, job) values ('Anthony Scoon', '6395844585', 'ascoonq@google.cn', 'Engineer IV');
INSERT INTO users (name, phone, email, job) values ('Paulo Bittlestone', '8232767354', 'pbittlestoner@wikipedia.org', 'Help Desk Technician');
INSERT INTO users (name, phone, email, job) values ('Dorian Walls', '8088756584', 'dwallss@youtube.com', 'Structural Analysis Engineer');
INSERT INTO users (name, phone, email, job) values ('Blakelee Revens', '2467148724', 'brevenst@wufoo.com', 'Data Coordiator');
INSERT INTO users (name, phone, email, job) values ('Borg Splevin', '3136025951', 'bsplevinu@ca.gov', 'Nurse');
INSERT INTO users (name, phone, email, job) values ('Gardener Moyse', '6368937864', 'gmoysev@ebay.com', 'VP Accounting');
INSERT INTO users (name, phone, email, job) values ('Valencia Baradel', '7693949074', 'vbaradelw@4shared.com', 'Speech Pathologist');
INSERT INTO users (name, phone, email, job) values ('Herbert Goreisr', '5303262504', 'hgoreisrx@bing.com', 'Community Outreach Specialist');
INSERT INTO users (name, phone, email, job) values ('Merl Pulhoster', '1392113328', 'mpulhostery@time.com', 'Librarian');
INSERT INTO users (name, phone, email, job) values ('Erminia Kliesl', '9073895761', 'eklieslz@1und1.de', 'Budget/Accounting Analyst II');
INSERT INTO users (name, phone, email, job) values ('Tedmund Ridges', '2178037065', 'tridges10@paginegialle.it', 'Programmer III');
INSERT INTO users (name, phone, email, job) values ('Teriann Shelf', '8872269400', 'tshelf11@twitpic.com', 'Clinical Specialist');
INSERT INTO users (name, phone, email, job) values ('Lissie Watt', '7039775434', 'lwatt12@devhub.com', 'Analyst Programmer');
INSERT INTO users (name, phone, email, job) values ('Inglis Kirkman', '4809773570', 'ikirkman13@bbb.org', 'Administrative Assistant III');
INSERT INTO users (name, phone, email, job) values ('Riva Hamblington', '8829854271', 'rhamblington14@stumbleupon.com', 'Data Coordiator');
INSERT INTO users (name, phone, email, job) values ('Conny Timmons', '9246923068', 'ctimmons15@rediff.com', 'Accountant III');
INSERT INTO users (name, phone, email, job) values ('Darell Joncic', '5304433787', 'djoncic16@yellowpages.com', 'Developer II');
INSERT INTO users (name, phone, email, job) values ('Wernher Cowerd', '9021423318', 'wcowerd17@answers.com', 'Budget/Accounting Analyst II');
INSERT INTO users (name, phone, email, job) values ('Galvin Reape', '4045177036', 'greape18@sun.com', 'Engineer I');
INSERT INTO users (name, phone, email, job) values ('Julee Liepins', '8798654081', 'jliepins19@ed.gov', 'Geological Engineer');
INSERT INTO users (name, phone, email, job) values ('Dennie Massey', '8172804652', 'dmassey1a@geocities.com', 'Geological Engineer');
INSERT INTO users (name, phone, email, job) values ('Dita Dyett', '8406571196', 'ddyett1b@eepurl.com', 'Web Designer I');
INSERT INTO users (name, phone, email, job) values ('Gabriele Kincla', '3226039358', 'gkincla1c@deliciousdays.com', 'Project Manager');
INSERT INTO users (name, phone, email, job) values ('Inigo Rawcliffe', '4494533396', 'irawcliffe1d@businesswire.com', 'Product Engineer');
INSERT INTO users (name, phone, email, job) values ('Vitoria Pennick', '3007102989', 'vpennick1e@unblog.fr', 'Account Representative II');
INSERT INTO users (name, phone, email, job) values ('Fabiano Sunter', '9857154079', 'fsunter1f@google.com.br', 'Business Systems Development Analyst');
INSERT INTO users (name, phone, email, job) values ('Shandeigh Mulvin', '7326827207', 'smulvin1g@usa.gov', 'Registered Nurse');
INSERT INTO users (name, phone, email, job) values ('Tarrah Switsur', '3732525985', 'tswitsur1h@cafepress.com', 'Office Assistant IV');
INSERT INTO users (name, phone, email, job) values ('Robbie Saterweyte', '4976074424', 'rsaterweyte1i@nsw.gov.au', 'Dental Hygienist');
INSERT INTO users (name, phone, email, job) values ('Ryley Regelous', '2902262785', 'rregelous1j@prnewswire.com', 'Statistician I');
INSERT INTO users (name, phone, email, job) values ('Allie Gillbey', '9204883633', 'agillbey1k@imgur.com', 'Office Assistant III');
INSERT INTO users (name, phone, email, job) values ('Reg Brunnstein', '8986608518', 'rbrunnstein1l@wiley.com', 'Sales Associate');
INSERT INTO users (name, phone, email, job) values ('Flory Palphramand', '4978372859', 'fpalphramand1m@imdb.com', 'Administrative Officer');
INSERT INTO users (name, phone, email, job) values ('Jessamine Kowalski', '1478002164', 'jkowalski1n@cbslocal.com', 'Research Assistant IV');
INSERT INTO users (name, phone, email, job) values ('Linnet Kemston', '2677023162', 'lkemston1o@msu.edu', 'Sales Representative');
INSERT INTO users (name, phone, email, job) values ('Gal Wernham', '9042452376', 'gwernham1p@omniture.com', 'Account Representative III');
INSERT INTO users (name, phone, email, job) values ('Florance Stevenson', '6277918533', 'fstevenson1q@nsw.gov.au', 'Media Manager IV');
INSERT INTO users (name, phone, email, job) values ('Dasi Bendtsen', '1062076632', 'dbendtsen1r@g.co', 'Marketing Assistant');
INSERT INTO users (name, phone, email, job) values ('Algernon Janouch', '9813581367', 'ajanouch1s@examiner.com', 'Associate Professor');
INSERT INTO users (name, phone, email, job) values ('Ignacius Hallede', '2552487674', 'ihallede1t@fda.gov', 'Legal Assistant');
INSERT INTO users (name, phone, email, job) values ('Ynes Tennison', '5405100193', 'ytennison1u@rediff.com', 'Operator');
INSERT INTO users (name, phone, email, job) values ('Scottie Lisamore', '5356356228', 'slisamore1v@answers.com', 'Nuclear Power Engineer');
INSERT INTO users (name, phone, email, job) values ('Augy Swinerd', '2831038686', 'aswinerd1w@yellowpages.com', 'Environmental Specialist');
INSERT INTO users (name, phone, email, job) values ('Patricia Skipsea', '3194181771', 'pskipsea1x@twitpic.com', 'Geological Engineer');
INSERT INTO users (name, phone, email, job) values ('Wendy Barajaz', '4894362383', 'wbarajaz1y@go.com', 'Nurse');
INSERT INTO users (name, phone, email, job) values ('Roanna Strangwood', '4344814651', 'rstrangwood1z@sciencedirect.com', 'Research Nurse');
INSERT INTO users (name, phone, email, job) values ('Selby Lelliott', '2352256597', 'slelliott20@skype.com', 'Desktop Support Technician');
INSERT INTO users (name, phone, email, job) values ('Ezequiel McGaugan', '1983178489', 'emcgaugan21@yahoo.com', 'Registered Nurse');
INSERT INTO users (name, phone, email, job) values ('Auroora Twinberrow', '5019505441', 'atwinberrow22@github.com', 'Teacher');
INSERT INTO users (name, phone, email, job) values ('Winslow Whawell', '5963279623', 'wwhawell23@merriam-webster.com', 'Assistant Professor');
INSERT INTO users (name, phone, email, job) values ('Francis Noad', '4047723821', 'fnoad24@aboutads.info', 'Software Test Engineer II');
INSERT INTO users (name, phone, email, job) values ('Jacki Vondruska', '6299350488', 'jvondruska25@mail.ru', 'VP Accounting');
INSERT INTO users (name, phone, email, job) values ('Edith Worsley', '2984802993', 'eworsley26@fotki.com', 'Speech Pathologist');
INSERT INTO users (name, phone, email, job) values ('Tristan Bullar', '7343146594', 'tbullar27@indiatimes.com', 'Statistician III');
INSERT INTO users (name, phone, email, job) values ('Darryl Jikylls', '1399055627', 'djikylls28@angelfire.com', 'Web Designer II');
INSERT INTO users (name, phone, email, job) values ('Elka Malicki', '9097383183', 'emalicki29@chronoengine.com', 'Recruiter');
INSERT INTO users (name, phone, email, job) values ('Eziechiele Wolledge', '4384853917', 'ewolledge2a@blinklist.com', 'Help Desk Technician');
INSERT INTO users (name, phone, email, job) values ('Korella Duddin', '4235205854', 'kduddin2b@hostgator.com', 'Account Executive');
INSERT INTO users (name, phone, email, job) values ('Rica Klos', '4972565374', 'rklos2c@skype.com', 'Social Worker');
INSERT INTO users (name, phone, email, job) values ('Alfy Oxtoby', '8516694954', 'aoxtoby2d@taobao.com', 'Engineer II');
INSERT INTO users (name, phone, email, job) values ('Howard Fussie', '7809816206', 'hfussie2e@issuu.com', 'Analyst Programmer');
INSERT INTO users (name, phone, email, job) values ('Xena Derbyshire', '1208970695', 'xderbyshire2f@webmd.com', 'Assistant Media Planner');
INSERT INTO users (name, phone, email, job) values ('Duky Haugeh', '8143597177', 'dhaugeh2g@unesco.org', 'Dental Hygienist');
INSERT INTO users (name, phone, email, job) values ('Mayer Morehall', '2705657057', 'mmorehall2h@printfriendly.com', 'Quality Engineer');
INSERT INTO users (name, phone, email, job) values ('Shermy Paterson', '3244502052', 'spaterson2i@cloudflare.com', 'Assistant Manager');
INSERT INTO users (name, phone, email, job) values ('Fidole Bolderson', '1635700362', 'fbolderson2j@alexa.com', 'Health Coach I');
INSERT INTO users (name, phone, email, job) values ('Calli Skelington', '5861563671', 'cskelington2k@elpais.com', 'Human Resources Manager');
INSERT INTO users (name, phone, email, job) values ('Gerianne Ferrucci', '4123510097', 'gferrucci2l@reuters.com', 'Budget/Accounting Analyst I');
INSERT INTO users (name, phone, email, job) values ('Maurits Mallock', '5843425905', 'mmallock2m@over-blog.com', 'Engineer IV');
INSERT INTO users (name, phone, email, job) values ('Desmund Abson', '8899935411', 'dabson2n@theguardian.com', 'Help Desk Operator');
INSERT INTO users (name, phone, email, job) values ('Aileen Yitzhak', '5314792500', 'ayitzhak2o@independent.co.uk', 'Information Systems Manager');
INSERT INTO users (name, phone, email, job) values ('Guenevere Hillhouse', '4709415560', 'ghillhouse2p@cdc.gov', 'Sales Associate');
INSERT INTO users (name, phone, email, job) values ('Onofredo Wafer', '8936205474', 'owafer2q@google.fr', 'General Manager');
INSERT INTO users (name, phone, email, job) values ('Simmonds Caldaro', '7026116881', 'scaldaro2r@reverbnation.com', 'Professor');

## Populate table apps
INSERT INTO apps (app_name, app_id, version, price) values ('Tempsoft', 'com.oakley.Bigtax', '0.88', '$9.81');
INSERT INTO apps (app_name, app_id, version, price) values ('Domainer', 'org.opensource.Redhold', '9.2.5', '$1.28');
INSERT INTO apps (app_name, app_id, version, price) values ('Bitwolf', 'com.wired.Holdlamis', '1.2.4', '$3.38');
INSERT INTO apps (app_name, app_id, version, price) values ('Viva', 'com.sitemeter.Andalax', '0.99', '$1.60');
INSERT INTO apps (app_name, app_id, version, price) values ('Bitchip', 'net.jalbum.Flexidy', '0.5.9', '$6.00');
INSERT INTO apps (app_name, app_id, version, price) values ('Span', 'gov.irs.Tres-Zap', '0.7.7', '$3.20');
INSERT INTO apps (app_name, app_id, version, price) values ('Flexidy', 'com.nature.Sonair', '0.29', '$1.62');
INSERT INTO apps (app_name, app_id, version, price) values ('Treeflex', 'com.kickstarter.Bamity', '9.5.6', '$8.05');
INSERT INTO apps (app_name, app_id, version, price) values ('Span', 'com.dedecms.Toughjoyfax', '1.97', '$2.60');
INSERT INTO apps (app_name, app_id, version, price) values ('Mat Lam Tam', 'com.cnbc.Sonsing', '1.84', '$6.44');
INSERT INTO apps (app_name, app_id, version, price) values ('Bytecard', 'com.cloudflare.Veribet', '0.1.7', '$0.73');
INSERT INTO apps (app_name, app_id, version, price) values ('Stim', 'com.addthis.Andalax', '1.7', '$3.69');
INSERT INTO apps (app_name, app_id, version, price) values ('Tres-Zap', 'com.sogou.Quo Lux', '9.00', '$9.39');
INSERT INTO apps (app_name, app_id, version, price) values ('Tempsoft', 'com.google.Bigtax', '6.48', '$3.60');
INSERT INTO apps (app_name, app_id, version, price) values ('Lotstring', 'gov.ca.Voyatouch', '4.5.6', '$4.78');
INSERT INTO apps (app_name, app_id, version, price) values ('Bitchip', 'com.buzzfeed.Konklab', '5.56', '$1.65');
INSERT INTO apps (app_name, app_id, version, price) values ('Fix San', 'net.ovh.Y-find', '6.2.9', '$6.37');
INSERT INTO apps (app_name, app_id, version, price) values ('Greenlam', 'me.flavors.Treeflex', '6.9', '$8.93');
INSERT INTO apps (app_name, app_id, version, price) values ('Mat Lam Tam', 'com.vk.Y-find', '0.28', '$2.39');
INSERT INTO apps (app_name, app_id, version, price) values ('Y-Solowarm', 'org.pbs.Redhold', '1.4.6', '$0.69');
INSERT INTO apps (app_name, app_id, version, price) values ('Zathin', 'org.pbs.Zathin', '6.4', '$0.35');
INSERT INTO apps (app_name, app_id, version, price) values ('Prodder', 'com.sfgate.Bitwolf', '1.8.9', '$0.95');
INSERT INTO apps (app_name, app_id, version, price) values ('Temp', 'com.youtube.Fix San', '7.65', '$9.37');
INSERT INTO apps (app_name, app_id, version, price) values ('Overhold', 'uk.co.independent.Ronstring', '9.89', '$3.69');
INSERT INTO apps (app_name, app_id, version, price) values ('Opela', 'com.istockphoto.Regrant', '6.1', '$6.64');
INSERT INTO apps (app_name, app_id, version, price) values ('Home Ing', 'uk.co.webeden.Stronghold', '0.7.6', '$1.37');
INSERT INTO apps (app_name, app_id, version, price) values ('It', 'vu.de.Andalax', '0.41', '$4.15');
INSERT INTO apps (app_name, app_id, version, price) values ('Wrapsafe', 'com.dropbox.Quo Lux', '3.66', '$5.15');
INSERT INTO apps (app_name, app_id, version, price) values ('Aerified', 'com.eepurl.Zathin', '5.2.8', '$4.75');
INSERT INTO apps (app_name, app_id, version, price) values ('Tres-Zap', 'com.posterous.Latlux', '8.32', '$3.67');
INSERT INTO apps (app_name, app_id, version, price) values ('Hatity', 'ru.liveinternet.Fintone', '0.2.9', '$5.43');
INSERT INTO apps (app_name, app_id, version, price) values ('Biodex', 'jp.ne.hatena.Lotstring', '9.8.1', '$1.59');
INSERT INTO apps (app_name, app_id, version, price) values ('Y-find', 'com.about.Zamit', '6.96', '$6.79');
INSERT INTO apps (app_name, app_id, version, price) values ('Flexidy', 'org.wikimedia.Overhold', '4.6', '$8.25');
INSERT INTO apps (app_name, app_id, version, price) values ('Ronstring', 'com.examiner.Sonsing', '0.2.8', '$9.37');
INSERT INTO apps (app_name, app_id, version, price) values ('Asoka', 'com.barnesandnoble.Tres-Zap', '3.46', '$9.22');
INSERT INTO apps (app_name, app_id, version, price) values ('Bamity', 'com.studiopress.Ronstring', '7.5', '$3.81');
INSERT INTO apps (app_name, app_id, version, price) values ('Flexidy', 'com.studiopress.Span', '0.5.3', '$4.89');
INSERT INTO apps (app_name, app_id, version, price) values ('Lotlux', 'com.addtoany.Ronstring', '0.1.1', '$5.84');
INSERT INTO apps (app_name, app_id, version, price) values ('Alphazap', 'gov.ca.Konklux', '9.2.6', '$8.10');
INSERT INTO apps (app_name, app_id, version, price) values ('Bigtax', 'com.buzzfeed.Tempsoft', '6.62', '$7.56');
INSERT INTO apps (app_name, app_id, version, price) values ('Bitwolf', 'hk.com.google.Quo Lux', '3.47', '$4.13');
INSERT INTO apps (app_name, app_id, version, price) values ('Pannier', 'com.tinyurl.Overhold', '3.8.5', '$9.25');
INSERT INTO apps (app_name, app_id, version, price) values ('Namfix', 'com.arstechnica.Sub-Ex', '9.3', '$7.88');
INSERT INTO apps (app_name, app_id, version, price) values ('Domainer', 'com.cbslocal.Sonair', '5.72', '$4.03');
INSERT INTO apps (app_name, app_id, version, price) values ('Redhold', 'com.paypal.Vagram', '0.11', '$9.32');
INSERT INTO apps (app_name, app_id, version, price) values ('Sub-Ex', 'org.altervista.Redhold', '8.3', '$2.43');
INSERT INTO apps (app_name, app_id, version, price) values ('Ventosanzap', 'gov.noaa.Sonair', '0.68', '$1.05');
INSERT INTO apps (app_name, app_id, version, price) values ('Zontrax', 'com.walmart.Bamity', '1.8.9', '$7.28');
INSERT INTO apps (app_name, app_id, version, price) values ('Namfix', 'com.engadget.Temp', '8.49', '$0.29');
INSERT INTO apps (app_name, app_id, version, price) values ('Flowdesk', 'uk.co.timesonline.Greenlam', '0.3.9', '$1.04');
INSERT INTO apps (app_name, app_id, version, price) values ('Vagram', 'com.netlog.Konklux', '6.4.9', '$8.54');
INSERT INTO apps (app_name, app_id, version, price) values ('Latlux', 'com.netlog.Voyatouch', '0.2.8', '$9.54');
INSERT INTO apps (app_name, app_id, version, price) values ('Biodex', 'com.shutterfly.Biodex', '0.90', '$7.56');
INSERT INTO apps (app_name, app_id, version, price) values ('Opela', 'jp.exblog.Tampflex', '5.3', '$2.73');
INSERT INTO apps (app_name, app_id, version, price) values ('Voltsillam', 'com.homestead.Y-Solowarm', '2.2.1', '$6.00');
INSERT INTO apps (app_name, app_id, version, price) values ('Redhold', 'co.g.Flexidy', '0.86', '$8.86');
INSERT INTO apps (app_name, app_id, version, price) values ('Prodder', 'org.un.Keylex', '6.81', '$4.29');
INSERT INTO apps (app_name, app_id, version, price) values ('Duobam', 'jp.ne.ocn.Treeflex', '8.2.7', '$0.44');
INSERT INTO apps (app_name, app_id, version, price) values ('Biodex', 'com.youku.Stronghold', '0.87', '$6.72');
INSERT INTO apps (app_name, app_id, version, price) values ('Fix San', 'edu.cornell.Holdlamis', '0.78', '$2.31');
INSERT INTO apps (app_name, app_id, version, price) values ('Andalax', 'edu.columbia.Y-find', '1.5', '$5.06');
INSERT INTO apps (app_name, app_id, version, price) values ('Alphazap', 'ru.google.Home Ing', '0.9.3', '$0.20');
INSERT INTO apps (app_name, app_id, version, price) values ('Bamity', 'com.pcworld.Sonsing', '7.34', '$0.67');
INSERT INTO apps (app_name, app_id, version, price) values ('Vagram', 'org.dyndns.Opela', '0.3.3', '$2.18');
INSERT INTO apps (app_name, app_id, version, price) values ('Kanlam', 'gov.fda.Bytecard', '3.43', '$9.75');
INSERT INTO apps (app_name, app_id, version, price) values ('Aerified', 'net.seesaa.Toughjoyfax', '0.18', '$4.10');
INSERT INTO apps (app_name, app_id, version, price) values ('Tempsoft', 'gov.epa.Voltsillam', '1.92', '$8.05');
INSERT INTO apps (app_name, app_id, version, price) values ('Pannier', 'com.foxnews.Subin', '2.0.1', '$5.60');
INSERT INTO apps (app_name, app_id, version, price) values ('Hatity', 'edu.psu.Bamity', '8.48', '$4.87');
INSERT INTO apps (app_name, app_id, version, price) values ('Cookley', 'com.newyorker.Vagram', '8.3.2', '$1.04');
INSERT INTO apps (app_name, app_id, version, price) values ('Cookley', 'edu.wisc.Bitchip', '2.5.6', '$0.96');
INSERT INTO apps (app_name, app_id, version, price) values ('Span', 'edu.washington.Subin', '3.25', '$3.25');
INSERT INTO apps (app_name, app_id, version, price) values ('Latlux', 'com.omniture.Flowdesk', '4.4.8', '$3.06');
INSERT INTO apps (app_name, app_id, version, price) values ('Home Ing', 'org.dmoz.Veribet', '0.7.6', '$8.76');
INSERT INTO apps (app_name, app_id, version, price) values ('Cookley', 'gl.goo.Cardify', '4.1.5', '$3.29');
INSERT INTO apps (app_name, app_id, version, price) values ('Treeflex', 'com.mysql.Lotstring', '0.5.9', '$5.59');
INSERT INTO apps (app_name, app_id, version, price) values ('Opela', 'com.amazonaws.Vagram', '4.2.1', '$1.95');
INSERT INTO apps (app_name, app_id, version, price) values ('Biodex', 'com.time.Redhold', '0.69', '$6.04');
INSERT INTO apps (app_name, app_id, version, price) values ('Konklab', 'com.aol.Y-find', '6.5', '$3.18');
INSERT INTO apps (app_name, app_id, version, price) values ('Redhold', 'com.huffingtonpost.Zontrax', '7.0.3', '$6.30');
INSERT INTO apps (app_name, app_id, version, price) values ('It', 'com.go.Holdlamis', '2.8', '$3.81');
INSERT INTO apps (app_name, app_id, version, price) values ('Flexidy', 'net.a8.Bytecard', '0.1.7', '$8.50');
INSERT INTO apps (app_name, app_id, version, price) values ('Alpha', 'de.e-recht24.Rank', '6.03', '$2.38');
INSERT INTO apps (app_name, app_id, version, price) values ('Bigtax', 'com.mac.Transcof', '2.9.4', '$3.98');
INSERT INTO apps (app_name, app_id, version, price) values ('Home Ing', 'com.deliciousdays.Voyatouch', '5.2.2', '$9.31');
INSERT INTO apps (app_name, app_id, version, price) values ('Solarbreeze', 'com.blogs.Tresom', '7.31', '$2.33');
INSERT INTO apps (app_name, app_id, version, price) values ('Toughjoyfax', 'com.msn.Prodder', '9.7.0', '$1.15');
INSERT INTO apps (app_name, app_id, version, price) values ('Redhold', 'com.nytimes.Domainer', '9.0', '$7.95');
INSERT INTO apps (app_name, app_id, version, price) values ('Wrapsafe', 'hk.com.google.Bytecard', '7.4', '$7.94');
INSERT INTO apps (app_name, app_id, version, price) values ('Matsoft', 'com.sciencedirect.Flexidy', '0.2.5', '$4.35');
INSERT INTO apps (app_name, app_id, version, price) values ('Viva', 'com.moonfruit.Veribet', '7.3.0', '$4.86');
INSERT INTO apps (app_name, app_id, version, price) values ('Gembucket', 'io.github.Treeflex', '3.2', '$8.67');
INSERT INTO apps (app_name, app_id, version, price) values ('Cardify', 'com.hostgator.Zathin', '4.6.2', '$8.98');
INSERT INTO apps (app_name, app_id, version, price) values ('Greenlam', 'com.ask.Stim', '9.4.1', '$4.78');
INSERT INTO apps (app_name, app_id, version, price) values ('Tresom', 'com.yellowbook.Rank', '5.76', '$3.14');
INSERT INTO apps (app_name, app_id, version, price) values ('Zaam-Dox', 'org.dyndns.Job', '0.50', '$9.19');
INSERT INTO apps (app_name, app_id, version, price) values ('Vagram', 'com.latimes.Flexidy', '0.16', '$4.67');
INSERT INTO apps (app_name, app_id, version, price) values ('Zontrax', 'com.mac.Tresom', '0.2.7', '$3.48');
INSERT INTO apps (app_name, app_id, version, price) values ('Bitchip', 'br.com.google.Greenlam', '0.7.6', '$3.83');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
## Populate table usage

INSERT INTO usage 
SELECT c.name, c.phone, p.app_id, p.version
FROM users c, apps p ORDER BY RANDOM()
LIMIT 1000;


