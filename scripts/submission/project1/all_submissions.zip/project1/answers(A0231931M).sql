/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
My example is for students in a University. The first table is students 
and the content inside are first name, last name, email, date of birth, and student ID.
The second table is university and the content inside are university names and their rankings.
The third table is student and universtion relation and the content inside are 
student ID and university name
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE students (
first_name VARCHAR(64),
last_name VARCHAR(64),
email VARCHAR(64) UNIQUE,
birthdate DATE NOT NULL,
studentid VARCHAR(16) PRIMARY KEY,
UNIQUE (first_name, last_name));

CREATE TABLE university (
university_name VARCHAR(100) PRIMARY KEY,
ranking INT NOT NULL);

CREATE TABLE relation (
studentid VARCHAR(16) REFERENCES students(studentid)
ON UPDATE CASCADE ON DELETE CASCADE
DEFERRABLE INITIALLY DEFERRED,
university_name VARCHAR(100) REFERENCES university(university_name)
ON UPDATE CASCADE ON DELETE CASCADE
DEFERRABLE INITIALLY DEFERRED,
PRIMARY KEY (studentid, university_name));


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into students (first_name, last_name, email, birthdate, studentid) values ('Fee', 'Mabbot', 'fmabbot0@people.com.cn', '2/25/2019', 1);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Jelene', 'Keig', 'jkeig1@imdb.com', '1/11/2020', 2);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Jolene', 'McCartan', 'jmccartan2@clickbank.net', '7/12/2019', 3);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Franky', 'Gemlbett', 'fgemlbett3@mapquest.com', '12/6/2018', 4);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Sherlock', 'Tungate', 'stungate4@sciencedirect.com', '6/20/2020', 5);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Gretna', 'Semrad', 'gsemrad5@umn.edu', '12/30/2019', 6);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Johnny', 'Longfield', 'jlongfield6@vk.com', '3/1/2020', 7);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Wait', 'Danbrook', 'wdanbrook7@webeden.co.uk', '9/3/2018', 8);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Onfroi', 'Hadland', 'ohadland8@theglobeandmail.com', '9/4/2019', 9);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Bill', 'Folland', 'bfolland9@ucla.edu', '2/4/2020', 10);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Samara', 'Asker', 'saskera@ucoz.ru', '9/19/2019', 11);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Eolanda', 'Itshak', 'eitshakb@taobao.com', '8/27/2018', 12);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Bard', 'Mattiazzi', 'bmattiazzic@wix.com', '7/10/2019', 13);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Catha', 'Scougal', 'cscougald@vk.com', '5/27/2020', 14);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Carny', 'Sudron', 'csudrone@bloomberg.com', '2/8/2019', 15);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Christan', 'Alesi', 'calesif@alexa.com', '6/20/2020', 16);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Patricio', 'Henstridge', 'phenstridgeg@hhs.gov', '12/31/2019', 17);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Leyla', 'Habbijam', 'lhabbijamh@icio.us', '11/16/2019', 18);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Phylys', 'Witz', 'pwitzi@1688.com', '12/14/2019', 19);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Magdalena', 'Stace', 'mstacej@4shared.com', '6/10/2019', 20);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Arlin', 'Hellen', 'ahellenk@amazon.com', '10/9/2018', 21);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Gerry', 'Winmill', 'gwinmilll@wikispaces.com', '9/8/2019', 22);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Michail', 'Roughey', 'mrougheym@wordpress.com', '11/3/2018', 23);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Kippy', 'Yalden', 'kyaldenn@earthlink.net', '4/23/2020', 24);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Locke', 'Libbis', 'llibbiso@prweb.com', '7/24/2019', 25);
insert into students (first_name, last_name, email, birthdate, studentid) values ('David', 'Blouet', 'dblouetp@walmart.com', '4/18/2020', 26);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Sherm', 'McGuff', 'smcguffq@typepad.com', '5/31/2019', 27);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Ardine', 'Greystock', 'agreystockr@devhub.com', '10/11/2019', 28);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Matelda', 'Barnwell', 'mbarnwells@qq.com', '12/2/2018', 29);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Rutherford', 'Jost', 'rjostt@zdnet.com', '9/11/2018', 30);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Lindy', 'Gritskov', 'lgritskovu@toplist.cz', '3/18/2019', 31);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Nalani', 'Featherstone', 'nfeatherstonev@webmd.com', '7/9/2018', 32);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Katey', 'Luckham', 'kluckhamw@mapy.cz', '4/12/2020', 33);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Clarey', 'Butt', 'cbuttx@jugem.jp', '8/21/2018', 34);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Marja', 'Lymer', 'mlymery@apache.org', '7/12/2020', 35);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Griz', 'Melhuish', 'gmelhuishz@typepad.com', '3/25/2019', 36);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Meggy', 'Lanchbery', 'mlanchbery10@joomla.org', '5/31/2020', 37);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Eolande', 'Sibbs', 'esibbs11@woothemes.com', '7/7/2019', 38);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Hercules', 'McCoveney', 'hmccoveney12@answers.com', '7/18/2018', 39);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Maura', 'Bingley', 'mbingley13@cornell.edu', '6/12/2020', 40);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Sisely', 'Iskowicz', 'siskowicz14@slate.com', '2/18/2020', 41);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Livvy', 'Roberts', 'lroberts15@oracle.com', '5/27/2020', 42);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Elliott', 'Crotty', 'ecrotty16@pagesperso-orange.fr', '3/21/2020', 43);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Tiffani', 'Gasken', 'tgasken17@dropbox.com', '11/20/2018', 44);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Peadar', 'Harvey', 'pharvey18@sitemeter.com', '5/9/2020', 45);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Wendall', 'McCole', 'wmccole19@harvard.edu', '11/1/2019', 46);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Dane', 'Saxon', 'dsaxon1a@upenn.edu', '12/8/2019', 47);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Sybila', 'Wilshaw', 'swilshaw1b@4shared.com', '11/25/2019', 48);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Alexei', 'Dohr', 'adohr1c@blogs.com', '3/10/2020', 49);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Jeromy', 'Gabby', 'jgabby1d@diigo.com', '11/9/2019', 50);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Gawain', 'McPeck', 'gmcpeck1e@instagram.com', '2/17/2019', 51);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Husain', 'Chinnery', 'hchinnery1f@washingtonpost.com', '3/3/2019', 52);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Robers', 'Lovelock', 'rlovelock1g@usgs.gov', '8/18/2018', 53);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Gregorius', 'Vater', 'gvater1h@nyu.edu', '2/22/2019', 54);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Marchelle', 'Balffye', 'mbalffye1i@cyberchimps.com', '7/7/2020', 55);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Danit', 'Nother', 'dnother1j@studiopress.com', '9/2/2018', 56);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Page', 'Cass', 'pcass1k@japanpost.jp', '5/31/2019', 57);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Igor', 'Nail', 'inail1l@toplist.cz', '9/16/2019', 58);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Isabel', 'Bizzey', 'ibizzey1m@mozilla.com', '5/26/2020', 59);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Jo', 'Malter', 'jmalter1n@mysql.com', '5/9/2020', 60);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Ainsley', 'Demcak', 'ademcak1o@scribd.com', '7/12/2019', 61);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Vinni', 'Scroggs', 'vscroggs1p@techcrunch.com', '12/24/2018', 62);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Sue', 'Gathwaite', 'sgathwaite1q@smugmug.com', '11/23/2019', 63);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Luigi', 'Ions', 'lions1r@adobe.com', '3/23/2019', 64);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Keir', 'Aujouanet', 'kaujouanet1s@archive.org', '6/23/2020', 65);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Susannah', 'Hazelgrove', 'shazelgrove1t@prweb.com', '11/20/2019', 66);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Cinnamon', 'Pimblotte', 'cpimblotte1u@yellowpages.com', '5/16/2019', 67);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Sterne', 'Shere', 'sshere1v@go.com', '5/26/2020', 68);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Shawna', 'Vinden', 'svinden1w@chron.com', '10/31/2019', 69);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Korella', 'Battelle', 'kbattelle1x@themeforest.net', '8/10/2018', 70);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Maurizia', 'Benford', 'mbenford1y@ftc.gov', '11/1/2018', 71);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Elsa', 'Hache', 'ehache1z@arstechnica.com', '11/17/2018', 72);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Kelvin', 'Corlett', 'kcorlett20@cdbaby.com', '12/23/2019', 73);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Miranda', 'Cancott', 'mcancott21@google.es', '4/21/2019', 74);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Maureen', 'Levett', 'mlevett22@goo.gl', '7/30/2018', 75);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Catie', 'Olyff', 'colyff23@yellowpages.com', '6/26/2020', 76);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Yul', 'Askell', 'yaskell24@themeforest.net', '12/12/2019', 77);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Dev', 'Cass', 'dcass25@i2i.jp', '2/26/2020', 78);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Allix', 'Garnall', 'agarnall26@networkadvertising.org', '9/12/2019', 79);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Dun', 'Grichukhin', 'dgrichukhin27@hud.gov', '10/12/2018', 80);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Fey', 'Bison', 'fbison28@europa.eu', '5/20/2020', 81);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Herminia', 'McPharlain', 'hmcpharlain29@wikia.com', '7/14/2020', 82);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Ashlie', 'Backsal', 'abacksal2a@e-recht24.de', '7/15/2020', 83);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Vinson', 'Barfford', 'vbarfford2b@com.com', '10/31/2018', 84);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Lorrin', 'Snook', 'lsnook2c@jiathis.com', '2/6/2019', 85);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Zachariah', 'Zollner', 'zzollner2d@dedecms.com', '5/11/2019', 86);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Kerrie', 'Cadogan', 'kcadogan2e@accuweather.com', '8/5/2018', 87);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Eustace', 'Krysztowczyk', 'ekrysztowczyk2f@mlb.com', '11/11/2019', 88);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Ashlie', 'McCuthais', 'amccuthais2g@spiegel.de', '3/31/2019', 89);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Keary', 'Kennion', 'kkennion2h@multiply.com', '9/11/2018', 90);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Hermann', 'Gribben', 'hgribben2i@mapquest.com', '4/16/2020', 91);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Burg', 'Ithell', 'bithell2j@gizmodo.com', '1/21/2019', 92);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Cybil', 'Seak', 'cseak2k@studiopress.com', '11/21/2018', 93);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Margie', 'Duigenan', 'mduigenan2l@macromedia.com', '11/28/2019', 94);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Myer', 'Dossit', 'mdossit2m@ameblo.jp', '2/23/2020', 95);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Linell', 'Brane', 'lbrane2n@fastcompany.com', '2/15/2019', 96);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Quincy', 'Ramiro', 'qramiro2o@elpais.com', '10/17/2018', 97);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Valery', 'Pattinson', 'vpattinson2p@angelfire.com', '6/15/2019', 98);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Abdul', 'Reeder', 'areeder2q@cafepress.com', '8/18/2019', 99);
insert into students (first_name, last_name, email, birthdate, studentid) values ('Erina', 'Hukin', 'ehukin2r@usda.gov', '6/1/2020', 100);

insert into university (university_name, ranking) values ('Sichuan Normal University', 1);
insert into university (university_name, ranking) values ('Naval Postgraduate School', 2);
insert into university (university_name, ranking) values ('Our Lady of the Lake University', 3);
insert into university (university_name, ranking) values ('Tikrit University', 4);
insert into university (university_name, ranking) values ('Instituto Tecnologico de Durango', 5);
insert into university (university_name, ranking) values ('Guangzhou Normal University', 6);
insert into university (university_name, ranking) values ('Embry Riddle Aeronautical University, Prescott', 7);
insert into university (university_name, ranking) values ('Universitas Merdeka Malang', 8);
insert into university (university_name, ranking) values ('Universidade de Mogi das Cruzes', 9);
insert into university (university_name, ranking) values ('Universidade Federal de Juiz de Fora', 10);
insert into university (university_name, ranking) values ('Hastings College', 11);
insert into university (university_name, ranking) values ('Wentworth Institute of Technology', 12);
insert into university (university_name, ranking) values ('Music Academy in Lodz', 13);
insert into university (university_name, ranking) values ('Xinjiang Normal University', 14);
insert into university (university_name, ranking) values ('Universidad Autónoma de Zacatecas', 15);
insert into university (university_name, ranking) values ('University of Kalyani', 16);
insert into university (university_name, ranking) values ('Universidad Centro Occidental Lisandro Alvarado', 17);
insert into university (university_name, ranking) values ('Sanjay Gandhi Postgraduate lnstitute of Medical Sciences', 18);
insert into university (university_name, ranking) values ('The Global College Lahore', 19);
insert into university (university_name, ranking) values ('Okayama University of Science', 20);
insert into university (university_name, ranking) values ('Babson College', 21);
insert into university (university_name, ranking) values ('Universität Flensburg', 22);
insert into university (university_name, ranking) values ('Xiangtan University', 23);
insert into university (university_name, ranking) values ('Afeka Tel Aviv Academic College of Engineering', 24);
insert into university (university_name, ranking) values ('Brac University', 25);
insert into university (university_name, ranking) values ('Yakutsk State University', 26);
insert into university (university_name, ranking) values ('Universidad Fundepos Alma Mater', 27);
insert into university (university_name, ranking) values ('College for Financial Planning', 28);
insert into university (university_name, ranking) values ('Shanghai Medical University', 29);
insert into university (university_name, ranking) values ('Holy Names College', 30);
insert into university (university_name, ranking) values ('Ontario College of Art and Design', 31);
insert into university (university_name, ranking) values ('University of Chicago', 32);
insert into university (university_name, ranking) values ('Rasmussen College, North Dakota Campuses', 33);
insert into university (university_name, ranking) values ('Wuhan University of Technology', 34);
insert into university (university_name, ranking) values ('Islamic Azad University, Shahr-e-rey Branch', 35);
insert into university (university_name, ranking) values ('Badakhshan University', 36);
insert into university (university_name, ranking) values ('Semey State University', 37);
insert into university (university_name, ranking) values ('Chhatrapati Shahu Ji Maharaj University', 38);
insert into university (university_name, ranking) values ('Tai Solarin University of Education', 39);
insert into university (university_name, ranking) values ('Obninsk State Technical University for Nuclear Power Engineering', 40);
insert into university (university_name, ranking) values ('Middle East Technical University', 41);
insert into university (university_name, ranking) values ('Ekiti State University', 42);
insert into university (university_name, ranking) values ('Ghana Institute of Management and Public Administration (GIMPA)', 43);
insert into university (university_name, ranking) values ('Metropolitan State College of Denver', 44);
insert into university (university_name, ranking) values ('Makanlal Chutur Vedi University', 45);
insert into university (university_name, ranking) values ('Sarajevo Film Academy', 46);
insert into university (university_name, ranking) values ('Tashkent Islam University', 47);
insert into university (university_name, ranking) values ('Oregon Graduate Institute of Science and Technology', 48);
insert into university (university_name, ranking) values ('Beijing Union University', 49);
insert into university (university_name, ranking) values ('Universidad Nacional del Callao', 50);
insert into university (university_name, ranking) values ('Tel Aviv University', 51);
insert into university (university_name, ranking) values ('Institute for Advanced Studies Lucca', 52);
insert into university (university_name, ranking) values ('University of Notre Dame', 53);
insert into university (university_name, ranking) values ('Wheaton College Massachusetts', 54);
insert into university (university_name, ranking) values ('Lahore University of Management Sciences', 55);
insert into university (university_name, ranking) values ('Universidad Francisco de Aguirre', 56);
insert into university (university_name, ranking) values ('Azzahra University', 57);
insert into university (university_name, ranking) values ('University of South Carolina - Aiken', 58);
insert into university (university_name, ranking) values ('Institute of Business and Politics', 59);
insert into university (university_name, ranking) values ('Adventist University of the Philippines', 60);
insert into university (university_name, ranking) values ('Menlo College', 61);
insert into university (university_name, ranking) values ('Heidelberg College', 62);
insert into university (university_name, ranking) values ('Beijing Medical University', 63);
insert into university (university_name, ranking) values ('St. Petersburg State Institute of Technology (Technological University)', 64);
insert into university (university_name, ranking) values ('University of Calcutta', 65);
insert into university (university_name, ranking) values ('Karaganda State Buketov University', 66);
insert into university (university_name, ranking) values ('Fachhochschule Hannover', 67);
insert into university (university_name, ranking) values ('Universitas Pasundan', 68);
insert into university (university_name, ranking) values ('Fachhochschulstudiengänge der Wiener Wirtschaft', 69);
insert into university (university_name, ranking) values ('Sanford-Brown Institute', 70);
insert into university (university_name, ranking) values ('Hokkaigakuen University of Kitami', 71);
insert into university (university_name, ranking) values ('Universidad Metropolitana de Honduras', 72);
insert into university (university_name, ranking) values ('Universidad Peruana de Ciencias e Informática', 73);
insert into university (university_name, ranking) values ('Kent State University - Salem', 74);
insert into university (university_name, ranking) values ('National University of Science and Technology', 75);
insert into university (university_name, ranking) values ('Pontifícia Universidade Católica de Minas Gerais', 76);
insert into university (university_name, ranking) values ('International University of Kyrgyzstan', 77);
insert into university (university_name, ranking) values ('Al-Jabal Al-Gharbi University', 78);
insert into university (university_name, ranking) values ('Windsor University School of Medicine', 79);
insert into university (university_name, ranking) values ('Alcorn State University', 80);
insert into university (university_name, ranking) values ('University of Johannesburg', 81);
insert into university (university_name, ranking) values ('Ruhr-Universität Bochum', 82);
insert into university (university_name, ranking) values ('Université d''Aix-Marseille III', 83);
insert into university (university_name, ranking) values ('Nasarawa State University Keffi', 84);
insert into university (university_name, ranking) values ('Universidad Nacional Experimental "Rafael Maria Baralt"', 85);
insert into university (university_name, ranking) values ('Imo State University', 86);
insert into university (university_name, ranking) values ('Oulu Polytechnic', 87);
insert into university (university_name, ranking) values ('Medizinische Universität Innsbruck', 88);
insert into university (university_name, ranking) values ('Universidad Tecnológica Equinoccial', 89);
insert into university (university_name, ranking) values ('1 December University of Alba Iulia', 90);
insert into university (university_name, ranking) values ('University of Montana', 91);
insert into university (university_name, ranking) values ('Huizhou University', 92);
insert into university (university_name, ranking) values ('Sichuan Fine Art Institute', 93);
insert into university (university_name, ranking) values ('Darul Quran Islamic College University', 94);
insert into university (university_name, ranking) values ('Armenian State Agrarian University', 95);
insert into university (university_name, ranking) values ('Universidad Técnica de Esmeraldas "Luis Vargas Torres"', 96);
insert into university (university_name, ranking) values ('Vitebsk State Technological University', 97);
insert into university (university_name, ranking) values ('University of North Dakota', 98);
insert into university (university_name, ranking) values ('Politeknik Negeri Semarang', 99);
insert into university (university_name, ranking) values ('Mount Olive College', 100);


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO relation (studentid, university_name)
SELECT s.studentid, u.university_name
FROM students as s, university as u ORDER BY RANDOM() LIMIT 1000;

