/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
My example is about the covid-19 patients path tracing. One of the entity is the Patients infected by covid-19 in UK.
Another entity is the different place location in UK. So, the relationship is where the patients have been in UK.

Because in reality, once someone get infected by covid-19, people around him/her may be infected too. To trace the track of
these patients can help to find the people with higher potiential risk of being infected. At first we should find where and when
the patients have been. And then we can check who have also been to these place at the same time as the patients. So, my example
is about tracing the patients path.

And because from the mockaroo.com I found the NHS number, which is a identification number of people in UK, this content is set
to be in UK and the NHS number can be a primary key. For the patient, I have to specify its infected date. For the palce in UK,
I have to list the 

The following questions are written for PostgreSQL.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
Create table if not exists covid19_patients(NHS_number varchar(64) PRIMARY KEY,
											first_name  varchar(64),
											last_name  varchar(64),
											gender  varchar(64), 
											contact_number  varchar(64), 
											email  varchar(64), 
											Infected_date  date);

Create table if not exists UK_place(Country varchar(64),
								City varchar(64), 
								Street_name varchar(64), 
								Street_number varchar(64), 
								Postal_code varchar(64),
								Place_contact_number varchar(64) Primary Key);
								
Create table if not exists Patient_Path(NHS_number Varchar(64) REFERENCES covid19_patients (NHS_number),
										Place_contact_number varchar(64) References UK_place (Place_contact_number),
										Path_date date
									   );
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('8657855623', 'Olly', 'Sheavills', 'Non-binary', '+358 (867) 746-5921', 'osheavills0@amazon.co.uk', '8/20/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('7045221711', 'Marshall', 'Stone', 'Genderfluid', '+389 (947) 504-1909', 'mstone1@fc2.com', '8/15/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5943943382', 'Holly', 'Kmicicki', 'Male', '+7 (824) 140-8829', 'hkmicicki2@boston.com', '8/17/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('0217397654', 'Rinaldo', 'Guess', 'Agender', '+351 (913) 433-7784', 'rguess3@howstuffworks.com', '8/20/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5806137295', 'Emmalynne', 'MacHoste', 'Female', '+976 (471) 653-6990', 'emachoste4@theguardian.com', '8/2/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('8886084242', 'Thedrick', 'Yellep', 'Female', '+7 (879) 134-7003', 'tyellep5@printfriendly.com', '8/18/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('6083209889', 'Isabel', 'Anderson', 'Agender', '+86 (776) 419-5125', 'ianderson6@opensource.org', '8/14/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('4431641432', 'Pauletta', 'Crasford', 'Agender', '+374 (594) 638-9238', 'pcrasford7@amazon.co.uk', '8/11/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('8082332719', 'Chastity', 'Croce', 'Genderqueer', '+86 (465) 173-8061', 'ccroce8@csmonitor.com', '8/6/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('3839566959', 'Rafaelita', 'Loomis', 'Polygender', '+358 (255) 605-9190', 'rloomis9@quantcast.com', '8/20/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('4226599241', 'Ennis', 'Thurbon', 'Genderqueer', '+86 (639) 468-7034', 'ethurbona@sitemeter.com', '8/8/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('2083056493', 'Lorelle', 'Ghidetti', 'Male', '+86 (355) 637-8215', 'lghidettib@moonfruit.com', '8/14/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('6401017899', 'Stevie', 'Boycott', 'Bigender', '+53 (865) 615-4411', 'sboycottc@myspace.com', '8/15/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5804699792', 'Mamie', 'Cordova', 'Female', '+52 (697) 178-7965', 'mcordovad@engadget.com', '8/9/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('1479376396', 'Constantin', 'Eyckel', 'Female', '+86 (177) 683-6340', 'ceyckele@wordpress.com', '8/18/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5585680331', 'Brody', 'Gerrens', 'Bigender', '+55 (939) 283-0043', 'bgerrensf@mail.ru', '8/14/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('3597329195', 'Doralia', 'Brewers', 'Non-binary', '+380 (881) 863-0340', 'dbrewersg@omniture.com', '8/21/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('2161774875', 'Reina', 'Hastwell', 'Male', '+60 (925) 140-1657', 'rhastwellh@patch.com', '8/12/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('7798377859', 'Gerti', 'Sleight', 'Polygender', '+380 (329) 720-5174', 'gsleighti@google.fr', '8/16/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('7845271217', 'Casie', 'Fearneley', 'Non-binary', '+63 (548) 153-0634', 'cfearneleyj@forbes.com', '8/21/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('9929026185', 'Falito', 'Scougal', 'Bigender', '+56 (263) 451-4876', 'fscougalk@privacy.gov.au', '8/2/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('6442953270', 'Noell', 'Laphorn', 'Genderfluid', '+55 (825) 901-3159', 'nlaphornl@themeforest.net', '8/5/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('2560580578', 'Shaylyn', 'Rozzier', 'Non-binary', '+218 (895) 537-5318', 'srozzierm@mozilla.com', '8/4/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('3969206979', 'Gwendolin', 'Wakes', 'Female', '+375 (775) 291-1398', 'gwakesn@wix.com', '8/7/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('0927835339', 'Christoffer', 'La Batie', 'Agender', '+62 (861) 324-0006', 'clabatieo@ed.gov', '8/15/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5858567797', 'Fanya', 'Bathersby', 'Agender', '+63 (891) 667-6922', 'fbathersbyp@tuttocitta.it', '8/12/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('7804488130', 'Robin', 'Fairlem', 'Genderfluid', '+51 (305) 131-4334', 'rfairlemq@soup.io', '8/21/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('3263300075', 'Gussie', 'Prandoni', 'Polygender', '+351 (246) 876-5786', 'gprandonir@zdnet.com', '8/3/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('3756156761', 'Prudy', 'Heard', 'Agender', '+51 (390) 129-0423', 'pheards@mysql.com', '8/12/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5086631033', 'Sally', 'Keeping', 'Bigender', '+1 (892) 715-4225', 'skeepingt@phpbb.com', '8/19/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('3849949478', 'Emory', 'Brogini', 'Female', '+86 (298) 741-8383', 'ebroginiu@infoseek.co.jp', '8/7/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('0987042629', 'Joey', 'Iacobacci', 'Bigender', '+1 (435) 739-4984', 'jiacobacciv@dyndns.org', '8/15/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('9409144841', 'Lauraine', 'Olorenshaw', 'Bigender', '+86 (216) 607-8317', 'lolorenshaww@google.pl', '8/11/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('0415024242', 'Val', 'Nairne', 'Bigender', '+20 (424) 360-9366', 'vnairnex@yahoo.co.jp', '8/9/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('1408507692', 'Bronny', 'Bovis', 'Non-binary', '+62 (181) 652-1421', 'bbovisy@bbc.co.uk', '8/11/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('0320890538', 'Earl', 'Chatel', 'Genderqueer', '+30 (652) 339-8132', 'echatelz@sina.com.cn', '8/18/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('0620114649', 'Essie', 'Lukasen', 'Non-binary', '+62 (995) 507-6783', 'elukasen10@twitpic.com', '8/8/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('0777784688', 'Jacky', 'Olifaunt', 'Genderqueer', '+7 (401) 690-1960', 'jolifaunt11@webs.com', '8/15/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('0793460743', 'Cassie', 'Foro', 'Non-binary', '+44 (753) 890-2325', 'cforo12@unicef.org', '8/21/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('4081670838', 'Marie-jeanne', 'Husselbee', 'Bigender', '+86 (749) 961-8865', 'mhusselbee13@bandcamp.com', '8/16/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('7551667164', 'Cathee', 'Haruard', 'Male', '+33 (286) 630-3022', 'charuard14@purevolume.com', '8/15/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('6193540512', 'Adelbert', 'Speeding', 'Agender', '+7 (878) 144-8575', 'aspeeding15@com.com', '8/20/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('6933424545', 'Merry', 'Moyce', 'Genderqueer', '+62 (235) 649-3507', 'mmoyce16@webmd.com', '8/2/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('9202603480', 'Fonzie', 'Daton', 'Genderfluid', '+55 (627) 422-7697', 'fdaton17@ox.ac.uk', '8/5/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5437919549', 'Artur', 'Cruse', 'Bigender', '+86 (931) 521-6231', 'acruse18@netscape.com', '8/3/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('6130517858', 'Thaddus', 'Bockler', 'Bigender', '+351 (384) 190-9204', 'tbockler19@clickbank.net', '8/15/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('6438181145', 'Jeffrey', 'McElhargy', 'Genderfluid', '+92 (469) 513-3380', 'jmcelhargy1a@linkedin.com', '8/18/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('4683343274', 'Ethyl', 'Garrould', 'Bigender', '+260 (141) 794-5119', 'egarrould1b@flickr.com', '8/16/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('8139577006', 'Nichol', 'Ferrarese', 'Non-binary', '+385 (920) 763-1760', 'nferrarese1c@myspace.com', '8/2/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('6561441923', 'Kriste', 'Sadgrove', 'Male', '+7 (102) 683-0894', 'ksadgrove1d@yale.edu', '8/6/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('3620032866', 'Dud', 'Droghan', 'Bigender', '+7 (520) 883-4493', 'ddroghan1e@wsj.com', '8/16/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('9503712971', 'Lock', 'Pettisall', 'Genderqueer', '+62 (193) 160-0488', 'lpettisall1f@lulu.com', '8/20/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('4501579986', 'Joyous', 'Mackerel', 'Genderqueer', '+7 (286) 330-9778', 'jmackerel1g@csmonitor.com', '8/11/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5897815224', 'Muhammad', 'Verna', 'Genderfluid', '+62 (771) 161-5120', 'mverna1h@4shared.com', '8/20/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('8179433889', 'Loraine', 'McIlvenna', 'Bigender', '+268 (802) 656-2411', 'lmcilvenna1i@sogou.com', '8/7/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('2135802964', 'Dorry', 'Dulinty', 'Male', '+86 (191) 870-4605', 'ddulinty1j@go.com', '8/14/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('9510585327', 'Melany', 'Praton', 'Genderqueer', '+86 (951) 450-7593', 'mpraton1k@furl.net', '8/12/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('0555717224', 'Jaimie', 'Duesbury', 'Genderfluid', '+66 (809) 224-9516', 'jduesbury1l@wufoo.com', '8/9/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('6033405188', 'Henrik', 'Swett', 'Genderqueer', '+62 (280) 164-7469', 'hswett1m@sakura.ne.jp', '8/20/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('1807959082', 'Ines', 'Merrill', 'Bigender', '+86 (436) 932-2312', 'imerrill1n@bizjournals.com', '8/8/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5786610373', 'Madeline', 'Blaw', 'Bigender', '+63 (974) 502-8730', 'mblaw1o@themeforest.net', '8/4/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('3819980695', 'Drusie', 'Leadston', 'Genderqueer', '+374 (323) 243-2515', 'dleadston1p@jigsy.com', '8/8/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('1254164197', 'Omar', 'Megarrell', 'Bigender', '+62 (776) 653-6771', 'omegarrell1q@123-reg.co.uk', '8/6/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('6983771354', 'Corissa', 'Sondon', 'Male', '+63 (101) 216-6788', 'csondon1r@comsenz.com', '8/12/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5003583311', 'Florry', 'Birkett', 'Female', '+55 (706) 136-5315', 'fbirkett1s@constantcontact.com', '8/11/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('2457151562', 'Lorette', 'Boggon', 'Bigender', '+7 (803) 559-4425', 'lboggon1t@goo.ne.jp', '8/5/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('2866290712', 'Huberto', 'Bennion', 'Genderfluid', '+55 (416) 701-0422', 'hbennion1u@51.la', '8/5/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('3631658273', 'Cinnamon', 'Demsey', 'Agender', '+86 (779) 912-4236', 'cdemsey1v@cmu.edu', '8/12/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('1748742051', 'Devon', 'Jepp', 'Bigender', '+63 (242) 119-7381', 'djepp1w@addthis.com', '8/12/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('1815928352', 'Sergio', 'Rentilll', 'Bigender', '+385 (232) 196-9777', 'srentilll1x@cbslocal.com', '8/13/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5405605042', 'Jedd', 'McComb', 'Non-binary', '+48 (954) 680-2617', 'jmccomb1y@friendfeed.com', '8/19/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5398477757', 'Stanleigh', 'Cuthill', 'Bigender', '+48 (334) 299-6749', 'scuthill1z@freewebs.com', '8/21/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('9377255325', 'Ethelind', 'Piddletown', 'Bigender', '+62 (410) 607-5989', 'epiddletown20@flickr.com', '8/11/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5696600417', 'Torrie', 'Bushel', 'Agender', '+380 (869) 719-5069', 'tbushel21@cafepress.com', '8/19/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('4304135244', 'Evin', 'Tetla', 'Genderfluid', '+7 (427) 448-8465', 'etetla22@wikia.com', '8/12/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('0269000917', 'Lindsay', 'Indge', 'Agender', '+63 (362) 252-3001', 'lindge23@weebly.com', '8/7/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('0182883272', 'Merl', 'Castaignet', 'Non-binary', '+86 (467) 408-4218', 'mcastaignet24@rambler.ru', '8/2/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('6086854505', 'Lianne', 'Baudry', 'Bigender', '+86 (185) 276-8609', 'lbaudry25@ucoz.com', '8/9/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('7943010817', 'Bear', 'Napier', 'Female', '+54 (534) 371-9491', 'bnapier26@timesonline.co.uk', '8/12/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('4106635852', 'Arie', 'Bichener', 'Male', '+52 (974) 380-2198', 'abichener27@furl.net', '8/5/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('1992516804', 'Alphonso', 'Wraxall', 'Non-binary', '+972 (822) 307-5255', 'awraxall28@sina.com.cn', '8/9/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('7732072111', 'Jenni', 'Rankine', 'Agender', '+33 (231) 170-5964', 'jrankine29@theguardian.com', '8/14/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('3187341365', 'Daryn', 'Durbin', 'Male', '+48 (813) 942-3740', 'ddurbin2a@cloudflare.com', '8/4/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('7750506586', 'Gasparo', 'McGrah', 'Polygender', '+7 (839) 463-5845', 'gmcgrah2b@cocolog-nifty.com', '8/11/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('0715263404', 'Marcy', 'Josselsohn', 'Female', '+237 (544) 280-0494', 'mjosselsohn2c@unicef.org', '8/9/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('2568306610', 'Dillon', 'Worner', 'Agender', '+62 (905) 904-1600', 'dworner2d@theguardian.com', '8/19/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5241138161', 'Abbi', 'Twist', 'Female', '+64 (749) 440-9464', 'atwist2e@behance.net', '8/5/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('7566688421', 'Francoise', 'Fandrich', 'Agender', '+242 (889) 202-2420', 'ffandrich2f@tinypic.com', '8/15/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('6932378655', 'Brianna', 'Coste', 'Female', '+351 (120) 495-3707', 'bcoste2g@prlog.org', '8/15/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('0892921374', 'Doralynne', 'Castillon', 'Polygender', '+86 (706) 447-8135', 'dcastillon2h@sourceforge.net', '8/13/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('3411574232', 'Halsey', 'Pollicote', 'Non-binary', '+1 (202) 370-0137', 'hpollicote2i@de.vu', '8/15/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('8231564411', 'Artemas', 'Dinning', 'Non-binary', '+86 (304) 896-3099', 'adinning2j@rambler.ru', '8/13/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('6128126731', 'Gery', 'Dettmar', 'Female', '+62 (114) 606-3560', 'gdettmar2k@plala.or.jp', '8/10/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5399490404', 'Krispin', 'Fairbrace', 'Genderfluid', '+86 (908) 306-7373', 'kfairbrace2l@opensource.org', '8/19/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('4176183276', 'Clair', 'Neaverson', 'Non-binary', '+63 (440) 349-3559', 'cneaverson2m@privacy.gov.au', '8/10/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('8678897988', 'Anthia', 'Brasher', 'Agender', '+86 (283) 268-7201', 'abrasher2n@dion.ne.jp', '8/21/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('2497902798', 'Nolana', 'Wellen', 'Bigender', '+62 (271) 350-0389', 'nwellen2o@artisteer.com', '8/14/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('3565544066', 'Phebe', 'Fretson', 'Male', '+7 (178) 894-4316', 'pfretson2p@pen.io', '8/3/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('0487950879', 'Che', 'Robbe', 'Male', '+7 (915) 280-0451', 'crobbe2q@shinystat.com', '8/21/2021');
insert into covid19_patients (NHS_number, first_name, last_name, gender, contact_number, email, Infected_date) values ('5348718173', 'Dieter', 'Ruffy', 'Genderfluid', '+30 (324) 589-6350', 'druffy2r@oakley.com', '8/7/2021');

insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Swindon', 'Namekagon', '54708', 'SN1', '+44 (928) 910-3195');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Edinburgh', 'Lunder', '3', 'EH9', '+44 (128) 910-2930');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Sheffield', 'David', '3679', 'S33', '+44 (837) 796-7864');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Twyford', 'West', '27', 'LE14', '+44 (932) 469-7664');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Upton', 'Hoard', '8547', 'DN21', '+44 (189) 270-6610');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Linton', 'Farragut', '957', 'BD23', '+44 (567) 152-0490');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Charlton', 'Quincy', '47', 'OX12', '+44 (854) 499-5151');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Norton', 'Florence', '265', 'NN11', '+44 (355) 280-7949');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'London', 'Chive', '7714', 'SW1E', '+44 (680) 363-2935');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Buckland', 'Northview', '03759', 'CT16', '+44 (246) 455-5890');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Church End', 'Gulseth', '00805', 'N3', '+44 (521) 616-4106');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Linton', 'Nobel', '38', 'BD23', '+44 (617) 138-5672');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Newton', 'Old Shore', '947', 'IV1', '+44 (533) 578-7283');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Horton', 'Hoard', '41752', 'BS37', '+44 (419) 934-0127');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Eaton', 'Washington', '359', 'DN22', '+44 (347) 614-2309');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Ford', 'Blue Bill Park', '0448', 'GL54', '+44 (680) 346-7175');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Liverpool', 'Clemons', '09052', 'L33', '+44 (548) 671-7015');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Bristol', 'American', '42', 'BS41', '+44 (675) 850-2530');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Aberdeen', 'Crowley', '95', 'AB39', '+44 (920) 428-7575');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Bristol', 'Springview', '21612', 'BS41', '+44 (278) 748-0416');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Kingston', 'Kedzie', '6740', 'DT10', '+44 (449) 961-9177');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Norton', 'Starling', '75982', 'NN11', '+44 (346) 737-7119');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Norton', 'Kipling', '30704', 'S8', '+44 (711) 418-1197');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Newbiggin', 'Macpherson', '6', 'NE46', '+44 (540) 894-6071');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Newton', 'Norway Maple', '11420', 'NG34', '+44 (481) 532-0105');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Wirral', 'Monument', '151', 'CH48', '+44 (318) 788-5103');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Kingston', 'Artisan', '7123', 'DT10', '+44 (347) 752-1647');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'London', 'Quincy', '58507', 'EC1V', '+44 (472) 613-9454');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Birmingham', 'Hoepker', '73136', 'B40', '+44 (105) 409-3520');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'London', 'Meadow Vale', '59', 'EC1V', '+44 (550) 140-3401');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Kirkton', 'Morrow', '96', 'KW10', '+44 (965) 922-5344');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Leeds', 'Eggendart', '5', 'LS6', '+44 (144) 878-8578');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Manchester', 'Brown', '782', 'M14', '+44 (862) 819-8183');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Denton', 'Mallory', '8544', 'M34', '+44 (455) 103-8466');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Seaton', 'Pearson', '517', 'LE15', '+44 (259) 795-1064');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Marston', 'Superior', '84278', 'ST20', '+44 (853) 263-6484');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Denton', 'Cody', '32709', 'M34', '+44 (237) 520-2378');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Sheffield', 'Sutteridge', '143', 'S1', '+44 (770) 426-3970');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Upton', 'Sunfield', '744', 'WF9', '+44 (890) 802-4631');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Kirkton', 'Rieder', '884', 'KW10', '+44 (849) 776-4658');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Halton', 'Harbort', '40714', 'LS9', '+44 (136) 417-4435');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Edinburgh', 'Blaine', '3099', 'EH9', '+44 (236) 726-5684');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Brampton', 'Sycamore', '87', 'NR34', '+44 (321) 736-6134');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Belfast', 'Fulton', '71', 'BT2', '+44 (374) 199-9719');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Newport', 'Hooker', '9809', 'NR29', '+44 (929) 334-5324');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Preston', 'Hagan', '53704', 'PR1', '+44 (320) 177-4005');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'London', 'Saint Paul', '73', 'EC1V', '+44 (455) 845-9322');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Merton', 'Bunker Hill', '504', 'SW19', '+44 (419) 306-9573');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Whitwell', 'Arapahoe', '1888', 'DL10', '+44 (403) 569-6030');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Bristol', 'Eagan', '757', 'BS41', '+44 (512) 655-1981');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Kingston', 'Artisan', '9', 'DT10', '+44 (173) 346-8013');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Middleton', 'Manufacturers', '3', 'LE16', '+44 (981) 542-6025');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Norton', 'Katie', '74510', 'NN11', '+44 (876) 735-9304');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Sutton', 'Calypso', '8904', 'RH5', '+44 (847) 509-3934');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Buckland', 'South', '40749', 'CT16', '+44 (520) 380-7056');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Walton', 'Blue Bill Park', '80275', 'CV35', '+44 (174) 480-8270');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Sutton', 'Corscot', '56594', 'CT15', '+44 (614) 408-6788');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Edinburgh', 'Sauthoff', '1283', 'EH9', '+44 (834) 627-6719');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Denton', 'Helena', '9', 'M34', '+44 (192) 341-4743');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Milton', 'Namekagon', '9741', 'AB56', '+44 (354) 576-4320');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Upton', 'Coleman', '64', 'WF9', '+44 (592) 947-0648');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Wirral', 'Grim', '38', 'CH48', '+44 (660) 269-7341');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Aberdeen', 'Rowland', '4', 'AB39', '+44 (669) 347-5613');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Leeds', 'Autumn Leaf', '5', 'LS6', '+44 (925) 812-9816');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'London', 'Transport', '99437', 'W1F', '+44 (391) 416-6348');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Liverpool', 'Crownhardt', '18', 'L74', '+44 (883) 949-2397');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Newton', 'Red Cloud', '638', 'NG34', '+44 (469) 704-4022');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Linton', 'Corry', '08622', 'BD23', '+44 (846) 118-3669');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'London', 'Huxley', '08', 'WC2H', '+44 (985) 813-5070');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Horton', 'Center', '47', 'BS37', '+44 (458) 631-8145');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Whitwell', 'Esker', '867', 'DL10', '+44 (499) 222-7684');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Church End', 'Farwell', '4', 'CB4', '+44 (934) 723-8165');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Burnside', 'Hoffman', '05897', 'EH52', '+44 (386) 289-9497');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Norton', 'Grover', '765', 'S8', '+44 (260) 319-4144');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Ashley', 'Sullivan', '53', 'SN13', '+44 (474) 928-8839');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Ford', 'Becker', '2', 'GL54', '+44 (408) 471-8673');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Newbiggin', 'Carioca', '43', 'NE46', '+44 (822) 836-0546');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Aberdeen', 'Fairfield', '2534', 'AB39', '+44 (265) 487-7519');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Sheffield', 'Fieldstone', '988', 'S1', '+44 (953) 374-9566');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Walton', 'Golf', '5939', 'CV35', '+44 (295) 157-3381');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Liverpool', 'Sherman', '4339', 'L33', '+44 (915) 439-0792');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Aston', 'Charing Cross', '69', 'TF6', '+44 (364) 375-8944');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Sutton', 'Arizona', '65', 'CT15', '+44 (280) 381-6301');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Walton', 'Stuart', '748', 'CV35', '+44 (685) 579-6440');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Newport', 'Lighthouse Bay', '9431', 'NR29', '+44 (323) 784-2926');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Wootton', 'Northport', '85', 'NN4', '+44 (620) 708-2114');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'London', 'Ludington', '583', 'WC2H', '+44 (306) 651-4863');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Liverpool', 'Portage', '0152', 'L33', '+44 (879) 482-3533');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Sheffield', 'Algoma', '987', 'S1', '+44 (113) 801-0627');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Swindon', 'Troy', '4604', 'SN1', '+44 (645) 753-3250');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Aberdeen', 'Maywood', '0', 'AB39', '+44 (870) 745-1169');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Walton', 'Monica', '88', 'CV35', '+44 (551) 338-8860');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Edinburgh', 'Fieldstone', '3', 'EH9', '+44 (337) 584-5837');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Manchester', 'Beilfuss', '7920', 'M14', '+44 (320) 312-8143');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Buckland', 'Crescent Oaks', '91973', 'CT16', '+44 (886) 815-9000');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Kingston', 'Anthes', '97209', 'DT10', '+44 (191) 628-8349');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Sutton', 'Esch', '7', 'CT15', '+44 (568) 954-9701');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Milton', 'Merchant', '7157', 'AB56', '+44 (677) 758-4795');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Liverpool', 'Logan', '387', 'L74', '+44 (720) 662-4122');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Manchester', 'Lukken', '54', 'M14', '+44 (813) 523-0900');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Upton', 'Novick', '772', 'WF9', '+44 (390) 724-6691');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'London', 'Laurel', '2', 'EC3M', '+44 (245) 516-4930');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Carlton', 'Golf View', '8690', 'DL8', '+44 (191) 979-3880');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Tullich', 'Hermina', '3486', 'AB55', '+44 (621) 832-1492');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'London', 'Village Green', '87', 'EC3M', '+44 (785) 736-4490');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Wootton', 'Sage', '35713', 'NN4', '+44 (628) 659-7884');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Newport', 'Waywood', '4', 'NR29', '+44 (320) 793-5440');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Manchester', 'Union', '9', 'M14', '+44 (522) 768-2548');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Hatton', 'Anniversary', '73', 'CV35', '+44 (901) 100-6748');
insert into UK_place (Country, City, Street_name, Street_number, Postal_code, Place_contact_number) values ('United Kingdom', 'Norton', 'Shasta', '9', 'S8', '+44 (158) 404-5512');


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
do $$
declare 
   counter integer := 0;
begin
	while counter < 1000 loop
		insert into Patient_Path values(
		(SELECT NHS_number FROM covid19_patients ORDER BY random() LIMIT 1),
		(SELECT Place_contact_number FROM UK_place ORDER BY random() LIMIT 1),
		(SELECT current_date - floor((random() * 30))::int rand_date));
		counter := counter + 1;
	end loop;

end$$;