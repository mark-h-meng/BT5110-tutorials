/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/* A0231906J                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/

/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* I have created three tables, including 'student', 'movie', and 'moviepreference',                         */
/* and use 'moviepreference' to linked up the other two tables.                                              */
/* The first table are informations of different students and I chose student's email to be the primary key  */
/* because every student has different email address.                                                        */
/* The second table: movie is a table that has a list of movie names, genre, movie language and ratings      */
/* and I chose the column 'movie', which stands for movie name, to be the primary key                        */
/* because the movie names in this table are all unique and not null.                                        */
/* The goal of this relational database is to see which students are into what kind of movie?                */
/* Therefore, the third table 'moviepreference' is to show the student's movie preference.                   */
/* The 'moviepreference' table contains two columns: emails of students(email) and movie names(movie).       */

/* The following codes is written for  PostgreSQL                                                            */

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE student (
	student_id VARCHAR(100),
	first_name VARCHAR(100)NOT NULL,
	last_name VARCHAR(100)NOT NULL,
	email VARCHAR(100)PRIMARY KEY,
	gender VARCHAR(50),
	Race VARCHAR(100),
	Department VARCHAR(100));

CREATE TABLE movie (
	movie VARCHAR(50)PRIMARY KEY,
	genres VARCHAR(50),
	language VARCHAR(50),
	country VARCHAR(50),
	ratings NUMERIC(2));

CREATE TABLE moviepreference (
	email VARCHAR(100),
	movie VARCHAR(100));

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('26-520-1758', 'Winfield', 'Briar', 'wbriar0@gnu.org', 'Female', 'Latin American Indian', 'Legal');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('31-984-0310', 'Forester', 'Crop', 'fcrop1@webnode.com', 'Non-binary', 'Asian', 'Research and Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('16-759-1961', 'Phoebe', 'Brosh', 'pbrosh2@pcworld.com', 'Genderfluid', 'Latin American Indian', 'Marketing');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('97-595-3378', 'Jayme', 'Kegley', 'jkegley3@dyndns.org', 'Non-binary', 'American Indian and Alaska Native (AIAN)', 'Engineering');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('34-395-9365', 'Val', 'Pechet', 'vpechet4@google.de', 'Genderqueer', 'Pakistani', 'Marketing');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('42-679-4186', 'Melicent', 'Flamank', 'mflamank5@odnoklassniki.ru', 'Male', 'Cherokee', 'Services');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('53-690-8473', 'Betti', 'Thirst', 'bthirst6@msn.com', 'Non-binary', 'Asian Indian', 'Services');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('50-775-9707', 'Cary', 'Geraudy', 'cgeraudy7@businesswire.com', 'Bigender', 'Chilean', 'Human Resources');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('41-591-5901', 'Christel', 'Gilluley', 'cgilluley8@ibm.com', 'Genderqueer', 'Asian', 'Marketing');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('46-194-8441', 'Nomi', 'Dunderdale', 'ndunderdale9@techcrunch.com', 'Genderqueer', 'Puget Sound Salish', 'Services');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('74-300-0039', 'Gregor', 'Blewitt', 'gblewitta@businessweek.com', 'Agender', 'Ute', 'Accounting');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('08-216-8241', 'Kimberly', 'Benthall', 'kbenthallb@boston.com', 'Male', 'Thai', 'Human Resources');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('17-779-1291', 'Grissel', 'Keilty', 'gkeiltyc@ibm.com', 'Polygender', 'Yakama', 'Services');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('19-702-3095', 'Shelli', 'Elsay', 'selsayd@printfriendly.com', 'Genderfluid', 'Laotian', 'Sales');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('80-349-5537', 'Carlotta', 'Dugdale', 'cdugdalee@issuu.com', 'Agender', 'Micronesian', 'Product Management');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('68-264-4146', 'Hobart', 'Guilloton', 'hguillotonf@simplemachines.org', 'Genderqueer', 'Potawatomi', 'Product Management');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('70-076-4669', 'Brod', 'Gannicott', 'bgannicottg@shinystat.com', 'Agender', 'Asian Indian', 'Services');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('42-905-6072', 'Shir', 'Toolan', 'stoolanh@hibu.com', 'Female', 'Argentinian', 'Research and Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('13-177-8197', 'Dulcia', 'Upstone', 'dupstonei@eepurl.com', 'Female', 'Venezuelan', 'Marketing');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('85-048-4691', 'Granger', 'Blowin', 'gblowinj@aol.com', 'Bigender', 'Colombian', 'Research and Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('04-133-6370', 'Beatrix', 'Heggadon', 'bheggadonk@virginia.edu', 'Genderfluid', 'American Indian and Alaska Native (AIAN)', 'Engineering');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('91-474-8579', 'Sherri', 'Gagie', 'sgagiel@census.gov', 'Agender', 'Native Hawaiian', 'Business Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('52-400-5033', 'Shurwood', 'Gilberthorpe', 'sgilberthorpem@canalblog.com', 'Polygender', 'Costa Rican', 'Engineering');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('42-464-9983', 'Vick', 'Slinger', 'vslingern@engadget.com', 'Polygender', 'Bolivian', 'Training');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('92-021-1517', 'Falkner', 'McComas', 'fmccomaso@mail.ru', 'Genderfluid', 'Cree', 'Business Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('11-710-4249', 'Alys', 'MacAlpine', 'amacalpinep@flavors.me', 'Genderqueer', 'Cuban', 'Research and Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('24-041-0225', 'Allyn', 'Maynell', 'amaynellq@java.com', 'Genderqueer', 'Choctaw', 'Business Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('47-682-8371', 'Giacopo', 'Swane', 'gswaner@over-blog.com', 'Genderfluid', 'Seminole', 'Sales');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('74-033-2805', 'Marcellus', 'Crum', 'mcrums@typepad.com', 'Polygender', 'Cherokee', 'Sales');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('77-778-0829', 'Lyman', 'Lovelady', 'lloveladyt@devhub.com', 'Non-binary', 'Eskimo', 'Human Resources');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('71-920-8446', 'Martha', 'McKeggie', 'mmckeggieu@uol.com.br', 'Polygender', 'Menominee', 'Engineering');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('96-028-8668', 'Tessa', 'Nesbitt', 'tnesbittv@seattletimes.com', 'Genderfluid', 'Delaware', 'Marketing');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('35-450-8906', 'Yul', 'Wickersham', 'ywickershamw@purevolume.com', 'Genderfluid', 'Micronesian', 'Training');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('33-906-4768', 'Giffy', 'Rivard', 'grivardx@domainmarket.com', 'Non-binary', 'Alaska Native', 'Product Management');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('09-423-0598', 'Morgen', 'Morfey', 'mmorfeyy@eepurl.com', 'Bigender', 'Chippewa', 'Accounting');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('49-852-5926', 'Barnard', 'Collyear', 'bcollyearz@pinterest.com', 'Female', 'Salvadoran', 'Product Management');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('83-683-4707', 'Ivar', 'Rowlings', 'irowlings10@salon.com', 'Polygender', 'Ute', 'Support');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('04-246-7075', 'Arvy', 'Stoakley', 'astoakley11@businessinsider.com', 'Bigender', 'Vietnamese', 'Research and Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('30-818-5692', 'Courtenay', 'Champneys', 'cchampneys12@globo.com', 'Female', 'Argentinian', 'Support');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('71-907-3510', 'Marcile', 'McCoish', 'mmccoish13@cyberchimps.com', 'Genderqueer', 'Pima', 'Research and Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('38-553-8460', 'Gertie', 'Boncoeur', 'gboncoeur14@economist.com', 'Non-binary', 'Venezuelan', 'Human Resources');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('21-687-6424', 'Dallas', 'Aslen', 'daslen15@networksolutions.com', 'Bigender', 'Native Hawaiian', 'Sales');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('38-332-4237', 'Andree', 'Pirkis', 'apirkis16@is.gd', 'Bigender', 'Yaqui', 'Marketing');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('26-111-0945', 'Andee', 'Rawkesby', 'arawkesby17@tuttocitta.it', 'Female', 'Yaqui', 'Research and Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('91-045-2691', 'Jelene', 'Brasse', 'jbrasse18@nps.gov', 'Bigender', 'Venezuelan', 'Engineering');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('51-505-8125', 'Kaleena', 'Wastling', 'kwastling19@ftc.gov', 'Agender', 'Cree', 'Training');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('30-607-6769', 'Alexio', 'Zarfati', 'azarfati1a@nba.com', 'Non-binary', 'Pakistani', 'Research and Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('91-100-4325', 'Gustie', 'Graine', 'ggraine1b@is.gd', 'Non-binary', 'Chickasaw', 'Services');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('05-262-5910', 'Alex', 'Austwick', 'aaustwick1c@noaa.gov', 'Bigender', 'Guatemalan', 'Marketing');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('40-859-7486', 'Trevar', 'Feldhuhn', 'tfeldhuhn1d@buzzfeed.com', 'Polygender', 'Native Hawaiian and Other Pacific Islander (NHPI)', 'Research and Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('01-746-4641', 'Pat', 'Espinheira', 'pespinheira1e@yellowbook.com', 'Genderfluid', 'Tongan', 'Human Resources');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('50-846-0319', 'Tades', 'Sudworth', 'tsudworth1f@storify.com', 'Agender', 'Eskimo', 'Accounting');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('84-666-0793', 'Ogdon', 'Corbould', 'ocorbould1g@clickbank.net', 'Agender', 'Filipino', 'Services');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('69-219-2737', 'Noellyn', 'Hambers', 'nhambers1h@constantcontact.com', 'Non-binary', 'Ute', 'Training');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('36-500-5111', 'Tremaine', 'Dodman', 'tdodman1i@privacy.gov.au', 'Genderfluid', 'Polynesian', 'Legal');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('19-806-2045', 'Clarinda', 'Pirot', 'cpirot1j@cbslocal.com', 'Non-binary', 'Choctaw', 'Research and Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('23-246-2487', 'Bartholomeo', 'Tomasek', 'btomasek1k@hexun.com', 'Male', 'Cambodian', 'Engineering');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('87-034-0216', 'Francoise', 'Vasnev', 'fvasnev1l@cornell.edu', 'Male', 'Sioux', 'Support');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('33-669-9290', 'Stanton', 'Dobby', 'sdobby1m@gov.uk', 'Bigender', 'Pueblo', 'Product Management');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('25-581-0961', 'Iormina', 'Chisholm', 'ichisholm1n@multiply.com', 'Male', 'Potawatomi', 'Training');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('99-441-9385', 'Bartholomeo', 'Gallone', 'bgallone1o@java.com', 'Genderqueer', 'American Indian', 'Support');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('80-908-7339', 'Wolfgang', 'Fullard', 'wfullard1p@people.com.cn', 'Female', 'Yuman', 'Human Resources');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('28-269-5155', 'Amabel', 'Janek', 'ajanek1q@businessinsider.com', 'Polygender', 'Shoshone', 'Legal');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('41-191-7392', 'Claudia', 'Haley', 'chaley1r@diigo.com', 'Agender', 'Sri Lankan', 'Research and Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('67-289-8310', 'Bogart', 'Sherwood', 'bsherwood1s@miibeian.gov.cn', 'Female', 'Native Hawaiian', 'Sales');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('22-293-5996', 'Fredra', 'Mcimmie', 'fmcimmie1t@technorati.com', 'Bigender', 'Colombian', 'Legal');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('39-582-3086', 'Duff', 'Achromov', 'dachromov1u@google.co.jp', 'Non-binary', 'Sioux', 'Legal');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('97-246-0110', 'Far', 'Lutzmann', 'flutzmann1v@unicef.org', 'Polygender', 'Hmong', 'Product Management');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('38-593-3406', 'Cindy', 'Janczak', 'cjanczak1w@archive.org', 'Genderfluid', 'American Indian and Alaska Native (AIAN)', 'Marketing');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('99-193-0907', 'Aubrey', 'Renfree', 'arenfree1x@surveymonkey.com', 'Genderqueer', 'Chickasaw', 'Training');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('14-502-0640', 'Adelina', 'Daniely', 'adaniely1y@123-reg.co.uk', 'Genderfluid', 'Paiute', 'Training');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('28-475-6282', 'Giraud', 'Pulhoster', 'gpulhoster1z@foxnews.com', 'Polygender', 'Creek', 'Services');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('34-893-0796', 'Lorenza', 'Du Hamel', 'lduhamel20@macromedia.com', 'Polygender', 'Sri Lankan', 'Legal');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('07-712-7064', 'Scarlett', 'Gomez', 'sgomez21@i2i.jp', 'Genderqueer', 'Pima', 'Research and Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('46-118-4579', 'Fraser', 'Cattonnet', 'fcattonnet22@paginegialle.it', 'Genderqueer', 'Yakama', 'Support');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('37-311-2618', 'Gaby', 'Shearston', 'gshearston23@mapy.cz', 'Agender', 'Latin American Indian', 'Engineering');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('52-643-9286', 'Nelli', 'Varndell', 'nvarndell24@who.int', 'Genderqueer', 'Houma', 'Marketing');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('48-067-1380', 'Marcie', 'Labern', 'mlabern25@soup.io', 'Genderqueer', 'Central American', 'Research and Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('86-283-7824', 'Sarita', 'Pryer', 'spryer26@tinypic.com', 'Male', 'Chickasaw', 'Research and Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('90-209-7981', 'Philipa', 'Gilchriest', 'pgilchriest27@newsvine.com', 'Male', 'Costa Rican', 'Marketing');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('33-567-5999', 'Gaby', 'Angerstein', 'gangerstein28@wikimedia.org', 'Agender', 'Yakama', 'Legal');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('24-947-1774', 'Diane-marie', 'Mates', 'dmates29@php.net', 'Agender', 'Black or African American', 'Business Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('40-970-4910', 'Renata', 'Niezen', 'rniezen2a@homestead.com', 'Female', 'Osage', 'Training');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('10-653-3696', 'Diana', 'Barks', 'dbarks2b@ask.com', 'Male', 'Tlingit-Haida', 'Business Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('52-332-8751', 'Mill', 'Edgars', 'medgars2c@timesonline.co.uk', 'Male', 'Native Hawaiian', 'Sales');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('43-531-4490', 'Lannie', 'Langthorn', 'llangthorn2d@live.com', 'Genderqueer', 'Creek', 'Marketing');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('60-085-3972', 'Kali', 'Bicker', 'kbicker2e@columbia.edu', 'Female', 'Iroquois', 'Services');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('30-859-5170', 'Di', 'Matyushkin', 'dmatyushkin2f@nytimes.com', 'Female', 'Seminole', 'Engineering');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('93-216-4047', 'Cacilia', 'Vergo', 'cvergo2g@nifty.com', 'Genderqueer', 'Ute', 'Sales');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('66-143-9469', 'Riley', 'Willan', 'rwillan2h@yellowbook.com', 'Male', 'Malaysian', 'Marketing');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('05-903-6264', 'Kylie', 'Belfit', 'kbelfit2i@cdc.gov', 'Genderfluid', 'Pueblo', 'Training');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('75-712-1599', 'Christoffer', 'Roland', 'croland2j@washington.edu', 'Male', 'Vietnamese', 'Human Resources');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('99-869-9640', 'Ambrosio', 'Evered', 'aevered2k@ehow.com', 'Bigender', 'American Indian and Alaska Native (AIAN)', 'Business Development');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('06-893-4440', 'Anatole', 'Haggleton', 'ahaggleton2l@hostgator.com', 'Male', 'Potawatomi', 'Marketing');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('78-792-3367', 'Merry', 'Richen', 'mrichen2m@zimbio.com', 'Polygender', 'Guatemalan', 'Sales');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('35-218-9555', 'Travis', 'Blackborow', 'tblackborow2n@alexa.com', 'Bigender', 'Chamorro', 'Services');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('64-574-9179', 'Udall', 'Malafe', 'umalafe2o@histats.com', 'Bigender', 'South American', 'Product Management');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('61-960-3261', 'Arlin', 'Birdsey', 'abirdsey2p@gnu.org', 'Non-binary', 'Guatemalan', 'Marketing');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('87-820-3156', 'Joni', 'Rubica', 'jrubica2q@forbes.com', 'Agender', 'Filipino', 'Engineering');
insert into student (student_id, first_name, last_name, email, gender, Race, Department) values ('67-986-2002', 'Graig', 'Lunney', 'glunney2r@jiathis.com', 'Genderfluid', 'Uruguayan', 'Business Development');


insert into movie (movie, genres, language, country, ratings) values ('Harley Davidson and the Marlboro Man', 'Action|Crime|Drama', 'Spanish', 'United States', 3);
insert into movie (movie, genres, language, country, ratings) values ('Paint Your Wagon', 'Comedy|Musical|Western', 'Finnish', 'China', 1);
insert into movie (movie, genres, language, country, ratings) values ('Blazing Saddles', 'Comedy|Western', 'Malayalam', 'China', 3);
insert into movie (movie, genres, language, country, ratings) values ('World''s Greatest Lover, The', 'Comedy', 'Ndebele', 'China', 2);
insert into movie (movie, genres, language, country, ratings) values ('Atonement', 'Drama|Romance|War', 'Norwegian', 'China', 10);
insert into movie (movie, genres, language, country, ratings) values ('Small Back Room, The', 'Romance|Thriller', 'Sotho', 'France', 1);
insert into movie (movie, genres, language, country, ratings) values ('Vääpeli Körmy ja kahtesti laukeava', 'Comedy|War', 'Dhivehi', 'China', 10);
insert into movie (movie, genres, language, country, ratings) values ('Jackass: The Movie', 'Action|Comedy|Documentary', 'Latvian', 'China', 4);
insert into movie (movie, genres, language, country, ratings) values ('Christmas Party, The (Joulubileet)', 'Comedy', 'Norwegian', 'China', 9);
insert into movie (movie, genres, language, country, ratings) values ('China Moon', 'Thriller', 'Somali', 'China', 6);
insert into movie (movie, genres, language, country, ratings) values ('Jane Eyre', 'Drama|Romance', 'Hebrew', 'Canada', 4);
insert into movie (movie, genres, language, country, ratings) values ('Korengal', 'Documentary|War', 'Portuguese', 'China', 2);
insert into movie (movie, genres, language, country, ratings) values ('National Lampoon''s Pucked', 'Comedy', 'Lao', 'China', 9);
insert into movie (movie, genres, language, country, ratings) values ('Arizona Dream', 'Comedy|Drama|Fantasy|Romance', 'Quechua', 'China', 10);
insert into movie (movie, genres, language, country, ratings) values ('Maxed Out: Hard Times, Easy Credit and the Era of Predatory Lenders', 'Documentary', 'Bosnian', 'China', 4);
insert into movie (movie, genres, language, country, ratings) values ('Capote', 'Crime|Drama', 'Persian', 'China', 8);
insert into movie (movie, genres, language, country, ratings) values ('Supermarket Woman (Sûpâ no onna)', 'Comedy', 'Dari', 'China', 9);
insert into movie (movie, genres, language, country, ratings) values ('WarGames', 'Drama|Sci-Fi|Thriller', 'Kyrgyz', 'France', 1);
insert into movie (movie, genres, language, country, ratings) values ('Tom Sawyer', 'Adventure|Children|Musical', 'Georgian', 'China', 7);
insert into movie (movie, genres, language, country, ratings) values ('Beverly Hills Chihuahua', 'Adventure|Children|Comedy', 'Indonesian', 'China', 6);
insert into movie (movie, genres, language, country, ratings) values ('Fourth Protocol, The', 'Thriller', 'Burmese', 'United States', 7);
insert into movie (movie, genres, language, country, ratings) values ('Long Ride Home, The', 'Romance|Western', 'Bislama', 'China', 3);
insert into movie (movie, genres, language, country, ratings) values ('My Little Pony: Equestria Girls', 'Animation|Children|Fantasy', 'Tetum', 'China', 1);
insert into movie (movie, genres, language, country, ratings) values ('3 Little Ninjas and the Lost Treasure', 'Action', 'Norwegian', 'France', 2);
insert into movie (movie, genres, language, country, ratings) values ('Ninja Cheerleaders', 'Action|Comedy', 'Dutch', 'France', 4);
insert into movie (movie, genres, language, country, ratings) values ('Hasty Heart, The', 'Drama', 'Amharic', 'China', 4);
insert into movie (movie, genres, language, country, ratings) values ('Out Late ', 'Documentary', 'Dzongkha', 'China', 1);
insert into movie (movie, genres, language, country, ratings) values ('When Evening Falls on Bucharest or Metabolism', '(no genres listed)', 'Belarusian', 'China', 5);
insert into movie (movie, genres, language, country, ratings) values ('Package, The', 'Action|Thriller', 'Tok Pisin', 'Mexico', 3);
insert into movie (movie, genres, language, country, ratings) values ('The Incident', 'Drama', 'Malagasy', 'China', 9);
insert into movie (movie, genres, language, country, ratings) values ('Get Over It', 'Comedy|Romance', 'Hiri Motu', 'China', 2);
insert into movie (movie, genres, language, country, ratings) values ('''71', 'Action|Drama|Thriller|War', 'Punjabi', 'China', 8);
insert into movie (movie, genres, language, country, ratings) values ('Cliffhanger', 'Action|Adventure|Thriller', 'Georgian', 'Mexico', 2);
insert into movie (movie, genres, language, country, ratings) values ('Strange Brew', 'Comedy', 'Croatian', 'United States', 9);
insert into movie (movie, genres, language, country, ratings) values ('Shirin', 'Drama', 'Tsonga', 'China', 10);
insert into movie (movie, genres, language, country, ratings) values ('Crime Lords of Tokyo', 'Documentary', 'Quechua', 'China', 2);
insert into movie (movie, genres, language, country, ratings) values ('Avventura, L'' (Adventure, The)', 'Drama|Mystery|Romance', 'Filipino', 'Canada', 4);
insert into movie (movie, genres, language, country, ratings) values ('Belles on Their Toes', 'Comedy', 'Oriya', 'China', 9);
insert into movie (movie, genres, language, country, ratings) values ('Hôtel des Invalides', 'Documentary', 'Tok Pisin', 'China', 9);
insert into movie (movie, genres, language, country, ratings) values ('Boricua''s Bond', 'Drama', 'French', 'China', 2);
insert into movie (movie, genres, language, country, ratings) values ('Dr. Dolittle 3', 'Children|Comedy|Fantasy', 'Icelandic', 'China', 4);
insert into movie (movie, genres, language, country, ratings) values ('Meatballs 4', 'Comedy', 'Lithuanian', 'China', 4);
insert into movie (movie, genres, language, country, ratings) values ('Puppet Master 4', 'Horror|Sci-Fi|Thriller', 'Mongolian', 'China', 10);
insert into movie (movie, genres, language, country, ratings) values ('Rose Tattoo, The', 'Drama|Romance', 'Hungarian', 'China', 3);
insert into movie (movie, genres, language, country, ratings) values ('Flight of Dragons, The', 'Adventure|Animation|Children|Drama|Fantasy', 'Tok Pisin', 'China', 7);
insert into movie (movie, genres, language, country, ratings) values ('Cast a Dark Shadow (Angel)', 'Thriller', 'Tok Pisin', 'United States', 1);
insert into movie (movie, genres, language, country, ratings) values ('Decline of the American Empire, The (Déclin de l''empire américain, Le)', 'Comedy|Drama', 'Tswana', 'China', 1);
insert into movie (movie, genres, language, country, ratings) values ('Quiet, The', 'Crime|Drama|Mystery|Thriller', 'German', 'Mexico', 7);
insert into movie (movie, genres, language, country, ratings) values ('Army of Shadows (L''armée des ombres)', 'Action|Drama|Thriller|War', 'Kyrgyz', 'China', 7);
insert into movie (movie, genres, language, country, ratings) values ('Cross My Heart', 'Comedy|Romance', 'Georgian', 'United States', 7);
insert into movie (movie, genres, language, country, ratings) values ('Cartoonist: Jeff Smith, BONE and the Changing Face of Comics, The', 'Documentary', 'Swahili', 'United States', 4);
insert into movie (movie, genres, language, country, ratings) values ('Welcome to Mooseport', 'Comedy', 'Fijian', 'China', 2);
insert into movie (movie, genres, language, country, ratings) values ('Star Wars: The Clone Wars', 'Action|Adventure|Animation|Sci-Fi', 'Greek', 'Canada', 2);
insert into movie (movie, genres, language, country, ratings) values ('Leafie, a Hen Into the Wild (Madangeul Naon Amtak)', 'Adventure|Animation|Drama', 'Norwegian', 'United States', 2);
insert into movie (movie, genres, language, country, ratings) values ('Dreamworld', 'Comedy|Drama|Romance', 'Somali', 'China', 3);
insert into movie (movie, genres, language, country, ratings) values ('Earthquake', 'Action|Drama|Thriller', 'Kashmiri', 'China', 1);
insert into movie (movie, genres, language, country, ratings) values ('High School', 'Comedy', 'Pashto', 'France', 3);
insert into movie (movie, genres, language, country, ratings) values ('Cellular', 'Action|Crime|Drama|Mystery|Thriller', 'Albanian', 'China', 5);
insert into movie (movie, genres, language, country, ratings) values ('Revenge of the Nerds II: Nerds in Paradise', 'Comedy', 'Macedonian', 'France', 5);
insert into movie (movie, genres, language, country, ratings) values ('Zatoichi and the Chess Expert (Zatôichi Jigoku tabi) (Zatôichi 12)', 'Action|Drama', 'Irish Gaelic', 'China', 2);
insert into movie (movie, genres, language, country, ratings) values ('Widows'' Peak', 'Drama', 'French', 'China', 3);
insert into movie (movie, genres, language, country, ratings) values ('When Willie Comes Marching Home', 'Comedy|War', 'Tajik', 'China', 5);
insert into movie (movie, genres, language, country, ratings) values ('Philomena', 'Comedy|Drama', 'Papiamento', 'China', 3);
insert into movie (movie, genres, language, country, ratings) values ('Consuming Spirits', 'Animation|Comedy|Drama|Mystery', 'West Frisian', 'China', 5);
insert into movie (movie, genres, language, country, ratings) values ('Wake in Providence, A', 'Comedy', 'Croatian', 'United States', 4);
insert into movie (movie, genres, language, country, ratings) values ('Rich Hill', 'Documentary', 'Filipino', 'China', 8);
insert into movie (movie, genres, language, country, ratings) values ('Last Stop for Paul', 'Comedy', 'French', 'China', 6);
insert into movie (movie, genres, language, country, ratings) values ('Cria! (Cría cuervos)', 'Drama|Mystery', 'Pashto', 'China', 7);
insert into movie (movie, genres, language, country, ratings) values ('Roger Dodger', 'Comedy|Drama', 'Oriya', 'China', 4);
insert into movie (movie, genres, language, country, ratings) values ('Born to Fight', 'Action|Children|Drama', 'New Zealand Sign Language', 'Canada', 2);
insert into movie (movie, genres, language, country, ratings) values ('After Alice (Eye of the Killer)', 'Crime|Drama|Mystery|Thriller', 'Mongolian', 'China', 8);
insert into movie (movie, genres, language, country, ratings) values ('Denise Calls Up', 'Comedy', 'Greek', 'China', 6);
insert into movie (movie, genres, language, country, ratings) values ('Alien Contamination', 'Action|Horror|Sci-Fi', 'Belarusian', 'France', 10);
insert into movie (movie, genres, language, country, ratings) values ('Paris, France', 'Comedy', 'Tajik', 'China', 6);
insert into movie (movie, genres, language, country, ratings) values ('Woman Chaser, The', 'Comedy', 'Amharic', 'China', 6);
insert into movie (movie, genres, language, country, ratings) values ('Parental Guidance', 'Comedy', 'Estonian', 'France', 1);
insert into movie (movie, genres, language, country, ratings) values ('Embrace of the Vampire', 'Horror|Thriller', 'Yiddish', 'China', 9);
insert into movie (movie, genres, language, country, ratings) values ('Rambo (Rambo 4)', 'Action|Drama|Thriller|War', 'Māori', 'China', 6);
insert into movie (movie, genres, language, country, ratings) values ('Quatermass Xperiment, The', 'Horror|Mystery|Sci-Fi|Thriller', 'Croatian', 'China', 2);
insert into movie (movie, genres, language, country, ratings) values ('Why Be Good?', 'Comedy|Romance', 'Danish', 'Canada', 5);
insert into movie (movie, genres, language, country, ratings) values ('I Know Where I''m Going!', 'Drama|Romance|War', 'Indonesian', 'France', 8);
insert into movie (movie, genres, language, country, ratings) values ('Next Day Air', 'Action|Comedy|Crime', 'Northern Sotho', 'United States', 6);
insert into movie (movie, genres, language, country, ratings) values ('Mary', 'Drama|Thriller', 'Estonian', 'China', 3);
insert into movie (movie, genres, language, country, ratings) values ('Upswing (Nousukausi)', 'Comedy|Drama', 'Tajik', 'China', 1);
insert into movie (movie, genres, language, country, ratings) values ('That''s Life!', 'Drama', 'Armenian', 'China', 10);
insert into movie (movie, genres, language, country, ratings) values ('Female Convict Scorpion: Jailhouse 41 (Joshuu sasori: Dai-41 zakkyo-bô)', 'Crime|Drama|Thriller', 'Marathi', 'Canada', 5);
insert into movie (movie, genres, language, country, ratings) values ('Thank You, Mr. Moto', 'Crime|Drama|Mystery', 'Arabic', 'Canada', 2);
insert into movie (movie, genres, language, country, ratings) values ('Bound by Honor (a.k.a. Blood In, Blood Out)', 'Action|Crime|Drama|Thriller', 'Maltese', 'China', 8);
insert into movie (movie, genres, language, country, ratings) values ('Charisma (Karisuma)', 'Drama', 'Latvian', 'China', 2);
insert into movie (movie, genres, language, country, ratings) values ('Brothers Grimm, The', 'Comedy|Fantasy|Horror|Thriller', 'Indonesian', 'Canada', 8);
insert into movie (movie, genres, language, country, ratings) values ('Dangerous Method, A', 'Drama|Thriller', 'Punjabi', 'China', 10);
insert into movie (movie, genres, language, country, ratings) values ('Single Shot, A', 'Crime|Drama|Film-Noir|Thriller', 'Gujarati', 'China', 4);
insert into movie (movie, genres, language, country, ratings) values ('Pixar Story, The', 'Documentary', 'Haitian Creole', 'China', 1);
insert into movie (movie, genres, language, country, ratings) values ('Machine Gun Kelly', 'Action|Crime', 'Malayalam', 'China', 8);
insert into movie (movie, genres, language, country, ratings) values ('Gone with the Wind', 'Drama|Romance|War', 'Swedish', 'China', 2);
insert into movie (movie, genres, language, country, ratings) values ('Gaucho, The', 'Adventure|Romance', 'Japanese', 'United States', 6);
insert into movie (movie, genres, language, country, ratings) values ('Oh, Sun (Soleil O)', 'Drama', 'Estonian', 'France', 10);
insert into movie (movie, genres, language, country, ratings) values ('Die Hard', 'Action|Crime|Thriller', 'Armenian', 'Mexico', 6);
insert into movie (movie, genres, language, country, ratings) values ('Cirque du Freak: The Vampire''s Assistant', 'Action|Adventure|Comedy|Fantasy|Horror|Thriller', 'Spanish', 'China', 9);
insert into movie (movie, genres, language, country, ratings) values ('Sade', 'Crime|Drama', 'Polish', 'China', 2);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO moviepreference
SELECT student.email, movie.movie FROM student, movie
ORDER BY RANDOM()
LIMIT 1000;
