/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL, version 13.3 */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* The chosen example consists of data from a beauty retailer (e.g Sephora).

Entity 1 will be a orders table containing order details such as which customer
ordered as user_id, the order_id, and when their order was made as created_as.

Entity 2 will be a products_inventory table containing inventory details such
as product_name, brand_name, and how much stock is available as units_remaining.

The many-to-many relationship is represented by items_in_order which associates
products being ordered with stock levels in the inventory. Unfortunately the system
does not have a constraint to prevent customers from ordering quantities larger than
available stock in the inventory.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE orders (
	order_id NUMERIC PRIMARY KEY UNIQUE,
	created_at DATE,
	user_id NUMERIC NOT NULL,
	country CHAR(64)
);

CREATE TABLE products_inventory (
	product_id NUMERIC,
	product_name CHAR(64) UNIQUE,
	brand_name CHAR(64),
	units_remaining NUMERIC CHECK (units_remaining >= 0),
	PRIMARY KEY(product_id, product_name, brand_name)
);

CREATE TABLE items_in_order (
	order_id NUMERIC,
	FOREIGN KEY(order_id) REFERENCES orders(order_id),
	product_id NUMERIC,
	product_name CHAR(64),
	brand CHAR(64),
	FOREIGN KEY(product_id, product_name, brand) REFERENCES products_inventory(product_id, product_name, brand_name)
		ON UPDATE CASCADE
		ON DELETE CASCADE,
	quantity NUMERIC NOT NULL CHECK (quantity > 0)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into orders (order_id, created_at, user_id, country) values ('2357757132', '13/01/2021', '0510816746', 'Armenia');
insert into orders (order_id, created_at, user_id, country) values ('8790551826', '09/08/2021', '6765461027', 'China');
insert into orders (order_id, created_at, user_id, country) values ('8339765531', '01/02/2021', '5701578046', 'Belarus');
insert into orders (order_id, created_at, user_id, country) values ('6811429003', '04/01/2021', '8818249495', 'China');
insert into orders (order_id, created_at, user_id, country) values ('3437245848', '02/07/2021', '4690550026', 'Indonesia');
insert into orders (order_id, created_at, user_id, country) values ('6198184293', '15/12/2020', '8199335513', 'Egypt');
insert into orders (order_id, created_at, user_id, country) values ('8395138512', '04/04/2021', '9487760369', 'Jamaica');
insert into orders (order_id, created_at, user_id, country) values ('5742458630', '04/02/2021', '0321279166', 'United Kingdom');
insert into orders (order_id, created_at, user_id, country) values ('2049594496', '23/02/2021', '0285640771', 'Philippines');
insert into orders (order_id, created_at, user_id, country) values ('9376454944', '11/05/2021', '0271683260', 'Philippines');
insert into orders (order_id, created_at, user_id, country) values ('7665512526', '25/04/2021', '8110506437', 'China');
insert into orders (order_id, created_at, user_id, country) values ('8501652806', '02/09/2020', '8630439408', 'France');
insert into orders (order_id, created_at, user_id, country) values ('5336169188', '03/02/2021', '0649775317', 'Russia');
insert into orders (order_id, created_at, user_id, country) values ('2809838240', '18/02/2021', '1725459582', 'Germany');
insert into orders (order_id, created_at, user_id, country) values ('8722037152', '31/08/2020', '2692450272', 'China');
insert into orders (order_id, created_at, user_id, country) values ('5893131274', '23/04/2021', '1039435564', 'Mongolia');
insert into orders (order_id, created_at, user_id, country) values ('2306221146', '20/03/2021', '1283894920', 'Ukraine');
insert into orders (order_id, created_at, user_id, country) values ('6475187739', '18/07/2021', '3119390461', 'China');
insert into orders (order_id, created_at, user_id, country) values ('6776306117', '22/09/2020', '0012426970', 'Pakistan');
insert into orders (order_id, created_at, user_id, country) values ('4482323837', '04/05/2021', '9180714463', 'Indonesia');
insert into orders (order_id, created_at, user_id, country) values ('3375926766', '28/10/2020', '3548736319', 'Tanzania');
insert into orders (order_id, created_at, user_id, country) values ('6796583779', '15/08/2021', '5698825556', 'Ethiopia');
insert into orders (order_id, created_at, user_id, country) values ('4611091031', '15/10/2020', '7782305144', 'Indonesia');
insert into orders (order_id, created_at, user_id, country) values ('9385927531', '23/12/2020', '1211688208', 'Russia');
insert into orders (order_id, created_at, user_id, country) values ('3634293381', '11/07/2021', '3205819195', 'Indonesia');
insert into orders (order_id, created_at, user_id, country) values ('5737489485', '13/10/2020', '3769414993', 'Argentina');
insert into orders (order_id, created_at, user_id, country) values ('2402776838', '19/04/2021', '6185846152', 'Indonesia');
insert into orders (order_id, created_at, user_id, country) values ('1485761050', '25/08/2020', '1405872500', 'Azerbaijan');
insert into orders (order_id, created_at, user_id, country) values ('6350186907', '19/07/2021', '6138494083', 'Philippines');
insert into orders (order_id, created_at, user_id, country) values ('8394345778', '19/04/2021', '2414174234', 'United States');
insert into orders (order_id, created_at, user_id, country) values ('0748920234', '05/02/2021', '4019193517', 'Bulgaria');
insert into orders (order_id, created_at, user_id, country) values ('1401657354', '17/11/2020', '0210836059', 'South Africa');
insert into orders (order_id, created_at, user_id, country) values ('0582914973', '07/12/2020', '1461705541', 'Portugal');
insert into orders (order_id, created_at, user_id, country) values ('6007984257', '19/10/2020', '5963662265', 'Peru');
insert into orders (order_id, created_at, user_id, country) values ('6045815483', '17/11/2020', '9633850053', 'Bulgaria');
insert into orders (order_id, created_at, user_id, country) values ('4938889978', '04/11/2020', '3658837551', 'Ukraine');
insert into orders (order_id, created_at, user_id, country) values ('5690376280', '29/12/2020', '5452737650', 'Russia');
insert into orders (order_id, created_at, user_id, country) values ('1752129938', '27/08/2020', '2815935988', 'Laos');
insert into orders (order_id, created_at, user_id, country) values ('6464052993', '23/07/2021', '3459324287', 'Brazil');
insert into orders (order_id, created_at, user_id, country) values ('2383425958', '20/01/2021', '2007691787', 'China');
insert into orders (order_id, created_at, user_id, country) values ('9539463971', '27/05/2021', '2646898231', 'Malaysia');
insert into orders (order_id, created_at, user_id, country) values ('2193169519', '04/02/2021', '6903035567', 'China');
insert into orders (order_id, created_at, user_id, country) values ('2811443053', '20/08/2021', '8124945403', 'Saudi Arabia');
insert into orders (order_id, created_at, user_id, country) values ('2873478136', '31/03/2021', '7936738282', 'Egypt');
insert into orders (order_id, created_at, user_id, country) values ('8802888221', '06/06/2021', '4194242947', 'China');
insert into orders (order_id, created_at, user_id, country) values ('3292369290', '31/08/2020', '7110368998', 'Ukraine');
insert into orders (order_id, created_at, user_id, country) values ('1602206198', '25/07/2021', '6433490506', 'Indonesia');
insert into orders (order_id, created_at, user_id, country) values ('2012839924', '18/04/2021', '7271873317', 'France');
insert into orders (order_id, created_at, user_id, country) values ('0189966033', '08/01/2021', '3882696540', 'Syria');
insert into orders (order_id, created_at, user_id, country) values ('2701556848', '28/06/2021', '0443083711', 'Japan');
insert into orders (order_id, created_at, user_id, country) values ('0262314290', '14/02/2021', '6218503658', 'Pakistan');
insert into orders (order_id, created_at, user_id, country) values ('0921387873', '07/10/2020', '5015594828', 'Australia');
insert into orders (order_id, created_at, user_id, country) values ('9519006974', '20/08/2021', '9242139874', 'Czech Republic');
insert into orders (order_id, created_at, user_id, country) values ('7870048976', '17/02/2021', '4099441962', 'Chad');
insert into orders (order_id, created_at, user_id, country) values ('5428572671', '16/10/2020', '3489348001', 'Malaysia');
insert into orders (order_id, created_at, user_id, country) values ('3232466621', '03/04/2021', '5075894003', 'Greece');
insert into orders (order_id, created_at, user_id, country) values ('5048320905', '19/06/2021', '0280609264', 'China');
insert into orders (order_id, created_at, user_id, country) values ('9387411958', '29/12/2020', '2722526948', 'United Kingdom');
insert into orders (order_id, created_at, user_id, country) values ('8914938131', '19/11/2020', '2519263598', 'China');
insert into orders (order_id, created_at, user_id, country) values ('7667425175', '29/07/2021', '5724124742', 'Gabon');
insert into orders (order_id, created_at, user_id, country) values ('7037962104', '14/12/2020', '8244933461', 'Mexico');
insert into orders (order_id, created_at, user_id, country) values ('4329787431', '31/08/2020', '7846003135', 'China');
insert into orders (order_id, created_at, user_id, country) values ('3579692127', '20/08/2021', '4085590189', 'China');
insert into orders (order_id, created_at, user_id, country) values ('8601882706', '16/02/2021', '3539866728', 'Greece');
insert into orders (order_id, created_at, user_id, country) values ('6497906541', '07/02/2021', '0970492782', 'Brazil');
insert into orders (order_id, created_at, user_id, country) values ('4502261475', '19/02/2021', '5943691405', 'Ukraine');
insert into orders (order_id, created_at, user_id, country) values ('1001369815', '17/06/2021', '3378035730', 'Indonesia');
insert into orders (order_id, created_at, user_id, country) values ('4741619656', '24/05/2021', '1251331599', 'Japan');
insert into orders (order_id, created_at, user_id, country) values ('3633318836', '13/10/2020', '6114982495', 'Democratic Republic of the Congo');
insert into orders (order_id, created_at, user_id, country) values ('1288388322', '02/07/2021', '4500196064', 'United States');
insert into orders (order_id, created_at, user_id, country) values ('6104361722', '27/11/2020', '6837097032', 'Indonesia');
insert into orders (order_id, created_at, user_id, country) values ('2764625065', '11/04/2021', '7236727946', 'Canada');
insert into orders (order_id, created_at, user_id, country) values ('0673268780', '11/10/2020', '7659365193', 'Palestinian Territory');
insert into orders (order_id, created_at, user_id, country) values ('4110065100', '02/03/2021', '2859209921', 'Suriname');
insert into orders (order_id, created_at, user_id, country) values ('9868510635', '24/02/2021', '5307619502', 'Russia');
insert into orders (order_id, created_at, user_id, country) values ('9110475656', '12/11/2020', '9420797635', 'China');
insert into orders (order_id, created_at, user_id, country) values ('8902395588', '13/10/2020', '6086447969', 'Germany');
insert into orders (order_id, created_at, user_id, country) values ('5381730276', '18/12/2020', '3583979486', 'Israel');
insert into orders (order_id, created_at, user_id, country) values ('3432637993', '04/03/2021', '3599290016', 'Indonesia');
insert into orders (order_id, created_at, user_id, country) values ('9907200999', '11/02/2021', '4947317973', 'France');
insert into orders (order_id, created_at, user_id, country) values ('6341791011', '06/07/2021', '5657099133', 'France');
insert into orders (order_id, created_at, user_id, country) values ('6262115625', '13/09/2020', '7873482286', 'Russia');
insert into orders (order_id, created_at, user_id, country) values ('9602342838', '04/01/2021', '1991219598', 'United States');
insert into orders (order_id, created_at, user_id, country) values ('7064926911', '31/03/2021', '6822079416', 'Denmark');
insert into orders (order_id, created_at, user_id, country) values ('6442999823', '21/09/2020', '1497965969', 'China');
insert into orders (order_id, created_at, user_id, country) values ('3951321423', '15/11/2020', '2041310669', 'China');
insert into orders (order_id, created_at, user_id, country) values ('4038731464', '26/06/2021', '1862920141', 'China');
insert into orders (order_id, created_at, user_id, country) values ('5397432202', '24/08/2020', '7694347996', 'Indonesia');
insert into orders (order_id, created_at, user_id, country) values ('5812548641', '20/09/2020', '8875206244', 'Nigeria');
insert into orders (order_id, created_at, user_id, country) values ('8027243866', '24/05/2021', '1681150360', 'United States');
insert into orders (order_id, created_at, user_id, country) values ('7489959551', '01/11/2020', '5072498743', 'China');
insert into orders (order_id, created_at, user_id, country) values ('2228610755', '22/12/2020', '8080919216', 'China');
insert into orders (order_id, created_at, user_id, country) values ('5245709996', '30/05/2021', '3470708223', 'Sweden');
insert into orders (order_id, created_at, user_id, country) values ('5648173768', '16/01/2021', '5779520186', 'China');
insert into orders (order_id, created_at, user_id, country) values ('2144888728', '21/03/2021', '3843753423', 'Iran');
insert into orders (order_id, created_at, user_id, country) values ('3563350310', '17/12/2020', '3611410535', 'Brazil');
insert into orders (order_id, created_at, user_id, country) values ('1618995227', '08/05/2021', '7959291454', 'Poland');
insert into orders (order_id, created_at, user_id, country) values ('6841053877', '14/08/2021', '7389605812', 'Yemen');
insert into orders (order_id, created_at, user_id, country) values ('0235441015', '14/02/2021', '8471989948', 'Indonesia');
insert into orders (order_id, created_at, user_id, country) values ('7053282783', '22/09/2020', '4382707765', 'Bosnia and Herzegovina');

insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('4675490018', 'All Nighter Long-Lasting Makeup Setting Spray', 'Urban Decay', '2104');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('4482519294', 'Super Shock Pressed Pigments', 'Colour Pop', '40523');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('6045659309', 'Powder Bronzer', 'Jordana', '42');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('5825308547', 'Makeup Clutch Eyebrow Powder', 'e.l.f.', '4');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('7883508628', 'Smooth Focus Pressed Setting Powder - Shine Control', 'Laura Mercier', '630');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('5942153221', 'Cushion Glossy Eyeliner', 'Sephora', '5976');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('6171948497', 'Radiant Glow Illuminator', 'Divergent', '06825');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('8276985548', 'Charlotte Olympia Cream Colour Base', 'MAC', '091');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('7643436118', 'Stormy', 'Sugarpill', '5');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('9173872415', 'Color Splurge Eye Satin Matte Duo', 'Black Opal', '8502');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1049269195', 'Naked Honey', 'MAC', '485');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('6589927081', 'Face & Body Scrub', 'md formulations', '16644');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('4364156353', 'Pressed', 'Paula Dorf', '2');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1666544620', 'Mini Tweezer Set', 'Revlon', '6');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('2003343350', 'Eyeshadow Palette', 'Chanel', '194');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('0542513595', 'EverStrong Sulfate-Free Fortify System Hydrate Shampoo', 'L''Oreal', '5361');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1198816589', 'Magnifique French Manicure Topcoat', 'ORLY', '1664');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('8474808928', 'Perfectly Clean Splash Away Foaming Cleanser', 'Estee Lauder', '0');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('7115027250', 'All In One 3 Way Glaze', 'Essie', '5715');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('0459090097', 'Highlighting Powder', 'Rouge Bunny Rouge', '2');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1801159114', 'Mineral Mineral Glow', 'e.l.f.', '649');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('3729859382', 'Flat Round Blush 156 Brush', 'Make Up For Ever', '17893');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1943609810', 'Clear Lash Mascara', 'e.l.f.', '28');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1694243753', 'Perfection Lumiere Velvet SPF 15', 'Chanel', '2');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('0531039331', 'Sport for Women', 'Burberry', '90365');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('5658418445', 'A22 Pointed Cheek Brush', 'Anastasia', '16313');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('3007142423', 'Define & Tame Brow Perfecting Gel', 'Laura Geller', '311');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('5635436552', 'Master Glaze', 'Maybelline', '05');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('4580646398', 'Angled Foundation Brush', 'e.l.f.', '27862');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('3254697243', 'Angled Shadow Brush', 'Sephora', '0');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('7012857366', 'L''Absolu Nu', 'Lancome', '5555');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('9749699637', 'Contoured Eyelash Comb', 'Sephora', '02');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('7444482098', 'Studio Nail Lacquer', 'MAC', '1287');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('3676366360', 'Powder Brush #15', 'BH Cosmetics', '95675');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('3874444686', 'Blush Palette', 'Viseart', '5');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('6951081700', 'Kick Ass Blur & Brighten Concealer Crayon', 'Soap and Glory', '2191');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('4563624764', 'Sculpting Blush', 'Make Up For Ever', '76756');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('3934037836', 'Waterproof Eye Crayon', 'BH Cosmetics', '6272');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('4805869585', 'Color Splurge Patent Lips', 'Black Opal', '37');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('6687136410', 'Double Extend Beauty Tubes', 'L''Oreal', '243');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('8227742521', 'EmphasEYES Inner Rim Brightener', 'Tarte', '9074');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('3205718968', 'Bienfait Multi-Vital Eye SPF 28', 'Lancome', '4545');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('9652371599', 'Jewel Eyeshadow Palette', 'Tarina Tarantino', '6');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('5257555549', 'Parure de Lumiere', 'Guerlain', '62002');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('2014884498', 'MAJOR Major Lash Mascara', 'Stila', '16');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('3770569563', 'Color Icon Eyeshadow', 'Giorgio Armani', '49');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1931303193', 'Fine Liner 315', 'Zoeva', '266');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('4578884880', 'Ultimate Lip Spackle', 'Laura Geller', '78');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('8957195505', 'Intensive Repair Extra-Enriched Hand CrÃ¨me', 'Eucerin', '99');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('7437613891', 'Translucent Loose Powder', 'Inglot', '33170');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('6690991792', 'Color Liner', 'Make Up For Ever', '22');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('7912003444', 'Baume Gloss', 'Givenchy', '3224');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('4684308758', 'Flash Dry Quick-Dry High Shine Drops', 'ORLY', '2');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('6871872701', 'Quad Royale', 'Edward Bess', '359');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('2365962580', 'Cream-To-Powder', 'Milani', '2059');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('5514066193', 'Aqua Brow', 'Make Up For Ever', '738');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('6388592171', 'Powerchrome Eye Pencil', 'MAC', '09537');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('2075817618', 'Wonderful Cushion Matte Lip Cream', 'Sephora', '620');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('9753008600', 'Alcohol-Free Face Toner For Normal to Dry Skin', 'theBalm', '7');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1349727970', 'Duraline', 'Inglot', '0535');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('8582948344', 'Hypnose Star', 'Lancome', '032');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('8778582474', 'Contouring Cheek Color Duo', 'Tom Ford Beauty', '407');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('5458136195', 'Luxe Complete Set', 'Zoeva', '85');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('0073620866', 'Asphalt Flower', 'MAC', '2');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('5585962779', 'Body Excellence Firming and Rejuvenating Cream', 'Chanel', '2');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('7280404162', 'Amazonian Clay Collector''s Palette (Summer 2015)', 'Tarte', '6216');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('2440593583', 'Liquid Eyeliner', 'Guerlain', '8');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('8731614620', 'Hyaluronic Blush', 'By Terry', '31');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('3874392031', 'UV Protective Liquid Foundation SPF 42', 'Shiseido', '5759');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1721486690', 'Tube Tint', 'Bobbi Brown', '5');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('7009510911', 'No 8 Large Concealer', 'Hourglass', '03');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('0687818362', 'Ideal Light', 'Estee Lauder', '7');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('6146891797', 'Purifying Toning Lotion', 'Dior', '5');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('3869414855', 'Angled Radiance CrÃ¨me Brush', 'IT Cosmetics', '839');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1404886052', 'Smooth Operator Amazonian Clay Finishing Powder', 'Tarte', '1');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('4154796518', 'Lip Concealer Brush #10', 'BH Cosmetics', '5936');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('3636106406', 'Dramatic Lash Kit', 'e.l.f.', '80');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('5844123530', 'Eye Color Applicators', 'e.l.f.', '4');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('4076218825', 'Glamoflauge', 'Hard Candy', '02');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('0067987567', '1 Lash', 'MAC', '4');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('7384426200', 'Concealer Medium 176 Brush', 'Make Up For Ever', '5');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('2610309767', 'White Patchouli', 'Tom Ford Beauty', '299');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('8211776081', 'Oval Detailer #7', 'Nubar', '3399');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('6491791815', 'Aqua Allegoria Jasminora', 'Guerlain', '04');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('3186660785', 'Mineral Powder Brush', 'e.l.f.', '7694');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1437501389', 'Pure Argan Milk Intensive Hydrating Treatment', 'Josie Maran', '3');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1521009112', 'Custom Cover Drops', 'Cover FX', '7484');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1242769773', 'Huggable Lipcolour', 'MAC', '6');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('0425316920', 'Laque Brilliance Extreme Extreme Shine Nail Lacquer', 'Chanel', '54063');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1585501298', 'Daily Clarifying Treatment Oil', 'Jouer', '162');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('9245163806', 'Vive Pro Hydra Gloss Moisturizing Shampoo for Dry Hair', 'L''Oreal', '52851');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('4585741410', 'Tone Perfecting Eye Gel CrÃ¨me', 'Laura Mercier', '44');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('4892731838', 'Big & Healthy Lip Cream', 'Buxom', '88139');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('3737986061', 'Studio Line Overworked Hair Putty', 'L''Oreal', '87');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('7845588962', 'Face Brush', 'Laura Mercier', '1');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('9382157794', 'Moderniste Lip Pencil', 'Surratt Beauty', '1');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('1070734454', 'Parure Gold Gold Radiance Foundation SPF 34', 'Guerlain', '092');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('2135326887', 'Tweezer Slant Tip', 'Revlon', '94');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('4811010108', '3-in-1 Extractor', 'Sephora', '6');
insert into products_inventory (product_id, product_name, brand_name, units_remaining) values ('9706305386', 'Hyaluronic Hydra-Primer', 'By Terry', '7408');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO items_in_order(order_id, product_id, product_name, brand, quantity)
SELECT o.order_id, pi.product_id, pi.product_name, pi.brand_name, ROUND(RANDOM()*(100-1+1)+1)
FROM orders o, products_inventory pi
WHERE RANDOM() < 0.1;
