/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
This database is a simplified version of a database for a job hunting platform. 
It has three tables - "candidates", "jobs" and "application" - to store the data of its individual and corporate users.
Table "candidates" stores each user's first_name, last_name, dob, skills, email and their 4-digit unique applicant identifier assigned by the platform. 
Table "Jobs" stores data regarding recuriting companies' name and city as well as their available jobs' title and salary. 
A company may have offices in different cities but the same company in the same city should has only one job title posted in the platform.
Last but not least, "application" table records the detailed information about the company, city and job title each candidate has applied for.
The code is written for PostgreSQL.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS CANDIDATES(
  applicant_id CHAR(16) PRIMARY KEY, 
  first_name VARCHAR(64) NOT NULL, 
  last_name VARCHAR(64) NOT NULL, 
  email VARCHAR(64) UNIQUE NOT NULL, 
  dob DATE NOT NULL, 
  skills VARCHAR(64) NOT NULL
);
CREATE TABLE IF NOT EXISTS JOBS(
  company VARCHAR(64) NOT NULL, 
  job_title VARCHAR(64) NOT NULL, 
  salary NUMERIC NOT NULL, 
  city VARCHAR(64) NOT NULL, 
  PRIMARY KEY (company, job_title,city)
);
CREATE TABLE application(
  applicant_id VARCHAR(16) REFERENCES CANDIDATES(applicant_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED, 
  company VARCHAR(64), 
  job_title VARCHAR(64), 
  city VARCHAR(64),
  PRIMARY KEY (applicant_id, company, job_title,city), 
  FOREIGN KEY (company, job_title,city) REFERENCES JOBS(company, job_title,city) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED
);


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (8727, 'Parrnell', 'Goodbarr', 'pgoodbarr0@shop-pro.jp', '1988-08-21', 'DC Circuits');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (9613, 'Eustace', 'Hungerford', 'ehungerford1@foxnews.com', '1993-03-14', 'Corporate Real Estate');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (3133, 'Tiffani', 'Hannigane', 'thannigane2@lulu.com', '1993-08-10', 'DVB-S');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (6198, 'Meggy', 'Nodin', 'mnodin3@walmart.com', '1996-11-28', 'WSIB');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (2924, 'Megen', 'Vorley', 'mvorley4@blogtalkradio.com', '1993-09-23', 'SNOMED');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (2373, 'Florry', 'Rosenzveig', 'frosenzveig5@cnet.com', '1988-07-21', 'LCD TV');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (1733, 'Siward', 'Poutress', 'spoutress6@mlb.com', '1997-12-28', 'ETL Tools');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (9004, 'Ximenes', 'Saffrin', 'xsaffrin7@bloomberg.com', '1985-07-23', 'NCIDQ');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (3599, 'Tobye', 'Attwood', 'tattwood8@edublogs.org', '1992-04-28', 'Affirmative Action');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (5008, 'Tades', 'Tricker', 'ttricker9@behance.net', '1995-03-09', 'Digital Marketing');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (9825, 'Fritz', 'Detloff', 'fdetloffa@arizona.edu', '1991-09-21', 'XMind');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7828, 'Addy', 'Reiach', 'areiachb@dot.gov', '1995-02-16', 'NDA');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (1674, 'Margery', 'Verrill', 'mverrillc@webeden.co.uk', '1991-05-25', 'Peer Tutoring');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (5629, 'Ewell', 'Natalie', 'enatalied@bbb.org', '1999-01-07', 'Routing');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (6661, 'Kayley', 'Lubman', 'klubmane@marketwatch.com', '1991-06-22', 'RED MX');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (6834, 'Meir', 'Whibley', 'mwhibleyf@princeton.edu', '1986-09-10', 'Yeast two-hybrid');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7324, 'Ogden', 'Emeny', 'oemenyg@gov.uk', '1993-03-14', 'HTML Help Workshop');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (3185, 'Brandice', 'Pentycost', 'bpentycosth@stanford.edu', '1994-04-06', 'JFace');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (8207, 'Jedidiah', 'Trippack', 'jtrippacki@businesswire.com', '1996-07-23', 'OEE');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7539, 'Mycah', 'McElmurray', 'mmcelmurrayj@pbs.org', '1997-04-13', 'Sports Injuries');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7415, 'Leilah', 'Diviney', 'ldivineyk@elegantthemes.com', '1997-04-10', 'Allergic Rhinitis');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7474, 'Freeman', 'Raddin', 'fraddinl@statcounter.com', '1986-09-04', 'HPLC');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7527, 'Terrell', 'Djekovic', 'tdjekovicm@adobe.com', '1986-12-11', 'Natural Resources');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (5561, 'Field', 'Dufoure', 'fdufouren@odnoklassniki.ru', '1985-12-24', 'Aircraft');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (5611, 'Roch', 'Flintoffe', 'rflintoffeo@cnbc.com', '1990-02-02', 'IBM BPM');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (2037, 'Erminie', 'Kupis', 'ekupisp@wikipedia.org', '1998-01-15', 'Gyrotonic');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7723, 'Frederic', 'Giacometti', 'fgiacomettiq@addtoany.com', '1993-01-12', 'XHTML');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (8852, 'Daveta', 'Akker', 'dakkerr@tumblr.com', '1996-07-24', 'QHSE');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (9807, 'Essy', 'Deluce', 'edeluces@google.fr', '1993-12-20', 'Brand Development');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (1028, 'Minnie', 'Busch', 'mbuscht@facebook.com', '1996-10-21', 'SVOD');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (4729, 'Chelsy', 'Rann', 'crannu@amazon.co.uk', '1996-04-19', 'Epoxy');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (6224, 'Maitilde', 'Stoffers', 'mstoffersv@deliciousdays.com', '1991-12-25', 'QS1');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (8593, 'Fabien', 'Millwater', 'fmillwaterw@feedburner.com', '1997-04-16', 'BPMN');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (1912, 'Dodie', 'Mellem', 'dmellemx@php.net', '1991-09-12', 'Affordable Housing');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (3143, 'Leontyne', 'Sandham', 'lsandhamy@alexa.com', '1994-09-16', 'NDDS');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (8050, 'Hamilton', 'Sawnwy', 'hsawnwyz@stanford.edu', '1996-11-11', 'Digital Strategy');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (6578, 'Reid', 'Tesche', 'rtesche10@indiatimes.com', '1988-03-20', 'Administration');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (3396, 'Lucinda', 'Tower', 'ltower11@last.fm', '1990-12-07', 'SAP SD Module');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (2947, 'Wittie', 'Flatley', 'wflatley12@biblegateway.com', '1998-01-30', 'CMM');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (6418, 'Laure', 'Soppit', 'lsoppit13@wix.com', '1992-06-14', 'DNV');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (3184, 'Derrek', 'Boyn', 'dboyn14@scientificamerican.com', '1987-11-28', 'Judicial Review');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (1956, 'Adela', 'Audry', 'aaudry15@usatoday.com', '1997-10-02', 'National Association of Realtors');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (9965, 'Zenia', 'Thursfield', 'zthursfield16@sitemeter.com', '1996-10-17', 'JMX');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (5682, 'Frayda', 'Masser', 'fmasser17@wordpress.com', '1986-05-21', 'Lynx');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7731, 'Dorotea', 'Allman', 'dallman18@netlog.com', '1994-06-10', 'Registered Nurses');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (8623, 'Mariejeanne', 'Stallion', 'mstallion19@yelp.com', '1994-12-17', 'Judicial Review');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7058, 'Jefferson', 'Kenefick', 'jkenefick1a@youku.com', '1999-04-06', 'GDI+');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (1139, 'Myrwyn', 'Jodkowski', 'mjodkowski1b@cisco.com', '1987-06-05', 'ArcGIS');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7114, 'Adriaens', 'Warsop', 'awarsop1c@drupal.org', '1997-12-19', 'Working Capital Management');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (5693, 'Appolonia', 'Lenaghen', 'alenaghen1d@house.gov', '1994-08-29', 'CICS');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (3293, 'Rodina', 'Toolan', 'rtoolan1e@msn.com', '1985-08-07', 'System Administration');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (9918, 'Maury', 'Matteotti', 'mmatteotti1f@sohu.com', '1997-01-12', 'CCIE');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (8777, 'Dulcia', 'Harvard', 'dharvard1g@plala.or.jp', '1996-05-13', 'OOH');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (5258, 'Susann', 'Stemp', 'sstemp1h@mysql.com', '1986-01-15', 'Project Estimation');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (3631, 'Hashim', 'Hearons', 'hhearons1i@jiathis.com', '1985-01-28', 'XMetal');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (2505, 'Allx', 'Methuen', 'amethuen1j@nih.gov', '1994-03-31', 'MBS');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (9333, 'Ryley', 'Cabena', 'rcabena1k@abc.net.au', '1991-12-10', 'GSP');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (2075, 'Nariko', 'Jeacock', 'njeacock1l@odnoklassniki.ru', '1985-08-20', 'SAP XI');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (8294, 'Ruthy', 'Edgin', 'redgin1m@google.com.au', '1994-09-12', 'SQR');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (4537, 'Dennie', 'Marquess', 'dmarquess1n@yahoo.com', '1986-06-14', 'SMTP');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7573, 'Shem', 'Beere', 'sbeere1o@dropbox.com', '1987-10-09', 'Video Production');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (9281, 'Friedrich', 'Carverhill', 'fcarverhill1p@jalbum.net', '1996-10-13', 'CQC');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (8756, 'Katerine', 'Iamittii', 'kiamittii1q@wikipedia.org', '1992-01-01', 'MM modules');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (5420, 'Zaneta', 'Govinlock', 'zgovinlock1r@sina.com.cn', '1993-10-16', 'Service Delivery');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7991, 'Conway', 'Lightwood', 'clightwood1s@mlb.com', '1989-03-27', 'SNAP');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (5398, 'Elihu', 'Gianullo', 'egianullo1t@nyu.edu', '1985-09-24', 'QMF');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (8128, 'Hollis', 'Stubbs', 'hstubbs1u@mac.com', '1996-11-29', 'PNR');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (2534, 'Tedman', 'Conradsen', 'tconradsen1v@etsy.com', '1989-09-21', 'IEC 61131-3');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (3625, 'Jody', 'Schulze', 'jschulze1w@disqus.com', '1988-04-08', 'TMN');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (9697, 'Nelson', 'Dobble', 'ndobble1x@umn.edu', '1999-10-14', 'OLEDs');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7053, 'Karlotte', 'Hartegan', 'khartegan1y@free.fr', '1996-03-28', 'IGRP');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (3091, 'Bren', 'Stopps', 'bstopps1z@go.com', '1990-11-05', 'Church Growth');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7395, 'Eleanore', 'Duckerin', 'educkerin20@nih.gov', '1996-04-22', 'Resume Writing');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (1475, 'Karita', 'Ruby', 'kruby21@ovh.net', '1997-04-25', 'Yields');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (6849, 'Lara', 'Duncanson', 'lduncanson22@imageshack.us', '1988-03-28', 'CNG');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (9912, 'Darius', 'Binestead', 'dbinestead23@cbsnews.com', '1999-11-24', 'Loans');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7215, 'Drucie', 'Snaith', 'dsnaith24@myspace.com', '1987-01-16', 'APO SNP');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7992, 'Silvanus', 'MacIver', 'smaciver25@livejournal.com', '1987-03-14', 'PnL Management');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7978, 'Shelly', 'Rama', 'srama26@webs.com', '1997-04-30', 'Tax Accounting');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (5137, 'Idette', 'Zealey', 'izealey27@baidu.com', '1987-11-30', 'Employment Law');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (5519, 'Heinrik', 'Townend', 'htownend28@printfriendly.com', '1987-07-31', 'Interpersonal Skills');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (6705, 'Diana', 'Bangley', 'dbangley29@oakley.com', '1995-12-03', 'Patient Safety');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (5251, 'Mariana', 'Vala', 'mvala2a@soup.io', '1990-06-15', 'Higher Education');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (4614, 'Silvie', 'Folland', 'sfolland2b@imdb.com', '1995-07-24', 'Aerodynamics');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (9515, 'Osbourne', 'Challes', 'ochalles2c@ask.com', '1993-05-15', 'Business Aviation');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (5844, 'Konrad', 'Singyard', 'ksingyard2d@icq.com', '1997-07-24', 'Lead Generation');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (4804, 'Kathleen', 'Folley', 'kfolley2e@reddit.com', '1985-09-08', 'Kernel Programming');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (1422, 'Cassius', 'Boundley', 'cboundley2f@lulu.com', '1993-09-22', 'QR');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (4391, 'Xerxes', 'Scarbarrow', 'xscarbarrow2g@cornell.edu', '1990-09-15', 'TCAP');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (6697, 'Muire', 'Ritchie', 'mritchie2h@liveinternet.ru', '1994-05-03', 'Editing');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (9082, 'Lucila', 'Edmans', 'ledmans2i@surveymonkey.com', '1993-06-30', 'TCAD');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7148, 'Tania', 'Kyteley', 'tkyteley2j@ocn.ne.jp', '1988-05-14', 'WFO');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (4731, 'Brandais', 'Biggins', 'bbiggins2k@youtube.com', '1991-01-09', 'Ocean');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7089, 'Raviv', 'Elam', 'relam2l@craigslist.org', '1994-03-22', 'SSI');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (3951, 'Dona', 'Aspling', 'daspling2m@youtu.be', '1995-02-08', 'EEM');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (8111, 'Monty', 'Pettyfar', 'mpettyfar2n@engadget.com', '1995-10-23', 'Fertilizers');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (7575, 'Bobinette', 'O''Dowd', 'bodowd2o@craigslist.org', '1988-12-30', 'AutoCAD Civil 3D');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (6961, 'Keely', 'Alwell', 'kalwell2p@angelfire.com', '1990-11-22', 'DMMs');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (8873, 'Elden', 'Arter', 'earter2q@about.me', '1997-05-04', 'IBM AIX');
insert into CANDIDATES (Applicant_id, first_name, last_name, email, dob, skills) values (1626, 'Brose', 'Jewkes', 'bjewkes2r@hexun.com', '1994-06-13', 'Nmap');


insert into JOBS (company , job_title, salary, city) values ('Devbug', 'Biostatistician I', 20516, 'Ostankinskiy');
insert into JOBS (company , job_title, salary, city) values ('Skippad', 'Web Designer I', 12224, 'Kota Bharu');
insert into JOBS (company , job_title, salary, city) values ('Quamba', 'Human Resources Manager', 3462, 'Guanyao');
insert into JOBS (company , job_title, salary, city) values ('Meezzy', 'Geological Engineer', 17178, 'Norrtälje');
insert into JOBS (company , job_title, salary, city) values ('Meezzy', 'Senior Sales Associate', 17995, 'Orong');
insert into JOBS (company , job_title, salary, city) values ('Jabbertype', 'Senior Quality Engineer', 21463, 'Hanyuan');
insert into JOBS (company , job_title, salary, city) values ('Jaxworks', 'Chief Design Engineer', 19997, 'Lyski');
insert into JOBS (company , job_title, salary, city) values ('Feedspan', 'VP Quality Control', 5625, 'Lichtenburg');
insert into JOBS (company , job_title, salary, city) values ('Thoughtmix', 'Web Developer II', 3068, 'Qarāwat Banī Zayd');
insert into JOBS (company , job_title, salary, city) values ('Livefish', 'Quality Engineer', 5416, 'Dikwa');
insert into JOBS (company , job_title, salary, city) values ('Zooxo', 'Software Consultant', 17867, 'Amancio');
insert into JOBS (company , job_title, salary, city) values ('Trunyx', 'GIS Technical Architect', 15408, 'Cimonyong');
insert into JOBS (company , job_title, salary, city) values ('Edgeify', 'VP Sales', 24210, 'Gargaliánoi');
insert into JOBS (company , job_title, salary, city) values ('Mycat', 'Social Worker', 9558, 'Fujioka');
insert into JOBS (company , job_title, salary, city) values ('Oozz', 'Compensation Analyst', 16768, 'Bandung');
insert into JOBS (company , job_title, salary, city) values ('Fliptune', 'Graphic Designer', 24800, 'Dolany');
insert into JOBS (company , job_title, salary, city) values ('Avamba', 'Occupational Therapist', 8379, 'Hullo');
insert into JOBS (company , job_title, salary, city) values ('Mybuzz', 'Help Desk Operator', 23382, 'Micoud');
insert into JOBS (company , job_title, salary, city) values ('Plajo', 'Analog Circuit Design manager', 4069, 'Fuzihe');
insert into JOBS (company , job_title, salary, city) values ('Divanoodle', 'Food Chemist', 15541, 'Kuçovë');
insert into JOBS (company , job_title, salary, city) values ('Yamia', 'Sales Representative', 5836, 'Taquari');
insert into JOBS (company , job_title, salary, city) values ('Skipstorm', 'Chemical Engineer', 8316, 'Chochkan');
insert into JOBS (company , job_title, salary, city) values ('Skajo', 'Assistant Media Planner', 17889, 'Cleveland');
insert into JOBS (company , job_title, salary, city) values ('Bluejam', 'Graphic Designer', 11060, 'Lille');
insert into JOBS (company , job_title, salary, city) values ('Meeveo', 'Financial Analyst', 4016, 'Bum Bum');
insert into JOBS (company , job_title, salary, city) values ('Blogspan', 'Nurse', 21406, 'Lohong');
insert into JOBS (company , job_title, salary, city) values ('Feedfish', 'Mechanical Systems Engineer', 3805, 'Pregrada');
insert into JOBS (company , job_title, salary, city) values ('Dazzlesphere', 'Graphic Designer', 4422, 'Puan');
insert into JOBS (company , job_title, salary, city) values ('Bubblemix', 'Geologist IV', 17987, 'Villa Gesell');
insert into JOBS (company , job_title, salary, city) values ('Eazzy', 'Associate Professor', 20433, 'Arjona');
insert into JOBS (company , job_title, salary, city) values ('Yambee', 'Account Coordinator', 20830, 'Fengcheng');
insert into JOBS (company , job_title, salary, city) values ('Twitterlist', 'VP Product Management', 18382, 'The Valley');
insert into JOBS (company , job_title, salary, city) values ('Voomm', 'Teacher', 10916, 'Boksitogorsk');
insert into JOBS (company , job_title, salary, city) values ('Twitterwire', 'Programmer Analyst IV', 12600, 'Liborina');
insert into JOBS (company , job_title, salary, city) values ('Zoovu', 'Design Engineer', 10197, 'Navan');
insert into JOBS (company , job_title, salary, city) values ('Zooveo', 'Statistician III', 24876, 'Rizal');
insert into JOBS (company , job_title, salary, city) values ('Twimbo', 'Geologist I', 4007, 'Soledad');
insert into JOBS (company , job_title, salary, city) values ('Browsedrive', 'Financial Analyst', 6230, 'Contraalmirante Cordero');
insert into JOBS (company , job_title, salary, city) values ('Trilia', 'Programmer Analyst IV', 15276, 'Bruxelles');
insert into JOBS (company , job_title, salary, city) values ('Wikibox', 'Actuary', 16182, 'Slobodskoy');
insert into JOBS (company , job_title, salary, city) values ('Yacero', 'Staff Scientist', 8685, 'Montego Bay');
insert into JOBS (company , job_title, salary, city) values ('Yakidoo', 'Senior Developer', 9341, 'Shumikha');
insert into JOBS (company , job_title, salary, city) values ('Bluejam', 'Marketing Manager', 6167, 'Zongga');
insert into JOBS (company , job_title, salary, city) values ('Oyope', 'Food Chemist', 15881, 'Mingjing');
insert into JOBS (company , job_title, salary, city) values ('Skaboo', 'Sales Associate', 9399, 'Sulang Tengah');
insert into JOBS (company , job_title, salary, city) values ('Twinder', 'Legal Assistant', 13692, 'Vojkovice');
insert into JOBS (company , job_title, salary, city) values ('Blogpad', 'Chief Design Engineer', 3174, 'Akoupé');
insert into JOBS (company , job_title, salary, city) values ('Blogtags', 'Desktop Support Technician', 9512, 'Gribanovskiy');
insert into JOBS (company , job_title, salary, city) values ('Twinte', 'Computer Systems Analyst II', 23626, 'Cabean');
insert into JOBS (company , job_title, salary, city) values ('Yadel', 'Research Associate', 5257, 'Barranqueras');
insert into JOBS (company , job_title, salary, city) values ('Cogilith', 'Media Manager IV', 3567, 'Pampierstad');
insert into JOBS (company , job_title, salary, city) values ('Buzzster', 'Programmer Analyst IV', 10404, 'San Pedro Pinula');
insert into JOBS (company , job_title, salary, city) values ('Yakidoo', 'Software Engineer IV', 8535, 'Naftalan');
insert into JOBS (company , job_title, salary, city) values ('Muxo', 'Chief Design Engineer', 18720, 'Mikstat');
insert into JOBS (company , job_title, salary, city) values ('Ntag', 'Help Desk Technician', 13800, 'Santa Teresita');
insert into JOBS (company , job_title, salary, city) values ('Kamba', 'Cost Accountant', 19880, 'Chipata');
insert into JOBS (company , job_title, salary, city) values ('Yakijo', 'Computer Systems Analyst IV', 13290, 'Gisiliba');
insert into JOBS (company , job_title, salary, city) values ('Meembee', 'Programmer II', 6288, 'Vista Hermosa');
insert into JOBS (company , job_title, salary, city) values ('Lajo', 'Help Desk Operator', 23438, 'Wiśniewo');
insert into JOBS (company , job_title, salary, city) values ('Mudo', 'Web Developer IV', 17348, 'Kalmar');
insert into JOBS (company , job_title, salary, city) values ('Centizu', 'VP Quality Control', 24335, 'Hesi');
insert into JOBS (company , job_title, salary, city) values ('Fliptune', 'Senior Sales Associate', 24932, 'Darovskoy');
insert into JOBS (company , job_title, salary, city) values ('Zoozzy', 'Nurse Practicioner', 5670, 'Zhangzhishan');
insert into JOBS (company , job_title, salary, city) values ('Eazzy', 'Structural Analysis Engineer', 9086, 'Pirajuí');
insert into JOBS (company , job_title, salary, city) values ('Janyx', 'Human Resources Manager', 12361, 'Gaoshan');
insert into JOBS (company , job_title, salary, city) values ('Edgepulse', 'Project Manager', 4866, 'Caen');
insert into JOBS (company , job_title, salary, city) values ('Edgewire', 'Account Executive', 14506, 'Damietta');
insert into JOBS (company , job_title, salary, city) values ('Tagcat', 'Senior Quality Engineer', 22662, 'Khorramdarreh');
insert into JOBS (company , job_title, salary, city) values ('Bluejam', 'Editor', 20841, 'Temuco');
insert into JOBS (company , job_title, salary, city) values ('Wordify', 'Chemical Engineer', 13212, 'Garango');
insert into JOBS (company , job_title, salary, city) values ('Centizu', 'Registered Nurse', 9335, 'Pechenga');
insert into JOBS (company , job_title, salary, city) values ('Agimba', 'Financial Advisor', 11799, 'Novo-Nikol’skoye');
insert into JOBS (company , job_title, salary, city) values ('Skaboo', 'VP Marketing', 2670, 'Wailolung');
insert into JOBS (company , job_title, salary, city) values ('Rooxo', 'Recruiting Manager', 7690, 'Victoria');
insert into JOBS (company , job_title, salary, city) values ('Zoombox', 'Structural Engineer', 9113, 'Dzorastan');
insert into JOBS (company , job_title, salary, city) values ('Flashset', 'Business Systems Development Analyst', 21665, 'Pasirangin Tiga');
insert into JOBS (company , job_title, salary, city) values ('Vinte', 'Mechanical Systems Engineer', 16974, 'Manizales');
insert into JOBS (company , job_title, salary, city) values ('Thoughtsphere', 'Environmental Specialist', 3318, 'Betulia');
insert into JOBS (company , job_title, salary, city) values ('Lajo', 'Nurse Practicioner', 23507, 'Lemery');
insert into JOBS (company , job_title, salary, city) values ('Topicblab', 'Senior Developer', 10689, 'Głuchów');
insert into JOBS (company , job_title, salary, city) values ('Katz', 'Civil Engineer', 23525, 'Coromandel');
insert into JOBS (company , job_title, salary, city) values ('Rhynyx', 'Senior Cost Accountant', 12928, 'Miętne');
insert into JOBS (company , job_title, salary, city) values ('Kayveo', 'Tax Accountant', 5800, 'Gedera');
insert into JOBS (company , job_title, salary, city) values ('Blognation', 'Web Developer IV', 6868, 'Tinalmud');
insert into JOBS (company , job_title, salary, city) values ('Linkbridge', 'Human Resources Assistant III', 22664, 'Xiqi');
insert into JOBS (company , job_title, salary, city) values ('Roomm', 'Financial Advisor', 14468, 'Dukuh Kaler');
insert into JOBS (company , job_title, salary, city) values ('Babbleopia', 'Product Engineer', 23387, 'Gugark’');
insert into JOBS (company , job_title, salary, city) values ('Buzzster', 'Occupational Therapist', 19394, 'Morales');
insert into JOBS (company , job_title, salary, city) values ('Skiba', 'GIS Technical Architect', 2776, 'Banān');
insert into JOBS (company , job_title, salary, city) values ('Oyoyo', 'Web Designer IV', 5310, 'Wuluo');
insert into JOBS (company , job_title, salary, city) values ('Quatz', 'Professor', 15133, 'Buenavista');
insert into JOBS (company , job_title, salary, city) values ('Wikizz', 'VP Sales', 2545, 'Xiaomei');
insert into JOBS (company , job_title, salary, city) values ('Livetube', 'Marketing Manager', 11921, 'Huertas');
insert into JOBS (company , job_title, salary, city) values ('Skippad', 'Associate Professor', 15381, 'Santa Cruz das Palmeiras');
insert into JOBS (company , job_title, salary, city) values ('Brainlounge', 'Occupational Therapist', 22218, 'Iriga City');
insert into JOBS (company , job_title, salary, city) values ('Gabcube', 'Software Test Engineer IV', 24698, 'Bosanski Šamac');
insert into JOBS (company , job_title, salary, city) values ('Jazzy', 'Staff Accountant III', 19414, 'Xishan');
insert into JOBS (company , job_title, salary, city) values ('Yombu', 'Software Engineer I', 21517, 'Nazir Town');
insert into JOBS (company , job_title, salary, city) values ('Meezzy', 'VP Accounting', 15820, 'Ban Nahin');
insert into JOBS (company , job_title, salary, city) values ('Thoughtstorm', 'Compensation Analyst', 23969, 'Tabiauan');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO application(applicant_id, company, job_title,city) 
select 
  applicant_id, 
  company, 
  job_title,
  city
from 
  candidates, 
  jobs 
order by 
  random() 
limit 
  1000;
  