/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/
Name: Ning Tang
Student Number: A0232009U
/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
The code is written for PostgreSQL.

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
Since I am a big fan of soccer, I would like to set up a situation in which the entity set E1 is Players,
the entity set E2 is SoccerClubs and the relationship between two sets is Playfor.
The entity set E1 include player_id, first_name, last_name, nationality and phone_num while E2 entity includes club_id, 
name and region. The table Playfor associates the player_id of Players with the club_id of 
clubs. All code for following questions is written for PostgreSQL.

/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS players (
player_id VARCHAR(16) PRIMARY KEY,
first_name VARCHAR(64) NOT NULL,
last_name VARCHAR(64) NOT NULL,
nationality VARCHAR(64) NOT NULL,
phone_num VARCHAR(64) NOT NULL);

CREATE TABLE IF NOT EXISTS soccerclubs (
club_id VARCHAR(16) PRIMARY KEY,
name VARCHAR(64) NOT NULL,
region VARCHAR(64) NOT NULL);

CREATE TABLE IF NOT EXISTS playfor (
player_id VARCHAR(16) REFERENCES Players(player_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
club_id VARCHAR(16) REFERENCES SoccerClubs(club_id) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
PRIMARY KEY(player_id, club_id));

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/*Insert mock data into the first dataset, Players*/
insert into players (player_id, first_name, last_name, nationality, phone_num) values (1, 'Feodor', 'Coulthard', 'Russia', '810-290-0697');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (2, 'Red', 'Cockren', 'South Korea', '916-274-7771');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (3, 'Reamonn', 'Acom', 'Philippines', '590-912-9121');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (4, 'Patricio', 'McCullogh', 'Brazil', '440-333-0968');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (5, 'Lorene', 'Baudasso', 'Philippines', '338-144-1637');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (6, 'Timmy', 'Stackbridge', 'Canada', '754-405-6014');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (7, 'Lorette', 'Caughtry', 'Nigeria', '981-470-8673');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (8, 'Paxton', 'Palphreyman', 'Afghanistan', '213-353-3003');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (9, 'Quill', 'Instone', 'Kazakhstan', '183-365-9947');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (10, 'Frederica', 'Reasce', 'Russia', '888-955-5080');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (11, 'Stacy', 'Bretland', 'Philippines', '767-205-2755');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (12, 'Vannie', 'McCaig', 'Brazil', '899-734-3020');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (13, 'Noble', 'Gabbett', 'China', '215-656-4093');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (14, 'Deni', 'Trouncer', 'Sudan', '892-424-7924');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (15, 'Shena', 'Arkin', 'Hungary', '968-624-7081');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (16, 'Shirlene', 'Diegan', 'Montenegro', '487-603-5146');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (17, 'Dniren', 'Gringley', 'Portugal', '571-707-7018');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (18, 'Alison', 'Rentoll', 'Russia', '164-600-1061');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (19, 'Madelene', 'Benck', 'Poland', '160-722-6623');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (20, 'Cindelyn', 'Adamolli', 'Mexico', '142-512-3293');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (21, 'Joelly', 'Swinn', 'Greece', '892-133-8222');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (22, 'Dael', 'Thirst', 'Central African Republic', '623-120-5497');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (23, 'Ruthann', 'O''Cannon', 'Venezuela', '111-433-3095');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (24, 'Estele', 'Prickett', 'Indonesia', '902-203-4277');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (25, 'Cassi', 'Scamaden', 'Moldova', '453-924-5523');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (26, 'Ozzy', 'Tredgold', 'Bolivia', '938-569-9175');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (27, 'Jenine', 'Raiker', 'Indonesia', '915-530-3568');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (28, 'Carl', 'Jillins', 'Micronesia', '924-184-5654');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (29, 'Darb', 'Blackaller', 'France', '870-795-5435');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (30, 'Lizbeth', 'Armistead', 'China', '390-703-1105');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (31, 'Guthry', 'Bahike', 'United States', '863-470-1071');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (32, 'Lori', 'Peye', 'Thailand', '351-307-1751');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (33, 'Elsi', 'Wallworth', 'Moldova', '213-302-6097');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (34, 'Dorine', 'Ivie', 'China', '574-338-0549');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (35, 'Zorine', 'Looby', 'Ukraine', '936-543-0833');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (36, 'Isabella', 'Fiorentino', 'Ukraine', '810-291-3089');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (37, 'Uriah', 'Yurenev', 'China', '709-962-3933');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (38, 'Micaela', 'Timmermann', 'Peru', '114-320-7202');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (39, 'Micky', 'Mains', 'Sweden', '208-511-6679');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (40, 'Abigale', 'Helm', 'Sweden', '173-226-6133');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (41, 'Tansy', 'Glass', 'Sweden', '248-501-8702');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (42, 'Leland', 'Philbrick', 'Russia', '742-609-3821');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (43, 'Bobbi', 'Pidon', 'China', '262-823-5426');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (44, 'Gerhard', 'Ingraham', 'China', '211-150-1270');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (45, 'Dita', 'Mulhall', 'Brazil', '352-844-1046');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (46, 'Ketti', 'Scalera', 'China', '451-571-8814');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (47, 'Carena', 'Fochs', 'Indonesia', '145-803-6517');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (48, 'Genni', 'Soigne', 'Syria', '152-285-0573');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (49, 'Giffer', 'Shann', 'Thailand', '663-674-1668');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (50, 'Trent', 'McCrae', 'Indonesia', '587-246-9159');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (51, 'Flora', 'Rushbrooke', 'China', '569-483-7152');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (52, 'Gilburt', 'Bohea', 'Yemen', '369-700-1970');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (53, 'Dyanne', 'Egdell', 'China', '842-633-3912');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (54, 'Leanna', 'Burburough', 'Sweden', '922-243-5999');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (55, 'Griffie', 'Shewon', 'Indonesia', '547-522-5880');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (56, 'Barnebas', 'Unwins', 'Greece', '863-903-0600');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (57, 'Ellen', 'Lanston', 'Philippines', '428-411-3072');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (58, 'Quinn', 'Trowsdale', 'China', '938-350-9912');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (59, 'Giffie', 'Zannini', 'Indonesia', '917-299-0705');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (60, 'Clement', 'Torricina', 'Russia', '156-784-2224');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (61, 'Lauraine', 'Cramphorn', 'Argentina', '796-897-5320');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (62, 'Gerard', 'Grindlay', 'Peru', '212-599-1255');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (63, 'Sharai', 'Mabee', 'Sweden', '153-411-6253');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (64, 'Rupert', 'Gilliland', 'Russia', '462-276-8280');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (65, 'Mathilde', 'Sonier', 'Russia', '136-408-6277');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (66, 'Bernice', 'Beney', 'China', '546-431-6687');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (67, 'Charity', 'Ambrogiotti', 'Colombia', '208-569-0963');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (68, 'Friedrick', 'Rau', 'Poland', '884-618-2024');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (69, 'Anjela', 'Elsegood', 'Poland', '130-106-9415');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (70, 'Elka', 'Sutton', 'Mongolia', '192-494-8716');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (71, 'Peadar', 'Kassel', 'Colombia', '680-729-6361');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (72, 'Claudia', 'Burkert', 'Cuba', '459-837-7076');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (73, 'Gilbertine', 'Hayter', 'Indonesia', '265-408-7200');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (74, 'Tabbi', 'Davidy', 'Philippines', '671-289-4933');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (75, 'Leonerd', 'Castell', 'Russia', '461-923-4004');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (76, 'Lesly', 'Klimpke', 'Russia', '156-869-3179');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (77, 'Huntlee', 'Zuann', 'China', '976-255-2907');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (78, 'Raff', 'Wippermann', 'China', '410-209-4013');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (79, 'Lily', 'Constantine', 'Dominican Republic', '898-602-7903');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (80, 'Timothy', 'Veness', 'China', '528-445-4874');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (81, 'Genevieve', 'Chidlow', 'Russia', '918-435-9994');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (82, 'Sansone', 'Stuchbury', 'China', '263-522-2701');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (83, 'Raine', 'Finneran', 'Gambia', '152-223-1089');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (84, 'Denis', 'Gallone', 'Azerbaijan', '573-714-4098');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (85, 'Brinn', 'Odgaard', 'Ukraine', '986-837-1815');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (86, 'Bess', 'Spurden', 'Canada', '376-982-8278');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (87, 'Cloe', 'Lanfare', 'Bosnia and Herzegovina', '754-364-2547');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (88, 'Rozelle', 'Weatherburn', 'China', '397-261-9338');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (89, 'Leoline', 'MacPhail', 'Armenia', '723-660-5978');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (90, 'Phoebe', 'Normabell', 'China', '271-102-0121');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (91, 'Cirstoforo', 'Drew', 'Netherlands', '130-349-2782');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (92, 'Jade', 'Belton', 'China', '968-333-5848');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (93, 'Lane', 'Kilpatrick', 'Zambia', '747-558-1197');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (94, 'Brynna', 'Tripet', 'Honduras', '874-651-4802');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (95, 'Blythe', 'Santhouse', 'China', '966-918-3445');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (96, 'Jehanna', 'Leon', 'Indonesia', '673-745-2441');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (97, 'Junie', 'McLurg', 'Myanmar', '780-604-2350');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (98, 'Gaston', 'Scotchmoor', 'Argentina', '552-405-5565');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (99, 'Caprice', 'Gallemore', 'Spain', '551-302-7793');
insert into players (player_id, first_name, last_name, nationality, phone_num) values (100, 'Carce', 'Matias', 'China', '820-846-6321');

/*Insert into the second dataset, SoccerClubs*/
insert into soccerclubs (club_id, name, region) values (1, 'Hilpert and Sons', 'Philippines');
insert into soccerclubs (club_id, name, region) values (2, 'Kihn Inc', 'China');
insert into soccerclubs (club_id, name, region) values (3, 'Glover-Harvey', 'Estonia');
insert into soccerclubs (club_id, name, region) values (4, 'Kuhic-Price', 'Indonesia');
insert into soccerclubs (club_id, name, region) values (5, 'Walker-Parker', 'Croatia');
insert into soccerclubs (club_id, name, region) values (6, 'Kuhlman LLC', 'China');
insert into soccerclubs (club_id, name, region) values (7, 'Towne-Huel', 'Indonesia');
insert into soccerclubs (club_id, name, region) values (8, 'McGlynn, Goyette and Wuckert', 'Portugal');
insert into soccerclubs (club_id, name, region) values (9, 'Towne, Waelchi and Trantow', 'China');
insert into soccerclubs (club_id, name, region) values (10, 'Quigley-Toy', 'Gambia');
insert into soccerclubs (club_id, name, region) values (11, 'Lakin, Towne and Ziemann', 'China');
insert into soccerclubs (club_id, name, region) values (12, 'Altenwerth, Ankunding and Kovacek', 'Thailand');
insert into soccerclubs (club_id, name, region) values (13, 'Willms, Koelpin and Little', 'Spain');
insert into soccerclubs (club_id, name, region) values (14, 'Bahringer-Towne', 'Indonesia');
insert into soccerclubs (club_id, name, region) values (15, 'Reinger-Schaefer', 'Malawi');
insert into soccerclubs (club_id, name, region) values (16, 'Abernathy-Fadel', 'China');
insert into soccerclubs (club_id, name, region) values (17, 'Senger-Weissnat', 'Norway');
insert into soccerclubs (club_id, name, region) values (18, 'McLaughlin, Welch and Nolan', 'Sweden');
insert into soccerclubs (club_id, name, region) values (19, 'Stehr Group', 'Vietnam');
insert into soccerclubs (club_id, name, region) values (20, 'Wunsch, Nader and Windler', 'Israel');
insert into soccerclubs (club_id, name, region) values (21, 'Grimes-Zieme', 'Thailand');
insert into soccerclubs (club_id, name, region) values (22, 'Stracke-Brekke', 'France');
insert into soccerclubs (club_id, name, region) values (23, 'Prosacco, Schroeder and Considine', 'Cuba');
insert into soccerclubs (club_id, name, region) values (24, 'Christiansen-Labadie', 'China');
insert into soccerclubs (club_id, name, region) values (25, 'Zboncak-O''Keefe', 'France');
insert into soccerclubs (club_id, name, region) values (26, 'Lehner-Kautzer', 'Indonesia');
insert into soccerclubs (club_id, name, region) values (27, 'Marvin-Ziemann', 'Poland');
insert into soccerclubs (club_id, name, region) values (28, 'Goyette, Crona and Murray', 'Philippines');
insert into soccerclubs (club_id, name, region) values (29, 'Greenholt, Wunsch and Moen', 'Mexico');
insert into soccerclubs (club_id, name, region) values (30, 'Roberts Group', 'China');
insert into soccerclubs (club_id, name, region) values (31, 'Hamill, Mills and Veum', 'Ukraine');
insert into soccerclubs (club_id, name, region) values (32, 'Green LLC', 'Philippines');
insert into soccerclubs (club_id, name, region) values (33, 'Doyle-Murazik', 'Russia');
insert into soccerclubs (club_id, name, region) values (34, 'Toy and Sons', 'China');
insert into soccerclubs (club_id, name, region) values (35, 'Prohaska, Schneider and Wiegand', 'China');
insert into soccerclubs (club_id, name, region) values (36, 'Mosciski, Will and Kihn', 'Indonesia');
insert into soccerclubs (club_id, name, region) values (37, 'Kerluke, Tillman and Trantow', 'China');
insert into soccerclubs (club_id, name, region) values (38, 'Keebler, Kohler and Nitzsche', 'France');
insert into soccerclubs (club_id, name, region) values (39, 'Kozey, White and Hammes', 'Morocco');
insert into soccerclubs (club_id, name, region) values (40, 'Pollich and Sons', 'Iran');
insert into soccerclubs (club_id, name, region) values (41, 'Mertz Group', 'Portugal');
insert into soccerclubs (club_id, name, region) values (42, 'Wunsch, Stehr and Pouros', 'Mongolia');
insert into soccerclubs (club_id, name, region) values (43, 'Crooks Inc', 'Brazil');
insert into soccerclubs (club_id, name, region) values (44, 'Streich Inc', 'Vietnam');
insert into soccerclubs (club_id, name, region) values (45, 'Daniel-Heidenreich', 'China');
insert into soccerclubs (club_id, name, region) values (46, 'Thompson-Zulauf', 'Greece');
insert into soccerclubs (club_id, name, region) values (47, 'Prohaska-McLaughlin', 'Burundi');
insert into soccerclubs (club_id, name, region) values (48, 'Mosciski-Mayer', 'Nepal');
insert into soccerclubs (club_id, name, region) values (49, 'Predovic, Effertz and Jerde', 'North Korea');
insert into soccerclubs (club_id, name, region) values (50, 'Pollich, Hyatt and Jakubowski', 'Brazil');
insert into soccerclubs (club_id, name, region) values (51, 'Mills-O''Reilly', 'Canada');
insert into soccerclubs (club_id, name, region) values (52, 'Durgan, Friesen and Sporer', 'Guatemala');
insert into soccerclubs (club_id, name, region) values (53, 'Kilback-Terry', 'Canada');
insert into soccerclubs (club_id, name, region) values (54, 'Hettinger Inc', 'Japan');
insert into soccerclubs (club_id, name, region) values (55, 'Fay and Sons', 'China');
insert into soccerclubs (club_id, name, region) values (56, 'Kessler-Goodwin', 'Croatia');
insert into soccerclubs (club_id, name, region) values (57, 'Davis-Hirthe', 'United States');
insert into soccerclubs (club_id, name, region) values (58, 'D''Amore-Brakus', 'Russia');
insert into soccerclubs (club_id, name, region) values (59, 'Lemke-VonRueden', 'Cuba');
insert into soccerclubs (club_id, name, region) values (60, 'Swaniawski and Sons', 'Nigeria');
insert into soccerclubs (club_id, name, region) values (61, 'Rippin, Vandervort and Breitenberg', 'Honduras');
insert into soccerclubs (club_id, name, region) values (62, 'Cummings, Mueller and Koss', 'Ethiopia');
insert into soccerclubs (club_id, name, region) values (63, 'Prohaska and Sons', 'Bangladesh');
insert into soccerclubs (club_id, name, region) values (64, 'Spinka-Conroy', 'Indonesia');
insert into soccerclubs (club_id, name, region) values (65, 'Bruen and Sons', 'Poland');
insert into soccerclubs (club_id, name, region) values (66, 'Emard-Kub', 'Czech Republic');
insert into soccerclubs (club_id, name, region) values (67, 'Hane Inc', 'North Korea');
insert into soccerclubs (club_id, name, region) values (68, 'Metz, Altenwerth and Kuhn', 'China');
insert into soccerclubs (club_id, name, region) values (69, 'Halvorson, Bartell and Fahey', 'France');
insert into soccerclubs (club_id, name, region) values (70, 'Price, Bradtke and Morar', 'China');
insert into soccerclubs (club_id, name, region) values (71, 'Labadie, Rempel and Runte', 'China');
insert into soccerclubs (club_id, name, region) values (72, 'Jacobson Inc', 'Mexico');
insert into soccerclubs (club_id, name, region) values (73, 'Strosin, Rogahn and Hayes', 'Philippines');
insert into soccerclubs (club_id, name, region) values (74, 'Schmitt-Grimes', 'United States');
insert into soccerclubs (club_id, name, region) values (75, 'Brekke and Sons', 'Belarus');
insert into soccerclubs (club_id, name, region) values (76, 'Konopelski, Flatley and Stokes', 'Indonesia');
insert into soccerclubs (club_id, name, region) values (77, 'Hartmann-Rosenbaum', 'Bosnia and Herzegovina');
insert into soccerclubs (club_id, name, region) values (78, 'Hettinger, Friesen and Upton', 'Chile');
insert into soccerclubs (club_id, name, region) values (79, 'Miller-Prosacco', 'Serbia');
insert into soccerclubs (club_id, name, region) values (80, 'O''Hara Group', 'Mexico');
insert into soccerclubs (club_id, name, region) values (81, 'Kuhn-DuBuque', 'China');
insert into soccerclubs (club_id, name, region) values (82, 'Robel, Wiza and D''Amore', 'Japan');
insert into soccerclubs (club_id, name, region) values (83, 'Windler-Kohler', 'Sweden');
insert into soccerclubs (club_id, name, region) values (84, 'Wolf, Stokes and Ryan', 'Brazil');
insert into soccerclubs (club_id, name, region) values (85, 'Zboncak Group', 'Argentina');
insert into soccerclubs (club_id, name, region) values (86, 'Effertz, Hansen and Willms', 'United States');
insert into soccerclubs (club_id, name, region) values (87, 'Bartoletti-West', 'Japan');
insert into soccerclubs (club_id, name, region) values (88, 'Johns, Marvin and Anderson', 'Ukraine');
insert into soccerclubs (club_id, name, region) values (89, 'Fay and Sons', 'Indonesia');
insert into soccerclubs (club_id, name, region) values (90, 'Bradtke, Reynolds and Lind', 'China');
insert into soccerclubs (club_id, name, region) values (91, 'Boyer-Rempel', 'Spain');
insert into soccerclubs (club_id, name, region) values (92, 'Olson-Collins', 'Poland');
insert into soccerclubs (club_id, name, region) values (93, 'Monahan-Cronin', 'Hungary');
insert into soccerclubs (club_id, name, region) values (94, 'Wolf-Hoppe', 'Indonesia');
insert into soccerclubs (club_id, name, region) values (95, 'Welch LLC', 'Indonesia');
insert into soccerclubs (club_id, name, region) values (96, 'Hermann, Johns and Zemlak', 'Indonesia');
insert into soccerclubs (club_id, name, region) values (97, 'Reichel Inc', 'China');
insert into soccerclubs (club_id, name, region) values (98, 'Grant, Daugherty and Connelly', 'China');
insert into soccerclubs (club_id, name, region) values (99, 'Sipes-Lesch', 'China');
insert into soccerclubs (club_id, name, region) values (100, 'Maggio, McGlynn and Hackett', 'Japan');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into playfor (player_id, club_id)
select p.player_id, s.club_id
from players p, soccerclubs s
order by random()
limit 1000;
