/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/
/*            Shaobin Qiao   A0232196E                                  */


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* 
I created three tables, student, university and applied_to. They record 
students who applied to universities, information of universities and 
students' application history.
The student table records the information of 100 students, including 
their ID (primary key), first_name, last_name, email, gender and gpa. 
The university table records university_id (primary_key), university_name,
their states and their ranking of 100 universities. The table applied_to records the universities
each student applied to and whether they are admitted or not. 
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table student (
	id  INT PRIMARY KEY,
	first_name VARCHAR(50) NOT NULL,
	last_name VARCHAR(50) NOT NULL,
	email VARCHAR(50) NOT NULL,
	gender VARCHAR(10) NOT NULL,
	GPA DECIMAL(3,2) NOT NULL
);

create table university (
	university_id INT PRIMARY KEY,
	university_name VARCHAR(100) NOT NULL,
	states VARCHAR(50) NOT NULL,
	university_ranking  INT NOT NULL
);

create table applied_to (
	student_id INT references student(id) NOT NULL,
	university_id INT references university(university_id) NOT NULL,
	admitted BOOLEAN NOT NULL);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

/* student */
insert into student (id, first_name, last_name, email, gender, GPA) values (1, 'Othella', 'Melville', 'omelville0@senate.gov', 'male', 3.14);
insert into student (id, first_name, last_name, email, gender, GPA) values (2, 'Merrill', 'Dumbare', 'mdumbare1@nyu.edu', 'male', 3.64);
insert into student (id, first_name, last_name, email, gender, GPA) values (3, 'Carter', 'Keyzman', 'ckeyzman2@unicef.org', 'female', 3.75);
insert into student (id, first_name, last_name, email, gender, GPA) values (4, 'Elisabet', 'Hatry', 'ehatry3@ameblo.jp', 'male', 3.26);
insert into student (id, first_name, last_name, email, gender, GPA) values (5, 'Ted', 'Euplate', 'teuplate4@marriott.com', 'female', 3.9);
insert into student (id, first_name, last_name, email, gender, GPA) values (6, 'Carmencita', 'Biskupski', 'cbiskupski5@bing.com', 'male', 3.5);
insert into student (id, first_name, last_name, email, gender, GPA) values (7, 'Gillan', 'Rubinlicht', 'grubinlicht6@google.com', 'male', 3.11);
insert into student (id, first_name, last_name, email, gender, GPA) values (8, 'Regina', 'Fontel', 'rfontel7@tripod.com', 'female', 3.83);
insert into student (id, first_name, last_name, email, gender, GPA) values (9, 'Devonne', 'Staynes', 'dstaynes8@jigsy.com', 'male', 3.48);
insert into student (id, first_name, last_name, email, gender, GPA) values (10, 'Xylina', 'Payne', 'xpayne9@histats.com', 'male', 3.9);
insert into student (id, first_name, last_name, email, gender, GPA) values (11, 'Marja', 'Kuzemka', 'mkuzemkaa@weibo.com', 'female', 3.67);
insert into student (id, first_name, last_name, email, gender, GPA) values (12, 'Florie', 'Puleque', 'fpulequeb@hubpages.com', 'male', 3.98);
insert into student (id, first_name, last_name, email, gender, GPA) values (13, 'Dillie', 'Vaneschi', 'dvaneschic@ovh.net', 'male', 3.18);
insert into student (id, first_name, last_name, email, gender, GPA) values (14, 'Stesha', 'Boothman', 'sboothmand@salon.com', 'female', 3.53);
insert into student (id, first_name, last_name, email, gender, GPA) values (15, 'Lanette', 'Andrzejak', 'landrzejake@barnesandnoble.com', 'male', 3.04);
insert into student (id, first_name, last_name, email, gender, GPA) values (16, 'August', 'Webland', 'aweblandf@epa.gov', 'female', 3.43);
insert into student (id, first_name, last_name, email, gender, GPA) values (17, 'Emanuele', 'Hingeley', 'ehingeleyg@nature.com', 'male', 3.57);
insert into student (id, first_name, last_name, email, gender, GPA) values (18, 'Layla', 'Carletti', 'lcarlettih@tmall.com', 'male', 3.01);
insert into student (id, first_name, last_name, email, gender, GPA) values (19, 'Caesar', 'Udell', 'cudelli@toplist.cz', 'female', 3.9);
insert into student (id, first_name, last_name, email, gender, GPA) values (20, 'Morgan', 'Day', 'mdayj@hexun.com', 'female', 3.85);
insert into student (id, first_name, last_name, email, gender, GPA) values (21, 'Vanny', 'Klamp', 'vklampk@google.nl', 'male', 3.48);
insert into student (id, first_name, last_name, email, gender, GPA) values (22, 'Jarad', 'Ternott', 'jternottl@bloglines.com', 'female', 3.62);
insert into student (id, first_name, last_name, email, gender, GPA) values (23, 'Norbert', 'Reynoollds', 'nreynoolldsm@bizjournals.com', 'male', 3.52);
insert into student (id, first_name, last_name, email, gender, GPA) values (24, 'Broderic', 'Grose', 'bgrosen@latimes.com', 'male', 3.22);
insert into student (id, first_name, last_name, email, gender, GPA) values (25, 'Ingmar', 'Lewens', 'ilewenso@prweb.com', 'male', 3.35);
insert into student (id, first_name, last_name, email, gender, GPA) values (26, 'Melissa', 'Houlison', 'mhoulisonp@sohu.com', 'male', 3.89);
insert into student (id, first_name, last_name, email, gender, GPA) values (27, 'Norean', 'Morse', 'nmorseq@ted.com', 'female', 3.69);
insert into student (id, first_name, last_name, email, gender, GPA) values (28, 'Morley', 'Bugge', 'mbugger@dion.ne.jp', 'female', 3.98);
insert into student (id, first_name, last_name, email, gender, GPA) values (29, 'Ginevra', 'Balhatchet', 'gbalhatchets@vinaora.com', 'male', 3.98);
insert into student (id, first_name, last_name, email, gender, GPA) values (30, 'Cacilia', 'Linsey', 'clinseyt@eepurl.com', 'male', 3.6);
insert into student (id, first_name, last_name, email, gender, GPA) values (31, 'Sebastian', 'Folca', 'sfolcau@smh.com.au', 'female', 3.01);
insert into student (id, first_name, last_name, email, gender, GPA) values (32, 'Calvin', 'Timny', 'ctimnyv@google.com.br', 'male', 3.34);
insert into student (id, first_name, last_name, email, gender, GPA) values (33, 'Koral', 'Gerrie', 'kgerriew@studiopress.com', 'female', 3.28);
insert into student (id, first_name, last_name, email, gender, GPA) values (34, 'Eryn', 'Simic', 'esimicx@cnbc.com', 'female', 3.01);
insert into student (id, first_name, last_name, email, gender, GPA) values (35, 'Mikey', 'Daldan', 'mdaldany@msn.com', 'female', 3.17);
insert into student (id, first_name, last_name, email, gender, GPA) values (36, 'Karee', 'Chastel', 'kchastelz@google.ru', 'male', 3.53);
insert into student (id, first_name, last_name, email, gender, GPA) values (37, 'Louis', 'Thunders', 'lthunders10@earthlink.net', 'male', 3.34);
insert into student (id, first_name, last_name, email, gender, GPA) values (38, 'Allsun', 'Bownas', 'abownas11@eepurl.com', 'male', 3.92);
insert into student (id, first_name, last_name, email, gender, GPA) values (39, 'Georgine', 'Cleave', 'gcleave12@delicious.com', 'male', 3.98);
insert into student (id, first_name, last_name, email, gender, GPA) values (40, 'Luca', 'McGaughey', 'lmcgaughey13@newyorker.com', 'female', 3.9);
insert into student (id, first_name, last_name, email, gender, GPA) values (41, 'Geno', 'Ramsell', 'gramsell14@bloglovin.com', 'male', 3.44);
insert into student (id, first_name, last_name, email, gender, GPA) values (42, 'Renado', 'Vanyakin', 'rvanyakin15@admin.ch', 'male', 3.02);
insert into student (id, first_name, last_name, email, gender, GPA) values (43, 'Ivonne', 'Oran', 'ioran16@merriam-webster.com', 'female', 3.98);
insert into student (id, first_name, last_name, email, gender, GPA) values (44, 'King', 'Shapland', 'kshapland17@patch.com', 'male', 3.06);
insert into student (id, first_name, last_name, email, gender, GPA) values (45, 'Caroline', 'Wiltsher', 'cwiltsher18@list-manage.com', 'male', 3.54);
insert into student (id, first_name, last_name, email, gender, GPA) values (46, 'Magdalen', 'Carde', 'mcarde19@goo.gl', 'male', 3.93);
insert into student (id, first_name, last_name, email, gender, GPA) values (47, 'Bobbee', 'Simonnot', 'bsimonnot1a@un.org', 'female', 3.55);
insert into student (id, first_name, last_name, email, gender, GPA) values (48, 'Chrissie', 'Sawell', 'csawell1b@netscape.com', 'male', 3.43);
insert into student (id, first_name, last_name, email, gender, GPA) values (49, 'Tommie', 'Core', 'tcore1c@indiegogo.com', 'female', 3.43);
insert into student (id, first_name, last_name, email, gender, GPA) values (50, 'Durward', 'Gath', 'dgath1d@google.de', 'male', 3.71);
insert into student (id, first_name, last_name, email, gender, GPA) values (51, 'Cherice', 'Hartfleet', 'chartfleet1e@seesaa.net', 'male', 3.93);
insert into student (id, first_name, last_name, email, gender, GPA) values (52, 'Zebadiah', 'Josephy', 'zjosephy1f@networkadvertising.org', 'male', 3.15);
insert into student (id, first_name, last_name, email, gender, GPA) values (53, 'Terra', 'Baversor', 'tbaversor1g@tuttocitta.it', 'female', 3.64);
insert into student (id, first_name, last_name, email, gender, GPA) values (54, 'Claudia', 'Tudball', 'ctudball1h@marketwatch.com', 'male', 3.59);
insert into student (id, first_name, last_name, email, gender, GPA) values (55, 'Cristy', 'Mendoza', 'cmendoza1i@mashable.com', 'male', 3.02);
insert into student (id, first_name, last_name, email, gender, GPA) values (56, 'Andie', 'De Ath', 'adeath1j@indiatimes.com', 'male', 3.42);
insert into student (id, first_name, last_name, email, gender, GPA) values (57, 'Kaylil', 'Haly', 'khaly1k@japanpost.jp', 'male', 3.8);
insert into student (id, first_name, last_name, email, gender, GPA) values (58, 'Locke', 'Trowle', 'ltrowle1l@japanpost.jp', 'female', 3.87);
insert into student (id, first_name, last_name, email, gender, GPA) values (59, 'Shoshana', 'Summerton', 'ssummerton1m@istockphoto.com', 'female', 3.1);
insert into student (id, first_name, last_name, email, gender, GPA) values (60, 'Dillie', 'Loweth', 'dloweth1n@loc.gov', 'male', 3.45);
insert into student (id, first_name, last_name, email, gender, GPA) values (61, 'Erik', 'McFie', 'emcfie1o@washingtonpost.com', 'female', 3.63);
insert into student (id, first_name, last_name, email, gender, GPA) values (62, 'Cathyleen', 'Eates', 'ceates1p@example.com', 'male', 3.68);
insert into student (id, first_name, last_name, email, gender, GPA) values (63, 'Marty', 'Reuther', 'mreuther1q@tuttocitta.it', 'male', 3.09);
insert into student (id, first_name, last_name, email, gender, GPA) values (64, 'Thorny', 'Snelson', 'tsnelson1r@comcast.net', 'male', 3.29);
insert into student (id, first_name, last_name, email, gender, GPA) values (65, 'Gilly', 'Baron', 'gbaron1s@google.ca', 'female', 3.43);
insert into student (id, first_name, last_name, email, gender, GPA) values (66, 'Katey', 'Salt', 'ksalt1t@apache.org', 'male', 3.65);
insert into student (id, first_name, last_name, email, gender, GPA) values (67, 'Bari', 'Itzkovwitch', 'bitzkovwitch1u@myspace.com', 'male', 3.32);
insert into student (id, first_name, last_name, email, gender, GPA) values (68, 'Yvor', 'Lamartine', 'ylamartine1v@chicagotribune.com', 'male', 3.43);
insert into student (id, first_name, last_name, email, gender, GPA) values (69, 'Chilton', 'Patsall', 'cpatsall1w@yellowbook.com', 'male', 3.65);
insert into student (id, first_name, last_name, email, gender, GPA) values (70, 'Ebony', 'Duddridge', 'eduddridge1x@networkadvertising.org', 'female', 3.56);
insert into student (id, first_name, last_name, email, gender, GPA) values (71, 'Munmro', 'Pitson', 'mpitson1y@ameblo.jp', 'male', 3.11);
insert into student (id, first_name, last_name, email, gender, GPA) values (72, 'Merla', 'Bruff', 'mbruff1z@cnet.com', 'male', 3.44);
insert into student (id, first_name, last_name, email, gender, GPA) values (73, 'Stanton', 'McDermot', 'smcdermot20@lulu.com', 'female', 3.42);
insert into student (id, first_name, last_name, email, gender, GPA) values (74, 'Christina', 'Pietzker', 'cpietzker21@wikipedia.org', 'female', 3.0);
insert into student (id, first_name, last_name, email, gender, GPA) values (75, 'Crin', 'MacGinlay', 'cmacginlay22@psu.edu', 'male', 3.5);
insert into student (id, first_name, last_name, email, gender, GPA) values (76, 'Kiele', 'Beange', 'kbeange23@squarespace.com', 'female', 3.8);
insert into student (id, first_name, last_name, email, gender, GPA) values (77, 'Keir', 'O''Loinn', 'koloinn24@toplist.cz', 'male', 3.74);
insert into student (id, first_name, last_name, email, gender, GPA) values (78, 'Nanci', 'Dodshon', 'ndodshon25@patch.com', 'male', 3.48);
insert into student (id, first_name, last_name, email, gender, GPA) values (79, 'Erika', 'Zukierman', 'ezukierman26@discuz.net', 'male', 3.39);
insert into student (id, first_name, last_name, email, gender, GPA) values (80, 'Barbabra', 'Vallack', 'bvallack27@seesaa.net', 'female', 3.19);
insert into student (id, first_name, last_name, email, gender, GPA) values (81, 'Lidia', 'Pinchback', 'lpinchback28@meetup.com', 'male', 3.16);
insert into student (id, first_name, last_name, email, gender, GPA) values (82, 'Joey', 'Panyer', 'jpanyer29@1688.com', 'male', 3.39);
insert into student (id, first_name, last_name, email, gender, GPA) values (83, 'Benedick', 'Crix', 'bcrix2a@elegantthemes.com', 'male', 3.91);
insert into student (id, first_name, last_name, email, gender, GPA) values (84, 'Shari', 'Bernon', 'sbernon2b@dion.ne.jp', 'male', 3.82);
insert into student (id, first_name, last_name, email, gender, GPA) values (85, 'Adria', 'Olman', 'aolman2c@dell.com', 'male', 3.9);
insert into student (id, first_name, last_name, email, gender, GPA) values (86, 'Finlay', 'Clewes', 'fclewes2d@google.co.uk', 'female', 3.78);
insert into student (id, first_name, last_name, email, gender, GPA) values (87, 'Karl', 'Calderon', 'kcalderon2e@japanpost.jp', 'female', 3.43);
insert into student (id, first_name, last_name, email, gender, GPA) values (88, 'Ina', 'Bugdale', 'ibugdale2f@histats.com', 'male', 3.06);
insert into student (id, first_name, last_name, email, gender, GPA) values (89, 'Perla', 'Plascott', 'pplascott2g@youtu.be', 'male', 3.75);
insert into student (id, first_name, last_name, email, gender, GPA) values (90, 'Wandie', 'Doggart', 'wdoggart2h@wiley.com', 'female', 3.67);
insert into student (id, first_name, last_name, email, gender, GPA) values (91, 'Brannon', 'Montez', 'bmontez2i@sciencedirect.com', 'male', 3.99);
insert into student (id, first_name, last_name, email, gender, GPA) values (92, 'Susi', 'Byneth', 'sbyneth2j@alibaba.com', 'male', 3.84);
insert into student (id, first_name, last_name, email, gender, GPA) values (93, 'Kathlin', 'Kingshott', 'kkingshott2k@reddit.com', 'male', 3.56);
insert into student (id, first_name, last_name, email, gender, GPA) values (94, 'Dominic', 'Kender', 'dkender2l@indiatimes.com', 'male', 3.61);
insert into student (id, first_name, last_name, email, gender, GPA) values (95, 'Garik', 'Lightwood', 'glightwood2m@stanford.edu', 'male', 3.34);
insert into student (id, first_name, last_name, email, gender, GPA) values (96, 'Micky', 'Bengle', 'mbengle2n@sitemeter.com', 'male', 3.58);
insert into student (id, first_name, last_name, email, gender, GPA) values (97, 'Finley', 'Tokell', 'ftokell2o@etsy.com', 'male', 3.55);
insert into student (id, first_name, last_name, email, gender, GPA) values (98, 'Huey', 'Izhakov', 'hizhakov2p@twitpic.com', 'male', 3.67);
insert into student (id, first_name, last_name, email, gender, GPA) values (99, 'Ada', 'Logesdale', 'alogesdale2q@imgur.com', 'male', 3.26);
insert into student (id, first_name, last_name, email, gender, GPA) values (100, 'Lenette', 'Northey', 'lnorthey2r@paypal.com', 'male', 3.17);

/* university */
insert into university (university_id, university_name, states, university_ranking ) values (1, 'College of the Holy Spirit', 'New Mexico', 8);
insert into university (university_id, university_name, states, university_ranking ) values (2, 'Dokkyo University', 'Tennessee', 12);
insert into university (university_id, university_name, states, university_ranking ) values (3, 'University of Nigeria', 'Pennsylvania', 2);
insert into university (university_id, university_name, states, university_ranking ) values (4, 'Khulna University of Engineering And Technology', 'Florida', 18);
insert into university (university_id, university_name, states, university_ranking ) values (5, 'Technological Education Institute of Epiros', 'Florida', 8);
insert into university (university_id, university_name, states, university_ranking ) values (6, 'Chao Yang University of Science and Technology', 'Florida', 9);
insert into university (university_id, university_name, states, university_ranking ) values (7, 'Michigan Technological University', 'Arizona', 16);
insert into university (university_id, university_name, states, university_ranking ) values (8, 'University of Connecticut at Hartford', 'District of Columbia', 47);
insert into university (university_id, university_name, states, university_ranking ) values (9, 'St. Meinrad College', 'Florida', 14);
insert into university (university_id, university_name, states, university_ranking ) values (10, 'Miami University of Ohio - Hamilton', 'Florida', 43);
insert into university (university_id, university_name, states, university_ranking ) values (11, 'Instituto Tecnológico de Querétaro', 'Pennsylvania', 10);
insert into university (university_id, university_name, states, university_ranking ) values (12, 'Patuakhali Science and Technology University', 'Illinois', 14);
insert into university (university_id, university_name, states, university_ranking ) values (13, 'Tsurumi University', 'North Carolina', 19);
insert into university (university_id, university_name, states, university_ranking ) values (14, 'Universidad Católica de Occidente', 'Ohio', 32);
insert into university (university_id, university_name, states, university_ranking ) values (15, 'Vanguard University of Southern California', 'Ohio', 17);
insert into university (university_id, university_name, states, university_ranking ) values (16, 'Molde University College', 'Tennessee', 50);
insert into university (university_id, university_name, states, university_ranking ) values (17, 'Odessa National Polytechnic University', 'District of Columbia', 19);
insert into university (university_id, university_name, states, university_ranking ) values (18, 'Federal College Of Education (Technical), Akoka', 'Florida', 29);
insert into university (university_id, university_name, states, university_ranking ) values (19, 'Dominican University', 'Ohio', 31);
insert into university (university_id, university_name, states, university_ranking ) values (20, 'Agriculture and Forestry University', 'Oregon', 19);
insert into university (university_id, university_name, states, university_ranking ) values (21, 'University of Szczecin', 'Georgia', 15);
insert into university (university_id, university_name, states, university_ranking ) values (22, 'Universidade Camilo Castelo Branco', 'Michigan', 18);
insert into university (university_id, university_name, states, university_ranking ) values (23, 'Ecole Nationale Vétérinaire de Lyon', 'Missouri', 44);
insert into university (university_id, university_name, states, university_ranking ) values (24, 'Singhania University Rajasthan', 'New York', 37);
insert into university (university_id, university_name, states, university_ranking ) values (25, 'Liszt Ferenc Academy of Music Budapest', 'Ohio', 21);
insert into university (university_id, university_name, states, university_ranking ) values (26, 'Universidad El Bosque', 'Ohio', 42);
insert into university (university_id, university_name, states, university_ranking ) values (27, 'University of Sharjah', 'Missouri', 32);
insert into university (university_id, university_name, states, university_ranking ) values (28, 'Hamamatsu University School of Medicine', 'Louisiana', 43);
insert into university (university_id, university_name, states, university_ranking ) values (29, 'Wolkite University', 'Florida', 40);
insert into university (university_id, university_name, states, university_ranking ) values (30, 'Southeastern University', 'Minnesota', 13);
insert into university (university_id, university_name, states, university_ranking ) values (31, 'Kenya College of Accountancy', 'New York', 22);
insert into university (university_id, university_name, states, university_ranking ) values (32, 'Manchester College', 'Oklahoma', 40);
insert into university (university_id, university_name, states, university_ranking ) values (33, 'Help University College', 'Texas', 17);
insert into university (university_id, university_name, states, university_ranking ) values (34, 'University of Medicine and Pharmacy of Iasi', 'Wisconsin', 2);
insert into university (university_id, university_name, states, university_ranking ) values (35, 'Hyupsung University', 'New York', 46);
insert into university (university_id, university_name, states, university_ranking ) values (36, 'Universidad Don Bosco', 'Minnesota', 20);
insert into university (university_id, university_name, states, university_ranking ) values (37, 'Chonju National University of Education', 'Ohio', 11);
insert into university (university_id, university_name, states, university_ranking ) values (38, 'Arak University of Medical Sciences', 'Oklahoma', 46);
insert into university (university_id, university_name, states, university_ranking ) values (39, 'Károl Gáspár University of the Reformed Church', 'California', 47);
insert into university (university_id, university_name, states, university_ranking ) values (40, 'Upper Iowa University', 'Minnesota', 25);
insert into university (university_id, university_name, states, university_ranking ) values (41, 'Zagazig University', 'Washington', 5);
insert into university (university_id, university_name, states, university_ranking ) values (42, 'Chosun University', 'New York', 48);
insert into university (university_id, university_name, states, university_ranking ) values (43, 'Al-Islah University', 'Washington', 24);
insert into university (university_id, university_name, states, university_ranking ) values (44, 'Islamic Azad University, Aliabad ', 'Texas', 8);
insert into university (university_id, university_name, states, university_ranking ) values (45, 'Baylor University', 'Florida', 43);
insert into university (university_id, university_name, states, university_ranking ) values (46, 'Jawaharlal Nehru Agricultural University', 'Texas', 19);
insert into university (university_id, university_name, states, university_ranking ) values (47, 'Freed-Hardeman University', 'Texas', 34);
insert into university (university_id, university_name, states, university_ranking ) values (48, 'Guangdong University of Foreign Studies', 'Pennsylvania', 31);
insert into university (university_id, university_name, states, university_ranking ) values (49, 'Applied Science University', 'Texas', 43);
insert into university (university_id, university_name, states, university_ranking ) values (50, 'University of Cassino', 'California', 15);
insert into university (university_id, university_name, states, university_ranking ) values (51, 'Université Kasdi Merbah Ouargla', 'Louisiana', 23);
insert into university (university_id, university_name, states, university_ranking ) values (52, 'Centro Universitario Villanueva', 'Texas', 3);
insert into university (university_id, university_name, states, university_ranking ) values (53, 'University of Food Technology', 'Florida', 37);
insert into university (university_id, university_name, states, university_ranking ) values (54, 'Odessa National Marine University', 'Ohio', 46);
insert into university (university_id, university_name, states, university_ranking ) values (55, 'University of Basrah', 'Georgia', 29);
insert into university (university_id, university_name, states, university_ranking ) values (56, 'Military academy of Lithuania', 'Pennsylvania', 25);
insert into university (university_id, university_name, states, university_ranking ) values (57, 'Fordham University', 'Florida', 30);
insert into university (university_id, university_name, states, university_ranking ) values (58, 'Centenary College of Louisiana', 'Nevada', 1);
insert into university (university_id, university_name, states, university_ranking ) values (59, 'Qinghai University', 'California', 23);
insert into university (university_id, university_name, states, university_ranking ) values (60, 'Universität Erfurt', 'Florida', 10);
insert into university (university_id, university_name, states, university_ranking ) values (61, 'Politeknik Negeri Padang', 'Illinois', 30);
insert into university (university_id, university_name, states, university_ranking ) values (62, 'University of Mustansiriyah', 'Arizona', 38);
insert into university (university_id, university_name, states, university_ranking ) values (63, 'Ballsbridge University ', 'Virginia', 12);
insert into university (university_id, university_name, states, university_ranking ) values (64, 'Kumamoto University', 'California', 17);
insert into university (university_id, university_name, states, university_ranking ) values (65, 'Université de Chlef', 'Florida', 43);
insert into university (university_id, university_name, states, university_ranking ) values (66, 'University of Sheffield', 'California', 25);
insert into university (university_id, university_name, states, university_ranking ) values (67, 'Universidad Nacional de Chimborazo', 'Illinois', 7);
insert into university (university_id, university_name, states, university_ranking ) values (68, 'Royal Danish School of Educational Sciences', 'California', 32);
insert into university (university_id, university_name, states, university_ranking ) values (69, 'University of Veterinary Science', 'Iowa', 10);
insert into university (university_id, university_name, states, university_ranking ) values (70, 'Bauchi State University, Gadau', 'Alabama', 3);
insert into university (university_id, university_name, states, university_ranking ) values (71, 'DIPLOMA-Fachhochschule Ölsnitz/Vogtland', 'California', 5);
insert into university (university_id, university_name, states, university_ranking ) values (72, 'Shanxi Normal University', 'New York', 5);
insert into university (university_id, university_name, states, university_ranking ) values (73, 'Islamic Azad University, Janah', 'Mississippi', 26);
insert into university (university_id, university_name, states, university_ranking ) values (74, 'Royal Danish School of Pharmacy', 'Florida', 13);
insert into university (university_id, university_name, states, university_ranking ) values (75, 'Tabor College', 'Massachusetts', 36);
insert into university (university_id, university_name, states, university_ranking ) values (76, 'Jumeira University', 'New York', 42);
insert into university (university_id, university_name, states, university_ranking ) values (77, 'University of Bihac', 'Tennessee', 11);
insert into university (university_id, university_name, states, university_ranking ) values (78, 'California Western School of Law', 'Texas', 30);
insert into university (university_id, university_name, states, university_ranking ) values (79, 'Tunku Syed Sirajuddin Polytechnic', 'District of Columbia', 48);
insert into university (university_id, university_name, states, university_ranking ) values (80, 'Institute of Architecture "Ion Mincu" Bucharest', 'North Carolina', 19);
insert into university (university_id, university_name, states, university_ranking ) values (81, 'University of Zilinska', 'New Mexico', 45);
insert into university (university_id, university_name, states, university_ranking ) values (82, 'University of the Assumption', 'Illinois', 27);
insert into university (university_id, university_name, states, university_ranking ) values (83, 'Turku School of Economics and Business Administration', 'South Carolina', 37);
insert into university (university_id, university_name, states, university_ranking ) values (84, 'Buddhasravaka Bhikshu University', 'New Jersey', 15);
insert into university (university_id, university_name, states, university_ranking ) values (85, 'Millsaps College', 'Louisiana', 37);
insert into university (university_id, university_name, states, university_ranking ) values (86, 'Crichton College', 'Florida', 6);
insert into university (university_id, university_name, states, university_ranking ) values (87, 'Kurgan International University', 'District of Columbia', 49);
insert into university (university_id, university_name, states, university_ranking ) values (88, 'Thi Qar University', 'Georgia', 20);
insert into university (university_id, university_name, states, university_ranking ) values (89, 'Pontifícia Universidade Católica de Minas Gerais', 'California', 26);
insert into university (university_id, university_name, states, university_ranking ) values (90, 'Hunan Agricultural University', 'Ohio', 38);
insert into university (university_id, university_name, states, university_ranking ) values (91, 'Adama Science and Technology University', 'California', 12);
insert into university (university_id, university_name, states, university_ranking ) values (92, 'Komazawa University', 'California', 45);
insert into university (university_id, university_name, states, university_ranking ) values (93, 'Sakarya University', 'Missouri', 11);
insert into university (university_id, university_name, states, university_ranking ) values (94, 'Chiba Institute of Technology', 'Georgia', 14);
insert into university (university_id, university_name, states, university_ranking ) values (95, 'Institute of Teachers Education, Tuanku Bainun', 'New York', 43);
insert into university (university_id, university_name, states, university_ranking ) values (96, 'Pacific Adventist University', 'District of Columbia', 28);
insert into university (university_id, university_name, states, university_ranking ) values (97, 'Anna Maria College', 'North Carolina', 35);
insert into university (university_id, university_name, states, university_ranking ) values (98, 'Millennia Atlantic University', 'Minnesota', 15);
insert into university (university_id, university_name, states, university_ranking ) values (99, 'Eckerd College', 'Texas', 30);
insert into university (university_id, university_name, states, university_ranking ) values (100, 'Louisiana State University at Eunice', 'Alabama', 31);



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO applied_to (student_id, university_id, admitted)
select s.id, u.university_id, random() > 0.7 
from student as s, university as u where random() <= 0.1;
