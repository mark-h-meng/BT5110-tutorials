/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/

/* Name: Li Xinlin
   Student ID: A0150639A
   Email: E0015720@u.nus.edu  */

/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/

/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*

In this project, will take online book store case as an example of application.
There are two main tables customers and books to store the customers' and books' info respectively.

We can create the first entity set E1 as table 'customers', which store the details of customer 
as data dictionary shown below: 

-- customer_id  (varchar)   :customer's identification no, like SG NRIC/FIN No in IC which is unique and not null, can set as primary key.             
-- customer_name (varchar)  :customer's detail name
-- gender (varchar)         :customer's gender, strictly limited to male or female
-- dob (varchar)            :customer's date of bith
-- email (varchar)          :customer's email contact
-- nationality (varchar)    :customer's nationality  			       


Following we can created second entity set E2 as table 'books', which store the info of books, 
and data dictionary shown below:	

-- book_id (varchar)        :Book's ISBN no issued by publisher,which is unique and not null,set as composite primary key with book name.
-- book_name (varchar)      :Detail name of this book and unique matching the ISBN No. Set as composite primary key with book id.
-- author (varchar)         :Author (person's name) of this book.              
-- publisher (varchar)      :Publisher (company name) of this book.             
-- price (int)	            :Retail price for this book.  
 
As mentioned this is a online book store, when the customers place the order for their desired books and
make the payment, we can say that the new relationship has been built. Hence we can create the new
many-to-many relationsip set (R) as table 'orders'. Each row of this table will record the details of
order that which customer placed the order for which book with respective price. Thus this table could be only be populated
after the table 'customers' and 'books' being populated because of the referential integrity constraints (FOREIGN KEY).

The data dictionary for `orders` as shown below:

-- customer_id (varchar)     :Customer's id no which is referenced from main table `customers`(E1) and set as one of composite primary key.	  	
-- book_id (varchar)         :Book's id no which is referenced from main table `books`(E2) and set as one of composite primary key.	  
-- book_name (varchar)       :Book's name no which is referenced from main table `books`(E2) and set as one of composite primary key.
-- payment (int)	         :The amount payable for this order, which is the retail price of this book.
		
Once we have completed the design of this entity relationship, 
we may proceed to design the query in following quesitons by PostgreSQL.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */


drop table if exists orders;
drop table if exists customers;
drop table if exists books;


-- create table customers
create table if not exists customers (
		customer_id VARCHAR(16) primary key,
		customer_name VARCHAR(32) not null,
		gender VARCHAR(8) constraint gender check(gender = 'Male' or gender='Female'),
		dob VARCHAR(16),
		email VARCHAR(64),
		nationality VARCHAR(32)
);

-- create table books
create table if not exists books (
		book_id VARCHAR(16),
		book_name VARCHAR(128),
		author VARCHAR(128) not null,
		publisher VARCHAR(128) not null,
		price INT not null,
		primary key (book_id,book_name)
);

-- create table orders
create table if not exists orders (
		customer_id varchar(16) references customers (customer_id) on update cascade on delete cascade deferrable initially deferred,
	    book_id varchar(16),
		book_name varchar(128),
		payment int,
		foreign key (book_id,book_name) references books (book_id,book_name),
		primary key (customer_id,book_id,book_name)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

-- Populate datasets for table customers (E1):
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('U7765481Z', 'Shara Zorener', 'Female', '04/08/1980', 'szorener0@wikimedia.org', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('G6758793X', 'Dimitri Barrott', 'Male', '13/10/1979', 'dbarrott1@timesonline.co.uk', 'Brazil');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('Z3476892J', 'Lyell Eliasen', 'Male', '31/03/2003', 'leliasen2@163.com', 'United States');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('S5896877X', 'Berri Heinel', 'Female', '13/02/1990', 'bheinel3@imdb.com', 'Jordan');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('W9810033I', 'Shani Grimsell', 'Male', '19/11/1994', 'sgrimsell4@admin.ch', 'Sweden');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('Y2232552P', 'Tammie Laurenceau', 'Male', '13/08/1968', 'tlaurenceau5@soup.io', 'Indonesia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('G9867300K', 'Dominick Quakley', 'Male', '10/07/1965', 'dquakley6@google.ru', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('X5475617R', 'Jermayne Stocking', 'Male', '12/01/1967', 'jstocking7@qq.com', 'Sweden');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('R9709143G', 'Darrell Gonzalo', 'Male', '24/09/2002', 'dgonzalo8@marriott.com', 'Philippines');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('L4942564A', 'Conny Clemendet', 'Female', '27/06/1997', 'cclemendet9@aol.com', 'Russia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('G1547104Z', 'Bili Webburn', 'Male', '31/07/1976', 'bwebburna@unblog.fr', 'Argentina');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('V0428532S', 'Elvera Gutowski', 'Male', '18/08/2000', 'egutowskib@hugedomains.com', 'Ireland');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('O3915008Y', 'Bartlett Jime', 'Male', '12/10/1973', 'bjimec@cisco.com', 'Malaysia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('Y7724243V', 'Myrtice Hall', 'Male', '13/07/2001', 'mhalld@is.gd', 'Libya');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('D1461599L', 'Miof mela Wooding', 'Female', '30/11/1976', 'mmelae@homestead.com', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('U4642134P', 'Braden Kennea', 'Male', '16/05/1994', 'bkenneaf@wsj.com', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('R5016923K', 'Devan Bulstrode', 'Male', '12/11/1971', 'dbulstrodeg@dion.ne.jp', 'Philippines');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('I3019487O', 'Charleen Attenbrow', 'Male', '09/08/1973', 'cattenbrowh@epa.gov', 'Brazil');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('P8372136E', 'Fonz Rosenbusch', 'Male', '07/07/1981', 'frosenbuschi@ebay.com', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('L6918983T', 'Vaughan Buddle', 'Male', '01/01/1978', 'vbuddlej@de.vu', 'Netherlands');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('Z4193795J', 'Katie Champness', 'Female', '31/12/1986', 'kchampnessk@yandex.ru', 'South Africa');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('N0315649Z', 'Vitoria Faint', 'Male', '23/09/1983', 'vfaintl@google.com.hk', 'Azerbaijan');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('H5628330N', 'Marney Yakuntzov', 'Female', '02/03/1995', 'myakuntzovm@mediafire.com', 'Ukraine');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('M3984969I', 'Cherianne Slyman', 'Male', '23/01/1987', 'cslymann@constantcontact.com', 'Tunisia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('A6159726I', 'Carmelita Haizelden', 'Male', '24/07/2000', 'chaizeldeno@webeden.co.uk', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('C9803762A', 'Jacky MacRitchie', 'Male', '29/11/1969', 'jmacritchiep@typepad.com', 'Indonesia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('I5516108R', 'Nahum Gockelen', 'Female', '07/09/1991', 'ngockelenq@whitehouse.gov', 'Ukraine');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('E1446757A', 'Cosette Pimlett', 'Male', '13/11/1966', 'cpimlettr@epa.gov', 'Netherlands');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('G0721139K', 'Charlot Hunnawill', 'Female', '07/10/1995', 'chunnawills@upenn.edu', 'Japan');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('L4022027U', 'Tymon Lally', 'Male', '12/02/1989', 'tlallyt@smh.com.au', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('R5779792F', 'Dannye Hampshire', 'Female', '22/09/1981', 'dhampshireu@webmd.com', 'Estonia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('B5951182Q', 'Jamesy Oliver', 'Male', '30/04/1999', 'joliverv@ftc.gov', 'Philippines');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('Z1776027X', 'Brocky Cline', 'Male', '30/04/2002', 'bclinew@google.de', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('C1126622A', 'Averell Lawling', 'Male', '23/01/1973', 'alawlingx@state.gov', 'Indonesia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('O2883855A', 'Brody Leverett', 'Female', '29/01/1980', 'bleveretty@nhs.uk', 'Peru');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('B5753254T', 'Katrinka Underwood', 'Male', '05/12/2000', 'kunderwoodz@cpanel.net', 'Greece');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('D6089383C', 'Fidelio Annon', 'Female', '15/06/1989', 'fannon10@dedecms.com', 'Bahamas');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('N0771425F', 'Nadeen MacAfee', 'Female', '03/01/1971', 'nmacafee11@japanpost.jp', 'Macedonia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('A3075812Z', 'Barbabra Philippart', 'Male', '22/10/1986', 'bphilippart12@last.fm', 'Indonesia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('B4377185G', 'Tedi Parvin', 'Female', '06/05/1979', 'tparvin13@marketwatch.com', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('N0965987R', 'Arleyne Montgomery', 'Female', '12/12/1971', 'amontgomery14@google.cn', 'Micronesia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('N8636457K', 'Germain Treamayne', 'Female', '22/03/1972', 'gtreamayne15@altervista.org', 'Uruguay');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('T9003459C', 'Iosep Denison', 'Female', '30/04/1965', 'idenison16@buzzfeed.com', 'Greece');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('G3487433S', 'Ivette Dewbury', 'Female', '23/05/1991', 'idewbury17@indiatimes.com', 'Indonesia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('T0859558K', 'Hilliard Lesmonde', 'Female', '30/08/1970', 'hlesmonde18@last.fm', 'Poland');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('H4558039V', 'Valentine Basill', 'Male', '05/06/1997', 'vbasill19@fotki.com', 'Russia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('G2873269G', 'Junia Reyne', 'Male', '14/08/1995', 'jreyne1a@businessweek.com', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('O0187921Y', 'Kareem Butters', 'Female', '07/01/1993', 'kbutters1b@seesaa.net', 'Belarus');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('P6425391W', 'Natassia Schouthede', 'Male', '15/05/1985', 'nschouthede1c@about.com', 'Philippines');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('V0026524P', 'Walliw Dutson', 'Female', '14/06/1965', 'wdutson1d@w3.org', 'Poland');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('U7888619N', 'Mariellen Garnett', 'Female', '01/02/1993', 'mgarnett1e@zimbio.com', 'Ukraine');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('H8342301N', 'Alexandro Royste', 'Male', '24/09/1965', 'aroyste1f@cmu.edu', 'Ukraine');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('X6605632I', 'Verena Andrzejowski', 'Female', '25/09/1991', 'vandrzejowski1g@deliciousdays.com', 'Japan');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('I7036724U', 'Oralia Pammenter', 'Female', '18/08/1985', 'opammenter1h@skyrock.com', 'Serbia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('F4012342H', 'Jobie Mateja', 'Female', '25/02/1971', 'jmateja1i@theguardian.com', 'South Korea');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('S8338264U', 'Rowney Drakeford', 'Female', '04/06/1965', 'rdrakeford1j@istockphoto.com', 'Malawi');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('S7050693H', 'Gwenora Jocic', 'Male', '19/01/2003', 'gjocic1k@vimeo.com', 'Mali');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('Z5748875L', 'Hyman Emburey', 'Female', '26/12/1970', 'hemburey1l@ted.com', 'Venezuela');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('D4567396B', 'Caresa Gainsford', 'Female', '25/11/1983', 'cgainsford1m@gravatar.com', 'France');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('W8034839X', 'Lemmy Gurling', 'Female', '30/09/2001', 'lgurling1n@netvibes.com', 'Venezuela');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('X3155735J', 'Margarethe Izen', 'Female', '28/04/1970', 'mizen1o@dailymotion.com', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('P6385408U', 'Hillel Devanney', 'Male', '07/05/1993', 'hdevanney1p@google.ru', 'Indonesia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('Z3026883O', 'Catlee Hockell', 'Male', '21/05/1982', 'chockell1q@youtu.be', 'South Africa');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('T8538733R', 'Caro Jukubczak', 'Male', '03/09/2002', 'cjukubczak1r@yahoo.co.jp', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('G8158294B', 'Paco Bellsham', 'Female', '12/09/1982', 'pbellsham1s@army.mil', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('S3413656L', 'Candra Gledstane', 'Male', '29/09/1978', 'cgledstane1t@xing.com', 'Laos');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('P8990865A', 'Alvis Gaytor', 'Female', '04/10/1993', 'agaytor1u@wordpress.org', 'Switzerland');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('I9272479T', 'Fleur Danilchik', 'Male', '06/08/1983', 'fdanilchik1v@comsenz.com', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('C3523187I', 'Richardo Pettiford', 'Male', '16/09/1984', 'rpettiford1w@harvard.edu', 'Indonesia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('C9717981K', 'Ollie Smoote', 'Male', '17/07/1990', 'osmoote1x@tiny.cc', 'Indonesia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('E8085983R', 'Lorin Shuttle', 'Female', '06/05/1971', 'lshuttle1y@tumblr.com', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('S8236175O', 'Greggory Luipold', 'Male', '01/09/1977', 'gluipold1z@rambler.ru', 'Sweden');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('R1698238F', 'Damiano Dudley', 'Female', '15/06/1968', 'ddudley20@yale.edu', 'Thailand');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('Z6501838E', 'Vivyan Rosenthal', 'Male', '22/05/1973', 'vrosenthal21@paypal.com', 'Indonesia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('V0355364N', 'Gaspard Lettice', 'Male', '25/02/1974', 'glettice22@xing.com', 'France');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('A8715720X', 'Bartram Rogerson', 'Female', '31/01/2003', 'brogerson23@google.com.au', 'Russia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('Y6113187C', 'Susanne Manger', 'Female', '31/07/1968', 'smanger24@noaa.gov', 'Portugal');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('K1274565O', 'Othella Vasiliu', 'Male', '23/12/1993', 'ovasiliu25@storify.com', 'Syria');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('J5299181G', 'Bidget LAbbet', 'Male', '23/03/1978', 'blabbet26@webeden.co.uk', 'Poland');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('E4059024P', 'Fiorenze Durrand', 'Male', '05/05/1981', 'fdurrand27@sogou.com', 'Brazil');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('J7320794M', 'Feliks Pavlik', 'Female', '29/11/1977', 'fpavlik28@gov.uk', 'Mongolia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('G4863072Z', 'Felice Waye', 'Female', '19/05/1991', 'fwaye29@ning.com', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('A7927799W', 'Brenden Bontein', 'Male', '03/08/1993', 'bbontein2a@a8.net', 'Lithuania');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('X9833917D', 'Florie Sissot', 'Female', '15/08/1987', 'fsissot2b@newyorker.com', 'Russia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('K4517813U', 'Benni Layus', 'Female', '14/03/1966', 'blayus2c@wordpress.com', 'United States');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('Q0838741Y', 'Alica Cole', 'Female', '21/02/1970', 'acole2d@smugmug.com', 'Czech Republic');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('Z2355585P', 'Aubry Ropartz', 'Female', '26/04/1996', 'aropartz2e@spotify.com', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('F3155336J', 'Tabbie Pietrowski', 'Female', '15/12/1996', 'tpietrowski2f@infoseek.co.jp', 'Iran');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('O9819895J', 'Edgar Walkowski', 'Male', '01/09/1995', 'ewalkowski2g@disqus.com', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('K6236693C', 'Alisander Blacksell', 'Female', '17/05/1995', 'ablacksell2h@jigsy.com', 'Greece');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('Y9434676J', 'Rhetta Lauxmann', 'Female', '19/02/1977', 'rlauxmann2i@hud.gov', 'South Africa');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('V0846016I', 'Cullen Hathwood', 'Female', '27/08/1978', 'chathwood2j@phpbb.com', 'Mongolia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('Q7744592J', 'Jasun Farrand', 'Male', '24/01/1977', 'jfarrand2k@is.gd', 'Armenia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('V1750849Y', 'Simon Collingham', 'Female', '21/06/1999', 'scollingham2l@cmu.edu', 'Philippines');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('V4293005M', 'Griffie Buttfield', 'Male', '27/09/1972', 'gbuttfield2m@technorati.com', 'Russia');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('O3914997R', 'Lyn Missen', 'Female', '19/11/1973', 'lmissen2n@typepad.com', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('E6809134Z', 'Leesa Tufts', 'Female', '05/03/1975', 'ltufts2o@pbs.org', 'China');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('J7535201K', 'Zerk Cotterill', 'Female', '21/05/1967', 'zcotterill2p@nationalgeographic.com', 'Finland');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('K0325564L', 'Arlena MacKeague', 'Female', '23/11/1981', 'amackeague2q@techcrunch.com', 'Portugal');
insert into customers (customer_id, customer_name, gender, dob, email, nationality) values ('K6679811N', 'Lynnett Mein', 'Female', '03/03/1990', 'lmein2r@marketwatch.com', 'Syria');


-- Populate datasets for table books (E2):
insert into books (book_id, book_name, author, publisher, price) values ('750134567-8', 'Cop Out', 'Gordon', 'Cremin Group', 51);
insert into books (book_id, book_name, author, publisher, price) values ('130883510-8', 'Jackass Number Two', 'Donella', 'Marvin Inc', 44);
insert into books (book_id, book_name, author, publisher, price) values ('343669718-4', 'No End in Sight', 'Eddie', 'Ratke and Sons', 45);
insert into books (book_id, book_name, author, publisher, price) values ('166324842-7', 'Burn, Witch, Burn (Night of the Eagle)', 'Maible', 'Simonis, Roob and Grant', 53);
insert into books (book_id, book_name, author, publisher, price) values ('515916990-3', 'Hear My Song', 'Harriette', 'Weber, McLaughlin and Okuneva', 58);
insert into books (book_id, book_name, author, publisher, price) values ('901752687-4', 'Invisible Ghost', 'Isabella', 'Effertz-Marquardt', 78);
insert into books (book_id, book_name, author, publisher, price) values ('492573383-4', 'Runaway', 'Grata', 'Tillman-Graham', 56);
insert into books (book_id, book_name, author, publisher, price) values ('633194140-1', 'No Reservations', 'Jacques', 'O''Reilly-Waelchi', 49);
insert into books (book_id, book_name, author, publisher, price) values ('998022617-X', 'California Dreamin'' (Nesfarsit)', 'Shepperd', 'Krajcik, Nicolas and Kassulke', 45);
insert into books (book_id, book_name, author, publisher, price) values ('403911925-8', 'Goddess of 1967, The', 'Pearla', 'Bailey-Huels', 33);
insert into books (book_id, book_name, author, publisher, price) values ('926045644-4', 'Dhoondte Reh Jaoge', 'Mirna', 'Brekke LLC', 33);
insert into books (book_id, book_name, author, publisher, price) values ('844726578-1', 'Street Fight', 'Gwenni', 'Kemmer, Jerde and Medhurst', 57);
insert into books (book_id, book_name, author, publisher, price) values ('893559403-2', 'Heaven', 'Will', 'Hane, Jacobson and Lind', 60);
insert into books (book_id, book_name, author, publisher, price) values ('497867568-5', 'Scanners III: The Takeover (Scanner Force)', 'Jeno', 'Swaniawski, Hackett and O''Hara', 54);
insert into books (book_id, book_name, author, publisher, price) values ('254083279-2', 'Imaginary Witness: Hollywood and the Holocaust ', 'Rosalynd', 'Legros Group', 52);
insert into books (book_id, book_name, author, publisher, price) values ('975420466-7', 'Red Doors', 'Yoshiko', 'Herzog-Keeling', 25);
insert into books (book_id, book_name, author, publisher, price) values ('389457843-2', 'Magicians', 'Dacie', 'Schamberger, Osinski and Schaefer', 34);
insert into books (book_id, book_name, author, publisher, price) values ('783717397-X', 'Get Thrashed: The Story of Thrash Metal', 'Bertie', 'Schneider, Kuphal and Mueller', 40);
insert into books (book_id, book_name, author, publisher, price) values ('606629604-3', 'Rush Hour 2', 'Cassandra', 'Champlin, Rosenbaum and Nitzsche', 45);
insert into books (book_id, book_name, author, publisher, price) values ('641383808-6', 'Boy of the Streets', 'Karlene', 'Brakus and Sons', 48);
insert into books (book_id, book_name, author, publisher, price) values ('400650976-6', 'Playground', 'Cari', 'Beahan and Sons', 52);
insert into books (book_id, book_name, author, publisher, price) values ('301562852-6', 'In the Cut', 'Arman', 'Koss, Cormier and Braun', 31);
insert into books (book_id, book_name, author, publisher, price) values ('417400088-3', 'Funny Lady', 'Beaufort', 'Rice, Kunde and Friesen', 53);
insert into books (book_id, book_name, author, publisher, price) values ('233207445-7', 'Scattered Clouds (Midaregumo)', 'Jennie', 'Bogisich-Larkin', 43);
insert into books (book_id, book_name, author, publisher, price) values ('607375166-4', 'Wrath of God, The', 'Corry', 'Stokes, Hettinger and Dickens', 34);
insert into books (book_id, book_name, author, publisher, price) values ('452673527-2', 'Ali: Fear Eats the Soul (Angst essen Seele auf)', 'Mart', 'Hintz-Nolan', 36);
insert into books (book_id, book_name, author, publisher, price) values ('790332394-6', 'Grapes of Death, The (Raisins de la mort, Les)', 'Roderich', 'Kuhlman Group', 46);
insert into books (book_id, book_name, author, publisher, price) values ('257700678-0', 'Ménilmontant', 'Hall', 'Bogisich LLC', 63);
insert into books (book_id, book_name, author, publisher, price) values ('439930781-1', 'Mantrap', 'Clevie', 'Rodriguez Group', 27);
insert into books (book_id, book_name, author, publisher, price) values ('193019940-6', 'Rose Seller, The (La vendedora de rosas)', 'Elmo', 'Kerluke Group', 40);
insert into books (book_id, book_name, author, publisher, price) values ('404058670-0', 'Beach Girls and the Monster, The', 'Hermina', 'McClure LLC', 22);
insert into books (book_id, book_name, author, publisher, price) values ('863244388-7', 'Brotherhood, The', 'Yalonda', 'Bartoletti and Sons', 69);
insert into books (book_id, book_name, author, publisher, price) values ('503140060-9', 'Treasure Hunter, The (Ci ling)', 'Geralda', 'Jerde, Bartoletti and Murphy', 23);
insert into books (book_id, book_name, author, publisher, price) values ('560275415-6', 'Anne of Green Gables', 'Claudie', 'Ferry Group', 43);
insert into books (book_id, book_name, author, publisher, price) values ('445406617-5', 'Zero 2', 'Guthrey', 'Jacobs, Gislason and Brown', 55);
insert into books (book_id, book_name, author, publisher, price) values ('986391904-7', 'Eddie Murphy Raw', 'Jeffry', 'Casper-Murray', 32);
insert into books (book_id, book_name, author, publisher, price) values ('434202986-3', 'Fitzwilly', 'Orelie', 'Koelpin-Mann', 42);
insert into books (book_id, book_name, author, publisher, price) values ('664800154-2', 'My Little Pony: Equestria Girls', 'Kerby', 'Kautzer-Rempel', 53);
insert into books (book_id, book_name, author, publisher, price) values ('939897775-3', 'Tripper, The', 'Ruddie', 'Beer Group', 67);
insert into books (book_id, book_name, author, publisher, price) values ('601194228-8', 'Run, Man, Run! (Corri uomo corri)', 'Tiena', 'Walker-D''Amore', 35);
insert into books (book_id, book_name, author, publisher, price) values ('575644626-5', 'Terkel in Trouble (Terkel i knibe)', 'Babb', 'Hammes Group', 39);
insert into books (book_id, book_name, author, publisher, price) values ('321775440-9', 'Proud Valley, The', 'Amabel', 'Vandervort LLC', 59);
insert into books (book_id, book_name, author, publisher, price) values ('931542702-5', 'Pharaoh''s Army', 'Archaimbaud', 'Ruecker and Sons', 25);
insert into books (book_id, book_name, author, publisher, price) values ('712264690-4', 'Woman in the Window, The', 'Halli', 'Hayes, Hoppe and Lowe', 77);
insert into books (book_id, book_name, author, publisher, price) values ('011837400-1', 'K-11', 'Leone', 'Funk Group', 60);
insert into books (book_id, book_name, author, publisher, price) values ('114206703-3', 'Swing Shift', 'Madella', 'Upton LLC', 21);
insert into books (book_id, book_name, author, publisher, price) values ('451231477-6', 'National Lampoon''s Van Wilder', 'Ulrich', 'Kassulke, Kemmer and Yundt', 68);
insert into books (book_id, book_name, author, publisher, price) values ('647381723-9', 'The Final Girl', 'Gipsy', 'Adams, Johnston and Conn', 19);
insert into books (book_id, book_name, author, publisher, price) values ('345825332-7', 'Fantastic Night, The (Nuit fantastique, La)', 'Karl', 'Swaniawski and Sons', 31);
insert into books (book_id, book_name, author, publisher, price) values ('610581618-9', 'Must Have Been Love', 'Gibb', 'Weimann-Zulauf', 41);
insert into books (book_id, book_name, author, publisher, price) values ('306775215-5', 'Poto and Cabengo', 'Hyacinthe', 'Rodriguez-Hintz', 46);
insert into books (book_id, book_name, author, publisher, price) values ('405266172-9', 'Go West', 'Vickie', 'Gorczany LLC', 24);
insert into books (book_id, book_name, author, publisher, price) values ('799199742-1', 'The Mark of the Angels - Miserere', 'Karim', 'Schroeder, Blick and Parisian', 49);
insert into books (book_id, book_name, author, publisher, price) values ('346720280-2', 'Revenge of the Pink Panther', 'Wait', 'Runte-Kuvalis', 8);
insert into books (book_id, book_name, author, publisher, price) values ('058853517-6', 'Legacy, The', 'Angus', 'Gleason Group', 61);
insert into books (book_id, book_name, author, publisher, price) values ('326678648-3', 'PAY 2 PLAY: Democracy''s High Stakes', 'Ines', 'Boyer, Jaskolski and Block', 58);
insert into books (book_id, book_name, author, publisher, price) values ('998296994-3', 'Return of Mod Squad, The', 'Gusty', 'Stroman, Fadel and Schultz', 62);
insert into books (book_id, book_name, author, publisher, price) values ('167587277-5', 'Buud Yam', 'Elicia', 'Conroy and Sons', 39);
insert into books (book_id, book_name, author, publisher, price) values ('501595646-0', 'In Your Hands (Forbrydelser)', 'Isac', 'Gerlach LLC', 27);
insert into books (book_id, book_name, author, publisher, price) values ('647297068-8', 'Tables Turned on the Gardener', 'Felice', 'Simonis-Rolfson', 64);
insert into books (book_id, book_name, author, publisher, price) values ('530657552-8', 'Ah, Wilderness!', 'Waiter', 'Hermann Inc', 35);
insert into books (book_id, book_name, author, publisher, price) values ('095874557-9', 'Dark Wind, The', 'Kennedy', 'Ondricka-O''Connell', 29);
insert into books (book_id, book_name, author, publisher, price) values ('558814725-1', 'Great Day in the Morning', 'Garland', 'Lemke-Kutch', 15);
insert into books (book_id, book_name, author, publisher, price) values ('836606327-5', 'Ace of Hearts', 'Lawrence', 'Lowe, DuBuque and Koch', 36);
insert into books (book_id, book_name, author, publisher, price) values ('405274542-6', 'Man of Her Dreams (a.k.a. The Fiancé)', 'Corny', 'Schaden-Friesen', 54);
insert into books (book_id, book_name, author, publisher, price) values ('225976948-9', 'Midsummer Night''s Party, A (Midsummer of Love, A) (Sommaren med Göran)', 'Giana', 'Kertzmann, Koch and Lowe', 50);
insert into books (book_id, book_name, author, publisher, price) values ('488123278-9', 'Sparrow (a.k.a. Cultured Bird) (Man jeuk)', 'Zorine', 'Heidenreich-Williamson', 44);
insert into books (book_id, book_name, author, publisher, price) values ('434634982-X', 'Vow, The', 'Mella', 'Douglas and Sons', 38);
insert into books (book_id, book_name, author, publisher, price) values ('142559921-4', 'Naked City, The', 'Russell', 'Kihn-Morar', 38);
insert into books (book_id, book_name, author, publisher, price) values ('053642042-4', 'Edge of Darkness', 'Wynn', 'Kutch Inc', 65);
insert into books (book_id, book_name, author, publisher, price) values ('486006084-9', 'You''re Next', 'Clem', 'Cummings-Glover', 38);
insert into books (book_id, book_name, author, publisher, price) values ('662291289-0', 'Destiny Turns on the Radio', 'Yvette', 'Gutkowski-Schowalter', 55);
insert into books (book_id, book_name, author, publisher, price) values ('889252297-3', 'Undefeated, The', 'Staford', 'Spinka Inc', 68);
insert into books (book_id, book_name, author, publisher, price) values ('983530913-2', 'Daddy Nostalgia (Daddy Nostalgie)', 'Richy', 'Blanda and Sons', 18);
insert into books (book_id, book_name, author, publisher, price) values ('141645107-2', 'Pitkä kuuma kesä', 'Magdalen', 'Mohr, Strosin and O''Conner', 51);
insert into books (book_id, book_name, author, publisher, price) values ('096722942-1', 'Limelight', 'Seline', 'Christiansen, Wunsch and Johnston', 29);
insert into books (book_id, book_name, author, publisher, price) values ('580474150-0', 'Eye for an Eye, An', 'Conway', 'Wiza, Russel and Stoltenberg', 34);
insert into books (book_id, book_name, author, publisher, price) values ('300168353-8', 'American Drug War: The Last White Hope', 'Lucina', 'Rowe-Jenkins', 39);
insert into books (book_id, book_name, author, publisher, price) values ('822224151-6', 'XIII: The Conspiracy', 'Minna', 'Romaguera-Tromp', 72);
insert into books (book_id, book_name, author, publisher, price) values ('710984255-X', 'Coyote Ugly', 'Akim', 'Nicolas-Senger', 58);
insert into books (book_id, book_name, author, publisher, price) values ('421767977-7', 'Apt Pupil', 'Pryce', 'Botsford, Schamberger and Walter', 66);
insert into books (book_id, book_name, author, publisher, price) values ('689691570-6', 'Zoom', 'Terrie', 'Bechtelar-Crooks', 49);
insert into books (book_id, book_name, author, publisher, price) values ('792579302-3', 'Letting Go of God', 'Kim', 'Lubowitz-Okuneva', 40);
insert into books (book_id, book_name, author, publisher, price) values ('793666004-6', 'Something in the Air (Apres Mai)', 'Gwynne', 'Marks-Wilkinson', 65);
insert into books (book_id, book_name, author, publisher, price) values ('786437671-1', 'Election', 'Lennie', 'Koepp, Smith and Tillman', 49);
insert into books (book_id, book_name, author, publisher, price) values ('311494715-8', 'Lost Skeleton of Cadavra, The', 'Andreas', 'Conn, Kerluke and King', 41);
insert into books (book_id, book_name, author, publisher, price) values ('223995544-9', 'Auggie Rose (a.k.a. Beyond Suspicion)', 'Elwira', 'Vandervort, Pagac and Dach', 66);
insert into books (book_id, book_name, author, publisher, price) values ('498343945-5', 'Missile to the Moon', 'Valaria', 'Mohr-Nolan', 38);
insert into books (book_id, book_name, author, publisher, price) values ('598008763-X', 'Get to Know Your Rabbit', 'Ralina', 'Weimann-Baumbach', 32);
insert into books (book_id, book_name, author, publisher, price) values ('940558573-8', 'Lone Ranger, The', 'Brody', 'Pouros-Brown', 48);
insert into books (book_id, book_name, author, publisher, price) values ('962471454-1', 'Antitrust', 'Lynne', 'Walsh-Abbott', 28);
insert into books (book_id, book_name, author, publisher, price) values ('706449593-7', 'Dunwich Horror, The', 'Morgun', 'Stamm-Emard', 36);
insert into books (book_id, book_name, author, publisher, price) values ('168721925-7', 'Buud Yam', 'Elianora', 'Bernier LLC', 45);
insert into books (book_id, book_name, author, publisher, price) values ('807880472-5', 'When the Game Stands Tall', 'Robena', 'Kuhlman, Dicki and Stracke', 68);
insert into books (book_id, book_name, author, publisher, price) values ('068277981-4', 'Ten Minutes Older: The Trumpet', 'Nell', 'Graham-Marvin', 33);
insert into books (book_id, book_name, author, publisher, price) values ('597821408-5', 'Nana', 'Wren', 'Stiedemann Group', 53);
insert into books (book_id, book_name, author, publisher, price) values ('675474554-1', 'Incredible Shrinking Woman, The', 'Trace', 'Padberg and Sons', 60);
insert into books (book_id, book_name, author, publisher, price) values ('364970562-1', 'Hitch-Hiker, The', 'Devonne', 'Buckridge Inc', 53);
insert into books (book_id, book_name, author, publisher, price) values ('103522879-3', 'Fast Five (Fast and the Furious 5, The)', 'Gretchen', 'Bahringer, Goodwin and Morissette', 56);
insert into books (book_id, book_name, author, publisher, price) values ('403302546-4', 'Secret World of Arrietty, The (Kari-gurashi no Arietti)', 'Kassey', 'Homenick, Murazik and Weissnat', 45);


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

-- Populate the date for table orders (R) by using one single insert query with random()

insert into orders
select 
		c.customer_id,
		b.book_id,
		b.book_name,
		b.price as payment
from customers c cross join books b
order by random() <= 0.1
limit 1000;


-- Check the total number of result generated.
select count(*) from orders ;

-- Check the generated realtion table orders by random sampling.
select * 
from orders
order by random()
limit 10;

