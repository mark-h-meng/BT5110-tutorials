/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*Entity set E1 is set to be customer, while E2 is product from a certain 
grocery store.
Table E1 contains information about the customers, which include the following 
attributes: customer id, first name, last name, email, phone_number, membership
(whether the customer has membership or not).
Table E2 contains information about the products in the store, namely product 
name, country of origin and price.
Table R contains information about the purchase history of each customer, it will 
have attributes of customer id, product name and purchased quantity.

PostgreSQL will be used.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS customer(
	customer_id VARCHAR(36) PRIMARY KEY,
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL,
	email VARCHAR(64) UNIQUE NOT NULL,
	phone_number VARCHAR(18) UNIQUE NOT NULL,
	is_member BOOLEAN NOT NULL);

CREATE TABLE IF NOT EXISTS product(
	product_name VARCHAR(36) PRIMARY KEY,
	country_of_origin VARCHAR(16) NOT NULL,
	price VARCHAR(12) NOT NULL);
	
CREATE TABLE purchase(
	customer_id VARCHAR(36) REFERENCES customer(customer_id)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED,
	product_name VARCHAR(36) REFERENCES product(product_name)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED,
	quantity INTEGER NOT NULL,
	PRIMARY KEY (customer_id, product_name));
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('5aacfca5-ed5f-45e4-b447-16358eea8414', 'Kalila', 'Crookes', 'kcrookes0@apple.com', '408-120-8501', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('f05563cc-732f-4673-9eb3-5d303406abfd', 'Jewel', 'Flaune', 'jflaune1@bbc.co.uk', '472-991-0840', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('c8dace7a-db79-4d4c-a3c3-454a4a2a1ca2', 'Mickie', 'Dunckley', 'mdunckley2@blinklist.com', '617-283-6606', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('7892f710-65f8-4af6-8202-6b4ce94ed910', 'Hilarius', 'Dimmock', 'hdimmock3@arstechnica.com', '869-636-9422', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('c184cf37-4f35-4ef6-9160-461e9783cf3c', 'Lon', 'Horsted', 'lhorsted4@sina.com.cn', '561-452-0727', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('37d70e4c-88e7-4d01-830c-b8c35d366ae5', 'Hannis', 'Colthard', 'hcolthard5@lycos.com', '949-120-1977', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('6d965685-c158-4646-ab47-4a3a75bf4706', 'Claudelle', 'Segges', 'csegges6@e-recht24.de', '293-683-9815', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('5d2d5364-1d57-4300-b952-a5316fe5d170', 'Vonny', 'Wackly', 'vwackly7@technorati.com', '585-107-2345', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('39ea3705-a100-4a9b-ba91-5f06bb26acaa', 'Marylou', 'Vyel', 'mvyel8@cocolog-nifty.com', '424-551-8902', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('b0841e04-3916-4c33-a19c-7de383b009d4', 'Conn', 'Gecke', 'cgecke9@bloglovin.com', '425-691-9120', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('6c957fb2-bcca-4aef-9522-294f5f50fd5d', 'Olive', 'Houliston', 'ohoulistona@un.org', '643-102-6447', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('d7ec2993-abde-487d-b64f-f6d9e0ebdc08', 'Chastity', 'Standring', 'cstandringb@live.com', '412-868-9399', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('84260d8f-a269-4514-ac0a-b549e9188822', 'Prissie', 'Lethabridge', 'plethabridgec@patch.com', '985-964-5068', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('0357a5e2-f41e-465a-87cf-b6f3f8583981', 'Rogers', 'Berntsson', 'rberntssond@indiegogo.com', '397-636-5164', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('fda415ab-cfb8-429b-9e15-13a68a967681', 'Car', 'Britner', 'cbritnere@youtube.com', '485-295-5628', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('3f366e16-297b-4bc4-9002-41e8510a0337', 'Jess', 'Dumbare', 'jdumbaref@un.org', '460-574-6936', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('2f6a8b61-1d1f-407c-83ab-79ca73bcc0a3', 'Dario', 'Antushev', 'dantushevg@gravatar.com', '508-811-5690', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('b5b02601-cca0-43b2-b148-822cd3011dc5', 'Gwyn', 'Denison', 'gdenisonh@upenn.edu', '624-854-2759', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('668caa6e-055f-41ab-b007-015fd3b2c89c', 'Myrtie', 'Jelkes', 'mjelkesi@cam.ac.uk', '818-587-5281', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('c911e9dc-30ef-4ac9-8ab8-bfcdc9e7bc65', 'Jess', 'Folke', 'jfolkej@microsoft.com', '333-702-6253', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('02684407-7a34-4cdc-8492-2171cb0af0b4', 'Bowie', 'Baptiste', 'bbaptistek@odnoklassniki.ru', '226-838-3312', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('37a6370f-316c-46ae-87a0-46202c0bf56e', 'Rikki', 'Foulser', 'rfoulserl@apache.org', '942-971-6827', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('d265382c-5e18-44c7-b7e4-a2aed17527c5', 'Garvey', 'Aldwinckle', 'galdwincklem@sohu.com', '719-244-2047', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('4a173dbe-3ef3-437f-8961-47f0136314dd', 'Roxi', 'MacAughtrie', 'rmacaughtrien@ibm.com', '806-274-8439', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('ddd1d707-4e89-46da-aff1-010a5d4fe97b', 'Tyrus', 'Ewin', 'tewino@mtv.com', '699-305-9064', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('5e1bc78d-aa60-40bf-90e1-24faeabb0c8a', 'Lindsay', 'Figures', 'lfiguresp@icio.us', '542-868-0850', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('6e9e2654-fa45-4111-a599-38b1393ee94a', 'Maryrose', 'Bedow', 'mbedowq@meetup.com', '458-901-1759', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('7caea702-ab4b-48d5-b388-ddee6c3e9280', 'Findlay', 'Stainland', 'fstainlandr@elpais.com', '886-188-5602', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('da975d38-e045-485e-a18e-6e3780c374d2', 'Claybourne', 'Meadows', 'cmeadowss@zimbio.com', '654-800-2584', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('aa9278ad-92ae-4dda-829d-3137b948d860', 'Maiga', 'Staden', 'mstadent@mac.com', '752-711-1169', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('57e497f8-ca43-4559-a39b-f3e0116ab2f4', 'Tallie', 'Tiuit', 'ttiuitu@yellowbook.com', '859-691-5965', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('2fb9f7d9-5d58-44f5-b4f7-6d2d5041a981', 'Wallie', 'Lynett', 'wlynettv@about.com', '552-553-9258', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('fbe515a0-306f-40f1-9c7e-d144819542e4', 'Filippa', 'Rottgers', 'frottgersw@umn.edu', '384-578-0428', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('2be3fc91-377a-446e-b9ce-2880716af225', 'Florencia', 'Creenan', 'fcreenanx@bloglovin.com', '410-239-2667', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('04952a63-ea83-4cc4-a368-2e35f50fa97d', 'Karine', 'Allsopp', 'kallsoppy@tamu.edu', '237-197-8888', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('36377c90-a508-4958-b7ea-a31536b313ae', 'Jill', 'Lille', 'jlillez@cam.ac.uk', '697-477-4449', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('18fa5fd9-1c13-480b-aed6-16740d84357c', 'Ambrosius', 'Swatman', 'aswatman10@gnu.org', '523-753-2438', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('571d9701-0b1f-4959-b4e6-3614402262b4', 'April', 'Kirsopp', 'akirsopp11@360.cn', '309-531-7615', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('bd1a3861-0bc3-4395-b8ac-37a2a8f965ae', 'Kip', 'Purdie', 'kpurdie12@businesswire.com', '259-280-2647', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('54feab4e-ed8e-49fc-80e3-6a5f15150703', 'Gal', 'Brotheridge', 'gbrotheridge13@msu.edu', '383-807-7119', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('3baba25e-7aec-46ab-8854-7ac28f7c3d10', 'Anatola', 'Kike', 'akike14@cisco.com', '220-240-3033', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('bc37c419-3ff5-47d0-aefb-e9e9e45ebe9b', 'Dionisio', 'Capun', 'dcapun15@histats.com', '199-408-3983', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('2962df90-913f-4060-9192-a93fde4a1e96', 'Madeleine', 'Pullin', 'mpullin16@paypal.com', '287-715-4105', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('a6e772d9-6f26-4204-9049-7e15dc394bd2', 'Neysa', 'Limon', 'nlimon17@furl.net', '221-332-0080', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('1436e97b-1973-454e-ba0b-01201526aaa6', 'Gabe', 'Gerlts', 'ggerlts18@artisteer.com', '365-873-9506', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('5c6446d4-1d97-4ef3-b0ba-0914fc1d5faa', 'Angelle', 'Vasyaev', 'avasyaev19@alexa.com', '375-911-8421', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('06d0ae93-9f9e-4a78-91c4-07ccb29f02e0', 'Byrom', 'Markos', 'bmarkos1a@networksolutions.com', '997-789-8266', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('ad628de5-e41f-400b-9ff9-45d728883451', 'Wake', 'Tofanelli', 'wtofanelli1b@amazon.com', '621-103-3874', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('caf5cfa0-4977-4c89-a4c4-5e00c4a26f26', 'Pernell', 'Fahey', 'pfahey1c@gizmodo.com', '184-922-0880', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('8694a528-b577-4016-83fe-385a8f7f9c4d', 'Gustav', 'Redbourn', 'gredbourn1d@webmd.com', '735-108-1287', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('43f3b933-41df-4b0b-8e18-4ee0a4ed2871', 'Kristyn', 'Guerra', 'kguerra1e@hubpages.com', '882-928-3556', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('64758c0d-705b-42f7-a474-b5ae85fc5777', 'Petr', 'Runcieman', 'pruncieman1f@shinystat.com', '153-266-3873', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('e11e82a0-20c8-4d04-b1fe-d7e4751a45ab', 'Godfry', 'Guille', 'gguille1g@weather.com', '897-457-6939', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('c4dba71a-72f7-4797-84da-98750daddf91', 'Mitchael', 'Potte', 'mpotte1h@sun.com', '582-753-1974', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('eef259ee-2f0a-41b0-9e42-348415f17331', 'Mike', 'Tailby', 'mtailby1i@google.co.jp', '110-726-0206', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('3d0d03a0-7f14-4791-ab1d-197b38198f80', 'Fredericka', 'Stoddart', 'fstoddart1j@thetimes.co.uk', '799-780-6056', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('91cae872-1c08-46a0-bda6-9294fd06edb7', 'Kelsi', 'Lorain', 'klorain1k@google.ru', '732-371-7660', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('bf70a962-0b41-462f-876e-70ff3d83eb34', 'Dulcy', 'Sobtka', 'dsobtka1l@fc2.com', '126-966-2436', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('07455cc6-7c08-4f07-a0d2-c6808516f3f9', 'Dorian', 'Roche', 'droche1m@china.com.cn', '120-459-5105', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('85bf3d0a-2a23-4921-a910-38ae4ad1fc61', 'Allene', 'Dilland', 'adilland1n@reuters.com', '643-732-8932', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('ba9b6e87-f149-4d01-9210-9e2fee7fd99c', 'Ram', 'Stemson', 'rstemson1o@networkadvertising.org', '639-120-8609', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('59d46142-0498-41ce-9bf9-c5830239b593', 'Adan', 'Sebley', 'asebley1p@rambler.ru', '899-331-4950', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('ec6e12d7-72c5-4258-ad3d-c245d26f077b', 'Fremont', 'Threadgold', 'fthreadgold1q@google.co.uk', '688-141-4389', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('6ac44a95-227b-419a-a8e0-2807d20e903e', 'Ki', 'MacLaren', 'kmaclaren1r@tamu.edu', '723-527-6437', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('a30d82fd-5362-4ffe-b056-80da7ba0f3bd', 'Tony', 'Slocumb', 'tslocumb1s@thetimes.co.uk', '617-466-5157', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('b3686ae0-0d62-44b6-af57-496749b8762d', 'Brander', 'Surmeyer', 'bsurmeyer1t@columbia.edu', '553-758-9222', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('726b7109-0e4d-4d1f-a95f-d10eff21fbe5', 'Griz', 'Ollington', 'gollington1u@youtu.be', '576-451-0056', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('550b4ad7-7192-4b55-b5e3-31fd5033a8cb', 'Veriee', 'Splaven', 'vsplaven1v@squarespace.com', '300-744-6280', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('cb735284-26bc-4738-b73d-28fbe7821fe4', 'Putnem', 'Keneleyside', 'pkeneleyside1w@biblegateway.com', '229-421-2180', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('cad519b7-3c33-4f48-ba07-b916cf0287b2', 'Michaela', 'Larratt', 'mlarratt1x@tripadvisor.com', '227-913-2894', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('d11a02e7-121e-4e58-b162-8872e36c0e7f', 'Arliene', 'Lamblot', 'alamblot1y@economist.com', '607-411-8736', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('e19448bb-5515-4d5c-a871-d08dc3f03f95', 'Kalie', 'Hawking', 'khawking1z@w3.org', '953-419-9563', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('8859f912-807a-4dff-8c85-f3a983d61cea', 'Theresa', 'Dearing', 'tdearing20@tmall.com', '862-842-3216', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('4ff0ebed-ba86-4e75-a8b9-fac2fd9aabc6', 'Dyanne', 'Benz', 'dbenz21@sfgate.com', '362-554-3719', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('643b33db-3766-4baf-8cdb-143f55370274', 'Neda', 'Davidou', 'ndavidou22@soundcloud.com', '808-831-8764', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('2c35dbdc-855e-407e-b22c-66a5509764ca', 'Vinny', 'Mesias', 'vmesias23@latimes.com', '253-163-1695', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('d78851c9-8ee6-45c4-8a39-1ecf4f56ab2c', 'Timoteo', 'Houchin', 'thouchin24@sohu.com', '125-820-5561', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('ecbec0d9-543c-4bc4-92c1-c411a1c784d9', 'Clyve', 'Harwin', 'charwin25@etsy.com', '782-636-1239', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('db65612a-8b52-4171-8e73-02ee6dc24335', 'Tripp', 'Torbard', 'ttorbard26@utexas.edu', '930-130-8844', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('7cb7777c-dc28-45b0-8b71-55ca822d583c', 'Lee', 'Binion', 'lbinion27@oaic.gov.au', '663-630-0331', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('7e7026f9-baa7-4a59-b75f-cea3f649242c', 'Cordie', 'Kembry', 'ckembry28@ft.com', '759-726-5624', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('643c3201-7dea-4a6d-b045-a2d85a08d0b0', 'Bart', 'Crampsey', 'bcrampsey29@exblog.jp', '704-304-3667', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('cbce0f5b-bc37-4cbf-89f9-5ce28029c18d', 'Jerrine', 'Deftie', 'jdeftie2a@simplemachines.org', '866-862-8394', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('28dcaee0-0f41-406b-949b-5897a55959f2', 'Gilberto', 'Fogarty', 'gfogarty2b@thetimes.co.uk', '152-852-4998', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('d6bb8221-1fbe-40aa-8dbb-45a37525789d', 'Darelle', 'Elloy', 'delloy2c@icq.com', '890-662-9312', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('c9910f52-53dc-40d0-b39c-f64f6e5bea33', 'Kaiser', 'Rowan', 'krowan2d@bigcartel.com', '489-459-3788', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('33c95d3e-f0f8-433e-8060-b57791aef66d', 'Shannon', 'Osipov', 'sosipov2e@flickr.com', '494-409-5752', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('5d110d6d-2478-480d-ab97-dd90a4c5de21', 'Helge', 'McCoid', 'hmccoid2f@infoseek.co.jp', '456-794-2242', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('0c94c6fa-9c22-41ba-9b54-4477acbb7577', 'Theodor', 'Shapiro', 'tshapiro2g@mozilla.org', '515-261-0846', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('6e3d6fbf-667a-4651-96a7-497baf37b300', 'Bren', 'Mussett', 'bmussett2h@arizona.edu', '820-461-8058', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('c1c9e713-4806-4df2-b9ab-e42d332d82a0', 'Montgomery', 'Antonutti', 'mantonutti2i@prweb.com', '544-707-4913', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('20467aba-8b55-46bf-9c3e-6e5b363d3cb8', 'Cristal', 'Klugel', 'cklugel2j@pinterest.com', '966-957-7688', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('1b1f71ac-b3c4-4698-8db0-96250049d3d9', 'Kassandra', 'Domoney', 'kdomoney2k@quantcast.com', '889-914-0718', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('c7614c92-d014-4e52-a479-e00edea914ae', 'Edita', 'Burren', 'eburren2l@walmart.com', '359-306-6113', false);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('b8eb9106-a49b-42e1-adab-6e78659fc2ee', 'Latrena', 'Sobey', 'lsobey2m@godaddy.com', '239-233-8160', true);
insert into customer (customer_id, first_name, last_name, email, phone_number, is_member) values ('0d47b922-9aeb-4b15-9f38-7d02818c5032', 'Mirilla', 'Chatell', 'mchatell2n@google.co.jp', '658-568-3435', true);

insert into product (product_name, country_of_origin, price) values ('Parsley Italian - Fresh', 'China', '$36.01');
insert into product (product_name, country_of_origin, price) values ('Lobak', 'Vietnam', '$28.78');
insert into product (product_name, country_of_origin, price) values ('Juice - Pineapple, 48 Oz', 'China', '$9.85');
insert into product (product_name, country_of_origin, price) values ('Cookie - Dough Variety', 'France', '$41.58');
insert into product (product_name, country_of_origin, price) values ('Remy Red', 'China', '$19.34');
insert into product (product_name, country_of_origin, price) values ('Squash - Guords', 'Indonesia', '$40.05');
insert into product (product_name, country_of_origin, price) values ('Carbonated Water - Blackberry', 'China', '$5.11');
insert into product (product_name, country_of_origin, price) values ('Squid Ink', 'Indonesia', '$36.25');
insert into product (product_name, country_of_origin, price) values ('Cookies - Oreo, 4 Pack', 'China', '$33.71');
insert into product (product_name, country_of_origin, price) values ('Wine - Trimbach Pinot Blanc', 'Indonesia', '$36.46');
insert into product (product_name, country_of_origin, price) values ('Chicken - Ground', 'China', '$24.33');
insert into product (product_name, country_of_origin, price) values ('Turkey - Breast, Bone - In', 'China', '$7.61');
insert into product (product_name, country_of_origin, price) values ('Soup - Knorr, Ministrone', 'Indonesia', '$41.94');
insert into product (product_name, country_of_origin, price) values ('Cheese - Brie,danish', 'China', '$7.42');
insert into product (product_name, country_of_origin, price) values ('Pizza Pizza Dough', 'Indonesia', '$27.61');
insert into product (product_name, country_of_origin, price) values ('Bagel - 12 Grain Preslice', 'China', '$18.30');
insert into product (product_name, country_of_origin, price) values ('Tamarind Paste', 'Indonesia', '$42.85');
insert into product (product_name, country_of_origin, price) values ('Nut - Peanut, Roasted', 'France', '$11.88');
insert into product (product_name, country_of_origin, price) values ('Shrimp - Baby, Warm Water', 'Indonesia', '$15.16');
insert into product (product_name, country_of_origin, price) values ('Truffle Cups Green', 'China', '$9.76');
insert into product (product_name, country_of_origin, price) values ('Flour - Pastry', 'Indonesia', '$5.72');
insert into product (product_name, country_of_origin, price) values ('Pumpkin - Seed', 'Canada', '$8.47');
insert into product (product_name, country_of_origin, price) values ('Beans - Yellow', 'Indonesia', '$38.69');
insert into product (product_name, country_of_origin, price) values ('Buffalo - Striploin', 'Indonesia', '$45.09');
insert into product (product_name, country_of_origin, price) values ('Cookies - Englishbay Chochip', 'Brazil', '$10.21');
insert into product (product_name, country_of_origin, price) values ('Pork - Ham, Virginia', 'United States', '$39.64');
insert into product (product_name, country_of_origin, price) values ('Wine - White Cab Sauv.on', 'Brazil', '$48.33');
insert into product (product_name, country_of_origin, price) values ('Soup - Knorr, Classic Can. Chili', 'Canada', '$38.15');
insert into product (product_name, country_of_origin, price) values ('Pasta - Lasagna Noodle, Frozen', 'Japan', '$7.51');
insert into product (product_name, country_of_origin, price) values ('Cheese - Valancey', 'Brazil', '$21.68');
insert into product (product_name, country_of_origin, price) values ('Beef - Top Sirloin - Aaa', 'Indonesia', '$13.74');
insert into product (product_name, country_of_origin, price) values ('Cookie Dough - Oatmeal Rasin', 'Indonesia', '$26.37');
insert into product (product_name, country_of_origin, price) values ('Wine - Sauvignon Blanc Oyster', 'Vietnam', '$30.15');
insert into product (product_name, country_of_origin, price) values ('Doilies - 5, Paper', 'China', '$19.04');
insert into product (product_name, country_of_origin, price) values ('Cod - Salted, Boneless', 'China', '$11.10');
insert into product (product_name, country_of_origin, price) values ('Foam Dinner Plate', 'Japan', '$42.88');
insert into product (product_name, country_of_origin, price) values ('Cheese Cloth', 'China', '$35.91');
insert into product (product_name, country_of_origin, price) values ('Ice Cream - Vanilla', 'Japan', '$14.21');
insert into product (product_name, country_of_origin, price) values ('Honey - Liquid', 'United States', '$47.95');
insert into product (product_name, country_of_origin, price) values ('Ecolab Digiclean Mild Fm', 'China', '$41.16');
insert into product (product_name, country_of_origin, price) values ('Ostrich - Prime Cut', 'United States', '$15.26');
insert into product (product_name, country_of_origin, price) values ('Wine - Acient Coast Caberne', 'China', '$42.09');
insert into product (product_name, country_of_origin, price) values ('Parsley - Dried', 'Germany', '$3.32');
insert into product (product_name, country_of_origin, price) values ('Wine - Domaine Boyar Royal', 'Indonesia', '$42.09');
insert into product (product_name, country_of_origin, price) values ('Turkey - Oven Roast Breast', 'Brazil', '$48.56');
insert into product (product_name, country_of_origin, price) values ('Mace Ground', 'Japan', '$17.66');
insert into product (product_name, country_of_origin, price) values ('Pears - Anjou', 'Brazil', '$21.17');
insert into product (product_name, country_of_origin, price) values ('Eggplant Italian', 'United States', '$28.09');
insert into product (product_name, country_of_origin, price) values ('Macaroons - Two Bite Choc', 'Indonesia', '$2.60');
insert into product (product_name, country_of_origin, price) values ('Flour - Cake', 'China', '$45.10');
insert into product (product_name, country_of_origin, price) values ('Soup Campbells Beef With Veg', 'Canada', '$32.10');
insert into product (product_name, country_of_origin, price) values ('Bacon Strip Precooked', 'United States', '$37.42');
insert into product (product_name, country_of_origin, price) values ('Cheese - Brick With Pepper', 'Indonesia', '$49.34');
insert into product (product_name, country_of_origin, price) values ('Pork - European Side Bacon', 'China', '$20.63');
insert into product (product_name, country_of_origin, price) values ('Bread - Raisin', 'Brazil', '$39.50');
insert into product (product_name, country_of_origin, price) values ('Turnip - Wax', 'Indonesia', '$18.46');
insert into product (product_name, country_of_origin, price) values ('Soup Campbells', 'China', '$17.88');
insert into product (product_name, country_of_origin, price) values ('Tomatoes - Cherry', 'South Africa', '$42.04');
insert into product (product_name, country_of_origin, price) values ('V8 - Berry Blend', 'Indonesia', '$4.52');
insert into product (product_name, country_of_origin, price) values ('Sausage - Andouille', 'China', '$8.46');
insert into product (product_name, country_of_origin, price) values ('Shrimp - 16 - 20 Cooked, Peeled', 'China', '$44.47');
insert into product (product_name, country_of_origin, price) values ('Juice - Propel Sport', 'China', '$8.02');
insert into product (product_name, country_of_origin, price) values ('Beer - True North Strong Ale', 'China', '$3.35');
insert into product (product_name, country_of_origin, price) values ('Olive - Spread Tapenade', 'France', '$11.67');
insert into product (product_name, country_of_origin, price) values ('Poppy Seed', 'China', '$26.62');
insert into product (product_name, country_of_origin, price) values ('Chutney Sauce', 'United States', '$31.96');
insert into product (product_name, country_of_origin, price) values ('Pasta - Detalini, White, Fresh', 'Indonesia', '$16.38');
insert into product (product_name, country_of_origin, price) values ('Mushroom - Trumpet, Dry', 'China', '$28.02');
insert into product (product_name, country_of_origin, price) values ('Cake - Mini Potato Pancake', 'China', '$16.65');
insert into product (product_name, country_of_origin, price) values ('Appetizer - Veg Assortment', 'Indonesia', '$19.98');
insert into product (product_name, country_of_origin, price) values ('Muffin Mix - Corn Harvest', 'China', '$8.32');
insert into product (product_name, country_of_origin, price) values ('Cotton Wet Mop 16 Oz', 'Brazil', '$14.89');
insert into product (product_name, country_of_origin, price) values ('Ice Cream - Strawberry', 'Indonesia', '$21.98');
insert into product (product_name, country_of_origin, price) values ('Salmon Steak - Cohoe 8 Oz', 'China', '$29.76');
insert into product (product_name, country_of_origin, price) values ('Pasta - Shells, Medium, Dry', 'Spain', '$8.94');
insert into product (product_name, country_of_origin, price) values ('Olives - Nicoise', 'Indonesia', '$13.71');
insert into product (product_name, country_of_origin, price) values ('Pomegranates', 'Indonesia', '$30.41');
insert into product (product_name, country_of_origin, price) values ('Butter - Pod', 'China', '$8.33');
insert into product (product_name, country_of_origin, price) values ('Tendrils - Baby Pea, Organic', 'Spain', '$12.51');
insert into product (product_name, country_of_origin, price) values ('Boogies', 'China', '$27.93');
insert into product (product_name, country_of_origin, price) values ('Kiwi', 'China', '$36.42');
insert into product (product_name, country_of_origin, price) values ('Dried Figs', 'Indonesia', '$31.97');
insert into product (product_name, country_of_origin, price) values ('Bread - Mini Hamburger Bun', 'Indonesia', '$23.34');
insert into product (product_name, country_of_origin, price) values ('Wine - Red, Colio Cabernet', 'France', '$12.98');
insert into product (product_name, country_of_origin, price) values ('Sobe - Green Tea', 'Brazil', '$26.14');
insert into product (product_name, country_of_origin, price) values ('Table Cloth 54x72 White', 'China', '$8.78');
insert into product (product_name, country_of_origin, price) values ('Chip - Potato Dill Pickle', 'Indonesia', '$21.95');
insert into product (product_name, country_of_origin, price) values ('Oil - Olive Bertolli', 'China', '$28.80');
insert into product (product_name, country_of_origin, price) values ('Lamb - Whole Head Off', 'Japan', '$13.51');
insert into product (product_name, country_of_origin, price) values ('Sugar - Sweet N Low, Individual', 'Indonesia', '$19.38');
insert into product (product_name, country_of_origin, price) values ('Tobasco Sauce', 'China', '$27.95');
insert into product (product_name, country_of_origin, price) values ('Scallops - U - 10', 'China', '$34.28');
insert into product (product_name, country_of_origin, price) values ('Beef - Texas Style Burger', 'China', '$9.23');
insert into product (product_name, country_of_origin, price) values ('Beef - Striploin', 'South Africa', '$5.68');
insert into product (product_name, country_of_origin, price) values ('Daves Island Stinger', 'Indonesia', '$11.63');
insert into product (product_name, country_of_origin, price) values ('Lidsoupcont Rp12dn', 'Vietnam', '$22.31');
insert into product (product_name, country_of_origin, price) values ('Apple - Royal Gala', 'China', '$49.39');
insert into product (product_name, country_of_origin, price) values ('Cornflakes', 'China', '$20.40');
insert into product (product_name, country_of_origin, price) values ('Wine - Riesling Alsace Ac 2001', 'South Korea', '$27.84');
insert into product (product_name, country_of_origin, price) values ('Basil - Thai', 'China', '$33.79');
insert into product (product_name, country_of_origin, price) values ('Bread Cranberry Foccacia', 'China', '$32.15');
insert into product (product_name, country_of_origin, price) values ('Pastrami', 'France', '$3.01');
insert into product (product_name, country_of_origin, price) values ('Garam Marsala', 'France', '$22.87');
insert into product (product_name, country_of_origin, price) values ('Garbage Bags - Black', 'Mexico', '$6.63');
insert into product (product_name, country_of_origin, price) values ('Bread - Multigrain, Loaf', 'China', '$48.99');
insert into product (product_name, country_of_origin, price) values ('Hagen Daza - Dk Choocolate', 'France', '$46.74');
insert into product (product_name, country_of_origin, price) values ('Rappini - Andy Boy', 'Brazil', '$27.96');
insert into product (product_name, country_of_origin, price) values ('Mushroom - Crimini', 'China', '$11.62');
insert into product (product_name, country_of_origin, price) values ('Rice Wine - Aji Mirin', 'Indonesia', '$39.36');
insert into product (product_name, country_of_origin, price) values ('Pineapple - Regular', 'China', '$45.64');
insert into product (product_name, country_of_origin, price) values ('Wine - Gewurztraminer Pierre', 'Japan', '$5.54');
insert into product (product_name, country_of_origin, price) values ('Soup - Campbells Chicken', 'China', '$48.67');
insert into product (product_name, country_of_origin, price) values ('Amaretto', 'Canada', '$7.80');
insert into product (product_name, country_of_origin, price) values ('Jam - Blackberry, 20 Ml Jar', 'China', '$48.28');
insert into product (product_name, country_of_origin, price) values ('Container Clear 8 Oz', 'China', '$15.53');
insert into product (product_name, country_of_origin, price) values ('Shrimp - Black Tiger 6 - 8', 'China', '$45.70');
insert into product (product_name, country_of_origin, price) values ('Madeira', 'China', '$23.14');
insert into product (product_name, country_of_origin, price) values ('Kolrabi', 'China', '$35.96');
insert into product (product_name, country_of_origin, price) values ('Tart Shells - Sweet, 2', 'France', '$4.32');
insert into product (product_name, country_of_origin, price) values ('Beer - Pilsner Urquell', 'Brazil', '$47.55');
insert into product (product_name, country_of_origin, price) values ('Lamb - Leg, Diced', 'China', '$25.74');
insert into product (product_name, country_of_origin, price) values ('Pear - Halves', 'Brazil', '$8.27');
insert into product (product_name, country_of_origin, price) values ('Cheese Cloth No 100', 'China', '$42.03');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO purchase(
  customer_id, product_name, quantity
) 
SELECT 
  customer_id, 
  product_name, 
  0 
FROM 
  (
    SELECT 
      DISTINCT c.customer_id, 
      p.product_name 
    FROM 
      customer c, 
      product p
  ) combined 
ORDER BY 
  random() 
LIMIT 
  1000;
UPDATE 
  purchase 
SET 
  quantity = floor(
    random() * 50 + 1
  )