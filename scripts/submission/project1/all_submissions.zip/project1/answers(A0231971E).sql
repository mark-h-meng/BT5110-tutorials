/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/* student number: A0231971E                                            */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */

/* The code is written for SQLite */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
This example is to develop an application for managing the prescription data 
of an elite private clinic offering premium medical services for high-end clients
from all over the world. 
I have chosen the entity set E1 to be clients, the entity set E2 to be drugs, and 
the relationship set R to be prescriptions. The table clients is created for clients 
with their first names, last names, date of birth, visiting date, country, passport 
number and client ID. The table drugs is created for drugs prescribed for clients, 
with drug names, drug companies and price. The table prescriptions associates the client
ID of the clients with the names and companies of the drugs specifically prescribed 
for clients.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
CREATE TABLE IF NOT EXISTS clients (
 first_name VARCHAR(64) NOT NULL,
 last_name VARCHAR(64) NOT NULL,
 dob DATE NOT NULL,
 visit_d DATE NOT NULL,
 country VARCHAR(16) NOT NULL,
 passportno VARCHAR(9) UNIQUE NOT NULL,
 clientid VARCHAR(8) PRIMARY KEY);
	
CREATE TABLE IF NOT EXISTS drugs(
 name VARCHAR(32),
 company CHAR(32),
 price NUMERIC NOT NULL,
 PRIMARY KEY (name, company));
  
 CREATE TABLE prescriptions(
 clientid VARCHAR(16) REFERENCES clients(clientid) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED,
 name VARCHAR(32),
 company CHAR(32),
 PRIMARY KEY (clientid, name, company),
 FOREIGN KEY (name, company) REFERENCES drugs(name, company) ON UPDATE CASCADE ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Brigitte', 'Holliar', '2/2/1980', '11/16/2020', 'Vietnam', 'Y35087444', '14926953');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Rosie', 'Caslake', '3/31/1961', '11/5/2020', 'China', 'F24013214', '88472451');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Sergent', 'Bebis', '10/17/1969', '5/4/2021', 'Poland', 'B19855683', '38080369');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Tamra', 'Aery', '10/1/1985', '7/28/2021', 'China', 'A79197237', '45989549');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Scot', 'Trace', '11/29/1992', '3/27/2021', 'Ireland', 'M71182254', '71486433');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Tabor', 'Warsop', '7/31/1957', '2/28/2021', 'Portugal', 'J93371395', '19452688');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Catriona', 'Jefferson', '10/7/1977', '10/23/2020', 'United Kingdom', 'P36614698', '94384397');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Frans', 'Gaze', '8/28/1980', '4/27/2021', 'China', 'X30700837', '00153963');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Jeana', 'Edmunds', '7/23/1969', '10/9/2020', 'China', 'R18557366', '47302184');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Claudianus', 'Attac', '11/9/1967', '12/4/2020', 'Philippines', 'V13332591', '63099265');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Keir', 'Beuscher', '5/14/1960', '5/21/2021', 'Peru', 'E67102431', '56774252');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Farley', 'Goggey', '12/9/1993', '6/5/2021', 'Costa Rica', 'X77504068', '91423973');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Miguel', 'Hollibone', '10/12/1998', '12/12/2020', 'Philippines', 'V04843537', '70101672');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Duane', 'Hollyard', '8/29/2000', '8/20/2020', 'Ivory Coast', 'I77113222', '07814652');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Rinaldo', 'Poluzzi', '12/22/2014', '5/26/2021', 'El Salvador', 'P11226665', '86225957');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Vite', 'Habbes', '8/10/2016', '8/28/2020', 'Philippines', 'G27153496', '21705868');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Darren', 'Killcross', '8/4/2010', '1/21/2021', 'Brazil', 'G30946788', '75065537');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Rosina', 'Evequot', '1/13/2018', '9/10/2020', 'Serbia', 'Y36843915', '98179256');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Hyacinthie', 'Yurukhin', '11/27/1965', '5/23/2021', 'Brazil', 'C25768067', '94053220');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Dolly', 'Gozzett', '11/2/1975', '12/15/2020', 'China', 'W66735970', '00295972');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Seumas', 'McCreery', '1/19/1963', '12/2/2020', 'Nepal', 'A19352169', '33916741');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Marlo', 'Blogg', '11/30/1992', '12/20/2020', 'Indonesia', 'I85561224', '76871441');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Flem', 'Baudinelli', '5/18/1980', '4/28/2021', 'United States', 'A98193380', '20250026');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Kelwin', 'Twomey', '6/14/1970', '11/10/2020', 'Canada', 'Z13350260', '77611221');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Englebert', 'Ruffler', '3/23/1976', '3/27/2021', 'United States', 'M70160517', '96058582');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('August', 'Crevagh', '6/5/1964', '10/5/2020', 'Brazil', 'R88099735', '75578188');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Cristina', 'Roddam', '1/23/1993', '8/12/2020', 'Cameroon', 'W23743761', '94352233');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Kit', 'Boxhall', '1/16/2010', '5/28/2021', 'Ukraine', 'J30038111', '78952396');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Arda', 'Readie', '9/28/1989', '11/28/2020', 'Belize', 'J12996773', '72440066');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Royce', 'McIlwrath', '4/23/1995', '1/13/2021', 'France', 'Z13269496', '32457235');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Osgood', 'Nazareth', '9/12/2000', '12/28/2020', 'Indonesia', 'Y37066182', '94787589');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Clayborne', 'Sawden', '3/13/1997', '12/22/2020', 'Yemen', 'B24572647', '18374816');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Wes', 'de Chastelain', '5/6/1958', '12/22/2020', 'Aruba', 'T79645379', '11271320');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Leesa', 'Bernardot', '10/3/2005', '1/23/2021', 'China', 'G63070900', '37064880');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Orland', 'Rosenbarg', '9/12/2008', '9/18/2020', 'Indonesia', 'H67216052', '65825299');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Gerik', 'Slaight', '2/18/1979', '7/20/2021', 'China', 'V79358692', '98539504');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Antoni', 'Fieldhouse', '2/27/1992', '6/23/2021', 'Peru', 'J13982442', '00722556');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Eartha', 'Warlawe', '6/1/2017', '7/22/2021', 'North Korea', 'S78298425', '68766708');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Jilleen', 'Hawkslee', '5/26/2002', '11/9/2020', 'Portugal', 'G03185158', '35215345');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Isidora', 'Mattiassi', '12/24/1998', '6/22/2021', 'Germany', 'R80967926', '78830865');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Dorthea', 'Sego', '12/18/2018', '8/4/2020', 'Yemen', 'F08043216', '43442248');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Grazia', 'Dongles', '6/3/2011', '6/17/2021', 'Czech Republic', 'S24293908', '36671581');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Gustave', 'Jameson', '10/27/2001', '5/23/2021', 'China', 'Y24432420', '35928658');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Ami', 'Chritchley', '3/8/1950', '4/5/2021', 'Pakistan', 'I17759093', '47344484');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Antoni', 'Tinsley', '8/6/1973', '4/15/2021', 'Ukraine', 'N75536036', '20517920');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Rivalee', 'Grix', '8/3/1991', '10/17/2020', 'Canada', 'G66708349', '60377740');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Lita', 'Cristofvao', '3/5/2010', '5/25/2021', 'Guinea', 'G17008777', '59598596');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Nadeen', 'Shildrake', '2/9/2009', '5/31/2021', 'Ireland', 'Q29892339', '49033714');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Emmerich', 'Meany', '10/26/2006', '7/6/2021', 'Japan', 'X31386072', '29041500');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Jillene', 'McKinlay', '6/3/1977', '8/10/2020', 'Philippines', 'R91804208', '59982455');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Corey', 'McQuade', '8/28/2013', '12/10/2020', 'Russia', 'X19419058', '90470904');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Shepherd', 'Choppin', '12/17/1973', '6/9/2021', 'Russia', 'F03525292', '86519002');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Chick', 'Warlow', '8/17/1967', '10/4/2020', 'China', 'M62646913', '13255302');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Filippa', 'Stormont', '1/21/1957', '5/22/2021', 'Azerbaijan', 'F77889233', '79493396');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Bay', 'Banes', '7/11/1958', '4/28/2021', 'Argentina', 'T18237667', '42088926');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Sumner', 'Stedman', '10/11/1964', '7/19/2021', 'South Africa', 'O36430601', '60430434');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Kelsi', 'Mauchlen', '3/29/2014', '11/18/2020', 'Gabon', 'M58297421', '02377342');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Richard', 'Double', '11/22/2001', '6/7/2021', 'Uruguay', 'B93544951', '90723305');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Yoko', 'Kolakowski', '9/26/1967', '11/30/2020', 'Indonesia', 'S34634124', '15203175');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Haleigh', 'Seak', '3/9/1982', '8/15/2020', 'Finland', 'X50646405', '19267226');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Bernice', 'Wilflinger', '12/18/1996', '3/1/2021', 'Nepal', 'B61006113', '32889816');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Jorey', 'Utton', '8/11/2017', '12/5/2020', 'Honduras', 'K40443150', '28658744');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Sherman', 'Petry', '11/5/1978', '5/18/2021', 'Tunisia', 'H97235187', '60171302');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Nadean', 'Edsall', '5/6/1967', '5/16/2021', 'Russia', 'S18591821', '87090538');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Woody', 'Dodshon', '1/16/2008', '11/22/2020', 'Indonesia', 'J66498687', '72246239');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Aretha', 'Inchcomb', '12/29/1990', '7/15/2021', 'Tanzania', 'I08806033', '84686748');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Harlen', 'Reubel', '9/1/2008', '9/2/2020', 'Russia', 'S70713983', '94463417');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Arri', 'Gierke', '3/1/1955', '9/11/2020', 'Sweden', 'O58052877', '54741343');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Elihu', 'Fladgate', '6/29/1990', '1/9/2021', 'Russia', 'K97651383', '09490270');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Palmer', 'Adamowicz', '9/9/1987', '12/16/2020', 'France', 'F78636218', '62547930');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Adelbert', 'Gantlett', '8/24/2004', '9/28/2020', 'Colombia', 'B52148291', '99904419');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Sofia', 'Hedingham', '10/18/1968', '8/30/2020', 'Pakistan', 'P44447326', '63128421');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Felicle', 'Everly', '8/12/1968', '10/21/2020', 'Bulgaria', 'X01840542', '09589550');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Natka', 'Andrichuk', '3/1/1978', '1/26/2021', 'Saint Vincent and the Grenadines', 'F68417502', '94980603');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Obie', 'Millbank', '12/16/1984', '2/17/2021', 'China', 'T53369680', '67208532');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Ly', 'Sima', '10/5/1968', '4/23/2021', 'Peru', 'Z40451019', '05640086');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Zaneta', 'Blanche', '3/15/1981', '6/24/2021', 'Philippines', 'F36558571', '28222996');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Francoise', 'Cuttles', '10/14/1977', '5/26/2021', 'Philippines', 'Z36985723', '20077882');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Adelaida', 'Cockerham', '11/19/1992', '1/28/2021', 'China', 'A94658822', '12542694');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Gunner', 'Balhatchet', '1/23/1950', '7/26/2021', 'Indonesia', 'M68937126', '87419535');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Galven', 'Duffit', '1/7/2015', '1/18/2021', 'Sweden', 'Z78828949', '39668845');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Nev', 'Sinderland', '9/21/1985', '12/5/2020', 'Indonesia', 'N12047411', '10522503');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Reece', 'Silly', '8/25/2017', '2/3/2021', 'Indonesia', 'W15639099', '02293874');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Gar', 'McConnel', '4/5/1954', '9/20/2020', 'Russia', 'M86220705', '68719635');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Ogdon', 'Featherstonhalgh', '9/14/2015', '11/19/2020', 'China', 'A28558272', '90282661');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Hamish', 'Elwill', '12/19/1990', '7/13/2021', 'France', 'F94731937', '75040685');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Devinne', 'Tremoulet', '12/19/2014', '1/19/2021', 'China', 'E28219828', '32621797');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Fields', 'Blakemore', '3/12/1987', '4/8/2021', 'China', 'U20227199', '87356525');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Karel', 'Gravie', '6/26/1998', '6/24/2021', 'France', 'O21377983', '51910809');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Marty', 'Mitchley', '4/4/1996', '8/7/2020', 'Sweden', 'D50672490', '88839654');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Emmy', 'Stroband', '8/1/2006', '11/11/2020', 'Russia', 'O09674384', '34551436');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Carling', 'Weymouth', '12/20/1980', '1/4/2021', 'China', 'W40597413', '17322974');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Olav', 'Craisford', '6/7/1951', '11/8/2020', 'Philippines', 'E31376507', '17531320');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Mabelle', 'Avory', '5/25/1972', '3/2/2021', 'Russia', 'O59416515', '77084619');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Madonna', 'Tyrone', '6/20/1974', '6/19/2021', 'Denmark', 'N78686865', '84328394');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Reginald', 'Pennuzzi', '2/3/2008', '12/10/2020', 'Russia', 'A96386223', '41657025');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Aeriel', 'Goldis', '9/7/1990', '11/5/2020', 'Argentina', 'Y41394849', '78376783');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Bevon', 'Ludmann', '7/11/2016', '9/25/2020', 'Nepal', 'T15657631', '81755238');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Cindee', 'Loades', '6/21/1979', '10/20/2020', 'China', 'G90656372', '53518514');
INSERT into clients (first_name, last_name, dob, visit_d, country, passportno, clientid) values ('Doralin', 'Slocomb', '2/19/1998', '4/20/2021', 'Russia', 'B59487234', '51430238');

/************************************************************************/

INSERT into drugs (name, company, price) values ('Doxazosin', 'Jakubowski LLC', 26308.47);
INSERT into drugs (name, company, price) values ('Titanium Dioxide and Zinc Oxide', 'Bernier-Conn', 2963.1);
INSERT into drugs (name, company, price) values ('Fluoxetine hydrochloride', 'Boyer, Collier and Dooley', 44412.31);
INSERT into drugs (name, company, price) values ('Clindamycin Hydrochloride', 'Dooley-Heathcote', 61927.83);
INSERT into drugs (name, company, price) values ('ANTIMONY TRISULFIDE - MAHONIA AQUIFOLIUM ROOT BARK - LYCOPODIUM CLAVATUM SPORE', 'Kuvalis, Schimmel and Cummings', 62468.03);
INSERT into drugs (name, company, price) values ('ALCOHOL', 'Runte-Schmeler', 94528.51);
INSERT into drugs (name, company, price) values ('Metformin Hydrochloride', 'Ratke-Bode', 73878.06);
INSERT into drugs (name, company, price) values ('Acetaminophen, Dextromethorphan HBr, Doxylamine succinate, Phenylephrine HCl', 'Kihn, Erdman and Bosco', 72407.39);
INSERT into drugs (name, company, price) values ('Eucalyptol, menthol, methyl salicylate, thymol', 'Marquardt-Runolfsson', 92990.39);
INSERT into drugs (name, company, price) values ('CARISOPRODOL', 'Medhurst Group', 62007.15);
INSERT into drugs (name, company, price) values ('Aluminum Chlorohydrate', 'Lubowitz and Sons', 31509.75);
INSERT into drugs (name, company, price) values ('CHLOROXYLENOL', 'Wiegand-Ferry', 47489.08);
INSERT into drugs (name, company, price) values ('Clopidogrel', 'Wuckert, King and Moore', 12881.72);
INSERT into drugs (name, company, price) values ('ALCOHOL', 'Cronin-Treutel', 71825.92);
INSERT into drugs (name, company, price) values ('Sennosides', 'Daugherty-Friesen', 95817.23);
INSERT into drugs (name, company, price) values ('CEFOTETAN and DEXTROSE', 'Feil Inc', 82496.54);
INSERT into drugs (name, company, price) values ('Octinoxate and Zinc Oxide', 'Green-Jones', 81546.72);
INSERT into drugs (name, company, price) values ('MORPHINE SULFATE', 'Swift Group', 35960.86);
INSERT into drugs (name, company, price) values ('Menthol', 'Trantow, Cummings and Collier', 90749.35);
INSERT into drugs (name, company, price) values ('fluocinolone acetonide', 'Keeling, Deckow and Price', 60360.8);
INSERT into drugs (name, company, price) values ('Zinc Oxide', 'Ratke, Nader and O''Kon', 99234.48);
INSERT into drugs (name, company, price) values ('Dexamethasone Sodium Phosphate', 'Schamberger, Schoen and Beier', 28633.62);
INSERT into drugs (name, company, price) values ('brompheniramine maleate, phenylephrine HCl', 'Miller Group', 20220.62);
INSERT into drugs (name, company, price) values ('Chloroxylenol', 'Pagac Group', 98498.55);
INSERT into drugs (name, company, price) values ('Rimantadine Hydrochloride', 'Stracke-Schiller', 1449.5);
INSERT into drugs (name, company, price) values ('spinosad', 'Mohr, Beer and Bechtelar', 63515.62);
INSERT into drugs (name, company, price) values ('OXYGEN', 'Wolff, Casper and Rogahn', 36514.29);
INSERT into drugs (name, company, price) values ('furosemide', 'Roberts-Gutmann', 48272.81);
INSERT into drugs (name, company, price) values ('albuterol sulfate', 'Gusikowski-Langosh', 18127.19);
INSERT into drugs (name, company, price) values ('pregabalin', 'West-Baumbach', 87092.56);
INSERT into drugs (name, company, price) values ('White Petrolatum', 'Rosenbaum and Sons', 82072.77);
INSERT into drugs (name, company, price) values ('POLYETHYLENE GLYCOL 3350', 'Littel, Haley and Schowalter', 55745.95);
INSERT into drugs (name, company, price) values ('antihemophilic factor (Recombinant, Plasma/Albumin-Free)', 'Kutch and Sons', 7783.15);
INSERT into drugs (name, company, price) values ('Doxycycline hyclate', 'Hartmann, Beatty and Feest', 90191.0);
INSERT into drugs (name, company, price) values ('California Black Walnut', 'Casper-Bayer', 33680.53);
INSERT into drugs (name, company, price) values ('Metoclopramide Hydrochloride', 'Nicolas Inc', 69798.26);
INSERT into drugs (name, company, price) values ('Aspirin, Caffeine, and Dihydrocodeine Bitartrate', 'Leannon-Gerlach', 66631.51);
INSERT into drugs (name, company, price) values ('estradiol', 'Feest LLC', 33910.08);
INSERT into drugs (name, company, price) values ('Probenecid and Colchicine', 'Hauck and Sons', 82535.28);
INSERT into drugs (name, company, price) values ('Duloxetine Hydrochloride', 'Conroy, Walsh and Rippin', 90809.27);
INSERT into drugs (name, company, price) values ('ALCOHOL', 'Brown, Hackett and Wyman', 96545.24);
INSERT into drugs (name, company, price) values ('tazobactam sodium and piperacillin sodium', 'Donnelly, Konopelski and Senger', 66764.58);
INSERT into drugs (name, company, price) values ('Octinoxate', 'Becker and Sons', 82955.51);
INSERT into drugs (name, company, price) values ('Vancomycin Hydrochloride', 'Kozey-Hane', 82956.31);
INSERT into drugs (name, company, price) values ('Benzalkonium Chloride', 'Roberts Inc', 28478.02);
INSERT into drugs (name, company, price) values ('DROSERA ROTUNDIFOLIA, DROSERA INTERMEDIA, DROSERA ANGLICA, ERIODICTYON CALIFORNICUM FLOWERING TOP, GRINDELIA HIRSUTULA FLOWERING TOP, POTASSIUM IODIDE, SPONGIA OFFICINALIS SKELETON, ROASTED, LOBARIA PULMONARIA, TEUCRIUM SCORODONIA FLOWERING TOP, and VERBASCUM DENSIFLORUM FLOWERING TOP', 'Windler, Beer and McLaughlin', 41447.48);
INSERT into drugs (name, company, price) values ('Bismuthum metallicum, Antimon.crud., Arg. nit., Arsenicum alb., Baptisia, Bryonia, Chamomilla, Cinchona, Iris versicolor, Kali bic., Lachesis, Lycopodium, Mag. carb., Nux vom., Phosphorus, Podoph. pelt., Pulsatilla, Raphanus, Rhus toxicodendron, Tabacum, Verbascum, Zingiber, Echinacea, Juglans regia', 'Feeney-Johnson', 48724.1);
INSERT into drugs (name, company, price) values ('CHOLECALCIFEROL, .ALPHA.-TOCOPHEROL SUCCINATE, D-, THIAMINE MONONITRATE, RIBOFLAVIN, NIACINAMIDE, PYRIDOXINE HYDROCHLORIDE, FOLIC ACID, CYANOCOBALAMIN, BIOTIN, CALCIUM PANTOTHENATE, IRON SUCROSE, HEME IRON POLYPEPTIDE, POTASSIUM IODIDE, ZINC OXIDE, SODIUM SELENATE, CUPRIC SULFATE, DOCONEXENT, LINOLENIC ACID, OSBOND ACID', 'Daniel LLC', 88560.56);
INSERT into drugs (name, company, price) values ('Diphenhydramine Hydrochloride, Zinc Acetate', 'Harber-Willms', 5497.78);
INSERT into drugs (name, company, price) values ('risperidone', 'Torp-Klein', 48392.75);
INSERT into drugs (name, company, price) values ('Methyl Salicylate Menthol Eucalyptus', 'Donnelly-Padberg', 18534.67);
INSERT into drugs (name, company, price) values ('Carbon Dioxide', 'Bayer-Murphy', 89879.88);
INSERT into drugs (name, company, price) values ('Dandelion', 'Gusikowski-Nader', 28820.7);
INSERT into drugs (name, company, price) values ('Fentanyl Citrate', 'Bruen, Upton and Turner', 32151.19);
INSERT into drugs (name, company, price) values ('antimonium tart 30c, arsenicum 30c, belladonna 30c, bacillinum 200c, calcarea carb 30c, cactus 30c, causticum 30c, cuprum met. 30c, dulcamara 30c, ipecac 30c, hepar sulph 30c, kali sulph 30c, lycopodium 30c, natrum carb 30c, nux vomica 30c, phosphorus 30c, pulsatilla 30c, sepia 30c, senega 30c,', 'Jast-Willms', 12461.48);
INSERT into drugs (name, company, price) values ('DIDANOSINE', 'Carroll-Greenholt', 17040.13);
INSERT into drugs (name, company, price) values ('propranolol hydrochloride', 'VonRueden-Pouros', 44126.64);
INSERT into drugs (name, company, price) values ('Sodium Fluoride', 'Zieme-Hermann', 15118.4);
INSERT into drugs (name, company, price) values ('Minocycline hydrochloride', 'Lakin-Lubowitz', 47118.22);
INSERT into drugs (name, company, price) values ('Octreotide Acetate', 'Fritsch and Sons', 43933.3);
INSERT into drugs (name, company, price) values ('enoxaparin sodium', 'Considine and Sons', 91723.6);
INSERT into drugs (name, company, price) values ('bupropion hydrochloride', 'Goldner-Kirlin', 4523.86);
INSERT into drugs (name, company, price) values ('OCTINOXATE, TITANIUM DIOXIDE', 'Haley, Kuhn and Block', 66122.11);
INSERT into drugs (name, company, price) values ('isotretinoin', 'Spencer and Sons', 15999.4);
INSERT into drugs (name, company, price) values ('Octinoxate and Titanium Dioxide', 'Howe-Johns', 9601.38);
INSERT into drugs (name, company, price) values ('Ropinirole Hydrochloride', 'Brakus, Marvin and Bartoletti', 61469.67);
INSERT into drugs (name, company, price) values ('metoprolol succinate', 'Kilback-Crona', 85847.84);
INSERT into drugs (name, company, price) values ('padimate O, petrolatum', 'Streich-Harber', 35784.84);
INSERT into drugs (name, company, price) values ('sitagliptin and simvastatin', 'Leffler, Jast and Casper', 20416.42);
INSERT into drugs (name, company, price) values ('TITANIUM DIOXIDE, ZINC OXIDE and OCTINOXATE', 'Wiegand, Bechtelar and Cole', 43521.54);
INSERT into drugs (name, company, price) values ('Pravastatin Sodium', 'Balistreri-Harris', 97892.63);
INSERT into drugs (name, company, price) values ('PHENOBARBITAL, HYOSCYAMINE SULFATE, ATROPINE SULFATE, SCOPOLAMINE HYDROBROMIDE', 'Littel, Toy and Yundt', 94444.0);
INSERT into drugs (name, company, price) values ('Naproxen Sodium', 'Marks-Rau', 34657.6);
INSERT into drugs (name, company, price) values ('Menthol', 'Gleason-Jones', 38830.99);
INSERT into drugs (name, company, price) values ('Eucalyptol, menthol, methyl salicylate, thymol', 'Zieme, Dach and Glover', 71968.37);
INSERT into drugs (name, company, price) values ('Titanium Dioxide', 'Jacobi-Mosciski', 8947.3);
INSERT into drugs (name, company, price) values ('methylprednisolone acetate', 'Hamill, Kunze and Keeling', 59720.1);
INSERT into drugs (name, company, price) values ('Eucalyptol , Menthol , Methyl Salicylate, Thymol', 'Nolan LLC', 102.02);
INSERT into drugs (name, company, price) values ('Homeopathic Liquid', 'Von-Conroy', 12731.6);
INSERT into drugs (name, company, price) values ('Acetaminophen, Caffeine, Aspirin, Salicylamide', 'Dickens-Cummerata', 73527.63);
INSERT into drugs (name, company, price) values ('Amoxicillin', 'Heller, Grady and Sawayn', 19083.77);
INSERT into drugs (name, company, price) values ('rosiglitazone maleate and metformin hydrochloride', 'Frami, Koelpin and Towne', 44580.32);
INSERT into drugs (name, company, price) values ('Bacitracin, Polymyxin B', 'Ryan, Lesch and Considine', 62220.4);
INSERT into drugs (name, company, price) values ('oxycodone hydrochloride', 'Lakin, Labadie and Schneider', 97992.3);
INSERT into drugs (name, company, price) values ('Candesartan cilexetil', 'Sauer-Walsh', 96733.83);
INSERT into drugs (name, company, price) values ('carmustine', 'Mills Inc', 56678.46);
INSERT into drugs (name, company, price) values ('Parachlorometaxylenol', 'Torphy, Ernser and Hahn', 59630.58);
INSERT into drugs (name, company, price) values ('Naproxen Sodium', 'Keebler Group', 12072.19);
INSERT into drugs (name, company, price) values ('Red Maple', 'Crooks-Jenkins', 25071.93);
INSERT into drugs (name, company, price) values ('Ethyl Alcohol', 'Raynor, Bradtke and Abshire', 26759.56);
INSERT into drugs (name, company, price) values ('Bismuth subsalicylate', 'Lang, McCullough and Runolfsson', 11410.74);
INSERT into drugs (name, company, price) values ('Oxymetazoline Hydrochloride', 'Bahringer, Tillman and Von', 76297.18);
INSERT into drugs (name, company, price) values ('HYDROQUINONE', 'Rolfson, Aufderhar and Wyman', 52684.42);
INSERT into drugs (name, company, price) values ('Furosemide', 'Marquardt-Littel', 28540.19);
INSERT into drugs (name, company, price) values ('levalbuterol inhalation 1.25mg/3mL', 'Greenholt Group', 50530.3);
INSERT into drugs (name, company, price) values ('TITANIUM DIOXIDE', 'Sauer, Bogan and Gleason', 7885.83);
INSERT into drugs (name, company, price) values ('DULOXETINE HYDROCHLORIDE', 'Nitzsche, Berge and Keeling', 76939.85);
INSERT into drugs (name, company, price) values ('Ethiodized Oil', 'Zieme, Effertz and Miller', 29050.2);
INSERT into drugs (name, company, price) values ('ZINC ACETATE and ZINC GLUCONATE', 'Jaskolski, Fay and Kunze', 87971.0);
INSERT into drugs (name, company, price) values ('oxycodone hydrochloride', 'Leuschke-Rice', 77404.63);


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO prescriptions (clientid, name, company)
SELECT clientid, name, company 
FROM clients, drugs
ORDER BY random()	
LIMIT 1000;



