/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* 
The code is written for PostgreSQL
This database stores check-in records of university personnel into location or an establishment in a university for contact tracing and compliance checking purposes.
The relationship is many-to-many relationship, i.e. one personnel can visit more than one location, and one location can be visited by more than one personnel.

personnel (entity) - A sample record of students and staff in the university
Columns include:
	-Email (primary key),
	-Personnel ID,
	-First name, 
	-Last name;
	-Gender, 
	-Faculty,
	-Student/staff
	
location (entity) - Buildings and establishments in the university with check-in capability
Columns include:
	-Location ID (primary key),
	-Location name,
	-Latitude, (latitude and logitude for contact tracing purpose)
	-Longitude,
	-Type of location,
	
visited (relationship) - Check-in records of the personnel who visited the location in the university between Jan 2021 to June 2021. 
Columns include:
	-Visitor's email,
	-Location ID,
	-Check-in time (between Jan 1 to June 31 2021)
	Primary key: Visitor's email + Location ID
	
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE IF NOT EXISTS personnel (
	personnel_id CHAR(8) NOT NULL UNIQUE,
	email VARCHAR(256) PRIMARY KEY,
	first_name VARCHAR(256) NOT NULL,
	last_name VARCHAR(256) NOT NULL,
	gender VARCHAR(6) NOT NULL CONSTRAINT gender CHECK(gender = 'Male' OR gender='Female'),
	faculty VARCHAR(62) NOT NULL,
	type VARCHAR(7) NOT NULL
);

CREATE TABLE IF NOT EXISTS location (
	location_id VARCHAR(5) PRIMARY KEY,
	name VARCHAR(256) NOT NULL,
	type VARCHAR(50) NOT NULL,
	lat VARCHAR(10) NOT NULL,
	long VARCHAR(10) NOT NULL
);

CREATE TABLE IF NOT EXISTS visited (
	visitor VARCHAR(256) REFERENCES personnel(email),
	location_id VARCHAR(5) REFERENCES location(location_id),
	check_in_time TIMESTAMP NOT NULL,
	PRIMARY KEY (visitor, location_id)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('r9199555', 'r9199555@mus.edu', 'Lucia', 'Gater', 'Male', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('n7585954', 'n7585954@mus.edu', 'Ediva', 'Waberer', 'Female', 'Faculty of Law', 'Staff');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('t2298166', 't2298166@mus.edu', 'Bryna', 'Abethell', 'Female', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('v8969877', 'v8969877@mus.edu', 'Heddie', 'Trowl', 'Male', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('a8583645', 'a8583645@mus.edu', 'Brew', 'Coleman', 'Female', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('g3992474', 'g3992474@mus.edu', 'Sig', 'McFie', 'Male', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('d6851072', 'd6851072@mus.edu', 'Wyndham', 'Churchin', 'Male', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('w2489711', 'w2489711@mus.edu', 'Karl', 'Skeldon', 'Male', 'School of Business', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('p4287284', 'p4287284@mus.edu', 'Romona', 'Weare', 'Female', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('i2438136', 'i2438136@mus.edu', 'Cammy', 'Meineck', 'Male', 'School of Business', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('y7624253', 'y7624253@mus.edu', 'Granger', 'Ortell', 'Male', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('z0014883', 'z0014883@mus.edu', 'Wood', 'Walczynski', 'Male', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('n9779305', 'n9779305@mus.edu', 'Kelly', 'Tyrwhitt', 'Male', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('i0364195', 'i0364195@mus.edu', 'Romain', 'Estcot', 'Female', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('s0954674', 's0954674@mus.edu', 'Trever', 'Vasentsov', 'Female', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('g7507936', 'g7507936@mus.edu', 'Moyna', 'Fraulo', 'Female', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('f2165767', 'f2165767@mus.edu', 'Eden', 'Purrier', 'Female', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('t4405286', 't4405286@mus.edu', 'Kelci', 'Tabart', 'Male', 'Faculty of Medicine', 'Staff');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('a1667917', 'a1667917@mus.edu', 'Maritsa', 'Broose', 'Female', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('l8157841', 'l8157841@mus.edu', 'Iris', 'Haffner', 'Female', 'School of Business', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('w3910272', 'w3910272@mus.edu', 'Carlyle', 'Tunstall', 'Female', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('e3620132', 'e3620132@mus.edu', 'Sharai', 'Stebbings', 'Male', 'School of Business', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('a1602714', 'a1602714@mus.edu', 'Jameson', 'Browne', 'Male', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('o4333053', 'o4333053@mus.edu', 'Carmon', 'Toyer', 'Male', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('w4981294', 'w4981294@mus.edu', 'Raquel', 'Itzcovichch', 'Male', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('n0258127', 'n0258127@mus.edu', 'Nat', 'Chander', 'Female', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('o9600239', 'o9600239@mus.edu', 'Malinda', 'Postins', 'Female', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('a9634284', 'a9634284@mus.edu', 'Auroora', 'McConigal', 'Female', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('i3455852', 'i3455852@mus.edu', 'Patrizius', 'Loftin', 'Female', 'School of Business', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('f7754853', 'f7754853@mus.edu', 'Paulita', 'Wybrow', 'Male', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('n7204843', 'n7204843@mus.edu', 'Roarke', 'Izachik', 'Male', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('h0826497', 'h0826497@mus.edu', 'Herminia', 'McIlreavy', 'Female', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('b6728806', 'b6728806@mus.edu', 'Garnet', 'Banaszczyk', 'Female', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('q5240187', 'q5240187@mus.edu', 'Irma', 'Sorton', 'Male', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('w4200161', 'w4200161@mus.edu', 'Cathlene', 'Cartmale', 'Male', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('f0659630', 'f0659630@mus.edu', 'Judy', 'Sarch', 'Female', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('c4512651', 'c4512651@mus.edu', 'Mikkel', 'Cadigan', 'Female', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('t3868891', 't3868891@mus.edu', 'Riccardo', 'Ornils', 'Female', 'School of Business', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('y1072606', 'y1072606@mus.edu', 'Dexter', 'Excell', 'Female', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('d7866702', 'd7866702@mus.edu', 'Christal', 'Kirsche', 'Male', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('a4535239', 'a4535239@mus.edu', 'Felicdad', 'Jachimak', 'Female', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('a0841714', 'a0841714@mus.edu', 'Melesa', 'Chappell', 'Male', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('n8810986', 'n8810986@mus.edu', 'Griselda', 'Williamson', 'Female', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('t9395594', 't9395594@mus.edu', 'Bartolomeo', 'Dilleston', 'Male', 'Faculty of Law', 'Staff');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('y7111323', 'y7111323@mus.edu', 'Bax', 'Brafferton', 'Male', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('h1421775', 'h1421775@mus.edu', 'Buddie', 'Neligan', 'Female', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('q5307975', 'q5307975@mus.edu', 'Emelen', 'Corcut', 'Female', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('p4386359', 'p4386359@mus.edu', 'Marlo', 'Starsmeare', 'Female', 'School of Business', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('u7838252', 'u7838252@mus.edu', 'Mead', 'Backshell', 'Female', 'School of Business', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('v8959942', 'v8959942@mus.edu', 'Cynthia', 'Niess', 'Male', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('i2402986', 'i2402986@mus.edu', 'Hetty', 'Wedlake', 'Female', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('a0732237', 'a0732237@mus.edu', 'Harri', 'Varian', 'Female', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('p7155061', 'p7155061@mus.edu', 'Emilia', 'Drance', 'Female', 'School of Computing', 'Staff');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('e9638698', 'e9638698@mus.edu', 'Sharon', 'Lambrecht', 'Male', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('e0762545', 'e0762545@mus.edu', 'Sean', 'Refford', 'Female', 'School of Business', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('m9203641', 'm9203641@mus.edu', 'Maryjane', 'Tradewell', 'Female', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('i6675327', 'i6675327@mus.edu', 'Drusie', 'Graveston', 'Male', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('a7879796', 'a7879796@mus.edu', 'Heall', 'Birrel', 'Female', 'Faculty of Engineering', 'Staff');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('m0324623', 'm0324623@mus.edu', 'Dona', 'Bufton', 'Male', 'School of Business', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('i3438835', 'i3438835@mus.edu', 'Denice', 'Barmadier', 'Female', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('z1680198', 'z1680198@mus.edu', 'Yehudi', 'Reolfo', 'Female', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('d6384402', 'd6384402@mus.edu', 'Rickard', 'Fitzharris', 'Female', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('m6597973', 'm6597973@mus.edu', 'Miquela', 'Maro', 'Female', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('h7832018', 'h7832018@mus.edu', 'Estell', 'Sifleet', 'Male', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('m1508783', 'm1508783@mus.edu', 'Lil', 'Dalgarnocht', 'Female', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('o4478501', 'o4478501@mus.edu', 'Quentin', 'Croome', 'Female', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('b9376328', 'b9376328@mus.edu', 'Burch', 'Tender', 'Male', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('m4492223', 'm4492223@mus.edu', 'Jedidiah', 'Coxhell', 'Male', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('t2335197', 't2335197@mus.edu', 'Kip', 'Powis', 'Male', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('d2937762', 'd2937762@mus.edu', 'Udale', 'Le Pruvost', 'Female', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('d7680555', 'd7680555@mus.edu', 'Rawley', 'Niche', 'Female', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('w1760733', 'w1760733@mus.edu', 'Shanda', 'Leal', 'Male', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('p8426435', 'p8426435@mus.edu', 'Gustaf', 'Tharme', 'Male', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('l8124903', 'l8124903@mus.edu', 'Bree', 'Ginty', 'Male', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('l3546442', 'l3546442@mus.edu', 'Roana', 'Curryer', 'Male', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('l8137620', 'l8137620@mus.edu', 'Carmela', 'Scottrell', 'Male', 'School of Business', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('a6737799', 'a6737799@mus.edu', 'Suzette', 'Berlin', 'Male', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('w1276327', 'w1276327@mus.edu', 'Fabiano', 'Burbury', 'Female', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('d9150262', 'd9150262@mus.edu', 'Kienan', 'Clopton', 'Male', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('h6860984', 'h6860984@mus.edu', 'Kaspar', 'Bellringer', 'Female', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('r7305171', 'r7305171@mus.edu', 'Preston', 'Spurriar', 'Male', 'Faculty of Medicine', 'Staff');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('v4307794', 'v4307794@mus.edu', 'Jo', 'Cheves', 'Male', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('i3759396', 'i3759396@mus.edu', 'Yettie', 'Djuricic', 'Male', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('q1369155', 'q1369155@mus.edu', 'Magdalene', 'Connick', 'Female', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('s8812894', 's8812894@mus.edu', 'Bill', 'Ord', 'Female', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('u3242611', 'u3242611@mus.edu', 'Annamaria', 'Rose', 'Male', 'School of Business', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('f5116317', 'f5116317@mus.edu', 'Domenic', 'Mannakee', 'Female', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('g8730238', 'g8730238@mus.edu', 'Doralia', 'Dearle', 'Male', 'School of Business', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('j1425189', 'j1425189@mus.edu', 'Benoit', 'Kembley', 'Female', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('d8389530', 'd8389530@mus.edu', 'Roderigo', 'Corish', 'Male', 'School of Business', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('m5247023', 'm5247023@mus.edu', 'Morly', 'Higgan', 'Male', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('f5757908', 'f5757908@mus.edu', 'Teri', 'Maginot', 'Female', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('q7709305', 'q7709305@mus.edu', 'Skippy', 'Claiden', 'Female', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('c1544288', 'c1544288@mus.edu', 'Blisse', 'Franciottoi', 'Female', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('z8597684', 'z8597684@mus.edu', 'Gregg', 'Domney', 'Female', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('x4523018', 'x4523018@mus.edu', 'Jania', 'Bernardeau', 'Female', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('r4249752', 'r4249752@mus.edu', 'Gaylord', 'Manderson', 'Female', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('z4587633', 'z4587633@mus.edu', 'Dory', 'Bonnick', 'Male', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('g1949625', 'g1949625@mus.edu', 'Harold', 'Scaice', 'Male', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('a4508582', 'a4508582@mus.edu', 'Merwyn', 'Dancer', 'Male', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('r1413378', 'r1413378@mus.edu', 'Neale', 'Shilburne', 'Female', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('y1016399', 'y1016399@mus.edu', 'Kleon', 'Matevushev', 'Female', 'School of Business', 'Staff');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('l2962141', 'l2962141@mus.edu', 'Elsinore', 'Farndon', 'Female', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('o3027908', 'o3027908@mus.edu', 'Sallyann', 'Cheves', 'Male', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('s6547182', 's6547182@mus.edu', 'Loree', 'Sturgeon', 'Female', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('v5106569', 'v5106569@mus.edu', 'Sibilla', 'Hurdle', 'Female', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('t0908195', 't0908195@mus.edu', 'Angelique', 'Blampey', 'Female', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('e6860824', 'e6860824@mus.edu', 'Nowell', 'Cummungs', 'Female', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('t6595519', 't6595519@mus.edu', 'Fred', 'Yeliashev', 'Female', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('f9707304', 'f9707304@mus.edu', 'Jacques', 'Ambrogetti', 'Female', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('u7495961', 'u7495961@mus.edu', 'Michail', 'Gawkroge', 'Male', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('e5265779', 'e5265779@mus.edu', 'Marjy', 'McKnockiter', 'Male', 'Faculty of Law', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('q6068462', 'q6068462@mus.edu', 'Natassia', 'Frend', 'Female', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('j5191298', 'j5191298@mus.edu', 'Uri', 'Nairn', 'Male', 'Faculty of Engineering', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('w8078958', 'w8078958@mus.edu', 'Fred', 'Vines', 'Male', 'Faculty of Science', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('j3003051', 'j3003051@mus.edu', 'Mirelle', 'Aleshkov', 'Female', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('r0840560', 'r0840560@mus.edu', 'Loleta', 'O''Henehan', 'Male', 'Faculty of Medicine', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('w1638705', 'w1638705@mus.edu', 'Willa', 'Schmuhl', 'Male', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('q7065464', 'q7065464@mus.edu', 'Vicky', 'Nappin', 'Male', 'School of Computing', 'Student');
INSERT INTO personnel (personnel_id, email, first_name, last_name, gender, faculty, type) VALUES ('t5362432', 't5362432@mus.edu', 'Sayre', 'Basant', 'Female', 'Faculty of Medicine', 'Student');
INSERT INTO location (location_id, name, type, lat, long) VALUES ('AU1', 'Auditorium 1', 'Auditorium/Lecture Hall', 1.28643, 103.77684);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('AU2', 'Auditorium 2', 'Auditorium/Lecture Hall', 1.29164, 103.76998);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('AU3', 'Auditorium 3', 'Auditorium/Lecture Hall', 1.29127, 103.77018);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('AU4', 'Auditorium 4', 'Auditorium/Lecture Hall', 1.29692, 103.7698);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('AU5', 'Auditorium 5', 'Auditorium/Lecture Hall', 1.28481, 103.77291);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('AU6', 'Auditorium 6', 'Auditorium/Lecture Hall', 1.29684, 103.77176);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('AU7', 'Auditorium 7', 'Auditorium/Lecture Hall', 1.294, 103.76881);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('AU8', 'Auditorium 8', 'Auditorium/Lecture Hall', 1.29269, 103.78641);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('AU9', 'Auditorium 9', 'Auditorium/Lecture Hall', 1.29573, 103.77424);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('AU10', 'Auditorium 10', 'Auditorium/Lecture Hall', 1.29754, 103.78104);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LT01', 'Lecture Theatre 1', 'Auditorium/Lecture Hall', 1.29744, 103.76568);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LT02', 'Lecture Theatre 2', 'Auditorium/Lecture Hall', 1.28723, 103.76303);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LT03', 'Lecture Theatre 3', 'Auditorium/Lecture Hall', 1.29517, 103.76232);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LT04', 'Lecture Theatre 4', 'Auditorium/Lecture Hall', 1.29907, 103.78113);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LT05', 'Lecture Theatre 5', 'Auditorium/Lecture Hall', 1.29091, 103.78379);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LT06', 'Lecture Theatre 6', 'Auditorium/Lecture Hall', 1.29499, 103.78643);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LT07', 'Lecture Theatre 7', 'Auditorium/Lecture Hall', 1.28346, 103.76284);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LT08', 'Lecture Theatre 8', 'Auditorium/Lecture Hall', 1.28262, 103.77099);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LT09', 'Lecture Theatre 9', 'Auditorium/Lecture Hall', 1.28345, 103.77338);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LT10', 'Lecture Theatre 10', 'Auditorium/Lecture Hall', 1.29085, 103.77889);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('BIZ1', 'Business 1', 'Academic building', 1.29745, 103.7856);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('BIZ2', 'Business 2', 'Academic building', 1.28572, 103.76793);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('COM1', 'Computing 1', 'Academic building', 1.28405, 103.78703);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('COM2', 'Computing 2', 'Academic building', 1.28008, 103.76405);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LAW1', 'Law 1', 'Academic building', 1.29848, 103.78185);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LAW2', 'Law 2', 'Academic building', 1.29421, 103.78094);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LAW3', 'Law 3', 'Academic building', 1.29198, 103.77879);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('ENG1', 'Engineering 1', 'Academic building', 1.2891, 103.76373);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('ENG2', 'Engineering 2', 'Academic building', 1.28736, 103.78801);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('ENG3', 'Engineering 3', 'Academic building', 1.29628, 103.77343);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('MED1', 'Medicine 1', 'Academic building', 1.29318, 103.7629);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('MED2', 'Medicine 2', 'Academic building', 1.28655, 103.76489);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('MED3', 'Medicine 3', 'Academic building', 1.29215, 103.76308);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LIF1', 'Life Science 1', 'Academic building', 1.28174, 103.7813);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LIF2', 'Life Science 2', 'Academic building', 1.28974, 103.76361);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LIF3', 'Life Science 3', 'Academic building', 1.2936, 103.78714);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('SCI1', 'Science 1', 'Academic building', 1.29823, 103.78387);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('SCI2', 'Science 2', 'Academic building', 1.28426, 103.76868);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('SCI3', 'Science 3', 'Academic building', 1.285, 103.76048);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('SCI4', 'Science 4', 'Academic building', 1.29492, 103.77413);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('SCI5', 'Science 5', 'Academic building', 1.29854, 103.77616);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('SCI6', 'Science 6', 'Academic building', 1.28464, 103.77958);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('SCI7', 'Science 7', 'Academic building', 1.29951, 103.76288);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('SCI8', 'Science 8', 'Academic building', 1.28611, 103.78199);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('SCI9', 'Science 9', 'Academic building', 1.28343, 103.78042);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('SCI10', 'Science 10', 'Academic building', 1.28848, 103.76068);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LKS', 'LKS Building', 'Academic building', 1.29023, 103.78616);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('NBK', 'NBK Building', 'Academic building', 1.28189, 103.76917);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('CBA', 'CBA Building', 'Academic building', 1.28753, 103.78451);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('UH1', 'University Hall 1', 'All-purpose Hall', 1.28301, 103.76536);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('UH2', 'University Hall 2', 'All-purpose Hall', 1.29624, 103.77845);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('UH3', 'University Hall 3', 'All-purpose Hall', 1.2828, 103.7657);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('UH4', 'University Hall 4', 'All-purpose Hall', 1.28268, 103.7729);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('UH5', 'University Hall 5', 'All-purpose Hall', 1.2938, 103.77037);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('KH1', 'Kent Hall 1', 'All-purpose Hall', 1.29686, 103.78359);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('KH2', 'Kent Hall 2', 'All-purpose Hall', 1.2935, 103.76185);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('KH3', 'Kent Hall 3', 'All-purpose Hall', 1.29787, 103.77318);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('KH4', 'Kent Hall 4', 'All-purpose Hall', 1.28114, 103.76858);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('KH5', 'Kent Hall 5', 'All-purpose Hall', 1.28211, 103.77493);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('KH6', 'Kent Hall 6', 'All-purpose Hall', 1.2911, 103.7865);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('KH7', 'Kent Hall 7', 'All-purpose Hall', 1.28249, 103.77058);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('RH1', 'Raff Hall 1', 'All-purpose Hall', 1.2858, 103.76881);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('RH2', 'Raff Hall 2', 'All-purpose Hall', 1.2862, 103.7843);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('RH3', 'Raff Hall 3', 'All-purpose Hall', 1.29898, 103.76755);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('RH4', 'Raff Hall 4', 'All-purpose Hall', 1.28591, 103.77945);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('RH5', 'Raff Hall 5', 'All-purpose Hall', 1.29429, 103.78793);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('RH6', 'Raff Hall 6', 'All-purpose Hall', 1.286, 103.76087);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('RH7', 'Raff Hall 7', 'All-purpose Hall', 1.2993, 103.76356);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('VH1', 'Vale Hall 1', 'All-purpose Hall', 1.29148, 103.78495);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('VH2', 'Vale Hall 2', 'All-purpose Hall', 1.28182, 103.78744);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('VH3', 'Vale Hall 3', 'All-purpose Hall', 1.28549, 103.76906);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('VH4', 'Vale Hall 4', 'All-purpose Hall', 1.28387, 103.78897);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('VH5', 'Vale Hall 5', 'All-purpose Hall', 1.28342, 103.76055);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('VH6', 'Vale Hall 6', 'All-purpose Hall', 1.29452, 103.77387);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('VH7', 'Vale Hall 7', 'All-purpose Hall', 1.28364, 103.7704);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LIB1', 'Library 1', 'Library', 1.29054, 103.78161);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LIB2', 'Library 2', 'Library', 1.29253, 103.77318);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('LIB3', 'Library 3', 'Library', 1.29351, 103.77638);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('FED', 'Federal Building', 'Academic building', 1.28507, 103.77411);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('MC', 'Moot Court', 'Auditorium/Lecture Hall', 1.29644, 103.76736);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('FRO', 'Frontier Canteen', 'F&B', 1.28377, 103.78629);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('CAN1', 'Canteen 1', 'F&B', 1.28731, 103.77135);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('CAN2', 'Canteen 2', 'F&B', 1.29028, 103.76351);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('CAN3', 'Canteen 3', 'F&B', 1.2976, 103.77811);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('MUS', 'Music Caf', 'F&B', 1.28168, 103.78206);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('CAF', 'Caf 123', 'F&B', 1.28787, 103.76244);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('TEA', 'Tea Party Caf', 'F&B', 1.29958, 103.76455);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('POP', 'Populus Caf', 'F&B', 1.28554, 103.77768);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('WW', 'Winter Warmer', 'F&B', 1.29822, 103.76117);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('USC', 'University Sports Centre', 'Sports', 1.28281, 103.76961);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('TC', 'Tennis Court', 'Sports', 1.28083, 103.77721);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('BC', 'Badminton Court', 'Sports', 1.29021, 103.78837);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('APB', 'All-Purpose Building', 'Sports', 1.29467, 103.76499);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('AT', 'Atown Residence', 'Sports', 1.29086, 103.76049);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('HOSA', 'Hostel A', 'Hostel', 1.29285, 103.78047);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('HOSB', 'Hostel B', 'Hostel', 1.29557, 103.77115);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('HOSC', 'Hostel C', 'Hostel', 1.28754, 103.77428);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('HOSD', 'Hostel D', 'Hostel', 1.28607, 103.77697);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('HOSE', 'Hostel E', 'Hostel', 1.28568, 103.77753);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('HOSF', 'Hostel F', 'Hostel', 1.29357, 103.78985);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('HOSG', 'Hostel G', 'Hostel', 1.2889, 103.76847);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('HOSH', 'Hostel H', 'Hostel', 1.29329, 103.78881);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('HOSI', 'Hostel I', 'Hostel', 1.28657, 103.77037);
INSERT INTO location (location_id, name, type, lat, long) VALUES ('HOSJ', 'Hostel J', 'Hostel', 1.29957, 103.76824);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
/* Perform cross join between both entity tables to get approximately 10% of possible combination. Also added a random timestamp between 2021-01-01 to 2021-07-01 as check-in time */
INSERT INTO visited (
  SELECT 
    personnel.email, 
    location.location_id, 
    timestamp '2021-01-01 20:00:00' + random() * (
      timestamp '2021-07-01 00:00:00' - timestamp '2021-01-01 00:00:00'
    ) 
  from 
    personnel, 
    location 
  where 
    random()<= 0.1
);
