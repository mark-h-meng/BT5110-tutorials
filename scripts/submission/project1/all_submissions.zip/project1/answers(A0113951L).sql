/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
The business case would be a OLTP application to facilitate the purchase of
materials used by a MNC with manufacturing sites all over the world, and 
buying supplies from all over the world. However, in most cases, due to 
quality control, plants are only able to buy from qualified suppliers, and
at the price agreed by the regional purchasing teams. Nevertheless, multiple 
suppliers may be qualified to deliver the same material, even to the same plant
in order to ensure supply security.

For a transaction to occur, the plant (entity 2) can only buy from a 
designated supplier for the specific material (entity 1) desired, and the price would 
be the agreed price. The date of order placement and expected date of delivery 
would be recorded in order to track delivery and ensure ontime delivery by suppliers. 

For simplicity sake, we take the following assumptions:
- plants can buy any materials from any suppliers
- all materials purchased can be used to make the desired products
- The unit quantity of all items is 1
- All transactions occur in hard currency (USD)

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DROP TABLE transactions;
DROP TABLE qualified_supplier;
DROP TABLE production;


create table qualified_supplier (
	supplier_name VARCHAR(64) NOT NULL,
	supplier_code VARCHAR(7) NOT NULL,
	item_name VARCHAR(64) NOT NULL,
	item_code VARCHAR(5) NOT NULL,
	destination_country VARCHAR(64) NOT NULL,
	price DECIMAL(5,2) NOT NULL, 
	PRIMARY KEY (supplier_code, item_code, destination_country, price)
);
	
CREATE TABLE production (
	plant_name VARCHAR(64) NOT NULL,
	plant_code VARCHAR(4) UNIQUE NOT NULL,
	plant_country VARCHAR(64) NOT NULL,
	PRIMARY KEY (plant_code, plant_country)
);

CREATE TABLE transactions(
	supplier_name VARCHAR(64) NOT NULL,
	supplier_code VARCHAR(7) NOT NULL,
	item_name VARCHAR(64) NOT NULL,
	item_code VARCHAR(5) NOT NULL,
	plant_name VARCHAR(64) NOT NULL,
	plant_code VARCHAR(4) NOT NULL,
	plant_country VARCHAR(64) NOT NULL,
	price DECIMAL(5,2) NOT NULL,
	po_date DATE NOT NULL, 
	FOREIGN KEY (supplier_code, item_code, plant_country, price ) REFERENCES qualified_supplier (supplier_code, item_code, destination_country, price), 
	FOREIGN KEY (plant_code, plant_country) REFERENCES production (plant_code, plant_country)
);



/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bailey, Schumm and Schmitt', 5489675, 'Rabbit - Frozen', 1592, 'South Africa', 64.89);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Beer LLC', 7107868, 'Broom And Broom Rack White', 6947, 'Canada', 38.02);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Berge, Herman and Gutkowski', 9698275, 'Sobe - Orange Carrot', 522, 'Greece', 96.49);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Jones-Barton', 2229318, 'Buffalo - Short Rib Fresh', 9833, 'Canada', 33.06);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Hartmann-Schroeder', 1645623, 'Bandage - Finger Cots', 5829, 'Armenia', 87.4);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Gusikowski, Heathcote and Olson', 1348702, 'Nescafe - Frothy French Vanilla', 5764, 'Uzbekistan', 80.51);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Mitchell, Kutch and Greenholt', 3454718, 'Lobster - Base', 6573, 'South Africa', 77.12);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Heidenreich, Towne and Gibson', 1030407, 'Pie Box - Cello Window 2.5', 3896, '﻿Brazil', 4.58);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Beer LLC', 7107868, 'Ice Cream Bar - Hageen Daz To', 5704, 'Canada', 57.21);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Mitchell, Kutch and Greenholt', 3454718, 'Pie Shells 10', 5414, 'Czech Republic', 88.92);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bode-Bosco', 3764826, 'Flour - Masa De Harina Mexican', 2146, 'Russia', 42.91);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Hartmann-Schroeder', 1645623, 'Grapefruit - Pink', 6288, 'Philippines', 6.08);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Cummings, Streich and Homenick', 3908154, 'Lumpfish Black', 1581, 'Czech Republic', 98.51);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Hartmann-Schroeder', 1645623, 'Orange Roughy 4/6 Oz', 3077, 'Japan', 6.25);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Hartmann-Schroeder', 1645623, 'Wine - Fontanafredda Barolo', 193, 'Japan', 29.65);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Mitchell, Kutch and Greenholt', 3454718, 'Rabbit - Frozen', 1592, 'Mongolia', 17.17);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Hartmann-Schroeder', 1645623, 'Ecolab Silver Fusion', 3505, 'Canada', 48.68);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Gusikowski, Heathcote and Olson', 1348702, 'Squid - Breaded', 6928, 'Uzbekistan', 87.67);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Gusikowski, Heathcote and Olson', 1348702, 'Club Soda - Schweppes, 355 Ml', 6019, 'Portugal', 88.87);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Glover-Sanford', 9891936, 'Scallops - Live In Shell', 9537, 'Bosnia and Herzegovina', 79.3);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Glover-Sanford', 9891936, 'Sobe - Orange Carrot', 522, 'Japan', 24.82);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Lakin-Wehner', 6027265, 'Grapefruit - Pink', 6288, 'Portugal', 98.78);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Jones-Barton', 2229318, 'Beef - Montreal Smoked Brisket', 360, 'Japan', 3.39);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Mitchell, Kutch and Greenholt', 3454718, 'Pepper - Cubanelle', 572, 'Russia', 92.78);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Lakin-Wehner', 6027265, 'Cake - Bande Of Fruit', 2346, 'Czech Republic', 97.59);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Mitchell, Kutch and Greenholt', 3454718, 'Truffle Shells - White Chocolate', 1929, 'Argentina', 75.74);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Dibbert LLC', 2978731, 'Wine - Barossa Valley Estate', 3520, 'Czech Republic', 89.99);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Dibbert LLC', 2978731, 'Tomatoes - Vine Ripe, Yellow', 801, 'Pakistan', 97.49);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Berge, Herman and Gutkowski', 9698275, 'Durian Fruit', 2861, '﻿Brazil', 34.16);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Glover-Sanford', 9891936, 'Cheese - Taleggio D.o.p.', 3006, 'Mongolia', 52.27);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Schoen-O''Keefe', 857443, 'Potatoes - Fingerling 4 Oz', 5262, 'Russia', 40.44);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Osinski, Vandervort and Considine', 6286482, 'Pastry - Carrot Muffin - Mini', 6084, 'El Salvador', 26.82);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Berge, Herman and Gutkowski', 9698275, 'Cod - Fillets', 3189, 'Ghana', 43.08);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Hackett-Grimes', 3560996, 'Chocolate Bar - Oh Henry', 4058, 'South Africa', 97.2);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Schoen-O''Keefe', 857443, 'Quail Eggs - Canned', 5858, 'Canada', 98.07);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Mitchell, Kutch and Greenholt', 3454718, 'Wine - Beaujolais Villages', 493, 'Ghana', 55.64);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Mitchell, Kutch and Greenholt', 3454718, 'Lumpfish Black', 1581, 'Bosnia and Herzegovina', 46.38);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Mitchell, Kutch and Greenholt', 3454718, 'Pop Shoppe Cream Soda', 5740, 'Mauritius', 71.58);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Hartmann-Schroeder', 1645623, 'Jam - Blackberry, 20 Ml Jar', 304, 'South Africa', 86.48);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Lakin-Wehner', 6027265, 'Pastry - Carrot Muffin - Mini', 6084, 'Portugal', 52.75);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Berge, Herman and Gutkowski', 9698275, 'Lobster - Base', 6573, 'Bosnia and Herzegovina', 32.28);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Schoen-O''Keefe', 857443, 'Water - Mineral, Carbonated', 3240, 'Mongolia', 18.11);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Dibbert LLC', 2978731, 'Lemonade - Island Tea, 591 Ml', 8371, 'Argentina', 75.45);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Dibbert LLC', 2978731, 'Pastry - Carrot Muffin - Mini', 6084, 'Czech Republic', 57.56);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Kerluke-Moen', 8381684, 'Scallops - Live In Shell', 9537, 'Bosnia and Herzegovina', 25.76);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bailey, Schumm and Schmitt', 5489675, 'Wine - Red, Mosaic Zweigelt', 8930, 'Mauritius', 74.28);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Hackett-Grimes', 3560996, 'Pork - Ham Hocks - Smoked', 1544, 'Uzbekistan', 54.68);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Schoen-O''Keefe', 857443, 'Nescafe - Frothy French Vanilla', 5764, 'Argentina', 82.2);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Cummings, Streich and Homenick', 3908154, 'Nescafe - Frothy French Vanilla', 5764, 'Argentina', 73.52);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Mitchell, Kutch and Greenholt', 3454718, 'Club Soda - Schweppes, 355 Ml', 6019, 'Uzbekistan', 40.34);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bode-Bosco', 3764826, 'Roe - Lump Fish, Red', 4284, 'El Salvador', 54.47);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Heidenreich, Towne and Gibson', 1030407, 'Chestnuts - Whole,canned', 4557, 'Ghana', 26.33);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Hartmann-Schroeder', 1645623, 'Tamarillo', 9919, 'Mongolia', 80.28);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bode-Bosco', 3764826, 'Pepper - Cubanelle', 572, 'Japan', 61.39);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Hartmann-Schroeder', 1645623, 'Tart Shells - Sweet, 3', 1562, 'Japan', 73.43);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Mitchell, Kutch and Greenholt', 3454718, 'Pheasants - Whole', 9010, 'Mongolia', 85.23);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Glover-Sanford', 9891936, 'Calvados - Boulard', 5213, 'Sweden', 52.21);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Dibbert LLC', 2978731, 'Longos - Lasagna Veg', 2510, 'Armenia', 67.17);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Mitchell, Kutch and Greenholt', 3454718, 'Sobe - Orange Carrot', 522, 'El Salvador', 79.59);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bins, Thiel and Pollich', 5275117, 'Vinegar - Champagne', 8005, '﻿Brazil', 32.79);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bode-Bosco', 3764826, 'Bar Mix - Pina Colada, 355 Ml', 5167, 'Armenia', 12.36);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Lakin-Wehner', 6027265, 'Muffin Batt - Choc Chk', 4197, 'Ghana', 14.81);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Glover-Sanford', 9891936, 'Pepper - Chilli Seeds Mild', 211, 'Philippines', 97.75);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Mitchell, Kutch and Greenholt', 3454718, 'Potatoes - Parissienne', 2305, 'Russia', 74.85);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Glover-Sanford', 9891936, 'Pie Box - Cello Window 2.5', 3896, 'Armenia', 63.5);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bailey, Schumm and Schmitt', 5489675, 'Mushrooms - Honey', 8166, 'Mongolia', 85.72);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bins, Thiel and Pollich', 5275117, 'Pepper - Chilli Seeds Mild', 211, 'El Salvador', 30.8);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Osinski, Vandervort and Considine', 6286482, 'Muffin Carrot - Individual', 6576, 'Pakistan', 94.72);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Kerluke-Moen', 8381684, 'Ice Cream Bar - Hageen Daz To', 5704, 'Portugal', 2.52);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Kerluke-Moen', 8381684, 'Cheese - Brie, Cups 125g', 8917, 'Armenia', 77.31);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Lakin-Wehner', 6027265, 'Flour Dark Rye', 6139, 'Mauritius', 76.16);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Beer LLC', 7107868, 'Chocolate Bar - Oh Henry', 4058, 'Netherlands', 44.42);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Heidenreich, Towne and Gibson', 1030407, 'Pastry - Carrot Muffin - Mini', 6084, 'Uzbekistan', 1.65);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Glover-Sanford', 9891936, 'Tamarillo', 9919, 'South Africa', 14.19);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Mitchell, Kutch and Greenholt', 3454718, 'Jam - Blackberry, 20 Ml Jar', 304, '﻿Brazil', 42.33);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Heidenreich, Towne and Gibson', 1030407, 'Syrup - Monin - Granny Smith', 9652, 'South Africa', 89.92);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bins, Thiel and Pollich', 5275117, 'Ice Cream Bar - Hageen Daz To', 5704, 'Mongolia', 58.37);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Osinski, Vandervort and Considine', 6286482, 'Pie Shell - 9', 6991, 'Armenia', 42.6);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bailey, Schumm and Schmitt', 5489675, 'Sprouts - Bean', 43, 'Portugal', 50.07);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bode-Bosco', 3764826, 'Bandage - Finger Cots', 5829, 'Portugal', 25.56);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Sipes-Schaden', 3873993, 'Brownies - Two Bite, Chocolate', 91, '﻿Brazil', 52.29);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Jones-Barton', 2229318, 'Cheese - St. Andre', 560, 'Philippines', 20.29);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Gusikowski, Heathcote and Olson', 1348702, 'Water - Mineral, Carbonated', 3240, 'Portugal', 64.22);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bins, Thiel and Pollich', 5275117, 'Flour - Masa De Harina Mexican', 2146, 'Uzbekistan', 85.9);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Sipes-Schaden', 3873993, 'Kirsch - Schloss', 6959, 'Bosnia and Herzegovina', 18.96);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Kerluke-Moen', 8381684, 'Broom And Broom Rack White', 6947, 'Japan', 21.15);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Kerluke-Moen', 8381684, 'Lumpfish Black', 1581, 'Japan', 95.71);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Heidenreich, Towne and Gibson', 1030407, 'Bandage - Finger Cots', 5829, 'Pakistan', 16.72);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Beer LLC', 7107868, 'Tart Shells - Sweet, 3', 1562, 'Czech Republic', 47.62);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Schoen-O''Keefe', 857443, 'Tomatillo', 9365, 'Greece', 15.79);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Heidenreich, Towne and Gibson', 1030407, 'Pepper - Chilli Seeds Mild', 211, 'Ghana', 94.06);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bailey, Schumm and Schmitt', 5489675, 'Club Soda - Schweppes, 355 Ml', 6019, 'Russia', 85.31);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Bode-Bosco', 3764826, 'Ham - Procutinni', 1723, 'Czech Republic', 5.14);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Hackett-Grimes', 3560996, 'Cake Sheet Combo Party Pack', 6429, 'El Salvador', 78.23);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Osinski, Vandervort and Considine', 6286482, 'Potatoes - Parissienne', 2305, 'Portugal', 88.25);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Hartmann-Schroeder', 1645623, 'Wine - Baron De Rothschild', 1279, 'Ghana', 54.75);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Heidenreich, Towne and Gibson', 1030407, 'Sobe - Orange Carrot', 522, 'Mauritius', 58.1);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Cummings, Streich and Homenick', 3908154, 'Ecolab Silver Fusion', 3505, 'Bosnia and Herzegovina', 30.53);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Sipes-Schaden', 3873993, 'Kirsch - Schloss', 6959, 'Argentina', 64.86);
insert into qualified_supplier (supplier_name, supplier_code, item_name, item_code, destination_country, price) values ('Lakin-Wehner', 6027265, 'Broom And Broom Rack White', 9107, 'Pakistan', 39.46);


insert into production (plant_name, plant_code, plant_country) values ('Miller', 'U942', 'China');
insert into production (plant_name, plant_code, plant_country) values ('Scofield', 'K418', 'Poland');
insert into production (plant_name, plant_code, plant_country) values ('Caliangt', 'J462', 'Canada');
insert into production (plant_name, plant_code, plant_country) values ('Utah', 'G351', 'Japan');
insert into production (plant_name, plant_code, plant_country) values ('Kipling', 'C783', 'Czech Republic');
insert into production (plant_name, plant_code, plant_country) values ('Forster', '9903', 'South Africa');
insert into production (plant_name, plant_code, plant_country) values ('Bunker Hill', 'L479', 'Sweden');
insert into production (plant_name, plant_code, plant_country) values ('Fuller', '1463', 'Brazil');
insert into production (plant_name, plant_code, plant_country) values ('Fordem', 'A554', 'Portugal');
insert into production (plant_name, plant_code, plant_country) values ('Loomis', '3555', 'Canada');
insert into production (plant_name, plant_code, plant_country) values ('Park Meadow', 'E001', 'South Africa');
insert into production (plant_name, plant_code, plant_country) values ('Milwaukee', 'T739', 'France');
insert into production (plant_name, plant_code, plant_country) values ('Merry', 'P980', 'Brazil');
insert into production (plant_name, plant_code, plant_country) values ('Burrows', 'U721', 'China');
insert into production (plant_name, plant_code, plant_country) values ('Sherman', 'T812', 'Brazil');
insert into production (plant_name, plant_code, plant_country) values ('Longview', 'Y773', 'Seychelles');
insert into production (plant_name, plant_code, plant_country) values ('Pawling', 'R115', 'Canada');
insert into production (plant_name, plant_code, plant_country) values ('Miller', '8093', 'Portugal');
insert into production (plant_name, plant_code, plant_country) values ('Washington', '8753', 'Portugal');
insert into production (plant_name, plant_code, plant_country) values ('Hovde', 'N068', 'China');
insert into production (plant_name, plant_code, plant_country) values ('Hoepker', '5954', 'Sweden');
insert into production (plant_name, plant_code, plant_country) values ('Coolidge', 'L152', 'Malaysia');
insert into production (plant_name, plant_code, plant_country) values ('Artisan', 'V245', 'Sweden');
insert into production (plant_name, plant_code, plant_country) values ('Gulseth', 'Q185', 'Tunisia');
insert into production (plant_name, plant_code, plant_country) values ('Messerschmidt', '2756', 'Japan');
insert into production (plant_name, plant_code, plant_country) values ('Hoard', 'S802', 'Czech Republic');
insert into production (plant_name, plant_code, plant_country) values ('Columbus', 'B580', 'Brazil');
insert into production (plant_name, plant_code, plant_country) values ('Hoepker', '0768', 'Philippines');
insert into production (plant_name, plant_code, plant_country) values ('Fordem', 'R990', 'Japan');
insert into production (plant_name, plant_code, plant_country) values ('Waywood', 'F306', 'China');
insert into production (plant_name, plant_code, plant_country) values ('West', 'B565', 'France');
insert into production (plant_name, plant_code, plant_country) values ('Glendale', '1429', 'Canada');
insert into production (plant_name, plant_code, plant_country) values ('Eagle Crest', 'Q061', 'Canada');
insert into production (plant_name, plant_code, plant_country) values ('Fairview', 'Y164', 'Sweden');
insert into production (plant_name, plant_code, plant_country) values ('Scoville', '5386', 'Poland');
insert into production (plant_name, plant_code, plant_country) values ('Fairview', 'K708', 'China');
insert into production (plant_name, plant_code, plant_country) values ('Waxwing', 'I916', 'France');
insert into production (plant_name, plant_code, plant_country) values ('Old Shore', 'W570', 'Czech Republic');
insert into production (plant_name, plant_code, plant_country) values ('Chive', 'P300', 'Portugal');
insert into production (plant_name, plant_code, plant_country) values ('Loftsgordon', '4186', 'South Africa');
insert into production (plant_name, plant_code, plant_country) values ('Warrior', 'D661', 'Canada');
insert into production (plant_name, plant_code, plant_country) values ('Annamark', 'A369', 'Brazil');
insert into production (plant_name, plant_code, plant_country) values ('Northview', '3346', 'Brazil');
insert into production (plant_name, plant_code, plant_country) values ('Melby', 'A447', 'Sweden');
insert into production (plant_name, plant_code, plant_country) values ('Johnson', 'C855', 'Seychelles');
insert into production (plant_name, plant_code, plant_country) values ('Eastwood', 'L476', 'Sweden');
insert into production (plant_name, plant_code, plant_country) values ('Dovetail', '6765', 'Thailand');
insert into production (plant_name, plant_code, plant_country) values ('Eagan', '5246', 'Brazil');
insert into production (plant_name, plant_code, plant_country) values ('Clemons', 'T961', 'Czech Republic');
insert into production (plant_name, plant_code, plant_country) values ('Reindahl', 'P627', 'Poland');
insert into production (plant_name, plant_code, plant_country) values ('Sunnyside', 'B706', 'Tunisia');
insert into production (plant_name, plant_code, plant_country) values ('Cottonwood', '7280', 'Canada');
insert into production (plant_name, plant_code, plant_country) values ('Southridge', 'M298', 'China');
insert into production (plant_name, plant_code, plant_country) values ('Darwin', '6977', 'Canada');
insert into production (plant_name, plant_code, plant_country) values ('Green', 'X387', 'Sweden');
insert into production (plant_name, plant_code, plant_country) values ('Dayton', 'M413', 'Brazil');
insert into production (plant_name, plant_code, plant_country) values ('1st', 'W625', 'Brazil');
insert into production (plant_name, plant_code, plant_country) values ('Summerview', 'G674', 'Brazil');
insert into production (plant_name, plant_code, plant_country) values ('Kim', 'L044', 'Seychelles');
insert into production (plant_name, plant_code, plant_country) values ('Cottonwood', 'Y434', 'Colombia');
insert into production (plant_name, plant_code, plant_country) values ('Village', 'T393', 'Seychelles');
insert into production (plant_name, plant_code, plant_country) values ('Sachtjen', 'G991', 'Philippines');
insert into production (plant_name, plant_code, plant_country) values ('Arapahoe', 'T271', 'China');
insert into production (plant_name, plant_code, plant_country) values ('Laurel', '3889', 'France');
insert into production (plant_name, plant_code, plant_country) values ('East', '8346', 'Brazil');
insert into production (plant_name, plant_code, plant_country) values ('Drewry', 'C622', 'Japan');
insert into production (plant_name, plant_code, plant_country) values ('American Ash', 'N649', 'Colombia');
insert into production (plant_name, plant_code, plant_country) values ('Knutson', '6745', 'Japan');
insert into production (plant_name, plant_code, plant_country) values ('Bultman', 'J258', 'Czech Republic');
insert into production (plant_name, plant_code, plant_country) values ('Elgar', 'E033', 'South Africa');
insert into production (plant_name, plant_code, plant_country) values ('Hoffman', 'A519', 'China');
insert into production (plant_name, plant_code, plant_country) values ('Oriole', '4616', 'Poland');
insert into production (plant_name, plant_code, plant_country) values ('Jenifer', '2816', 'Sweden');
insert into production (plant_name, plant_code, plant_country) values ('Talmadge', 'W913', 'Japan');
insert into production (plant_name, plant_code, plant_country) values ('Quincy', 'P379', 'Philippines');
insert into production (plant_name, plant_code, plant_country) values ('Dottie', 'P162', 'Tunisia');
insert into production (plant_name, plant_code, plant_country) values ('Nova', 'O461', 'Japan');
insert into production (plant_name, plant_code, plant_country) values ('Morrow', '9053', 'Canada');
insert into production (plant_name, plant_code, plant_country) values ('Daystar', 'S753', 'Tunisia');
insert into production (plant_name, plant_code, plant_country) values ('Hansons', '5040', 'Tunisia');
insert into production (plant_name, plant_code, plant_country) values ('Burrows', 'G436', 'Canada');
insert into production (plant_name, plant_code, plant_country) values ('Green', 'I394', 'China');
insert into production (plant_name, plant_code, plant_country) values ('Acker', 'I980', 'Seychelles');
insert into production (plant_name, plant_code, plant_country) values ('David', '2191', 'Brazil');
insert into production (plant_name, plant_code, plant_country) values ('Corry', 'W506', 'China');
insert into production (plant_name, plant_code, plant_country) values ('Tony', '2318', 'Colombia');
insert into production (plant_name, plant_code, plant_country) values ('Aberg', 'E124', 'Brazil');
insert into production (plant_name, plant_code, plant_country) values ('Packers', '8336', 'Sweden');
insert into production (plant_name, plant_code, plant_country) values ('Oneill', 'D083', 'Canada');
insert into production (plant_name, plant_code, plant_country) values ('Butternut', '9855', 'Sweden');
insert into production (plant_name, plant_code, plant_country) values ('Blackbird', 'Q356', 'Japan');
insert into production (plant_name, plant_code, plant_country) values ('Esch', 'H181', 'Sweden');
insert into production (plant_name, plant_code, plant_country) values ('Del Sol', 'A508', 'Seychelles');
insert into production (plant_name, plant_code, plant_country) values ('American', 'Y236', 'Poland');
insert into production (plant_name, plant_code, plant_country) values ('Erie', 'M547', 'Brazil');
insert into production (plant_name, plant_code, plant_country) values ('Russell', 'B045', 'China');
insert into production (plant_name, plant_code, plant_country) values ('Grover', 'A477', 'China');
insert into production (plant_name, plant_code, plant_country) values ('Lotheville', '1597', 'Malaysia');
insert into production (plant_name, plant_code, plant_country) values ('Corben', 'B881', 'Tunisia');
insert into production (plant_name, plant_code, plant_country) values ('Eagle Crest', 'Z361', 'Brazil');



/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO transactions
SELECT
	supplier_name,supplier_code,item_name,item_code,
	plant_name,plant_code,plant_country,price, po_date
FROM
	qualified_supplier
LEFT JOIN production ON destination_country = plant_country
CROSS JOIN generate_series('1/1/2020'::date, '1/1/2021'::date, '1 day') AS po_date
WHERE plant_country IS NOT NULL
ORDER BY random() limit 1000;
