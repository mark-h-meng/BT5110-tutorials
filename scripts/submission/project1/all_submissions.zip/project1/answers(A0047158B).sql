/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */


/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
This example show the prescription of drugs for patients. The first entity 
table records the patient information, whereas the second entity table records
the drug information. The relationship table records the prescription of drugs 
to patients. Codes are done in PostgreSQL.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
-- First Entity Table: patient table with patient info
CREATE TABLE patients (
	row_id INT NOT NULL,
	patient_id VARCHAR(50) PRIMARY KEY,
	first_name VARCHAR(50) NOT NULL,
	last_name VARCHAR(50) NOT NULL,
	email VARCHAR(50) UNIQUE NOT NULL,
	gender VARCHAR(50) NOT NULL,
	dob DATE NOT NULL,
	CHECK (gender IN ('Male', 'Female'))
);

-- Second Entity Table: drugs table with drugs info
CREATE TABLE drugs (
	row_id INT NOT NULL,
	drug_id VARCHAR(50) NOT NULL,
	drug_name VARCHAR(100) NOT NULL,
	batch VARCHAR(50) NOT NULL,
	manufacturer_id VARCHAR(50) NOT NULL,
	manufacturer_name VARCHAR(100) NOT NULL,
	PRIMARY KEY (drug_id, batch)
);

-- Relationship Table: prescriptions table with prescription info
CREATE TABLE prescriptions (
	patient_id VARCHAR(50) REFERENCES patients(patient_id)
		ON UPDATE CASCADE
		ON DELETE CASCADE
		DEFERRABLE,
	drug_id VARCHAR(50) NOT NULL,
	batch VARCHAR(50) NOT NULL,
	FOREIGN KEY (drug_id, batch) REFERENCES drugs(drug_id, batch)
		ON UPDATE CASCADE
		ON DELETE CASCADE
		DEFERRABLE
);


/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
-- Insert data to patients table (100 rows)
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (1, '2110654090', 'Melita', 'Corton', 'mcorton0@barnesandnoble.com', 'Male', '2014-08-29');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (2, '6816992342', 'De witt', 'Frogley', 'dfrogley1@hao123.com', 'Male', '1975-04-14');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (3, '3929358336', 'Jo', 'Cholmondeley', 'jcholmondeley2@360.cn', 'Male', '1989-09-27');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (4, '4218281513', 'Savina', 'Poyle', 'spoyle3@dmoz.org', 'Male', '1955-04-18');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (5, '7065378969', 'Hewett', 'Mecozzi', 'hmecozzi4@php.net', 'Male', '1974-07-19');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (6, '7063205765', 'Thayne', 'Harpur', 'tharpur5@domainmarket.com', 'Female', '1981-12-17');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (7, '9783535536', 'Michaella', 'Philippet', 'mphilippet6@adobe.com', 'Male', '2003-03-15');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (8, '3958659713', 'Mehetabel', 'Sheard', 'msheard7@ibm.com', 'Male', '2014-02-18');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (9, '9089385290', 'Ernestine', 'Stonnell', 'estonnell8@google.es', 'Male', '1966-05-06');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (10, '9494903994', 'Viole', 'Meineck', 'vmeineck9@mayoclinic.com', 'Male', '2009-03-29');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (11, '8462873975', 'Ulick', 'Summerton', 'usummertona@deviantart.com', 'Female', '1997-08-28');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (12, '9390444780', 'Hally', 'Ferenc', 'hferencb@youtu.be', 'Female', '2014-12-31');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (13, '5190186113', 'Danya', 'O''Farrell', 'dofarrellc@istockphoto.com', 'Male', '1976-02-26');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (14, '5253321462', 'Dinny', 'Vanyakin', 'dvanyakind@google.it', 'Male', '1954-12-07');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (15, '9101503995', 'Brear', 'Cordaroy', 'bcordaroye@dedecms.com', 'Male', '1993-12-18');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (16, '3686796694', 'Jemmie', 'Durnall', 'jdurnallf@biblegateway.com', 'Male', '1960-09-25');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (17, '8657577992', 'Scarlet', 'Maunder', 'smaunderg@pbs.org', 'Male', '1997-09-18');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (18, '0782572294', 'Rory', 'Clemoes', 'rclemoesh@msu.edu', 'Female', '2020-07-28');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (19, '7137261019', 'Pris', 'Haresnaip', 'pharesnaipi@unblog.fr', 'Female', '1991-02-19');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (20, '3328255788', 'Rutger', 'Garthside', 'rgarthsidej@so-net.ne.jp', 'Female', '1964-01-09');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (21, '2617651843', 'Bette', 'Ruppele', 'bruppelek@adobe.com', 'Male', '1971-06-04');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (22, '7974496282', 'Elie', 'Naisby', 'enaisbyl@seattletimes.com', 'Male', '2019-10-21');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (23, '8252161448', 'Anjanette', 'Barrus', 'abarrusm@npr.org', 'Male', '1960-10-12');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (24, '6669190263', 'Aleksandr', 'Dublin', 'adublinn@paginegialle.it', 'Female', '2016-08-24');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (25, '1705971679', 'Koo', 'Browell', 'kbrowello@imdb.com', 'Female', '2007-09-10');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (26, '7215969819', 'Pippo', 'Archambault', 'parchambaultp@eventbrite.com', 'Female', '2004-08-24');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (27, '6931654845', 'Daphne', 'Flohard', 'dflohardq@macromedia.com', 'Male', '2014-10-04');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (28, '6143982341', 'Candi', 'Godbald', 'cgodbaldr@shareasale.com', 'Female', '1962-02-19');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (29, '3492954839', 'Rhea', 'Jira', 'rjiras@noaa.gov', 'Male', '2017-03-18');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (30, '6990470240', 'Davide', 'Goodley', 'dgoodleyt@topsy.com', 'Female', '1966-05-10');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (31, '0488890829', 'Tiertza', 'Breazeall', 'tbreazeallu@sogou.com', 'Male', '1996-04-15');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (32, '0855167513', 'Thelma', 'Hendriksen', 'thendriksenv@scribd.com', 'Male', '2011-11-29');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (33, '0346815959', 'Damita', 'Ridings', 'dridingsw@yellowbook.com', 'Male', '1977-05-15');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (34, '8529627172', 'Pierette', 'Scoggans', 'pscoggansx@mediafire.com', 'Female', '1969-05-13');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (35, '2533227102', 'Noni', 'Antony', 'nantonyy@hibu.com', 'Male', '1977-01-30');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (36, '0474113760', 'Shara', 'Haslam', 'shaslamz@mapy.cz', 'Male', '2009-06-21');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (37, '8045281278', 'Janek', 'Spall', 'jspall10@nyu.edu', 'Male', '1971-05-15');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (38, '2005087408', 'Adrian', 'Skillings', 'askillings11@twitter.com', 'Female', '2019-02-09');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (39, '9268198010', 'Lezlie', 'Garman', 'lgarman12@altervista.org', 'Female', '1996-07-05');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (40, '4150712999', 'Wilbert', 'Sparkes', 'wsparkes13@google.ca', 'Female', '1963-08-02');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (41, '9092197955', 'Lin', 'Lawrenson', 'llawrenson14@xrea.com', 'Female', '1966-01-12');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (42, '3621871268', 'Tiff', 'Wheowall', 'twheowall15@webeden.co.uk', 'Female', '1951-06-16');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (43, '3236235306', 'Demetre', 'Rivelin', 'drivelin16@mediafire.com', 'Female', '1992-11-12');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (44, '5027239785', 'Sandor', 'MacGibbon', 'smacgibbon17@mashable.com', 'Male', '1992-05-30');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (45, '2837608858', 'Nora', 'Hawsby', 'nhawsby18@patch.com', 'Male', '2004-10-22');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (46, '1707742308', 'Maximo', 'Offener', 'moffener19@w3.org', 'Male', '2013-08-28');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (47, '0791911349', 'Carree', 'Oxbury', 'coxbury1a@gnu.org', 'Male', '1993-10-03');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (48, '6168139613', 'Mariette', 'Vanezis', 'mvanezis1b@guardian.co.uk', 'Male', '1961-11-15');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (49, '6423777632', 'Yankee', 'Lowdeane', 'ylowdeane1c@china.com.cn', 'Male', '1962-03-04');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (50, '9644553640', 'Naomi', 'Thomkins', 'nthomkins1d@youku.com', 'Female', '1975-06-04');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (51, '1329720652', 'Chrissie', 'Chardin', 'cchardin1e@shareasale.com', 'Male', '1965-06-02');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (52, '7933763065', 'Keriann', 'Valente', 'kvalente1f@cyberchimps.com', 'Male', '1997-12-26');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (53, '6934384695', 'Bud', 'Aron', 'baron1g@php.net', 'Female', '2004-12-26');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (54, '6441380714', 'Hube', 'Vivash', 'hvivash1h@reference.com', 'Male', '1966-12-14');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (55, '1767427891', 'Allyn', 'Milton', 'amilton1i@163.com', 'Female', '2016-11-30');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (56, '1285424247', 'Kile', 'Runsey', 'krunsey1j@nationalgeographic.com', 'Male', '1995-09-30');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (57, '8331094018', 'Spike', 'Brodley', 'sbrodley1k@about.com', 'Male', '1991-12-22');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (58, '4167004259', 'Hilarius', 'Quesne', 'hquesne1l@4shared.com', 'Female', '1968-05-14');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (59, '7650395030', 'Friedrick', 'Arnoll', 'farnoll1m@clickbank.net', 'Female', '1986-05-04');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (60, '5665542725', 'Markos', 'Josefovic', 'mjosefovic1n@weather.com', 'Male', '1994-08-18');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (61, '1316415066', 'Brittan', 'Bartoleyn', 'bbartoleyn1o@archive.org', 'Male', '2012-09-07');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (62, '1108402704', 'Oralia', 'Hartlebury', 'ohartlebury1p@blog.com', 'Male', '1985-08-01');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (63, '5365698436', 'Tresa', 'Viveash', 'tviveash1q@amazonaws.com', 'Male', '1978-07-05');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (64, '9271270053', 'Merwyn', 'Gianelli', 'mgianelli1r@surveymonkey.com', 'Female', '1976-01-20');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (65, '8760864958', 'Phillipe', 'Duffitt', 'pduffitt1s@unblog.fr', 'Male', '2016-06-15');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (66, '1456755137', 'Elyssa', 'Lafond', 'elafond1t@rediff.com', 'Male', '1977-07-09');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (67, '8946610689', 'Shayna', 'Atling', 'satling1u@answers.com', 'Male', '1974-07-06');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (68, '5724290065', 'Evangelina', 'Mussotti', 'emussotti1v@pcworld.com', 'Female', '1978-04-05');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (69, '0287940209', 'Sheff', 'Linke', 'slinke1w@utexas.edu', 'Female', '1998-03-21');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (70, '2955623741', 'Shanna', 'Agus', 'sagus1x@diigo.com', 'Female', '1984-10-04');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (71, '2141221110', 'Theodosia', 'Mougenel', 'tmougenel1y@t-online.de', 'Male', '1965-03-05');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (72, '8261399362', 'Ellwood', 'Skeermer', 'eskeermer1z@topsy.com', 'Female', '1969-08-20');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (73, '7154769882', 'Zane', 'Gibb', 'zgibb20@example.com', 'Female', '2012-10-03');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (74, '2207968006', 'Barron', 'Rigden', 'brigden21@npr.org', 'Female', '1954-05-28');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (75, '5819953479', 'Erasmus', 'Baildon', 'ebaildon22@hostgator.com', 'Female', '1957-02-18');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (76, '5745315660', 'Georgy', 'Follan', 'gfollan23@purevolume.com', 'Female', '1992-09-12');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (77, '0890135878', 'Kippar', 'Zuppa', 'kzuppa24@people.com.cn', 'Male', '1981-05-23');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (78, '0017179211', 'Claudina', 'Cloney', 'ccloney25@businessinsider.com', 'Female', '1984-09-09');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (79, '0969195257', 'Lona', 'Di Pietro', 'ldipietro26@google.co.jp', 'Male', '1969-12-16');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (80, '8129776294', 'Renault', 'Mulbery', 'rmulbery27@unc.edu', 'Female', '1959-06-14');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (81, '2974672442', 'Margo', 'Niset', 'mniset28@latimes.com', 'Female', '1999-08-04');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (82, '8251881110', 'Merill', 'McMurraya', 'mmcmurraya29@aol.com', 'Female', '1972-06-23');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (83, '3883306738', 'Katine', 'Serjeantson', 'kserjeantson2a@mit.edu', 'Female', '2004-09-13');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (84, '3013605251', 'Ross', 'John', 'rjohn2b@google.es', 'Male', '1959-01-31');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (85, '6337189035', 'Kelcey', 'Treamayne', 'ktreamayne2c@usda.gov', 'Female', '2002-01-24');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (86, '3321585626', 'Raine', 'Cholton', 'rcholton2d@artisteer.com', 'Female', '1954-03-01');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (87, '1752352947', 'Pearline', 'Dahmel', 'pdahmel2e@weibo.com', 'Female', '2002-01-20');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (88, '6496071888', 'Shurlock', 'Brosius', 'sbrosius2f@upenn.edu', 'Male', '2019-01-20');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (89, '8409410729', 'Barbette', 'Grigorio', 'bgrigorio2g@friendfeed.com', 'Male', '1975-12-26');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (90, '0961875003', 'Anestassia', 'Austing', 'aausting2h@surveymonkey.com', 'Female', '1979-03-26');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (91, '2961469880', 'Dominic', 'Lardge', 'dlardge2i@disqus.com', 'Female', '1976-07-22');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (92, '7786982507', 'Ingrim', 'Kimblen', 'ikimblen2j@scribd.com', 'Female', '2010-12-20');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (93, '1929748051', 'Irma', 'Mashal', 'imashal2k@nba.com', 'Female', '1979-10-20');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (94, '3296601376', 'Rickard', 'Kuhnert', 'rkuhnert2l@soundcloud.com', 'Female', '1980-07-01');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (95, '8287024064', 'Chas', 'Hayen', 'chayen2m@wikia.com', 'Male', '1963-01-13');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (96, '2466533677', 'Kirsten', 'Novakovic', 'knovakovic2n@1688.com', 'Male', '2003-10-02');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (97, '2379816697', 'Virginia', 'MacAfee', 'vmacafee2o@go.com', 'Female', '1973-04-09');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (98, '4456303840', 'Dania', 'Drynan', 'ddrynan2p@quantcast.com', 'Male', '2014-12-05');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (99, '1271045494', 'Sybilla', 'Attrey', 'sattrey2q@ucsd.edu', 'Female', '2019-04-05');
insert into patients (row_id, patient_id, first_name, last_name, email, gender, dob) values (100, '7909668058', 'Emelyne', 'Drummer', 'edrummer2r@state.gov', 'Female', '1961-05-11');


-- Insert data to drugs table (100 rows)
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (1, '76214-044', 'GOOD AFTERNOON BERRY BERRY TEA BB', 2004, '2430477343', 'SKINFOOD CO., LTD.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (2, '36987-2722', 'Western Juniper', 1996, '7012317329', 'Nelco Laboratories, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (3, '63323-006', 'Sodium Bicarbonate', 2006, '3570594750', 'Fresenius Kabi USA, LLC');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (4, '0574-7036', 'aspirin', 1997, '7454352693', 'Paddock Laboratories, LLC');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (5, '0268-6109', 'BEEF', 1994, '4980283454', 'ALK-Abello, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (6, '54868-4062', 'Captopril and Hydrochlorothiazide', 2007, '5624952708', 'Physicians Total Care, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (7, '49348-307', 'Isopropyl Alcohol', 2001, '7217760828', 'Sunmark');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (8, '0093-7639', 'Temozolomide', 2012, '8821334759', 'Teva Pharmaceuticals USA Inc');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (9, '63824-722', 'Cepacol', 1992, '5384080418', 'Reckitt Benckiser LLC');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (10, '37000-477', 'Pepto-Bismol', 1960, '6826322722', 'Procter & Gamble Manufacturing Company');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (11, '47219-202', 'NYLOXIN', 2009, '6070580877', 'RECEPTOPHARM INC');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (12, '16590-055', 'CITALOPRAM HYDROBROMIDE', 1993, '9470877756', 'Stat Rx USA');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (13, '68703-084', 'HayFever Fighter', 2007, '1859320376', 'Native Remedies, LLC');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (14, '11523-0461', 'Coppertone Sport', 1994, '9575986695', 'MSD Consumer Care, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (15, '0143-9689', 'Nicardipine Hydrochloride', 2002, '2295304970', 'West-ward Pharmaceutical Corp');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (16, '54868-3314', 'Cimetidine', 2000, '9150153757', 'Physicians Total Care, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (17, '11559-737', 'TIME ZONE', 1997, '9624178895', 'ESTEE LAUDER INC');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (18, '64942-1117', 'Dove Clinical Protection Cool Essentials', 1992, '8577086089', 'Conopco Inc. d/b/a Unilever');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (19, '51224-151', 'Ursodiol', 1998, '2612023364', 'TAGI Pharma, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (20, '55154-7453', 'Propylthiouracil', 1992, '0681930837', 'Cardinal Health');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (21, '54305-221', 'MENTHOL FRESH COUGH SUPPRESSANT', 1997, '6511180581', 'Ricola Ag');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (22, '16714-401', 'Cefuroxime Axetil', 2009, '6014262520', 'NorthStar Rx LLC');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (23, '63323-401', 'Aztreonam', 1993, '0975850199', 'Fresenius Kabi USA, LLC');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (24, '65044-6694', 'Standardized Mite, Dermatophagoides pteronyssinus, Intradermal, 300 AU per mL', 2004, '5442559946', 'Jubilant HollisterStier LLC');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (25, '36987-1908', 'Botrytis cinerea', 2002, '5719217126', 'Nelco Laboratories, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (26, '0078-0500', 'Lamisil', 2007, '4527858866', 'Novartis Pharmaceuticals Corporation');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (27, '0363-0282', 'Wal Hist', 2000, '7886026314', 'Walgreen Company');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (28, '51079-899', 'Verapamil Hydrochloride', 2002, '5078845070', 'Mylan Institutional Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (29, '41250-099', 'meijer', 2012, '0030697808', 'Meijer Distribution Inc');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (30, '53329-207', 'Epi-Clenz Instant Hand Antiseptic', 1969, '6710795977', 'Medline Industries, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (31, '64997-300', 'kids cough', 1991, '4682418025', 'KEYSUN PTY. LIMITED Also Traded as KEYSUN LABORATORIES');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (32, '37000-327', 'Head and Shoulders 2in1', 2010, '6969605876', 'Procter & Gamble Manufacturing Co.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (33, '41190-648', 'shoprite nasal four', 1995, '4560722439', 'Wakefern Food Corporation');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (34, '55154-5091', 'Diltiazem Hydrochloride', 1990, '9440306424', 'Cardinal Health');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (35, '10893-892', 'Naturasil', 2010, '7895429868', 'Nature''s Innovation, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (36, '41163-462', 'equaline allergy', 2010, '9641432966', 'Supervalu Inc');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (37, '51444-001', 'Cold Rub', 2002, '2931191450', 'JMD All Star Impex Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (38, '50021-061', 'SUNZONE KIDS SPF 60', 1994, '9110518681', 'Empack Spraytech Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (39, '60429-509', 'HYDROCODONE BITARTRATE AND ACETAMINOPHEN', 1988, '0105605786', 'Golden State Medical Supply, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (40, '60631-412', 'Edarbyclor', 1997, '3637222752', 'Arbor Pharmaceuticals Ireland Limited');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (41, '0135-0456', 'TUMS', 2010, '2721727435', 'GlaxoSmithKline Consumer Heathcare LP');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (42, '58247-001', 'OXYGEN', 1993, '5719465022', 'Respitek Inc');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (43, '50436-7370', 'Famotidine', 1992, '7215403459', 'Unit Dose Services');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (44, '36987-2546', 'Black Birch', 2001, '3946097014', 'Nelco Laboratories, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (45, '49288-0842', 'Treatment Set TS345050', 1984, '9138672529', 'Antigen Laboratories, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (46, '59779-559', 'Allergy Relief', 2009, '9604356879', 'WOONSOCKET PRESCRIPTION CENTER,INCORPORATED');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (47, '36987-3157', 'Carelessweed', 2004, '4430004587', 'Nelco Laboratories, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (48, '49349-430', 'ISENTRESS', 2009, '2731163968', 'REMEDYREPACK INC.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (49, '13537-467', 'LBEL divine lip gloss SPF 15', 2010, '8774096915', 'Ventura Corporation LTD');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (50, '68016-450', 'Allergy Eye Drops', 1948, '2290910929', 'Premier Value');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (51, '55154-0355', 'Enalaprilat', 2005, '1571727620', 'Cardinal Health');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (52, '53346-1381', 'DR. RECKEWEG R81 Maldol', 2001, '8085819732', 'PHARMAZEUTISCHE FABRIK DR. RECKEWEG & CO');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (53, '45963-753', 'Glyburide (micronized) and Metformin Hydrochloride', 1992, '8523039988', 'Actavis Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (54, '42947-621', 'Povidone-Iodine', 2005, '0679683402', 'Wuxi Medical Instrument Factory');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (55, '43406-0040', 'PSORIASIS HP', 2005, '1692159054', 'Natural Creations, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (56, '0338-3991', 'IFEX', 2009, '4268861580', 'Baxter Healthcare Corporation');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (57, '10056-915', 'formu care omeprazole', 1995, '1579902642', 'Access Business Group LLC');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (58, '55154-1675', 'Metformin hydrochloride', 1998, '1313923664', 'Cardinal Health');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (59, '0869-0551', 'Medicated', 1985, '4961603287', 'Vi-Jon');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (60, '42248-115', 'Expression', 1998, '8889987944', 'Zenith Medicosm SL');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (61, '13537-299', 'LBEL NATURAL FINISH MOISTURIZING FOUNDATION SPF 25', 2011, '5605669737', 'Ventura Corporation LTD');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (62, '46122-198', 'good neighbor pharmacy night time', 1985, '2395799483', 'Amerisource Bergen');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (63, '0316-2045', 'Blue Lizard Sensitive Sunscreen', 2009, '7477729122', 'Crown Laboratories');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (64, '0615-6578', 'Amlodipine Besylate', 2006, '7077487180', 'NCS HealthCare of KY, Inc dba Vangard Labs');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (65, '68180-756', 'Amlodipine Besylate and Benazepril Hydrochloride', 1990, '3917861909', 'Lupin Pharmaceuticals, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (66, '67046-042', 'benztropine mesylate', 2005, '4847684516', 'Contract Pharmacy Services-PA');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (67, '51660-493', 'Ibuprofen and Pseudoephedrine hydrochloride', 1998, '7447480908', 'Ohm Laboratories Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (68, '41250-923', 'eye itch relief', 1990, '5242250380', 'Meijer Distribution Inc');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (69, '0003-4223', 'KOMBIGLYZE', 2006, '6774568300', 'E.R. Squibb & Sons, L.L.C.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (70, '55289-025', 'Erythromycin Base', 2008, '8646860612', 'PD-Rx Pharmaceuticals, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (71, '63459-416', 'GABITRIL', 2007, '2333707909', 'Cephalon, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (72, '67046-158', 'Enalapril Maleate', 2010, '2103992105', 'Contract Pharmacy Services-PA');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (73, '54569-5224', 'Phentermine Hydrochloride', 1995, '0786596589', 'A-S Medication Solutions LLC');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (74, '0009-0233', 'Bacitracin', 1989, '4252001048', 'Pharmacia and Upjohn Company');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (75, '0641-6021', 'Famotidine', 2013, '7212806501', 'West-ward Pharmaceutical Corp.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (76, '54868-4657', 'lisinopril', 2012, '9789291744', 'Physicians Total Care, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (77, '46122-013', 'GOOD NEIGHBOR PHARMACY DIAPER RASH CREAMY', 2004, '5239930333', 'AMERISOURCE BERGEN');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (78, '68084-411', 'Indomethacin', 2003, '4056100683', 'American Health Packaging');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (79, '49349-089', 'VENLAFAXINE HYDROCHLORIDE', 2011, '0026218658', 'REMEDYREPACK INC.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (80, '58980-336', 'Zencia Wash', 1992, '2499438738', 'Stratus Pharamceuticals, Inc');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (81, '10812-423', 'Neutrogena Ultra Sheer Dry Touch', 2004, '1886299862', 'Neutrogena Corporation');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (82, '0781-3164', 'Octreotide Acetate', 1985, '1819633136', 'Sandoz Inc');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (83, '57955-8197', 'Regional Allergies Northeastern US', 2009, '8092499489', 'King Bio Inc,');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (84, '64679-744', 'Fexofenadine', 1997, '0515455474', 'Wockhardt USA LLC.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (85, '64679-727', 'ONDANSETRON HYDROCHLORIDE', 1994, '3829258178', 'WOCKHARDT USA LLC');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (86, '22431-112', 'Acne Treatment Kit', 2010, '9269260410', 'Blue Cross Laboratories');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (87, '0264-3193', 'CEFEPIME HYDROCHLORIDE AND DEXTROSE', 1994, '7954768481', 'B. Braun Medical Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (88, '65841-764', 'Ranitidine Hydrochloride', 1993, '7567881888', 'Cadila Healthcare Limited');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (89, '0591-5454', 'Quinidine Sulfate', 2002, '4860945255', 'Watson Laboratories, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (90, '41163-450', 'Junior Acetaminophen', 2001, '3255780551', 'SUPERVALU INC.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (91, '66184-528', 'ck one all day perfection face makeup', 2012, '4571813317', 'Coty US LLC');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (92, '66129-430', 'Idole Beauty', 1999, '6042202286', 'International Beauty Exchange');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (93, '59351-0301', 'Rimmel London', 1994, '0373566042', 'Lancaster S.A.M.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (94, '54868-0064', 'Amitriptyline Hydrochloride', 2002, '2397653664', 'Physicians Total Care, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (95, '68258-3997', 'Mometasone Furoate', 2008, '6787224087', 'Dispensing Solutions, Inc.');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (96, '58411-143', 'CLE DE PEAU BEAUTE REFRESHING PROTECTIVE I', 1995, '1930795521', 'SHISEIDO AMERICAS CORPORATION');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (97, '52584-463', 'Nalbuphine Hydrochloride', 1993, '4590175401', 'General Injectables & Vaccines, Inc');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (98, '37000-403', 'Pepto-Bismol', 1985, '6963438455', 'Procter & Gamble Manufacturing Company');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (99, '49999-074', 'Piroxicam', 2005, '7434684615', 'Lake Erie Medical DBA Quality Care Products LLC');
insert into drugs (row_id, drug_id, drug_name, batch, manufacturer_id, manufacturer_name) values (100, '0363-0131', 'Wal-Zan 75', 2005, '6616550109', 'Walgreens Company');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO prescriptions (patient_id, drug_id, batch)
SELECT p.patient_id, d.drug_id, d.batch
FROM patients p, drugs d
TABLESAMPLE BERNOULLI(10);
	
--DROP TABLE prescriptions;
--DROP TABLE patients;
--DROP TABLE drugs;
--Student No.: A0047158B