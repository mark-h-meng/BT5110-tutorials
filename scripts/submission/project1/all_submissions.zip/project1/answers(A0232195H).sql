/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/

Student number: E0716338
/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
First Entity: Investor; Second entity: Stock; Relation: invests in
There are three tables. The first table is called "Investor". The attributes of this table includes their first and last name, gender, email, the university they graduated from, and the date they start investing
The second table is called "stock", which represents the second entity. The attributes of "stock" includes the name of the stock, stock cap and the return of this stock during the investment holding period
The third table is called "Investment", it is a bridge between the first and the second entity. It has attibutes such as investor's email, stock return and stock name
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table Investor (
	first_name VARCHAR(100) NOT NULL,
	last_name VARCHAR(100) NOT NULL,
	email VARCHAR(100) PRIMARY KEY NOT NULL,
	gender VARCHAR(100) NOT NULL,
	Education VARCHAR(100) NOT NULL,
	Since DATE NOT NULL);
	
create table Stock (
	Stock_Name VARCHAR(100) NOT NULL,
	Stock_Return DECIMAL(2,2) NOT NULL,
	Stock_MarketCap VARCHAR(100) NOT NULL,
    PRIMARY KEY (Stock_Name, Stock_Return));
	
create table Investment (
	email VARCHAR(100) REFERENCES Investor(email),
	Stock_Name VARCHAR(100),
	Stock_Return DECIMAL(2,2),
    PRIMARY KEY (email, Stock_Name, Stock_Return),
    FOREIGN KEY (Stock_Name, Stock_Return) REFERENCES Stock (Stock_Name, Stock_Return)
	ON UPDATE CASCADE ON DELETE CASCADE
	DEFERRABLE INITIALLY DEFERRED);
	
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Jed', 'McConnel', 'jmcconnel0@archive.org', 'Polygender', 'Ecole Nationale de l''Aviation Civile', '8/1/2011');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Daphna', 'Latch', 'dlatch1@purevolume.com', 'Female', 'Malone College', '3/25/2016');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Henry', 'Savidge', 'hsavidge2@sourceforge.net', 'Non-binary', 'The Queen''s University Belfast', '8/30/2020');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Bent', 'Mealham', 'bmealham3@dmoz.org', 'Genderfluid', 'Brno University of Technology', '12/8/2010');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Vi', 'Tams', 'vtams4@timesonline.co.uk', 'Male', 'Université Libre de Tunis', '12/1/2018');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Virgil', 'Enoksson', 'venoksson5@ebay.co.uk', 'Genderfluid', 'Unitomo Surabaya', '10/9/2011');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Ethelyn', 'Crop', 'ecrop6@tinypic.com', 'Polygender', 'Nova Scotia Agricultural College', '10/14/2020');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Marci', 'Balazs', 'mbalazs7@springer.com', 'Agender', 'Faculdade Integradas do Ceará', '3/19/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Sibbie', 'Badsworth', 'sbadsworth8@taobao.com', 'Polygender', 'Kathmandu University', '1/4/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Ashla', 'Cannings', 'acannings9@arizona.edu', 'Genderqueer', 'Dhaka University of Engineering and Technology', '4/18/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Dur', 'Rockcliffe', 'drockcliffea@barnesandnoble.com', 'Non-binary', 'Japanese Red Cross College of Nursing', '4/4/2012');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Jonas', 'Shatliffe', 'jshatliffeb@unesco.org', 'Non-binary', 'South West University Yucai College', '1/20/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Lynn', 'Tiddeman', 'ltiddemanc@mediafire.com', 'Agender', 'New Bulgarian University', '4/13/2021');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Ailina', 'Gutcher', 'agutcherd@dot.gov', 'Agender', 'Universidad del Istmo', '5/5/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Carma', 'Lampke', 'clampkee@woothemes.com', 'Bigender', 'St. Petersburg State Electrotechnical University', '7/6/2021');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Nichole', 'Whalebelly', 'nwhalebellyf@google.fr', 'Female', 'Ohio Dominican College', '9/28/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Ana', 'Hawkslee', 'ahawksleeg@google.fr', 'Female', 'Omar Al-Mukhtar University', '5/11/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Filberto', 'Alldridge', 'falldridgeh@macromedia.com', 'Polygender', 'Nizhny Novgorod State Academy of Medicine', '7/18/2011');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Kirby', 'Youles', 'kyoulesi@imgur.com', 'Male', 'Université de Marne la Vallée', '8/18/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Dolores', 'Burkett', 'dburkettj@rambler.ru', 'Genderfluid', 'Semera University', '9/17/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Rooney', 'Le Grand', 'rlegrandk@soup.io', 'Bigender', 'Universidad de Puerto Rico, Bayamon', '5/22/2018');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Feodor', 'Gennings', 'fgenningsl@wsj.com', 'Polygender', 'Kokand State Pedagogical Institute', '11/21/2011');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Abeu', 'Colliber', 'acolliberm@kickstarter.com', 'Genderfluid', 'Tuva State University', '2/17/2014');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Sibel', 'Annatt', 'sannattn@wikimedia.org', 'Agender', 'Kendall College', '6/20/2021');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Ives', 'Wallett', 'iwalletto@1688.com', 'Bigender', 'Technical University of Warsaw', '10/17/2017');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Fonsie', 'MacTrustam', 'fmactrustamp@google.pl', 'Female', 'Ecole Nationale Supérieure d''Ingénieurs en Mécanique et Energétique de Valenciennes', '1/7/2018');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Ebony', 'Breddy', 'ebreddyq@accuweather.com', 'Agender', 'John Wesley College', '5/19/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Murdoch', 'Buckle', 'mbuckler@discovery.com', 'Genderqueer', 'Sylhet International University', '10/7/2018');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Beryl', 'Broxap', 'bbroxaps@imageshack.us', 'Non-binary', 'Swami Ramanand Teerth Marathwada University', '9/5/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Stella', 'Sibille', 'ssibillet@telegraph.co.uk', 'Non-binary', 'Wilberforce University', '1/24/2016');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Wanda', 'Lovatt', 'wlovattu@house.gov', 'Genderqueer', 'University of Kurdistan - Hawler', '12/3/2020');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Nertie', 'Hawson', 'nhawsonv@netscape.com', 'Male', 'Ho Chi Minh City University of Transport', '8/23/2017');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Holly-anne', 'Cowie', 'hcowiew@mediafire.com', 'Polygender', 'Urmia University of Medical Sciences', '9/13/2011');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Zonda', 'Mangeon', 'zmangeonx@tripod.com', 'Genderqueer', 'Michael Okpara University of Agriculture', '11/13/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Lenard', 'Cordeux', 'lcordeuxy@businesswire.com', 'Polygender', 'Colby College', '1/2/2020');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Winfred', 'O''Gavin', 'wogavinz@com.com', 'Agender', 'University of North Texas', '12/3/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Cammie', 'Skydall', 'cskydall10@about.com', 'Bigender', 'Universitas Kristen Satya Wacana', '5/20/2018');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Midge', 'Durkin', 'mdurkin11@amazon.com', 'Male', 'NHTV Breda University of Professional Education', '9/1/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Blinnie', 'Leatham', 'bleatham12@forbes.com', 'Agender', 'Fuji University', '6/26/2018');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Marin', 'Simmonite', 'msimmonite13@ihg.com', 'Female', 'Universität Linz', '4/11/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Gertrud', 'Worledge', 'gworledge14@admin.ch', 'Genderfluid', 'Marian College', '2/11/2021');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Merna', 'Petronis', 'mpetronis15@noaa.gov', 'Female', 'Mount Carmel College of Nursing', '1/4/2016');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Keelia', 'Pitts', 'kpitts16@umn.edu', 'Male', 'Universidad Nacional del Callao', '9/27/2018');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Nicolea', 'Toman', 'ntoman17@g.co', 'Bigender', 'Popakademie Baden-Württemberg', '9/30/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Marietta', 'Dabel', 'mdabel18@uiuc.edu', 'Female', 'Loyola College in Maryland', '8/22/2017');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Mill', 'Carss', 'mcarss19@howstuffworks.com', 'Genderfluid', 'Al Yarmouk University College', '6/26/2012');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Marys', 'Mullord', 'mmullord1a@arizona.edu', 'Polygender', 'Baitulmal Management Institute (IPB)', '6/12/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Jacinda', 'Ife', 'jife1b@issuu.com', 'Male', 'Universität der Bundeswehr München', '9/21/2020');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Tamma', 'Corneck', 'tcorneck1c@dell.com', 'Agender', 'Qingdao University of Science and Technology', '8/14/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Lani', 'Piwell', 'lpiwell1d@upenn.edu', 'Male', 'Columbus University', '10/16/2016');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Dinny', 'Cockaday', 'dcockaday1e@tmall.com', 'Bigender', 'American Jewish University', '11/13/2010');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Scot', 'Rubinchik', 'srubinchik1f@wikimedia.org', 'Polygender', 'Al-Batterjee Medical College', '8/26/2012');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Colan', 'Gecke', 'cgecke1g@wix.com', 'Male', 'Framingham State College', '11/21/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Brok', 'Fulun', 'bfulun1h@yandex.ru', 'Female', 'Johnson Bible College', '7/21/2014');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Shepard', 'MacAllan', 'smacallan1i@redcross.org', 'Female', 'Kansas City Art Institute', '12/13/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Erwin', 'Mayhow', 'emayhow1j@com.com', 'Female', 'St. George''s University', '1/10/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Nance', 'Dulany', 'ndulany1k@uol.com.br', 'Bigender', 'Universidad Señor de Sipán', '12/16/2012');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Orlan', 'Pabelik', 'opabelik1l@oracle.com', 'Non-binary', 'Idaho State University', '7/24/2012');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Lottie', 'Cherrison', 'lcherrison1m@ted.com', 'Male', 'University of Ulster', '7/2/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Lawrence', 'Landrick', 'llandrick1n@tuttocitta.it', 'Genderqueer', 'Kaohsiung Medical College', '11/26/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Hymie', 'Timoney', 'htimoney1o@cbsnews.com', 'Polygender', 'National American University, Albuquerque', '2/20/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Dona', 'Sambell', 'dsambell1p@apache.org', 'Genderfluid', 'Kirchliche Hochschule Wuppertal', '4/29/2012');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Edd', 'Micheau', 'emicheau1q@constantcontact.com', 'Polygender', 'Jiangxi University of Traditional Chinese Medicine', '8/27/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Rochell', 'Pimbley', 'rpimbley1r@goo.ne.jp', 'Female', 'Southwest University of Finance and Economics', '11/8/2020');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Koralle', 'Gleed', 'kgleed1s@people.com.cn', 'Polygender', 'Universidad José Antonio Páez', '1/5/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Constantino', 'Hofner', 'chofner1t@baidu.com', 'Non-binary', 'Universidade Federal do ABC', '8/29/2011');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Nadeen', 'Tweedle', 'ntweedle1u@yandex.ru', 'Genderqueer', 'Colby College', '8/20/2021');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Codi', 'Celli', 'ccelli1v@ihg.com', 'Non-binary', 'Yokohama College of Commerce', '1/26/2016');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Freddy', 'Tincey', 'ftincey1w@mysql.com', 'Polygender', 'Krasnoyarsk State Technical University', '9/10/2014');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Gordan', 'Jelfs', 'gjelfs1x@sogou.com', 'Male', 'Federal University of Technology, Akure', '11/17/2012');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Pansy', 'MacSweeney', 'pmacsweeney1y@over-blog.com', 'Genderqueer', 'Wellesley College', '4/22/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Brigit', 'Mulliner', 'bmulliner1z@ask.com', 'Non-binary', 'Nigerian Turkish Nile University', '7/22/2017');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Wandis', 'Chaddock', 'wchaddock20@hugedomains.com', 'Bigender', 'Rostov State Medical University', '9/4/2014');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Mady', 'Ellard', 'mellard21@tinyurl.com', 'Male', 'State University of New York Upstate Medical University ', '6/23/2012');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Thibaud', 'Tant', 'ttant22@nydailynews.com', 'Non-binary', 'Siberian State Industrial University', '10/9/2016');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Johan', 'Simion', 'jsimion23@themeforest.net', 'Male', 'Bryn Mawr College', '9/26/2014');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Gwendolen', 'Batrim', 'gbatrim24@free.fr', 'Female', 'University of South Carolina - Sumter', '5/27/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Pippo', 'Woollam', 'pwoollam25@toplist.cz', 'Polygender', 'St. Petersburg State Conservatory', '8/9/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Yurik', 'Farens', 'yfarens26@chicagotribune.com', 'Bigender', 'National University of Lesotho', '6/2/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Owen', 'McCourtie', 'omccourtie27@bbb.org', 'Non-binary', 'Universidade do Porto', '2/23/2018');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Deva', 'Panons', 'dpanons28@desdev.cn', 'Female', 'Segi University College', '8/17/2016');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Reginauld', 'Camfield', 'rcamfield29@google.es', 'Genderqueer', 'Washington University in St. Louis', '7/28/2018');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Yvonne', 'Iamittii', 'yiamittii2a@fc2.com', 'Agender', ' Akanu Ibiam Federal Polytechnic, Unwana', '7/13/2012');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Elonore', 'Cambden', 'ecambden2b@jugem.jp', 'Genderqueer', 'Tufts University', '10/3/2010');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Emeline', 'Bollon', 'ebollon2c@imdb.com', 'Genderfluid', 'University of North Carolina at Charlotte', '3/14/2021');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Park', 'Bockman', 'pbockman2d@facebook.com', 'Genderfluid', 'Nanjing Forestry University', '12/27/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Lock', 'Tran', 'ltran2e@rediff.com', 'Polygender', 'University of Thessaly', '12/17/2010');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Calli', 'Cyster', 'ccyster2f@scientificamerican.com', 'Genderqueer', 'Mount St. Clare College', '5/28/2021');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Cathi', 'Canfer', 'ccanfer2g@themeforest.net', 'Male', 'Institute of Advanced Legal Studies, University of London', '1/18/2011');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Tana', 'Tunnick', 'ttunnick2h@google.nl', 'Female', 'Shahrekord University of Medical Sciences', '4/24/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Cirillo', 'Challener', 'cchallener2i@independent.co.uk', 'Genderfluid', 'Iwate Prefectural University', '2/20/2017');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Kristopher', 'Bahike', 'kbahike2j@berkeley.edu', 'Genderfluid', 'University of Science and Arts of Oklahoma', '3/13/2014');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Vinson', 'Longstaff', 'vlongstaff2k@wisc.edu', 'Non-binary', 'Melaka City Polytechnic', '3/18/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Dal', 'Hasley', 'dhasley2l@wired.com', 'Male', 'Guangdong Polytechnic Normal University', '3/28/2020');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Howey', 'Padefield', 'hpadefield2m@princeton.edu', 'Genderqueer', 'Indiana University - Southeast', '1/29/2011');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Hart', 'Jaszczak', 'hjaszczak2n@cnet.com', 'Agender', 'Islamic Azad University, Tehran South', '5/12/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Jedd', 'Tayler', 'jtayler2o@creativecommons.org', 'Male', 'Holy Family College', '10/5/2012');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Sullivan', 'Duffree', 'sduffree2p@zdnet.com', 'Non-binary', 'Odessa State Academy of Construction and Architecture', '7/5/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Rossy', 'Wadmore', 'rwadmore2q@indiatimes.com', 'Polygender', 'Southwest Baptist University', '7/25/2016');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Guthrey', 'Carah', 'gcarah2r@istockphoto.com', 'Agender', 'Higher School of University and Advanced Studies Pisa', '8/27/2010');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Stanton', 'Gilham', 'sgilham2s@indiatimes.com', 'Genderqueer', 'Chestnut Hill College', '4/6/2011');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Dar', 'Payton', 'dpayton2t@unc.edu', 'Polygender', 'Politécnico Grancolombiano - Institución Universitaria', '9/15/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Chery', 'Abyss', 'cabyss2u@bloglovin.com', 'Genderqueer', 'University of Great Falls', '7/15/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Ethelda', 'Penrose', 'epenrose2v@yahoo.com', 'Polygender', 'University of North Texas Health Science Center at Fort Worth', '11/30/2010');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Kellsie', 'Paulo', 'kpaulo2w@youtube.com', 'Genderfluid', 'Sul Ross State University', '3/31/2011');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Jordon', 'Inkles', 'jinkles2x@goo.ne.jp', 'Agender', 'Florida Metropolitan University, Fort Lauderdale College', '8/12/2021');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Inness', 'Browning', 'ibrowning2y@ebay.co.uk', 'Male', 'Technological Education Institute of Larissa', '4/2/2011');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Caryn', 'Pucker', 'cpucker2z@nydailynews.com', 'Male', 'Murni Nursing College', '7/17/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Armin', 'Coales', 'acoales30@prweb.com', 'Polygender', 'Danang College Of Technology', '9/5/2020');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Dedie', 'Cassin', 'dcassin31@earthlink.net', 'Male', 'Wenzhou Medical College', '12/23/2011');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Dominique', 'Benadette', 'dbenadette32@ibm.com', 'Female', 'National Taitung Teachers College', '6/3/2017');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Denice', 'Davidove', 'ddavidove33@ca.gov', 'Female', 'Fachhochschule Kempten, Hochschule für Technik und Wirtschaft', '2/10/2020');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Nobe', 'Brearley', 'nbrearley34@usatoday.com', 'Genderqueer', 'Fachhochschule Schwäbisch Hall, Hochschule für Gestaltung', '3/18/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Maridel', 'Cumming', 'mcumming35@bbc.co.uk', 'Male', 'Institut National de la Recherche Scientifique, Université du Québec', '6/17/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Colette', 'Chansonne', 'cchansonne36@usnews.com', 'Agender', 'University of Bihac', '10/18/2017');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Timothea', 'Babbidge', 'tbabbidge37@booking.com', 'Bigender', 'Ecole Supérieure des Sciences et Technologie de l''Ingénieur de Nancy', '9/30/2016');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Biron', 'Lutton', 'blutton38@quantcast.com', 'Polygender', 'Beijing Information Science and Technology University', '7/22/2012');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Allen', 'Bidnall', 'abidnall39@pcworld.com', 'Genderqueer', 'Universidad Ciencias Comerciales', '7/29/2021');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Hubey', 'Barwack', 'hbarwack3a@devhub.com', 'Bigender', 'Deutsche Sporthochschule Köln', '2/8/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Torre', 'Klimov', 'tklimov3b@tinyurl.com', 'Polygender', 'Pakistan Institute of Engineering and Applied Sciences (PIEAS)', '10/9/2010');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Gearalt', 'Dyer', 'gdyer3c@ovh.net', 'Agender', 'University of Northern Virginia', '12/28/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Jonell', 'Loggie', 'jloggie3d@berkeley.edu', 'Non-binary', 'Chestnut Hill College', '2/6/2021');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Gelya', 'Andreacci', 'gandreacci3e@fc2.com', 'Female', 'Ecole d''Ingénieurs en Informatique pour l''Industrie', '9/1/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Kittie', 'Menicomb', 'kmenicomb3f@cdc.gov', 'Genderqueer', 'Ecole Nationale de la Statistique et de l''Administration Economique', '8/13/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Raphael', 'McCutcheon', 'rmccutcheon3g@people.com.cn', 'Male', 'Korea Maritime University', '5/9/2021');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Bear', 'Glazyer', 'bglazyer3h@oaic.gov.au', 'Polygender', 'Methodist College', '8/23/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Kaylyn', 'Bellchamber', 'kbellchamber3i@youtube.com', 'Agender', 'Universidad Itaca', '9/15/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Devina', 'Rilton', 'drilton3j@bing.com', 'Agender', 'Asian Management Institute', '11/29/2012');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Mikkel', 'Whitmarsh', 'mwhitmarsh3k@whitehouse.gov', 'Non-binary', 'Universidad Miguel de Cervantes', '7/26/2016');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Gladi', 'Wiffill', 'gwiffill3l@nsw.gov.au', 'Female', 'Antioch New England Graduate School', '10/3/2010');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Sue', 'Rosberg', 'srosberg3m@un.org', 'Agender', 'Yamagata University', '9/28/2011');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Meghann', 'Jenkinson', 'mjenkinson3n@ft.com', 'Agender', 'Detroit College of Business - Flint', '3/25/2014');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Brand', 'Moyles', 'bmoyles3o@wikia.com', 'Polygender', 'Qurtuba University of Science and Infromation Technology', '9/17/2014');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Ray', 'Bantock', 'rbantock3p@360.cn', 'Genderqueer', 'Universidad de Ciencias Aplicadas y Ambientales (UDCA)', '9/21/2020');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Daisy', 'Kilmister', 'dkilmister3q@chicagotribune.com', 'Male', 'Kwame Nkrumah University of Science and Technology', '7/8/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Gunner', 'Koenraad', 'gkoenraad3r@vimeo.com', 'Bigender', 'Universidad Pedagógica y Tecnológica de Colombia', '2/11/2020');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Karim', 'Yesinin', 'kyesinin3s@toplist.cz', 'Agender', 'University of Jaffna', '3/30/2021');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Cynthia', 'Kettle', 'ckettle3t@redcross.org', 'Polygender', 'Pacific Graduate School of Psychology', '12/27/2014');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Candide', 'Clinton', 'cclinton3u@dot.gov', 'Non-binary', 'Necmettin Erbakan University', '3/26/2017');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Aguie', 'Treleven', 'atreleven3v@goodreads.com', 'Male', 'Raghebe Esfahani University', '12/28/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Ianthe', 'Keoghan', 'ikeoghan3w@nsw.gov.au', 'Bigender', 'Clearwater Christian College', '2/23/2013');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Luise', 'Vyel', 'lvyel3x@gravatar.com', 'Genderqueer', 'University of Central Europe in Skalica', '9/30/2019');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Phylis', 'Inglesent', 'pinglesent3y@lycos.com', 'Agender', 'London School of Business & Finance', '6/20/2018');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Milo', 'Finnick', 'mfinnick3z@craigslist.org', 'Female', 'Universidad de Chiclayo', '6/14/2017');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Rafaelita', 'Cogdon', 'rcogdon40@businesswire.com', 'Male', 'Tabriz University', '3/23/2012');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Daphne', 'Birkwood', 'dbirkwood41@amazonaws.com', 'Agender', 'Universidade do Estado do Rio Grande do Norte', '3/6/2020');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Yul', 'Riding', 'yriding42@princeton.edu', 'Male', 'Universidad Metropolitana de Monterrey', '8/26/2012');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Wesley', 'Davydenko', 'wdavydenko43@unc.edu', 'Bigender', 'Universidad Latinoamericana de Ciencia y Tecnología', '5/18/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Bertha', 'Brassington', 'bbrassington44@state.gov', 'Non-binary', 'Institut Catholique de Paris', '6/6/2015');
insert into Investor (first_name, last_name, email, gender, Education, Since) values ('Mirabel', 'Vereker', 'mvereker45@google.co.uk', 'Genderfluid', 'Alfred Nobel University of Economics and Law ', '12/9/2018');




insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Onvia, Inc.', -0.03, '$30.65M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Civitas Solutions, Inc.', 0.44, '$636.19M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Clean Energy Fuels Corp.', 0.27, '$380.76M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('M.D.C. Holdings, Inc.', 0.51, '$1.77B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Airgain, Inc.', 0.66, '$136.04M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Iridium Communications Inc', 0.76, '$1.11B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Valhi, Inc.', -0.69, '$1.11B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('SeaWorld Entertainment, Inc.', -0.92, '$1.49B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Humana Inc.', 0.47, '$33.84B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Mastercard Incorporated', 0.93, '$135.24B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Sabra Healthcare REIT, Inc.', 0.26, '$146.63M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('First Financial Bancorp.', -0.95, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Innospec Inc.', 0.46, '$1.6B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Masimo Corporation', 0.02, '$4.69B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Alon USA Partners, LP', 0.71, '$669.59M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Lexicon Pharmaceuticals, Inc.', -0.67, '$1.77B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('OneBeacon Insurance Group, Ltd.', 0.08, '$1.72B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Gyrodyne , LLC', -0.38, '$30.84M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Kayne Anderson Acquisition Corp.', -0.15, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Erie Indemnity Company', 0.98, '$6.57B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Imax Corporation', 0.12, '$1.68B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Embotelladora Andina S.A.', 0.97, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Alpha and Omega Semiconductor Limited', 0.11, '$420.14M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Xunlei Limited', -0.55, '$219.73M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Mazor Robotics Ltd.', -0.13, '$811.57M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Regal Beloit Corporation', 0.1, '$3.65B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Cemex S.A.B. de C.V.', -0.65, '$4.5B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('SEI Investments Company', 0.46, '$8.61B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('PNC Financial Services Group, Inc. (The)', 0.43, '$59.28B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Level 3 Communications, Inc.', -0.86, '$22.42B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('USA Truck, Inc.', -0.54, '$55.33M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Kimco Realty Corporation', -0.1, '$7.87B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Pacific Special Acquisition Corp.', 0.46, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Capitol Acquisition Corp. III', -0.04, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('RMG Networks Holding Corporation', 0.69, '$28.99M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Maiden Holdings, Ltd.', -0.52, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Fairmount Santrol Holdings Inc.', 0.05, '$882.34M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('ServiceMaster Global Holdings, Inc.', 0.93, '$5.33B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Barington/Hilco Acquisition Corp.', -0.98, '$49.88M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Catalent, Inc.', 0.29, '$4.61B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Armstrong Flooring, Inc.', -0.25, '$504.86M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('SPS Commerce, Inc.', -0.2, '$1.04B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('EQT Corporation', 0.7, '$10.19B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Oncobiologics, Inc.', 0.57, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Newfield Exploration Company', -0.66, '$5.84B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Kindred Biosciences, Inc.', -0.57, '$165.5M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Calamos Global Total Return Fund', 0.3, '$111.57M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('OneMain Holdings, Inc.', 0.03, '$3.13B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Tortoise Energy Infrastructure Corporation', -0.92, '$1.41B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Anixter International Inc.', -0.54, '$2.61B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Vertex Energy, Inc', -0.11, '$32.79M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('GigaMedia Limited', 0.37, '$33.71M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Recro Pharma, Inc.', -0.04, '$120.19M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Lincoln National Corporation', -0.14, '$15.26B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Peoples Bancorp of North Carolina, Inc.', -0.15, '$175.04M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Dividend and Income Fund', -0.86, '$130.45M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Altisource Residential Corporation', -0.38, '$678.58M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('LaSalle Hotel Properties', -0.66, '$3.54B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Neustar, Inc.', -0.87, '$1.87B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('AmTrust Financial Services, Inc.', -0.06, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Costamare Inc.', -0.31, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('LG Display Co., Ltd.', 0.91, '$11.74B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('I.D. Systems, Inc.', 0.9, '$87.7M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('NASDAQ TEST STOCK', -0.7, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Kayne Anderson Acquisition Corp.', 0.63, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Kemper Corporation', 0.4, '$2.05B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('OneMain Holdings, Inc.', -0.48, '$3.13B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Atlas Financial Holdings, Inc.', -0.34, '$188.28M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Western Asset Municipal Defined Opportunity Trust Inc', -0.7, '$273.41M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('WisdomTree Barclays Negative Duration U.S. Aggregate Bond Fund', 0.02, '$12.99M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Enel Chile S.A.', 0.69, '$5.43B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('PulteGroup, Inc.', 0.18, '$7.58B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Imprimis Pharmaceuticals, Inc.', -0.5, '$60.4M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Real Goods Solar, Inc.', 0.48, '$6.14M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Steven Madden, Ltd.', 0.19, '$2.29B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Teekay Offshore Partners L.P.', 0.19, '$293.41M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Brunswick Corporation', -0.65, '$5.37B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Centennial Resource Development, Inc.', 0.55, '$3.63B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Trinity Industries, Inc.', -0.06, '$4.07B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Compania Cervecerias Unidas, S.A.', -0.65, '$4.88B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Pro-Dex, Inc.', 0.06, '$21.56M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Snyder''s-Lance, Inc.', -0.54, '$3.44B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Quarterhill Inc.', 0.56, '$175.49M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Juno Therapeutics, Inc.', -0.89, '$2.47B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Dupont Fabros Technology, Inc.', -0.84, '$4.93B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Inseego Corp.', -0.18, '$59.33M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Lifevantage Corporation', -0.35, '$56.08M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Alaska Air Group, Inc.', 0.93, '$10.97B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('The Kraft Heinz Company', -0.91, '$108.87B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Center Coast MLP & Infrastructure Fund', -0.17, '$218.49M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('ROBO Global Robotics and Automation Index ETF', -0.76, '$158.98M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Conduent Incorporated', -0.2, '$3.33B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Genetic Technologies Ltd', 0.22, '$12.31M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Stage Stores, Inc.', 0.76, '$66.96M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Fibria Celulose S.A.', 0.02, '$6.18B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Female Health Company (The)', 0.47, '$36.35M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Astrotech Corporation', -0.39, '$21.18M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Southern Company (The)', -0.42, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('RAIT Financial Trust', 0.1, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Pinnacle Entertainment, Inc.', 0.53, '$1.16B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('J P Morgan Chase & Co', -0.2, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Fiserv, Inc.', 0.41, '$26.47B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Gabelli Utility Trust (The)', -0.07, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Schnitzer Steel Industries, Inc.', -0.8, '$520.56M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('BlueStar TA-BIGITech Israel Technology ETF', 0.64, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Nuveen Ohio Quality Municipal Income Fund', 0.37, '$279.5M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Emmis Communications Corporation', 0.44, '$39.09M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Korea Equity Fund, Inc.', -0.14, '$93.02M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Solar Capital Ltd.', -0.22, '$920.44M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Nektar Therapeutics', -0.7, '$2.82B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Cedar Fair, L.P.', 0.28, '$3.97B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('ARC Document Solutions, Inc.', 0.26, '$196.39M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Spok Holdings, Inc.', 0.42, '$371.61M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Ardagh Group S.A.', -0.96, '$5.2B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('SPX FLOW, Inc.', 0.83, '$1.64B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Rosehill Resources Inc.', -0.36, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Voya Asia Pacific High Dividend Equity Income Fund', 0.71, '$126.72M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Wells Fargo & Company', -0.7, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Ares Management L.P.', 0.6, '$3.79B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Westrock Company', 0.43, '$14.44B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Kimco Realty Corporation', 0.05, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Greif Bros. Corporation', 0.98, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('SAP SE', -0.14, '$126.8B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('BOK Financial Corporation', -0.61, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Customers Bancorp, Inc', -0.03, '$875.28M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Foot Locker, Inc.', 0.75, '$6.83B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Blueknight Energy Partners L.P., L.L.C.', -0.25, '$259.46M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Concurrent Computer Corporation', 0.13, '$68.78M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Allstate Corporation (The)', 0.9, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('M B T Financial Corp', 0.29, '$229.8M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Liberty Media Corporation', -0.24, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Check-Cap Ltd.', 0.43, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Ascent Capital Group, Inc.', -0.19, '$183.57M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Huaneng Power International, Inc.', 0.01, '$11.05B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('China Fund, Inc. (The)', 0.13, '$284.89M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('NCI Building Systems, Inc.', -0.46, '$1.21B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Strayer Education, Inc.', 0.17, '$1.04B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Endocyte, Inc.', 0.94, '$64.56M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('First Trust Mid Cap Core AlphaDEX Fund', -0.13, '$699.62M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Covanta Holding Corporation', 0.55, '$1.87B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Streamline Health Solutions, Inc.', 0.51, '$21.44M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Five Star Senior Living Inc.', -0.86, '$79.99M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('VanEck Vectors Pharmaceutical ETF', -0.78, '$285.13M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Pieris Pharmaceuticals, Inc.', 0.34, '$184.33M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Shopify Inc.', -0.46, '$7.35B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Unilever PLC', 0.07, '$157.69B');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('QuinStreet, Inc.', 0.99, '$181.85M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Entergy Arkansas, Inc.', 0.7, 'n/a');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('Central Federal Corporation', -0.33, '$35.67M');
insert into Stock (Stock_Name, Stock_Return, Stock_MarketCap) values ('AU Optronics Corp', 0.3, '$3.9B');


Polulate the table:
SELECT *
From Investor;

SELECT *
From Stock;
/************************************************************************/
/*                                                                      */
/* Question 1.e   */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO Investment (email, Stock_Name, Stock_Return) Values(
'Select email from Investor
Order by RANDOM()
LIMIT 1',
'Select Stock_Name from Stock
Order by RANDOM()
LIMIT 1',
Select Stock_Return from Stock
Order by RANDOM()
LIMIT 1);
