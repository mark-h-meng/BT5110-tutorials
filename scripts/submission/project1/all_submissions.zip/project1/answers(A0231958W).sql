/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*

I am a data analyst at a global stock exchange platform company.

To have a better understanding of our clients' interests in U.S stocks,

I wanted to see which U.S stocks were invested in at what price by our clients

during the regular trading hours on the previous day.  

I prepared 3 tables: client, stock, invest

Table 1. client 
This table provides our clients' personal information.
(first name, last name, email, customer_id, country)

Table 2. stock
This table provides details on U.S stocks listed in NYSE and NASDAQ.
(stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap)

Table 3. invest
This table provides information on the list of our clients and the summary of their investments in U.S stocks on the previous day. 
(customer_id, stock_symbol, stock_price)

PostgreSQL is used to answer the questions below.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

CREATE TABLE client (
	first_name VARCHAR(64) NOT NULL,
	last_name VARCHAR(64) NOT NULL, 
	email VARCHAR(64) NOT NULL UNIQUE,
	customer_id VARCHAR(64) PRIMARY KEY,
	country VARCHAR(64) NOT NULL);

CREATE TABLE stock(
	stock_market varchar(64) NOT NULL,
	stock_sector VARCHAR(64) NOT NULL,
	stock_symbol VARCHAR(64) NOT NULL PRIMARY KEY,
	stock_name VARCHAR(64) NOT NULL,
	stock_market_cap VARCHAR(64) NOT NULL);
	
CREATE TABLE invest (
	customer_id VARCHAR(64) REFERENCES client(customer_id)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED,
	stock_symbol VARCHAR(64),
	stock_price VARCHAR(64),
	PRIMARY KEY(customer_id, stock_symbol, stock_price),
	FOREIGN KEY (stock_symbol) REFERENCES stock(stock_symbol)
		ON UPDATE CASCADE ON DELETE CASCADE
		DEFERRABLE INITIALLY DEFERRED);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Public Utilities', 'ENBL', 'Enable Midstream Partners, LP', '$6.43B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Technology', 'KFY', 'Korn/Ferry International', '$1.88B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Miscellaneous', 'HPJ', 'Highpower International Inc', '$61.17M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Transportation', 'TOPS', 'TOP Ships Inc.', '$392729.7');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Miscellaneous', 'CAJ', 'Canon, Inc.', '$38.48B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Capital Goods', 'MLI', 'Mueller Industries, Inc.', '$1.76B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Health Care', 'LPCN', 'Lipocine Inc.', '$74.57M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Health Care', 'BCR', 'C.R. Bard, Inc.', '$22.71B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Miscellaneous', 'LKSD', 'LSC Communications, Inc.', '$742.65M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Finance', 'OCN', 'Ocwen Financial Corporation', '$351.32M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Consumer Services', 'SMRT', 'Stein Mart, Inc.', '$82.39M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'EHTH', 'eHealth, Inc.', '$347.43M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'CATY', 'Cathay General Bancorp', '$3.1B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Health Care', 'REGN', 'Regeneron Pharmaceuticals, Inc.', '$48.88B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Health Care', 'TLGT', 'Teligent, Inc.', '$459.34M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Consumer Services', 'BYD', 'Boyd Gaming Corporation', '$2.85B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Consumer Services', 'FPO', 'First Potomac Realty Trust', '$654.69M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Public Utilities', 'PCG', 'Pacific Gas & Electric Co.', '$35.34B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Health Care', 'BPMC', 'Blueprint Medicines Corporation', '$1.56B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Capital Goods', 'NPK', 'National Presto Industries, Inc.', '$776.78M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Consumer Services', 'MCS', 'Marcus Corporation (The)', '$909.47M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Capital Goods', 'RGR', 'Sturm, Ruger & Company, Inc.', '$1.2B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Finance', 'BCH', 'Banco De Chile', '$12.86B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Consumer Services', 'DG', 'Dollar General Corporation', '$19.23B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Energy', 'BTU', 'Peabody Energy Corporation', '$2.28B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Consumer Non-Durables', 'DTEA', 'DAVIDsTEA Inc.', '$166.11M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'FSFG', 'First Savings Financial Group, Inc.', '$116.61M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Public Utilities', 'CHT', 'Chunghwa Telecom Co., Ltd.', '$27.64B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Consumer Services', 'AMZN', 'Amazon.com, Inc.', '$472.1B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Technology', 'JBL', 'Jabil Inc.', '$5.19B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'WSFS', 'WSFS Financial Corporation', '$1.45B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'EBTC', 'Enterprise Bancorp Inc', '$414.73M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'EAGL', 'Double Eagle Acquisition Corp.', '$628.13M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Health Care', 'CNMD', 'CONMED Corporation', '$1.42B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Consumer Services', 'ELS', 'Equity Lifestyle Properties, Inc.', '$7.49B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'SHBI', 'Shore Bancshares Inc', '$215.57M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Health Care', 'FMS', 'Fresenius Medical Care Corporation', '$30.33B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Technology', 'APTI', 'Apptio, Inc.', '$654.41M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Finance', 'FIG', 'Fortress Investment Group LLC', '$3.1B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'ACFC', 'Atlantic Coast Financial Corporation', '$119.14M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Consumer Non-Durables', 'CAL', 'Caleres, Inc.', '$1.15B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Consumer Services', 'MARK', 'Remark Holdings, Inc.', '$57.31M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'IBCP', 'Independent Bank Corporation', '$452.26M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Consumer Services', 'GMRE', 'Global Medical REIT Inc.', '$164.26M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Health Care', 'VKTX', 'Viking Therapeutics, Inc.', '$25.84M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Consumer Durables', 'CDXC', 'ChromaDex Corporation', '$153.95M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Public Utilities', 'VVC', 'Vectren Corporation', '$5.15B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Technology', 'TEAM', 'Atlassian Corporation Plc', '$7.84B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Health Care', 'MOH', 'Molina Healthcare Inc', '$3.92B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Consumer Services', 'DEA', 'Easterly Government Properties, Inc.', '$779.29M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Capital Goods', 'LNN', 'Lindsay Corporation', '$914.46M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Consumer Non-Durables', 'WVVI', 'Willamette Valley Vineyards, Inc.', '$40.16M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Energy', 'PLUG', 'Plug Power, Inc.', '$498.3M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Basic Industries', 'GLDD', 'Great Lakes Dredge & Dock Corporation', '$229.77M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Energy', 'CVI', 'CVR Energy Inc.', '$1.78B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Health Care', 'ALKS', 'Alkermes plc', '$8.75B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Consumer Services', 'HR', 'Healthcare Realty Trust Incorporated', '$4.14B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Transportation', 'PXS', 'Pyxis Tankers Inc.', '$26.87M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Finance', 'MFCB', 'MFC Bancorp Ltd.', '$101.56M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Finance', 'PZN', 'Pzena Investment Management Inc', '$637.26M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Health Care', 'WVE', 'WAVE Life Sciences Ltd.', '$582.07M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Public Utilities', 'OKS', 'ONEOK Partners, L.P.', '$14.31B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Energy', 'PDS', 'Precision Drilling Corporation', '$985.28M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Public Utilities', 'CALL', 'magicJack VocalTec Ltd', '$111.49M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Miscellaneous', 'MELI', 'MercadoLibre, Inc.', '$11.63B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Consumer Services', 'ISIG', 'Insignia Systems, Inc.', '$11.89M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Technology', 'OIIM', 'O2Micro International Limited', '$47.92M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Health Care', 'TFX', 'Teleflex Incorporated', '$9.03B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Consumer Non-Durables', 'MYE', 'Myers Industries, Inc.', '$551.95M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Basic Industries', 'MSB', 'Mesabi Trust', '$173.18M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Health Care', 'ALT', 'Altimmune, Inc.', '$2.44M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'EMCI', 'EMC Insurance Group Inc.', '$588.24M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Energy', 'NOV', 'National Oilwell Varco, Inc.', '$12.79B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Consumer Services', 'DLTR', 'Dollar Tree, Inc.', '$16.58B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Consumer Services', 'UONEK', 'Urban One, Inc. ', '$103.88M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Health Care', 'TGTX', 'TG Therapeutics, Inc.', '$741.2M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Basic Industries', 'AES', 'The AES Corporation', '$7.87B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Finance', 'SYF', 'Synchrony Financial', '$23.79B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Capital Goods', 'BRSS', 'Global Brass and Copper Holdings, Inc.', '$675.15M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'OXBR', 'Oxbridge Re Holdings Limited', '$34.73M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Consumer Services', 'SYX', 'Systemax Inc.', '$685.51M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Technology', 'TNC', 'Tennant Company', '$1.33B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Technology', 'WK', 'Workiva Inc.', '$788.23M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Technology', 'YUME', 'YuMe, Inc.', '$163.2M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Energy', 'MPC', 'Marathon Petroleum Corporation', '$27.89B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Capital Goods', 'MSON', 'MISONIX, Inc.', '$89.33M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Transportation', 'VLRS', 'Controladora Vuela Compania de Aviacion, S.A.B. de C.V.', '$1.44B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Public Utilities', 'FTR', 'Frontier Communications Corporation', '$1.64B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Consumer Services', 'NNN', 'National Retail Properties', '$5.87B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'HBNC', 'Horizon Bancorp (IN)', '$580.2M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Technology', 'INTU', 'Intuit Inc.', '$35.74B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Technology', 'SCKT', 'Socket Mobile, Inc.', '$22.85M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'FCFP', 'First Community Financial Partners, Inc.', '$234.26M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'PICO', 'PICO Holdings Inc.', '$386.6M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Technology', 'VRNT', 'Verint Systems Inc.', '$2.54B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Finance', 'PEBK', 'Peoples Bancorp of North Carolina, Inc.', '$175.04M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Health Care', 'MRK', 'Merck & Company, Inc.', '$172.23B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NYSE', 'Energy', 'ECA', 'Encana Corporation', '$8.55B');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Energy', 'EXXI', 'Energy XXI Gulf Coast, Inc.', '$774.83M');
INSERT INTO stock (stock_market, stock_sector, stock_symbol, stock_name, stock_market_cap) VALUES ('NASDAQ', 'Health Care', 'QDEL', 'Quidel Corporation', '$854.72M');
																				
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Elroy', 'Garfit', 'egarfit0@huffingtonpost.com', 'egarfit0', 'Indonesia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Any', 'Pidgin', 'apidgin1@taobao.com', 'apidgin1', 'Philippines');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Brenda', 'Tripney', 'btripney2@spotify.com', 'btripney2', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Amalee', 'Silverlock', 'asilverlock3@mozilla.com', 'asilverlock3', 'Indonesia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Carmen', 'Kirkhouse', 'ckirkhouse4@alexa.com', 'ckirkhouse4', 'Poland');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Timmie', 'Tackett', 'ttackett5@house.gov', 'ttackett5', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Kelly', 'Angeau', 'kangeau6@disqus.com', 'kangeau6', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Kirsteni', 'Sutliff', 'ksutliff7@scientificamerican.com', 'ksutliff7', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Dagny', 'Glaisner', 'dglaisner8@example.com', 'dglaisner8', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Laney', 'Vella', 'lvella9@cam.ac.uk', 'lvella9', 'Greece');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Penni', 'Clarycott', 'pclarycotta@wikispaces.com', 'pclarycotta', 'Argentina');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Homere', 'Cherrie', 'hcherrieb@businessweek.com', 'hcherrieb', 'France');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Latrina', 'Copcutt', 'lcopcuttc@sciencedirect.com', 'lcopcuttc', 'Japan');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Saw', 'Hrycek', 'shrycekd@msu.edu', 'shrycekd', 'Peru');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Rosalia', 'Fone', 'rfonee@google.ca', 'rfonee', 'Colombia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Tarah', 'Poor', 'tpoorf@jugem.jp', 'tpoorf', 'Czech Republic');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Linette', 'Jiricka', 'ljirickag@state.tx.us', 'ljirickag', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Timmy', 'Ollarenshaw', 'tollarenshawh@free.fr', 'tollarenshawh', 'Poland');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Noak', 'de Chastelain', 'ndechastelaini@telegraph.co.uk', 'ndechastelaini', 'Philippines');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Constancia', 'Minster', 'cminsterj@yolasite.com', 'cminsterj', 'Indonesia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Philippine', 'Mistry', 'pmistryk@furl.net', 'pmistryk', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Klarrisa', 'Benini', 'kbeninil@msu.edu', 'kbeninil', 'Ukraine');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Jed', 'Devereu', 'jdevereum@oracle.com', 'jdevereum', 'Saint Kitts and Nevis');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Sal', 'Davidove', 'sdavidoven@gravatar.com', 'sdavidoven', 'Brazil');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Tamqrah', 'Dooley', 'tdooleyo@google.it', 'tdooleyo', 'Sweden');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Fancie', 'Kemmer', 'fkemmerp@icq.com', 'fkemmerp', 'United States');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Cissy', 'Bannester', 'cbannesterq@umn.edu', 'cbannesterq', 'United States');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Obie', 'Liddiard', 'oliddiardr@wisc.edu', 'oliddiardr', 'Bulgaria');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Dona', 'Dupey', 'ddupeys@berkeley.edu', 'ddupeys', 'Democratic Republic of the Congo');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Rodger', 'Barbey', 'rbarbeyt@livejournal.com', 'rbarbeyt', 'Philippines');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Dyanne', 'Negro', 'dnegrou@google.es', 'dnegrou', 'United States');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Amby', 'Flaunier', 'aflaunierv@foxnews.com', 'aflaunierv', 'Japan');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Wenonah', 'Burnip', 'wburnipw@nymag.com', 'wburnipw', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Pammi', 'Chubb', 'pchubbx@t.co', 'pchubbx', 'Sweden');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Fabian', 'Haxley', 'fhaxleyy@newyorker.com', 'fhaxleyy', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Nessi', 'Golbourn', 'ngolbournz@xing.com', 'ngolbournz', 'New Zealand');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Cornie', 'Shama', 'cshama10@wired.com', 'cshama10', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Allx', 'Filipov', 'afilipov11@bbb.org', 'afilipov11', 'Sweden');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Serene', 'Chrisp', 'schrisp12@imdb.com', 'schrisp12', 'Malaysia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Ricky', 'Goff', 'rgoff13@trellian.com', 'rgoff13', 'Indonesia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Gillan', 'Yarham', 'gyarham14@cnet.com', 'gyarham14', 'Papua New Guinea');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Miguela', 'Witchard', 'mwitchard15@exblog.jp', 'mwitchard15', 'Palestinian Territory');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Nichole', 'Beeho', 'nbeeho16@tuttocitta.it', 'nbeeho16', 'Indonesia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Colet', 'Pressland', 'cpressland17@harvard.edu', 'cpressland17', 'Brazil');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Asia', 'Orable', 'aorable18@adobe.com', 'aorable18', 'Ecuador');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Beverlie', 'Littrell', 'blittrell19@whitehouse.gov', 'blittrell19', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Lucas', 'Kinleyside', 'lkinleyside1a@newyorker.com', 'lkinleyside1a', 'Ecuador');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Doralin', 'Krugmann', 'dkrugmann1b@epa.gov', 'dkrugmann1b', 'Russia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Richie', 'Sandars', 'rsandars1c@go.com', 'rsandars1c', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Murry', 'Gammill', 'mgammill1d@fda.gov', 'mgammill1d', 'Sudan');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Gaspar', 'Dumbreck', 'gdumbreck1e@wired.com', 'gdumbreck1e', 'Portugal');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Geralda', 'Piscotti', 'gpiscotti1f@godaddy.com', 'gpiscotti1f', 'Sweden');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Ransom', 'Linsay', 'rlinsay1g@amazon.de', 'rlinsay1g', 'Bangladesh');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Rob', 'Simonassi', 'rsimonassi1h@ameblo.jp', 'rsimonassi1h', 'Brazil');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Waylen', 'Shier', 'wshier1i@si.edu', 'wshier1i', 'Peru');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Karl', 'Fiddiman', 'kfiddiman1j@360.cn', 'kfiddiman1j', 'Portugal');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Ilario', 'Diggin', 'idiggin1k@marriott.com', 'idiggin1k', 'Azerbaijan');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Allina', 'Kinzett', 'akinzett1l@usatoday.com', 'akinzett1l', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Christie', 'Hassall', 'chassall1m@accuweather.com', 'chassall1m', 'Russia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Pancho', 'Venediktov', 'pvenediktov1n@nydailynews.com', 'pvenediktov1n', 'Philippines');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Nickolas', 'Miquelet', 'nmiquelet1o@howstuffworks.com', 'nmiquelet1o', 'Indonesia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Vin', 'Skirling', 'vskirling1p@gmpg.org', 'vskirling1p', 'Russia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Vonny', 'Leuren', 'vleuren1q@github.io', 'vleuren1q', 'Tanzania');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Rem', 'Malkie', 'rmalkie1r@sina.com.cn', 'rmalkie1r', 'Croatia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Armand', 'Edland', 'aedland1s@patch.com', 'aedland1s', 'Philippines');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Karalynn', 'Pierce', 'kpierce1t@google.es', 'kpierce1t', 'United States');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Addy', 'Pixton', 'apixton1u@nytimes.com', 'apixton1u', 'Portugal');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Randene', 'Bettleson', 'rbettleson1v@weebly.com', 'rbettleson1v', 'Russia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Dody', 'O"Leary', 'doleary1w@sogou.com', 'doleary1w', 'Greece');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Harli', 'Wohler', 'hwohler1x@google.co.jp', 'hwohler1x', 'Ireland');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Gian', 'Bogeys', 'gbogeys1y@freewebs.com', 'gbogeys1y', 'Mexico');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Neall', 'Kubin', 'nkubin1z@msu.edu', 'nkubin1z', 'Indonesia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Freeman', 'Askem', 'faskem20@howstuffworks.com', 'faskem20', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Sileas', 'Charge', 'scharge21@cbc.ca', 'scharge21', 'Indonesia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Lewiss', 'Wiley', 'lwiley22@columbia.edu', 'lwiley22', 'Pakistan');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Aimee', 'Lightoller', 'alightoller23@topsy.com', 'alightoller23', 'Russia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Hermine', 'Compford', 'hcompford24@cafepress.com', 'hcompford24', 'Sweden');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Mercy', 'Magwood', 'mmagwood25@ameblo.jp', 'mmagwood25', 'Gabon');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Jules', 'Nucci', 'jnucci26@bloglovin.com', 'jnucci26', 'Portugal');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Cart', 'Cleft', 'ccleft27@omniture.com', 'ccleft27', 'Indonesia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Gaynor', 'Iglesias', 'giglesias28@soup.io', 'giglesias28', 'Mexico');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Karlyn', 'Debell', 'kdebell29@marriott.com', 'kdebell29', 'Sweden');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Moses', 'Isgar', 'misgar2a@springer.com', 'misgar2a', 'France');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Magdalena', 'Saby', 'msaby2b@vimeo.com', 'msaby2b', 'Portugal');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Nina', 'Domotor', 'ndomotor2c@go.com', 'ndomotor2c', 'United States');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Tori', 'Lawford', 'tlawford2d@nih.gov', 'tlawford2d', 'Poland');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Alejandro', 'Soro', 'asoro2e@qq.com', 'asoro2e', 'Argentina');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Adrianne', 'Bergin', 'abergin2f@i2i.jp', 'abergin2f', 'Poland');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Robena', 'Flowers', 'rflowers2g@123-reg.co.uk', 'rflowers2g', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Thibaud', 'Harbisher', 'tharbisher2h@yale.edu', 'tharbisher2h', 'Philippines');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Miranda', 'Tzuker', 'mtzuker2i@1688.com', 'mtzuker2i', 'Czech Republic');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Luigi', 'Kynaston', 'lkynaston2j@qq.com', 'lkynaston2j', 'Slovenia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Andria', 'Pirt', 'apirt2k@umn.edu', 'apirt2k', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Cesar', 'Merigon', 'cmerigon2l@princeton.edu', 'cmerigon2l', 'Peru');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Gregorius', 'Seebright', 'gseebright2m@amazon.co.uk', 'gseebright2m', 'Peru');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Armando', 'Le Barr', 'alebarr2n@prnewswire.com', 'alebarr2n', 'United States');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Trudey', 'Nathon', 'tnathon2o@printfriendly.com', 'tnathon2o', 'Slovenia');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Layney', 'Woloschin', 'lwoloschin2p@blogspot.com', 'lwoloschin2p', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Robinette', 'Simner', 'rsimner2q@networksolutions.com', 'rsimner2q', 'China');
INSERT INTO client (first_name, last_name, email, customer_id, country) VALUES ('Mattie', 'Gannon', 'mgannon2r@bbb.org', 'mgannon2r', 'Denmark');


/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into invest(customer_id, stock_symbol, stock_price)
select *, round(CAST (random()*(500-10)+10 AS numeric), 2) as price from (
select client.customer_id, stock.stock_symbol 
from client, stock order by random() limit 1000
) data;
