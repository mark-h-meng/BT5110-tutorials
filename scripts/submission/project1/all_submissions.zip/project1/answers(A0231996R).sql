/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/* A0231996R ZHANG JIAJING                                              */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */

/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/* The first table 'resident' has 4 attributes: id, name, vaccination and test_result.
id is the primary key in this table, as an identifier of a unique resident.
name indicates the full name of a resident. 
For the vaccination attribute, True means Vaccinated, False means not Vaccinated.
test_result attribute showes the most recent covid-19 test result of a resident. True means Positive, False means Negative.

The second table 'locations' has 4 attributes: address, contact, lo and la.
address is the primary key in this table, as an identifier of a unique street address that the residence has visited.
contact is the phone number of that address to contact (if available).
la and lo respectively indicate the latitude and the longtitude of the street address.

The third table travel_history collects id information from the table resident
and shows the name, test_result, vaccination and address visited of the corresponding resident.
A foreign key constraint enforces referential integrity. (All foreign key constraints can be declared as table constraints.)
In this table, id and address as recorded in the travel_history table must respectively corresponding to 
an existing id (primary key) in the resident table and an existing address (primary key) in the locations table.

*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
create table resident (
	id VARCHAR(50) PRIMARY KEY,
	name VARCHAR(50),
	vaccination VARCHAR(50),
	test_result VARCHAR(50)
);

create table locations (
	address VARCHAR(50) PRIMARY KEY ,
	contact VARCHAR(50),
	lo VARCHAR(50),
	la VARCHAR(50)
);

create table travel_history (
	id VARCHAR(50) REFERENCES resident (id),
	name VARCHAR(50),
	test_result VARCHAR(50),
	vaccination VARCHAR(50),
	address VARCHAR(50),
	FOREIGN KEY (address) REFERENCES locations(address)
);

/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

insert into resident (id, name, vaccination, test_result) values ('10-0452207', 'Kat Kenna', true, false);
insert into resident (id, name, vaccination, test_result) values ('59-7874710', 'Doug Mitton', true, true);
insert into resident (id, name, vaccination, test_result) values ('77-2381540', 'Bran Humpatch', false, true);
insert into resident (id, name, vaccination, test_result) values ('22-6857838', 'Ashly Stovell', false, false);
insert into resident (id, name, vaccination, test_result) values ('47-8484053', 'Ashlin Ruprich', true, false);
insert into resident (id, name, vaccination, test_result) values ('68-1865034', 'Donelle Winspare', true, true);
insert into resident (id, name, vaccination, test_result) values ('96-9842104', 'Emmalyn Redborn', false, true);
insert into resident (id, name, vaccination, test_result) values ('21-2192263', 'Abbot Forrest', true, false);
insert into resident (id, name, vaccination, test_result) values ('17-3647166', 'Burtie Stuart', false, true);
insert into resident (id, name, vaccination, test_result) values ('20-0034315', 'Marten Roubert', true, false);
insert into resident (id, name, vaccination, test_result) values ('15-6932475', 'Alfons Aguirrezabala', true, false);
insert into resident (id, name, vaccination, test_result) values ('77-9612076', 'Benedick Chedzoy', true, true);
insert into resident (id, name, vaccination, test_result) values ('28-7419004', 'Lorne Jedrzejczak', false, false);
insert into resident (id, name, vaccination, test_result) values ('10-6864857', 'Helge Padfield', false, true);
insert into resident (id, name, vaccination, test_result) values ('96-6683341', 'Angelico Bachelar', false, false);
insert into resident (id, name, vaccination, test_result) values ('03-4031734', 'Lira Franke', false, false);
insert into resident (id, name, vaccination, test_result) values ('70-7309788', 'Alejoa Avard', true, true);
insert into resident (id, name, vaccination, test_result) values ('52-3274323', 'Eveleen Molan', false, true);
insert into resident (id, name, vaccination, test_result) values ('73-0030478', 'Alethea Budik', true, true);
insert into resident (id, name, vaccination, test_result) values ('35-2907751', 'Harley Arboin', false, true);
insert into resident (id, name, vaccination, test_result) values ('69-7103730', 'Arte Belfit', true, true);
insert into resident (id, name, vaccination, test_result) values ('85-9718674', 'Ermina Kennelly', false, false);
insert into resident (id, name, vaccination, test_result) values ('72-1636933', 'Priscilla Eacott', false, false);
insert into resident (id, name, vaccination, test_result) values ('16-2593627', 'Doria Vanyashin', false, false);
insert into resident (id, name, vaccination, test_result) values ('51-7984903', 'Mischa Gregh', false, false);
insert into resident (id, name, vaccination, test_result) values ('04-6542681', 'Opal Niesel', true, true);
insert into resident (id, name, vaccination, test_result) values ('94-6187490', 'Josy Gookey', true, true);
insert into resident (id, name, vaccination, test_result) values ('27-3927125', 'Lisetta Heggison', true, true);
insert into resident (id, name, vaccination, test_result) values ('45-0602179', 'Mead Fishley', false, true);
insert into resident (id, name, vaccination, test_result) values ('29-3829700', 'Bogey Rieger', false, true);
insert into resident (id, name, vaccination, test_result) values ('12-7422747', 'Abba Aizikov', true, false);
insert into resident (id, name, vaccination, test_result) values ('43-6465685', 'Tessie Robberts', false, false);
insert into resident (id, name, vaccination, test_result) values ('66-8046490', 'Shanon Brettor', true, false);
insert into resident (id, name, vaccination, test_result) values ('80-0369487', 'Dulcea Cohan', false, true);
insert into resident (id, name, vaccination, test_result) values ('68-0856927', 'Jillene Stanbro', false, true);
insert into resident (id, name, vaccination, test_result) values ('12-2293083', 'Matias Kiley', true, false);
insert into resident (id, name, vaccination, test_result) values ('74-6683523', 'Aline Oldman', false, true);
insert into resident (id, name, vaccination, test_result) values ('18-7794879', 'Jenna Oris', false, false);
insert into resident (id, name, vaccination, test_result) values ('29-6556912', 'Abigael Gentiry', true, true);
insert into resident (id, name, vaccination, test_result) values ('24-4243774', 'Arabele Hadlow', true, true);
insert into resident (id, name, vaccination, test_result) values ('23-3713535', 'Lira Neilly', true, false);
insert into resident (id, name, vaccination, test_result) values ('58-7738961', 'Ebenezer Niemetz', true, false);
insert into resident (id, name, vaccination, test_result) values ('21-7942012', 'Paige Hutton', false, true);
insert into resident (id, name, vaccination, test_result) values ('27-5510567', 'Belia Novak', true, true);
insert into resident (id, name, vaccination, test_result) values ('47-1161709', 'Rodie Benardette', true, false);
insert into resident (id, name, vaccination, test_result) values ('92-3914624', 'Maybelle Peoples', false, true);
insert into resident (id, name, vaccination, test_result) values ('56-7667474', 'Eveleen Lapidus', false, false);
insert into resident (id, name, vaccination, test_result) values ('78-2024783', 'Anitra Bilney', true, true);
insert into resident (id, name, vaccination, test_result) values ('59-7132084', 'Tasia Huffadine', true, true);
insert into resident (id, name, vaccination, test_result) values ('37-6565291', 'Earle Paur', false, false);
insert into resident (id, name, vaccination, test_result) values ('87-1078454', 'Filmore Lantiff', false, false);
insert into resident (id, name, vaccination, test_result) values ('18-9141156', 'Cacilia Riolfo', true, false);
insert into resident (id, name, vaccination, test_result) values ('51-8582879', 'Cross Lancley', true, false);
insert into resident (id, name, vaccination, test_result) values ('85-4789281', 'Amber Ronnay', true, false);
insert into resident (id, name, vaccination, test_result) values ('54-7887857', 'Dotty Fayer', false, true);
insert into resident (id, name, vaccination, test_result) values ('04-9499985', 'Winthrop Molyneux', false, true);
insert into resident (id, name, vaccination, test_result) values ('08-7172341', 'Abraham Dimond', true, true);
insert into resident (id, name, vaccination, test_result) values ('99-2331721', 'Leann Castiglioni', true, false);
insert into resident (id, name, vaccination, test_result) values ('27-0219048', 'Lelia Walker', true, false);
insert into resident (id, name, vaccination, test_result) values ('14-9659644', 'Gabbie Youens', true, false);
insert into resident (id, name, vaccination, test_result) values ('02-0072044', 'Torie Linde', true, false);
insert into resident (id, name, vaccination, test_result) values ('69-3898544', 'Westley Tarrier', true, true);
insert into resident (id, name, vaccination, test_result) values ('17-9615060', 'Bren Kachel', false, false);
insert into resident (id, name, vaccination, test_result) values ('85-1961680', 'Allard Bussey', false, true);
insert into resident (id, name, vaccination, test_result) values ('30-8951517', 'Caye Swepson', true, true);
insert into resident (id, name, vaccination, test_result) values ('51-4514789', 'Tisha Jurisic', false, false);
insert into resident (id, name, vaccination, test_result) values ('85-3454532', 'Patrizia Winterborne', false, true);
insert into resident (id, name, vaccination, test_result) values ('01-2611741', 'Saraann Bartkowiak', true, false);
insert into resident (id, name, vaccination, test_result) values ('47-8256146', 'Dennis Leneve', true, true);
insert into resident (id, name, vaccination, test_result) values ('78-3982075', 'Kenon Loveridge', true, false);
insert into resident (id, name, vaccination, test_result) values ('32-6431295', 'Ginger Samwyse', true, true);
insert into resident (id, name, vaccination, test_result) values ('51-2437137', 'Brandise Nangle', false, true);
insert into resident (id, name, vaccination, test_result) values ('20-5296441', 'Drona Lacase', true, true);
insert into resident (id, name, vaccination, test_result) values ('31-2340216', 'Oran Birch', false, false);
insert into resident (id, name, vaccination, test_result) values ('54-2936915', 'Cosette Foyston', true, true);
insert into resident (id, name, vaccination, test_result) values ('65-2890230', 'Dian Condon', true, true);
insert into resident (id, name, vaccination, test_result) values ('58-9358743', 'Tadeas Poli', true, false);
insert into resident (id, name, vaccination, test_result) values ('95-5442135', 'Tito Nials', false, false);
insert into resident (id, name, vaccination, test_result) values ('32-9767588', 'Rollins La Padula', false, false);
insert into resident (id, name, vaccination, test_result) values ('81-6126486', 'Mill Spraberry', false, true);
insert into resident (id, name, vaccination, test_result) values ('48-3712548', 'Patsy McEvilly', true, true);
insert into resident (id, name, vaccination, test_result) values ('31-8378591', 'Hope Biddell', false, false);
insert into resident (id, name, vaccination, test_result) values ('44-9432780', 'Lionello Lakenton', false, false);
insert into resident (id, name, vaccination, test_result) values ('60-2711654', 'Mimi Loffhead', true, false);
insert into resident (id, name, vaccination, test_result) values ('67-6907236', 'Rodolfo Hyam', true, true);
insert into resident (id, name, vaccination, test_result) values ('18-0257678', 'Hilary Pretti', true, false);
insert into resident (id, name, vaccination, test_result) values ('08-5580682', 'Yvon Rothman', true, false);
insert into resident (id, name, vaccination, test_result) values ('03-1032487', 'Abrahan Kiloh', false, false);
insert into resident (id, name, vaccination, test_result) values ('95-3399883', 'Cammy Devons', true, false);
insert into resident (id, name, vaccination, test_result) values ('47-5464370', 'Quentin Conningham', false, false);
insert into resident (id, name, vaccination, test_result) values ('38-7990288', 'Elijah Andreone', true, false);
insert into resident (id, name, vaccination, test_result) values ('18-4813903', 'Nichole Dresser', false, false);
insert into resident (id, name, vaccination, test_result) values ('91-2021312', 'Kinsley Beckett', true, true);
insert into resident (id, name, vaccination, test_result) values ('03-9889915', 'Leigh Delacour', true, false);
insert into resident (id, name, vaccination, test_result) values ('28-8783174', 'Zeke Klazenga', true, false);
insert into resident (id, name, vaccination, test_result) values ('47-4468659', 'Maddie Chesman', true, true);
insert into resident (id, name, vaccination, test_result) values ('20-6126496', 'Bebe Gocke', true, false);
insert into resident (id, name, vaccination, test_result) values ('10-6293387', 'Spense Jikovsky', true, true);
insert into resident (id, name, vaccination, test_result) values ('95-8916359', 'Basia Slainey', false, false);
insert into resident (id, name, vaccination, test_result) values ('78-1583485', 'Tonnie Ranyard', false, true);


insert into locations (address, contact, lo, la) values ('8909 Morningstar Place', null, 84.17916, 44.35542);
insert into locations (address, contact, lo, la) values ('7837 Mcbride Street', '822-568-5875', -42.5264409, -19.4746347);
insert into locations (address, contact, lo, la) values ('4 Fisk Alley', '602-318-5776', 109.326383, 28.138525);
insert into locations (address, contact, lo, la) values ('459 Darwin Avenue', '903-108-8477', -49.4984804, -2.2414892);
insert into locations (address, contact, lo, la) values ('8 Anhalt Hill', '476-328-1806', 16.2923097, 50.2294568);
insert into locations (address, contact, lo, la) values ('1176 High Crossing Center', '230-487-1297', 124.870243, 12.532252);
insert into locations (address, contact, lo, la) values ('2 Butterfield Place', null, 110.9387418, -7.4703872);
insert into locations (address, contact, lo, la) values ('645 Red Cloud Point', '503-207-6913', -9.2011356, 39.1168675);
insert into locations (address, contact, lo, la) values ('96050 Straubel Parkway', null, 105.7204476, 21.4981346);
insert into locations (address, contact, lo, la) values ('545 Emmet Terrace', '674-733-7620', -99.0806088, 19.3579802);
insert into locations (address, contact, lo, la) values ('8 Norway Maple Center', null, 26.9399664, 58.8484094);
insert into locations (address, contact, lo, la) values ('1 Del Mar Drive', null, 128.0462031, 46.9758047);
insert into locations (address, contact, lo, la) values ('57 Division Circle', '597-424-1169', 113.576677, 22.270978);
insert into locations (address, contact, lo, la) values ('90464 Kingsford Crossing', '947-640-4816', -48.1597946, -20.6974477);
insert into locations (address, contact, lo, la) values ('573 Harper Parkway', '684-938-9455', 114.758301, 27.859517);
insert into locations (address, contact, lo, la) values ('10 Parkside Lane', null, -93.3808756, 44.9863911);
insert into locations (address, contact, lo, la) values ('13228 Dovetail Pass', '503-229-8879', 46.0515529, -18.7679039);
insert into locations (address, contact, lo, la) values ('7 Bartelt Court', '447-469-7657', 2.8002946, 47.3591366);
insert into locations (address, contact, lo, la) values ('46 Eastlawn Terrace', '670-533-1617', 18.2763069, 6.5060695);
insert into locations (address, contact, lo, la) values ('228 Pine View Hill', '478-321-6343', 123.5082, -8.4478);
insert into locations (address, contact, lo, la) values ('3842 Dwight Place', '490-593-0118', 115.345484, 40.446264);
insert into locations (address, contact, lo, la) values ('6 Victoria Road', null, 17.2266796, 51.7157581);
insert into locations (address, contact, lo, la) values ('15000 Kim Plaza', null, 34.374358, 53.3249623);
insert into locations (address, contact, lo, la) values ('3 Amoth Junction', '647-111-9918', 103.575676, 37.515114);
insert into locations (address, contact, lo, la) values ('6 Namekagon Terrace', '671-317-0521', 31.3156748, 47.9114733);
insert into locations (address, contact, lo, la) values ('9272 Eagle Crest Court', null, -8.6041746, 39.7075592);
insert into locations (address, contact, lo, la) values ('12 Brickson Park Way', '585-203-8487', -0.1284654, 51.5142805);
insert into locations (address, contact, lo, la) values ('50809 Cascade Terrace', null, 111.212846, 28.374107);
insert into locations (address, contact, lo, la) values ('9134 Anniversary Pass', null, 106.457478, 27.145704);
insert into locations (address, contact, lo, la) values ('97 Walton Lane', null, 21.894173, 49.8501369);
insert into locations (address, contact, lo, la) values ('0 Lunder Hill', '730-217-5619', 111.885002, -6.898384);
insert into locations (address, contact, lo, la) values ('6042 Springview Way', '864-722-3718', -0.607106, 47.854132);
insert into locations (address, contact, lo, la) values ('3753 Superior Junction', null, 102.8112253, 22.3750231);
insert into locations (address, contact, lo, la) values ('71 Porter Lane', '673-974-2210', -46.914966, -22.6053393);
insert into locations (address, contact, lo, la) values ('16 Golf View Way', null, 121.0133007, 14.5346437);
insert into locations (address, contact, lo, la) values ('28 Bluejay Trail', '545-997-1831', 113.253787, 23.1456682);
insert into locations (address, contact, lo, la) values ('38225 Hallows Lane', '220-604-8381', 121.494708, 29.884053);
insert into locations (address, contact, lo, la) values ('8202 Morrow Hill', '827-601-5330', -58.8062726, -27.5093879);
insert into locations (address, contact, lo, la) values ('24 Summit Pass', '995-597-3424', -63.4286929, -18.0549287);
insert into locations (address, contact, lo, la) values ('42 Warrior Road', '809-436-1184', 107.6940475, -6.9211461);
insert into locations (address, contact, lo, la) values ('48644 Buhler Circle', '282-365-3452', -70.7375968, -33.8125656);
insert into locations (address, contact, lo, la) values ('40952 Pond Junction', null, 100.4284178, 13.7733179);
insert into locations (address, contact, lo, la) values ('678 Kennedy Avenue', '273-192-7176', 55.4194753, -4.6488523);
insert into locations (address, contact, lo, la) values ('798 Orin Trail', null, 119.065936, 26.512298);
insert into locations (address, contact, lo, la) values ('0 Morningstar Lane', '728-278-6770', 111.0631793, -6.612633);
insert into locations (address, contact, lo, la) values ('923 Rowland Circle', '153-788-5999', 47.195011, 14.42099);
insert into locations (address, contact, lo, la) values ('7933 Blaine Place', '819-241-8107', 103.4049445, 0.7697665);
insert into locations (address, contact, lo, la) values ('623 Everett Drive', '354-701-2884', -76.2754275, 18.0443274);
insert into locations (address, contact, lo, la) values ('4 Dottie Crossing', null, 114.491954, 38.238247);
insert into locations (address, contact, lo, la) values ('31 Roxbury Park', null, 20.7278613, 50.1644211);
insert into locations (address, contact, lo, la) values ('62124 Memorial Circle', '647-357-4867', 16.1641685, 49.9542636);
insert into locations (address, contact, lo, la) values ('491 Drewry Place', '662-267-0142', 116.3184614, 35.0633042);
insert into locations (address, contact, lo, la) values ('75451 Everett Crossing', '144-765-1282', 114.503413, 31.689906);
insert into locations (address, contact, lo, la) values ('80111 Red Cloud Terrace', '803-835-1242', 24.6447745, 48.5177572);
insert into locations (address, contact, lo, la) values ('26 Scofield Center', '690-740-7254', 15.4077563, 43.968465);
insert into locations (address, contact, lo, la) values ('26294 Bultman Circle', '829-190-9317', -73.5947459, -4.4864625);
insert into locations (address, contact, lo, la) values ('62598 Laurel Park', '352-506-2295', -117.636429, 33.9498503);
insert into locations (address, contact, lo, la) values ('80 Grayhawk Hill', null, 20.6475673, 44.874);
insert into locations (address, contact, lo, la) values ('47235 Oriole Point', '395-791-0022', 103.064018, 31.421061);
insert into locations (address, contact, lo, la) values ('9 Kings Drive', null, 125.6030836, 39.593883);
insert into locations (address, contact, lo, la) values ('3331 Pierstorff Plaza', '937-614-9317', 18.9605242, 53.8446847);
insert into locations (address, contact, lo, la) values ('0173 Straubel Parkway', '453-971-7456', -75.5509602, 9.442952);
insert into locations (address, contact, lo, la) values ('124 Harper Drive', null, -81.1278814, 22.5267186);
insert into locations (address, contact, lo, la) values ('090 Norway Maple Hill', null, 123.7433907, -8.2285121);
insert into locations (address, contact, lo, la) values ('7437 Susan Court', '535-323-3382', 43.8674076, 43.555139);
insert into locations (address, contact, lo, la) values ('613 Jenna Point', '453-452-3298', -38.965934, -12.6010371);
insert into locations (address, contact, lo, la) values ('1598 Arizona Place', '599-957-7301', -8.8714085, 39.8019855);
insert into locations (address, contact, lo, la) values ('0 Holmberg Lane', '950-563-2328', -60.7301511, 11.1869803);
insert into locations (address, contact, lo, la) values ('1326 Ludington Place', '239-975-2402', -68.1430029, 47.0163969);
insert into locations (address, contact, lo, la) values ('4 Eastwood Road', '356-150-7219', -60.3090948, -36.9072882);
insert into locations (address, contact, lo, la) values ('5049 Paget Road', '130-416-9968', 113.093384, 22.58405);
insert into locations (address, contact, lo, la) values ('8400 Loeprich Center', null, 122.526443, 40.63181);
insert into locations (address, contact, lo, la) values ('0097 Everett Point', null, 27.4673845, 5.6052635);
insert into locations (address, contact, lo, la) values ('761 Daystar Park', '816-586-4352', 113.3227193, 23.1497287);
insert into locations (address, contact, lo, la) values ('54955 Debs Lane', '177-334-3359', 7.7424053, 48.5271841);
insert into locations (address, contact, lo, la) values ('66 Dawn Crossing', '312-997-7113', 21.846991, 50.0113078);
insert into locations (address, contact, lo, la) values ('1 Kensington Place', '693-686-8939', 107.8954131, -7.2536471);
insert into locations (address, contact, lo, la) values ('49407 Schlimgen Park', '379-244-3305', 130.478187, 45.212088);
insert into locations (address, contact, lo, la) values ('2 Ryan Drive', '423-622-6212', 7.1215271, 51.4964248);
insert into locations (address, contact, lo, la) values ('96522 Tennessee Road', null, 26.6700737, -4.4238447);
insert into locations (address, contact, lo, la) values ('6493 Dawn Street', '396-653-7733', 46.3582371, 43.330734);
insert into locations (address, contact, lo, la) values ('5178 Lake View Drive', '707-199-8395', 39.1231459, 8.5870183);
insert into locations (address, contact, lo, la) values ('087 Arrowood Court', '704-452-7986', -73.363333, -13.527778);
insert into locations (address, contact, lo, la) values ('4 Washington Crossing', '592-165-8037', -81.9248, 45.97927);
insert into locations (address, contact, lo, la) values ('885 Hanson Plaza', '750-971-6301', 106.8329412, -6.3007596);
insert into locations (address, contact, lo, la) values ('8273 Bellgrove Parkway', null, 116.695522, 27.646686);
insert into locations (address, contact, lo, la) values ('9332 Kedzie Lane', '314-132-5112', -4.7497457, 41.6465777);
insert into locations (address, contact, lo, la) values ('59918 Coleman Road', '297-215-0479', 12.3750266, 4.6740235);
insert into locations (address, contact, lo, la) values ('03 Summer Ridge Junction', null, 122.486657, 37.16516);
insert into locations (address, contact, lo, la) values ('307 Northland Road', '914-332-7228', -63.8817832, -17.4013758);
insert into locations (address, contact, lo, la) values ('93 5th Pass', '558-535-7692', 35.8970453, 31.9018747);
insert into locations (address, contact, lo, la) values ('55874 Manufacturers Road', '145-803-2971', 123.5839983, -5.282644);
insert into locations (address, contact, lo, la) values ('8705 Texas Place', null, 101.642899, 2.100305);
insert into locations (address, contact, lo, la) values ('6 Mitchell Plaza', '638-553-2693', -77.6407258, -11.0216067);
insert into locations (address, contact, lo, la) values ('55 Derek Pass', '337-866-4336', -77.1197521, 20.3332172);
insert into locations (address, contact, lo, la) values ('1 Myrtle Lane', '448-630-7862', 111.308664, 41.186564);
insert into locations (address, contact, lo, la) values ('499 John Wall Road', '486-223-1472', 122.6579982, 11.0126649);
insert into locations (address, contact, lo, la) values ('8873 Hollow Ridge Crossing', '845-891-9629', 56.0925161, 57.8745672);
insert into locations (address, contact, lo, la) values ('98288 Lien Road', null, 109.540241, -7.3582578);
insert into locations (address, contact, lo, la) values ('65705 Gulseth Road', null, -8.1572713, 38.3884463);

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */

INSERT INTO travel_history
SELECT id,name, test_result, vaccination, address 
FROM resident
CROSS JOIN locations
ORDER BY random()
LIMIT 1000;
