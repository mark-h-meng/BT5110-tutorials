/************************************************************************/
/*                                                                      */
/* Project Generating Fake but Realistic Data                           */
/*                                                                      */
/************************************************************************/


/************************************************************************/
/*                                                                      */
/* Question 1.a                                                         */
/*                                                                      */
/************************************************************************/
/* Remove accordingly: */
/* The code is written for PostgreSQL */
/************************************************************************/
/*                                                                      */
/* Question 1.b                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in plain text in English below: */
/*
'Doctor' is chosen as entity set 1 (E1) and 'patient' is chosen as entity 
set 2 (E2). The relationship set, R, will be 'seen'. This project uses 
mock data from mockaroo to populate E1 and E2. E1 will consist of doctor's
data such as Medical Council Registration (MCR) number, first name, last 
name and  email. E2 consists of patient data such as name, ID, gender, 
contact number, consultation date and diagnosis. The primary key of E1 
will be MCR number and the primary key for E2 will be the composite of 
patient name and consultation date. The relationship table will be 
populated with the primary keys of E1 and E2 (mcr number, patient name,
consultation date) and serves to capture the data on when and who has seen
the patient.
*/
/************************************************************************/
/*                                                                      */
/* Question 1.c                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
DROP 
  TABLE IF EXISTS seen;
DROP 
  TABLE IF EXISTS doctor;
DROP 
  TABLE IF EXISTS patient;
CREATE TABLE doctor(
  mcr_no VARCHAR(7) PRIMARY KEY, 
  first_name VARCHAR(64) NOT NULL, 
  last_name VARCHAR(64) NOT NULL, 
  email VARCHAR(64) NOT NULL
);
CREATE TABLE patient(
  patient_name VARCHAR(64) NOT NULL, 
  patient_id VARCHAR(9), 
  gender VARCHAR(1) NOT NULL, 
  contact INTEGER NOT NULL, 
  consult_date DATE, 
  diagnosis VARCHAR(64), 
  PRIMARY KEY(patient_id, consult_date)
);
CREATE TABLE seen(
  mcr_no VARCHAR(7) REFERENCES doctor(mcr_no) 
	ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED, 
  patient_id VARCHAR(9), 
  consult_date DATE, 
  PRIMARY key (mcr_no, patient_id, consult_date), 
  FOREIGN key (patient_id, consult_date) 
	REFERENCES patient(patient_id, consult_date) 
	ON UPDATE CASCADE DEFERRABLE INITIALLY DEFERRED
);
/************************************************************************/
/*                                                                      */
/* Question 1.d                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
insert into doctor (mcr_no, first_name, last_name, email) values ('M05153O', 'Lynnea', 'Clew', 'lclew0@taobao.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M92729N', 'Allie', 'O''Corren', 'aocorren1@squarespace.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M26601V', 'Thorn', 'Lunge', 'tlunge2@examiner.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M62324T', 'Ailyn', 'Caccavari', 'acaccavari3@istockphoto.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M64720T', 'Fannie', 'Shelvey', 'fshelvey4@devhub.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M04902J', 'Esma', 'Toffel', 'etoffel5@miibeian.gov.cn');
insert into doctor (mcr_no, first_name, last_name, email) values ('M98158A', 'Aprilette', 'Beamish', 'abeamish6@vimeo.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M56369V', 'Alyss', 'Bradnum', 'abradnum7@sourceforge.net');
insert into doctor (mcr_no, first_name, last_name, email) values ('M58706B', 'Oby', 'Nuzzetti', 'onuzzetti8@va.gov');
insert into doctor (mcr_no, first_name, last_name, email) values ('M94196W', 'Sandro', 'Somersett', 'ssomersett9@berkeley.edu');
insert into doctor (mcr_no, first_name, last_name, email) values ('M94845B', 'Quintus', 'Huntington', 'qhuntingtona@mlb.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M35083B', 'Manya', 'Diviny', 'mdivinyb@kickstarter.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M28332Y', 'Annalise', 'Bearns', 'abearnsc@phoca.cz');
insert into doctor (mcr_no, first_name, last_name, email) values ('M00039P', 'Corinne', 'Hablot', 'chablotd@mediafire.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M23065W', 'Emily', 'Mayler', 'emaylere@altervista.org');
insert into doctor (mcr_no, first_name, last_name, email) values ('M87091Y', 'Ingar', 'Esland', 'ieslandf@icio.us');
insert into doctor (mcr_no, first_name, last_name, email) values ('M21918K', 'Clerkclaude', 'Berryann', 'cberryanng@fastcompany.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M61318J', 'Farley', 'Yuill', 'fyuillh@phoca.cz');
insert into doctor (mcr_no, first_name, last_name, email) values ('M24923U', 'Elladine', 'Dennison', 'edennisoni@amazon.co.jp');
insert into doctor (mcr_no, first_name, last_name, email) values ('M91413S', 'Alleyn', 'Duffett', 'aduffettj@digg.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M43425G', 'Jessika', 'Gregory', 'jgregoryk@studiopress.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M75749V', 'Evita', 'Corish', 'ecorishl@naver.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M13897F', 'Bartholomeus', 'Blanket', 'bblanketm@blog.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M06728L', 'Hattie', 'Edgeworth', 'hedgeworthn@freewebs.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M26386Y', 'Erina', 'England', 'eenglando@soup.io');
insert into doctor (mcr_no, first_name, last_name, email) values ('M02061B', 'Blithe', 'Dobbinson', 'bdobbinsonp@census.gov');
insert into doctor (mcr_no, first_name, last_name, email) values ('M64890U', 'Allie', 'Evitt', 'aevittq@reddit.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M88754H', 'Bonnee', 'MacCheyne', 'bmaccheyner@opera.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M46602N', 'Klaus', 'Fend', 'kfends@soup.io');
insert into doctor (mcr_no, first_name, last_name, email) values ('M14618L', 'Waite', 'Pennycook', 'wpennycookt@arstechnica.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M53347O', 'Burnaby', 'Forde', 'bfordeu@myspace.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M11207S', 'Sib', 'Doodney', 'sdoodneyv@army.mil');
insert into doctor (mcr_no, first_name, last_name, email) values ('M71581H', 'Bing', 'MacMenamie', 'bmacmenamiew@clickbank.net');
insert into doctor (mcr_no, first_name, last_name, email) values ('M08897N', 'Felicia', 'Sheepy', 'fsheepyx@imgur.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M89722K', 'Gun', 'Dixon', 'gdixony@fema.gov');
insert into doctor (mcr_no, first_name, last_name, email) values ('M81727F', 'Vernor', 'Lope', 'vlopez@army.mil');
insert into doctor (mcr_no, first_name, last_name, email) values ('M43843K', 'Ginnie', 'Schowenburg', 'gschowenburg10@intel.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M58698T', 'Hank', 'Capelow', 'hcapelow11@state.tx.us');
insert into doctor (mcr_no, first_name, last_name, email) values ('M56518Q', 'Elisha', 'Lillie', 'elillie12@tuttocitta.it');
insert into doctor (mcr_no, first_name, last_name, email) values ('M29467D', 'Maxy', 'Riall', 'mriall13@smugmug.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M32041U', 'Matt', 'Brownill', 'mbrownill14@last.fm');
insert into doctor (mcr_no, first_name, last_name, email) values ('M50301X', 'Jamal', 'Nunnerley', 'jnunnerley15@usa.gov');
insert into doctor (mcr_no, first_name, last_name, email) values ('M87738Q', 'Beverlie', 'Le Pruvost', 'blepruvost16@wix.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M07806N', 'Elka', 'Hartman', 'ehartman17@businesswire.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M02212C', 'Wendi', 'Drever', 'wdrever18@vkontakte.ru');
insert into doctor (mcr_no, first_name, last_name, email) values ('M81363C', 'Norean', 'Sparway', 'nsparway19@adobe.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M47424G', 'Elton', 'Clampe', 'eclampe1a@miibeian.gov.cn');
insert into doctor (mcr_no, first_name, last_name, email) values ('M20772A', 'Jerald', 'Mosey', 'jmosey1b@live.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M59364V', 'Fidole', 'Gurry', 'fgurry1c@woothemes.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M96634Z', 'Desirae', 'Bothbie', 'dbothbie1d@boston.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M95998F', 'Krisha', 'Sehorsch', 'ksehorsch1e@altervista.org');
insert into doctor (mcr_no, first_name, last_name, email) values ('M47182E', 'Puff', 'Bartles', 'pbartles1f@shareasale.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M92584U', 'Ezequiel', 'Gillimgham', 'egillimgham1g@prlog.org');
insert into doctor (mcr_no, first_name, last_name, email) values ('M44667F', 'Grove', 'Skade', 'gskade1h@google.nl');
insert into doctor (mcr_no, first_name, last_name, email) values ('M78946L', 'Adolpho', 'Gimblet', 'agimblet1i@prlog.org');
insert into doctor (mcr_no, first_name, last_name, email) values ('M46199N', 'Erasmus', 'Drewell', 'edrewell1j@stanford.edu');
insert into doctor (mcr_no, first_name, last_name, email) values ('M85299T', 'Shannah', 'Doudny', 'sdoudny1k@vistaprint.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M93029X', 'Roger', 'Isselee', 'risselee1l@addthis.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M17501L', 'Husain', 'Weepers', 'hweepers1m@ed.gov');
insert into doctor (mcr_no, first_name, last_name, email) values ('M70326Y', 'Kerrin', 'Hounsom', 'khounsom1n@ted.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M42345B', 'Zacharias', 'Gouch', 'zgouch1o@joomla.org');
insert into doctor (mcr_no, first_name, last_name, email) values ('M97113R', 'Jock', 'Longfoot', 'jlongfoot1p@over-blog.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M79579W', 'Ferne', 'Leisk', 'fleisk1q@sciencedaily.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M19971Y', 'Joni', 'Daville', 'jdaville1r@barnesandnoble.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M59978U', 'Iago', 'Lark', 'ilark1s@youku.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M72686D', 'Vlad', 'Paragreen', 'vparagreen1t@nasa.gov');
insert into doctor (mcr_no, first_name, last_name, email) values ('M21075Y', 'Arlan', 'Fishe', 'afishe1u@networkadvertising.org');
insert into doctor (mcr_no, first_name, last_name, email) values ('M43204Q', 'Marlo', 'Jakoubec', 'mjakoubec1v@pinterest.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M05870X', 'Demetri', 'Curner', 'dcurner1w@soup.io');
insert into doctor (mcr_no, first_name, last_name, email) values ('M83825N', 'Jecho', 'Punshon', 'jpunshon1x@flickr.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M33501H', 'Alfie', 'Castell', 'acastell1y@amazonaws.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M87732S', 'Keri', 'Cheer', 'kcheer1z@1688.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M23226O', 'Cristy', 'Jeannenet', 'cjeannenet20@blog.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M94394N', 'Kippar', 'Ratie', 'kratie21@adobe.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M96433D', 'Cloe', 'Tydd', 'ctydd22@csmonitor.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M53638M', 'Brok', 'Postin', 'bpostin23@cyberchimps.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M59168L', 'Alfie', 'Artist', 'aartist24@oracle.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M26057Z', 'Alard', 'Naseby', 'anaseby25@storify.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M72769J', 'Reidar', 'Meckiff', 'rmeckiff26@twitter.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M13096Q', 'Barth', 'Blease', 'bblease27@paginegialle.it');
insert into doctor (mcr_no, first_name, last_name, email) values ('M41967W', 'Shandra', 'Lesor', 'slesor28@yale.edu');
insert into doctor (mcr_no, first_name, last_name, email) values ('M75793P', 'Wylie', 'Vertigan', 'wvertigan29@archive.org');
insert into doctor (mcr_no, first_name, last_name, email) values ('M42342M', 'Scott', 'Conachy', 'sconachy2a@mapy.cz');
insert into doctor (mcr_no, first_name, last_name, email) values ('M64197B', 'Francyne', 'Choudhury', 'fchoudhury2b@facebook.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M79043F', 'Ophelie', 'Nabbs', 'onabbs2c@xinhuanet.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M14335C', 'Barry', 'Gohn', 'bgohn2d@archive.org');
insert into doctor (mcr_no, first_name, last_name, email) values ('M71686L', 'Elvira', 'McCree', 'emccree2e@bloomberg.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M15260Q', 'Cyndie', 'Shearstone', 'cshearstone2f@umn.edu');
insert into doctor (mcr_no, first_name, last_name, email) values ('M59664A', 'Brittaney', 'Ough', 'bough2g@wp.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M90416P', 'Mela', 'Sissens', 'msissens2h@51.la');
insert into doctor (mcr_no, first_name, last_name, email) values ('M05727T', 'Bancroft', 'Coomer', 'bcoomer2i@opera.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M13134B', 'Barbi', 'Seligson', 'bseligson2j@marriott.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M17804R', 'Marillin', 'Saylor', 'msaylor2k@paypal.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M77905V', 'Bianka', 'Sturges', 'bsturges2l@instagram.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M90101B', 'Guilbert', 'Bullier', 'gbullier2m@salon.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M00490G', 'Ollie', 'Gonnel', 'ogonnel2n@storify.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M16046B', 'Dilly', 'Verma', 'dverma2o@tripod.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M89195R', 'Leeland', 'Dreschler', 'ldreschler2p@hibu.com');
insert into doctor (mcr_no, first_name, last_name, email) values ('M41435A', 'Mikaela', 'Flewin', 'mflewin2q@yandex.ru');
insert into doctor (mcr_no, first_name, last_name, email) values ('M04910H', 'Lynnet', 'Negro', 'lnegro2r@blogger.com');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Dolli Videler', 'S7783941T', 'F', '95441033', '4/11/2020', 'Undeter pois-sol/liq NEC');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Ewell Lewing', 'S1034545V', 'M', '96179607', '30/12/2020', 'Cl skl fx NEC/br inj NEC');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Johann Szach', 'S2446110V', 'M', '97542957', '13/8/2021', 'Family hx-anemia');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Eddy Slyford', 'S5489533J', 'M', '90705703', '10/12/2020', 'Presenile depression');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Willem Mullin', 'S2739226L', 'M', '93397409', '11/12/2020', 'Injury axillary nerve');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Geraldine Bidgod', 'S1400851A', 'F', '92808980', '9/2/2021', 'Ben hy kid w cr kid I-IV');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Diena Shayes', 'S4409409K', 'F', '93683072', '17/5/2021', 'Fat embolism');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Marti Rohmer', 'S7618875C', 'F', '91030210', '28/3/2021', 'NB hypoxia');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Oliviero Boase', 'S9250695R', 'M', '94790776', '3/2/2021', 'Hmplg mgrn w ntrc wo st');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Daryl Leaming', 'S7418609B', 'F', '91371606', '7/8/2021', 'Injury ovarian vein');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Osborn Stiger', 'S8900552V', 'M', '95961209', '10/6/2021', 'Paratyphoid fever b');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Bernard Wynrahame', 'S0840961Z', 'M', '96060638', '25/10/2020', 'Plantar nerve lesion');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Sky Iliff', 'S1501255U', 'M', '90003656', '8/4/2021', 'Chr eustachian salping');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Lionel Stamp', 'S4262984S', 'M', '93422814', '17/10/2020', 'Buphthal w oth eye anom');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Nollie Edgerley', 'S0315789N', 'F', '98916200', '24/12/2020', 'Del-twins, 1 nb, 1 sb');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Colas Pavinese', 'S4400420R', 'M', '93119130', '28/11/2020', 'Physical restrain status');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Evey Pitrollo', 'S9920807Z', 'F', '97433339', '6/7/2021', 'Unil femoral hern w gang');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Kylie Matthew', 'S0237984W', 'F', '98804360', '7/8/2021', 'Premature menopause');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Valina Mattityahou', 'S0003206Z', 'F', '93925440', '18/5/2021', 'Juvenile neurosyph NEC');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Creigh Waterson', 'S2263311P', 'M', '90075170', '18/4/2021', 'Craniorachischisis');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Sid Fewster', 'S9906255I', 'M', '95175544', '3/10/2020', 'TB of organ NEC-oth test');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Mohandis Downey', 'S3448879I', 'M', '97078537', '12/3/2021', 'Cong heart anomaly NEC');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Marya Yantsurev', 'S4356140H', 'F', '91379370', '18/8/2021', 'Pyrexia in labor-deliver');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Layton Pyle', 'S4833104F', 'M', '93130652', '29/9/2020', 'Dystrophy of vulva NEC');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Joann Everill', 'S0506275U', 'F', '99043578', '13/5/2021', 'Accidnt-mech firearm/gun');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Clementia Eddis', 'S3163818W', 'F', '97172217', '19/12/2020', 'Heart disease NOS');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Merline Winfindale', 'S7507053O', 'F', '97828332', '8/9/2020', 'Ariboflavinosis');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Rene Obell', 'S5101527V', 'M', '95739486', '25/3/2021', 'Ac/subac endocardit NOS');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Maria Duffitt', 'S2830946Y', 'F', '95017076', '25/6/2021', 'Hi grde myelodys syn les');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Janelle Manueli', 'S0370249O', 'F', '98040109', '12/11/2020', 'Cl skl base fx-deep coma');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Janean Ragless', 'S6809732L', 'F', '90763718', '14/9/2020', 'Viral arthritis-ankle');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Eolande Doveston', 'S8721290C', 'F', '96154872', '9/3/2021', 'Amebiasis carrier');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Nikki Hawkslee', 'S6911376B', 'M', '98395799', '24/2/2021', 'Inf arthritis NOS-shlder');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Barbee Klawi', 'S3771111E', 'F', '98715532', '4/7/2021', 'Abnormal vulva-postpart');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Brittni Wolfe', 'S4901155C', 'F', '99006048', '29/9/2020', 'Osteomyelit NOS-forearm');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Eartha De Beauchamp', 'S1853365B', 'F', '91500957', '9/12/2020', 'Fracture calcaneus-close');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Jill Bushaway', 'S6534810K', 'F', '90737856', '14/12/2020', 'Benign neoplasm ovary');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Farris Cudde', 'S5649609T', 'M', '94398202', '27/3/2021', 'Inj cutan senso nerv/leg');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Juliane Fleischer', 'S3808968E', 'F', '90690215', '18/4/2021', 'Jumping rope');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Isabelita Rambadt', 'S4905837D', 'F', '95670643', '7/2/2021', 'Acc d/t snow blizzard');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Bourke Fish', 'S8622867A', 'M', '95015453', '7/9/2020', 'Cryst arthrop NEC-shlder');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Paolo Stearn', 'S0276388U', 'M', '95852211', '10/3/2021', 'Obs dfct ren plv&urt NOS');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Dewey Yockney', 'S2927484D', 'M', '99447809', '17/7/2021', 'Recurrent pterygium');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Weber Maltman', 'S9194874G', 'M', '92914675', '4/2/2021', 'Tetanus neonatorum');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Fanny Lightbown', 'S2984835F', 'F', '99185688', '14/3/2021', 'Malignant hyperthermia');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Nathanael Hulls', 'S7227504E', 'M', '91682530', '21/1/2021', 'BMI 45.0-49.9, adult');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Ebony Marklund', 'S0376066L', 'F', '92778436', '29/11/2020', 'T7-t12 fx-op/ant crd syn');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Lorie MacConnell', 'S2305916W', 'F', '90238382', '26/11/2020', 'Poliomyelitis contact');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Evan Leipnik', 'S1520995P', 'M', '94270733', '4/10/2020', 'Pilonidal cyst w abscess');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Ynes Rysom', 'S4433148G', 'F', '90567188', '6/8/2021', 'Burn NOS forearm');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Wallas Janiak', 'S4564651I', 'M', '98211208', '10/2/2021', 'Abdmnal mass lt lwr quad');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Fabien Housecroft', 'S0656136V', 'M', '96348519', '20/8/2021', 'Oth curr cond-antepartum');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Thedric Moohan', 'S2541354Y', 'M', '94898402', '6/1/2021', 'TB of bronchus-cult dx');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Trip Faloon', 'S3407046L', 'M', '91636314', '12/2/2021', 'Amputation toe-complicat');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Marion Sinnat', 'S2662480V', 'F', '94540550', '13/7/2021', 'Mal neo uterine isthmus');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Caesar Rosenfelt', 'S9378682V', 'M', '95440505', '6/9/2020', 'War inj:person IED');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Raina Chastand', 'S2234197Q', 'F', '95030252', '3/12/2020', 'Sexual function problem');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Norrie Gimson', 'S6498735S', 'M', '91476833', '19/5/2021', 'Defibrination syndrome');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Hadrian Von Welden', 'S4744957K', 'M', '91402946', '2/12/2020', 'One eye-total/oth-unknwn');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Onfroi Whyler', 'S7935730O', 'M', '90452503', '16/12/2020', 'Batter by spouse/partner');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Johan Conner', 'S5542058U', 'M', '95255416', '1/11/2020', 'Retinal hemorrhage');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Cesya Beretta', 'S0153829J', 'F', '93469671', '29/6/2021', 'TB pleurisy-histolog dx');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Orbadiah Kinnock', 'S4555114R', 'M', '99649618', '8/11/2020', 'Family dsrpt-foster care');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Dennison Dmtrovic', 'S0006606R', 'M', '93457747', '27/7/2021', 'Vertebral artery syndrom');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Thia Charnley', 'S3116311G', 'F', '95212625', '20/4/2021', 'Heat exhaustion NOS');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Gayle Lorryman', 'S5899773P', 'M', '95443572', '12/9/2020', 'Narclpsy w/o cat oth dis');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Reine Bestar', 'S9838206S', 'F', '90839242', '9/10/2020', 'Abn vestibular func stud');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Derrik Evetts', 'S6589606Q', 'M', '97569883', '3/11/2020', 'Retinal varices');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Bird Brammar', 'S9295800A', 'F', '97176926', '10/11/2020', 'Prim TB pleuris-oth test');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Irv Ismirnioglou', 'S6010712S', 'M', '95686503', '12/1/2021', 'TB of hip-oth test');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Malanie Crumpe', 'S5371794T', 'F', '93321270', '17/4/2021', 'Outlet contraction-deliv');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Lazar Whitsun', 'S8786102E', 'M', '90729574', '28/2/2021', 'Adv eff polio vaccine');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Margie Sollas', 'S3330537K', 'F', '98735485', '31/10/2020', 'Adv eff GI agent NEC');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Dimitry Vowells', 'S1444660Z', 'M', '93228833', '12/8/2021', 'Amniotic prob NEC-deliv');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Mathilde Crispe', 'S9112296X', 'F', '98628041', '19/12/2020', 'Mononeuritis leg NOS');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Eloisa Edmeads', 'S7191839Z', 'F', '92087194', '18/6/2021', 'Trichomoniasis NOS');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Hyacintha Mainwaring', 'S7508547W', 'F', '95474146', '13/2/2021', 'Rflx sym dystrph up limb');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Berton Wrigglesworth', 'S4700526N', 'M', '94452506', '28/5/2021', 'Opn cort contu-deep coma');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Orlando Pattemore', 'S5664665K', 'M', '98341590', '22/2/2021', 'Hered prog musc dystrphy');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Olenolin Linzey', 'S5055863U', 'M', '91985160', '7/1/2021', 'Joint dis NOS-oth jt');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Demetre Barkess', 'S9290153L', 'M', '96907892', '11/9/2020', 'Low bladder compliance');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Lottie Espinoza', 'S6946834S', 'F', '96281796', '19/2/2021', 'Pericardial disease NEC');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Daphna Szymanzyk', 'S0262359Q', 'F', '96759912', '1/8/2021', 'DMII renl nt st uncntrld');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Danielle Esplin', 'S7568567O', 'F', '97881464', '4/3/2021', 'Keratoconjunctivitis NOS');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Elsinore Gravestone', 'S7432468O', 'F', '90816491', '5/1/2021', 'Toxic effect strychnine');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Dane Le Prevost', 'S2960675S', 'M', '99158342', '16/10/2020', 'Anomaly dental arch NOS');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Dolf Gilli', 'S5587985D', 'M', '92033581', '16/11/2020', 'Disloca midcarpal-closed');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Benoit Dulinty', 'S9965063I', 'M', '97392243', '7/9/2020', 'Ab NOS w metab dis-comp');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Blane Heaysman', 'S3379782R', 'M', '90892406', '15/6/2021', 'Parasitic endophthal NOS');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Gretta Bilton', 'S7397048U', 'F', '90776071', '17/2/2021', 'Mal neo stom great curv');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Jocko McLewd', 'S9510466G', 'M', '93267137', '30/9/2020', 'Chr serous OM NEC');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Gan Skouling', 'S1166204Z', 'M', '91366559', '16/8/2021', 'Post-traumatic seroma');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Kelly Guttridge', 'S4046034H', 'F', '99630717', '18/4/2021', 'Uncert behavior neo NOS');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Jemmy Ganforthe', 'S8590385W', 'F', '96539609', '29/9/2020', 'Otosclerosis NOS');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Mitchel Kobierra', 'S7023810B', 'M', '94268727', '5/4/2021', 'Congenital torticollis');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Francesca Deighton', 'S2364708H', 'F', '98299574', '18/1/2021', 'Fx symphy mandib body-cl');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Kassia Lucius', 'S4964049P', 'F', '94080379', '5/7/2021', 'Lactation fail-postpart');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Amory Frantz', 'S4310128L', 'M', '91048990', '13/12/2020', 'Lordosis NEC');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Betteann Giroldi', 'S5378938C', 'F', '93479709', '9/8/2021', 'Blister forearm');
insert into patient (patient_name, patient_id, gender, contact, consult_date, diagnosis) values ('Meg Mellish', 'S7024289D', 'F', '93787689', '26/1/2021', 'Deep 3rd brn fngr w thmb');

/************************************************************************/
/*                                                                      */
/* Question 1.e                                                         */
/*                                                                      */
/************************************************************************/
/* Write your answer in SQL below: */
INSERT INTO seen(mcr_no,patient_id,consult_date)
SELECT 
	d.mcr_no, 
	p.patient_id, 
	p.consult_date
FROM 
	doctor d, 
	patient p
ORDER BY 
	random() 
	LIMIT 1000;