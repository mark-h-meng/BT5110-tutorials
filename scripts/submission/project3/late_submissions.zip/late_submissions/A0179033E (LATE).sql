/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0179033E                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON pay.salary = 189170
WHERE per.empid = pay.empid
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.07 ms
-- Average Execution 1.87 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll WHERE salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.09 ms
-- Average Execution 1.90 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT * FROM payroll pay WHERE pay.salary <> 189170 AND per.empid = pay.empid)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.10 ms
-- Average Execution 4.09 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT DISTINCT joined.empid, joined.lname FROM
(SELECT pay.empid, per.lname, pay.salary,
CASE
	WHEN NOT EXISTS(SELECT * FROM employee e, payroll p WHERE p.salary <> 189170 AND pay.salary = p.salary) AND (pay.empid,per.lname) IN (SELECT per2.empid,per2.lname AS lookup FROM employee per2) THEN 1 
	ELSE 0 
END AS flag, per.empid AS empid2
FROM employee per, payroll pay
ORDER BY flag DESC, pay.empid) AS joined
WHERE joined.flag = 1
ORDER BY joined.empid;

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.32 ms
-- Average Execution 7363458.07 ms
