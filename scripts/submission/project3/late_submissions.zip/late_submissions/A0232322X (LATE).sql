/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232322X                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON pay.empid = per.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;


/* SELECT test('SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON pay.empid = per.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;', 100) */

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.22> ms
-- Average Execution <7.11> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT EXISTS (
			SELECT pay.empid FROM payroll pay, employee per
			WHERE pay.empid = per.empid)) AS temp
WHERE EXISTS (
	SELECT pay.empid
	FROM payroll pay
	WHERE pay.empid = per.empid
	AND pay.salary = 189170)
ORDER BY per.empid, per.lname;


/* SELECT test('SELECT per.empid, per.lname
FROM employee per, (SELECT EXISTS (
			SELECT pay.empid FROM payroll pay, employee per
			WHERE pay.empid = per.empid)) AS temp
WHERE EXISTS (
	SELECT pay.empid
	FROM payroll pay
	WHERE pay.empid = per.empid
	AND pay.salary = 189170)
ORDER BY per.empid, per.lname;', 100) */

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.30> ms
-- Average Execution <6.40> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid
	FROM payroll pay
	WHERE pay.salary <> 189170
	AND per.empid = pay.empid)
ORDER BY per.empid, per.lname;


/* SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid
	FROM payroll pay
	WHERE pay.salary <> 189170
	AND per.empid = pay.empid)
ORDER BY per.empid, per.lname;', 100) */

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.26> ms
-- Average Execution <14.35> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT DISTINCT per.empid, per.lname
FROM employee per, payroll pay
WHERE per.empid IN(
	SELECT pay.empid 
	FROM payroll pay
	WHERE pay.salary = 189170)
ORDER BY per.empid, per.lname;
	

/* SELECT test('SELECT DISTINCT per.empid, per.lname
FROM employee per, payroll pay
WHERE per.empid IN(
	SELECT pay.empid 
	FROM payroll pay
	WHERE pay.salary = 189170)
ORDER BY per.empid, per.lname;', 20)   */

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.42> ms
-- Average Execution <92.23> ms
