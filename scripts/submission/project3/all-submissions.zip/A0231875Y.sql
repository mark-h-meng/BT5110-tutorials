/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231875Y                               */
/******************************************************************************/
-- Reference query provided in the assignment for Question 2
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170;
 
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
-- Query provided in the assignment for Question 2a
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON TRUE AND pay.salary = 189170
WHERE TRUE
ORDER BY per.empid, per.lname;


-- My modified query based on the query provided in the assignment for Question 2a
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON pay.salary = 189170
WHERE per.empid = pay.empid 
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.09 ms
-- Average Execution 2.24 ms


/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
-- Query provided in the assignment for Question 2b
SELECT per.empid, per.lname
FROM employee per, (SELECT TRUE) AS temp
	WHERE TRUE
ORDER BY per.empid, per.lname;


-- My modified query based on the query provided in the assignment for Question 2b
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary FROM payroll pay) AS temp
	WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.10 ms
-- Average Execution 2.36 ms


/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
-- Query provided in the assignment for Question 2c
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT TRUE)
ORDER BY per.empid, per.lname;


-- My modified query based on the query provided in the assignment for Question 2c
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid, pay.salary FROM payroll pay WHERE (pay.salary != 189170) AND per.empid = pay.empid) 
ORDER BY per.empid, per.lname;
			 
-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.11 ms
-- Average Execution 5.01 ms


/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee AS per, employee AS per2
WHERE NOT EXISTS (
	SELECT *
	FROM payroll AS pay2 
	INNER JOIN 
	(SELECT (SELECT DISTINCT per.empid FROM employee AS per WHERE per.empid = pay.empid) FROM payroll AS pay) AS temp
		ON pay2.empid = temp.empid
	WHERE (pay2.salary != 189170) AND per.empid = pay2.empid)
AND (per.lname >= per2.lname AND per.empid >= per2.empid)
GROUP BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.23 ms
-- Average Execution 19683.29 ms

