/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232015Y                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid=pay.empid AND pay.salary = 189170
WHERE per.empid notnull
ORDER BY per.empid, per.lname;

select test (
'SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid=pay.empid AND pay.salary = 189170
WHERE per.empid notnull
ORDER BY per.empid, per.lname;',100)

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.15> ms
-- Average Execution <5.63> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid
					from payroll pay 
					where pay.salary = 189170) AS temp
	WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname;
 
select test (
'SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid
					from payroll pay 
					where pay.salary = 189170) AS temp
	WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname;',100)

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.15> ms
-- Average Execution <5.23> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid from payroll pay
    where pay.salary <> 189170
    and per.empid=pay.empid)
ORDER BY per.empid, per.lname;

select test (
'SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid from payroll pay
    where pay.salary <> 189170
    and per.empid=pay.empid)
ORDER BY per.empid, per.lname;',100)

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.15> ms
-- Average Execution <10.87> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per,payroll pay1
where per.empid=pay1.empid
and pay1.salary <=ALL (
    SELECT pay3.salary from payroll pay3
    where pay3.salary >=189170)
and pay1.salary >=ALL (
    SELECT pay2.salary from payroll pay2
    where pay2.salary <=189170)
ORDER BY per.empid, per.lname;

select test (
'SELECT per.empid, per.lname
FROM employee per,payroll pay1
where per.empid=pay1.empid
and pay1.salary <=ALL (
    SELECT pay3.salary from payroll pay3
    where pay3.salary >=189170)
and pay1.salary >=ALL (
    SELECT pay2.salary from payroll pay2
    where pay2.salary <=189170)
ORDER BY per.empid, per.lname;',20)

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.24> ms
-- Average Execution <1906.78> ms
