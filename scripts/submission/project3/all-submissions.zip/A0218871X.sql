/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0218871X                               */
/******************************************************************************/
 SELECT per.empid, per.lname
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid
 AND pay.salary = 189170;

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/


SELECT per.empid , per.lname
FROM employee per RIGHT OUTER JOIN payroll pay
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid , per.lname;


-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.10ms
-- Average Execution 4.60ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll WHERE salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;





-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.11 ms
-- Average Execution 4.26 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
  SELECT per.empid , per.lname
FROM  payroll pay
WHERE per.empid = pay.empid AND pay.salary <> 189170
)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.13ms
-- Average Execution 9.45ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/


SELECT a.empid, a.lname
FROM
(SELECT per.empid, per.lname
FROM employee per
WHERE per.empid
NOT IN (
SELECT per.empid
FROM  payroll pay
WHERE per.empid = pay.empid
AND (pay.salary > 189170)
AND  per.empid IS NOT NULL) ) AS a JOIN
(SELECT per.empid, per.lname
FROM employee per
WHERE per.empid
NOT IN (
SELECT per.empid
FROM  payroll pay
WHERE per.empid = pay.empid
AND (pay.salary < 189170)
AND  per.empid IS NOT NULL)) AS b

ON a.empid = b.empid
ORDER BY a.empid, a.lname;


--0.27 : 27149.36
-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.27 ms
-- Average Execution 27149.36 ms
