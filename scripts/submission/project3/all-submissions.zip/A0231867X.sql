/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231867X                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.07 ms
-- Average Execution 1.94 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT 
  per.empid, 
  per.lname 
FROM 
  employee per, 
  (
    select 
      p.empid as empid, 
      salary 
    from 
      employee p 
      left join payroll pay on p.empid = pay.empid
  ) AS temp 
WHERE 
  per.empid = temp.empid 
  and temp.salary = 189170 
ORDER BY 
  per.empid, 
  per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.15 ms
-- Average Execution 3.06 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT 
  per.empid, 
  per.lname 
FROM 
  employee per 
WHERE 
  NOT EXISTS (
    select 
      1 
    from 
      employee p, 
      payroll pay 
    where 
      p.empid = pay.empid 
      and pay.salary <> 189170 
      and p.empid = per.empid
  ) 
ORDER BY 
  per.empid, 
  per.lname;



-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.12 ms
-- Average Execution 7.93 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
 
select employee.empid, employee.lname
from employee
where empid in
(
    select empid
    from employee p
    where p.empid not in 
    (
        select empid
        from
        (

            select p1.empid as empid
            from employee p1
            left join
            payroll r1
            on p1.empid = r1.empid
            where r1.salary > 189170

            union

            select p2.empid as empid
            from employee p2
            left join 
            payroll r2
            on p2.empid = r2.empid
            where r2.salary < 189170
        ) a
    )
)
order by 
  employee.empid, 
  employee.lname;


-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.22 ms
-- Average Execution 14.83 ms

