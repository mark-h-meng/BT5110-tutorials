/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231907H                              */
/******************************************************************************/

/* 1.d */ 
SELECT test('SELECT per.empid, per.lname 
  FROM employee per, payroll pay
  WHERE per.empid = pay.empid AND pay.salary = 189170;', 1000)
/* Result: 0.11 : 3.64 */

/* Question 2 Reference SQL query */
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170;

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.04> ms
-- Average Execution <1.37> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll pay WHERE pay.salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.04> ms
-- Average Execution <1.27> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid
    FROM  payroll pay
    WHERE per.empid = pay.empid
	AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.04> ms
-- Average Execution <2.83> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT emp.empid, emp.lname 
    FROM employee emp, payroll pay
    WHERE per.empid = pay.empid 
    AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
  FROM employee per
  WHERE NOT EXISTS (
    SELECT emp.empid, emp.lname 
    FROM employee emp, payroll pay
    WHERE per.empid = pay.empid 
    AND pay.salary <> 189170)
  ORDER BY per.empid, per.lname;', 20)

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.33> ms
-- Average Execution <245640.23> ms

/* Explanation: This is the query I incidentally wrote when I dealt with 2.c. I found it was very
slow but can got to the correct answer. But I was a little afraid there is some problem not 
permitted by the pdf, so I presented another solution.*/

SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (
  SELECT pay.empid
  FROM  payroll pay
  WHERE per.empid = pay.empid
  AND pay.salary = 189170)
  
SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (
  SELECT pay.empid
  FROM  payroll pay
  WHERE per.empid = pay.empid
  AND pay.salary = 189170)', 20)
  
-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.05> ms
-- Average Execution <5485.48> ms
