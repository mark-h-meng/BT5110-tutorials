/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0218968J                               */
/******************************************************************************/
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/

SELECT per.empid , per. lname
FROM employee per RIGHT OUTER JOIN payroll pay
ON pay.empid = per.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid , per. lname ;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.07 ms
-- Average Execution 1.85 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/

SELECT per.empid , per. lname
FROM employee per , (
    SELECT pay.empid, pay.salary 
    FROM payroll pay ) AS temp
WHERE temp.empid = per.empid 
AND temp.salary = 189170
ORDER BY per.empid , per. lname ;
 

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.06 ms
-- Average Execution 1.76 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/

SELECT per.empid , per. lname
FROM employee per
WHERE NOT EXISTS (
	SELECT pay.empid, pay.salary 
	FROM payroll pay
	WHERE per.empid=pay.empid
	AND pay.salary <> 189170)
ORDER BY per.empid , per. lname ;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.08 ms
-- Average Execution 4.01 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

CREATE OR REPLACE FUNCTION find_emp()
RETURNS TABLE(
	empid char(9),
	lname char(15))
AS $$
DECLARE
	pay RECORD;
	emp RECORD;
BEGIN
	FOR emp in EXECUTE 'SELECT * FROM employee' LOOP
		FOR pay in EXECUTE 'SELECT * FROM payroll' LOOP
			IF emp.empid = pay.empid THEN
				IF pay.salary = 189170 THEN
					empid := emp.empid;
					lname := emp.lname;
					RETURN NEXT;
				END IF;
			END IF;
		END LOOP;
	END LOOP;
END;
$$ LANGUAGE plpgsql;

SELECT * 
FROM find_emp() AS r
ORDER BY r.empid , r.lname; 


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.02 ms
-- Average Execution 20401.03 ms

/********************************************************************************

PLEASE NOTE: 
Function performance has been measured using the following statement:
SELECT TEST('SELECT find_emp()', 20);

Most Important Sources:

1. AVOIDING UNNECESSARY STORED PROCEDURE CALLS IN POSTGRESQL : https://www.cybertec-postgresql.com/en/avoiding-unnecessary-stored-procedure-calls-in-postgresql/
2. How to optimize the performance of a stored procedure in Postgres? https://stackoverflow.com/questions/57342383/how-to-optimize-the-performance-of-a-stored-procedure-in-postgres
3. Execute: https://www.postgresql.org/docs/13/plpgsql-statements.html
4. https://gis.stackexchange.com/questions/42574/why-is-a-stored-procedures-much-slower-than-the-single-query
5. How to Develop a PL/pgSQL Function That Returns a Table https://www.postgresqltutorial.com/plpgsql-function-returns-a-table/
6. RETURN NEXT: https://academy.vertabelo.com/course/user-defined-functions/returning-tables/tables-and-sets/returns-table-with-return-next
7. SQL Functions Returning TABLE: https://www.postgresql.org/docs/13/xfunc-sql.html#XFUNC-SQL-FUNCTIONS-RETURNING-TABLE
8. PostgreSQL Stored Procedures: https://carto.com/help/working-with-data/sql-stored-procedures/

********************************************************************************/

