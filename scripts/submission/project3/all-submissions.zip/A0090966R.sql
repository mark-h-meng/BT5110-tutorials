/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0090966R                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.11 ms
-- Average Execution 4.81 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll pay WHERE pay.salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.11 ms
-- Average Execution 4.52 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT * FROM payroll pay WHERE pay.empid = per.empid AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.12 ms
-- Average Execution 9.35 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT DISTINCT a.empid, a.lname FROM
(SELECT * FROM employee) a 
INNER JOIN
(SELECT DISTINCT y.empid, y.salary, x.lname
FROM employee x
CROSS JOIN payroll y) b 
ON (a.empid = b.empid AND a.lname = b.lname)
WHERE b.salary = 189170
ORDER BY a.empid, a.lname;

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.19 ms
-- Average Execution 263.31 ms


--0.19	264.43
--0.19	260.86
--0.19	259.06
--0.19	263.54
--0.19	267.22
--0.19	260.39
--0.19	261.33
--0.19	262.13
--0.19	266.10
--0.19	260.96
--0.19	264.82
--0.19	262.24
--0.19	264.10
--0.19	263.31
--0.19	262.72
--0.19	265.40
--0.19	267.25
--0.19	264.93
--0.19	262.51
--0.19	262.84


--Alternatively
-- SELECT per.empid, per.lname
-- FROM employee per
-- WHERE per.empid NOT IN 
-- (SELECT empid FROM employee
-- INTERSECT
-- SELECT empid FROM payroll WHERE salary <> 189170)
-- ORDER BY per.empid, per.lname;
-- 0.11  27.30
