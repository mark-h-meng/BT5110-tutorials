/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231856B                               */
/******************************************************************************/
 SELECT per.empid, per.lname
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid
 AND pay.salary = 189170;

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null AND pay.salary = 189170
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.13> ms
-- Average Execution <5.12> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid FROM payroll WHERE salary=189170) AS temp
	WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.13> ms
-- Average Execution <5.03> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per1.empid, per1.lname
FROM employee per1
WHERE NOT EXISTS (
    SELECT per.empid, per.lname
    FROM employee per, payroll pay
    WHERE per.empid = pay.empid
    AND pay.salary <> 189170
    AND per1.empid=per.empid)
ORDER BY per1.empid, per1.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.22> ms
-- Average Execution <22.15> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

/* a includes the employee whose salary is below or equal to 189170
   b includes the employee whose salary is more than or equal to 189170
   then we take their intercept, the result is equal to 189170 */
SELECT a.empid, a.lname FROM
  (
  SELECT per.empid, per.lname
  FROM employee per
  WHERE (per.empid, per.lname) NOT IN
    (
    SELECT per1.empid, per1.lname
    FROM employee per1, payroll pay
    WHERE per1.empid=pay.empid
    AND per.empid = per1.empid
    AND per.lname=per1.lname
    AND pay.salary > 189170 )
  ORDER BY per.empid, per.lname
  ) as a
  INNER JOIN
  (
  SELECT per.empid, per.lname
  FROM employee per
  WHERE (per.empid, per.lname) NOT IN
    (
    SELECT per1.empid, per1.lname
    FROM employee per1, payroll pay
    WHERE per1.empid=pay.empid
    AND per.empid = per1.empid
    AND per.lname=per1.lname
    AND pay.salary < 189170 )
  ORDER BY per.empid, per.lname
  ) as b
  ON a.empid=b.empid
  AND a.lname=b.lname;

  /* sad story of having a slow computer */

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.38> ms
-- Average Execution <55080.76> ms
