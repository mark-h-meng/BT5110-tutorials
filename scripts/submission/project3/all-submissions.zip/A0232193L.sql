/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0xxxxxxx                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 -- Average Planning <time> 0.13 ms
-- Average Execution <time> 3.28 ms
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> 0.14 ms
-- Average Execution <time> 3.69 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid from payroll where salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> 0.13 ms
-- Average Execution <time> 3.15 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT empid
    from payroll pay
    where per.empid = pay.empid
    and pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> 0.16 ms
-- Average Execution <time> 7.77 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

select temp.empid, temp.lname
from (
(select per.empid, per.lname
from employee per join payroll pay
on per.empid = pay.empid
where per.empid is not null
order by per.empid, per.lname)  
intersect 
(select per.empid as empid, per.lname 
from employee per join payroll pay 
on per.empid = pay.empid
where per.empid is not null  
and not exists (
    select *
	from payroll pay where per.empid = pay.empid and pay.salary <> 189170)
order by per.empid, per.lname)) temp
order by temp.empid, temp.lname;


-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <time> 0.49 ms
-- Average Execution <time> 31.44 ms