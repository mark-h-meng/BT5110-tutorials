/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232196E                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per RIGHT OUTER JOIN payroll pay ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null
ORDER BY per.empid , per.lname;
	

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.02 ms
-- Average Execution 1.94 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary from payroll) AS temp
	WHERE temp.empid = per.empid and temp.salary = 189170
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.02 ms
-- Average Execution 1.83 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
 SELECT *
 FROM payroll pay 
 WHERE per.empid = pay.empid  
 AND pay.salary <> 189170 
)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.02 ms
-- Average Execution 3.86 ms

/******************************************************************************/
/* Answer Question 3 below                                                    */
/******************************************************************************/

select per.empid, per.lname
FROM employee per, payroll pay
where cast(per.empid as int) - cast(pay.empid as int) = 0
and
pay.salary < all
(select pay.salary from employee per 
right join payroll pay on per.empid = pay.empid 
where pay.salary > 189170)
and 
pay.salary > all
(select pay.salary from employee per 
right join payroll pay on per.empid = pay.empid 
where pay.salary < 189170)
ORDER BY per.empid, per.lname;
-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.13 ms
-- Average Execution 939.75 ms