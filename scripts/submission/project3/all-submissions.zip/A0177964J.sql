/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0177964J                               */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per , payroll pay
WHERE per.empid = pay.empid AND pay.salary = 189170
ORDER BY per.empid , per.lname ;
 
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.2> ms
-- Average Execution <6.67> ms

SELECT test 
	('SELECT per.empid, per.lname
		FROM employee per RIGHT OUTER JOIN payroll pay 
    	ON per.empid = pay.empid AND pay.salary = 189170
		WHERE per.empid IS NOT NULL
		ORDER BY per.empid, per.lname;', 100);


/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid
				   FROM payroll pay
				   WHERE pay.salary = 189170) AS temp
WHERE temp.empid = per.empid
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.18> ms
-- Average Execution <6.35> ms

SELECT test 
	('SELECT per.empid, per.lname
		FROM employee per, (SELECT pay.empid
				  			FROM payroll pay
				   			WHERE pay.salary = 189170) AS temp
		WHERE temp.empid = per.empid
		ORDER BY per.empid, per.lname;', 100);

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT *
	FROM payroll pay
	WHERE per.empid = pay.empid
	AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.16> ms
-- Average Execution <8.90> ms

SELECT test 
	('SELECT per.empid, per.lname
		FROM employee per
		WHERE NOT EXISTS (
    	SELECT *
		FROM payroll pay
		WHERE per.empid = pay.empid
		AND pay.salary <> 189170)
		ORDER BY per.empid, per.lname;', 100);


/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per LEFT OUTER JOIN payroll pay 
ON per.empid = pay.empid
WHERE pay.empid NOT IN (
		SELECT pay1.empid
		FROM payroll pay1
		WHERE pay1.salary <> 189170)
GROUP BY per.empid, per.lname
ORDER BY per.empid, per.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.22> ms
-- Average Execution <22.40> ms

SELECT test 
	('SELECT per.empid, per.lname
	FROM employee per LEFT OUTER JOIN payroll pay 
	ON per.empid = pay.empid
	WHERE pay.empid NOT IN (
	SELECT pay1.empid
	FROM payroll pay1
	WHERE pay1.salary <> 189170)
	GROUP BY per.empid, per.lname
	ORDER BY per.empid, per.lname;', 20);
