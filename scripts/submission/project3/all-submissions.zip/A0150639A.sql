/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0150639A                               */
/******************************************************************************/
 
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170;

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid  IS NOT NULL
ORDER BY per.empid, per.lname;

-- Put into test to get the execution time
SELECT test('SELECT per.empid, per.lname
			FROM employee per RIGHT OUTER JOIN payroll pay 
				ON per.empid = pay.empid AND pay.salary = 189170
			WHERE per.empid  IS NOT NULL
			ORDER BY per.empid, per.lname;',100);

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.19 ms
-- Average Execution 5.12 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per, 
	(SELECT * FROM payroll) AS temp
	WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;

-- Put into test to get the execution time
SELECT test('SELECT per.empid, per.lname
			FROM employee per, 
				(SELECT * FROM payroll) AS temp
				WHERE per.empid = temp.empid AND temp.salary = 189170
			ORDER BY per.empid, per.lname;',100);

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.18 ms
-- Average Execution 4.73 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT *
	FROM payroll pay
	WHERE pay.empid = per.empid
		  AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Put into test to get the execution time
SELECT test('SELECT per.empid, per.lname
			FROM employee per
			WHERE NOT EXISTS (
				SELECT *
				FROM payroll pay
				WHERE pay.empid = per.empid
					  AND pay.salary <> 189170)
			ORDER BY per.empid, per.lname;',100);

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.19 ms
-- Average Execution 10.90 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per2.empid,per2.lname
FROM employee per2
WHERE per2.empid <> ALL (
	SELECT per.empid
	FROM employee per
	WHERE per.empid <> ALL (
		SELECT pay.empid
		FROM payroll pay
		WHERE pay.salary = 189170))
ORDER BY per2.empid, per2.lname;			

-- Put into test to get the execution time

SELECT test('SELECT per2.empid,per2.lname
			FROM employee per2
			WHERE per2.empid <> ALL (
				SELECT per.empid
				FROM employee per
				WHERE per.empid <> ALL (
					SELECT pay.empid
					FROM payroll pay
					WHERE pay.salary = 189170))
			ORDER BY per2.empid, per2.lname;',20);


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.15 ms
-- Average Execution 14062.24 ms
