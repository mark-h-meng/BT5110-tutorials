/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232013A                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;
	
-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.16 ms
-- Average Execution 7.26 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll) AS temp
	WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;
 
-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.13 ms
-- Average Execution 6.09 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid
	FROM payroll pay
	WHERE pay.salary != 189170 AND per.empid = pay.empid)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.19 ms
-- Average Execution 16.43 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT main.empid, main.lname
FROM ( SELECT per.lname, per.fname, per.address, per.city, per.state, per.zip, pay.empid, pay.bonus, pay.salary
FROM employee per RIGHT OUTER JOIN payroll pay ON pay.empid >= per.empid
GROUP BY per.lname, per.fname, per.address, per.city, per.state, per.zip, pay.empid, pay.bonus, pay.salary
HAVING MIN(pay.salary) >= 189170
INTERSECT
SELECT per.lname, per.fname, per.address, per.city, per.state, per.zip, pay.empid, pay.bonus, pay.salary
FROM employee per
RIGHT OUTER JOIN (SELECT * FROM payroll) AS pay
ON pay.empid <= per.empid
GROUP BY per.lname, per.fname, per.address, per.city, per.state, per.zip, pay.empid, pay.bonus, pay.salary
HAVING MAX(pay.salary) <= 189170 ) AS main
WHERE main.empid IS NOT NULL
ORDER BY main.empid, main.lname;

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.35 ms
-- Average Execution 2548868.05 ms
