
/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232195H                         */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per . empid , per . lname
FROM employee per RIGHT OUTER JOIN payroll pay
ON per . empid = pay . empid AND pay . salary = 189170
WHERE per . empid is not NULL
ORDER BY per . empid , per . lname ;
	
-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.07> ms
-- Average Execution <2.31> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per . empid , per . lname
FROM employee per , ( SELECT empid FROM payroll WHERE salary = 189170 ) AS temp
WHERE per . empid = temp . empid
ORDER BY per . empid , per . lname ;
	
-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.07> ms
-- Average Execution <2.18> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT 1
	FROM payroll pay
	WHERE per . empid = pay . empid  AND pay . salary <> 189170
	)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.09> ms
-- Average Execution <4.86> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per . empid NOT IN (
	SELECT pay . empid
	FROM payroll pay
	WHERE pay . salary <> 189170
	ORDER BY pay.salary
)
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.07> ms
-- Average Execution <8.65> ms
