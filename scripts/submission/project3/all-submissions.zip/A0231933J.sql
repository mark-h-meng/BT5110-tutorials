/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231933J                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per. empid = pay. empid AND pay.salary = 189170
WHERE per. empid = pay. empid
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.17 ms
-- Average Execution 4.90 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * from payroll where payroll.salary=189170) AS temp
	WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.12 ms
-- Average Execution 5.41 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
SELECT *
from employee per1, payroll pay
where per1.empid=pay.empid and pay.salary!=189170 and per.empid=per1.empid)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.19 ms
-- Average Execution 19.18 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid,per.lname
FROM employee per
WHERE NOT EXISTS (
SELECT per1.empid,per1.lname
from employee per1 left join payroll pay
on per1.empid=pay.empid and per.empid=per1.empid
where pay.salary not in(select pay.salary from payroll pay where pay.salary=189170))
ORDER BY per.empid, per.lname asc;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.33 ms
-- Average Execution 41345.26 ms
