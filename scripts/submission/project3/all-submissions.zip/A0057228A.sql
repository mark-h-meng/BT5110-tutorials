/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0057228A                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per RIGHT OUTER JOIN payroll pay ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid , per.lname;
	

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.04 ms
-- Average Execution 2.19 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per, (SELECT * FROM payroll pay WHERE pay.salary = 189170) AS temp WHERE per.empid = temp.empid
ORDER BY per.empid , per.lname;
	
-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.03 ms
-- Average Execution 2:09 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per WHERE NOT EXISTS (
SELECT * FROM payroll pay WHERE per.empid = pay.empid AND pay.salary <> 189170)
ORDER BY per.empid , per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.04 ms
-- Average Execution 4.27 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per1.empid, per1.lname	
FROM employee per1 LEFT OUTER JOIN payroll pay1 ON per1.empid = pay1.empid
WHERE pay1.salary <= 189170 AND NOT EXISTS 
	(SELECT * 
	 FROM employee per2 LEFT OUTER JOIN payroll pay2 ON per2.empid = pay2.empid
		WHERE (pay2.salary > pay1.salary) AND (pay2.salary <= 189170))
	AND EXISTS (SELECT * 
		    FROM payroll pay3 
		    WHERE (pay3.salary = 189170)
ORDER by pay1.salary DESC, per1.empid);	

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.14 ms
-- Average Execution 207.20 ms
