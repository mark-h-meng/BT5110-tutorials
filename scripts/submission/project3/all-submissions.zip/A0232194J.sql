/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232194J                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per 
RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid NOTNULL
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.03 ms
-- Average Execution 1.98 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary FROM payroll) AS temp
    WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.03 ms
-- Average Execution 1.86 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid, pay.salary
    FROM payroll pay
    WHERE pay.empid = per.empid
    AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.04 ms
-- Average Execution 3.95 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT emp.empid, emp.lname
FROM employee emp
WHERE emp.empid NOT IN (
(
SELECT per.empid
FROM employee per
WHERE per.empid NOT IN (
    SELECT pay.empid
    FROM payroll pay
    WHERE pay.salary >= 189170)
ORDER BY per.empid
)
UNION
(
SELECT per.empid
FROM employee per
WHERE per.empid NOT IN (
    SELECT pay.empid
    FROM payroll pay
    WHERE pay.salary <= 189170)
ORDER BY per.empid
)
);  


-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.07 ms
-- Average Execution 13.92 ms
