/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231851L                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170
 order by per.empid,per.lname;
 

-- Average Planning 0.11 ms
-- Average Execution 2.62 ms 
 
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid=pay.empid AND pay.salary = 189170
WHERE per.empid is not null
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.12> ms
-- Average Execution <2.81> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid,pay.salary
				   from payroll pay
				   where pay.salary=189170) AS temp
WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname;
 

			
-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.12 ms
-- Average Execution 2.60 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT per.empid,pay.salary
	from payroll pay
	where per.empid=pay.empid and pay.salary <> 189170)
ORDER BY per.empid, per.lname;



-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.13> ms
-- Average Execution <5.60> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/


select per.empid,per.lname
from employee per cross join payroll pay
where per.empid not in(
	select pay.empid
	from payroll pay
	where pay.salary<>189170 and pay.empid=per.empid)
		and per.empid=pay.empid
order by per.empid,per.lname;

			
-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.15 ms
-- Average Execution 5904.12 ms
