/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0119351L                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid is not null AND pay.salary = 189170
WHERE per.empid = pay.empid
ORDER BY per.empid, per.lname;
	
	

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.08 ms
-- Average Execution 2.29 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary
				   from payroll
				   where salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.08 ms
-- Average Execution 2.11 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid
	from payroll pay, payroll pay2
	where (pay.salary > 189170 or pay2.salary < 189170)
	and pay.empid = pay2.empid
	and pay.empid = per.empid)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.09 ms
-- Average Execution 4.66 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid
	from payroll pay, payroll pay2
	where (pay.salary > 189170 or pay2.salary < 189170)
	and pay.empid = pay2.empid
	and pay.empid = per.empid)
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.14 ms
-- Average Execution 9.88 ms
