/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here:  A0231945A                                   */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.18 ms
-- Average Execution 7.04 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid,pay.salary from payroll pay) AS temp
	WHERE temp.salary = 189170 and temp.empid = per.empid
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.14 ms
-- Average Execution 5.05 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per 
WHERE NOT EXISTS (
    SELECT  *
    FROM payroll pay 
	WHERE pay.salary <> 189170 and pay.empid=per.empid)
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.16 ms
-- Average Execution 12.31 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

select per.empid,per.lname
from employee per right join
(SELECT per.empid,per.lname FROM employee per
WHERE per.empid in (SELECT empid from payroll 
						where payroll.salary<189172 and per.empid=payroll.empid))as temp1
 on per.empid=temp1.empid
 intersect
 select per.empid,per.lname
from employee per right join
(SELECT per.empid,per.lname FROM employee per
WHERE per.empid in (SELECT empid from payroll 
						where payroll.salary>189169 and per.empid=payroll.empid))as temp2
on per.empid=temp2.empid
except
select per.empid,per.lname
from employee per right join
(SELECT per.empid,per.lname FROM employee per
WHERE per.empid in (SELECT empid from payroll 
						where payroll.salary=189171 and per.empid=payroll.empid))as temp3
on per.empid=temp3.empid;

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.81 ms
-- Average Execution 41082.78 ms
