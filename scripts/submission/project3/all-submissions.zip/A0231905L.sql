/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231905L                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid 
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.12 ms
-- Average Execution 4.17 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid FROM payroll pay WHERE pay.salary = 189170) AS temp
	WHERE temp.empid = per.empid
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.15 ms
-- Average Execution 4.09 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid FROM payroll pay WHERE pay.empid=per.empid
        AND pay.salary!=189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.14 ms
-- Average Execution 8.37 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT temp.empid, temp.lname 
FROM ((SELECT *
FROM employee per
WHERE per.empid NOT IN (
    SELECT pay.empid FROM payroll pay WHERE pay.empid!=per.empid) 
ORDER BY per.empid, per.lname)
INTERSECT
(SELECT *
FROM employee per
WHERE per.empid NOT IN (
    SELECT pay.empid FROM payroll pay WHERE pay.salary!=189170) 
ORDER BY per.empid, per.lname)) AS temp
ORDER BY temp.empid, temp.lname;

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.36 ms
-- Average Execution 59413.01 ms
