/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231973B                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay
	ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;

/*
 SELECT test('SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay
	ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;',100);
 */


-- Average Planning 0.17 ms
-- Average Execution 5.59 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.salary, pay.empid FROM payroll pay) AS temp
	WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;
 
/*
SELECT test('SELECT per.empid, per.lname
FROM employee per, (SELECT pay.salary, pay.empid FROM payroll pay) AS temp
	WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;',100);
 */

-- Average Planning 0.17 ms
-- Average Execution 5.69 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
	SELECT pay.salary
	FROM payroll pay
	WHERE per.empid = pay.empid
	AND pay.salary != 189170)
ORDER BY per.empid, per.lname;

/*
 SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
	SELECT pay.salary
	FROM payroll pay
	WHERE per.empid = pay.empid
	AND pay.salary != 189170)
ORDER BY per.empid, per.lname;',100);
 */

-- Average Planning 0.16 ms
-- Average Execution 11.11 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, payroll pay 
WHERE NOT per.empid > pay.empid 
AND NOT per.empid < pay.empid 
GROUP BY pay.salary, per.empid, per.lname
HAVING pay.salary NOT IN (
	SELECT pay2.salary FROM payroll pay2
	WHERE pay2.salary < 189170
	OR pay2.salary > 189170)
ORDER BY per.empid, per.lname;

/*
SELECT test('SELECT per.empid, per.lname
FROM employee per, payroll pay 
WHERE NOT per.empid > pay.empid 
AND NOT per.empid < pay.empid 
GROUP BY pay.salary, per.empid, per.lname
HAVING pay.salary NOT IN (
	SELECT pay2.salary FROM payroll pay2
	WHERE pay2.salary < 189170
	OR pay2.salary > 189170)
ORDER BY per.empid, per.lname;',20);
*/

-- Average Planning 0.22 ms
-- Average Execution 128 740.33 ms


