/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0124294H                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null
ORDER BY per.empid, per.lname;

-- SELECT test ('SELECT per.empid, per.lname
-- FROM employee per RIGHT OUTER JOIN payroll pay 
--     ON per.empid = pay.empid AND pay.salary = 189170
-- WHERE per.empid is not null
-- ORDER BY per.empid, per.lname; ' , 100) ;

-- Indicate the average measured times for 100 executions for the query.
-- Average Planning 0.16 ms
-- Average Execution 4.14 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid from payroll pay where pay.salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- SELECT test ('SELECT per.empid, per.lname
-- FROM employee per, (SELECT pay.empid from payroll pay where pay.salary = 189170) AS temp
-- 	WHERE per.empid = temp.empid
-- ORDER BY per.empid, per.lname;', 100) ;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.20 ms
-- Average Execution 4.68 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT * from payroll pay where pay.salary <> 189170 and per.empid = pay.empid
)
ORDER BY per.empid, per.lname;

-- SELECT test ('SELECT per.empid, per.lname
-- FROM employee per
-- WHERE NOT EXISTS (
--     SELECT * from payroll pay where pay.salary <> 189170 and per.empid = pay.empid
-- )
-- ORDER BY per.empid, per.lname;', 100) ;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.18 ms
-- Average Execution 9.37 ms

/******************************************************************************/
/* Answer Question 3 below                                                    */
/******************************************************************************/

SELECT per.empid, per.lname FROM employee per,
(SELECT * FROM employee emp
WHERE emp.empid IN
(SELECT emp1.empid FROM employee emp1, payroll pay1
WHERE emp1.empid = pay1.empid and
pay1.salary IN
(SELECT pay2.salary FROM 
(select pay.empid as pay_empid,pay.bonus,pay.salary,emp.empid as emp_empid,emp.lname,
emp.fname,emp.address,emp.city,emp.state,emp.zip from payroll pay,employee emp) pay2 
WHERE  pay1.empid = pay2.pay_empid AND emp.empid = pay2.pay_empid AND pay2.salary = 189170 AND pay2.pay_empid = pay2.emp_empid))) filtered 
where filtered.empid = per.empid  
ORDER BY per.empid , per.lname;

-- SELECT test ('SELECT per.empid, per.lname FROM employee per,
-- (SELECT * FROM employee emp
-- WHERE emp.empid IN
-- (SELECT emp1.empid FROM employee emp1, payroll pay1
-- WHERE emp1.empid = pay1.empid and
-- pay1.salary IN
-- (SELECT pay2.salary FROM 
-- (select pay.empid as pay_empid,pay.bonus,pay.salary,emp.empid as emp_empid,emp.lname,
-- emp.fname,emp.address,emp.city,emp.state,emp.zip from payroll pay,employee emp) pay2 
-- WHERE  pay1.empid = pay2.pay_empid AND emp.empid = pay2.pay_empid AND pay2.salary = 189170 AND pay2.pay_empid = pay2.emp_empid))) filtered 
-- where filtered.empid = per.empid  
-- ORDER BY per.empid , per.lname;',20)

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.23 ms
-- Average Execution 152904.18 ms
