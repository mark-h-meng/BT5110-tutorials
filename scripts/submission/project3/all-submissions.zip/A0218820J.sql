/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0218820J (Yu Zhe)                      */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid  AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.08 ms
-- Average Execution 1.93 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary FROM payroll pay WHERE pay.Salary=189170) AS temp
	WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.07 ms
-- Average Execution 2.01 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT *
    FROM payroll pay
    WHERE pay.salary<>189170
    AND per.empid=pay.empid)
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.08 ms
-- Average Execution 4.46 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per
WHERE EXISTS (
    SELECT   *
	FROM payroll pay  
    WHERE per.empid=pay.empid
	EXCEPT
	SELECT   *
    FROM payroll pay
    WHERE 189170<>ALL(SELECT pay.salary FROM payroll pay2)
    AND per.empid=pay.empid)
ORDER BY per.empid, per.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 13 ms
-- Average Execution 29372.80 ms
