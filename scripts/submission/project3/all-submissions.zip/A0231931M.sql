/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231931M                               */
/******************************************************************************/
/*
SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170
 ORDER BY per.empid , per.lname;
*/

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/


SELECT per.empid, per.lname 
FROM employee per RIGHT OUTER JOIN payroll pay 
	ON per.empid = pay.empid 
AND pay.salary = 189170 
WHERE per.empid is NOT NULL
ORDER BY per.empid, per.lname;


/*
SELECT test('SELECT per.empid, per.lname 
FROM employee per RIGHT OUTER JOIN payroll pay 
	ON per.empid = pay.empid 
AND pay.salary = 189170 
WHERE per.empid is NOT NULL
ORDER BY per.empid, per.lname;', 100)
*/

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.05> ms
-- Average Execution <2.78> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/


SELECT per.empid, per.lname
FROM employee per, (SELECT TRUE) AS temp, payroll pay
	WHERE TRUE AND per.empid = pay.empid AND pay.salary = 189170
ORDER BY per.empid, per.lname;


/*

SELECT test('SELECT per.empid, per.lname
FROM employee per, (SELECT TRUE) AS temp, payroll pay
	WHERE TRUE AND per.empid = pay.empid AND pay.salary = 189170
ORDER BY per.empid, per.lname;', 100)
*/


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.05> ms
-- Average Execution <2.34> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/



SELECT per.empid, per.lname
FROM employee per WHERE NOT EXISTS (
	SELECT pay.empid
	FROM payroll as pay
	WHERE per.empid=pay.empid AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;


/*
SELECT test('SELECT per.empid, per.lname
FROM employee per WHERE NOT EXISTS 
(SELECT pay.empid
FROM payroll as pay
WHERE per.empid=pay.empid AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;', 100)
*/

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.05> ms
-- Average Execution <4.73> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/


SELECT per.empid, per.lname
FROM employee per
WHERE 
	per.empid IN ( SELECT pay.empid 
		FROM payroll pay 
		WHERE per.empid = pay.empid)
	AND per.empid NOT IN ( SELECT pay.empid 
		FROM payroll pay 
		WHERE pay.salary < 189170
			OR pay.salary > 189170)
ORDER BY 
	per.empid, per.lname;

/*
SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE 
	per.empid IN ( SELECT pay.empid 
		FROM payroll pay 
		WHERE per.empid = pay.empid)
	AND per.empid NOT IN ( SELECT pay.empid 
		FROM payroll pay 
		WHERE pay.salary < 189170
			OR pay.salary > 189170)
ORDER BY 
	per.empid, per.lname;', 100)
*/


-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.06> ms
-- Average Execution <192.02> ms


