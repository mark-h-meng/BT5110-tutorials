/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231868W                               */
/******************************************************************************/
 SELECT per.empid, per.lname
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid
 AND pay.salary = 189170;

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.10 ms
-- Average Execution 2.29 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary from payroll) AS temp
WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.12 ms
-- Average Execution 2.91 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT * from payroll pay1
	  WHERE pay1.empid = per.empid
	  AND NOT EXISTS (
	  SELECT * from payroll pay2
	  WHERE pay2.empid = per.empid
	  AND pay2.salary = 189170))
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.16 ms
-- Average Execution 6.41 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT * FROM
(SELECT per.empid, per.lname
FROM (SELECT empid, fname, lname FROM employee) per
FULL OUTER JOIN
(SELECT empid FROM payroll) pay
ON per.empid = pay.empid
EXCEPT
SELECT per.empid, per.lname
FROM (SELECT empid, fname, lname FROM employee) per
FULL OUTER JOIN
(SELECT empid FROM payroll) pay
ON per.empid = pay.empid
WHERE NOT EXISTS (
   SELECT * from payroll pay1
 WHERE pay1.empid = per.empid
 AND EXISTS (
 SELECT * from payroll pay2
 WHERE pay2.empid = per.empid
 AND pay2.salary = 189170))
AND per.fname = ANY (
SELECT fname FROM employee)) d
GROUP BY empid, lname
ORDER BY empid, lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.52 ms
-- Average Execution 37.31 ms
