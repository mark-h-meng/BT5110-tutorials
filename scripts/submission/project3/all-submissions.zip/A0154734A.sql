/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0154734A                              */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.07 ms
-- Average Execution 1.80 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary from payroll pay) AS temp
	WHERE per.empid = temp.empid and temp.salary = 189170
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.06 ms
-- Average Execution 1.64 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid, pay.salary from payroll pay where per.empid = pay.empid and pay.salary != 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.07 ms
-- Average Execution 3.73 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT temp.empid, temp.lname
FROM (SELECT per.empid, per.lname, pay.empid AS p_empid, pay.salary
FROM employee per, payroll pay
	  WHERE per.empid = pay.empid
EXCEPT
SELECT per.empid, per.lname, pay.empid AS p_empid, pay.salary
FROM employee per, payroll pay
WHERE pay.salary != 189170) AS temp
ORDER BY temp.empid, temp.lname


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.19 ms
-- Average Execution 47562.85 ms
