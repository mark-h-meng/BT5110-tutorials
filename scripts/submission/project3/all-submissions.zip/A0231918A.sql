/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231918A                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.26 ms
-- Average Execution 5.55 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll WHERE salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.26 ms
-- Average Execution 5.12 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
SELECT * FROM payroll pay WHERE per.empid = pay.empid AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.26 ms
-- Average Execution 12.13 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE (per.empid, per.lname) NOT IN (
SELECT per1.empid, per1.lname
FROM employee per1, payroll pay
WHERE per1.empid = pay.empid
AND pay.salary > 189170
UNION
SELECT per1.empid, per1.lname
FROM employee per1, payroll pay
WHERE per1.empid = pay.empid
AND pay.salary < 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.49 ms
-- Average Execution 48.04 ms
