/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231902R                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid
    AND pay.salary = 189170
WHERE per.empid is not NULL
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.11> ms
-- Average Execution <2.92> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
	WHERE per.empid is not NULL
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.05> ms
-- Average Execution <8.16> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid , per. lname
FROM employee per
where empid is NULL
and lname is NULL
order by per.empid , per.lname;


-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.03> ms
-- Average Execution <0.82> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, payroll pay
where per.empid = pay.empid
and per.empid not in(
    (select per2.empid
    from employee per2, payroll pay2
    where per2.empid = pay2.empid
    and pay2.salary <> 189170)
);


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.25> ms
-- Average Execution <23.77> ms

SELECT per.empid, per.lname
FROM employee per
EXCEPT
Select per2.empid, per2.lname
from employee per2
where per2.empid is NULL
order by empid, lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.08> ms
-- Average Execution <67.77> ms

SELECT per.empid , per. lname
FROM employee per
where per.empid in (
    select per2.empid
    from employee per2
    where per2.empid is NULL)
and per.lname in (
    select per3.lname
    from employee per3
    where per3.lname is null)
order by empid , lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.17> ms
-- Average Execution <0.81> ms