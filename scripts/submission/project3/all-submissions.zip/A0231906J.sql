/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231906J                               */
/******************************************************************************/

 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay ON per.empid = pay.empid
WHERE pay.salary = '189170'
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.06> ms
-- Average Execution <1.70> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
 
SELECT per.empid, per.lname
FROM employee per, payroll pay 
WHERE per.empid = pay.empid
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.08> ms
-- Average Execution <7.84> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid
	FROM payroll pay)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.02> ms
-- Average Execution <0.01> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
 
SELECT per.empid, per.lname
FROM employee per LEFT OUTER JOIN payroll pay ON per.empid = pay.empid
WHERE pay.salary IN (SELECT pa.salary					 
					 FROM employee em LEFT OUTER JOIN payroll pa ON em.empid = pa.empid
					 WHERE pa.salary > 189160)
AND pay.salary IN (SELECT pa.salary					 
					 FROM employee em LEFT OUTER JOIN payroll pa ON em.empid = pa.empid
					 WHERE pa.salary > 189161)
AND pay.salary IN (SELECT pa.salary					 
					 FROM employee em LEFT OUTER JOIN payroll pa ON em.empid = pa.empid
					 WHERE pa.salary > 189162)
AND pay.salary IN (SELECT pa.salary					 
					 FROM employee em LEFT OUTER JOIN payroll pa ON em.empid = pa.empid
					 WHERE pa.salary > 189163)
AND pay.salary IN (SELECT pa.salary					 
					 FROM employee em LEFT OUTER JOIN payroll pa ON em.empid = pa.empid
					 WHERE pa.salary > 189164)
AND pay.salary IN (SELECT pa.salary					 
					 FROM employee em LEFT OUTER JOIN payroll pa ON em.empid = pa.empid
					 WHERE pa.salary > 189165)
AND pay.salary IN (SELECT pa.salary					 
					 FROM employee em LEFT OUTER JOIN payroll pa ON em.empid = pa.empid
					 WHERE pa.salary > 189166)
AND pay.salary IN (SELECT pa.salary					 
					 FROM employee em LEFT OUTER JOIN payroll pa ON em.empid = pa.empid
					 WHERE pa.salary > 189167)
AND pay.salary IN (SELECT pa.salary					 
					 FROM employee em LEFT OUTER JOIN payroll pa ON em.empid = pa.empid
					 WHERE pa.salary > 189168)
AND pay.salary IN (SELECT pa.salary					 
					 FROM employee em LEFT OUTER JOIN payroll pa ON em.empid = pa.empid
					 WHERE pa.salary > 189169)
AND pay.salary <= ANY (SELECT pa.salary
				   FROM employee em LEFT OUTER JOIN payroll pa ON em.empid = pa.empid
				   WHERE pa.salary < 189171)
ORDER BY per.empid, per.lname;

SELECT per.empid, per.lname
FROM employee per LEFT OUTER JOIN payroll pay ON per.empid = pay.empid 
WHERE EXISTS (SELECT *
			 FROM employee em LEFT OUTER JOIN payroll pa ON em.empid = pa.empid
			 WHERE pa.salary >= 10
			 UNION
			 SELECT *
			 FROM employee em LEFT OUTER JOIN payroll pa ON em.empid = pa.empid
			 WHERE pa.salary >= 20
			 UNION
			 SELECT *
			 FROM employee em LEFT OUTER JOIN payroll pa ON em.empid = pa.empid
			 WHERE pa.salary <= 10000000000 )
ORDER BY per.empid, per.lname;

SELECT per.empid, per.lname
FROM employee per LEFT OUTER JOIN payroll pay ON per.empid = pay.empid
WHERE NOT EXISTS (
    SELECT pay.empid, pay.salary
	FROM payroll pay
	WHERE pay.salary <= 0)
AND NOT EXISTS (
    SELECT pay.empid, pay.salary
	FROM payroll pay
	WHERE pay.salary <= 1)
AND NOT EXISTS (
    SELECT pay.empid, pay.salary
	FROM payroll pay
	WHERE pay.salary <= 100000)
ORDER BY per.empid, per.lname

/* Average planning and execution time for each query: */
/* 1.38/658.80 */
/* 0.27/119.66 */
/* 0.13/8.49   */

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <1.78> ms
-- Average Execution <786.95> ms
