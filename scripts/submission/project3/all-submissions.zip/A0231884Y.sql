/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231884Y                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.09> ms
-- Average Execution <2.08> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary from payroll pay) AS temp
	WHERE per.empid = temp.empid and temp.salary = 189170
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.09> ms
-- Average Execution <1.91> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT *
	from payroll pay
	where per.empid = pay.empid and pay.salary != 189170)
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.09> ms
-- Average Execution <4.20> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
select per.empid, per.lname
from employee per
where per.empid <> ALL (
	select tt.empid
	from
	(select *
	from employee per
	where per.empid <> ALL(
		select pay.empid
		from payroll pay
		where pay.salary > 189169)
	or per.empid <> ALL(
		select pay.empid
		from payroll pay
		where pay.salary < 189171)) tt)
order by per.empid, per.lname;


-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.22> ms
-- Average Execution <8168.98> ms
