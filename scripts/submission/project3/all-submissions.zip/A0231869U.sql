/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231869U                               */
/******************************************************************************/
 SELECT per.empid, per.lname
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid
 AND pay.salary = 189170;

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per . empid , per . lname
FROM employee per RIGHT OUTER JOIN payroll pay
ON per.empid = pay.empid AND pay . salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per . empid , per . lname ;


-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.18> ms
-- Average Execution <6.90> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary FROM payroll WHERE salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.16> ms
-- Average Execution <6.11> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT * FROM payroll pay WHERE per.empid = pay.empid AND salary <> 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.18> ms
-- Average Execution <13.78> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT a.empid, a.lname
FROM (
(SELECT per.empid AS empid1, per.lname, per.fname, per.address, per.city, per.state, per.zip, pay1.empid, pay1.bonus, pay1.salary
FROM employee per FULL OUTER JOIN payroll pay1
ON per.empid = pay1.empid
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname)
INTERSECT
(SELECT * FROM employee per FULL OUTER JOIN payroll pay1
ON per.empid = pay1.empid
WHERE per.empid IS NOT NULL
AND NOT EXISTS (
    SELECT * FROM payroll pay2 WHERE per.empid = pay2.empid AND salary <> 189170)
ORDER BY per.empid, per.lname)) a
ORDER BY a.empid, a.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.69> ms
-- Average Execution <122.87> ms
