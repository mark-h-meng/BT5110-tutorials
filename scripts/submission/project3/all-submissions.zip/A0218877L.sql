/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0218877L                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170;
 -- 11
 
SELECT test (' SELECT per.empid , per.lname
FROM employee per , payroll pay
WHERE per. empid = pay. empid 
AND pay. salary = 189170; ' , 100) ;
-- 0.07 : 1.89
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

SELECT test (' SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname; ' , 100) ;
-- 0.07 : 1.86

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.07 ms
-- Average Execution 1.86 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll pay1 WHERE pay1.salary=189170) pay
	WHERE per.empid=pay.empid
ORDER BY per.empid, per.lname;

SELECT test (' SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll pay1 WHERE pay1.salary=189170) pay
	WHERE per.empid=pay.empid
ORDER BY per.empid, per.lname; ' , 100) ;
-- 0.07 : 1.82

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.07 ms
-- Average Execution 1.82 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
	SELECT * FROM payroll pay
	WHERE per.empid = pay.empid
	AND pay.salary<>189170)
ORDER BY per.empid, per.lname;

SELECT test (' SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
	SELECT * FROM payroll pay
	WHERE per.empid = pay.empid
	AND pay.salary<>189170)
ORDER BY per.empid, per.lname; ' , 100) ;
-- 0.10 : 3.91

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.10 ms
-- Average Execution 3.91 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS(
	SELECT * FROM employee per1, payroll pay
	WHERE per.empid = pay.empid
	AND per.empid = per1.empid
	AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;
-- Quite long, 4-6 min

SELECT test (' SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS(
	SELECT * FROM employee per1, payroll pay
	WHERE per.empid = pay.empid
	AND per.empid = per1.empid
	AND pay.salary <> 189170)
ORDER BY per.empid, per.lname; ' , 20) ;
-- 1.02 : 288212.18

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 1.02 ms
-- Average Execution 288212.18 ms
