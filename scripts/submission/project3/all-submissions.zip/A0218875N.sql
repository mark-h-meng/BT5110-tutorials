/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0218875N                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay
	ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid = pay.empid
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.13 ms
-- Average Execution 3.43 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid, pay.salary FROM payroll pay WHERE pay.salary = 189170 ) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.14 ms
-- Average Execution 3.58 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (SELECT pay.empid
	FROM payroll pay
	WHERE per.empid = pay.empid
	AND pay.salary != 189170
	) 
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.15 ms
-- Average Execution 7.83 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
WITH S1 AS 
(SELECT per.empid, per.lname
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
EXCEPT 
SELECT pay.empid, per.lname
FROM employee per, payroll pay
WHERE pay.salary != 189170) 

SELECT *
FROM S1
ORDER BY S1.empid, S1.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.23 ms
-- Average Execution 10563.03 ms
