/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0060127U                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid = pay.empid
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.15 ms
-- Average Execution 3.39 ms
	

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * 
				   FROM employee AS per1, payroll AS pay
				   WHERE per1.empid = pay.empid
				   AND pay.salary = 189170) AS temp
WHERE per.lname= temp.lname
ORDER BY per.empid, per.lname;

 

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.21 ms
-- Average Execution 5.73 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (SELECT pay.empid
				 FROM payroll as pay
				 WHERE per.empid=pay.empid
				 AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.14 ms
-- Average Execution 7.87 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee AS per, payroll AS pay
WHERE pay.salary = 189170
AND per.empid=pay.empid
AND per.empid <> ALL (SELECT per1.empid
				 FROM payroll as pay1,  employee AS per1
				 WHERE per1.empid=pay1.empid
				 AND pay1.salary <> 189170)
	AND per.empid = ANY (SELECT per2.empid
				FROM payroll as pay2,  employee AS per2
				WHERE per2.empid=pay2.empid
				AND pay2.salary = 189170)
GROUP BY per.empid, per.lname
ORDER BY per.empid, per.lname;



-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.33 ms
-- Average Execution 28490.21 ms
