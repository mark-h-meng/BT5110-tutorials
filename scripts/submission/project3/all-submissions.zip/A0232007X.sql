/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232007X                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 --  0.07 : 2.24
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON pay.salary = 189170
where pay.empid=per.empid
ORDER BY per.empid, per.lname;
-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.08 ms
-- Average Execution 2.47 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid,salary from payroll where salary=189170) AS temp
	WHERE temp.empid=per.empid
ORDER BY per.empid, per.lname;
 
-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.08 ms
-- Average Execution 2.43 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT salary from payroll pay where pay.empid=per.empid and salary != 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.09 ms
-- Average Execution 5.02 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
select empid,lname
from employee per
where empid <> all (select empid from payroll pay where salary <> 189170 and bonus is not null)
order by empid,lname;
-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.07 ms
-- Average Execution 5521.03 ms