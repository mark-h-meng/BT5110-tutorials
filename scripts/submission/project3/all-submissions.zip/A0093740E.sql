/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0093740E                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
/**SELECT per.empid, per.lname
	FROM employee per RIGHT OUTER JOIN payroll pay 
    	ON TRUE AND pay.salary = 189170
	WHERE TRUE
	ORDER BY per.empid, per.lname;**/

-- Only modify the "ON" and "WHERE" clauses (replace the occurrences of "TRUE" only)

SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 100 executions for the query.
SELECT test('SELECT per.empid, per.lname
			FROM employee per RIGHT OUTER JOIN payroll pay 
    			ON per.empid = pay.empid AND pay.salary = 189170
			WHERE per.empid IS NOT NULL
			ORDER BY per.empid, per.lname;', 100);

-- (replace <time> with the average time reported by test function).
-- Average Planning <0.1> ms
-- Average Execution <5.03> ms



/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
/**SELECT per.empid, per.lname
	FROM employee per, (SELECT TRUE) AS temp
		WHERE TRUE
	ORDER BY per.empid, per.lname;**/
 
-- Only modify the "FROM" and "WHERE" clauses (replace the occurrences of "TRUE" only)

SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.

SELECT test('SELECT per.empid, per.lname
FROM employee per, (SELECT * FROM payroll pay WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;', 100);

-- (replace <time> with the average time reported by test function).
-- Average Planning <0.11> ms
-- Average Execution <4.78> ms



/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
/**SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT TRUE)
ORDER BY per.empid, per.lname;**/

-- Only modify the "WHERE" clauses of the subquery (replace the occurrences of "TRUE" only)

SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (SELECT *FROM payroll pay
         		WHERE pay.empid = per.empid AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.

SELECT test('SELECT per.empid, per.lname
			FROM employee per
			WHERE NOT EXISTS (SELECT *FROM payroll pay
         					WHERE pay.empid = per.empid AND pay.salary <> 189170)
			ORDER BY per.empid, per.lname;', 100);

-- (replace <time> with the average time reported by test function).
-- Average Planning <0.12> ms
-- Average Execution <10.14> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per
WHERE
(SELECT salary FROM payroll pay WHERE pay.empid = per.empid) = 189170
ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.

SELECT test('SELECT per.empid, per.lname
			FROM employee per
			WHERE
			(SELECT salary FROM payroll pay WHERE pay.empid = per.empid) = 189170
			ORDER BY per.empid, per.lname;', 20);

-- (replace <time> with the average time reported by test function).
-- Average Planning <0.08> ms
-- Average Execution <15222.57> ms
