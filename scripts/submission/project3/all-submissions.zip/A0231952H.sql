/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231952H                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null
ORDER BY per.empid, per.lname;', 100);

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.16> ms
-- Average Execution <4.61> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid from payroll pay where pay.salary = 189170) AS temp
	WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid from payroll pay where pay.salary = 189170) AS temp
	WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname;', 100);

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.16> ms
-- Average Execution <4.18> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT * from payroll pay where pay.salary <> 189170 and per.empid = pay.empid)
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT * from payroll pay where pay.salary <> 189170 and per.empid = pay.empid)
ORDER BY per.empid, per.lname;', 100);

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.17> ms
-- Average Execution <9.38> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
select distinct per.empid, per.lname
from employee per
where per.empid not in (
	select distinct per.empid from employee per
	intersect
	select distinct pay.empid from payroll pay
	where pay.salary <> 189170)
order by per.empid, per.lname;
 
SELECT test('select distinct per.empid, per.lname
from employee per
where per.empid not in (
	select distinct per.empid from employee per
	intersect
	select distinct pay.empid from payroll pay
	where pay.salary <> 189170)
order by per.empid, per.lname;', 20);

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.16> ms
-- Average Execution <38.60> ms
