/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231849X                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid,per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid=pay.empid  AND pay.salary = 189170
where per.empid is not null
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.04> ms
-- Average Execution <2.14> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid from payroll where salary=189170) AS temp
	WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname;
 
-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.03> ms
-- Average Execution <2.08> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT empid from payroll where payroll.salary<>189170 and per.empid=payroll.empid)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.05> ms
-- Average Execution <4.27> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid,per.lname FROM employee per
WHERE NOT EXISTS (SELECT empid from payroll where payroll.salary>189171 and per.empid=payroll.empid)
intersect
SELECT per1.empid,per1.lname FROM employee per1
WHERE NOT EXISTS (SELECT empid from payroll where payroll.salary<189170 and per1.empid=payroll.empid)
except
SELECT per2.empid,per2.lname FROM employee per2
WHERE NOT EXISTS (SELECT empid from payroll where payroll.salary<>189171 and per2.empid=payroll.empid)
order by empid,lname;

/* Because I found that from the question 2, the query with subqueries would take a longer time to execute. */
/* I tried to combine it with the 'intersect' and 'expect'. So, my answer logic is a set that has the salary between 189170 and 189171 but not 189171.*/
/* Actually by applying set theory in this question, I can keep expanding the time of execution by making more set logic.*/

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.13> ms
-- Average Execution <13.80> ms
