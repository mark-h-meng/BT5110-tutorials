/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0124216U                              */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170;

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.09 ms
-- Average Execution 2.63 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (
SELECT *
FROM payroll pay 
WHERE pay.salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.11 ms
-- Average Execution 2.81 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
SELECT *
FROM payroll pay
WHERE pay.empid = per.empid 
AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.11 ms
-- Average Execution 5.44 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT distinct per.empid, per.lname
FROM employee per, payroll pay
where pay.empid not in (
	select per2.empid
	from employee per2
	where per2.empid<>pay.empid
	or not ((pay.salary > ALL(
		select pay3.salary
		from payroll pay3
		where pay3.salary < 189170))
	and (pay.salary < ALL(
		select pay3.salary
		from payroll pay3
		where pay3.salary > 189170))
	)
)
and per.empid not in (
	select pay2.empid
	from payroll pay2
	where pay2.empid<>per.empid
	or (pay2.empid=per.empid 
	and not ((pay2.salary > ALL(
		select pay3.salary
		from payroll pay3
		where pay3.salary < 189170))
	and (pay2.salary < ALL(
		select pay3.salary
		from payroll pay3
		where pay3.salary > 189170))
	))
)
order by per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.25 ms
-- Average Execution 28190.88 ms
