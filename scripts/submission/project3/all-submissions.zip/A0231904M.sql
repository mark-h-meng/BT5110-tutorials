/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231904M                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.48 ms
-- Average Execution 13.75 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid
					FROM payroll pay
					WHERE pay.salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.36 ms
-- Average Execution 8.86 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT *
	FROM payroll pay
	WHERE per.empid = pay.empid
	AND pay.salary != 189170)
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.23 ms
-- Average Execution 20.72 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT c.emp_id, c.lname
FROM (SELECT *
	  FROM (SELECT per.empid emp_id, per.lname
		   	FROM employee per) a FULL OUTER JOIN
	  		(SELECT pay.empid pay_id, pay.salary
			FROM payroll pay) b
	  		ON a.emp_id = b.pay_id) c
WHERE c.salary NOT IN(
	SELECT pay1.salary
	FROM payroll pay1
	WHERE pay1.salary != 189170)
ORDER BY c.emp_id, c.lname;


-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 1.08 ms
-- Average Execution 38.90 ms
