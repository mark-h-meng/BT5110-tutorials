/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231941L                             */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid=pay.empid AND pay.salary = 189170
WHERE per.empid NOTNULL
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.21 ms
-- Average Execution 8.33 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid FROM payroll pay 
				    WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.20 ms
-- Average Execution 7.57 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid, per.lname
	FROM payroll pay
	WHERE pay.empid=per.empid
	AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.21 ms
-- Average Execution 16.66 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN (
	SELECT per.empid
	FROM employee per
	WHERE EXISTS (
    	SELECT pay.empid
		FROM payroll pay
		WHERE pay.empid = per.empid
		AND pay.salary > 189170)
	UNION
	SELECT per.empid
	FROM employee per
	WHERE EXISTS (
    	SELECT pay.empid
		FROM payroll pay
		WHERE pay.empid=per.empid
		AND pay.salary < 189170))
ORDER BY per.empid;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.62 ms
-- Average Execution 69.14 ms
