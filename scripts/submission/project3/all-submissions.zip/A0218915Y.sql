/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0218915Y                              */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 100 executions for the query.
SELECT test('SELECT per.empid, per.lname
			FROM employee per RIGHT OUTER JOIN payroll pay 
				ON per.empid = pay.empid AND pay.salary = 189170
			WHERE per.empid IS NOT NULL
			ORDER BY per.empid, per.lname;',100);
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.10> ms
-- Average Execution <2.39> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid FROM payroll WHERE salary =189170 ) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 100 executions for the query.
SELECT test('SELECT per.empid, per.lname
			FROM employee per, (SELECT empid FROM payroll WHERE salary =189170 ) AS temp
				WHERE per.empid = temp.empid
			ORDER BY per.empid, per.lname;',100);
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.11> ms
-- Average Execution <2.48> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT * FROM payroll pay WHERE per.empid = pay.empid AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
SELECT test('SELECT per.empid, per.lname
			FROM employee per
			WHERE NOT EXISTS (
				SELECT * FROM payroll pay WHERE per.empid = pay.empid AND pay.salary <> 189170)
			ORDER BY per.empid, per.lname;',100);
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.11> ms
-- Average Execution <4.71> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT test('SELECT per.empid, per.lname
			FROM employee per
			WHERE(SELECT COUNT(pay.salary) 
				  FROM payroll pay LEFT OUTER JOIN employee ON per.empid = pay.empid
				  WHERE per.empid IS NOT NULL AND pay.salary = 189170) > 0	
			ORDER BY per.empid, per.lname;',20);
-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.12> ms
-- Average Execution <61719.32> ms
