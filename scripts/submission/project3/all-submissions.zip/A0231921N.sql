/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231921N                               */
/******************************************************************************/

 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;

-- Average Planning <0.02> ms
-- Average Execution <1.93> ms

/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
--SELECT per.empid, per.lname
--FROM employee per RIGHT OUTER JOIN payroll pay 
--    ON TRUE AND pay.salary = 189170
--WHERE TRUE
--ORDER BY per.empid, per.lname;

SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.05> ms
-- Average Execution <2.09> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
--SELECT per.empid, per.lname
--FROM employee per, (SELECT TRUE) AS temp
--	WHERE TRUE
--ORDER BY per.empid, per.lname;

SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid
				   FROM payroll pay
				   WHERE pay.salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname; 

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.04> ms
-- Average Execution <2.01> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
-- SELECT per.empid, per.lname
-- FROM employee per
-- WHERE NOT EXISTS (
--     SELECT TRUE)
-- ORDER BY per.empid, per.lname;

SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
   SELECT *
   FROM payroll pay
   WHERE pay.salary <> 189170
	AND per.empid = pay.empid)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.04> ms
-- Average Execution <4.20> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per_id, lname 
FROM (
	SELECT *
	FROM (
			SELECT per.empid per_id, pay.empid pay_id, per.lname, pay.salary, 
				RANK() OVER(ORDER BY per.empid::INTEGER DESC) perid_rank, 
				RANK() OVER(ORDER BY pay.empid::INTEGER DESC) payid_rank
			FROM employee per, payroll pay
			) id_match
	WHERE perid_rank = payid_rank 
			AND salary NOT IN (
				SELECT salary
				FROM payroll
				GROUP BY salary
				HAVING salary < 189170)
	
	INTERSECT
	
	SELECT *
	FROM (
			SELECT per.empid per_id, pay.empid pay_id, per.lname, pay.salary, 
				RANK() OVER(ORDER BY per.empid::INTEGER DESC) perid_rank, 
				RANK() OVER(ORDER BY pay.empid::INTEGER DESC) payid_rank
			FROM employee per, payroll pay
			) id_match
	WHERE perid_rank = payid_rank 
			AND salary NOT IN( 
				SELECT salary
				FROM payroll
				GROUP BY salary
				HAVING salary > 189170)
	) filtered
ORDER BY per_id, lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.93> ms
-- Average Execution <1058097.03> ms