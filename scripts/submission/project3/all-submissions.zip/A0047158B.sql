/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0047158B                              */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per 
RIGHT OUTER JOIN payroll pay ON pay.empid = per.empid 
	AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.08> ms
-- Average Execution <2.19> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (
	SELECT pay.empid, pay.salary
	FROM payroll pay
	WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
 
-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.09> ms
-- Average Execution <2.01> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT *
	FROM employee per1, payroll pay
	WHERE pay.salary <> 189170
	AND per1.empid = pay.empid
	AND per.empid = per1.empid)
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.12> ms
-- Average Execution <8.46> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT *
	FROM employee per1
	LEFT OUTER JOIN (
		SELECT * 
		FROM payroll pay
		WHERE NOT EXISTS (
			SELECT * 
			FROM payroll pay1
			WHERE NOT EXISTS (
				SELECT * 
				FROM payroll pay2 
				WHERE NOT EXISTS (
					SELECT * 
					FROM payroll pay3 
					WHERE pay3.salary <= 189170
					AND pay3.empid = pay2.empid)
				AND pay1.empid = pay2.empid)
			AND NOT EXISTS (
				SELECT * 
				FROM payroll pay4 
				WHERE NOT EXISTS (
					SELECT * 
					FROM payroll pay5 
					WHERE pay5.salary >= 189170
					AND pay5.empid = pay4.empid)
				AND pay1.empid = pay4.empid)
			AND pay1.empid = pay.empid))AS temp ON temp.empid = per1.empid
	WHERE temp.salary IN (
		SELECT temp2.salary 
		FROM (
			SELECT * 
			FROM payroll pay6
			WHERE NOT EXISTS (
				SELECT * 
				FROM payroll pay7
				WHERE NOT EXISTS (
					SELECT * 
					FROM payroll pay8 
					WHERE NOT EXISTS (
						SELECT * 
						FROM payroll pay9 
						WHERE pay9.salary <= 189170
						AND pay9.empid = pay8.empid)
					AND pay7.empid = pay8.empid)
				AND NOT EXISTS (
					SELECT * 
					FROM payroll pay10 
					WHERE NOT EXISTS (
						SELECT * 
						FROM payroll pay11 
						WHERE pay11.salary >= 189170
						AND pay11.empid = pay10.empid)
					AND pay7.empid = pay10.empid)
				AND pay7.empid = pay6.empid))AS temp2)
	AND per1.empid = temp.empid
	AND per.empid = per1.empid)
ORDER BY per.empid, per.lname;


-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.56> ms
-- Average Execution <35.11> ms
