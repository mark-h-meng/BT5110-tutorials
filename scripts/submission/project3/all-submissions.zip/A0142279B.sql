/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0142279B                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay. salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.09> ms
-- Average Execution <1.87> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid FROM payroll WHERE payroll.salary=189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.07> ms
-- Average Execution <1.76> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT empid FROM payroll pay
	WHERE pay.salary <> 189170 AND pay.empid=per.empid)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.07> ms
-- Average Execution <3.76> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
 SELECT e.empid, e.lname FROM employee e
WHERE e.empid IN
(SELECT e1.empid FROM employee e1, payroll p1
WHERE p1.empid = e1.empid AND
p1.salary NOT IN
(SELECT p2.salary FROM payroll p2
WHERE p2.salary > 189170 AND p2.empid = p1.empid AND p2.empid = e.empid))
AND e.empid IN
(SELECT e2.empid FROM employee e2, payroll p3
WHERE p3.empid = e2.empid AND
p3.salary NOT IN
(SELECT p4.salary FROM payroll p4
WHERE p4.salary < 189170 AND p4.empid = p3.empid AND p4.empid = e.empid));

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.32> ms
-- Average Execution <268547.81> ms
