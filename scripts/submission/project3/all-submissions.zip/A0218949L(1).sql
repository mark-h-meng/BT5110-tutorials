/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0218949L                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE NOT per.empid ISNULL
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0:13 ms
-- Average Execution 5:20 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid 
				    FROM payroll pay
				    WHERE pay.salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0:12 ms
-- Average Execution 4:72 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT 1
	FROM payroll pay
	WHERE pay.salary<>189170
	AND per.empid = pay.empid)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0:15 ms
-- Average Execution 10:18 ms

/******************************************************************************/
/* Answer Question 3 below                                                    */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE per.empid IN (
	SELECT emp.empid
	FROM employee emp, payroll pay
	WHERE emp.empid = pay.empid
	AND pay.salary IN (
		SELECT pay2.salary
		FROM payroll pay2
		WHERE per.empid = pay2.empid
		AND pay.empid = pay2.empid
		AND pay2.salary > 189169
		AND pay2.salary <= ANY (
			SELECT pay3.salary 
			FROM payroll pay3
			WHERE per.empid = pay3.empid
			AND pay.empid = pay3.empid
			AND pay2.empid = pay3.empid
			AND pay3.salary < 189171)
	)
);
-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.28 ms
-- Average Execution 109202.47 ms