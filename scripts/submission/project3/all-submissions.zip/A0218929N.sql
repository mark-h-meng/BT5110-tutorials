/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0218929N                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.15 ms
-- Average Execution 4.61 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT *
				    FROM payroll pay
				    WHERE pay.salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.15 ms
-- Average Execution 4.31 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid
	FROM payroll pay
	WHERE per.empid = pay.empid
	AND pay.salary != 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.16 ms
-- Average Execution 9.52 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per
WHERE per.empid NOT IN
		((SELECT pay1.empid
		FROM payroll pay1
		WHERE pay1.salary IN
			(SELECT pay5.salary
			 FROM payroll pay5
			 WHERE pay5.salary - 189170 > 0 
			 AND per.empid = pay5.empid
			 AND pay1.empid = pay5.empid)
		EXCEPT
		SELECT pay2.empid
		FROM payroll pay2
		WHERE pay2.salary IN
			(SELECT pay6.salary
			FROM payroll pay6
			WHERE pay6.salary - 189170 < 0
			AND per.empid = pay6.empid
			AND pay2.empid = pay6.empid))
		UNION
		(SELECT pay3.empid
		FROM payroll pay3
		WHERE pay3.salary IN
		  	(SELECT pay7.salary
			FROM payroll pay7
			WHERE pay7.salary - 189170 < 0
			AND per.empid = pay7.empid
			AND pay3.empid = pay7.empid)
		 EXCEPT
		 SELECT pay4.empid
		 FROM payroll pay4
		 WHERE pay4.salary IN
		 	(SELECT pay8.salary
			FROM payroll pay8
			WHERE pay8.salary - 189170 > 0
			AND per.empid = pay8.empid
			AND pay4.empid = pay8.empid)))
ORDER BY per.empid, per.lname;


-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.87 ms
-- Average Execution 358110 ms
