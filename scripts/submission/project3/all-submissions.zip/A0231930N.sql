/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231930N                               */
/******************************************************************************/

 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
    RIGHT OUTER JOIN payroll pay
    ON per.empid = pay.empid
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.11> ms
-- Average Execution <2.67> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/

SELECT per.empid , per.lname
FROM employee per, (SELECT pay.empid,pay.salary FROM payroll pay WHERE pay.salary = 189170) AS salary 
WHERE per.empid = salary.empid
ORDER BY per.empid , per.lname;
 

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.12> ms
-- Average Execution <2.84> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
 SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.salary 
	FROM payroll pay
	WHERE per.empid = pay.empid
	AND pay.salary <> 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.13> ms
-- Average Execution <6.61> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/*   */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT * 
	FROM payroll pay
	WHERE per.empid = pay.empid
	AND pay.salary <> 189170
	AND EXISTS (
		SELECT * 
		FROM payroll pay
		WHERE pay.salary = 189170 
		AND EXISTS (SELECT DISTINCT COUNT(*)
				   FROM employee per
				   WHERE per.empid = pay.empid
				   AND per.lname NOT LIKE '%538487378938467' OR per.lname NOT LIKE '%9HD93HD93JDJ'
				   GROUP BY per.empid, per.city
				   HAVING pay.salary > 0 AND per.city <> 'Athens'
				   )
ORDER BY per.empid, per.lname))


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.29> ms
-- Average Execution <22.61> ms
