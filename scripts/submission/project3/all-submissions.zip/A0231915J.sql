/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231915J                              */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay ON per.empid = pay.empid AND pay.salary = 189170
where per.empid is not null
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay ON per.empid = pay.empid AND pay.salary = 189170
where per.empid is not null
ORDER BY per.empid, per.lname',100);

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.27> ms
-- Average Execution <8.32> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid,pay.salary from payroll pay where pay.salary=189170) AS temp
	WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid,pay.salary from payroll pay where pay.salary=189170) AS temp
	WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname',100);

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.21> ms
-- Average Execution <5.59> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
	SELECT * from payroll pay where pay.empid=per.empid and pay.salary<>189170)
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
	SELECT * from payroll pay where pay.empid=per.empid and pay.salary<>189170)
ORDER BY per.empid, per.lname',100);

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.26> ms
-- Average Execution <13.62> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT pay.empid,per.lname
 from employee per,payroll pay
 where pay.empid=any(select pay1.empid from employee per1,payroll pay1 where per1.empid=pay1.empid and pay1.salary=189170)
 and per.lname=any(select per1.lname from employee per1,payroll pay1 where per1.empid=pay1.empid and pay1.salary=189170)
 and per.empid=pay.empid
 order by per.empid,per.lname;


SELECT test('SELECT pay.empid,per.lname
from employee per,payroll pay
where pay.empid=any(select pay1.empid from employee per1,payroll pay1 where per1.empid=pay1.empid and pay1.salary=189170)
and per.lname=any(select per1.lname from employee per1,payroll pay1 where per1.empid=pay1.empid and pay1.salary=189170)
and per.empid=pay.empid
order by per.empid,per.lname',20);

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <1.79> ms
-- Average Execution <24.78> ms
