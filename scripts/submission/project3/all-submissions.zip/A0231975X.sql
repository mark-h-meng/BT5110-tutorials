/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231975X                               */
/******************************************************************************/
 CREATE TABLE employee (
  empid CHAR(9),
  lname CHAR(15),
  fname CHAR(12),
  address CHAR(20),
  city CHAR(20),
  state CHAR(2),
  zip CHAR(5)
);

CREATE TABLE payroll (
  empid CHAR(9),
  bonus INTEGER,
  salary INTEGER
);

CREATE or REPLACE FUNCTION random_string(length INTEGER) RETURNS TEXT AS 
$$
DECLARE
  chars TEXT[] := '{A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z}';
  result TEXT := '';
  i INTEGER := 0;
BEGIN
  IF length < 0 then
    RAISE EXCEPTION 'Given length cannot be less than 0';
  END IF;
  FOR i IN 1..length 
  LOOP
    result := result || chars[1+random()*(array_length(chars, 1)-1)];
  END LOOP;
  RETURN result;
END;
$$ LANGUAGE plpgsql;


INSERT INTO employee
SELECT
  TO_CHAR(g, '09999') AS empid,
  random_string(15) AS lname,
  random_string(12) AS fname,
  '500 ORACLE PARKWAY' AS address,
  'REDWOOD SHORES' AS city,
  'CA' AS state,
  '94065' AS zip
FROM
  generate_series(0, 9999) g;

INSERT INTO payroll(empid, bonus, salary)
SELECT
  per.empid,
  0 as bonus,
  99170 + ROUND(random() * 1000)*100 AS salary
FROM
  employee per;

CREATE OR REPLACE FUNCTION test (TEXT, INT) RETURNS TEXT AS
$$
DECLARE
r RECORD;
p TEXT;
e TEXT;
ap NUMERIC := 0;
ae NUMERIC := 0;
BEGIN
FOR i IN 1..$2
LOOP
	FOR r in EXECUTE 'EXPLAIN ANALYZE ' || $1
	LOOP
		IF  r::TEXT LIKE '%Planning%'
		THEN 
		p := regexp_replace( r::TEXT, '.*Planning (?:T|t)ime: (.*) ms.*', '\1');
		END IF;
		IF r::TEXT LIKE '%Execution%'
		THEN 
		e := regexp_replace( r::TEXT, '.*Execution (?:T|t)ime: (.*) ms.*', '\1');
		END IF;
	END LOOP;
	ap := ap + (p::NUMERIC - ap) / i;
	ae := ae + (e::NUMERIC - ae) / i;
END LOOP;
RETURN ROUND(ap, 2) || ' : ' || ROUND(ae, 2) ;
END;
$$ LANGUAGE plpgsql;

SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.lname notnull
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.07> ms
-- Average Execution <1.93> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, 
	(SELECT pay.empid, pay.salary
	FROM payroll pay) AS temp
WHERE temp.empid = per.empid
AND temp.salary = 189170
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.06> ms
-- Average Execution <1.74> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT per1.empid, per1.lname
	FROM employee per1, payroll pay
	WHERE per1.empid = pay.empid
	AND pay.salary <> 189170
	AND per.empid = per1.empid)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.13> ms
-- Average Execution <7.46> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM (
	SELECT per1.empid, per1.lname
	FROM employee per1) as per
	FULL OUTER JOIN(
	SELECT pay1.salary, pay1.empid
	FROM payroll pay1) as pay
    ON per.empid = pay.empid 
WHERE per.lname notnull
AND pay.empid notnull
AND per.empid <> ALL (
	SELECT per2.empid
	FROM employee per2, payroll pay2
	WHERE per2.empid = pay2.empid
	AND pay2.salary <> 189170)
ORDER BY per.empid, per.lname;


-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.17> ms
-- Average Execution <4319.22> ms. I guess this execution speed may be related to the slow running speed of my computer, and the acurate duration may need to be confirmed by the marking team.
