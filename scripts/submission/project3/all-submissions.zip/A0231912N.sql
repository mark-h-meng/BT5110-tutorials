/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231912N                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per LEFT OUTER JOIN payroll pay 
    ON per.empid = pay.empid  
	AND pay.salary = 189170
WHERE pay.salary is NOT NULL 
ORDER BY per.empid, per.lname;
	
SELECT test('SELECT per.empid, per.lname
	FROM employee per LEFT OUTER JOIN payroll pay 
    ON per.empid = pay.empid  
	AND pay.salary = 189170
	WHERE pay.salary is NOT NULL 
	ORDER BY per.empid, per.lname ',100);
-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.06> ms
-- Average Execution <1.76> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per,(SELECT pay.empid
				  FROM payroll pay
				  WHERE pay.salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
 
SELECT test('SELECT per.empid, per.lname
	FROM employee per,(SELECT pay.empid
				  FROM payroll pay
				  WHERE pay.salary = 189170) AS temp
	WHERE per.empid = temp.empid
	ORDER BY per.empid, per.lname',100);

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.06> ms
-- Average Execution <61.69> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per1.empid, per1.lname
FROM employee per1
WHERE NOT EXISTS(SELECT per.empid, per.lname
	FROM employee per, payroll pay 
    WHERE per.empid = pay.empid  
	AND pay.salary <> 189170
	AND per1.empid = per.empid)
ORDER BY per1.empid, per1.lname;

SELECT test('SELECT per1.empid, per1.lname
FROM employee per1
WHERE NOT EXISTS(SELECT per.empid, per.lname
	FROM employee per, payroll pay 
    WHERE per.empid = pay.empid  
	AND pay.salary <> 189170
	AND per1.empid = per.empid)
ORDER BY per1.empid, per1.lname',100);

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.12> ms
-- Average Execution <7.11> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT e.empid,e.lname
FROM employee e
WHERE NOT EXISTS(
	SELECT *
	FROM payroll p ,employee e2
WHERE NOT EXISTS(
	SELECT *
	FROM employee e1,payroll p1
	WHERE e.empid = e1.empid
	AND p1.salary = 189170
    AND e1.empid = p1.empid))

SELECT test('SELECT e.empid,e.lname
FROM employee e
WHERE NOT EXISTS(
	SELECT *
	FROM payroll p ,employee e2
WHERE NOT EXISTS(
	SELECT *
	FROM employee e1,payroll p1
	WHERE e.empid = e1.empid
	AND p1.salary = 189170
    AND e1.empid = p1.empid))',100);
	
-- Indicate the average measured time for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.18> ms
-- Average Execution <148986.12> ms
