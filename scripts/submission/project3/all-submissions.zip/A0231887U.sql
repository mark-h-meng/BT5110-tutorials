/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231887U                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid is not null
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.09 ms
-- Average Execution 2.79 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT * from payroll where salary = 189170) AS temp
	WHERE per.empid = temp.empid  
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.08 ms
-- Average Execution 2.66 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT empid from payroll pay where pay.empid = per.empid and pay.salary != 189170)
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.08 ms
-- Average Execution 5.08 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
select empid, lname
from (
	select e.*, t.empid as empid2, t.bonus, t.salary
	from (select * from employee group by 1,2,3,4,5,6,7 order by 1,2,3,4,5,6,7  ) as e
	cross join (
		select * from payroll as p group by 1,2,3 order by 1,2,3
	) t
	where 1=1
	group by 1,2,3,4,5,6,7,8,9,10
	having e.empid = t.empid
	order by 1,2,3,4,5,6,7,8,9,10
) t2
where 1=1 
  and t2.salary = 189170
group by 1,2
order by 1,2
;


-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.23 ms
-- Average Execution 7.88 ms
