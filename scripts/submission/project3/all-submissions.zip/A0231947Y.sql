/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231947Y                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <1.63> with the average time reported by test function).
-- Average Planning <0.04> ms
-- Average Execution <1.59> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid , pay.salary FROM payroll pay) AS temp
	WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;
 
-- Indicate the average measured times for 100 executions for the query.
-- (replace <1.53> with the average time reported by test function).
-- Average Planning <0.04> ms
-- Average Execution <1.49> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid, pay.salary FROM payroll pay
	WHERE per.empid = pay.empid AND pay.salary <> 189170 )
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <2.98> with the average time reported by test function).
-- Average Planning <0.05> ms
-- Average Execution <2.93> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
 SELECT per.empid, per.lname
 FROM employee per FULL OUTER JOIN payroll pay ON per.empid = pay.empid
 WHERE per.empid IS NOT NULL
 GROUP BY per.empid, per.lname
 Having SUM(pay.salary) = ANY
 (SELECT SUM(pay.salary)
 FROM payroll pay CROSS JOIN employee per
 WHERE per.empid = pay.empid AND pay.salary >= 189170
 UNION
 SELECT SUM(pay.salary)
 FROM payroll pay
 WHERE per.empid = pay.empid AND pay.salary <= 189170
 EXCEPT
 SELECT SUM(pay.salary)
 FROM payroll pay
 WHERE per.empid = pay.empid AND pay.salary <> 189170)
 ORDER BY per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <29022.18> with the average time reported by test function).
-- Average Planning <0.22> ms
-- Average Execution <29021.96> ms
