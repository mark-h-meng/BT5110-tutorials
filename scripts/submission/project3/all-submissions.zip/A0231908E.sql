/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231908E                               */
/******************************************************************************/
 SELECT test('SELECT per.empid , per.lname FROM employee per , payroll pay
WHERE per.empid = pay.empid AND pay.salary = 189170;', 1000);
 
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
SELECT per.empid , per.lname
FROM employee per , payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170 
ORDER BY per.empid , per.lname;
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid = pay.empid
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid = pay.empid
ORDER BY per.empid, per.lname;', 1000);
	

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.09 ms
-- Average Execution 4.39 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid,pay.salary
				   from payroll pay) AS temp
	WHERE per.empid=temp.empid
	and temp.salary=189170
ORDER BY per.empid, per.lname;
 
SELECT test('SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid,pay.salary
				   from payroll pay) AS temp
	WHERE per.empid=temp.empid
	and temp.salary=189170
ORDER BY per.empid, per.lname;', 1000);
	

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.09 ms
-- Average Execution 4.45 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid
	FROM payroll pay
	where per.empid=pay.empid
	and pay.salary !=189170 )
ORDER BY per.empid, per.lname;

SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid
	FROM payroll pay
	where per.empid=pay.empid
	and pay.salary !=189170 )
ORDER BY per.empid, per.lname;', 1000);

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.11 ms
-- Average Execution 9.94 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
 SELECT per.empid, per.lname
 FROM employee per , payroll pay
 WHERE per.empid = pay.empid 
 and pay.salary = all( 
	 select pay.salary
	 from payroll pay
	 where pay.salary= 189170);

SELECT test(' SELECT per.empid, per.lname
 FROM employee per , payroll pay
 WHERE per.empid = pay.empid 
 and pay.salary = all( 
	 select pay.salary
	 from payroll pay
	 where pay.salary= 189170);', 20);

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.18 ms
-- Average Execution 13.07 ms
