/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0218865R                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON pay.empid = per.empid AND pay.salary = 189170
WHERE per.empid is not null
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.14 ms
-- Average Execution 4.21 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary FROM payroll WHERE salary = 189170) AS temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.14 ms
-- Average Execution 3.87 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
   SELECT * FROM payroll pay
				 WHERE pay.empid = per.empid
				 AND pay.salary != 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.16 ms
-- Average Execution 9.07 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname FROM employee per
WHERE per.empid IN (SELECT per_empid from 
(
SELECT per2.empid as per_empid, pay.empid as pay_empid FROM employee per2, payroll pay
WHERE pay.salary not IN
(SELECT pay2.salary FROM payroll pay2
WHERE pay2.salary != 189170 
 AND EXISTS (select distinct e.empid from employee e where e.empid = pay2.empid)
 AND pay2.empid = pay.empid 
 AND pay2.empid = per.empid)
) temp WHERE per_empid = pay_empid);
-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.29 ms
-- Average Execution 238262.07 ms
