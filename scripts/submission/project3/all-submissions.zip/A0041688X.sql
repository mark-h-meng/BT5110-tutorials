/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0041688X                               */
/******************************************************************************/
SELECT per.empid, per.lname 
FROM employee per, payroll pay
WHERE per.empid = pay.empid 
AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid=pay.empid AND pay.salary = 189170
WHERE per.empid NOTNULL
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.07> ms
-- Average Execution <2.00> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid,salary from payroll) AS temp
	WHERE per.empid=temp.empid
	AND temp.salary=189170
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.08> ms
-- Average Execution <1.85> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
	SELECT pay.empid
	FROM payroll pay
	WHERE pay.empid=per.empid 
	AND pay.salary<>189170)
ORDER BY per.empid, per.lname;


-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.09> ms
-- Average Execution <4.19> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT 
  pay.empid, per.lname 
FROM 
  payroll pay, employee per 
WHERE per.empid IN (
	SELECT per1.empid 
    FROM employee per1 
    WHERE pay.empid = per.empid 
    AND per.empid <> ANY(
		SELECT per2.empid 
        FROM employee per2 
        WHERE per1.empid NOT IN (
			SELECT pay2.empid 
            FROM payroll pay2 
            WHERE NOT (pay.salary = 189170)))) 
ORDER by per.empid, per.lname;

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.15> ms
-- Average Execution <260701.98> ms
