/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0232022A                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/

SELECT per.empid , per. lname
FROM employee per RIGHT OUTER JOIN payroll pay
ON True AND pay. salary = 189170
WHERE per.empid = pay.empid
ORDER BY per.empid , per. lname ;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.12 ms
-- Average Execution 4.51 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, 
(SELECT empid,salary from payroll
where salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.18 ms
-- Average Execution 4.54 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT  empid,salary from payroll
where salary = 189170 and per.empid <> empid)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.1 ms
-- Average Execution 7.02 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

select empid, lname 
from employee t1
where t1.empid 
<> all (select empid from payroll t2
   where t2.salary+1 <> 189171 );

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.09 ms
-- Average Execution 17592.34ms
