/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231854E                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
	ON per.empid=pay.empid 
WHERE pay.salary =189170
ORDER BY per.empid, per.lname;

-- Average Planning <0.30> ms
-- Average Execution <9.11> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT pay.empid FROM payroll pay WHERE pay.salary = 189170) as temp
	WHERE per.empid = temp.empid
ORDER BY per.empid, per.lname;
 
-- Average Planning <0.28> ms
-- Average Execution <8.95> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT * FROM payroll pay
	WHERE per.empid = pay.empid
	AND pay.salary<>189170 )
ORDER BY per.empid, per.lname;

-- Average Planning <0.25> ms
-- Average Execution <18.50> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname FROM employee per
WHERE per.empid NOT IN (SELECT empid FROM payroll WHERE salary > 189170) 
	AND per.empid NOT IN (SELECT empid FROM payroll WHERE salary < 189170);

-- Average Planning <0.35> ms
-- Average Execution <49.08> ms
