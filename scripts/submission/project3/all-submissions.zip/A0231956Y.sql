/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231956Y                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per 
RIGHT OUTER JOIN payroll pay 
    ON per.empid=pay.empid 
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

-- For 100 executions of this query:
-- Average Planning <0.17> ms
-- Average Execution <3.95> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per, 
	(SELECT pay.empid,pay.salary
	from payroll pay
	where pay.salary=189170) AS temp
WHERE per.empid=temp.empid
ORDER BY per.empid, per.lname;
 
-- For 100 executions of this query,
-- Average Planning <0.17> ms
-- Average Execution <4.04> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT pay.empid
	FROM payroll pay
	WHERE pay.empid=per.empid
		and pay.salary!=189170)
ORDER BY per.empid, per.lname;

-- For 100 executions of this query,
-- Average Planning <0.17> ms
-- Average Execution <8.84> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT DISTINCT per.empid, per.lname
FROM employee per
WHERE per.empid IN (
    SELECT DISTINCT pay.empid
    FROM payroll pay 
    WHERE pay.empid=per.empid and 
    pay.salary NOT IN (SELECT DISTINCT sum(pay.salary)/count(pay.empid) as sal
                            FROM payroll pay
                            GROUP BY pay.salary 
                            HAVING sum(pay.salary)/count(pay.empid)=ANY(SELECT DISTINCT sum(pay.salary)/count(pay.empid) as sal
																		FROM payroll pay
																		GROUP BY pay.empid 
																		HAVING sum(pay.salary)/count(pay.empid)>189170
																	    ORDER BY sal)
					 
                       UNION
                       SELECT DISTINCT sum(pay.salary)/count(pay.empid)as sal
                            FROM payroll pay
                            GROUP BY pay.salary 
                            HAVING sum(pay.salary)/count(pay.empid)=ANY(SELECT DISTINCT sum(pay.salary)/count(pay.empid) as sal
																		FROM payroll pay
																		GROUP BY pay.empid 
																		HAVING sum(pay.salary)/count(pay.empid)<189170
																	    ORDER BY sal)
                       ORDER BY sal
                      )
    GROUP BY pay.empid
    ORDER BY pay.empid)
GROUP BY per.empid, per.lname
ORDER BY per.empid, per.lname;

-- For 20 executions of this query,
-- Average Planning <0.16> ms
-- Average Execution <27561.28> ms
