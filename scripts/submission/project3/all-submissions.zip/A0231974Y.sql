/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231974Y                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per RIGHT OUTER JOIN payroll pay ON TRUE AND per.empid = pay.empid
WHERE pay.salary = 189170
ORDER BY per.empid , per.lname;

SELECT test('SELECT per.empid , per.lname
FROM employee per RIGHT OUTER JOIN payroll pay ON TRUE AND per.empid = pay.empid
WHERE pay.salary = 189170
ORDER BY per.empid , per.lname;', 100);

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.08> ms
-- Average Execution <4.48> ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per, (SELECT *
					FROM payroll pay
				   WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid , per.lname;

SELECT test('SELECT per.empid , per.lname
FROM employee per, (SELECT *
					FROM payroll pay
				   WHERE pay.salary = 189170) AS temp
WHERE per.empid = temp.empid
ORDER BY per.empid , per.lname;', 100);

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.09> ms
-- Average Execution <4.64> ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per 
WHERE NOT EXISTS (
	SELECT *
	FROM payroll pay
	WHERE per.empid = pay.empid AND pay.salary <> 189170
)
ORDER BY per.empid , per.lname;

SELECT test('SELECT per.empid , per.lname
FROM employee per 
WHERE NOT EXISTS (
	SELECT *
	FROM payroll pay
	WHERE per.empid = pay.empid AND pay.salary <> 189170
)
ORDER BY per.empid , per.lname;', 100);

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.10> ms
-- Average Execution <10.15> ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
Select per.empid , per.lname
FROM employee per, payroll pay
WHERE per.empid = pay.empid

EXCEPT

Select per.empid , per.lname
FROM employee per, (Select *
				   FROM payroll pay
				   WHERE pay.salary <> 189170) AS temp
WHERE per.empid = temp.empid

Order By empid, lname;

SELECT test('Select per.empid , per.lname
FROM employee per, payroll pay
WHERE per.empid = pay.empid

EXCEPT

Select per.empid , per.lname
FROM employee per, (Select *
				   FROM payroll pay
				   WHERE pay.salary <> 189170) AS temp
WHERE per.empid = temp.empid

Order By empid, lname;', 20);

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning <0.23> ms
-- Average Execution <39.52> ms
