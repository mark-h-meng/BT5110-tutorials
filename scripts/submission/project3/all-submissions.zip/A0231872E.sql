/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231872E                              */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per RIGHT OUTER JOIN payroll pay ON per.empid = pay.empid AND pay.salary = 189170
where pay.salary = 189170
ORDER BY per.empid , per.lname;
	

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.08 ms
-- Average Execution2.64 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per, (SELECT * from payroll) AS temp 
WHERE per.empid = temp.empid
and temp.salary=189170
ORDER BY per.empid , per.lname;
 

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.06 ms
-- Average Execution 1.95 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid , per.lname
FROM employee per WHERE NOT EXISTS (
SELECT *
from payroll pay
where pay.empid=per.empid
and pay.salary<>189170)
ORDER BY per.empid , per.lname;

-- Indicate the average measured times for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.09 ms
-- Average Execution 5.02 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
select per.empid,per.lname
from employee per,payroll pay
where(per.empid,pay.empid) in (select A.empid1,A.empid2
        from(
 select (case when per1.empid<>pay1.empid
                      then null
                      else per1.empid end ) as empid1,pay1.empid as empid2
                         from payroll pay1,employee per1
          ) A)
and pay.empid not in(
select pay3.empid
from payroll pay3
where pay3.salary <>189170);

-- Indicate the average measured time for 1000 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.22 ms
-- Average Execution 296614.16 ms





