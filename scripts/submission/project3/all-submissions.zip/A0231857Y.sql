/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231857Y                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid = pay.empid AND pay.salary = 189170
WHERE per.empid IS NOT NULL
ORDER BY per.empid, per.lname;
	

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.65 ms
-- Average Execution 30.20 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per, (SELECT empid, salary FROM payroll) AS temp
	WHERE per.empid = temp.empid AND salary = 189170
ORDER BY per.empid, per.lname;
 

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.57 ms
-- Average Execution 29.62 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT * FROM payroll pay WHERE per.empid = pay.empid AND salary != 189170)
ORDER BY per.empid, per.lname;

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.78 ms
-- Average Execution 80.10 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/
SELECT DISTINCT per2.empid, per2.lname
FROM employee per2 
WHERE EXISTS (
    SELECT DISTINCT per_pay.empid
    FROM 
      (
        SELECT per.empid AS emp_id, per.lname, per.fname, per.address, per.city, per.state, per.zip, pay.empid, pay.bonus, pay.salary 
        FROM employee per, payroll pay 
        GROUP BY per.empid, per.lname, per.fname, per.address, per.city, per.state, per.zip, pay.empid, pay.bonus, pay.salary
        HAVING AVG(pay.salary) = (SELECT salary FROM payroll pay2 WHERE salary = 189170 AND pay.empid = pay2.empid)
        ORDER BY per.empid, per.lname, per.fname, per.address, per.city, per.state, per.zip, pay.empid, pay.bonus, pay.salary
      ) AS per_pay 
    WHERE per_pay.empid = per2.empid)
    ORDER BY per2.empid, per2.lname;


-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 20.16 ms
-- Average Execution 21,805,502.28 ms
