/******************************************************************************/
/* Fabian Pascal                                                              */
/* Indicate your student number here: A0231993X                               */
/******************************************************************************/
 SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;
 
 /*SELECT test(' SELECT per.empid, per.lname 
 FROM employee per, payroll pay
 WHERE per.empid = pay.empid 
 AND pay.salary = 189170;', 1000); */
 
/******************************************************************************/
/* Answer Question 2.a below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid=pay.empid AND pay.salary=189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;

/*SELECT test('SELECT per.empid, per.lname
FROM employee per RIGHT OUTER JOIN payroll pay 
    ON per.empid=pay.empid AND pay.salary=189170
WHERE pay.salary = 189170
ORDER BY per.empid, per.lname;', 100);  */
	

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.07 ms
-- Average Execution 1.85 ms

/******************************************************************************/
/* Answer Question 2.b below                                                  */
/******************************************************************************/
SELECT per.empid, per.lname
FROM employee as per, (SELECT pay.empid, pay.salary FROM payroll as pay) AS temp
	WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;

/*SELECT test('SELECT per.empid, per.lname
FROM employee as per, (SELECT pay.empid, pay.salary FROM payroll as pay) AS temp
	WHERE per.empid = temp.empid AND temp.salary = 189170
ORDER BY per.empid, per.lname;', 100);  */
 
-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.10 ms
-- Average Execution 1.98 ms

/******************************************************************************/
/* Answer Question 2.c below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT * 
	FROM payroll as pay
	WHERE pay.salary <> 189170 AND per.empid = pay.empid)
ORDER BY per.empid, per.lname;

/*SELECT test('SELECT per.empid, per.lname
FROM employee per
WHERE NOT EXISTS (
    SELECT * 
	FROM payroll as pay
	WHERE pay.salary <> 189170 AND per.empid = pay.empid)
ORDER BY per.empid, per.lname;', 100);  */

-- Indicate the average measured times for 100 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.10 ms
-- Average Execution 4.26 ms

/******************************************************************************/
/* Answer Question 3 below                                                  */
/******************************************************************************/

SELECT per.empid, per.lname, pay.salary
FROM employee as per, payroll as pay
WHERE per.empid = pay.empid AND pay.salary < ALL(
    SELECT pay1.salary
	FROM payroll as pay1
	WHERE per.empid = pay1.empid AND pay.empid = pay1.empid AND pay1.salary>189170)
INTERSECT
SELECT per2.empid, per2.lname, pay2.salary
FROM employee as per2, payroll as pay2
WHERE per2.empid = pay2.empid AND pay2.salary > ALL(
    SELECT pay3.salary
	FROM payroll as pay3
	WHERE per2.empid = pay3.empid AND pay3.empid = pay2.empid AND pay3.salary<189170)
ORDER BY empid, lname;


/* SELECT test('SELECT per.empid, per.lname, pay.salary
FROM employee as per, payroll as pay
WHERE per.empid = pay.empid AND pay.salary < ALL(
    SELECT pay1.salary
	FROM payroll as pay1
	WHERE per.empid = pay1.empid AND pay.empid = pay1.empid AND pay1.salary>189170)
INTERSECT
SELECT per2.empid, per2.lname, pay2.salary
FROM employee as per2, payroll as pay2
WHERE per2.empid = pay2.empid AND pay2.salary > ALL(
    SELECT pay3.salary
	FROM payroll as pay3
	WHERE per2.empid = pay3.empid AND pay3.empid = pay2.empid AND pay3.salary<189170)
ORDER BY empid, lname;', 20); */

--Successfully run. Total query runtime: 3 min 53 secs.

-- Indicate the average measured time for 20 executions for the query.
-- (replace <time> with the average time reported by test function).
-- Average Planning 0.18 ms
-- Average Execution 11570.57 ms
